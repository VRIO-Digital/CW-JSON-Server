# Prototypes - Waste Stream Analyst (Ironbridge Environmental Services)

Each HTML file opens from disk, with no server. The in-page mock server reads the same merged db as `json/00_merged/db.IRONBRIDGE.json`; New Role, Goals and Submissions read the package's `json/01_new_role/new_role.json`, `json/03_goals/` and `json/04_submissions/` content, written into the source by `_build/proto/make_proto_data.py`.

| Folder | File | What it is |
|---|---|---|
| `combined/` | `ContextWeave_Ironbridge_WSA_offline.html` | New Role, Graph Studio, Goals and Submissions in one build. |
| `new_role_graph_studio/` | `ContextWeave_Ironbridge_WSA_NewRole_GraphStudio_offline.html` | New Role and Graph Studio (`VITE_CW_ONLY=roles`). |
| `goals_and_submissions/` | `ContextWeave_Ironbridge_WSA_Goals_Submissions_offline.html` | Goals and Submissions (`VITE_CW_ONLY=journeys`). |
| `goals_only/` | `ContextWeave_Ironbridge_WSA_Goals_offline.html` | Only Goals in the menu (`VITE_CW_ONLY=goals`). |
| `submissions_only/` | `ContextWeave_Ironbridge_WSA_Submissions_offline.html` | Only Submissions, landing on Submissions (`VITE_CW_ONLY=submissions`). |
| `source/` | `ContextWeave_Ironbridge_WSA_source.zip` | The full source. `npm install`, then `./build_all.sh` writes the five files to `out_html/`. |
| `test/` | `walk_goals.mjs`, `walk_newrole.mjs` | Playwright click tests: `SUBS_FILE=<html with Submissions> node test/walk_goals.mjs <html with Goals> [widths]`; `node test/walk_newrole.mjs <html with New Role> [widths]`. At this build: 72 checks per width on Goals and Submissions, 65 on New Role and Graph Studio, no failures at 1280, 1440 and 1728. |

## Demo path

1. **New Role.** Add a new role: Waste Stream Analyst, Hazardous waste management. The three businesses are found in the connected data (Municipal solid waste finds nothing and says why). Step 2 accepts `uploads/01_new_role/Ironbridge_Job_Description_Waste_Stream_Analyst.pdf`: six suggested changes, among them a task to confirm the slot with the plant manager before a re-route is booked, the laboratory part of classification out of scope, and the 28% threshold on contract margin. Steps 3 to 6 offer the sources, personas, metrics with their SQL and hero questions. Save and build opens the role in Graph Studio.
2. **Graph Studio.** Build both lanes, form the Bridge, publish v1; the Playground holds the kept metrics with their queries, the Canvas draws the graph. The seeded Waste Stream Analyst role is already built and published.
3. **Goals, Answer once.** Use the Halden proposal example (it attaches the six profiles and the Delmar pricing schedule). Answer the two questions with a tile, or add `Halden_routing_working_2026-10.xlsx` or the acceptance policy from the + menu. Agree and run, take the checkpoint (Granger, with Port Terrell as the alternative), then say "Quote the QR-14 streams on Port Terrell": step 3 re-runs and the margin moves from 34.7% to 43.0% on capacity that is not confirmed. Accept the findings, choose, Build the pricing schedule in Submissions.
4. **Goals, Keep watching.** Open the outlet watch armed by Dana Whitfield and click Simulate tonight's load (4 November): the rule fires on 18 positions (14 shipments without an outlet after the Port Terrell kiln outage), the notice goes out, choose option 1, execute. The re-route notice lands in Submissions as a draft.
5. **Submissions.** The pricing schedule in the Delmar structure (seeded at the outline step), the acceptance memo and the quote letter from the Halden goal; the re-route notice and the re-route and outlet list from the watch. Describe a slide pack in words to see what it cannot place (competitor pricing and Halden's expansion plans are not connected).

The state is exposed for tests as `window.__cwJourney` (journey store, goal store, cases), `window.__cwSubs` (submissions), `window.__cwVisuals` and `window.__cwDesigner`.

## Kept in step with the package

`_build/proto/export_from_prototype.mjs` drives the combined build through every recorded journey and writes what its stores hold; `_build/proto/compare_with_prototype.py` compares that with the twelve Goals transcripts and the submissions in `json/`. The submissions take their sections and visuals, and the described slide pack its reading, from that export (`_build/proto/exported/`). `_build/contract_check.ts` drives the app's own API client through the mock server against `db.IRONBRIDGE.json`: 107 calls, none refused (`_build/contract_report.json`).
