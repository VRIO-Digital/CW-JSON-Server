// New Role and Graph Studio walkthrough for the Ironbridge Waste Stream Analyst prototype. Usage: node test/walk_newrole.mjs <absolute path to html> [widths]
import { createRequire } from 'module'
const { chromium } = createRequire(import.meta.url)(process.env.PLAYWRIGHT_PATH || 'playwright')
const FILE = process.argv[2] || new URL('../dist-offline/index.html', import.meta.url).pathname
const WIDTHS = (process.argv[3] || '1280,1440,1728').split(',').map(Number)
const F = 'file://' + FILE
const SHOTS = process.env.SHOTS || new URL('./shots', import.meta.url).pathname
const BANNED = /Keolis|Valmont|Veolia|Bramwell|Corrigan|Supply Chain Analyst|critical position|Capital Program|€|—|–|use case|Use case|New Graph|Weaver\b|\bAgent [A-Z][a-z]+|Outlook/i

const b = await chromium.launch()
let total = 0, fails = 0
for (const W of WIDTHS) {
  console.log(`== ${W}`)
  const p = await b.newPage({ viewport: { width: W, height: 900 } })
  const errs = []
  p.on('pageerror', (e) => errs.push(String(e)))
  p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()) })
  const ok = (c, m) => { total++; if (!c) { fails++; console.log('  FAIL', m) } }
  const shot = (n, full = false) => p.screenshot({ path: `${SHOTS}/newrole_${W}_${n}.png`, fullPage: full })
  const main = () => p.locator('.ant-layout-content, main').first()
  const clean = async (where) => { const t = await main().innerText(); const m = t.match(BANNED); ok(!m, `no banned text on ${where}${m ? `: "${m[0]}"` : ''}`) }
  const next = () => p.getByRole('button', { name: /^Next/ }).click()
  const toast = async (re) => { await p.waitForTimeout(300); return re.test(await p.locator('.ant-message').innerText().catch(() => '')) }
  const waitFor = async (fn, ms = 20000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await fn()) return true; await p.waitForTimeout(250) } return false }

  /* ---------- the first screen: add a new role */
  await p.goto(F + '#/K/new-graph'); await p.waitForTimeout(1800)
  ok(/Add a new role/.test(await main().innerText()), 'the first screen says Add a new role')
  ok(await p.locator('.nr-card').count() === 0, 'no role cards on the first screen')
  ok(await p.locator('.nr-opt').count() === 4, 'four roles to pick from')
  await shot('01_landing'); await clean('first screen')

  /* ---------- step 1: role */
  ok((await p.locator('.ng-step').allInnerTexts()).map((t) => t.replace(/\d/g, '').trim()).join('|') === 'Role|Responsibilities|Sources|Personas|Metrics|Hero questions', 'six steps: Role, Responsibilities, Sources, Personas, Metrics, Hero questions')
  await next(); ok(await toast(/Pick the role/), 'Next asks for a role first')
  await p.locator('.nr-opt', { hasText: 'Waste Stream Analyst' }).click()
  ok(await p.locator('.nr-ind').count() === 5, 'five industries offered')
  ok(/Municipal solid waste/.test(await p.locator('.nr-inds').innerText()), 'municipal solid waste offered')
  ok(await p.getByTestId('utilities').count() === 0, 'no businesses listed before an industry is picked')
  await p.locator('.nr-ind', { hasText: 'Municipal solid waste' }).click(); await p.waitForTimeout(3500)
  ok(/No municipal waste operations/.test(await p.getByTestId('utilities').innerText()), 'municipal waste: none found in the connected data')
  await p.locator('.nr-ind', { hasText: 'Hazardous waste management' }).click(); await p.waitForTimeout(1200)
  ok(/Finding the hazardous waste management businesses/.test(await p.getByTestId('utilities').innerText()) && await p.locator('.nr-util').count() === 0, 'hazardous waste: reading the connected data, businesses not shown yet')
  await shot('02_finding')
  ok(await waitFor(async () => (await p.locator('.nr-util').count()) === 3, 8000), 'three businesses found after the read')
  ok(await p.locator('.nr-util.is-on').count() === 3, 'all three are selected')
  ok(/State hazardous waste programs/.test(await p.getByTestId('utilities').innerText()) && /1,749 approved profiles/.test(await p.getByTestId('utilities').innerText()), 'businesses show region, programs, facilities and approved profiles')
  ok(await p.locator('text=Works for').count() === 0, 'no Works for field')
  await next(); ok(await toast(/email address/), 'Next asks for the reports-to email')
  await p.locator('#nr-reports').fill('dana.whitfield@vriodigital.com')
  ok(/Waste Stream Analyst · Midwest, Gulf, East/.test(await p.locator('#nr-name').inputValue()), 'role name filled from role and businesses')
  await shot('03_role', true); await clean('step 1')
  ok(!/utilit/i.test(await main().innerText()), 'step 1 speaks of businesses, not utilities')
  await next(); await p.waitForTimeout(600)

  /* ---------- step 2: responsibilities */
  ok(await p.locator('.ng-run-inline').count() === 1 && await p.locator('.nr-area').count() === 0, 'responsibilities are drafted after a short wait')
  ok(await waitFor(async () => (await p.locator('.nr-area').count()) === 6, 6000), 'six responsibilities drafted')
  await p.locator('.nr-area[data-area=submit] .ant-checkbox-input').uncheck()
  ok(/Out of scope/.test(await p.locator('.nr-area[data-area=submit]').innerText()) && await p.locator('.nr-area[data-area=submit] .gc-chip').count() === 3, 'taking one out asks for a reason')
  await p.locator('.nr-area[data-area=exposure] .nr-area-name').click()
  await p.locator('.nr-area[data-area=exposure] input[placeholder="Add a task"]').fill('Review the Riverbend floor positions each quarter'); await p.locator('.nr-area[data-area=exposure] button', { hasText: 'Add' }).click()
  ok(/Review the Riverbend floor positions each quarter/.test(await p.locator('.nr-area[data-area=exposure]').innerText()), 'a task added to a responsibility')
  await p.locator('input[type=file]').first().setInputFiles({ name: 'Ironbridge_Job_Description_Waste_Stream_Analyst.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-1.4') })
  await p.waitForTimeout(600)
  ok(/reading/.test(await p.getByTestId('jd').innerText()), 'job description is read after a short wait')
  ok(await waitFor(async () => (await p.locator('.nr-find').count()) >= 3, 6000), 'suggestions from the job description')
  await p.locator('.nr-find', { hasText: 'Add a task' }).first().getByRole('button', { name: 'Accept' }).click()
  ok(/Confirm the slot with the plant manager/.test(await p.locator('.nr-area[data-area=route]').innerText()), 'accepted task lands in Route in the network')
  await p.locator('.nr-find', { hasText: 'out of scope' }).first().getByRole('button', { name: 'Accept' }).click()
  ok(/Out of scope/.test(await p.locator('.nr-area[data-area=classify]').innerText()), 'accepted scope change takes the laboratory part out')
  ok(/4 of 6 responsibilities in scope/.test(await main().innerText()), '4 of 6 in scope')
  await shot('04_resp', true); await clean('step 2')
  ok(!/utilit/i.test(await main().innerText()), 'step 2 speaks of businesses, not utilities')
  await next(); await p.waitForTimeout(1000)

  /* ---------- step 3: sources */
  const srcText = await p.locator('.ng-form').innerText()
  ok(await p.locator('.ng-source').count() === 5, 'five connected sources')
  ok(/Ironbridge operations system/.test(srcText) && /Technical Solutions documents/.test(srcText) && /Technical Solutions mailbox/.test(srcText) && /BigQuery/.test(srcText) && /Google Drive/.test(srcText) && /Gmail/.test(srcText), 'operations, finance and legacy data, Google Drive and Gmail')
  await next(); ok(await toast(/Select at least one source/), 'Next asks for at least one source')
  for (const c of await p.locator('.ng-check').all()) await c.click()
  await shot('05_sources', true); await clean('step 3')
  await next(); await p.waitForTimeout(800)

  /* ---------- step 4: personas */
  await p.getByRole('button', { name: /Suggest personas/ }).click(); await p.waitForTimeout(700)
  ok(await p.locator('.ng-run-inline').count() === 1, 'personas are drafted after a short wait')
  ok(await waitFor(async () => (await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).count()) >= 5, 6000), 'personas suggested for the role')
  for (let i = 0; i < 4; i++) { await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).first().click(); await p.waitForTimeout(120) }
  ok(/Director of Technical Solutions/.test(await main().innerText()), 'the Director of Technical Solutions among the personas')
  await shot('06_personas', true); await clean('step 4')
  await next(); await p.waitForTimeout(800)

  /* ---------- step 5: metrics */
  await p.getByRole('button', { name: /Suggest metrics/ }).click()
  ok(await waitFor(async () => (await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).count()) > 5, 7000), 'metrics suggested')
  ok(/Matters to/.test(await main().innerText()), 'each metric says which personas it matters to')
  for (let i = 0; i < 5; i++) { await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).first().click(); await p.waitForTimeout(120) }
  ok(await waitFor(async () => (await p.locator('.nr-sql').count()) === 5, 6000), 'a query is written for each kept metric')
  await p.locator('.nr-sql summary').first().click()
  ok(/SELECT[\s\S]*FROM/.test(await p.locator('.nr-sql pre').first().innerText()), 'the query reads the warehouse tables')
  await shot('07_metrics', true); await clean('step 5')
  await next(); await p.waitForTimeout(800)

  /* ---------- step 6: hero questions */
  await p.getByRole('button', { name: /Suggest/ }).first().click()
  ok(await waitFor(async () => (await p.locator('.ng-form button', { hasText: /^\+?\s*Add$/ }).count()) > 4, 7000), 'questions suggested')
  for (let i = 0; i < 4; i++) { await p.locator('.ng-form button', { hasText: /^\+?\s*Add$/ }).first().click(); await p.waitForTimeout(250) }
  ok(!(await p.getByRole('button', { name: /Save and build graph/ }).isDisabled()), 'Save and build is enabled')
  await shot('08_questions', true); await clean('step 6')
  await p.getByRole('button', { name: /Save and build graph/ }).click(); await p.waitForTimeout(2500)

  /* ---------- Graph Studio: the new role */
  ok(/graph-studio\/uc-/.test(p.url()), 'opens the role in Graph Studio')
  ok(/Waste Stream Analyst · Midwest, Gulf, East/.test(await main().innerText()), 'the new role is selected')
  ok((await p.locator('.ant-tabs-tab').allInnerTexts()).join('|') === 'Build|Bridge|Playground|Canvas|Versions', 'tabs: Build, Bridge, Playground, Canvas, Versions')
  await p.getByRole('button', { name: /Draft from my data model/ }).click(); await p.waitForTimeout(1200)
  ok(/Ironbridge Environmental Services runs thirteen permitted/.test(await p.locator('textarea').first().inputValue()), 'story drafted from the data model')
  await p.getByRole('button', { name: /Build graph/ }).click()
  { const okb = await waitFor(async () => /Complete · (\d+) of \1 documents/.test(await main().innerText()) && /\d+ tables/.test(await main().innerText()), 30000); const mt = await main().innerText(); ok(okb, `both lanes build (${(mt.match(/Complete · \d+ of \d+ documents/) ?? ['?'])[0]}; ${(mt.match(/\d+ tables/) ?? ['?'])[0]})`); console.log('  build:', (mt.match(/.{0,60}(of \d+ documents|\d+ tables).{0,40}/g) ?? []).slice(0, 4).join(' | ')) }
  await shot('09_built', true); await clean('Build')
  await p.locator('.ant-tabs-tab', { hasText: 'Bridge' }).click()
  ok(await waitFor(async () => /Bridge build 1/.test(await main().innerText()), 15000), 'the Bridge is formed')
  await p.getByRole('button', { name: /Accept all/ }).click(); await p.waitForTimeout(500)
  await p.locator('.ant-popover .ant-btn-primary, .ant-popconfirm .ant-btn-primary').first().click(); await p.waitForTimeout(1200)
  await p.getByRole('button', { name: /Publish v1/ }).click(); await p.waitForTimeout(1500)
  ok(await waitFor(async () => /answering/.test(await main().innerText()), 6000), 'published: the Bridge is answering')
  await shot('10_bridge'); await clean('Bridge')
  await p.locator('.ant-tabs-tab', { hasText: 'Playground' }).click(); await p.waitForTimeout(1500)
  const pg = await main().innerText()
  ok(/Capacity booked against permitted|Unit headroom|Full cost a ton|Contract margin/.test(pg) && /SELECT/.test(pg), 'Playground holds the kept metrics with their queries')
  await clean('Playground')
  await p.locator('.ant-tabs-tab', { hasText: 'Canvas' }).click(); await p.waitForTimeout(2500)
  ok(/\d+ nodes/.test(await main().innerText()), 'Canvas draws the graph')
  await shot('11_canvas'); await clean('Canvas')
  await p.locator('.ant-tabs-tab', { hasText: 'Versions' }).click(); await p.waitForTimeout(1200)
  ok(/v1[\s\S]*published/.test(await main().innerText()), 'Versions: v1 published')
  await clean('Versions')

  /* ---------- back to New Role: a fresh wizard; the seeded role opens in Graph Studio */
  await p.locator('.ant-menu-item, a', { hasText: 'New Role' }).first().click(); await p.waitForTimeout(1500)
  ok(/Add a new role/.test(await main().innerText()) && await p.locator('.nr-card').count() === 0, 'New Role opens on a fresh Add a new role')
  await p.goto(F + '#/K/graph-studio/uc-waste-stream-analyst-ib26a01'); await p.waitForTimeout(2500)
  const st = await main().innerText()
  ok(/Waste Stream Analyst · Ironbridge Environmental Services/.test(st) && /Build v1 · complete/.test(st) && /Graph v1 · published/.test(st), 'the seeded role: both lanes built and published')
  await clean('seeded role')
  ok(errs.length === 0, `no console errors${errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''}`)
  await p.close()
}
console.log(`${total} checks, ${fails} failures`)
await b.close()
process.exit(fails ? 1 : 0)
