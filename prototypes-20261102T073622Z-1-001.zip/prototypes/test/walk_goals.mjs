// Goals and Submissions walkthroughs for the Ironbridge Waste Stream Analyst prototype. Usage: node test/walk_goals.mjs <absolute path to html> [widths]
import { createRequire } from 'module'
const { chromium } = createRequire(import.meta.url)(process.env.PLAYWRIGHT_PATH || 'playwright')
const FILE = process.argv[2] || new URL('../dist-offline/index.html', import.meta.url).pathname
const WIDTHS = (process.argv[3] || '1280,1440,1728').split(',').map(Number)
const F = 'file://' + FILE
// Section 8 (Submissions on its own) runs against SUBS_FILE when set: the Submissions-only build.
const SHOTS = process.env.SHOTS || new URL('./shots', import.meta.url).pathname
const b = await chromium.launch()
let fails = 0, checks = 0
const ok = (c, m) => { checks++; if (!c) { fails++; console.log('  FAIL', m) } }
const BANNED = /Keolis|Valmont|Veolia|Bramwell|Corrigan|Sabine Coast|Helena Marsh|Rafael Duarte|ferric|Kiln 2|Arcwood|framework|€|—|–|\bEUR\b|Capital Program/

for (const W of WIDTHS) {
  console.log(`== ${W}`)
  const ctx = await b.newContext({ viewport: { width: W, height: 900 }, acceptDownloads: true })
  const p = await ctx.newPage()
  const errs = []
  p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()) })
  p.on('pageerror', (e) => errs.push(String(e)))
  const shot = (n) => p.screenshot({ path: `${SHOTS}/goals_${W}_${n}.png` })
  const J = () => p.evaluate(() => { const s = window.__cwJourney.useJourney.getState(); const j = s.current ? s.goals[s.current] : null; return j ? { id: j.id, stage: j.stage, status: j.status, findings: j.findings, answers: j.answers, chosen: j.chosen, nodes: j.nodes.map((n) => n.id), chips: j.chips, history: j.history.length, exec: j.exec ? { state: j.exec.state, done: j.exec.done } : null, outputs: j.outputs.length, saved: s.saved.length } : { saved: s.saved.length } })
  const clean = async (where) => { const t = await p.evaluate(() => document.body.innerText); const m = t.match(BANNED); ok(!m, `${where}: no old-story text or em-dash (${m ? t.slice(Math.max(0, m.index - 40), m.index + 40).replace(/\n/g, ' ') : ''})`) }
  const rail = (id) => ({ innerText: async () => {
    let peeked = false
    if (!(await p.locator('.hub-rail').count())) { await p.locator('.hub-top .hub-icon[aria-label="Show the list"]').first().click(); await p.waitForTimeout(250); peeked = true }
    const t = await p.locator(`[id="${id}"]`).first().innerText()
    if (peeked) { await p.locator('.hub-veil').click().catch(() => {}); await p.waitForTimeout(200) }
    return t
  }, locator: (sel) => p.locator(`[id="${id}"] ${sel}`) })
  const chip = (t) => p.locator('.gc-chip', { hasText: t }).first()
  const waitFor = async (fn, ms = 20000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await fn()) return true; await p.waitForTimeout(250) } return false }
  const newGoal = async () => { if (!/#\/K\/goals/.test(p.url())) { await p.goto(F + '#/K/goals'); await p.waitForTimeout(600) } if (await p.locator('.hub-new').count()) { await p.locator('.hub-new').click(); await p.waitForTimeout(500) } await p.locator('.ns-toggle button', { hasText: 'Answer once' }).click().catch(() => {}); await p.waitForTimeout(200) }
  const closeToasts = async () => { for (const x of await p.locator('.ant-notification-notice-close').all()) await x.click().catch(() => {}) }

  /* ---------- 0: the list */
  await p.goto(F + '#/K/goals'); await p.waitForTimeout(1200)
  const railText = await p.locator('.hub').first().innerText()
  ok(/Needs you/.test(railText) && /Findings ready/.test(railText) && /Standing goals/.test(railText) && /Executed/.test(railText) && /Saved plans/.test(railText), 'five groups: Needs you, Findings ready, Standing goals, Executed, Saved plans')
  ok(await p.locator('.rl-lib').count() === 0, 'no Library button above the list')
  ok((await rail('j-saved').innerText()).match(/new goal from it/g)?.length === 2, 'Saved plans group holds the two saved plans')
  ok(await p.locator('.ns-h', { hasText: 'Or start from a saved plan' }).count() === 1 && await p.locator('.ns-card:not(.is-static)').count() >= 1, 'start screen shows saved-plan cards')
  ok(await p.locator('.ns-lib').count() === 0, 'no Library link on the start screen')
  await shot('start_saved')
  await clean('start')

  /* ---------- 1: answer once, the Halden proposal */
  await p.getByText('Use the Halden proposal example').click(); await p.waitForTimeout(200)
  await p.locator('.composer.is-big .send').click()
  ok(await waitFor(async () => (await p.locator('.hc[data-q="cap"]').count()) > 0), 'first question appears')
  ok((await rail('j-needs').innerText()).includes('Halden Biopharma proposal'), 'a draft goal sits under Needs you')
  await shot('q1')
  await p.locator('.hc[data-q="cap"] .tile').nth(3).click()
  ok(await waitFor(async () => (await p.locator('.hc[data-q="spec"]').count()) > 0), 'second question appears')
  await p.locator('.hc[data-q="spec"] .tile').nth(0).click()
  ok(await waitFor(async () => (await J()).stage === 'plan'), 'plan stage after the two answers')
  // edit a row through the chat
  await p.locator('.bf-row[data-row="success"] .bf-edit').click(); await p.waitForTimeout(200)
  await p.locator('.hub-input textarea').type('every stream has a named unit, a priced route and a stated fallback')
  await p.locator('.hub-input .send').click(); await p.waitForTimeout(1500)
  ok((await J()).history >= 1, 'row edit is logged as a change')
  await chip('Add a what-if').click(); await p.waitForTimeout(1200)
  await p.locator('.diff .ant-btn-primary').last().click(); await p.waitForTimeout(600)
  ok((await J()).nodes.includes('f1'), 'what-if fork added')
  await shot('plan'); await clean('plan')
  await chip('Agree and run').click()
  ok(await waitFor(async () => (await J()).status === 'wait'), 'run stops at the checkpoint')
  ok((await rail('j-needs').innerText()).includes('checkpoint'), 'checkpoint shows under Needs you')
  await p.locator('.hc[data-cp] .tile').nth(0).click()
  ok(await waitFor(async () => (await J()).status === 'ready', 25000), 'findings ready')
  ok((await rail('j-ready').innerText()).includes('Halden Biopharma proposal'), 'goal sits under Findings ready')
  ok((await p.locator('.hub-feed').innerText()).includes('34.7%'), 'findings message carries the margin 34.7%')
  await chip('Quote the QR-14 streams on Port Terrell').click(); await p.waitForTimeout(1200)
  await p.locator('.diff .ant-btn-primary').last().click()
  ok(await waitFor(async () => (await J()).findings.includes('F3b'), 8000), 'steer re-runs step 3, finding 3 changes')
  await p.waitForTimeout(1500)
  ok(await p.evaluate(() => { const s = window.__cwJourney.useJourney.getState(); const j = s.goals[s.current]; return j.recs[0]?.title.includes('on Port Terrell') }), 'the recommendation follows the steer: on Port Terrell')
  await shot('findings'); await clean('findings')
  await chip('Accept all findings').click(); await p.waitForTimeout(1200)
  await p.locator('.reco .ant-btn', { hasText: 'Why this' }).first().click(); await p.waitForTimeout(800)
  ok(await p.locator('.reco').first().innerText().then((t) => /Hide the path/.test(t)), 'why this opens the path')
  await p.locator('.reco .ant-btn', { hasText: 'Choose' }).first().click(); await p.waitForTimeout(1200)
  ok(!!(await J()).chosen, 'recommendation chosen')
  ok((await rail('j-executed').innerText()).includes('Halden Biopharma proposal'), 'answer-once goal moves to Executed')
  ok(!(await rail('j-ready').innerText()).includes('Halden Biopharma proposal'), 'and leaves Findings ready')
  await chip('Save this plan').click(); await p.waitForTimeout(800)
  ok((await J()).saved === 3, 'plan saved')
  ok((await rail('j-saved').innerText()).match(/new goal from it/g)?.length === 3, 'saved plan appears under Saved plans')
  await chip('Build the pricing schedule in Submissions').click()
  ok(await waitFor(async () => /\/submissions\/sub-/.test(p.url()), 5000), 'opens the pricing schedule in Submissions')
  await p.waitForTimeout(800); await shot('sub_from_goal'); await clean('submission from goal')

  /* ---------- 2: the seeded standing goal fires, waits for review, executes */
  await p.goto(F + '#/K/goals'); await p.waitForTimeout(800)
  if (!(await p.locator('.hub-rail').count())) { await p.locator('.hub-top .hub-icon[aria-label="Show the list"]').first().click(); await p.waitForTimeout(250) }
  await p.locator('[id="j-standing"] .rl-mini').first().click()
  ok(await waitFor(async () => (await p.locator('.ant-notification-notice', { hasText: 'Standing goal fired' }).count()) > 0, 4000), 'fired: notification pops')
  ok(await waitFor(async () => (await J()).status === 'ready', 20000), 'analysis done')
  const toast = p.locator('.ant-notification-notice', { hasText: 'Recommends' })
  ok(await waitFor(async () => (await toast.count()) > 0, 3000), 'notification says what it found and what it recommends')
  { const tt = await toast.first().innerText(); ok(/found/i.test(tt) && /Re-route nine shipments to Granger/.test(tt), 'notification carries the finding and the recommendation') }
  await shot('watch_notified')
  ok((await rail('j-needs').innerText()).includes('Nightly load, 4 November'), 'the fired run sits under Needs you')
  ok((await rail('j-standing').innerText()).includes('1 run waits for you'), 'the standing goal says a run waits')
  await toast.first().locator('.ant-btn', { hasText: 'Review it' }).click(); await p.waitForTimeout(600)
  await closeToasts()
  await chip('Accept all findings').click(); await p.waitForTimeout(1200)
  await chip('Choose option 1').click(); await p.waitForTimeout(1200)
  ok((await J()).exec?.state === 'confirm', 'choosing shows what will be executed, nothing done yet')
  ok((await J()).status !== 'executed', 'not executed before you say so')
  ok((await rail('j-needs').innerText()).includes('ready to execute'), 'still under Needs you, ready to execute')
  await shot('watch_confirm'); await clean('execute confirm')
  await p.locator('.hc-exec .ant-btn', { hasText: 'Execute' }).click()
  ok(await waitFor(async () => (await J()).status === 'executed', 8000), 'executed')
  ok((await rail('j-executed').innerText()).includes('Nightly load, 4 November'), 'run moves to Executed')
  ok(!(await rail('j-needs').innerText()).includes('Nightly load, 4 November'), 'and leaves Needs you')
  ok((await rail('j-standing').innerText()).includes('Armed'), 'the watch stays armed under Standing goals')
  ok(await waitFor(async () => (await p.locator('.ant-notification-notice', { hasText: 'Executed' }).count()) > 0, 3000), 'executed: notification pops')
  const subs = await p.evaluate(() => window.__cwSubs ? window.__cwSubs.getState().submissions.map((s) => s.title) : [])
  ok(subs.some((t) => /Re-route notice/.test(t)), 'execution drafted the re-route notice in Submissions')
  await shot('watch_executed'); await closeToasts()
  await p.locator('button[aria-label="Notifications"]').first().click(); await p.waitForTimeout(800)
  const drawer = await p.locator('.ant-drawer', { hasText: 'Notifications' }).last().innerText()
  ok(/recommends/i.test(drawer) && /Executed/.test(drawer), 'bell holds fired, found and executed notices')
  await shot('bell'); await p.keyboard.press('Escape'); await p.waitForTimeout(400)
  await clean('executed')

  /* ---------- 3: a new standing goal, armed */
  await newGoal()
  await p.locator('.ns-toggle button', { hasText: 'Keep watching' }).click()
  await p.getByText('Use the outlet watch example').click(); await p.locator('.composer.is-big .send').click()
  ok(await waitFor(async () => (await p.locator('.hc[data-q="fires"]').count()) > 0), 'watch: first question')
  await p.locator('.hc[data-q="fires"] .tile').nth(1).click()
  ok(await waitFor(async () => (await p.locator('.hc[data-q="tell"]').count()) > 0), 'watch: second question')
  await p.locator('.hc[data-q="tell"] .tile').nth(2).click()
  ok(await waitFor(async () => (await J()).stage === 'plan'), 'watch plan ready')
  await p.locator('.pd-foot .ant-btn-primary').click()
  ok(await waitFor(async () => (await J()).stage === 'armed'), 'armed')
  ok((await rail('j-standing').innerText()).match(/Every accepted stream has an outlet with capacity/g)?.length >= 2, 'two standing goals')

  /* ---------- 4: the short positions as a one-off */
  await newGoal()
  await p.getByText('shipments in the 4 November load with no outlet: what can still be done?').click(); await p.locator('.composer.is-big .send').click()
  ok(await waitFor(async () => (await J()).chips?.includes('Agree and run'), 15000), 'shortfall one-off: plan with nothing to ask')
  await p.locator('.pd-foot .ant-btn-primary').click()
  ok(await waitFor(async () => (await J()).findings.length === 4 && (await J()).status === 'ready', 20000), 'shortfall one-off: four findings')
  await chip('Accept all findings').click(); await p.waitForTimeout(1000)
  await chip('Choose option 1').click(); await p.waitForTimeout(1000)
  ok((await rail('j-executed').innerText()).includes('Fourteen shipments in the 4 November load'), 'shortfall one-off moves to Executed')
  await clean('shortfall one-off')

  /* ---------- 5: a goal the copy has no recorded analysis for */
  await newGoal()
  await p.locator('.composer.is-big textarea').fill('What is the carbon footprint of hauling the Halden streams to Granger instead of Port Terrell?')
  await p.locator('.composer.is-big .send').click()
  ok(await waitFor(async () => (await J()).chips?.includes('Agree and run'), 15000), 'generic: plan')
  await p.locator('.pd-foot .ant-btn-primary').click()
  ok(await waitFor(async () => (await J()).status === 'ready', 15000), 'generic: runs and stops honestly')
  ok((await p.locator('.hub-feed').innerText()).includes('no recorded analysis'), 'generic: says it has no recorded analysis')

  /* ---------- 6: a document from Google Drive answers both questions */
  await newGoal()
  await p.getByText('Use the Halden proposal example').click()
  await p.locator('.composer.is-big .cmp-btn').click(); await p.locator('.cmenu .mi', { hasText: 'Google Drive' }).click()
  await p.locator('.cmenu .mi', { hasText: 'Halden_routing_working_2026-10.xlsx' }).click()
  await p.locator('.composer.is-big .send').click()
  ok(await waitFor(async () => (await J()).stage === 'plan', 20000), 'working notes settle both questions')
  const jj = await J(); ok(jj.answers.cap === 'granger' && jj.answers.spec === 'incinerate', 'answers taken from the notes')
  await p.evaluate(() => { const s = window.__cwJourney.useJourney.getState(); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id: s.current, tab: 'data' } })) }); await p.waitForTimeout(900); await shot('data_streams')
  { const t = await p.locator('.ws').first().innerText().catch(() => ''); ok(/Methanol and DMSO/.test(t) && /QR-14/.test(t) && /US dollars/.test(t), 'data tab opens on the streams sheet, in US dollars') }
  await p.locator('.ws-tab', { hasText: 'Positions' }).click().catch(() => {}); await p.waitForTimeout(400)
  { const t = await p.locator('.ws').first().innerText().catch(() => ''); ok(/MN-3437842/.test(t) && /Granger/.test(t), 'positions sheet lists the flagged manifests') }
  await clean('from google drive')

  /* ---------- 7: the review made standing, on a schedule */
  await newGoal()
  await p.locator('.ns-toggle button', { hasText: 'Keep watching' }).click()
  await p.getByText('Network position and open quotes after every month-end close').click(); await p.locator('.composer.is-big .send').click()
  ok(await waitFor(async () => (await p.locator('.hc[data-q="tell"]').count()) > 0), 'schedule: who is told')
  await p.locator('.hc[data-q="tell"] .tile').nth(0).click()
  ok(await waitFor(async () => (await J()).stage === 'plan'), 'schedule: plan')
  await p.locator('.pd-foot .ant-btn-primary').click()
  ok(await waitFor(async () => (await J()).stage === 'armed'), 'schedule: armed')
  await p.locator('.panel-actions button', { hasText: 'Simulate' }).click()
  ok(await waitFor(async () => (await J()).status === 'ready', 30000), 'schedule: run lands findings')

  /* ---------- 8: Submissions on its own */
  await p.goto('about:blank'); await p.goto((process.env.SUBS_FILE ? 'file://' + process.env.SUBS_FILE : F) + '#/K/submissions'); await p.waitForTimeout(900)
  await p.getByText('Pricing schedule: Halden Biopharma 2027 to 2029').first().click(); await p.waitForTimeout(800)
  for (let i = 0; i < 6; i++) { const c = p.locator('.gc-chip', { hasText: /^Next$|Build it|Continue/ }).first(); if (await c.count()) await c.click(); else { const btn = p.locator('.hc .ant-btn-primary').last(); if (await btn.count()) await btn.click() } await p.waitForTimeout(1500) }
  const deck = await p.evaluate(() => document.body.innerText)
  ok(/Granger/.test(deck) && /34\.7%|\$1\.24M/.test(deck), 'seeded pricing schedule drafts from the goal with the proposal figures')
  const tpl = await p.evaluate(() => window.__cwSubs.getState().templates.map((t) => t.id))
  ok(['t-prior-pricing-2024', 't-ts-acceptance-memo', 't-cust-quote-letter', 't-ts-pricing-schedule', 't-ts-reroute-notice', 't-ts-reroute-list'].every((x) => tpl.includes(x)), 'the six story templates are in the library')
  await shot('deck'); await clean('deck')

  ok(errs.length === 0, `no console errors (${errs.slice(0, 3).join(' | ')})`)
  await ctx.close()
}
console.log(`${checks} checks, ${fails} failures`)
await b.close()
process.exit(fails ? 1 : 0)
