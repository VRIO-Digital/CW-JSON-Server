/* Drives api/client.ts through the in-page mock server, so every payload passes the client's real validators. */
const store: Record<string, string> = {}
;(globalThis as any).window = globalThis
;(globalThis as any).localStorage = { getItem: (k: string) => store[k] ?? null, setItem: (k: string, v: string) => (store[k] = String(v)), removeItem: (k: string) => delete store[k] }
store['contextweave.dataset'] = 'KEOLIS'
;(globalThis as any).location = { hash: '#/K/goals', href: 'http://x/#/K/goals' }
import { handle } from './src/mock/server'
import RAW from './src/mock/db.json'
;(globalThis as any).fetch = async (input: any, init: any = {}) => {
  const url = String(input)
  const at = url.indexOf('/api/backend')
  const rest = at >= 0 ? url.slice(at + 12) : url.replace(/^https?:\/\/[^/]+/, '')
  const qi = rest.indexOf('?')
  const path = qi >= 0 ? rest.slice(0, qi) : rest
  const query = new URLSearchParams(qi >= 0 ? rest.slice(qi + 1) : '')
  const body = init.body ? JSON.parse(init.body) : undefined
  const res: any = await handle((init.method || 'GET').toUpperCase(), path, query, body)
  if (res.stream) return new Response(res.stream, { status: res.status, headers: { 'content-type': 'text/event-stream' } })
  return new Response(JSON.stringify(res.json ?? {}), { status: res.status, headers: { 'content-type': 'application/json' } })
}
import * as C from './src/api/client'
const out: any[] = []
async function t(name: string, f: () => Promise<any>) {
  try { const v = await f(); out.push({ name, ok: true, v }); return v } catch (e: any) { out.push({ name, ok: false, error: String(e?.message || e).slice(0, 700) }); return null }
}
export async function run() {
  const db: any = RAW
  for (const [name, fn] of Object.entries(C)) {
    if (typeof fn !== 'function' || !/^(get|list)/.test(name) || (fn as any).length > 0 || name === 'getWhatIfFrame' || name === 'listStudioGraphs') continue
    await t(name, () => (fn as any)())
  }
  const uc = db.graph_use_cases[0].use_case_id
  for (const n of ['getStudioUseCase', 'listSgbBuilds', 'listDgbBuilds', 'listCorpusDocuments', 'getPlayground', 'listBridgeBuilds', 'listGraphVersions', 'getPublishedGraphVersion', 'listDgbClasses', 'getPublishedBridge'])
    await t(`${n}(uc)`, () => (C as any)[n](uc))
  const srcs: any = await t('listSources', () => C.listSources())
  const rows = srcs?.sources || srcs?.rows || []
  for (const s of rows) {
    const id = s.source_id || s.sourceId
    const kind = s.kind
    if (kind === 'bigquery') { await t(`browseSource(${id})`, () => C.browseSource(id)); await t(`getProfiledColumns(${id})`, () => C.getProfiledColumns(id)) }
    if (kind === 'gdrive') await t(`getProfiledDocuments(${id})`, () => (C as any).getProfiledDocuments(id))
    if (kind === 'gmail') { await t(`getProfiledMailDocuments(${id})`, () => (C as any).getProfiledMailDocuments(id)); await t(`getMailRun(${id})`, () => C.getMailRun(id)) }
  }
  await t('listDriveFolders', () => C.listDriveFolders(db.drives[0].drive_id))
  for (const r of db.reports.reports) await t(`getReport(${r.report_id})`, () => C.getReport(r.report_id))
  const counts: any = {}
  for (const d of db.graph_domains) {
    const p: any = await t(`suggestPersonas(${d.domain_id})`, () => C.suggestPersonas({ domainId: d.domain_id, businessNeed: '' }))
    const names = (p?.suggestions || []).map((x: any) => x.name)
    const m: any = await t(`suggestMetrics(${d.domain_id})`, () => C.suggestMetrics({ domainId: d.domain_id, businessNeed: '', personas: names }))
    const q: any = await t(`suggestQuestions(${d.domain_id})`, () => C.suggestQuestions({ domainId: d.domain_id, businessNeed: '', personas: names }))
    counts[d.domain_id] = { personas: names.length, metrics: m?.suggestions?.length, questions: q?.suggestions?.length }
  }
  out.push({ name: 'pool_counts', ok: true, v: counts })
  const srcIds = rows.map((s: any) => s.source_id || s.sourceId)
  let answered = 0
  for (const a of db.ask_answers) {
    const r: any = await t(`ask ${a.answer_id}`, () => C.askQuestionStreaming(uc, a.question, { citations: 'required', formats: [] } as any, srcIds, () => {}))
    if (r && (r.answerId === a.answer_id || r.answer_id === a.answer_id)) answered++
  }
  out.push({ name: 'ask_matched', ok: true, v: answered })
  return out.map((x) => (x.name === 'pool_counts' || x.name === 'ask_matched' ? x : { name: x.name, ok: x.ok, error: x.error }))
}
