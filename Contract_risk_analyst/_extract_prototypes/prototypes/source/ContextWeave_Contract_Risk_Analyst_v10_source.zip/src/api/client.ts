/*
 * Client for the JSON server in backend/. Vite proxies /api/* to it with
 * the /api prefix stripped, so the paths below mirror the real endpoint names.
 *
 * This is the app's only data source — start it with `npm run mock`.
 *
 * Where that server lives is the one thing that differs between environments,
 * and it is decided by `VITE_API_BASE` in the .env files, never here:
 *
 *   development  /api                      → the Vite proxy → localhost:4000
 *   production   http://<host>:4000        → the deployed mock server, directly
 *
 * Every request then goes under `/backend`, the prefix the server serves its endpoints at, appended
 * here rather than written into each of the ~200 paths below or into each .env file.
 *
 * Relative `/api` is the default when the variable is unset, so a build served
 * behind a proxy that already strips /api (deploy/nginx.conf.template) keeps
 * working untouched. Do not hardcode an origin below — check-docs fails on one.
 */

import type { Stat, Tone } from '../types'
import {
  arrayOf,
  bool,
  nullable,
  num,
  oneOf,
  shape,
  str,
  validate,
  variant,
  // `Check` is already taken in this file by the eval-checks payload type, so the
  // validator's own is aliased rather than renaming a public type.
  type Check as FieldCheck,
} from './validate'

import { currentDataset, resetDatasetIfRefused } from './dataset'

/**
 * The prefix the server serves every endpoint under — `backend/server.js`'s own `API_PREFIX`, which it
 * strips once in its dispatcher.
 *
 * It is a **path**, not an origin, which is why it is written here rather than in a `.env` file: where
 * the API lives differs per environment and belongs in `VITE_API_BASE`; *what the API calls its own
 * endpoints* is the same in every environment and is the server's fact, not the deployment's. Folding
 * it into `BASE` is what keeps the ~200 paths below spelled the way the server declares them.
 *
 * The two literals are a contract the compiler cannot see, exactly as `x-dataset` is, so `check-docs`
 * asserts this string and the server's are the same one.
 */
const API_PREFIX = '/backend'

// The trailing slash is stripped because every path below starts with one, and
// `${BASE}${path}` would otherwise ask for //sources.
const BASE =
  (import.meta.env.VITE_API_BASE ?? '/api').replace(/\/$/, '') + API_PREFIX

/* ---------------- Datasets ---------------- */

/** One tenant dataset, with what it actually holds. */
export type DatasetRow = {
  dataset: string
  label: string
  primary: boolean
  ref: string
  store: string
  projects: number
  drives: number
  reports: number
  graphs: number
  populated: boolean
}

export type DatasetsPayload = {
  datasets: DatasetRow[]
  both: { dataset: string; label: string; readOnly: boolean }
  selected: string
}

/**
 * Which datasets this tenant has, and which one this call was answered from.
 *
 * `selected` is the server's reading of the header the request carried, so it is what proves the
 * selection arrived — a selector showing CAPEX while every payload came from EPA is the failure
 * this endpoint makes visible.
 */
export async function listDatasets(): Promise<DatasetsPayload> {
  const raw = validate<{
    datasets: DatasetRow[]
    both: { dataset: string; label: string; read_only: boolean }
    selected: string
  }>('The dataset list', await request<unknown>('/datasets'), DATASETS_PAYLOAD)

  return {
    datasets: raw.datasets,
    both: { dataset: raw.both.dataset, label: raw.both.label, readOnly: raw.both.read_only },
    selected: raw.selected,
  }
}

/* ---------------- The report prototype's dataset ---------------- */

/**
 * The Authoring tab's sample data, from `s3://contextweave.com/EPA/reports_prototype.json`.
 *
 * It used to be `import dataset from './data/dataset.json'` — compiled into the bundle, so editing a
 * figure meant a rebuild and a redeploy, and it was the one thing on screen the bucket could not change.
 *
 * Typed as `unknown` on purpose: the prototype declares these shapes itself (`Dataset` in
 * `src/reports/data.ts`) and validates them on receipt, the same way it declares the `Governance` payload
 * rather than importing this file's types. Absent its host it is exactly the standalone prototype it was.
 */
export async function getReportsPrototypeDataset(): Promise<{
  ref: string
  store: string
  dataset: unknown
}> {
  return validate<{ ref: string; store: string; dataset: unknown }>(
    "The report prototype's dataset",
    await request<unknown>('/reports/prototype'),
    PROTOTYPE_PAYLOAD,
  )
}

/* ---------------- Identity ---------------- */

/** One persona the login form's role dropdown offers. */
export interface AuthRole {
  roleId: string
  label: string
  /** What this role can and cannot see — shown again on the signed-in card. */
  accessNote: string
}

export interface AuthRolesPayload {
  roles: AuthRole[]
  count: number
}

/**
 * Who is signed in. This is a persona demo, not a user directory — there is no
 * account store behind it, so the identity is exactly what the login form
 * collected plus what the chosen role implies. Nothing here should be read as
 * real authentication.
 */
export interface SessionIdentity {
  email: string
  /**
   * The user's own name, from the settings store.
   *
   * The login used to have none to report — it collected an address and a role and nothing else, which
   * is why the avatar is initials rather than a name. Now the address resolves to a user, so this is
   * read rather than invented.
   */
  name: string
  /** **Looked up, not claimed.** The settings store says which persona this address is. */
  roleId: string
  roleLabel: string
  accessNote: string
  /** Derived from the email, which is still what the avatar draws. */
  initials: string
  signedInAt: string
}

/* ---------------- Connect-a-source flow ---------------- */

export interface GoogleAccount {
  email: string
  name: string
}

export interface GcpProject {
  project_id: string
  display_name: string
  location: string
  dataset_count: number
  credential_handle: string | null
}

/** Which Google consent the wizard is asking for. */
/**
 * The connectors that run a Google consent, declared **once** so the type and the runtime check cannot
 * disagree.
 *
 * They did. The union was widened for Gmail and the two `oneOf(['bigquery', 'drive'])` schemas below
 * were not, so the server answered `provider: "gmail"`, the validator refused it, and the wizard showed
 * *"The Google sign-in could not be read — … provider should be one of bigquery | drive"* — a message
 * that blames a stale mock server, over a server that was right. A union is a compile-time claim and a
 * schema is a runtime one; only the second is checked against the payload, and only the first was
 * updated.
 */
export const OAUTH_PROVIDERS = ['bigquery', 'drive', 'gmail'] as const
export type OAuthProvider = (typeof OAUTH_PROVIDERS)[number]

/**
 * One account the sign-in window may offer.
 *
 * **The tenant's directory, served — never a list the window keeps.** These are `db.settings.users`,
 * this app's single answer to who exists, which is also the pool `/sources/oauth/mailboxes` refuses
 * an unknown address against: so the chooser can never offer a row the handshake would then turn
 * down. A copy held in the component is exactly how the consent screen once came to describe fewer
 * scopes than were being asked for.
 *
 * `initials` is the server's `emailInitials`, the same derivation the login session carries, so the
 * avatar here and the avatar in the sidebar cannot disagree about one person.
 */
export interface GoogleSignInAccount {
  email: string
  name: string
  initials: string
}

export interface OAuthStart {
  state: string
  provider: OAuthProvider
  auth_url: string
  scopes: string[]
  /** Who the chooser may sign in as. Rendered as returned, like `scopes`. */
  accounts: GoogleSignInAccount[]
}

/**
 * The consent, and only the consent. What the account can *see* is a second
 * call spent with `session` — the same shape a real handshake has, and what
 * gives the wizard a discovery stage backed by a real request.
 */
/**
 * A directory row a consent resolved — everything a session is except the moment it started.
 *
 * `Omit` rather than a second field list: these *are* the login's fields, resolved by the login's own
 * `identityFor`, and writing them out again is how one of them comes to be spelled differently on the
 * two paths a reader can arrive by.
 */
export type ConsentIdentity = Omit<SessionIdentity, 'signedInAt'>

export interface OAuthCallback {
  account: GoogleAccount
  session: string
  provider: OAuthProvider
  /**
   * **Who that account is in this tenant's directory** — the row `identityFor` resolved, which is the
   * same function `POST /auth/login` answers with.
   *
   * The sign-in window offers the directory, so a consent can be granted as somebody other than
   * whoever the browser signed in as, and this is what lets the console follow: the wizard adopts it
   * and every surface reading `useAuthStore` moves at once. Without it the wizard's own alert said
   * one person and the sidebar said another.
   *
   * **A `ConsentIdentity`, not a `SessionIdentity`: there is no `signedInAt`.** A consent is not a
   * sign-in, so the server has no such moment to report, and inventing one here would date a session
   * that had not begun. The store stamps it when it adopts the row, which is when the session really
   * does begin.
   *
   * `null` for an address the directory does not hold — a caller that names nobody, or one naming a
   * stranger. The consent still succeeds; the console simply does not change hands, which is the
   * honest answer when there is no row to change it to. **Nullable at every layer for that reason**,
   * and never defaulted to the current session: "nobody resolved" and "the person who was already
   * signed in" are different facts.
   */
  identity: ConsentIdentity | null
}

/* ---------------- Connect a Drive source ---------------- */

export interface DriveInfo {
  drive_id: string
  display_name: string
  kind: string
  folder_count: number
  document_count: number
  credential_handle: string | null
}

/** Drive's twin of `OAuthCallback` — its drives come from `/oauth/drives`. */
export type DriveOAuthCallback = OAuthCallback

/**
 * The mailbox a Gmail consent reaches, and the handle minted for it.
 *
 * One per consent rather than a list the tenant configured: a mailbox is whoever just signed in, so
 * unlike a drive there is no row in the document to point at.
 */
export interface MailboxInfo {
  mailbox: string
  /** What the tenant calls it — "EHS compliance inbox". */
  display_name: string
  description: string
  credential_handle: string
  label_count: number
}

/** What the Gmail preview discovers — labels only, and it registers nothing. */
export interface GmailPreview {
  mailbox: string
  display_name: string
  description: string
  /** Gmail's own system labels first, then this mailbox's own filing. */
  labels: string[]
  label_count: number
}

/** A registered Gmail source. No profiled counts: this connector carries no catalogue. */
export interface RegisteredGmailSource {
  source_id: string
  source_name: string
  connector: string
  mailbox: string
  credential_handle: string
  labels: string[]
  /** The optional Gmail search, exactly as typed, or null. */
  query: string | null
  status: string
  registered_at: string
  newly_connected: boolean
}


export interface PreviewFolder {
  folder_id: string
  /**
   * The folder this one sits inside, or `null` at the root of the drive.
   *
   * A drive is a tree and the allowlist is picked from it, but the folders stay one flat list —
   * every walk over them is unchanged, and the wizard builds the tree from these pointers.
   */
  parent_id: string | null
  name: string
  path: string
  description: string
  document_count: number
  page_count: number
  file_types: string[]
}

export interface DrivePreviewResult {
  drive_id: string
  display_name: string
  kind: string
  folder_count: number
  document_count: number
  folders: PreviewFolder[]
  registered: false
}

export interface RegisteredDriveSource {
  source_id: string
  source_name: string
  connector: string
  drive_id: string
  display_name: string
  folders: string[]
  status: string
  registered_at: string
  newly_connected: boolean
  folder_count: number
  document_count: number
}

export interface PreviewDataset {
  dataset_id: string
  location: string
  description: string
  table_count: number
  column_count: number
}

export interface PreviewResult {
  project_id: string
  dataset_count: number
  datasets: PreviewDataset[]
  registered: false
}

/**
 * What a *generic* registration answers with — a different shape from BigQuery's, and it always was.
 *
 * It has no \`project_id\`: a mailbox connects as an OAuth client, not into a GCP project. Validating it
 * against \`RegisteredSource\` demanded one anyway, so the server registered the source and the client
 * then threw \`project_id should be a string, got undefined\` — a failure toast over a source that had
 * been created. Never seen, because every connector on this path was \`available: false\` until the email
 * one; the same locked door that hid the form-wiring defect.
 */
export interface RegisteredGenericSource {
  source_id: string
  source_name: string
  connector: string
  type_label: string
  /** A \`secret://\` pointer, or null where the connector asks for no credential. */
  credential_handle: string | null
  /** What it connected *as* — a host, an account identifier. Null where a connector names nothing. */
  account: string | null
  /** What it has in scope, in the connector's own noun. Null where it narrows nothing. */
  scope: string | null
  datasets: string[]
  status: string
  registered_at: string
  newly_connected: boolean
}

export interface RegisteredSource {
  source_id: string
  source_name: string
  connector: string
  project_id: string
  credential_handle: string
  datasets: string[]
  status: string
  registered_at: string
  newly_connected: boolean
  dataset_count?: number
  table_count?: number
}

/* ---------------- Sources ---------------- */

export interface SourceRow {
  sourceId: string
  sourceName: string
  connector: string
  status: string
  projectAccount: string
  scope: string
  connectedAt: string
  /** 0 until the Metadata Profiler has run on this source. */
  profiledTables: number
  profiledColumns: number
  /**
   * Drive **and Gmail** sources; null for everything else, never 0.
   *
   * One field for one noun: a file in a folder and a file attached to a message are both
   * documents, and a `profiledMessages` beside this was two answers to one count.
   */
  profiledDocuments: number | null
  /** Entities extracted from those documents. Drive and Gmail sources. */
  profiledEntities: number | null
  /** Objects of this source profiled on `profiledTodayDate`, in whichever unit it holds. */
  profiledToday: number
  /** The server's own day, so the count above is checkable rather than assumed. */
  profiledTodayDate: string
  /**
   * A mailbox's chunk figures, and **null on every other connector** rather than 0 — a project does
   * not hold chunks, and 0 would say it holds none. Counted over what has been *processed*, never
   * over what the mailbox holds, which is what the note beside the tiles says.
   */
  documentsChunked: number | null
  chunksTotal: number | null
  chunkChars: number | null
  /**
   * The most recent chunk this source produced, gated to a rolling six-month window — `null`
   * on every non-chunking connector, and `null` here too once the true latest falls outside the
   * window: `chunksTotal` still counts a document chunked eight months ago, but it is not a
   * *recent* chunk, and this pair says so by being absent rather than by reporting stale history
   * under a tile labelled "recent".
   */
  lastChunkAt: string | null
  /** The chunk count of that one document — paired with `lastChunkAt`, so both are null together. */
  lastChunkCount: number | null
  /** The window's own start, on every source including ones with nothing to report, so the
      tile's claim ("nothing in the last 6 months") names a boundary the reader can check. */
  lastChunkSince: string
  datasets: string[]
  /** The folder allowlist. Drive sources only; empty for everything else. */
  folders: string[]
  /** The label allowlist. Gmail sources only; empty for everything else. */
  labels: string[]
  kind: string
  /**
   * Whether this source carries a catalogue at all.
   *
   * The server derives it from whether a profiler exists for the kind, so it is one answer rather than
   * a set of connector names the Catalog also has to know. True for a mailbox as well as a project and
   * a drive; false for the stubbed connectors, which have no pipeline behind them.
   *
   * It says nothing about the *graph*: mail is profiled for its catalogue and read at question
   * time, so what a mail profile holds never becomes a graph element. `runtime` on the step-4
   * payload is the flag for that, and the two are deliberately separate answers.
   */
  profilable: boolean
}

interface RawSourceRow {
  source_id: string
  source_name: string
  connector: string
  status: string
  project_account: string
  scope: string
  connected_at: string
  profiled_tables: number
  profiled_columns: number
  profiled_documents: number | null
  profiled_entities: number | null
  /** Objects of this source profiled on `profiled_today_date`, across whichever unit it holds. */
  profiled_today: number
  /** The server's own day, so the count above is checkable rather than assumed. */
  profiled_today_date: string
  documents_chunked: number | null
  chunks_total: number | null
  chunk_chars: number | null
  last_chunk_at: string | null
  last_chunk_count: number | null
  last_chunk_since: string
  datasets: string[]
  folders: string[]
  labels: string[]
  kind: string
  profilable: boolean
}

/* ---------------- Catalog: browse & profile ---------------- */

export interface BrowseTable {
  table_id: string
  /** What the semantic layer calls this view, e.g. `e-Manifest (shipments)`. */
  label: string
  type: string
  /** What one row is. A Gold view is only readable if its grain is stated. */
  grain: string
  columns: number
  /** `null` when the table is catalogued but has never been profiled — not zero, which would be a claim. */
  rows: number | null
  profiled: boolean
}

export interface BrowseDataset {
  dataset_id: string
  table_count: number
  tables: BrowseTable[]
}

export interface BrowseResult {
  source_id: string
  datasets: BrowseDataset[]
  dataset_count: number
  object_count: number
}

/* ---------------- Catalog: browse & profile documents ---------------- */

export interface BrowseDocument {
  document_id: string
  name: string
  mime_type: string
  doc_type: string
  /** What the document calls itself — `Consent Decree (modification)`. */
  doc_type_label: string
  /** The graph entity the file is about, from the extraction map. */
  linked_entity: string
  pages: number
  size_mb: number
  entities: number
  modified: string
  /** What a chunking run measured, or `null` where none has read this document. */
  chunks: number | null
  size_chars: number | null
  profiled: boolean
}

export interface BrowseFolder {
  folder_id: string
  name: string
  path: string
  document_count: number
  documents: BrowseDocument[]
}

export interface DocumentBrowseResult {
  source_id: string
  folders: BrowseFolder[]
  folder_count: number
  object_count: number
}

/**
 * One document attached to a message, in the browse tree.
 *
 * **`entities` is what profiling would extract, not what it has** — the same field a
 * `BrowseDocument` carries, and the document's `units` on a job row.
 */
export interface BrowseMailDocument {
  document_id: string
  name: string
  mime_type: string
  size_kb: number
  entities: number
  profiled: boolean
}

/**
 * One message in the browse tree — a **container**, not a profiled object.
 *
 * It is a level of the tree rather than a field on a leaf because a document in a mailbox is
 * not self-locating the way one in a folder is: who sent it and when is how a reader
 * recognises it. `documents` is empty for a message carrying nothing, and such a message is
 * still listed — an absent row would say the message does not exist rather than that it has
 * nothing to profile, and knowing which mail carries documents is most of what this is for.
 */
export interface BrowseMailMessage {
  message_id: string
  thread_id: string
  subject: string
  from: string
  from_name: string
  to: string
  to_name: string
  direction: 'sent' | 'received'
  /** Every label this message carries, its own first. */
  labels: string[]
  received: string
  size_kb: number
  document_count: number
  documents: BrowseMailDocument[]
}

/** A label and the mail filed under it — mail's twin of `BrowseFolder`, one level deeper. */
export interface BrowseMailLabel {
  label_id: string
  name: string
  message_count: number
  document_count: number
  messages: BrowseMailMessage[]
}

export interface MailDocumentBrowseResult {
  source_id: string
  labels: BrowseMailLabel[]
  label_count: number
  message_count: number
  /**
   * The profilable objects — documents, not the mail walked to find them.
   *
   * **An empty one is now a fact about the mail and nothing else.** It used to have a second
   * possible cause — a wizard toggle that put attachments out of scope — which is why
   * `attachments_in_scope` rode beside it: a decision with a remedy had to be distinguishable
   * from a mailbox that simply carries no files. That toggle is gone, attachments are always in
   * scope, and the ambiguity went with it.
   */
  object_count: number
}

/**
 * The connectors a profiling job can run for, and the object each one profiles — declared
 * **once** so the type and the runtime check cannot disagree.
 *
 * They already did once, for `OAUTH_PROVIDERS` above: the union was widened for Gmail and the
 * schema beside it was not, so a correct server answer was refused with a message blaming a
 * stale server. `kind` and `unit` are the same shape of claim — a union is checked by the
 * compiler, a `oneOf` is checked against the payload — and mail profiling adds a third member
 * to both, so they are derived from one array rather than written twice.
 *
 * **Three kinds, two units**, and that is not an oversight: BigQuery profiles tables, and both
 * Drive and Gmail profile *documents* — a file somebody filed in a folder and a file somebody
 * attached to a message are the same kind of object, so a job row reports the same noun for
 * either. What differs is where the profiler found it, which is the job's `kind`.
 */
export const PROFILE_KINDS = ['bigquery', 'gdrive', 'gmail'] as const
export type ProfileKind = (typeof PROFILE_KINDS)[number]

export const PROFILE_UNITS = ['table', 'document'] as const
export type ProfileUnit = (typeof PROFILE_UNITS)[number]

/**
 * One item of a job's work list. A BigQuery job profiles tables and a Drive or Gmail
 * job profiles documents, so the pair is named generically: `parent_id` is the dataset,
 * folder or label, `object_id` the table or document, `units` its columns or entities.
 * `unit` on the job says which noun to print.
 */
export interface JobObject {
  parent_id: string
  object_id: string
  label: string
  units: number | null
  state: 'pending' | 'profiled' | 'skipped'
}

export interface ProfilingJob {
  job_id: string
  short_id: string
  source_id: string
  kind: ProfileKind
  unit: ProfileUnit
  status: 'queued' | 'running' | 'complete' | 'cancelled' | 'failed'
  stage_index: number
  stage_total: number
  stage_label: string
  /**
   * Every stage this job's connector runs, in order — the server's `MAIL_PIPELINE`/`PIPELINE`/
   * `DOC_PIPELINE` as `pipelineFor` decides it. Carried so a surface narrating a run lists the
   * server's stages rather than a copy of its own, which would go stale silently.
   */
  stages: string[]
  /** Pre-formatted "3/5: Class inference". */
  pipeline: string
  progress: number
  objects: JobObject[]
  object_count: number
  objects_done: number
  force: boolean
  triggered_at: string
  started_at: string | null
  finished_at: string | null
  elapsed_seconds: number
  triggered_by: string
  error: string | null
}

export interface ProfilingJobsPayload {
  active: ProfilingJob[]
  recent: ProfilingJob[]
  active_count: number
  recent_count: number
  status_line: string
}

/*
 * The semantic class the profiler assigned, and it is **the dataset's vocabulary rather than a
 * closed set of ours**.
 *
 * This was a nine-member union, which was true of EPA and a claim about every dataset — the same
 * mistake as `rows: num` before CAPEX arrived with `rows: null`. CAPEX's generator emits sixteen
 * classes (`measure_record`, `period_accumulation`, `lifecycle_state` …), so the validator refused
 * the whole payload and **both dictionaries rendered nothing at all** behind "the data did not look
 * the way this app expects" — a page-level failure to protect a chip's wording.
 *
 * Widening is safe because nothing keys behaviour off the value any more. The tag is neutral by
 * construction (only `is-identifier` and `is-measure` carry a rule; anything else takes the base
 * style, which is what the class-chips-stay-neutral convention wants anyway), and the facet a column
 * answers to now arrives **on the column** as `facet`, computed server-side from `CLASS_FACET`.
 *
 * What replaced the runtime guard is a build-time one, which is the stronger trade: `check-docs`
 * asserts every class in **every** dataset is either in a facet or listed as deliberately unfaceted,
 * so a seventeenth class fails `npm run preflight` instead of a page.
 */
export type ColumnClass = string

export interface ProfiledColumn {
  column_id: string
  /** The profiler's own name for it (`TOTAL QUANTITY ACUTE KG`). */
  label: string
  /** Null where an uploaded dictionary named the column and not its type. */
  type: string | null
  class: ColumnClass
  /**
   * The class chip this column answers to, or `null` for a class with no chip.
   *
   * Server-side, from `CLASS_FACET`, because the panel used to hold its own copy of the fold and two
   * copies can disagree — a chip counting 69 and listing 41 reads as a broken filter.
   */
  facet: string | null
  /**
   * The classifier's confidence, shown beside the class chip — and **null for a declared column.**
   *
   * A column that arrived in an uploaded data dictionary was scored by nothing: a person wrote down
   * what it means. `0` would be a claim (the classifier was certain it was wrong) and a made-up
   * number would be worse, so the panel prints the derivation and no score.
   */
  confidence: number | null
  /**
   * How the classification was reached, or `null` where the profiler did not record it.
   *
   * **Nullable because it is the dataset's to state.** EPA's workbook records `llm` for all 237
   * columns; CAPEX's generator records nothing for any of its 224, and a schema saying `str` refused
   * the payload and blanked the whole dictionary. Third field in this family after `rows` and
   * `class` — a declared type is a claim about every dataset, not the one it was written against.
   *
   * Rendered only when present. There is no default, deliberately: `llm` would attribute a method to
   * a classification nobody described, which is the same lie as printing confidence 0.00 for a node
   * that was never scored.
   */
  derivation: string | null
  pii: boolean
  /** Both null for a declared column: a dictionary states meaning, and samples nothing. */
  null_pct: number | null
  distinct: number | null
  description: string | null
  /**
   * `needs review` means the profiler was below the High band (0.85) and no
   * curator has confirmed it — not that a description is missing. Every real
   * column has one.
   */
  description_status: 'needs review' | 'described'
}

export interface ProfiledTable {
  table_id: string
  label: string
  type: string
  grain: string
  /** `null` when nobody has counted — see the browse type above. */
  rows: number | null
  column_count: number
  columns: ProfiledColumn[]
}

export interface ProfiledDataset {
  dataset_id: string
  table_count: number
  column_count: number
  tables: ProfiledTable[]
}

export interface ColumnFacets {
  all: number
  needs_review: number
  pii: number
  ids: number
  measures: number
  dates: number
  /** `address` and `geo` together — both answer "where". */
  location: number
  flags: number
}

export interface ProfiledColumnsPayload {
  source_id: string
  profiled_tables: number
  dataset_count: number
  facets: ColumnFacets
  datasets: ProfiledDataset[]
}

/* ---------------- The document dictionary ---------------- */

export interface ProfiledEntity {
  entity_id: string
  type: string
  class: ColumnClass
  confidence: number
  pii: boolean
  /** How many times the extractor found it in this document. */
  occurrences: number
  /** Share of the document's chunks it appears in. */
  coverage_pct: number
}

/**
 * Where a document's extracted entity landed in the graph.
 *
 * Read from the extraction map, never derived — this is the join between the
 * unstructured side and the manifest stream, so `linked_manifests` is a real
 * count from that workbook and not a plausible number.
 */
export interface DocumentResolution {
  extraction_id: string
  extracted_entity: string
  /** `Generator (facility)`, `Transporter`, … */
  entity_type: string
  /** The graph node id, e.g. `FAC:LAD727050419`. */
  resolved_node: string
  resolved_facility: string
  state: string
  linked_manifests: number
  confidence: number
}

export interface ProfiledDocument {
  document_id: string
  name: string
  mime_type: string
  doc_type: string
  doc_type_label: string
  linked_entity: string
  /** Null when nothing resolved — the panel says so rather than showing nothing. */
  resolution: DocumentResolution | null
  pages: number
  size_mb: number
  modified: string
  /**
   * What a chunking run measured, or `null` where none has read this document.
   *
   * Nullable rather than 0 for the reason the mail corpus's are: 0 says a document produced no
   * chunks and no text, where the truth is that nothing counted. `chunks` was a served number for
   * every document while it was `pages * 2.5`; it reports a measurement now, so it reports nothing
   * where there is none.
   */
  chunks: number | null
  size_chars: number | null
  /** The opening lines the chunker extracted. Never composed here — an unread document has none. */
  snippet: string | null
  entity_count: number
  pii_count: number
  /** Curator-written; the unit under review for an unstructured file. */
  summary: string | null
  summary_status: 'needs review' | 'described'
  entities: ProfiledEntity[]
}

export interface ProfiledFolder {
  folder_id: string
  name: string
  path: string
  document_count: number
  entity_count: number
  documents: ProfiledDocument[]
}

/** Counts documents, not entities — a file is what a curator reviews. */
export interface DocumentFacets {
  all: number
  needs_review: number
  pii: number
}

/**
 * One document-kind chip: the `doc_type` slug it filters by, its label, and its count.
 *
 * **Served, because the kinds are the corpus's and not this app's.** These were four fixed keys on
 * `DocumentFacets` and a matching `TYPE_FOR_FACET` table in the panel — EPA's enforcement papers,
 * which left all four chips reading 0 against CAPEX's 36 scope documents and contracts. The `key` is
 * the slug the document carries, so the panel filters on it directly and there is no second map to
 * fall out of step.
 */
export interface DocumentTypeFacet {
  key: string
  label: string
  count: number
}

export interface ProfiledDocumentsPayload {
  source_id: string
  profiled_documents: number
  folder_count: number
  entity_count: number
  facets: DocumentFacets
  type_facets: DocumentTypeFacet[]
  folders: ProfiledFolder[]
}

/**
 * What the mail profiler extracted from one attached document.
 *
 * **It carries no `resolution`, and `observation` is why.** A drive document's resolution is the
 * graph node its entity resolved to — the join that makes profiling a filing worth doing. Mail is
 * a runtime source: an extraction from something that arrived in an inbox is a *claim about a
 * subject the graph already holds*, resolved when a question needs it and never merged into the
 * fact set. A resolved node here would be that merge, arriving quietly through the catalogue.
 *
 * It also carries **the message it arrived on**, because a document in a mailbox is not
 * self-locating the way one in a folder is: `signed-agreement.pdf` alone is ambiguous across a
 * corpus that reuses stems, and who sent it is how a reader recognises it.
 */
export interface ProfiledMailDocument {
  document_id: string
  name: string
  mime_type: string
  size_kb: number
  label: string
  /*
   * **Null where a dataset ships its mail.** `mail_corpus` states the documents and says nothing
   * about the messages they arrived on; inventing those would synthesise what shipping replaced.
   */
  message_id: string | null
  subject: string | null
  from: string | null
  from_name: string | null
  to: string | null
  to_name: string | null
  direction: 'sent' | 'received' | null
  received: string | null
  /**
   * What the Catalog's table states per row, and **null for a synthesised document** — nothing
   * counted the pages of a document nothing wrote, so the cell is an em dash rather than a figure.
   */
  pages: number | null
  size_chars: number | null
  snippet: string | null
  /** The corpus's own where it states one, else chunked off the size. */
  chunks: number
  entity_count: number
  pii_count: number
  /** Always true, and stated rather than inferred from the absent resolution. */
  observation: boolean
  summary: string | null
  summary_status: 'needs review' | 'described'
  entities: ProfiledEntity[]
}

export interface ProfiledMailLabel {
  label_id: string
  name: string
  document_count: number
  entity_count: number
  documents: ProfiledMailDocument[]
}

/** One label chip. Mail's grouping is Gmail's own labels, so the key *is* the label. */
export interface MailLabelFacet {
  key: string
  label: string
  count: number
}

export interface ProfiledMailDocumentsPayload {
  source_id: string
  mailbox: string | null
  profiled_documents: number
  /** Everything attached under the connected labels, so "5 of 19" is expressible. */
  document_total: number
  label_count: number
  entity_count: number
  facets: DocumentFacets
  label_facets: MailLabelFacet[]
  labels: ProfiledMailLabel[]
}

export interface ChangeSignal {
  signal_id: string
  kind: string
  severity: string
  dataset: string
  table: string
  detail: string
  action: string
  detected: string
}

/* ---------------- New Graph wizard ---------------- */

/** How well a domain is backed by data that is actually connected. */
export type DomainFit = 'strong' | 'partial' | 'none'

export interface GraphDomain {
  domainId: string
  name: string
  expectedSources: string[]
  fit: DomainFit
  /** Why it ranks where it does — shown under the domain name. */
  note: string
  rank: number
  /**
   * What steps 2, 3 and 5 could draft for this domain, counted off the tenant's own pools.
   *
   * A different fact from `fit`, which is about the *connected data*: a domain can be a strong fit
   * for what has been profiled and still have no persona, metric or hero question written against
   * it — which is three consecutive steps that draft nothing, and it is why this is on the card
   * where the domain is chosen rather than discovered two steps later.
   */
  drafts: { personas: number; metrics: number; heroQuestions: number }
}

export interface GraphDomainsPayload {
  domains: GraphDomain[]
  domainCount: number
  connectedSources: number
  profiledObjects: number
}

/**
 * A name plus a description, and where it came from. Personas (step 2) and metrics
 * (step 3) are the same shape, so they share one contract end to end.
 *
 * A persona is lightweight — it shapes questions and tone, never access control.
 */
export interface DraftedItem {
  name: string
  description: string
  source: 'ai' | 'user'
  /** What it was drafted *from*, where that is narrower than who drafted it — `'document'` only,
   *  set by the document pass and by nothing else. `source` is two-valued and cannot tell a measure
   *  read out of an attachment from one the suggester ranked out of the pool, so a row without this
   *  is never claimed to have come from a document. */
  origin?: 'document' | null
  /** The query this metric is answered by, or `null`. **Metrics only** — a persona is somebody to
   *  answer for, not something a warehouse can be asked. Carried through the wizard as well as the
   *  Playground, or a wizard save would drop what was written on the other screen. */
  sql?: string | null
}

export type Persona = DraftedItem
export type Metric = DraftedItem

/**
 * A hero question — the graph's contract. `priority` is two-valued on purpose:
 * High means "this one matters"; a third tier would invite ranking over choosing.
 */
/**
 * How answers of one question type render — one option a reader may ask for on Ask's
 * Answer requirements tab.
 *
 * **No longer part of a use-case brief.** It was step 6 of the wizard, stored
 * self-describing so a saved brief kept promising what it promised; the choice is made
 * per question now, so it is served with the graph list and never written to a draft.
 */
export interface AnswerFormat {
  formatId: string
  /** The question type — "Cost drivers", "Compliance". */
  name: string
  /** The render recipe — "narrative + drivers table + trend". */
  format: string
}

export type Citations = 'required' | 'optional'

/** A decision the user owes on a gap before the graph can be built. */
export type GapDecision =
  | 'accept permanent'
  | 'drop question'
  | 'connect source'
  | 'defer with trigger'

export interface GapChoice {
  elementId: string
  decision: GapDecision
}

/**
 * One derived element of the step 6 review. A `backed` element names the profiled object it
 * came from in `evidence`; a `gap` explains what is missing and needs a decision.
 *
 * **`runtime` is neither, and it is a third status rather than a shade of one of them.** A
 * hero question no profiled column covers, on a brief that picked a source read at question
 * time, is not backed — nothing in the graph carries it — and it is not a gap, because
 * something will answer it. It carries no decision, since there is nothing for a reviewer to
 * settle, and it is counted apart from `gapCount` so the build gate reads exactly as it did.
 */
export interface CoverageElement {
  elementId: string
  name: string
  kind: 'entity' | 'relationship'
  status: 'backed' | 'gap' | 'runtime'
  confidence: number
  evidence: string | null
  reason: string | null
}

/** A picked source that contributes at question time instead of deriving elements. */
export interface CoverageRuntimeSource {
  sourceId: string
  sourceName: string
  typeLabel: string
  /** How much of it is in scope — Gmail's labels, counted. */
  scope: number
  scopeLabel: string
}

export interface CoveragePayload {
  title: string
  entityCount: number
  relationshipCount: number
  heroQuestionCount: number
  gapCount: number
  /** Questions routed to a runtime source. Never folded into `gapCount`. */
  runtimeQuestionCount: number
  objectCount: number
  elements: CoverageElement[]
  /**
   * The runtime sources this brief picked, and the served sentence about what they do.
   *
   * Carried rather than dropped, which it was: the server has sent both since runtime
   * sources existed and the client mapped neither, so the step could not say why a source
   * the reader deliberately picked had contributed nothing — and a list that is merely
   * empty is not a message.
   */
  runtimeSources: CoverageRuntimeSource[]
  runtimeNote: string | null
}

export interface HeroQuestion {
  text: string
  priority: "high" | "normal"
  source: "ai" | "user"
  /** The query this question would be answered by, or `null` where nothing has been composed.
   *  Carried on the brief rather than re-derived on load: a reader can edit it, so it is their
   *  text once they have. */
  sql?: string | null
}

export interface GraphUseCase {
  useCaseId: string
  name: string
  status: 'draft' | 'committed'
  domainId: string | null
  businessNeed: string
  personas: Persona[]
  metrics: Metric[]
  sources: SourcePick[]
  heroQuestions: HeroQuestion[]
  gapDecisions: GapChoice[]
  step: number
  stepTotal: number
  updatedAt: string | null
  /** The role this graph stands in for (New Role's first two steps). Null on a brief saved without one. */
  role: RoleDetails | null
}

/** What New Role's first two steps collect: who the analyst is, where, and what they are responsible for. */
export interface RoleDetails {
  role_id: string
  role_name: string
  industry: string
  utilities: string[]
  reports_to: string
  responsibilities: string[]
  /** Tasks kept per responsibility, keyed by responsibility id. */
  tasks?: Record<string, string[]>
  /** Responsibilities taken out of scope, with the reason. */
  out?: Record<string, string>
  job_description?: string | null
}

/* ---------------- Graph Studio ---------------- */

/** What a review row may be answered with. A causal claim has its own set. */
export type ReviewChoice =
  | 'approve'
  | 'correct'
  | 'reject'
  | 'approve-causal'
  | 'downgrade-correlational'

export interface ReviewDecision {
  choice: ReviewChoice
  justification: string | null
  decidedAt: string
}

/**
 * One row of a graph's review queue. `floor` is why a human must see it at all
 * — a schema change, a causal claim, a new entity type.
 */
export interface ReviewItem {
  itemId: string
  /** `measure` is the third: a cross-basis measure is neither entity nor edge. */
  kind: 'relationship' | 'entity' | 'measure'
  title: string
  detail: string
  confidence: number
  /** The triage lane the row arrived in, which is the package's, not derived here. */
  band: 'High' | 'Medium' | 'Low' | null
  floor: string | null
  /** 'standard' or 'causal' — the fallback family when a row states no buttons. */
  actionSet: string
  /**
   * The row's own buttons. `label` is what it says in the row's terms ("Keep
   * distinct"); `choice` is what gets recorded, and stays one of the fixed set so a
   * decision means the same thing to the canvas on every row.
   */
  actions: { choice: ReviewChoice; label: string }[]
  /** What the deriver had to go on, as the package stated it. */
  evidence: string[]
  /** Canvas node ids the row is *about* — not necessarily what it makes proposed. */
  graphRefs: string[]
  /** True when the row cannot be resolved without a recorded reason. */
  justification: boolean
  decision: ReviewDecision | null
}

/** A built graph, as the studio's list shows it. */
export interface StudioGraph {
  useCaseId: string
  name: string
  domainId: string | null
  businessNeed: string
  /** The *working draft* — what Publish would make live. */
  version: string
  /** What was last made live, or null. Never the same as `version`. */
  liveVersion: string | null
  state: 'draft' | 'published'
  /** Rows still needing a human, plus the pivot if it is open. */
  queueCount: number
  mustReviewOutstanding: number
  mustReviewCount: number
  publishedCount: number
  builtAt: string | null
}

export interface StudioGraphsPayload {
  graphs: StudioGraph[]
  count: number
  /** Use cases still in the wizard — not listed, nothing to review yet. */
  draftCount: number
}

/* ---------------- Ask ---------------- */

/**
 * A graph Ask can query — one that is live.
 *
 * `version` is the *published* one, the only version that serves. A built graph
 * nobody published is not here at all; Ask has nothing to run against.
 */
export interface AskGraph {
  useCaseId: string
  name: string
  domainId: string | null
  version: string
  publishedAt: string | null
  publishedBy: string | null
  /* No graph-level `citations`: the reader chooses per question on the Answer
     requirements tab, so it rides on the answer instead. */
  /** Standing limits — the coverage step's gap decisions, read back. */
  caveats: string[]
  /** The hero questions this graph was built for; the chips under the box. */
  suggestedQuestions: string[]
  entityCount: number
  relationshipCount: number
}

/**
 * What a reader may require of an answer — the Answer requirements tab's pool.
 *
 * Served rather than written into the component, for the reason the consent screen
 * renders the scopes the endpoint returned: a client holding its own list can offer a
 * value `POST /ask` refuses.
 */
export interface AnswerRequirementOptions {
  citationsOptions: { value: Citations; label: string }[]
  defaultCitations: Citations
  formats: AnswerFormat[]
  /** Which half really applies, in the server's words. */
  note: string
}

/**
 * A connected source a reader may ask **directly**, with no graph in the picture.
 *
 * These are the runtime sources — read at question time, deriving nothing onto a canvas —
 * and the server is what says which those are. The page renders what it was served rather
 * than testing for a connector name, the rule step 4 of the New Graph wizard already keeps.
 */
export interface AskSource {
  sourceId: string
  name: string
  kind: string
  connector: string
  /** What it connected as — an address, for a mailbox. Null where a connector has no such notion. */
  account: string | null
  scope: string
  /**
   * What this source is on record as answering.
   *
   * The graph's chips are its brief's hero questions; a connected source has no brief, so these
   * are the recorded answers really drawn from it — the same promise by the same standard.
   * Declines are excluded server-side: asking one returns the recorded refusal, but offering it
   * would put a question in front of a reader this dataset cannot answer.
   */
  suggestedQuestions: string[]
}

export interface AskGraphsPayload {
  graphs: AskGraph[]
  count: number
  /** The connected sources that can be asked directly. Empty when none is connected. */
  sources: AskSource[]
  sourceCount: number
  /** Built but never published — the fix is Publish, not New Graph. */
  builtCount: number
  draftCount: number
  answerRequirements: AnswerRequirementOptions
}

/** One line of the supervisor's working, shown so an answer can be audited. */
export interface AskStep {
  step: string
  detail: string
}

export interface AskCitation {
  label: string
  detail: string
  /**
   * Null for a recorded answer's evidence rows. The query set states one
   * confidence for the whole answer, so a number per source view would be
   * invented — and the page shows the figure only where there is one.
   */
  confidence: number | null
  /**
   * The rest of the numbered source list, where the answer *authored* one.
   *
   * Every field below is `null` for a citation the server derived from an answer's
   * `evidence` rows, and that is the distinction the page has to keep: an evidence line
   * says nothing about whether its source was read at question time, so `runtime: false`
   * would be a claim rather than a default. Render each mark only where its value is not
   * null.
   */
  /** "dataset" · "document" · "correspondence" · "graph" · "absence". */
  kind: string | null
  sourceId: string | null
  /**
   * Read at question time rather than on a schedule. A runtime source has **no as-of** —
   * the query set's own rule is that two people asking an hour apart can legitimately get
   * different answers and neither is stale — so `asOf` is null on these by design.
   */
  runtime: boolean | null
  asOf: string | null
  /** Whether this source is authoritative *for this claim*, not in general. */
  authoritative: boolean | null
  /** Why it is not, in the set's own words. Null unless it says. */
  whyNotAuthoritative: string | null
  /** Its place in the numbered list the answer wrote. */
  n: number | null
}

/* ---------------- Ask: the blocks a recorded answer is made of ---------------- */

/**
 * One piece of an answer.
 *
 * A recorded answer is an ordered list of these, exactly as the tenant wrote it:
 * prose, a row of figures, a chart, a table. The discriminant is `type`, and an
 * unknown one is refused at the boundary rather than rendered as a blank — a
 * missing block in the middle of an answer reads as a gap in the reasoning.
 */
export type AnswerBlock =
  | { type: 'text'; markdown: string }
  | { type: 'metric'; items: AnswerMetric[] }
  | {
      type: 'chart'
      /** `column` is vertical bars, for a short label over a left-to-right series. */
      chart: 'bar' | 'line' | 'column' | 'grouped' | 'pie' | 'donut'
      title: string
      x_label?: string | null
      y_label?: string | null
      note?: string | null
      /** A wider viewBox where the surface is wider — a report card, not an answer column. */
      width?: number | null
      /** Two measures over the same rows: a grouped chart names them, one hue each. */
      series?: { key: string; label: string }[] | null
      /** A point may carry a state: the register's bars are coloured by compliance risk. */
      data: {
        label: string
        value: number
        tone?: 'good' | 'warn' | 'crit' | null
        /** One value per series on a grouped chart, keyed by measure. */
        values?: Record<string, number> | null
      }[]
    }
  | { type: 'table'; title: string; columns: string[]; rows: AnswerCell[][] }
  /**
   * **What correspondence claimed — never a figure the answer counted.**
   *
   * A runtime source is read when a question needs it, and what it yields is an
   * *observation*: a claim about a subject the graph already holds, attributed to whoever
   * made it, with the extractor's confidence attached. The query set is explicit that none
   * of it is merged into the fact set, and its own block notes say so per answer — *"Each
   * is a CLAIM by its sender with the extractor's confidence attached — none of it is
   * counted into any figure above."*
   *
   * So this block renders as attributed claims and never as a metric or a chart: the moment
   * a reader can read a total off it, it has stopped being an observation. Every field but
   * the four that identify the claim is nullable, because the corpus genuinely does not
   * carry them all — 22 of 27 rows name no month count and 13 name no change order.
   */
  | {
      type: 'observation'
      /** The tenant's own heading — "From correspondence", "Did not resolve", and others. */
      label: string
      items: AnswerObservation[]
      /** What the block is and what it is not, in the tenant's words. */
      note?: string | null
    }

/**
 * One claim read out of a message at question time.
 *
 * **snake_case, like the chart block's `x_label` beside it.** Blocks are passed through
 * from the payload unmapped — `toAskAnswer` maps the envelope's fields and hands `blocks`
 * straight on — so renaming these would need a block mapper whose only job is this one
 * type. The camelCase rule applies to the fields the envelope carries, not inside a block.
 */
export interface AnswerObservation {
  message_id: string
  from_name: string
  /** "contractor", "owner" — which side of the contract made the claim. */
  from_side?: string | null
  sent_at: string
  subject?: string | null
  claim: string
  /** The reason the extractor filed it under, where it resolved one. */
  reason_label?: string | null
  /** Money the claim asserts. Null where it asserts none — never 0, which is an amount. */
  amount?: number | null
  amount_basis?: string | null
  /** Schedule months the claim asserts, where it names any. */
  months?: number | null
  confidence?: number | null
  /** The extractor's own band for that confidence — "High", "Medium", "Low". */
  band?: string | null
  /** The graph subject this claim was resolved against, or null where nothing resolved. */
  resolved_to?: string | null
  change_order?: string | null
}

/** A table cell or a metric value: the tenant writes counts as numbers. */
export type AnswerCell = string | number

export interface AnswerMetric {
  label: string
  /** A figure or a short string — the tenant's own value, rendered as given. */
  value: number | string
  unit?: string | null
  /** `risk` and `good` are the only two, and they carry an icon, never colour alone. */
  flag?: 'good' | 'risk' | null
}

/**
 * What was required of this answer, and whether it was met — **computed by the server,
 * never asserted**. Citations really apply: required plus nothing cited is a fact, and
 * `satisfied` is false. A format is stated, not applied — a recorded answer holds the
 * blocks the tenant wrote, and claiming they were rendered to order would be a claim
 * the page underneath disproves.
 */
export interface AnswerRequirements {
  citations: Citations
  formats: AnswerFormat[]
  satisfied: boolean
  note: string
}

export interface AskAnswer {
  question: string
  /** Null when a connected source answered — there was no graph, so there is no version. */
  useCaseId: string | null
  graphName: string | null
  version: string | null
  /** The sources read at question time, where they were what answered. Empty otherwise. */
  sourceIds: string[]
  /** False is a real outcome: the graph abstained, and `reason` says why. */
  answered: boolean
  reason: string
  answer: string | null
  /** Null whenever it abstained — there is no number to report. */
  confidence: number | null
  entities: string[]
  path: string[]
  hops: number
  reasoning: AskStep[]
  citations: AskCitation[]
  caveats: string[]
  askedAt: string
  /** The one-line headline of a recorded answer; null when the graph walk answered. */
  summary: string | null
  /** Empty when the walk answered — it produces prose, not blocks. */
  blocks: AnswerBlock[]
  /** Which recorded answer this was, or null. Provenance, not decoration. */
  answerId: string | null
  /** What the reader asked this answer to carry, and whether it did. */
  requirements: AnswerRequirements
}

export interface PivotOption {
  optionId: string
  label: string
  consequence: string
}

export interface StudioPivot {
  pivotId: string
  alternativeId: string
  title: string
  detail: string
  /** Why it is a pivot and not a queue row — the server's sentence, not the page's. */
  whyPivot: string
  confidence: number
  band: 'High' | 'Medium' | 'Low' | null
  floor: string
  evidence: string[]
  graphRefs: string[]
  options: PivotOption[]
  open: boolean
  chosen: string | null
}

/**
 * One version of a graph — that is, one build of it.
 *
 * Immutable and content-addressed: `sha256` is the identity, and two builds of one
 * config differ there and nowhere else. Publishing flips `published` on exactly one
 * row; it never rewrites a row.
 */
export interface GraphVersion {
  /** The content hash. The identity, and what publish/unpublish name. */
  sha256: string
  graphId: string
  /**
   * This version's label — v1, v2, v3, one per build.
   *
   * Named `configVersion` for the payload field it maps, which is older than the change: it
   * used to name the *brief's* config and was shared by every build of it. A build takes the
   * next number now, assigned once when the run starts, so a published label is never
   * recomputed by a later rebuild.
   */
  configVersion: string
  entities: number
  relationships: number
  /** The build that produced it, so a version can be traced to its run. */
  fromJob: string
  createdAt: string
  /**
   * Whether the publish gate was clear when this build finished. `unknown` is not
   * a failure — nobody had settled the queue and pivot yet, so nothing checked it.
   */
  gate: 'passed' | 'unknown'
  /** At most one row is true. Ask queries that one and no other. */
  published: boolean
}

/* ---------------- Canvas ---------------- */

/**
 * How a package accounts for the way an element was built — **its own vocabulary, not a fixed one.**
 *
 * EPA states four origin classes: a source row becomes an entity or event node, an uploaded document
 * becomes a document node, a raw name resolves through an alias, and `schema` is the pair of element
 * classes that are not instances. CAPEX states its node's *type* here instead. Both are the graph's
 * account of itself, and neither is wrong — so this is a string, and the union that used to be here
 * refused every one of CAPEX's 442 nodes with a message about a stale server.
 *
 * **Nothing reads it to decide an appearance.** It was the legend's fill until the viewer was vendored
 * in; that draws by ontology `type` now, which is why widening this costs nothing. `dimension` was a
 * fifth EPA value until the graph was rebuilt — column values are no longer promoted to nodes, a waste
 * code being an attribute of a shipment — and it is gone rather than empty, because a legend row for it
 * would advertise a claim the graph denies.
 */
export type CanvasGroup = string

export interface CanvasNode {
  nodeId: string
  label: string
  sublabel: string
  /** The ontology's own type — Facility, Manifest, Evaluation, Enforcement, … */
  type: string
  /**
   * The build model's element class. A `thin_instance` carries identity and
   * provenance only — its values federate at query time and are not in the graph —
   * while a `concept` is type-level and a `measure_element` is a quantity promoted
   * so relationships can point at it.
   */
  elementClass: 'thin_instance' | 'concept' | 'measure_element'
  /**
   * The Catalog object it was built from, e.g. `epa_hazwaste.e_manifest`.
   *
   * `null` where the package states none — CAPEX states none for 11 of its 442 nodes. The inspector
   * prints provenance only when there is some, so an absence stays an absence rather than becoming the
   * string "null" under a heading that claims to say where a figure came from.
   */
  source: string | null
  /** Relationships carried. The node's radius is this, not a decorative size. */
  degree: number
  /** Radius in canvas units, from the server so a reload draws one picture. */
  r: number
  group: CanvasGroup
  /** Null where the package scored no node — CAPEX scores none of its 442. Never defaulted to 0. */
  confidence: number | null
  /** True while the review item behind it is undecided. */
  proposed: boolean
  origin: 'derived' | 'studio-authored'
  rejected: boolean
  needsReview: boolean
  reviewItemId: string | null
  onAnswerPath: boolean
  x: number
  y: number
}

export interface CanvasEdge {
  /** The graph's own id, which is how a recorded sanity check names its hops. */
  edgeId: string
  from: string
  to: string
  label: string
  /** The relationship's evidence, verbatim: `manifests=46; total_tons=1061.8; …`. */
  detail: string
  proposed: boolean
  reviewItemId: string | null
  onAnswerPath: boolean
}

export interface CanvasFacets {
  all: number
  lowConfidence: number
  needsReview: number
  studioAuthored: number
  /** One per origin class, so the legend can carry counts and filter by them. */
  groups: { key: CanvasGroup; count: number }[]
  /** One per ontology type — what the ring encodes. Rendered in the legend's order. */
  types: { key: string; count: number }[]
}

export interface CanvasPayload {
  nodes: CanvasNode[]
  edges: CanvasEdge[]
  nodeCount: number
  edgeCount: number
  facets: CanvasFacets
}

/** One relationship an answer travelled, as a sentence's worth of parts. */
export interface QueryHop {
  edgeId: string
  from: string
  to: string
  label: string
  fromLabel: string
  toLabel: string
  /** True where the hop's review row is still open — the answer is provisional. */
  proposed: boolean
}

/** A chip of context a recorded check states alongside its verdict. */
export interface QueryContext {
  /** What kind of thing it is — `document`, `traversal`, `measure`, `pending`, … */
  chip: string
  label: string
  meta: string
  /** False where the chip is a caveat rather than a confirmation. */
  ok: boolean
}

/**
 * What the draft graph could — or could not — answer.
 *
 * `recorded` says which route answered. A recorded check is one of the demo
 * package's five, and it brings the verdict, the Cypher the engine would plan, and
 * its cost against the budget; a derived walk brings `pathLabels`, the chain its
 * breadth-first search actually followed. The recorded fields are `null` on a walk,
 * and `pathLabels` is empty on a recorded check — its traversal is a sub-graph, not
 * a chain, so its hops are in `edgesUsed` and joining them with arrows would claim
 * a route nobody walked.
 */
export interface QueryAnswer {
  question: string
  answerable: boolean
  reason: string
  matched: string[]
  path: string[]
  pathLabels: string[]
  edgesUsed: QueryHop[]
  hops: number
  /** An answer leaning on an undecided edge is answerable *and* provisional. */
  caveats: string[]
  recorded: boolean
  checkId: string | null
  /** The hero question this check is a check *on*. */
  heroQuestionId: string | null
  /** How it matched — "the same question", or the words it shared. */
  matchedHow: string | null
  verdict: string | null
  verdictBody: string | null
  context: QueryContext[]
  plan: string | null
  costUsd: number | null
  budgetUsd: number | null
  canvas: CanvasPayload
}

export interface GraphStudioPayload extends StudioGraph {
  graphName: string
  status: string
  decisionMemory: string
  mustReview: ReviewItem[]
  /** Named a sample because it is one — these buckets are spot-checked. */
  confirmedSample: ReviewItem[]
  confirmedCount: number
  autoApprovedSample: ReviewItem[]
  autoApprovedCount: number
  pivot: StudioPivot
  pivotCount: number
  /** The recorded checks, as the Query tab's chips. A chip is a promise already made. */
  sanityChecks: { checkId: string; heroQuestionId: string; question: string }[]
  batchResolved: number
  batchTotal: number
  publish: { blocked: boolean; reasons: string[]; explanation: string }
  /** Every build that produced a version, newest first. */
  versions: GraphVersion[]
}

/** One object a graph could draw from — a table, a document, or a Gmail label. */
export interface GraphSourceObject {
  objectId: string
  parentId: string
  label: string
  /**
   * How much the object holds, in `unitLabel`, or `null` where nothing has counted it.
   *
   * Nullable because a runtime source is not sampled: Gmail's labels have no message
   * count, and `0` would say a label is empty rather than uncounted. Do not default it
   * to zero on the way out — that is the `rows ?? 0` mistake CLAUDE.md records, where the
   * compiler is satisfied by a value that lies.
   */
  units: number | null
  /** "columns", "entities", or "chunks". */
  unitLabel: string
  /**
   * What a mail document's row states beside its name.
   *
   * **Null on every other connector, and null for a synthesised mail document too** — nothing
   * counted the pages of a document nothing wrote, so the row prints neither rather than a figure
   * that looks as reasonable as a measured one.
   */
  pages: number | null
  sizeChars: number | null
  snippet: string | null
}

export interface GraphSource {
  sourceId: string
  sourceName: string
  connector: string
  kind: string
  status: string
  typeLabel: string
  account: string
  /** "Datasets", "Folders" or "Labels". */
  scopeLabel: string
  scope: string[]
  objects: GraphSourceObject[]
  objectCount: number
  /** "tables", "documents" or "labels". */
  unitLabel: string
  /**
   * Read at question time rather than profiled into the graph.
   *
   * Served rather than derived from `kind` in the component, so the step-4 gate and the
   * copy beside it cannot disagree about which sources are runtime — the same reason
   * `profilable` is served rather than tested against a pair of connector names.
   */
  runtime: boolean
}

export interface GraphSourcesPayload {
  sources: GraphSource[]
  sourceCount: number
  /** Connected *and* carrying something profiled — connected alone can't feed a graph. */
  profiledSourceCount: number
  /** Connected runtime sources, which contribute at question time instead. */
  runtimeSourceCount: number
}

/**
 * A step 4 pick. `mode: 'all'` keeps meaning "everything profiled here", so a
 * table profiled later is included without reopening the wizard.
 */
export interface SourcePick {
  sourceId: string
  mode: 'all' | 'subset'
  objects: string[]
}

export interface Suggestion {
  id: string
  name: string
  /** A persona's focus, a metric's definition — what the row shows beneath it. */
  detail: string
  /**
   * Hero questions only, and only where a use case stated one. It pre-ticks the
   * High box; the user still decides, because accepting is theirs.
   */
  priority?: 'high' | 'normal'
  /** Why it was drafted — shown so a suggestion is never unexplained. */
  why: string
}

/** What a model call cost and what it was doing — shown while it runs. */
export interface LlmRun {
  stages: string[]
  costUsd: number
  costCapUsd: number
}

export interface Suggestions {
  suggestions: Suggestion[]
  count: number
  derivedFrom: string
  /**
   * Why nothing was drafted, when nothing was — `null` otherwise.
   *
   * An empty list is an answer and this says which one. The step printed *"Nothing matched this
   * brief"* for every empty draft, which blames the reader's words for what is often a gap in the
   * tenant's pools: CAPEX declares four domains and has personas, metrics and hero questions for
   * two, so picking one of the other two drafted nothing three steps running. The two cases have
   * different fixes and the server is the only side that can tell them apart.
   */
  emptyReason: string | null
  run: LlmRun
}

/**
 * The derivation between step 6 and step 7. Async on purpose: it returns an id
 * immediately and the answer arrives by polling, so leaving the page does not
 * lose the run.
 */
export interface DerivationRun {
  derivationId: string
  status: 'running' | 'complete'
  stageIndex: number
  stageTotal: number
  stageLabel: string
  progress: number
  /** Entity names revealed so far — what the user watches stream in. */
  revealed: string[]
  entityTotal: number
  costUsd: number
  costCapUsd: number
  coverage: CoveragePayload | null
}

/** One substep inside a stage — the inner work, named the same way. */
export interface BuildStep {
  key: string
  state: 'pending' | 'running' | 'complete'
}

/** One stage of the build pipeline, and where it has got to. */
export interface BuildStage {
  /** The platform's own name, so a row matches a log line. */
  key: string
  state: 'pending' | 'running' | 'complete'
  /**
   * What the stage is actually doing. Never empty: a stage with no substeps would
   * be a row that claims work nobody can see, which is what this replaced.
   */
  steps: BuildStep[]
}

/**
 * One build of a graph. Every stage is present from the first response, so the
 * panel shows the whole pipeline and fills it in rather than growing a row.
 */
export interface GraphBuild {
  buildId: string
  useCaseId: string
  status: 'running' | 'complete'
  stageIndex: number
  stageTotal: number
  /** Progress in substeps — what actually advances, and what the header counts. */
  stepIndex: number
  stepTotal: number
  /** How long one substep takes, per the server. The page's ETA derives from it. */
  stepMs: number
  stages: BuildStage[]
  packageId: string
  graphVersion: string
  /** This run's own version — what Publish would make live. One per build. */
  configVersion: string
  startedAt: string
  finishedAt: string | null
}

export interface UseCasesPayload {
  useCases: GraphUseCase[]
  count: number
  draftCount: number
  committedCount: number
  /** Step labels come from the server, so the stepper cannot outgrow it. */
  steps: string[]
}

/* ---------------- Audit & Governance ---------------- */

export interface AuditEvent {
  actor: string
  action: string
  resource: string
  severity: string
  tone: Tone
  at: string
}

export interface Policy {
  name: string
  desc: string
  status: string
  tone: Tone
}

export interface AuditPayload {
  stats: Stat[]
  events: AuditEvent[]
  policies: Policy[]
  event_window: string
  policy_total: number
  connected_sources: number
}

/* ---------------- Trace & Observability ---------------- */

export interface Trace {
  id: string
  operation: string
  service: string
  duration: number
  spans: number
  status: string
  tone: Tone
  at: string
}

export interface Span {
  name: string
  start: number
  duration: number
}

export interface TracesPayload {
  stats: Stat[]
  items: Trace[]
  sampling: string
  connected_sources: number
  waterfall: {
    trace_id: string
    operation: string
    total_ms: number
    spans: Span[]
  } | null
}

/* ---------------- Validation & Evals ---------------- */

export interface EvalRun {
  suite: string
  target: string
  checks: number
  passRate: number
  status: string
  tone: Tone
  ranAt: string
}

export interface Check {
  name: string
  dataset: string
  result: string
  tone: Tone
  detail: string
}

export interface EvalsPayload {
  stats: Stat[]
  runs: EvalRun[]
  checks: Check[]
  run_trigger: string
  failure_summary: string
  connected_sources: number
}

interface RawEvalsPayload {
  stats: Stat[]
  runs: (Omit<EvalRun, 'passRate' | 'ranAt'> & { pass_rate: number; ran_at: string })[]
  checks: Check[]
  run_trigger: string
  failure_summary: string
  connected_sources: number
}

/* ---------------- db.json editor ---------------- */

export interface DbSection {
  key: string
  kind: string
  count: number
  /** Required keys cannot be removed — the server rejects a document without them. */
  required: boolean
}

export interface DbPayload {
  path: string
  bytes: number
  sections: DbSection[]
  required: string[]
  db: Record<string, unknown>
}

/* ---------------- Response schemas ---------------- */

/* ---------------- Identity ---------------- */

const AUTH_ROLE = shape({ role_id: str, label: str, access_note: str })

/**
 * The dataset pool, served rather than written here.
 *
 * The same rule the consent screen follows with its scopes and the Share picker with its roles: a
 * list held in the client can offer a value the API refuses, and here that would be a selector
 * showing CAPEX on a deployment with no CAPEX prefix. `populated` is the server's own answer to
 * "does this hold anything", so an empty dataset reads as empty rather than as a page that failed.
 */
const DATASET_ROW = shape({
  dataset: str,
  label: str,
  primary: bool,
  ref: str,
  store: str,
  projects: num,
  drives: num,
  reports: num,
  graphs: num,
  populated: bool,
})

/**
 * The report prototype's own dataset, served rather than bundled.
 *
 * **Shallow here, and deliberately.** The prototype already validates it deeply — `validateDataset` in
 * `src/reports/data/validate.ts` walks every row and every enum, and was written when this was a JSON
 * import — so this checks the envelope the boundary is responsible for and hands the rest over. Two deep
 * validators over one document is two answers to "what is a valid row".
 *
 * `arrayOf(unknownRow)` rather than a row schema for the same reason: the prototype owns those shapes.
 */
const PROTOTYPE_ROW = (value: unknown, path: string) =>
  value !== null && typeof value === 'object' ? [] : [`${path} should be an object`]

const PROTOTYPE_DATASET = shape({
  meta: shape({}),
  assumptions: shape({}),
  opts: shape({}),
  fields: arrayOf(PROTOTYPE_ROW),
  generators: arrayOf(PROTOTYPE_ROW),
  facilities: arrayOf(PROTOTYPE_ROW),
  quarters: arrayOf(PROTOTYPE_ROW),
  traces: arrayOf(PROTOTYPE_ROW),
  starters: arrayOf(PROTOTYPE_ROW),
  presets: arrayOf(PROTOTYPE_ROW),
  audiences: arrayOf(PROTOTYPE_ROW),
  library: arrayOf(PROTOTYPE_ROW),
  slice_default: arrayOf(str),
})

const PROTOTYPE_PAYLOAD = shape({
  ref: str,
  store: str,
  dataset: PROTOTYPE_DATASET,
})

const DATASETS_PAYLOAD = shape({
  datasets: arrayOf(DATASET_ROW),
  both: shape({ dataset: str, label: str, read_only: bool }),
  selected: str,
})

const AUTH_ROLES_PAYLOAD = shape({
  roles: arrayOf(AUTH_ROLE),
  count: num,
})

const SESSION_IDENTITY_PAYLOAD = shape({
  email: str,
  name: str,
  role_id: str,
  role_label: str,
  access_note: str,
  initials: str,
  signed_in_at: str,
})

const STAT = shape({ label: str, value: str, note: nullable(str), tone: nullable(str) })

const SOURCE_ROW = shape({
  source_id: str,
  source_name: str,
  connector: str,
  status: str,
  project_account: str,
  scope: str,
  connected_at: str,
  profiled_tables: num,
  profiled_columns: num,
  profiled_documents: nullable(num),
  profiled_entities: nullable(num),
  profiled_today: num,
  profiled_today_date: str,
  documents_chunked: nullable(num),
  chunks_total: nullable(num),
  chunk_chars: nullable(num),
  last_chunk_at: nullable(str),
  last_chunk_count: nullable(num),
  last_chunk_since: str,
  datasets: arrayOf(str),
  folders: arrayOf(str),
  labels: arrayOf(str),
  kind: str,
  profilable: bool,
})

const SOURCES_PAYLOAD = shape({
  sources: arrayOf(SOURCE_ROW),
  registered_count: num,
  connected_sources: num,
  profiled_tables: num,
  profiled_columns: num,
  profiled_documents: num,
  profiled_entities: num,
  profiled_today: num,
  profiled_today_date: str,
  documents_chunked: nullable(num),
  chunks_total: nullable(num),
  chunk_chars: nullable(num),
})

const BROWSE_PAYLOAD = shape({
  source_id: str,
  dataset_count: num,
  object_count: num,
  datasets: arrayOf(
    shape({
      dataset_id: str,
      table_count: num,
      tables: arrayOf(
        shape({
          table_id: str,
          label: str,
          type: str,
          grain: str,
          columns: num,
          /*
           * **Nullable, because a catalogued table need not have been profiled.** CAPEX's own provenance
           * says it: "rows is null for the 60 tables the package catalogued but did not profile — that is
           * the honest value, not zero." 62 of its 64 tables arrive that way, and declaring `num` here
           * made every browse of a CAPEX source fail validation with "rows should be a number, got null" —
           * a real payload refused by a schema written when one dataset had profiled everything.
           */
          rows: nullable(num),
          profiled: bool,
        }),
      ),
    }),
  ),
})

const DOCUMENT_BROWSE_PAYLOAD = shape({
  source_id: str,
  folder_count: num,
  object_count: num,
  folders: arrayOf(
    shape({
      folder_id: str,
      name: str,
      path: str,
      document_count: num,
      documents: arrayOf(
        shape({
          document_id: str,
          name: str,
          mime_type: str,
          doc_type: str,
          doc_type_label: str,
          linked_entity: str,
          pages: num,
          size_mb: num,
          entities: num,
          modified: str,
          /* Measured or absent — see the dictionary's own pair. */
          chunks: nullable(num),
          size_chars: nullable(num),
          profiled: bool,
        }),
      ),
    }),
  ),
})

const JOB = shape({
  job_id: str,
  short_id: str,
  source_id: str,
  /* Both read off the one declaration above, for the reason `OAUTH_PROVIDERS` is: a widened
     union with an unwidened schema refuses a correct payload and blames the server. */
  kind: oneOf(PROFILE_KINDS),
  unit: oneOf(PROFILE_UNITS),
  status: oneOf(['queued', 'running', 'complete', 'cancelled', 'failed']),
  stage_index: num,
  stage_total: num,
  stage_label: str,
  stages: arrayOf(str),
  pipeline: str,
  progress: num,
  object_count: num,
  objects_done: num,
  force: bool,
  triggered_at: str,
  elapsed_seconds: num,
  triggered_by: str,
  objects: arrayOf(
    shape({
      parent_id: str,
      object_id: str,
      label: str,
      units: nullable(num),
      state: oneOf(['pending', 'profiled', 'skipped']),
    }),
  ),
})

const JOBS_PAYLOAD = shape({
  active: arrayOf(JOB),
  recent: arrayOf(JOB),
  active_count: num,
  recent_count: num,
  status_line: str,
})

const COLUMNS_PAYLOAD = shape({
  source_id: str,
  profiled_tables: num,
  dataset_count: num,
  facets: shape({
    all: num,
    needs_review: num,
    pii: num,
    ids: num,
    measures: num,
    dates: num,
    location: num,
    flags: num,
  }),
  datasets: arrayOf(
    shape({
      dataset_id: str,
      table_count: num,
      column_count: num,
      tables: arrayOf(
        shape({
          table_id: str,
          label: str,
          type: str,
          grain: str,
          /* Nullable for the same reason as the browse payload above — see the note there. */
          rows: nullable(num),
          column_count: num,
          columns: arrayOf(
            shape({
              column_id: str,
              label: str,
              /*
               * **Nullable, all four, because a column can now be *declared* rather than measured.**
               * An uploaded data dictionary states what a column means; nothing sampled it, so there
               * is no type where the file gave none and no confidence, null% or distinct at all. The
               * alternative was a plausible figure in each, which is the one thing a dictionary must
               * not carry — the value of a profile is that its numbers were measured.
               *
               * Fifth in the family after `rows`, `class` and `derivation`, and the same lesson:
               * a declared type is a claim about every column, not the ones it was written against.
               */
              type: nullable(str),
              /* The dataset's vocabulary, not ours — see ColumnClass. */
              class: str,
              facet: nullable(str),
              confidence: nullable(num),
              /* Null wherever the profiler recorded no method — see the interface. */
              derivation: nullable(str),
              pii: bool,
              null_pct: nullable(num),
              distinct: nullable(num),
              description: nullable(str),
              description_status: oneOf(['needs review', 'described']),
            }),
          ),
        }),
      ),
    }),
  ),
})

const DOCUMENTS_PAYLOAD = shape({
  source_id: str,
  profiled_documents: num,
  folder_count: num,
  entity_count: num,
  facets: shape({
    all: num,
    needs_review: num,
    pii: num,
  }),
  type_facets: arrayOf(shape({ key: str, label: str, count: num })),
  folders: arrayOf(
    shape({
      folder_id: str,
      name: str,
      path: str,
      document_count: num,
      entity_count: num,
      documents: arrayOf(
        shape({
          document_id: str,
          name: str,
          mime_type: str,
          doc_type: str,
          doc_type_label: str,
          linked_entity: str,
          /* nullable() accepts an absent key as well as null, so this checks the
             shape when it is there and tolerates a document that resolved to
             nothing. */
          resolution: nullable(
            shape({
              extraction_id: str,
              extracted_entity: str,
              entity_type: str,
              resolved_node: str,
              resolved_facility: str,
              state: str,
              linked_manifests: num,
              confidence: num,
            }),
          ),
          pages: num,
          size_mb: num,
          modified: str,
          /* Measured or absent, exactly as the mail row above: `pages * 2.5` used to make this a
             number for every document, and a served figure nothing counted is the one thing a
             dictionary must not carry. */
          chunks: nullable(num),
          size_chars: nullable(num),
          snippet: nullable(str),
          entity_count: num,
          pii_count: num,
          summary: nullable(str),
          summary_status: oneOf(['needs review', 'described']),
          entities: arrayOf(
            shape({
              entity_id: str,
              type: str,
              /* Same reasoning as a column's: CAPEX's documents carry `measure_commitment`,
                 `person` and `label`, and refusing them blanked the whole document dictionary. */
              class: str,
              confidence: num,
              pii: bool,
              occurrences: num,
              coverage_pct: num,
            }),
          ),
        }),
      ),
    }),
  ),
})

const MAIL_BROWSE_PAYLOAD = shape({
  source_id: str,
  label_count: num,
  message_count: num,
  object_count: num,
  labels: arrayOf(
    shape({
      label_id: str,
      name: str,
      message_count: num,
      document_count: num,
      messages: arrayOf(
        shape({
          message_id: str,
          thread_id: str,
          subject: str,
          from: str,
          from_name: str,
          to: str,
          to_name: str,
          direction: oneOf(['sent', 'received']),
          labels: arrayOf(str),
          received: str,
          size_kb: num,
          document_count: num,
          documents: arrayOf(
            shape({
              document_id: str,
              name: str,
              mime_type: str,
              size_kb: num,
              entities: num,
              profiled: bool,
            }),
          ),
        }),
      ),
    }),
  ),
})

const MAIL_DOCUMENTS_PAYLOAD = shape({
  source_id: str,
  mailbox: nullable(str),
  profiled_documents: num,
  document_total: num,
  label_count: num,
  entity_count: num,
  facets: shape({
    all: num,
    needs_review: num,
    pii: num,
  }),
  label_facets: arrayOf(shape({ key: str, label: str, count: num })),
  labels: arrayOf(
    shape({
      label_id: str,
      name: str,
      document_count: num,
      entity_count: num,
      documents: arrayOf(
        shape({
          document_id: str,
          name: str,
          mime_type: str,
          size_kb: num,
          label: str,
          /*
           * **Nullable, because a shipped corpus states documents and not the mail they arrived
           * on.** A dataset that ships `mail_corpus` says what each document is; inventing the
           * message it came in would synthesise exactly what shipping it replaced. A synthesised
           * mailbox still fills all of these.
           */
          message_id: nullable(str),
          subject: nullable(str),
          from: nullable(str),
          from_name: nullable(str),
          to: nullable(str),
          to_name: nullable(str),
          direction: nullable(oneOf(['sent', 'received'])),
          received: nullable(str),
          /*
           * What the Catalog's table states per row. **Null for a synthesised document** rather
           * than a plausible figure: nothing counted the pages of a document nothing wrote, and an
           * em dash is the honest cell.
           */
          pages: nullable(num),
          size_chars: nullable(num),
          snippet: nullable(str),
          chunks: num,
          entity_count: num,
          pii_count: num,
          observation: bool,
          summary: nullable(str),
          summary_status: oneOf(['needs review', 'described']),
          entities: arrayOf(
            shape({
              entity_id: str,
              type: str,
              /* The dataset's vocabulary, not ours — the same reasoning as a drive document
                 entity's class, which refusing blanked a whole dictionary once. */
              class: str,
              confidence: num,
              pii: bool,
              occurrences: num,
              coverage_pct: num,
            }),
          ),
        }),
      ),
    }),
  ),
})

const AUDIT_PAYLOAD = shape({
  stats: arrayOf(STAT),
  events: arrayOf(
    shape({ actor: str, action: str, resource: str, severity: str, tone: str, at: str }),
  ),
  policies: arrayOf(shape({ name: str, desc: str, status: str, tone: str })),
  connected_sources: num,
})

const TRACES_PAYLOAD = shape({
  stats: arrayOf(STAT),
  items: arrayOf(
    shape({
      id: str,
      operation: str,
      service: str,
      duration: num,
      spans: num,
      status: str,
      tone: str,
      at: str,
    }),
  ),
  connected_sources: num,
  waterfall: nullable(
    shape({
      trace_id: str,
      operation: str,
      total_ms: num,
      spans: arrayOf(shape({ name: str, start: num, duration: num })),
    }),
  ),
})

const EVALS_PAYLOAD = shape({
  stats: arrayOf(STAT),
  runs: arrayOf(
    shape({
      suite: str,
      target: str,
      checks: num,
      pass_rate: num,
      status: str,
      tone: str,
      ran_at: str,
    }),
  ),
  checks: arrayOf(
    shape({ name: str, dataset: str, result: str, tone: str, detail: str }),
  ),
  connected_sources: num,
})

const SIGNALS_PAYLOAD = shape({
  signals: arrayOf(
    shape({
      signal_id: str,
      kind: str,
      severity: str,
      dataset: str,
      table: str,
      detail: str,
      action: str,
      detected: str,
    }),
  ),
  count: num,
  connected_sources: num,
})

const GRAPH_DOMAINS_PAYLOAD = shape({
  domain_count: num,
  connected_sources: num,
  profiled_objects: num,
  domains: arrayOf(
    shape({
      domain_id: str,
      name: str,
      expected_sources: arrayOf(str),
      fit: oneOf(['strong', 'partial', 'none']),
      note: str,
      rank: num,
      drafts: shape({ personas: num, metrics: num, hero_questions: num }),
    }),
  ),
})

const DRAFTED_ITEM = shape({
  name: str,
  description: str,
  source: oneOf(['ai', 'user']),
  /* Both nullable, and `nullable` accepts an absent key as well as a null — a brief saved before
     either field existed carries neither, and a persona never carries `sql` at all. */
  origin: nullable(str),
  sql: nullable(str),
})

const GRAPH_SOURCES_PAYLOAD = shape({
  source_count: num,
  profiled_source_count: num,
  runtime_source_count: num,
  sources: arrayOf(
    shape({
      source_id: str,
      source_name: str,
      connector: str,
      kind: str,
      status: str,
      type_label: str,
      account: str,
      scope_label: str,
      scope: arrayOf(str),
      object_count: num,
      unit_label: str,
      /* Read at question time rather than profiled — served, not derived from `kind`. */
      runtime: bool,
      objects: arrayOf(
        shape({
          object_id: str,
          parent_id: str,
          label: str,
          /*
           * **Nullable, and that is a claim about every dataset rather than the one in
           * front of us.** A Gmail label has no message count because this connector
           * samples no mail, and `num` here refused every runtime source with "units
           * should be a number, got null" under a message blaming a stale server — the
           * same shape as the `rows: num` failure CAPEX's browse schema hit.
           */
          units: nullable(num),
          unit_label: str,
          /*
           * What a document row states beside its name. **Null everywhere but a mailbox**, and
           * null there too for a synthesised document — nothing counted the pages of a document
           * nothing wrote, so the row prints neither rather than a plausible figure.
           */
          pages: nullable(num),
          size_chars: nullable(num),
          snippet: nullable(str),
        }),
      ),
    }),
  ),
})

const HERO_QUESTION = shape({
  text: str,
  priority: oneOf(["high", "normal"]),
  source: oneOf(["ai", "user"]),
  /* Nullable: a question nothing matched keeps none, and a brief saved before this field existed
     carries none either — `nullable` accepts an absent key as well as a null. */
  sql: nullable(str),
})

const ANSWER_FORMAT = shape({ format_id: str, name: str, format: str })

const GAP_CHOICE = shape({
  element_id: str,
  decision: oneOf([
    'accept permanent',
    'drop question',
    'connect source',
    'defer with trigger',
  ]),
})

const COVERAGE_PAYLOAD = shape({
  title: str,
  entity_count: num,
  relationship_count: num,
  hero_question_count: num,
  gap_count: num,
  runtime_question_count: num,
  object_count: num,
  elements: arrayOf(
    shape({
      element_id: str,
      name: str,
      kind: oneOf(['entity', 'relationship']),
      status: oneOf(['backed', 'gap', 'runtime']),
      confidence: num,
      evidence: nullable(str),
      reason: nullable(str),
    }),
  ),
  runtime_sources: arrayOf(
    shape({
      source_id: str,
      source_name: str,
      type_label: str,
      scope: num,
      scope_label: str,
    }),
  ),
  /* Null where the brief picked none — an absent note is not an empty one. */
  runtime_note: nullable(str),
})

const SOURCE_PICK = shape({
  source_id: str,
  mode: oneOf(['all', 'subset']),
  objects: arrayOf(str),
})

const USE_CASE = shape({
  use_case_id: str,
  name: str,
  status: oneOf(['draft', 'committed']),
  domain_id: nullable(str),
  business_need: str,
  personas: arrayOf(DRAFTED_ITEM),
  metrics: arrayOf(DRAFTED_ITEM),
  sources: arrayOf(SOURCE_PICK),
  hero_questions: arrayOf(HERO_QUESTION),
  gap_decisions: arrayOf(GAP_CHOICE),
  step: num,
  step_total: num,
  updated_at: nullable(str),
})

const LLM_RUN = shape({
  stages: arrayOf(str),
  cost_usd: num,
  cost_cap_usd: num,
})

const SUGGESTIONS_PAYLOAD = shape({
  count: num,
  derived_from: str,
  /* Null whenever anything was drafted — nullable checks the type, not the presence, so an older
     mock server that does not send it at all still validates. */
  empty_reason: nullable(str),
  run: LLM_RUN,
  suggestions: arrayOf(
    shape({
      id: str,
      name: str,
      detail: str,
      why: str,
      // Absent on personas, metrics and formats, and on any question no use case
      // stated a priority for — nullable checks the type, not the presence.
      priority: nullable(oneOf(['high', 'normal'])),
    }),
  ),
})

/*
 * Step 3's Edit answers with the row it just stored, in the same shape the suggesters send —
 * validated like every other write's reply, because a stale server answers a PATCH with the old
 * shape as readily as it answers a GET.
 */
const METRIC_EDIT_PAYLOAD = shape({
  metric: shape({
    id: str,
    name: str,
    detail: str,
    why: str,
    priority: nullable(oneOf(['high', 'normal'])),
  }),
})

const DERIVATION_PAYLOAD = shape({
  derivation_id: str,
  status: oneOf(['running', 'complete']),
  stage_index: num,
  stage_total: num,
  stage_label: str,
  stages: arrayOf(str),
  progress: num,
  revealed: arrayOf(str),
  entity_total: num,
  cost_usd: num,
  cost_cap_usd: num,
})

const GRAPH_BUILD = shape({
  build_id: str,
  use_case_id: str,
  status: oneOf(['running', 'complete']),
  stage_index: num,
  stage_total: num,
  step_index: num,
  step_total: num,
  step_ms: num,
  stages: arrayOf(
    shape({
      key: str,
      state: oneOf(['pending', 'running', 'complete']),
      steps: arrayOf(shape({ key: str, state: oneOf(['pending', 'running', 'complete']) })),
    }),
  ),
  package_id: str,
  graph_version: str,
  config_version: str,
  started_at: str,
  finished_at: nullable(str),
})

const GRAPH_BUILDS_PAYLOAD = shape({
  use_case_id: str,
  builds: arrayOf(GRAPH_BUILD),
  count: num,
})

const USE_CASES_PAYLOAD = shape({
  use_cases: arrayOf(USE_CASE),
  count: num,
  draft_count: num,
  committed_count: num,
  steps: arrayOf(str),
})

const PREVIEW_PAYLOAD = shape({
  project_id: str,
  dataset_count: num,
  datasets: arrayOf(
    shape({
      dataset_id: str,
      location: str,
      description: str,
      table_count: num,
      column_count: num,
    }),
  ),
})

const DRIVE_PREVIEW_PAYLOAD = shape({
  drive_id: str,
  display_name: str,
  kind: str,
  folder_count: num,
  document_count: num,
  folders: arrayOf(
    shape({
      folder_id: str,
      /* `nullable`, because a root folder has no parent — and nullable accepts an absent key
         too, so a drive seeded before nesting still reads rather than failing the whole
         preview over a folder that simply is not nested. */
      parent_id: nullable(str),
      name: str,
      path: str,
      description: str,
      document_count: num,
      page_count: num,
      file_types: arrayOf(str),
    }),
  ),
})

/** The drives a session can read — the twin of OAUTH_PROJECTS_PAYLOAD. */
const OAUTH_MAILBOXES_PAYLOAD = shape({
  mailboxes: arrayOf(
    shape({
      mailbox: str,
      display_name: str,
      description: str,
      credential_handle: str,
      label_count: num,
    }),
  ),
  mailbox_count: num,
})

const GMAIL_PREVIEW_PAYLOAD = shape({
  mailbox: str,
  display_name: str,
  description: str,
  labels: arrayOf(str),
  label_count: num,
})

const REGISTERED_GMAIL_PAYLOAD = shape({
  source_id: str,
  source_name: str,
  connector: str,
  mailbox: str,
  credential_handle: str,
  labels: arrayOf(str),
  query: nullable(str),
  status: str,
  registered_at: str,
  newly_connected: bool,
})

const OAUTH_DRIVES_PAYLOAD = shape({
  drives: arrayOf(
    shape({
      drive_id: str,
      display_name: str,
      kind: str,
      folder_count: num,
      document_count: num,
      credential_handle: nullable(str),
    }),
  ),
  drive_count: num,
})

const DRIVE_FOLDERS_PAYLOAD = shape({
  drive_id: str,
  folders: arrayOf(
    shape({
      folder_id: str,
      parent_id: nullable(str),
      name: str,
      path: str,
      document_count: num,
    }),
  ),
})

/* The directory row a consent resolved — the login's own session shape, minus the moment it began:
   a consent is not a sign-in and has no `signed_in_at` of its own to report. */
const CONSENT_IDENTITY = shape({
  email: str,
  name: str,
  role_id: str,
  role_label: str,
  access_note: str,
  initials: str,
})

const OAUTH_CALLBACK_PAYLOAD = shape({
  account: shape({ email: str, name: str }),
  session: str,
  provider: oneOf([...OAUTH_PROVIDERS]),
  identity: nullable(CONSENT_IDENTITY),
})

const OAUTH_PROJECTS_PAYLOAD = shape({
  projects: arrayOf(
    shape({
      project_id: str,
      display_name: str,
      location: str,
      dataset_count: num,
      credential_handle: nullable(str),
    }),
  ),
  project_count: num,
})

/* ---------------- Graph Studio ---------------- */

const STUDIO_GRAPH = shape({
  use_case_id: str,
  name: str,
  domain_id: nullable(str),
  business_need: str,
  version: str,
  state: oneOf(['draft', 'published']),
  live_version: nullable(str),
  queue_count: num,
  must_review_outstanding: num,
  must_review_count: num,
  published_count: num,
  built_at: nullable(str),
})

const STUDIO_GRAPHS_PAYLOAD = shape({
  graphs: arrayOf(STUDIO_GRAPH),
  count: num,
  draft_count: num,
})

const REVIEW_ITEM = shape({
  item_id: str,
  /* `measure` joined the two on the rebuild: a cross-basis measure is a third kind
     of thing to review, neither an entity nor a relationship. */
  kind: oneOf(['relationship', 'entity', 'measure']),
  title: str,
  detail: str,
  confidence: num,
  /* The triage lane the row arrived in. Nullable rather than absent-tolerant would
     hide a server that stopped sending it, so it is checked as a value. */
  band: nullable(oneOf(['High', 'Medium', 'Low'])),
  floor: nullable(str),
  action_set: str,
  /* The row's own buttons. `choice` is what gets recorded and `label` is what the
     button says, so a row can offer "Keep distinct" without inventing a fifth
     recorded outcome. */
  actions: arrayOf(shape({ choice: str, label: str })),
  evidence: arrayOf(str),
  graph_refs: arrayOf(str),
  justification: bool,
  decision: nullable(
    shape({ choice: str, justification: nullable(str), decided_at: str }),
  ),
})

const GRAPH_STUDIO_PAYLOAD = shape({
  use_case_id: str,
  name: str,
  domain_id: nullable(str),
  business_need: str,
  version: str,
  state: oneOf(['draft', 'published']),
  live_version: nullable(str),
  queue_count: num,
  must_review_outstanding: num,
  must_review_count: num,
  published_count: num,
  built_at: nullable(str),
  graph_name: str,
  status: str,
  decision_memory: str,
  must_review: arrayOf(REVIEW_ITEM),
  confirmed_sample: arrayOf(REVIEW_ITEM),
  confirmed_count: num,
  auto_approved_sample: arrayOf(REVIEW_ITEM),
  auto_approved_count: num,
  pivot: shape({
    pivot_id: str,
    alternative_id: str,
    title: str,
    detail: str,
    /* Why this is a pivot rather than a queue row — the sentence the page prints
       above the options, so it is the server's and not the component's. */
    why_pivot: str,
    confidence: num,
    band: nullable(oneOf(['High', 'Medium', 'Low'])),
    floor: str,
    evidence: arrayOf(str),
    graph_refs: arrayOf(str),
    options: arrayOf(shape({ option_id: str, label: str, consequence: str })),
    open: bool,
    chosen: nullable(str),
  }),
  pivot_count: num,
  /* The recorded sanity checks, as chips. Question and hero ref only — the verdict
     and the plan stay behind the query, so a chip cannot show an answer nobody
     asked for. */
  sanity_checks: arrayOf(
    shape({ check_id: str, hero_question_id: str, question: str }),
  ),
  batch_resolved: num,
  batch_total: num,
  publish: shape({ blocked: bool, reasons: arrayOf(str), explanation: str }),
  versions: arrayOf(
    shape({
      sha256: str,
      graph_id: str,
      config_version: str,
      entities: num,
      relationships: num,
      from_job: str,
      created_at: str,
      gate: oneOf(['passed', 'unknown']),
      published: bool,
    }),
  ),
})

const CANVAS_NODE = shape({
  node_id: str,
  label: str,
  sublabel: str,
  type: str,
  /* Which of the build model's three element classes the node is. The colour folds
     `concept` and `measure_element` into one hue, so this is where the distinction
     survives — and it is the distinction the graph rebuild was about. */
  element_class: oneOf(['thin_instance', 'concept', 'measure_element']),
  /*
   * **Nullable, because a package may not know where a node came from.** CAPEX states no source for 11
   * of its 442 nodes, and `str` refused the whole canvas over them. The viewer already prints
   * provenance only when there is some — an absence has no note — so null is the honest value and 0
   * consumers wanted a placeholder.
   */
  source: nullable(str),
  degree: num,
  r: num,
  /*
   * **A plain string, because `group` is each package's own vocabulary.** It was
   * `oneOf(['row', 'schema', 'document', 'alias'])`, which is EPA's account of how an element was
   * built — and CAPEX names its node types there instead (`Concept`, `Programme`, `Region`…), so
   * every one of its 442 nodes was refused with "group should be one of row | schema | document |
   * alias", under a message blaming a stale server. The union was true of one dataset by accident.
   *
   * Nothing is lost by widening it: the drawing stopped encoding `group` when the viewer was vendored
   * in — it colours by ontology `type` — so this is carried as the graph's own account of itself and
   * read by nobody who could be misled by an unfamiliar word. A union that is right for one dataset
   * and refuses another is not a validator, it is a bug with a good error message.
   */
  group: str,
  /*
   * **Nullable, because a package may score no node at all.** CAPEX scores none of its 442 — the
   * package states no per-node confidence — while EPA scores all 189, so `num` here was true of one
   * dataset by accident. It would have refused the other's entire canvas with "confidence should be a
   * number, got null", which reads as a stale server and is not one. The same shape as `rows` on a
   * browsed table, and the same rule: check every consumer for a `?? 0`, because a default that
   * lies satisfies the compiler and states a score nobody derived.
   */
  confidence: nullable(num),
  proposed: bool,
  origin: oneOf(['derived', 'studio-authored']),
  rejected: bool,
  needs_review: bool,
  review_item_id: nullable(str),
  on_answer_path: bool,
  x: num,
  y: num,
})

const CANVAS_EDGE = shape({
  /* The graph's own edge id. A recorded sanity check names its hops by id, so the
     highlight is the exact relationships the answer used. */
  edge_id: str,
  from: str,
  to: str,
  label: str,
  detail: str,
  proposed: bool,
  review_item_id: nullable(str),
  on_answer_path: bool,
})

const CANVAS_PAYLOAD = shape({
  nodes: arrayOf(CANVAS_NODE),
  edges: arrayOf(CANVAS_EDGE),
  node_count: num,
  edge_count: num,
  facets: shape({
    all: num,
    low_confidence: num,
    needs_review: num,
    studio_authored: num,
    groups: arrayOf(
      shape({ key: oneOf(['row', 'schema', 'document', 'alias']), count: num }),
    ),
    /* Per ontology type — what the ring encodes. Not a `oneOf`: the type list is the
       graph's, and a new type must show up in the legend rather than fail here. */
    types: arrayOf(shape({ key: str, count: num })),
  }),
})

/*
 * A studio answer, from either route.
 *
 * The recorded fields are nullable because a derived walk has none of them — and
 * `recorded` is the boolean that says which route answered, so a written verdict is
 * never read as something the walk produced. Nullable rather than optional: a server
 * that stopped sending `recorded` would otherwise read as "derived" on every answer.
 */
const QUERY_PAYLOAD = shape({
  question: str,
  answerable: bool,
  reason: str,
  matched: arrayOf(str),
  path: arrayOf(str),
  path_labels: arrayOf(str),
  edges_used: arrayOf(
    shape({
      edge_id: str,
      from: str,
      to: str,
      label: str,
      from_label: str,
      to_label: str,
      proposed: bool,
    }),
  ),
  hops: num,
  caveats: arrayOf(str),
  recorded: bool,
  check_id: nullable(str),
  hero_question_id: nullable(str),
  matched_how: nullable(str),
  verdict: nullable(str),
  verdict_body: nullable(str),
  context: arrayOf(shape({ chip: str, label: str, meta: str, ok: bool })),
  plan: nullable(str),
  cost_usd: nullable(num),
  budget_usd: nullable(num),
  canvas: CANVAS_PAYLOAD,
})

/* ---------------- Ask ---------------- */

const ASK_GRAPH = shape({
  use_case_id: str,
  name: str,
  domain_id: nullable(str),
  version: str,
  published_at: nullable(str),
  published_by: nullable(str),
  caveats: arrayOf(str),
  suggested_questions: arrayOf(str),
  entity_count: num,
  relationship_count: num,
})

const ANSWER_REQUIREMENT_OPTIONS = shape({
  citations_options: arrayOf(
    shape({ value: oneOf(['required', 'optional']), label: str }),
  ),
  default_citations: oneOf(['required', 'optional']),
  formats: arrayOf(ANSWER_FORMAT),
  note: str,
})

/*
 * A connected source a reader may ask directly.
 *
 * `account` is nullable because it is what the source connected *as* — an address for a
 * mailbox — and a connector with no such notion states none rather than an empty string.
 */
const ASK_SOURCE = shape({
  source_id: str,
  name: str,
  kind: str,
  connector: str,
  account: nullable(str),
  scope: str,
  suggested_questions: arrayOf(str),
})

const ASK_GRAPHS_PAYLOAD = shape({
  graphs: arrayOf(ASK_GRAPH),
  count: num,
  sources: arrayOf(ASK_SOURCE),
  source_count: num,
  built_count: num,
  draft_count: num,
  answer_requirements: ANSWER_REQUIREMENT_OPTIONS,
})

const ANSWER_REQUIREMENTS = shape({
  citations: oneOf(['required', 'optional']),
  formats: arrayOf(ANSWER_FORMAT),
  satisfied: bool,
  note: str,
})

/*
 * `answer` and `confidence` are nullable because an abstention has neither, and
 * that is a correct outcome rather than a missing field. `reason` is not
 * nullable: an answer that cannot say why it is an answer is not one.
 */
/**
 * One block of a recorded answer, by its `type`.
 *
 * `value` on a metric is `number | string` because the tenant writes both ("15",
 * "TXD000719518"), and coercing either way would rewrite their figure.
 */
/** A figure the tenant wrote either way — a number, or text like an EPA id. */
const cell: FieldCheck = (v, path, issues) => {
  if (typeof v !== 'number' && typeof v !== 'string') {
    issues.push(`${path} should be a number or a string, got ${typeof v}`)
  }
}

const ANSWER_BLOCK = variant('type', {
  text: shape({ type: str, markdown: str }),
  metric: shape({
    type: str,
    items: arrayOf(
      shape({
        label: str,
        value: cell,
        unit: nullable(str),
        flag: nullable(oneOf(['good', 'risk'])),
      }),
    ),
  }),
  chart: shape({
    type: str,
    chart: oneOf(['bar', 'line', 'column', 'grouped', 'pie', 'donut']),
    title: str,
    x_label: nullable(str),
    y_label: nullable(str),
    note: nullable(str),
    data: arrayOf(shape({ label: str, value: num })),
  }),
  table: shape({
    type: str,
    title: str,
    columns: arrayOf(str),
    /*
     * A cell is a string OR a number — the corpus writes counts as numbers and
     * everything else as text. Declared as `str` first, which would have refused
     * every table in the set: the boundary check caught it before a browser did,
     * which is the whole point of having one.
     */
    rows: arrayOf(arrayOf(cell)),
  }),
  /*
   * Claims read from correspondence at question time.
   *
   * Only the four fields that *identify* a claim are required — who said it, when, in which
   * message, and what they claimed. Everything else is `nullable`, and that was measured
   * against the corpus rather than assumed: of 27 rows, 10 name no amount, 22 no month
   * count, 13 no change order, 7 resolved to nothing and 3 carry no confidence at all.
   * Declaring any of those non-null is the `rows: num` mistake — a field the whole array
   * does not share is not a required field, and one absent value would refuse the answer.
   */
  observation: shape({
    type: str,
    label: str,
    note: nullable(str),
    items: arrayOf(
      shape({
        message_id: str,
        from_name: str,
        from_side: nullable(str),
        sent_at: str,
        subject: nullable(str),
        claim: str,
        reason_label: nullable(str),
        amount: nullable(num),
        amount_basis: nullable(str),
        months: nullable(num),
        confidence: nullable(num),
        band: nullable(str),
        resolved_to: nullable(str),
        change_order: nullable(str),
      }),
    ),
  }),
})

const ASK_ANSWER_PAYLOAD = shape({
  question: str,
  /*
   * **Null where a connected source answered rather than a graph.** These three were `str`,
   * which was true while a graph was the only thing that could be asked; a source-scoped
   * answer has no use case, no graph name and no version, and borrowing whatever happened to
   * be live would attribute it to content that did not produce it.
   */
  use_case_id: nullable(str),
  graph_name: nullable(str),
  version: nullable(str),
  /** The sources read at question time, where they were what answered. */
  source_ids: nullable(arrayOf(str)),
  answered: bool,
  reason: str,
  answer: nullable(str),
  confidence: nullable(num),
  entities: arrayOf(str),
  path: arrayOf(str),
  hops: num,
  reasoning: arrayOf(shape({ step: str, detail: str })),
  /*
   * Every field past the first three is `nullable`, which also means *absent is accepted* —
   * so the graph walk's own citations, which carry only a label and a detail, still validate
   * without the walk having to emit nulls it knows nothing about.
   */
  citations: arrayOf(
    shape({
      label: str,
      detail: str,
      confidence: nullable(num),
      kind: nullable(str),
      source_id: nullable(str),
      runtime: nullable(bool),
      as_of: nullable(str),
      authoritative: nullable(bool),
      why_not_authoritative: nullable(str),
      n: nullable(num),
    }),
  ),
  caveats: arrayOf(str),
  asked_at: str,
  summary: nullable(str),
  blocks: arrayOf(ANSWER_BLOCK),
  answer_id: nullable(str),
  requirements: ANSWER_REQUIREMENTS,
})

/* ---------------- Writes answer with a shape too ---------------- */

/*
 * A POST/PUT/PATCH response is as reachable as a GET's — `/db` can be edited
 * live, and a stale server answers writes with the old shape as readily as
 * reads. These were the endpoints whose results were rendered or stored without
 * a boundary check; a missing field surfaced as `undefined` in a table instead
 * of a message naming the field.
 */
const GOOGLE_SIGN_IN_ACCOUNT = shape({
  email: str,
  name: str,
  initials: str,
})

const OAUTH_START_PAYLOAD = shape({
  state: str,
  provider: oneOf([...OAUTH_PROVIDERS]),
  auth_url: str,
  scopes: arrayOf(str),
  /* Required, not `nullable`: a server that predates the chooser should be refused loudly with the
     restart message rather than opening a window with one account and no way to tell why. */
  accounts: arrayOf(GOOGLE_SIGN_IN_ACCOUNT),
})

const REGISTERED_SOURCE_PAYLOAD = shape({
  source_id: str,
  source_name: str,
  connector: str,
  project_id: str,
  credential_handle: str,
  datasets: arrayOf(str),
  status: str,
  registered_at: str,
  newly_connected: bool,
})

/* A generic registration's own shape — see `RegisteredGenericSource` for why it cannot borrow the
   BigQuery one. `nullable` on both of the fields a connector may legitimately not have. */
const REGISTERED_GENERIC_PAYLOAD = shape({
  source_id: str,
  source_name: str,
  connector: str,
  type_label: str,
  credential_handle: nullable(str),
  account: nullable(str),
  scope: nullable(str),
  datasets: arrayOf(str),
  status: str,
  registered_at: str,
  newly_connected: bool,
})

const REGISTERED_DRIVE_PAYLOAD = shape({
  source_id: str,
  source_name: str,
  connector: str,
  drive_id: str,
  display_name: str,
  folders: arrayOf(str),
  status: str,
  registered_at: str,
  newly_connected: bool,
  folder_count: num,
  document_count: num,
})

const PROJECT_DATASETS_PAYLOAD = shape({
  project_id: str,
  datasets: arrayOf(shape({ dataset_id: str })),
})

const JOB_STARTED_PAYLOAD = shape({ job: JOB })

const DELETED_PAYLOAD = shape({ deleted: str })

/*
 * Deleting a *source* answers with what the delete gave back as well as what it took: the
 * acceptances its declarations carried, cleared so the Data Modeling rows read *Curated by AI*
 * again. Its own schema rather than a widened `DELETED_PAYLOAD` — `shape` ignores keys it is not
 * told about, so sharing one would leave the new field unchecked while `deleteUseCase`, which
 * returns nothing of the kind, claimed to carry it.
 */
const SOURCE_DELETED_PAYLOAD = shape({
  deleted: str,
  released: shape({ entities: num, relationships: num }),
})

const DOCUMENT_SUMMARY_PAYLOAD = shape({ key: str, summary: nullable(str) })

const COLUMN_DESCRIPTION_PAYLOAD = shape({ key: str, description: nullable(str) })

const DB_SECTION = shape({ key: str, kind: str, count: num, required: bool })

const DB_PAYLOAD = shape({
  path: str,
  bytes: num,
  required: arrayOf(str),
  db: shape({}),
  sections: arrayOf(DB_SECTION),
})

/* A save answers with the section list the editor re-renders from. */
const DB_SAVED_PAYLOAD = shape({ saved: bool, sections: arrayOf(DB_SECTION) })

const DB_SECTION_SAVED_PAYLOAD = shape({
  saved: bool,
  section: str,
  sections: arrayOf(DB_SECTION),
})

/* ---------------- Transport ---------------- */

/** Thrown with the server's own error text so the UI can surface it verbatim. */
export class ApiError extends Error {
  status: number

  constructor(message: string, status: number) {
    super(message)
    this.name = 'ApiError'
    this.status = status
  }
}

/*
 * No backticks: this is shown in a toast, where they render as characters.
 *
 * **It names the request it could not make.** "Cannot reach the mock server" on its own sent a real
 * report round in circles: the server *was* running and answering that very endpoint from a terminal, so
 * the message described a state that was not true and hid the two things that discriminate — which URL
 * was tried, and by which method. A GET that works while a PATCH fails is a different fault from a dead
 * server, and only the URL says which.
 */
/**
 * What a thrown `fetch` means, and it is deliberately **three** possibilities rather than one.
 *
 * **The old wording named only the first** — *"Start it with npm run mock"* — and that is wrong
 * advice more often than it is right: a browser throws the same `TypeError: Failed to fetch` for a
 * server that is down, for a request the browser refused to send, and for a CORS preflight the
 * server answered badly. Two of those are unaffected by starting anything, and a reader following
 * the sentence restarts a server that was fine and is no closer. Reported from use, twice.
 *
 * So it names all three and points at the two places that can actually tell them apart: the mock
 * server's own log, which prints a line for every write and every refusal — **no line at all means
 * the request never arrived** — and the browser console, which is the only place the real reason is
 * written down.
 */
const unreachable = (method: string, url: string) =>
  `Cannot reach the mock server — ${method} ${url} did not complete. ` +
  'Either it is not running (npm run mock, port 4000), or the browser refused to send the ' +
  'request, or the CORS preflight failed. The server logs every write and every refusal: if no ' +
  'line appears there for this call, it never arrived — and the browser console says which of ' +
  'the two it was.'

async function request<T>(
  path: string,
  init?: { method?: string; body?: unknown },
): Promise<T> {
  const method = init?.method ?? 'GET'
  const url = `${BASE}${path}`
  let res: Response
  try {
    res = await fetch(url, {
      method,
      /*
       * **Every request names the dataset it is asking about, and this is the only place that
       * happens.** The server defaults a caller that names none to its primary, so omitting the
       * header would silently serve EPA under whatever the selector was showing — the one
       * confusion the split exists to prevent. A header rather than a query parameter on each
       * path, because it applies to every endpoint and none of them should have to remember it.
       */
      headers: {
        'x-dataset': currentDataset(),
        ...(init?.body ? { 'content-type': 'application/json' } : {}),
      },
      body: init?.body ? JSON.stringify(init.body) : undefined,
    })
  } catch (cause) {
    /*
     * A browser `fetch` throws for a dead server, a blocked request and a failed CORS preflight alike,
     * and says which only in the console. Carrying the underlying message through is what tells those
     * apart from a toast — `TypeError: Failed to fetch` is the generic one, anything else is a clue.
     */
    const detail = cause instanceof Error && cause.message ? ` (${cause.message})` : ''
    throw new ApiError(unreachable(method, url) + detail, 0)
  }

  const payload = await res.json().catch(() => ({}))
  if (!res.ok) {
    const detail =
      typeof payload === 'object' && payload && 'error' in payload
        ? String((payload as { error: unknown }).error)
        : `request failed (${res.status})`
    /*
     * **A refused dataset is retried once on the primary, and only that refusal is.**
     *
     * A selection persisted to `localStorage` outlives the dataset it names — `CAPEX` was removed
     * while browsers still had it selected — and the server then refuses *every* request with
     * `"CAPEX" is not a dataset`. Both sides behaving correctly and the app dead in the middle: with
     * nothing clearing the value, every page failed identically and the cure was editing
     * `localStorage` by hand.
     *
     * So the stale value is discarded and the call is remade on the primary, which succeeds. It is
     * deliberately narrow: keyed on the server's own refusal for this one cause, after the reset
     * reports it actually had something to clear, and it retries **once** — `resetDatasetIfRefused`
     * returns false the second time, so a genuine 400 cannot become a loop. Everything else, a 400
     * included, still throws untouched.
     *
     * Not pre-validated on the way out, because the pool is the server's: a list held in the client
     * could refuse a dataset the server has, which is the mistake the consent screen's client-side
     * scope list was.
     */
    if (res.status === 400 && /is not a dataset/.test(detail) && resetDatasetIfRefused()) {
      return request<T>(path, init)
    }
    throw new ApiError(detail, res.status)
  }
  return payload as T
}

/* ---------------- Endpoints ---------------- */

/* ---------------- Liveness ---------------- */

/**
 * Where this bundle calls the API, as it was built.
 *
 * **Read from here rather than from `import.meta.env` a second time.** `VITE_API_BASE` is inlined at
 * build time, so a page that read the variable itself would be a second answer to the same question —
 * and the one thing the diagnostics page exists to report is which API the app is *actually* talking
 * to. `BASE` is that answer, trailing slash already stripped.
 */
export const apiBase = (): string => BASE

/** What `GET /health` reports: that the documents parsed, and which store they were read from. */
export interface ServerHealth {
  ok: boolean
  /** Every dataset read at boot — a process that is listening has validated all of them. */
  datasets: string[]
  /** `s3` or `file`. After a deploy, `file` means `S3_BUCKET` never reached the process. */
  store: string
  port: number
  uptimeS: number
}

const SERVER_HEALTH = shape({
  ok: bool,
  datasets: arrayOf(str),
  store: str,
  port: num,
  uptime_s: num,
})

/**
 * The one endpoint that answers before any dataset is chosen.
 *
 * It names every dataset rather than the selected one, so it cannot fail on a wrong `x-dataset` — which
 * is exactly what makes it the first thing to ask when nothing else works.
 */
export async function getHealth(): Promise<ServerHealth> {
  const raw = validate<{
    ok: boolean
    datasets: string[]
    store: string
    port: number
    uptime_s: number
  }>('The server health', await request<unknown>('/health'), SERVER_HEALTH)

  return {
    ok: raw.ok,
    datasets: raw.datasets,
    store: raw.store,
    port: raw.port,
    uptimeS: raw.uptime_s,
  }
}

/* ---------------- Identity ---------------- */

export async function listAuthRoles(): Promise<AuthRolesPayload> {
  const raw = validate<{
    roles: { role_id: string; label: string; access_note: string }[]
    count: number
  }>('The role list', await request<unknown>('/auth/roles'), AUTH_ROLES_PAYLOAD)

  return {
    roles: raw.roles.map((r) => ({
      roleId: r.role_id,
      label: r.label,
      accessNote: r.access_note,
    })),
    count: raw.count,
  }
}

export async function login(input: {
  email: string
  password: string
}): Promise<SessionIdentity> {
  const raw = validate<{
    email: string
    name: string
    role_id: string
    role_label: string
    access_note: string
    initials: string
    signed_in_at: string
  }>(
    'The signed-in session',
    await request<unknown>('/auth/login', {
      method: 'POST',
      /* No role. It is the *user's*, looked up in the settings store by address — the form used to ask,
         which meant one address could sign in as any persona. */
      body: { email: input.email, password: input.password },
    }),
    SESSION_IDENTITY_PAYLOAD,
  )

  return {
    email: raw.email,
    name: raw.name,
    roleId: raw.role_id,
    roleLabel: raw.role_label,
    accessNote: raw.access_note,
    initials: raw.initials,
    signedInAt: raw.signed_in_at,
  }
}

/*
 * ---------------- Settings: users, and each persona's navigation ----------------
 *
 * From `settings.json`, a **separate store** from `db.json` holding only what this section administers.
 * Both writes commit, so a permission survives a restart.
 *
 * **Neither is access control.** They record and report a navigation preference; the persona arrives
 * from a browser whose login authenticates by shape. Any UI on top has to say so in those words.
 */

export interface SettingsUser {
  id: number
  name: string
  email: string
  roleId: string
  /** Resolved from `db.auth_roles` on the way out, so no label is stored twice. */
  roleLabel: string
}

export interface SettingsPersona {
  roleId: string
  label: string
  accessNote: string
  /** Live access, per navigation key. */
  nav: Record<string, boolean>
  /** Keys whose toggle is fixed — served rather than re-derived, because the server enforces it. */
  readOnly: string[]
  /** What Reset returns to, so the page keeps no copy of what "default" means. */
  defaults: Record<string, boolean>
  /** What this persona may do to a report in the Library: open, edit, delete. */
  reports: Record<string, boolean>
  /** The authored report access Reset restores — the twin of `defaults`. */
  reportDefaults: Record<string, boolean>
}

export interface SettingsPayload {
  users: SettingsUser[]
  personas: SettingsPersona[]
  /**
   * The report actions a row offers, served rather than written into the panel.
   *
   * The rule the consent screen's scopes follow: a column the component invented could offer a
   * permission `PATCH` refuses, and one it omitted would hide a permission the server stores and the
   * card reads.
   */
  reportActions: string[]
}

/*
 * An object whose keys are unknown and whose values must all be booleans — which `shape` cannot
 * express, since it checks named fields. The keys are navigation items, so they are the app's to know
 * and not the validator's; what has to be true is that every value is a real boolean, because a
 * `"false"` string would read as *on* everywhere it is tested.
 *
 * A `Check` pushes onto `issues` and never throws, like every other checker here.
 */
const boolMap: FieldCheck = (v, path, issues) => {
  if (v === null || typeof v !== 'object' || Array.isArray(v)) {
    issues.push(`${path} should be an object of booleans`)
    return
  }
  for (const [key, value] of Object.entries(v)) {
    if (typeof value !== 'boolean') {
      issues.push(`${path}.${key} should be a boolean, got ${value === null ? 'null' : typeof value}`)
    }
  }
}

const SETTINGS_PAYLOAD = shape({
  users: arrayOf(
    shape({ id: num, name: str, email: str, role_id: str, role_label: str }),
  ),
  personas: arrayOf(
    shape({
      role_id: str,
      label: str,
      access_note: str,
      nav: boolMap,
      read_only: arrayOf(str),
      defaults: boolMap,
      reports: boolMap,
      report_defaults: boolMap,
    }),
  ),
  report_actions: arrayOf(str),
})

const toSettings = (raw: {
  users: { id: number; name: string; email: string; role_id: string; role_label: string }[]
  personas: {
    role_id: string
    label: string
    access_note: string
    nav: Record<string, boolean>
    read_only: string[]
    defaults: Record<string, boolean>
    reports: Record<string, boolean>
    report_defaults: Record<string, boolean>
  }[]
  report_actions: string[]
}): SettingsPayload => ({
  users: raw.users.map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    roleId: u.role_id,
    roleLabel: u.role_label,
  })),
  personas: raw.personas.map((p) => ({
    roleId: p.role_id,
    label: p.label,
    accessNote: p.access_note,
    nav: p.nav,
    readOnly: p.read_only,
    defaults: p.defaults,
    reports: p.reports,
    reportDefaults: p.report_defaults,
  })),
  reportActions: raw.report_actions,
})

export async function getSettings(): Promise<SettingsPayload> {
  return toSettings(
    validate('The settings', await request<unknown>('/settings'), SETTINGS_PAYLOAD),
  )
}

/**
 * Saves one persona's navigation access.
 *
 * The whole set per write, so the payload says what the answer *is* rather than what changed — and the
 * reply is the whole view, so the caller renders a validated payload instead of patching its own copy.
 * A key the app does not have, a non-boolean, or a change to a fixed key are all refused by the server
 * with a sentence; none of them is silently dropped.
 */
export async function setPersonaNav(
  roleId: string,
  nav: Record<string, boolean>,
): Promise<SettingsPayload> {
  return toSettings(
    validate(
      'The persona’s navigation',
      await request<unknown>(`/settings/personas/${encodeURIComponent(roleId)}/nav`, {
        method: 'PATCH',
        body: { nav },
      }),
      SETTINGS_PAYLOAD,
    ),
  )
}

/**
 * Saves one persona's report access — which of a Library row's three acts it is offered.
 *
 * The twin of `setPersonaNav`, and the same contract for the same reasons: the whole set per write, the
 * whole view back, and an unknown action or a non-boolean refused by the server with a sentence rather
 * than dropped.
 *
 * **It is not access control, and any UI on top has to say so in those words.** The persona is
 * client-held, the login authenticates by shape, and the API still serves every report to a caller that
 * names no role — so what this changes is which controls a reader is offered, not what they may reach.
 */
export async function setPersonaReports(
  roleId: string,
  reports: Record<string, boolean>,
): Promise<SettingsPayload> {
  return toSettings(
    validate(
      'The persona’s report access',
      await request<unknown>(`/settings/personas/${encodeURIComponent(roleId)}/reports`, {
        method: 'PATCH',
        body: { reports },
      }),
      SETTINGS_PAYLOAD,
    ),
  )
}

/** Back to the persona's authored defaults — both blocks, which live in the same store. */
export async function resetPersonaNav(roleId: string): Promise<SettingsPayload> {
  return toSettings(
    validate(
      'The persona’s navigation',
      await request<unknown>(`/settings/personas/${encodeURIComponent(roleId)}/reset`, {
        method: 'POST',
      }),
      SETTINGS_PAYLOAD,
    ),
  )
}

/** The scope depends on the connector, so the provider goes out with the start. */
/**
 * Opens the handshake and reports what the chooser may offer.
 *
 * **`as` is who is signed in**, sent for the same reason the callback sends it: the identity is
 * client-held, so the server cannot look it up. The chooser is capped, and this is what keeps the
 * reader's own account on it — without it they could not connect as themselves, and the
 * *Connected as …* alert would name somebody the window never showed. Omitted where nobody is
 * signed in, which is a state this window can legitimately open in.
 */
export async function oauthStart(
  provider: OAuthProvider = 'bigquery',
  as?: string | null,
): Promise<OAuthStart> {
  const who = as ? `&as=${encodeURIComponent(as)}` : ''
  return validate<OAuthStart>(
    'The Google sign-in',
    await request<unknown>(`/sources/oauth/start?provider=${provider}${who}`),
    OAUTH_START_PAYLOAD,
  )
}

/**
 * Who is connecting has to be *sent*, because the server does not know it: the
 * console's identity is client-held (`useAuthStore`), so the consent callback
 * echoes back the email it is given as the connecting account. Omit it and the
 * server answers with the seeded `google_account` — which is how the wizard once
 * told every user they had connected as one person from `db.json`.
 */
function callbackPath(state: string, provider: OAuthProvider, signedInAs?: string) {
  const as = signedInAs ? `&as=${encodeURIComponent(signedInAs)}` : ''
  return `/sources/oauth/callback?state=${encodeURIComponent(state)}&provider=${provider}${as}`
}

/**
 * The consent's directory row, in this layer's spelling.
 *
 * **One mapper for all three connectors**, because the API is snake_case and the app is camelCase and
 * that translation belongs here rather than in a component — the rule `last_sync` → `lastSync`
 * already follows. Three copies of it is three chances for `role_id` to reach the auth store
 * unmapped, where it reads as a persona of `undefined` and every navigation permission silently
 * falls back to "not configured".
 */
function toConsentIdentity(raw: unknown): ConsentIdentity | null {
  if (raw === null || raw === undefined) return null
  const row = raw as {
    email: string
    name: string
    role_id: string
    role_label: string
    access_note: string
    initials: string
  }
  return {
    email: row.email,
    name: row.name,
    roleId: row.role_id,
    roleLabel: row.role_label,
    accessNote: row.access_note,
    initials: row.initials,
  }
}

/** Validated, then mapped — so no caller sees the wire spelling. */
function toOAuthCallback(raw: unknown, label: string): OAuthCallback {
  const checked = validate<Omit<OAuthCallback, 'identity'> & { identity: unknown }>(
    label,
    raw,
    OAUTH_CALLBACK_PAYLOAD,
  )
  return { ...checked, identity: toConsentIdentity(checked.identity) }
}

export async function oauthCallback(
  state: string,
  signedInAs?: string,
): Promise<OAuthCallback> {
  const raw = await request<unknown>(callbackPath(state, 'bigquery', signedInAs))
  return toOAuthCallback(raw, 'The Google sign-in result')
}

export async function driveOauthCallback(
  state: string,
  signedInAs?: string,
): Promise<DriveOAuthCallback> {
  const raw = await request<unknown>(callbackPath(state, 'drive', signedInAs))
  return toOAuthCallback(raw, 'The Google Drive sign-in result')
}

/** Spends the session on what the account can see. Twin: `listOauthDrives`. */
export async function listOauthProjects(session: string): Promise<GcpProject[]> {
  const raw = await request<unknown>(
    `/sources/oauth/projects?session=${encodeURIComponent(session)}`,
  )
  return validate<{ projects: GcpProject[] }>(
    'The projects this account can read',
    raw,
    OAUTH_PROJECTS_PAYLOAD,
  ).projects
}

/** Twin of `listOauthProjects`. */
export async function listOauthDrives(session: string): Promise<DriveInfo[]> {
  const raw = await request<unknown>(
    `/sources/oauth/drives?session=${encodeURIComponent(session)}`,
  )
  return validate<{ drives: DriveInfo[] }>(
    'The drives this account can read',
    raw,
    OAUTH_DRIVES_PAYLOAD,
  ).drives
}

export async function gmailOauthCallback(
  state: string,
  signedInAs?: string,
): Promise<OAuthCallback> {
  const raw = await request<unknown>(callbackPath(state, 'gmail', signedInAs))
  return toOAuthCallback(raw, 'The Gmail sign-in result')
}

/**
 * Twin of `listOauthDrives`. Takes the signed-in address for the reason the callback does: the
 * identity is client-held, so the server has nothing to look the mailbox up from.
 */
export async function listOauthMailboxes(
  session: string,
  signedInAs?: string,
): Promise<MailboxInfo[]> {
  const as = signedInAs ? `&as=${encodeURIComponent(signedInAs)}` : ''
  const raw = await request<unknown>(
    `/sources/oauth/mailboxes?session=${encodeURIComponent(session)}${as}`,
  )
  return validate<{ mailboxes: MailboxInfo[] }>(
    'The mailbox this account can read',
    raw,
    OAUTH_MAILBOXES_PAYLOAD,
  ).mailboxes
}

/** Discovery only — the labels this handle can see, registering nothing. */
export async function previewGmailSource(
  mailbox: string,
  credentialHandle: string,
): Promise<GmailPreview> {
  return validate<GmailPreview>(
    'The Gmail preview',
    await request<unknown>('/sources/gmail/preview', {
      method: 'POST',
      body: { mailbox, credential_handle: credentialHandle },
    }),
    GMAIL_PREVIEW_PAYLOAD,
  )
}

export async function registerGmailSource(input: {
  mailbox: string
  credentialHandle: string
  labels: string[]
  /** The optional Gmail search. Sent as typed — the server does not second-guess it. */
  query?: string
  sourceName: string
}): Promise<RegisteredGmailSource> {
  return validate<RegisteredGmailSource>(
    'The registered Gmail source',
    await request<unknown>('/sources/gmail', {
      method: 'POST',
      body: {
        mailbox: input.mailbox,
        credential_handle: input.credentialHandle,
        labels: input.labels,
        query: input.query ?? null,
        source_name: input.sourceName,
      },
    }),
    REGISTERED_GMAIL_PAYLOAD,
  )
}

export async function previewSource(
  projectId: string,
  credentialHandle: string,
): Promise<PreviewResult> {
  const raw = await request<unknown>('/sources/preview', {
    method: 'POST',
    body: { project_id: projectId, credential_handle: credentialHandle },
  })
  return validate<PreviewResult>("The dataset preview", raw, PREVIEW_PAYLOAD)
}

export async function registerSource(input: {
  projectId: string
  credentialHandle: string
  datasets: string[]
  sourceName: string
}): Promise<RegisteredSource> {
  return validate<RegisteredSource>(
    'The registered source',
    await request<unknown>('/sources', {
      method: 'POST',
      body: {
        project_id: input.projectId,
        credential_handle: input.credentialHandle,
        datasets: input.datasets,
        source_name: input.sourceName,
      },
    }),
    REGISTERED_SOURCE_PAYLOAD,
  )
}

export async function previewDrive(
  driveId: string,
  credentialHandle: string,
): Promise<DrivePreviewResult> {
  const raw = await request<unknown>('/sources/drive/preview', {
    method: 'POST',
    body: { drive_id: driveId, credential_handle: credentialHandle },
  })
  return validate<DrivePreviewResult>('The folder preview', raw, DRIVE_PREVIEW_PAYLOAD)
}

export async function registerDriveSource(input: {
  driveId: string
  credentialHandle: string
  folders: string[]
  sourceName: string
}): Promise<RegisteredDriveSource> {
  return validate<RegisteredDriveSource>(
    'The registered Drive source',
    await request<unknown>('/sources/drive', {
      method: 'POST',
      body: {
        drive_id: input.driveId,
        credential_handle: input.credentialHandle,
        folders: input.folders,
        source_name: input.sourceName,
      },
    }),
    REGISTERED_DRIVE_PAYLOAD,
  )
}

export async function registerGenericSource(input: {
  connector: string
  sourceName: string
  typeLabel: string
  credentialRef?: string
  /**
   * What the source connected *as* — the email connector's OAuth client id.
   *
   * An identifier, never a secret: it is shown on the Sources row, which is the point. The secret half
   * of the pair travels as \`credentialRef\`, a pointer, because the wizard promises the raw one is
   * never persisted.
   */
  account?: string
  /**
   * What this source has in scope, in the connector's own noun — a database, a schema.
   *
   * Sent so the Sources row can state it where BigQuery's states a dataset count. Absent for a
   * connector that narrows nothing, and the row then prints an em dash rather than a zero: `0` would
   * say the source reaches nothing, where the truth is that scope is not what this connector has.
   */
  scope?: string
}): Promise<RegisteredGenericSource> {
  return validate<RegisteredGenericSource>(
    'The registered source',
    await request<unknown>('/sources/generic', {
      method: 'POST',
      body: {
        connector: input.connector,
        source_name: input.sourceName,
        type_label: input.typeLabel,
        credential_ref: input.credentialRef ?? null,
        account: input.account ?? null,
        scope: input.scope ?? null,
      },
    }),
    REGISTERED_GENERIC_PAYLOAD,
  )
}

export async function listSources(): Promise<{
  sources: SourceRow[]
  registeredCount: number
  connectedSources: number
  profiledTables: number
  profiledColumns: number
  profiledDocuments: number
  profiledEntities: number
  profiledToday: number
  profiledTodayDate: string
  /* No chunk figures here: they are one mailbox's, and a sum across every source would be a
     tenant-wide chunk count nothing on screen asks for. They ride on the source row instead. */
}> {
  const payload = await request<unknown>('/sources')

  /*
   * A mock server started before the row shape changed still answers, but with
   * the old fields — which renders as blank ids, "Invalid Date" and "undefined
   * table(s)". Catch that specific case first so the message names the fix,
   * rather than letting the schema report a wall of field mismatches.
   */
  const rows = (payload as { sources?: unknown[] })?.sources
  if (Array.isArray(rows) && rows.some((s) => typeof (s as RawSourceRow).source_id !== 'string')) {
    throw new ApiError(
      'The JSON server is running an older version of this API (rows have no ' +
        'source_id). Restart it: stop `npm run mock` and start it again.',
      0,
    )
  }

  const raw = validate<{
    sources: RawSourceRow[]
    registered_count: number
    connected_sources: number
    profiled_tables: number
    profiled_columns: number
    profiled_documents: number
    profiled_entities: number
    profiled_today: number
    profiled_today_date: string
  documents_chunked: number | null
  chunks_total: number | null
  chunk_chars: number | null
  }>('The sources list', payload, SOURCES_PAYLOAD)

  return {
    sources: raw.sources.map((s) => ({
      sourceId: s.source_id,
      sourceName: s.source_name,
      connector: s.connector,
      status: s.status,
      projectAccount: s.project_account,
      scope: s.scope,
      connectedAt: s.connected_at,
      profiledTables: s.profiled_tables,
      profiledColumns: s.profiled_columns,
      profiledDocuments: s.profiled_documents,
      profiledEntities: s.profiled_entities,
      profiledToday: s.profiled_today,
      profiledTodayDate: s.profiled_today_date,
      documentsChunked: s.documents_chunked,
      chunksTotal: s.chunks_total,
      chunkChars: s.chunk_chars,
      lastChunkAt: s.last_chunk_at,
      lastChunkCount: s.last_chunk_count,
      lastChunkSince: s.last_chunk_since,
      datasets: s.datasets,
      folders: s.folders,
      labels: s.labels,
      kind: s.kind,
      profilable: s.profilable,
    })),
    registeredCount: raw.registered_count,
    connectedSources: raw.connected_sources,
    profiledTables: raw.profiled_tables,
    profiledColumns: raw.profiled_columns,
    profiledDocuments: raw.profiled_documents,
    profiledEntities: raw.profiled_entities,
    profiledToday: raw.profiled_today,
    profiledTodayDate: raw.profiled_today_date,
  }
}

/** All three answer with the changed row, so all three check its shape. */
export async function disconnectSource(sourceId: string): Promise<RawSourceRow> {
  return validate<RawSourceRow>(
    'The disconnected source',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/disconnect`, {
      method: 'POST',
    }),
    SOURCE_ROW,
  )
}

/**
 * The undo for `disconnectSource`. Re-issues the credential handle and flips the status back,
 * keeping the allowlist and every profiled object — which is what makes Disconnect safe to
 * offer as reversible. Re-registering through the wizard is *not* this: it builds a fresh
 * record and the profiled objects go with the old one.
 */
export async function reconnectSource(sourceId: string): Promise<RawSourceRow> {
  return validate<RawSourceRow>(
    'The reconnected source',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/reconnect`, {
      method: 'POST',
    }),
    SOURCE_ROW,
  )
}

/** What a source delete gave back — see `releaseDeclarations` in the server. */
export interface ReleasedDeclarations {
  entities: number
  relationships: number
}

export async function deleteSource(
  sourceId: string,
): Promise<{ deleted: string; released: ReleasedDeclarations }> {
  return validate<{ deleted: string; released: ReleasedDeclarations }>(
    'The deleted source',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}`, {
      method: 'DELETE',
    }),
    SOURCE_DELETED_PAYLOAD,
  )
}

export async function updateSourceDatasets(
  sourceId: string,
  datasets: string[],
): Promise<RawSourceRow> {
  return validate<RawSourceRow>(
    'The updated allowlist',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/datasets`, {
      method: 'PUT',
      body: { datasets },
    }),
    SOURCE_ROW,
  )
}

export async function updateSourceFolders(
  sourceId: string,
  folders: string[],
): Promise<RawSourceRow> {
  return validate<RawSourceRow>(
    'The updated folder allowlist',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/folders`, {
      method: 'PUT',
      body: { folders },
    }),
    SOURCE_ROW,
  )
}

export async function listProjectDatasets(
  projectId: string,
): Promise<{ project_id: string; datasets: { dataset_id: string }[] }> {
  return validate<{ project_id: string; datasets: { dataset_id: string }[] }>(
    'The dataset list',
    await request<unknown>(`/projects/${encodeURIComponent(projectId)}/datasets`),
    PROJECT_DATASETS_PAYLOAD,
  )
}

export async function listDriveFolders(driveId: string): Promise<{
  drive_id: string
  folders: {
    folder_id: string
    parent_id: string | null
    name: string
    path: string
    document_count: number
  }[]
}> {
  const raw = await request<unknown>(`/drives/${encodeURIComponent(driveId)}/folders`)
  return validate('The folder list', raw, DRIVE_FOLDERS_PAYLOAD)
}

export async function browseSource(sourceId: string): Promise<BrowseResult> {
  const raw = await request<unknown>(
    `/sources/${encodeURIComponent(sourceId)}/browse`,
  )
  return validate<BrowseResult>("The browsable objects", raw, BROWSE_PAYLOAD)
}

/*
 * A queued job goes straight into the jobs board and is then polled, so a
 * malformed one would render as a row of `undefined` that never resolves.
 */
export async function profileTables(
  sourceId: string,
  objects: { dataset_id: string; table_id: string }[],
  force: boolean,
): Promise<{ job: ProfilingJob }> {
  return validate<{ job: ProfilingJob }>(
    'The queued profiling job',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/profile`, {
      method: 'POST',
      body: { objects, force },
    }),
    JOB_STARTED_PAYLOAD,
  )
}

export async function browseDocuments(
  sourceId: string,
): Promise<DocumentBrowseResult> {
  const raw = await request<unknown>(
    `/sources/${encodeURIComponent(sourceId)}/browse-documents`,
  )
  return validate<DocumentBrowseResult>(
    'The browsable documents',
    raw,
    DOCUMENT_BROWSE_PAYLOAD,
  )
}

/** Drive's twin of `profileTables`, checked against the same job shape. */
/**
 * Queues a run over a drive's documents.
 *
 * **`objects` is optional, and leaving it out runs the whole drive** — the rule
 * `profileMailDocuments` already keeps. An empty array is deliberately not how that is said: the
 * server refuses one, because "profile nothing" and "profile everything" are opposite requests.
 * The key is omitted rather than sent as `undefined` so the body carries no ambiguous field.
 */
export async function profileDocuments(
  sourceId: string,
  objects: { folder_id: string; document_id: string }[] | undefined,
  force: boolean,
): Promise<{ job: ProfilingJob }> {
  return validate<{ job: ProfilingJob }>(
    'The queued profiling job',
    await request<unknown>(
      `/sources/${encodeURIComponent(sourceId)}/profile-documents`,
      { method: 'POST', body: objects === undefined ? { force } : { objects, force } },
    ),
    JOB_STARTED_PAYLOAD,
  )
}

export async function getProfiledDocuments(
  sourceId: string,
): Promise<ProfiledDocumentsPayload> {
  const raw = await request<unknown>(
    `/sources/${encodeURIComponent(sourceId)}/documents`,
  )
  return validate<ProfiledDocumentsPayload>(
    'The document dictionary',
    raw,
    DOCUMENTS_PAYLOAD,
  )
}

export async function setDocumentSummary(
  sourceId: string,
  input: { folder_id: string; document_id: string; summary: string },
): Promise<{ key: string; summary: string | null }> {
  return validate<{ key: string; summary: string | null }>(
    'The saved summary',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/documents`, {
      method: 'PATCH',
      body: input,
    }),
    DOCUMENT_SUMMARY_PAYLOAD,
  )
}

/* ---------------- Catalog: mail documents ----------------
 *
 * Mail's twins of the four above. Each endpoint refuses the other connectors' sources with a
 * 400 naming the one that serves them, so a mistaken call says which door to use rather than
 * answering with an empty tree that reads as "nothing to profile".
 *
 * The paths say `mail-documents` rather than `documents` because both connectors hold
 * documents and the payloads are different shapes — a drive's is folder → document, a
 * mailbox's is label → message → document, and one route serving both would be a union every
 * consumer had to narrow.
 */

export async function browseMailDocuments(
  sourceId: string,
): Promise<MailDocumentBrowseResult> {
  const raw = await request<unknown>(
    `/sources/${encodeURIComponent(sourceId)}/browse-mail-documents`,
  )
  return validate<MailDocumentBrowseResult>(
    'The browsable mail documents',
    raw,
    MAIL_BROWSE_PAYLOAD,
  )
}

/**
 * Mail's twin of `profileDocuments`, checked against the same job shape.
 *
 * **`objects` is omitted, and omitting it is what says "the whole mailbox".** Gmail's act is one
 * *Process documents* button, so there is nothing for a reader to pick and nothing for this to
 * send. An empty array would not do instead: the route would then have no way to tell "profile
 * nothing" from "profile everything", and the two are opposite requests.
 */
export async function profileMailDocuments(
  sourceId: string,
  force: boolean,
): Promise<{ job: ProfilingJob }> {
  return validate<{ job: ProfilingJob }>(
    'The queued profiling job',
    await request<unknown>(
      `/sources/${encodeURIComponent(sourceId)}/profile-mail-documents`,
      { method: 'POST', body: { force } },
    ),
    JOB_STARTED_PAYLOAD,
  )
}

const MAIL_RUN_PAYLOAD = shape({ source_id: str, job: nullable(JOB) })

/**
 * The newest mail run for one source — what *Process documents* watches.
 *
 * **Its own read rather than a row on the jobs board**, which deliberately excludes `gmail`: a mail
 * run is narrated on the Catalog surface that started it, and a row on the board as well would be
 * two places to watch one run. `job` is `null` where nothing has been run, because a reader who has
 * not pressed the button is not watching anything.
 */
export async function getMailRun(sourceId: string): Promise<ProfilingJob | null> {
  const raw = validate<{ source_id: string; job: ProfilingJob | null }>(
    'The mail run',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/mail-run`),
    MAIL_RUN_PAYLOAD,
  )
  return raw.job
}

export async function getProfiledMailDocuments(
  sourceId: string,
): Promise<ProfiledMailDocumentsPayload> {
  const raw = await request<unknown>(
    `/sources/${encodeURIComponent(sourceId)}/mail-documents`,
  )
  return validate<ProfiledMailDocumentsPayload>(
    'The mail document dictionary',
    raw,
    MAIL_DOCUMENTS_PAYLOAD,
  )
}

export async function setMailDocumentSummary(
  sourceId: string,
  input: { label_id: string; document_id: string; summary: string },
): Promise<{ key: string; summary: string | null }> {
  return validate<{ key: string; summary: string | null }>(
    'The saved summary',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/mail-documents`, {
      method: 'PATCH',
      body: input,
    }),
    DOCUMENT_SUMMARY_PAYLOAD,
  )
}

export async function getProfiledColumns(
  sourceId: string,
): Promise<ProfiledColumnsPayload> {
  const raw = await request<unknown>(
    `/sources/${encodeURIComponent(sourceId)}/columns`,
  )
  return validate<ProfiledColumnsPayload>("The column dictionary", raw, COLUMNS_PAYLOAD)
}

export async function setColumnDescription(
  sourceId: string,
  input: {
    dataset_id: string
    table_id: string
    column_id: string
    description: string
  },
): Promise<{ key: string; description: string | null }> {
  return validate<{ key: string; description: string | null }>(
    'The saved description',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/columns`, {
      method: 'PATCH',
      body: input,
    }),
    COLUMN_DESCRIPTION_PAYLOAD,
  )
}


/* ---------------- Data Modeling ----------------
 *
 * The Catalog's third act, over `db.data_model`. Browse says what a source holds and the dictionary
 * describes it column by column; this is where a curator says what a table *is*.
 *
 * A declaration is keyed by **`table_key`** — `"<dataset>.<table>"`, the key `column_profiles` uses
 * — rather than by a source id, because a registration lives in the mock server's memory and an
 * entity naming one would dangle at the next restart. A table is a fact of the document.
 */

/** One declared attribute. At most one carries `is_identifier` — the server refuses two. */
export interface ModelAttribute {
  name: string
  /** The profiler's type where the declarer had one to record, `null` otherwise. */
  type: string | null
  is_identifier: boolean
}

/**
 * One declared relationship, stored on the entity anchored to the **from** side.
 *
 * `from_columns`/`to_columns` are arrays because a real join can be composite; this tab's editor is
 * single-column, so it writes one and the panel *says* when it is reading the first pair of a
 * composite one rather than quietly rendering half a join.
 */
export interface ModelRelationshipItem {
  target_table_key: string
  from_columns: string[]
  to_columns: string[]
  relationship_type: string
  /** `1:1` | `1:N` | `N:1` | `N:N` — advisory, and a closed set the server checks. */
  cardinality_hint: string
  rationale: string
  /**
   * Who accepted this declaration, or `null` — and **being stored is not being confirmed**.
   *
   * Every stored declaration used to render as *Confirmed by you*, because the tab took
   * `provenance: 'human'` from the mere fact of being stored. That is a claim about the reader and
   * it was false for all 31 across the two documents: written in some earlier session, or by a
   * script, with no record of which. Reported from use, as twelve relationships credited to
   * somebody who had accepted none of them.
   *
   * Absent on every one written before the field existed, which is why it is nullable rather than
   * required: `null` is the honest answer to "who accepted this", and the label says *Curated by
   * AI* instead of naming a person.
   */
  confirmed_by?: string | null
}

/**
 * A column stored on one table whose *meaning* belongs to this entity.
 *
 * The whole point of the capability: `receiver_operating_tsdf` sits on the manifest and describes
 * the facility. Declared here, and stated on the physical table's own column list too — a note
 * rather than a hidden row, so nobody wonders where a column went.
 */
export interface ModelCrossAttribute {
  attribute_id: string
  source_table_key: string
  source_column: string
  description: string
}

export interface ModelEntity {
  entity_id: string
  /** `"<dataset>.<table>"`. One entity per table — the server refuses a second. */
  table_key: string
  entity_name: string
  description: string
  /**
   * Who declared this table, or `null` — the twin of the field on a relationship.
   *
   * An entity can exist without anybody having declared anything: the client mints an **anchor**
   * whenever a relationship points at an undeclared table, and its own description says so in as
   * many words. So the Entity detail header's pill is read off this rather than off the entity's
   * mere existence, which used to print *Declared* over all 14 of CAPEX's anchors. Only Save
   * Overview sends a name.
   */
  confirmed_by: string | null
  business_purpose: string | null
  grain_description: string | null
  attributes: ModelAttribute[]
  relationships: ModelRelationshipItem[]
  cross_attributes: ModelCrossAttribute[]
  updated_at: string
}

export interface DataModelPayload {
  entities: ModelEntity[]
  count: number
}

/**
 * What a save sends. Every field is optional beyond the first two because the write is an
 * **upsert that carries absent fields forward**: the Overview panel sends the text fields and the
 * identifier, the relationship editor sends `relationships`, and neither may erase the other's work.
 */
export interface ModelEntityInput {
  entity_id?: string
  /** Sent by Save Overview alone. Omitted, the server carries the stored answer forward. */
  confirmed_by?: string | null
  table_key?: string
  entity_name?: string
  description?: string
  business_purpose?: string | null
  grain_description?: string | null
  attributes?: ModelAttribute[]
  relationships?: ModelRelationshipItem[]
  cross_attributes?: (Omit<ModelCrossAttribute, 'attribute_id'> & {
    attribute_id?: string
  })[]
}

/** One table's suggested Overview, composed from that table's own catalogue row. */
export interface ModelTableSuggestion {
  table_key: string
  table_id: string
  suggested_description: string | null
  /**
   * Always `null` today, and the field is here rather than absent because the panel has a slot for
   * it: nothing in the document states what a table is *for*, so a sentence here would be words in
   * the tenant's mouth.
   */
  suggested_business_purpose: string | null
  suggested_grain_description: string | null
}

/** One suggested relationship, from a column two tables share and at least one calls an identifier. */
export interface ModelRelationshipSuggestion {
  from_table_key: string
  from_column: string
  to_table_key: string
  to_column: string
  relationship_type: string
  relationship_type_alternatives: string[]
  /**
   * `1:1` | `1:N` | `N:1` | `N:N`, or **`null` where it could not be derived**.
   *
   * The cardinality comes from whether each side's distinct count reaches its row count, and a
   * column *declared* in an uploaded data dictionary has no distinct count — a dictionary states
   * what a column means and samples nothing. `N:N` in that case would not be the cautious answer,
   * it would be a claim that both sides repeat, so the run says it has none and the reviewer sets
   * it on confirm.
   */
  cardinality_hint: string | null
  rationale: string
  /**
   * How sure the suggestion is — and **the two kinds mean different things by it**, which is why
   * `evidence_kind` is what tells them apart rather than the number.
   *
   * A *derived* suggestion's is the classifier's own confidence in the weaker of the two columns it
   * matched on. A *recorded* one's is a stated opinion, written down beside the suggestion.
   *
   * **`null` where a declared column is one of the two**: a classifier never scored it, and
   * `Math.min` over an absent score is `0.00`, which reads as a measurement rather than its absence.
   */
  confidence: number | null
  /**
   * What the suggestion stands on: `recorded` or `structural`.
   *
   * **Never `llm`, and that is deliberate.** A recorded suggestion has an AI suggester's *shape* — a
   * relationship name, the alternatives somebody weighed, a paragraph of reasoning, a confidence —
   * and its *provenance* is that it was written into this dataset's document. Printing "model
   * reasoning" over it would be the one untrue thing on the page, which is why `degraded` stays true
   * whichever kind a reader is looking at.
   */
  evidence_kind: string
}

export interface ModelSuggestionsPayload {
  source_id: string
  tables: ModelTableSuggestion[]
  relationships: ModelRelationshipSuggestion[]
  /**
   * Whether a model ran. Always false-in-spirit: no model runs here, either way.
   *
   * Not a placeholder, and not the same question as "is this any good" — a **recorded** suggestion
   * carries a real relationship name, the alternatives somebody weighed and a paragraph of
   * reasoning, none of which a column scan produces, and it was still written down rather than
   * generated. The two counts below are what let the tab say which kind it served instead of
   * implying one.
   */
  degraded: boolean
  /** Written into this dataset's document, and served ahead of a derived row for the same pair. */
  recorded_count: number
  /** Found by matching a shared identifier column, for every pair nothing has written down. */
  derived_count: number
  /**
   * Whether the **list** was cut — never the tables.
   *
   * This meant "only some tables were scanned", which made an unjoined table a claim about the cap
   * rather than about the schema: an 18-table source reported 12 joined and 6 apparently unrelated,
   * when all 18 share an identifier with another. Every profiled table is scanned now
   * (`tables_considered` is all of them) and the returned list is what a run cuts, since that is
   * what a reviewer has to read.
   */
  truncated: boolean
  tables_considered: number
  /** How many the scan found, before the list was cut. */
  relationships_total: number
  /**
   * The profiled tables **no** suggestion reaches, by `table_key`.
   *
   * Named rather than counted, because a count with no names leaves a reader working out whether
   * theirs is in it. It is computed over the whole scan and before the list is cut, so it is a fact
   * about the schema — a lookup nobody keyed, or a dictionary that has not named its identifier —
   * and never about a limit. Stored declarations are the client's to subtract: it holds those.
   */
  orphan_tables: string[]
}

const MODEL_ENTITY = shape({
  entity_id: str,
  table_key: str,
  entity_name: str,
  description: str,
  confirmed_by: nullable(str),
  business_purpose: nullable(str),
  grain_description: nullable(str),
  attributes: arrayOf(
    shape({ name: str, type: nullable(str), is_identifier: bool }),
  ),
  relationships: arrayOf(
    shape({
      target_table_key: str,
      from_columns: arrayOf(str),
      to_columns: arrayOf(str),
      relationship_type: str,
      cardinality_hint: str,
      rationale: str,
      /* Nullable, and absent on every declaration written before it existed — `nullable()` accepts
         a missing key as well as `null`, which is exactly the case here. */
      confirmed_by: nullable(str),
    }),
  ),
  cross_attributes: arrayOf(
    shape({
      attribute_id: str,
      source_table_key: str,
      source_column: str,
      description: str,
    }),
  ),
  updated_at: str,
})

const DATA_MODEL_PAYLOAD = shape({
  entities: arrayOf(MODEL_ENTITY),
  count: num,
})

const MODEL_SAVED_PAYLOAD = shape({ saved: bool, entity: MODEL_ENTITY })

const MODEL_SUGGESTIONS_PAYLOAD = shape({
  source_id: str,
  tables: arrayOf(
    shape({
      table_key: str,
      table_id: str,
      suggested_description: nullable(str),
      suggested_business_purpose: nullable(str),
      suggested_grain_description: nullable(str),
    }),
  ),
  relationships: arrayOf(
    shape({
      from_table_key: str,
      from_column: str,
      to_table_key: str,
      to_column: str,
      relationship_type: str,
      relationship_type_alternatives: arrayOf(str),
      cardinality_hint: nullable(str),
      rationale: str,
      confidence: nullable(num),
      evidence_kind: str,
    }),
  ),
  degraded: bool,
  recorded_count: num,
  derived_count: num,
  truncated: bool,
  tables_considered: num,
  relationships_total: num,
  orphan_tables: arrayOf(str),
})

/** Every declaration in this dataset. One read — the relationships ride on their entities. */
export async function listDataModel(): Promise<DataModelPayload> {
  return validate<DataModelPayload>(
    'The data model',
    await request<unknown>('/data-model/entities'),
    DATA_MODEL_PAYLOAD,
  )
}

/**
 * Creates or updates one declaration, and answers with the stored record.
 *
 * The reply is validated like a read, because it is rendered like one: a stale server answers a
 * write with the old shape as readily as a read.
 */
export async function saveDataModelEntity(
  input: ModelEntityInput,
): Promise<{ saved: boolean; entity: ModelEntity }> {
  return validate<{ saved: boolean; entity: ModelEntity }>(
    'The saved declaration',
    await request<unknown>('/data-model/entities', { method: 'POST', body: input }),
    MODEL_SAVED_PAYLOAD,
  )
}

/** What a bulk accept did, counted by the server over the rows it actually wrote. */
export interface AcceptedRelationships {
  /** How many undecided rows this run credited. */
  accepted: number
  /** How many in scope already carried somebody's name and were left alone. */
  already: number
  /** Every stored relation in scope, whoever accepted it. */
  total: number
  accepted_by: string
}

/**
 * Accepts every undecided stored relation in one request — the relations dialog's *Accept all*.
 *
 * **One call rather than one per row**, which is what it replaced: 59 requests for one decision, and
 * a refusal partway through leaving half the list accepted. The server resolves the whole scope
 * before writing and lands it in a single commit, so this is all of them or none.
 *
 * `tableKeys` is the source's own tables, so what gets accepted is exactly what the dialog listed —
 * both ends of a relationship have to be in scope, as they do for the list itself. `as` is the
 * browser's address, because the identity is client-held and a route cannot look up who is signed
 * in. The count comes back **from the server**, so the sentence the tab prints is what landed rather
 * than what was submitted.
 */
export async function acceptAllRelationships(args: {
  tableKeys: string[]
  as: string
}): Promise<AcceptedRelationships> {
  return validate<AcceptedRelationships>(
    'The accepted relations',
    await request<unknown>(
      `/data-model/relationships/accept?as=${encodeURIComponent(args.as)}`,
      { method: 'POST', body: { table_keys: args.tableKeys } },
    ),
    shape({ accepted: num, already: num, total: num, accepted_by: str }),
  )
}

/** Drops a whole declaration — its Overview, its identifier and its relationships. */
export async function deleteDataModelEntity(
  entityId: string,
): Promise<{ deleted: string }> {
  return validate<{ deleted: string }>(
    'The deleted declaration',
    await request<unknown>(`/data-model/entities/${encodeURIComponent(entityId)}`, {
      method: 'DELETE',
    }),
    shape({ deleted: str }),
  )
}

/** The suggestions run behind the tab's own button. Paced on the server, like every suggester here. */
export async function suggestDataModel(
  sourceId: string,
): Promise<ModelSuggestionsPayload> {
  return validate<ModelSuggestionsPayload>(
    'The schema suggestions',
    await request<unknown>('/data-model/suggestions', {
      method: 'POST',
      body: { source_id: sourceId },
    }),
    MODEL_SUGGESTIONS_PAYLOAD,
  )
}

/* ---------------- Uploading a schema or data dictionary ----------------
 *
 * Two acts over one file: a preview that writes nothing, then an apply that commits the dictionary
 * and queues a forced profiling run over the tables it touched.
 *
 * **The file travels as text in a JSON body**, read in the browser with `File.text()`. The server is
 * zero-dependency and a multipart parser for a text file would be a dependency's worth of code for
 * no gain — and it means the body is subject to the same 1 MB cap every other request has, which
 * `schemaUploadProblem` checks against *before* sending so an oversized file is a sentence rather
 * than a dropped connection.
 */

/** What one table in an upload would do to the dictionary. */
export interface SchemaPlanTable {
  table_id: string
  /** False for a table the upload *declares* — those must carry a label and a grain. */
  exists: boolean
  /** Whether a run has already profiled it, so the panel can say it will be re-profiled. */
  profiled: boolean
  label: string
  grain: string
  column_count: number
  /** How many the dictionary held before. 0 for a table whose columns were synthesised. */
  previous_column_count: number
  /**
   * How many columns the Catalog says this table has **now** — the number on screen.
   *
   * Not the same question as `previous_column_count`, and running the flow is what showed why: a
   * table catalogued with 24 columns and no dictionary reported `0 → 3` for a 3-column file, while
   * the figure a reader was looking at went 24 → 3. Applying replaces the count with the file's, so
   * this is what the preview puts before the arrow.
   */
  catalogued_column_count: number
  added: string[]
  /**
   * Columns the dictionary holds now and this file does not name.
   *
   * An upload **replaces** a table's dictionary rather than merging into it — a merge cannot remove
   * a column that is no longer there — so these are listed by name in the preview. Nothing about an
   * upload is silent about what it drops.
   */
  dropped: string[]
  /** Dropped columns that carry a curator's note, which stops applying with them. */
  orphaned_notes: string[]
  /**
   * Data Modeling declarations left reading a column this upload would drop.
   *
   * Worse than an orphaned note, which is why it is its own field: a declared join on a column the
   * dictionary no longer carries is a state `POST /data-model/entities` *refuses* to write, so it
   * would be found only by somebody trying to edit that relationship. Named in the preview, while
   * dropping the column is still a choice.
   */
  stranded_declarations: string[]
}

export interface SchemaPlan {
  filename: string
  /** `json` | `csv` | `tsv` | `sql` — what the reader made of the file. */
  format: string
  dataset_id: string
  table_count: number
  column_count: number
  new_table_count: number
  tables: SchemaPlanTable[]
}

export interface SchemaPreviewPayload extends SchemaPlan {
  source_id: string
}

export interface SchemaAppliedPayload {
  source_id: string
  /** One plan per dictionary written, in the order they were sent. */
  applied: SchemaPlan[]
  /**
   * **The one run this queued** — the dictionaries' tables *and* whatever else the reader had
   * checked, in a single job.
   *
   * It used to be a job over the dictionary's tables alone, with the client starting a second run
   * for the rest of the selection: one press of Start Profiling, two pipelines on the board, and
   * nothing saying which was which or when profiling had finished.
   */
  job: ProfilingJob
}

const SCHEMA_PLAN_FIELDS = {
  filename: str,
  format: str,
  dataset_id: str,
  table_count: num,
  column_count: num,
  new_table_count: num,
  tables: arrayOf(
    shape({
      table_id: str,
      exists: bool,
      profiled: bool,
      label: str,
      grain: str,
      column_count: num,
      previous_column_count: num,
      catalogued_column_count: num,
      added: arrayOf(str),
      dropped: arrayOf(str),
      orphaned_notes: arrayOf(str),
      stranded_declarations: arrayOf(str),
    }),
  ),
}

const SCHEMA_PREVIEW_PAYLOAD = shape({ source_id: str, ...SCHEMA_PLAN_FIELDS })

const SCHEMA_APPLIED_PAYLOAD = shape({
  source_id: str,
  applied: arrayOf(shape(SCHEMA_PLAN_FIELDS)),
  job: JOB,
})

/** Reads the file and reports what it would do. Writes nothing. */
export async function previewSchemaUpload(
  sourceId: string,
  input: { filename: string; dataset_id: string },
): Promise<SchemaPreviewPayload> {
  return validate<SchemaPreviewPayload>(
    'The schema preview',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/schema/preview`, {
      method: 'POST',
      body: input,
    }),
    SCHEMA_PREVIEW_PAYLOAD,
  )
}

/**
 * Commits every dictionary and queues **one** run, in one call.
 *
 * One act, because the halves are one: a dictionary that landed with no run behind it is a Catalog
 * advertising columns nothing has profiled, and splitting them would put the decision in the one
 * place that cannot see whether the first half succeeded.
 *
 * **`objects` is the rest of the reader's selection**, and it travels with the write for the same
 * reason. Without it this returned a job over the dictionary's tables and the caller started a
 * second one for everything else checked — two pipelines from one press, over one dataset, with
 * nothing on the board saying which was which.
 *
 * **`dictionaries` is an array** because a source with three datasets can have one read against
 * each, and a call per dataset would put the job count back where it started. They are resolved
 * before anything is written and land in one commit, so a refusal on the third file leaves the first
 * two unwritten.
 */
export async function applySchemaUpload(
  sourceId: string,
  input: {
    dictionaries: { filename: string; dataset_id: string }[]
    /** The checked tables. Ones a dictionary already covers are not queued twice. */
    objects: { dataset_id: string; table_id: string }[]
    /** Whether an already-profiled table outside the dictionaries should run again. */
    force: boolean
  },
): Promise<SchemaAppliedPayload> {
  return validate<SchemaAppliedPayload>(
    'The applied schema',
    await request<unknown>(`/sources/${encodeURIComponent(sourceId)}/schema`, {
      method: 'POST',
      body: input,
    }),
    SCHEMA_APPLIED_PAYLOAD,
  )
}
export async function cancelProfilingJob(jobId: string): Promise<ProfilingJob> {
  return validate<ProfilingJob>(
    'The cancelled job',
    await request<unknown>(`/profiling-jobs/${encodeURIComponent(jobId)}/cancel`, {
      method: 'POST',
    }),
    JOB,
  )
}

export async function listProfilingJobs(): Promise<ProfilingJobsPayload> {
  const raw = await request<unknown>('/profiling-jobs')
  return validate<ProfilingJobsPayload>("The profiling jobs", raw, JOBS_PAYLOAD)
}

export async function listChangeSignals(): Promise<{
  signals: ChangeSignal[]
  count: number
  connected_sources: number
}> {
  const raw = await request<unknown>('/change-signals')
  return validate("The change signals", raw, SIGNALS_PAYLOAD)
}

/* ---------------- New Graph wizard ---------------- */

interface RawGraphDomain {
  domain_id: string
  name: string
  expected_sources: string[]
  fit: DomainFit
  note: string
  rank: number
  drafts: { personas: number; metrics: number; hero_questions: number }
}

interface RawUseCase {
  use_case_id: string
  name: string
  status: 'draft' | 'committed'
  domain_id: string | null
  business_need: string
  personas: Persona[]
  metrics: Metric[]
  sources: { source_id: string; mode: 'all' | 'subset'; objects: string[] }[]
  hero_questions: HeroQuestion[]
  gap_decisions: { element_id: string; decision: GapDecision }[]
  step: number
  step_total: number
  updated_at: string | null
}

/** The fields steps 2–6 added. A server older than them answers with none. */
const USE_CASE_STEP_FIELDS = [
  'personas',
  'kpis',
  'sources',
  'hero_questions',
  'gap_decisions',
] as const

/*
 * A use case carrying none of the step 2–6 fields is not a malformed payload —
 * it is a mock server that started before those fields existed and is still
 * answering with the old shape. Five "should be an array, got undefined" lines
 * describe the symptom and send you reading the schema; this names the cause and
 * the one-line fix. The check has to live here because a stale server cannot
 * warn about itself.
 */
function assertCurrentUseCaseShape(raw: unknown) {
  if (raw === null || typeof raw !== 'object') return
  const u = raw as Record<string, unknown>
  // Only judge something that really is a use case, and only when *every* newer
  // field is absent — one missing field is a genuine bug worth the field names.
  if (typeof u.use_case_id !== 'string') return
  if (!USE_CASE_STEP_FIELDS.every((field) => u[field] === undefined)) return

  throw new Error(
    'The mock server is running an older version of this app, so a saved use ' +
      'case came back without its personas, metrics, sources, questions or gap ' +
      'decisions. Restart it with npm run mock and try again — nothing you ' +
      'entered has been lost.',
  )
}

const toUseCase = (u: RawUseCase): GraphUseCase => ({
  useCaseId: u.use_case_id,
  name: u.name,
  status: u.status,
  domainId: u.domain_id,
  businessNeed: u.business_need,
  personas: u.personas,
  metrics: u.metrics,
  sources: u.sources.map((s) => ({
    sourceId: s.source_id,
    mode: s.mode,
    objects: s.objects,
  })),
  heroQuestions: u.hero_questions,
  gapDecisions: u.gap_decisions.map((d) => ({
    elementId: d.element_id,
    decision: d.decision,
  })),
  step: u.step,
  stepTotal: u.step_total,
  updatedAt: u.updated_at,
  role: (u as unknown as { role?: RoleDetails | null }).role ?? null,
})

export async function listGraphDomains(): Promise<GraphDomainsPayload> {
  const raw = validate<{
    domains: RawGraphDomain[]
    domain_count: number
    connected_sources: number
    profiled_objects: number
  }>('The business domains', await request<unknown>('/graph-domains'), GRAPH_DOMAINS_PAYLOAD)

  return {
    domains: raw.domains.map((d) => ({
      domainId: d.domain_id,
      name: d.name,
      expectedSources: d.expected_sources,
      fit: d.fit,
      note: d.note,
      rank: d.rank,
      drafts: {
        personas: d.drafts.personas,
        metrics: d.drafts.metrics,
        heroQuestions: d.drafts.hero_questions,
      },
    })),
    domainCount: raw.domain_count,
    connectedSources: raw.connected_sources,
    profiledObjects: raw.profiled_objects,
  }
}

export async function listUseCases(): Promise<UseCasesPayload> {
  const payload = await request<unknown>('/graph-use-cases')
  // Before the field-by-field check, so a stale server is named as such.
  const first = (payload as { use_cases?: unknown[] } | null)?.use_cases?.[0]
  assertCurrentUseCaseShape(first)

  const raw = validate<{
    use_cases: RawUseCase[]
    count: number
    draft_count: number
    committed_count: number
    steps: string[]
  }>('The saved use cases', payload, USE_CASES_PAYLOAD)

  return {
    useCases: raw.use_cases.map(toUseCase),
    count: raw.count,
    draftCount: raw.draft_count,
    committedCount: raw.committed_count,
    steps: raw.steps,
  }
}

/** Steps 2 and 3 answer the same shape, so one fetcher serves both. */
async function fetchSuggestions(
  path: string,
  what: string,
  input: { domainId: string | null; businessNeed: string; personas?: string[] },
): Promise<Suggestions> {
  const raw = validate<{
    suggestions: Suggestion[]
    count: number
    derived_from: string
    empty_reason: string | null
    run: { stages: string[]; cost_usd: number; cost_cap_usd: number }
  }>(
    what,
    await request<unknown>(path, {
      method: 'POST',
      body: { domain_id: input.domainId, business_need: input.businessNeed, personas: input.personas ?? [] },
    }),
    SUGGESTIONS_PAYLOAD,
  )

  return {
    suggestions: raw.suggestions,
    count: raw.count,
    derivedFrom: raw.derived_from,
    /* `?? null` for an older mock server that predates the field, never a sentence invented here:
       the step then falls back to its own wording rather than printing a reason nobody computed. */
    emptyReason: raw.empty_reason ?? null,
    run: {
      stages: raw.run.stages,
      costUsd: raw.run.cost_usd,
      costCapUsd: raw.run.cost_cap_usd,
    },
  }
}

export const suggestPersonas = (input: {
  domainId: string | null
  businessNeed: string
  personas?: string[]
}) =>
  fetchSuggestions('/graph-personas/suggest', 'The persona suggestions', input)

export async function listGraphSources(): Promise<GraphSourcesPayload> {
  const raw = validate<{
    sources: {
      source_id: string
      source_name: string
      connector: string
      kind: string
      status: string
      type_label: string
      account: string
      scope_label: string
      scope: string[]
      object_count: number
      unit_label: string
      runtime: boolean
      objects: {
        object_id: string
        parent_id: string
        label: string
        /* Null where nothing has counted the object — a Gmail label has no message count. */
        units: number | null
        unit_label: string
        pages: number | null
        size_chars: number | null
        snippet: string | null
      }[]
    }[]
    source_count: number
    profiled_source_count: number
    runtime_source_count: number
  }>(
    'The available sources',
    await request<unknown>('/graph-sources'),
    GRAPH_SOURCES_PAYLOAD,
  )

  return {
    sources: raw.sources.map((s) => ({
      sourceId: s.source_id,
      sourceName: s.source_name,
      connector: s.connector,
      kind: s.kind,
      status: s.status,
      typeLabel: s.type_label,
      account: s.account,
      scopeLabel: s.scope_label,
      scope: s.scope,
      objectCount: s.object_count,
      unitLabel: s.unit_label,
      runtime: s.runtime,
      objects: s.objects.map((o) => ({
        objectId: o.object_id,
        parentId: o.parent_id,
        label: o.label,
        /* Carried through as null, never `?? 0`: nothing counted it, and 0 is a count. */
        units: o.units,
        unitLabel: o.unit_label,
        pages: o.pages,
        sizeChars: o.size_chars,
        snippet: o.snippet,
      })),
    })),
    sourceCount: raw.source_count,
    profiledSourceCount: raw.profiled_source_count,
    runtimeSourceCount: raw.runtime_source_count,
  }
}

/*
 * **The mailbox *used-for* fetcher and its payload stood here and are gone.** That description is
 * kept in the browser now, on request: the `PATCH` never reached the server in the environment this
 * runs in — four attempts, none transferring a byte, while the same call succeeded from `curl` —
 * and a value with a home in `localStorage` must not also have one on a source, or the two come to
 * disagree. `src/data/mailUsedFor.ts` is where it lives; restoring the server path is this fetcher,
 * its schema, the `used_for` field on the sources payload and the route that writes it.
 */

export const suggestMetrics = (input: {
  domainId: string | null
  businessNeed: string
  personas?: string[]
}) => fetchSuggestions('/graph-metrics/suggest', 'The metric suggestions', input)

/**
 * Step 3's **Edit** — correct a drafted metric's title or its calculation, in the pool.
 *
 * The one write behind a wizard suggestion, and it is a write because the pool is the document:
 * accepting a row copies it into the draft and dismissing one filters a list nothing saved, but a
 * corrected title is a correction every later brief drafts from. The reply is the suggestion
 * shape, so the row a caller is holding is replaced with what the server stored rather than with
 * what was submitted.
 */
export async function editMetric(input: {
  metricId: string
  name: string
  definition: string
}): Promise<Suggestion> {
  const raw = validate<{ metric: Suggestion }>(
    'The edited metric',
    await request<unknown>(`/graph-metrics/${encodeURIComponent(input.metricId)}`, {
      method: 'PATCH',
      body: { name: input.name, definition: input.definition },
    }),
    METRIC_EDIT_PAYLOAD,
  )
  return raw.metric
}

interface RawCoverage {
  title: string
  entity_count: number
  relationship_count: number
  hero_question_count: number
  gap_count: number
  runtime_question_count: number
  object_count: number
  elements: {
    element_id: string
    name: string
    kind: 'entity' | 'relationship'
    status: 'backed' | 'gap' | 'runtime'
    confidence: number
    evidence: string | null
    reason: string | null
  }[]
  runtime_sources: {
    source_id: string
    source_name: string
    type_label: string
    scope: number
    scope_label: string
  }[]
  runtime_note: string | null
}

/** Shared by the direct review and the answer a derivation run finishes with. */
const toCoverage = (raw: RawCoverage): CoveragePayload => ({
  title: raw.title,
  entityCount: raw.entity_count,
  relationshipCount: raw.relationship_count,
  heroQuestionCount: raw.hero_question_count,
  gapCount: raw.gap_count,
  runtimeQuestionCount: raw.runtime_question_count,
  objectCount: raw.object_count,
  elements: raw.elements.map((e) => ({
    elementId: e.element_id,
    name: e.name,
    kind: e.kind,
    status: e.status,
    confidence: e.confidence,
    evidence: e.evidence,
    reason: e.reason,
  })),
  runtimeSources: raw.runtime_sources.map((s) => ({
    sourceId: s.source_id,
    sourceName: s.source_name,
    typeLabel: s.type_label,
    scope: s.scope,
    scopeLabel: s.scope_label,
  })),
  runtimeNote: raw.runtime_note,
})

export async function reviewCoverage(input: {
  name: string
  sources: SourcePick[]
  heroQuestions: HeroQuestion[]
}): Promise<CoveragePayload> {
  return toCoverage(
    validate<RawCoverage>(
      'The coverage review',
      await request<unknown>('/graph-coverage', {
        method: 'POST',
        body: {
          name: input.name,
          sources: input.sources.map((s) => ({
            source_id: s.sourceId,
            mode: s.mode,
            objects: s.objects,
          })),
          hero_questions: input.heroQuestions,
        },
      }),
      COVERAGE_PAYLOAD,
    ),
  )
}

interface RawDerivation {
  derivation_id: string
  status: 'running' | 'complete'
  stage_index: number
  stage_total: number
  stage_label: string
  progress: number
  revealed: string[]
  entity_total: number
  cost_usd: number
  cost_cap_usd: number
  coverage: unknown
}

const toDerivation = (raw: RawDerivation): DerivationRun => ({
  derivationId: raw.derivation_id,
  status: raw.status,
  stageIndex: raw.stage_index,
  stageTotal: raw.stage_total,
  stageLabel: raw.stage_label,
  progress: raw.progress,
  revealed: raw.revealed,
  entityTotal: raw.entity_total,
  costUsd: raw.cost_usd,
  costCapUsd: raw.cost_cap_usd,
  // Only a finished run carries an answer, and it is validated as one.
  coverage: raw.coverage
    ? toCoverage(
        validate<RawCoverage>('The derived coverage', raw.coverage, COVERAGE_PAYLOAD),
      )
    : null,
})

export async function startDerivation(input: {
  name: string
  sources: SourcePick[]
  heroQuestions: HeroQuestion[]
}): Promise<DerivationRun> {
  const raw = validate<RawDerivation>(
    'The derivation run',
    await request<unknown>('/graph-derivations', {
      method: 'POST',
      body: {
        name: input.name,
        sources: input.sources.map((s) => ({
          source_id: s.sourceId,
          mode: s.mode,
          objects: s.objects,
        })),
        hero_questions: input.heroQuestions,
      },
    }),
    DERIVATION_PAYLOAD,
  )
  return toDerivation(raw)
}

export async function getDerivation(derivationId: string): Promise<DerivationRun> {
  const raw = validate<RawDerivation>(
    'The derivation run',
    await request<unknown>(`/graph-derivations/${encodeURIComponent(derivationId)}`),
    DERIVATION_PAYLOAD,
  )
  return toDerivation(raw)
}

export const suggestQuestions = (input: {
  domainId: string | null
  businessNeed: string
  personas?: string[]
}) =>
  fetchSuggestions(
    '/graph-questions/suggest',
    'The hero question suggestions',
    input,
  )

/** No `useCaseId` creates a draft; passing one updates it in place. */
export async function saveUseCase(input: {
  useCaseId?: string | null
  name: string
  domainId: string | null
  businessNeed: string
  personas: Persona[]
  metrics: Metric[]
  sources: SourcePick[]
  heroQuestions: HeroQuestion[]
  gapDecisions: GapChoice[]
  step: number
  status?: 'draft' | 'committed'
  role?: RoleDetails | null
}): Promise<GraphUseCase> {
  const payload = await request<{ use_case: RawUseCase }>('/graph-use-cases', {
    method: 'POST',
    body: {
      use_case_id: input.useCaseId ?? undefined,
      name: input.name,
      domain_id: input.domainId,
      business_need: input.businessNeed,
      personas: input.personas,
      metrics: input.metrics,
      sources: input.sources.map((s) => ({
        source_id: s.sourceId,
        mode: s.mode,
        objects: s.objects,
      })),
      hero_questions: input.heroQuestions,
      gap_decisions: input.gapDecisions.map((d) => ({
        element_id: d.elementId,
        decision: d.decision,
      })),
      step: input.step,
      status: input.status,
      role: input.role ?? undefined,
    },
  })
  assertCurrentUseCaseShape((payload as { use_case?: unknown } | null)?.use_case)
  return toUseCase(
    validate<{ use_case: RawUseCase }>(
      'The saved use case',
      payload,
      shape({ use_case: USE_CASE }),
    ).use_case,
  )
}

/* ---------------- Graph Studio ---------------- */

interface RawStudioGraph {
  use_case_id: string
  name: string
  domain_id: string | null
  business_need: string
  version: string
  live_version: string | null
  state: 'draft' | 'published'
  queue_count: number
  must_review_outstanding: number
  must_review_count: number
  published_count: number
  built_at: string | null
}

interface RawReviewItem {
  item_id: string
  kind: 'relationship' | 'entity' | 'measure'
  title: string
  detail: string
  confidence: number
  band: 'High' | 'Medium' | 'Low' | null
  floor: string | null
  action_set: string
  actions: { choice: string; label: string }[]
  evidence: string[]
  graph_refs: string[]
  justification: boolean
  decision: { choice: string; justification: string | null; decided_at: string } | null
}

interface RawStudio extends RawStudioGraph {
  graph_name: string
  status: string
  decision_memory: string
  must_review: RawReviewItem[]
  confirmed_sample: RawReviewItem[]
  confirmed_count: number
  auto_approved_sample: RawReviewItem[]
  auto_approved_count: number
  pivot: {
    pivot_id: string
    alternative_id: string
    title: string
    detail: string
    why_pivot: string
    confidence: number
    band: 'High' | 'Medium' | 'Low' | null
    floor: string
    evidence: string[]
    graph_refs: string[]
    options: { option_id: string; label: string; consequence: string }[]
    open: boolean
    chosen: string | null
  }
  pivot_count: number
  sanity_checks: { check_id: string; hero_question_id: string; question: string }[]
  batch_resolved: number
  batch_total: number
  publish: { blocked: boolean; reasons: string[]; explanation: string }
  versions: {
    sha256: string
    graph_id: string
    config_version: string
    entities: number
    relationships: number
    from_job: string
    created_at: string
    gate: 'passed' | 'unknown'
    published: boolean
  }[]
}

const toStudioGraph = (g: RawStudioGraph): StudioGraph => ({
  useCaseId: g.use_case_id,
  name: g.name,
  domainId: g.domain_id,
  businessNeed: g.business_need,
  version: g.version,
  liveVersion: g.live_version,
  state: g.state,
  queueCount: g.queue_count,
  mustReviewOutstanding: g.must_review_outstanding,
  mustReviewCount: g.must_review_count,
  publishedCount: g.published_count,
  builtAt: g.built_at,
})

const toReviewItem = (i: RawReviewItem): ReviewItem => ({
  itemId: i.item_id,
  kind: i.kind,
  title: i.title,
  detail: i.detail,
  confidence: i.confidence,
  band: i.band,
  floor: i.floor,
  actionSet: i.action_set,
  actions: i.actions.map((a) => ({ choice: a.choice as ReviewChoice, label: a.label })),
  evidence: i.evidence,
  graphRefs: i.graph_refs,
  justification: i.justification,
  decision: i.decision
    ? {
        choice: i.decision.choice as ReviewChoice,
        justification: i.decision.justification,
        decidedAt: i.decision.decided_at,
      }
    : null,
})

const toStudio = (raw: RawStudio): GraphStudioPayload => ({
  ...toStudioGraph(raw),
  graphName: raw.graph_name,
  status: raw.status,
  decisionMemory: raw.decision_memory,
  mustReview: raw.must_review.map(toReviewItem),
  confirmedSample: raw.confirmed_sample.map(toReviewItem),
  confirmedCount: raw.confirmed_count,
  autoApprovedSample: raw.auto_approved_sample.map(toReviewItem),
  autoApprovedCount: raw.auto_approved_count,
  pivot: {
    pivotId: raw.pivot.pivot_id,
    alternativeId: raw.pivot.alternative_id,
    title: raw.pivot.title,
    detail: raw.pivot.detail,
    whyPivot: raw.pivot.why_pivot,
    confidence: raw.pivot.confidence,
    band: raw.pivot.band,
    floor: raw.pivot.floor,
    evidence: raw.pivot.evidence,
    graphRefs: raw.pivot.graph_refs,
    options: raw.pivot.options.map((o) => ({
      optionId: o.option_id,
      label: o.label,
      consequence: o.consequence,
    })),
    open: raw.pivot.open,
    chosen: raw.pivot.chosen,
  },
  pivotCount: raw.pivot_count,
  sanityChecks: raw.sanity_checks.map((c) => ({
    checkId: c.check_id,
    heroQuestionId: c.hero_question_id,
    question: c.question,
  })),
  batchResolved: raw.batch_resolved,
  batchTotal: raw.batch_total,
  publish: raw.publish,
  versions: raw.versions.map((v) => ({
    sha256: v.sha256,
    graphId: v.graph_id,
    configVersion: v.config_version,
    entities: v.entities,
    relationships: v.relationships,
    fromJob: v.from_job,
    createdAt: v.created_at,
    gate: v.gate,
    published: v.published,
  })),
})

interface RawCanvasNode {
  node_id: string
  label: string
  sublabel: string
  type: string
  element_class: 'thin_instance' | 'concept' | 'measure_element'
  source: string | null
  degree: number
  r: number
  group: string
  confidence: number | null
  proposed: boolean
  origin: 'derived' | 'studio-authored'
  rejected: boolean
  needs_review: boolean
  review_item_id: string | null
  on_answer_path: boolean
  x: number
  y: number
}

interface RawCanvas {
  nodes: RawCanvasNode[]
  edges: {
    edge_id: string
    from: string
    to: string
    label: string
    detail: string
    proposed: boolean
    review_item_id: string | null
    on_answer_path: boolean
  }[]
  node_count: number
  edge_count: number
  facets: {
    all: number
    low_confidence: number
    needs_review: number
    studio_authored: number
    groups: { key: CanvasGroup; count: number }[]
    types: { key: string; count: number }[]
  }
}

const toCanvas = (raw: RawCanvas): CanvasPayload => ({
  nodes: raw.nodes.map((n) => ({
    nodeId: n.node_id,
    label: n.label,
    sublabel: n.sublabel,
    type: n.type,
    elementClass: n.element_class,
    source: n.source,
    degree: n.degree,
    r: n.r,
    group: n.group,
    confidence: n.confidence,
    proposed: n.proposed,
    origin: n.origin,
    rejected: n.rejected,
    needsReview: n.needs_review,
    reviewItemId: n.review_item_id,
    onAnswerPath: n.on_answer_path,
    x: n.x,
    y: n.y,
  })),
  edges: raw.edges.map((e) => ({
    edgeId: e.edge_id,
    from: e.from,
    to: e.to,
    label: e.label,
    detail: e.detail,
    proposed: e.proposed,
    reviewItemId: e.review_item_id,
    onAnswerPath: e.on_answer_path,
  })),
  nodeCount: raw.node_count,
  edgeCount: raw.edge_count,
  facets: {
    all: raw.facets.all,
    lowConfidence: raw.facets.low_confidence,
    needsReview: raw.facets.needs_review,
    studioAuthored: raw.facets.studio_authored,
    groups: raw.facets.groups,
    types: raw.facets.types,
  },
})

/** The studio's front door: only graphs that have actually been built. */
export async function listStudioGraphs(): Promise<StudioGraphsPayload> {
  const raw = validate<{
    graphs: RawStudioGraph[]
    count: number
    draft_count: number
  }>('The built graphs', await request<unknown>('/graph-studio'), STUDIO_GRAPHS_PAYLOAD)

  return {
    graphs: raw.graphs.map(toStudioGraph),
    count: raw.count,
    draftCount: raw.draft_count,
  }
}

const studioPath = (useCaseId: string) =>
  `/graph-studio/${encodeURIComponent(useCaseId)}`

export async function getGraphStudio(useCaseId: string): Promise<GraphStudioPayload> {
  return toStudio(
    validate<RawStudio>(
      'The review queue',
      await request<unknown>(studioPath(useCaseId)),
      GRAPH_STUDIO_PAYLOAD,
    ),
  )
}

/** Every action answers with the whole studio, so the page never guesses. */
const withStudio = (what: string, payload: unknown) =>
  toStudio(
    validate<{ studio: RawStudio }>(
      what,
      payload,
      shape({ studio: GRAPH_STUDIO_PAYLOAD }),
    ).studio,
  )

export async function decideReviewItem(input: {
  useCaseId: string
  itemId: string
  choice: ReviewChoice
  justification?: string
}): Promise<GraphStudioPayload> {
  return withStudio(
    'The recorded decision',
    await request<unknown>(`${studioPath(input.useCaseId)}/decisions`, {
      method: 'POST',
      body: {
        item_id: input.itemId,
        choice: input.choice,
        justification: input.justification,
      },
    }),
  )
}

export async function resolvePivot(
  useCaseId: string,
  optionId: string,
): Promise<GraphStudioPayload> {
  return withStudio(
    'The pivot decision',
    await request<unknown>(`${studioPath(useCaseId)}/pivot`, {
      method: 'POST',
      body: { option_id: optionId },
    }),
  )
}

type RawGraphBuild = {
  build_id: string
  use_case_id: string
  status: 'running' | 'complete'
  stage_index: number
  stage_total: number
  step_index: number
  step_total: number
  step_ms: number
  stages: BuildStage[]
  package_id: string
  graph_version: string
  config_version: string
  started_at: string
  finished_at: string | null
}

const toGraphBuild = (raw: RawGraphBuild): GraphBuild => ({
  buildId: raw.build_id,
  useCaseId: raw.use_case_id,
  status: raw.status,
  stageIndex: raw.stage_index,
  stageTotal: raw.stage_total,
  stepIndex: raw.step_index,
  stepTotal: raw.step_total,
  stepMs: raw.step_ms,
  stages: raw.stages,
  packageId: raw.package_id,
  graphVersion: raw.graph_version,
  configVersion: raw.config_version,
  startedAt: raw.started_at,
  finishedAt: raw.finished_at,
})

const studioBuildsPath = (useCaseId: string) =>
  `/graph-studio/${encodeURIComponent(useCaseId)}/builds`

/**
 * Builds, or rebuilds. Answers 202 with a queued run, not a finished graph.
 *
 * **It says who started it to nobody, and that is deliberate.** This took an `as` and sent it
 * as `?as=`, because a runtime-answered graph published itself when the run landed — so for
 * that one graph this call *was* the publish act and had to name somebody. A build publishes
 * nothing now: every graph waits for the Publish button, `publishVersion` still sends the
 * address, and a build has no publication to credit. Sending one anyway would ask the reader's
 * identity of a route that throws it away.
 */
export async function startGraphBuild(useCaseId: string): Promise<GraphBuild> {
  return toGraphBuild(
    validate<RawGraphBuild>(
      'The graph build',
      await request<unknown>(studioBuildsPath(useCaseId), { method: 'POST' }),
      GRAPH_BUILD,
    ),
  )
}

/** This graph's runs, newest first. */
export async function listGraphBuilds(useCaseId: string): Promise<GraphBuild[]> {
  const raw = validate<{ builds: RawGraphBuild[] }>(
    'The build history',
    await request<unknown>(studioBuildsPath(useCaseId)),
    GRAPH_BUILDS_PAYLOAD,
  )
  return raw.builds.map(toGraphBuild)
}

export async function getGraphBuild(
  useCaseId: string,
  buildId: string,
): Promise<GraphBuild> {
  return toGraphBuild(
    validate<RawGraphBuild>(
      'The graph build',
      await request<unknown>(
        `${studioBuildsPath(useCaseId)}/${encodeURIComponent(buildId)}`,
      ),
      GRAPH_BUILD,
    ),
  )
}

export async function getStudioCanvas(useCaseId: string): Promise<CanvasPayload> {
  return toCanvas(
    validate<RawCanvas>(
      'The canvas',
      await request<unknown>(`${studioPath(useCaseId)}/canvas`),
      CANVAS_PAYLOAD,
    ),
  )
}

/** Asks the *draft* graph, and comes back with the path it used. */
export async function askStudio(
  useCaseId: string,
  question: string,
): Promise<QueryAnswer> {
  const raw = validate<{
    question: string
    answerable: boolean
    reason: string
    matched: string[]
    path: string[]
    path_labels: string[]
    edges_used: {
      edge_id: string
      from: string
      to: string
      label: string
      from_label: string
      to_label: string
      proposed: boolean
    }[]
    hops: number
    caveats: string[]
    recorded: boolean
    check_id: string | null
    hero_question_id: string | null
    matched_how: string | null
    verdict: string | null
    verdict_body: string | null
    context: { chip: string; label: string; meta: string; ok: boolean }[]
    plan: string | null
    cost_usd: number | null
    budget_usd: number | null
    canvas: RawCanvas
  }>(
    'The answer',
    await request<unknown>(`${studioPath(useCaseId)}/query`, {
      method: 'POST',
      body: { question },
    }),
    QUERY_PAYLOAD,
  )

  const canvas = toCanvas(raw.canvas)
  const label = (id: string) =>
    canvas.nodes.find((n) => n.nodeId === id)?.label ?? id

  return {
    question: raw.question,
    answerable: raw.answerable,
    reason: raw.reason,
    matched: raw.matched,
    path: raw.path,
    /*
     * A chain only where there is one. For a derived walk the labels are resolved
     * here rather than trusted, so what the answer shows is what the canvas draws;
     * for a recorded check the server sends none, because its traversal is a
     * sub-graph and arrow-joining its ids would claim a route nobody walked. The
     * hops are in `edgesUsed` either way.
     */
    pathLabels: raw.recorded ? raw.path_labels : raw.path.map(label),
    edgesUsed: raw.edges_used.map((e) => ({
      edgeId: e.edge_id,
      from: e.from,
      to: e.to,
      label: e.label,
      fromLabel: e.from_label,
      toLabel: e.to_label,
      proposed: e.proposed,
    })),
    hops: raw.hops,
    caveats: raw.caveats,
    recorded: raw.recorded,
    checkId: raw.check_id,
    heroQuestionId: raw.hero_question_id,
    matchedHow: raw.matched_how,
    verdict: raw.verdict,
    verdictBody: raw.verdict_body,
    context: raw.context,
    plan: raw.plan,
    costUsd: raw.cost_usd,
    budgetUsd: raw.budget_usd,
    canvas,
  }
}

/**
 * Publish one version — gate Ask's access to that exact content.
 *
 * Named by content hash, not by a number: what is published is a specific build.
 * Publishing an older row is what a rollback is, and the server's gate still
 * refuses an unreviewed graph whichever row is chosen.
 */
/**
 * Publish one version, and record who did it.
 *
 * `as` is the signed-in address. The server cannot look it up — the identity is
 * client-held — so every "published by" line in the app is only as true as this argument,
 * which is the same contract the consent callback has. Omitting it falls back to the
 * tenant's seeded account rather than to nobody.
 */
export async function publishVersion(
  useCaseId: string,
  sha256: string,
  as?: string | null,
): Promise<GraphStudioPayload> {
  const path = `${studioPath(useCaseId)}/versions/${sha256}/publish`
  return withStudio(
    'The published version',
    await request<unknown>(as ? `${path}?as=${encodeURIComponent(as)}` : path, {
      method: 'POST',
    }),
  )
}

/** Take the published version out of Ask. The version itself is untouched. */
export async function unpublishVersion(
  useCaseId: string,
  sha256: string,
): Promise<GraphStudioPayload> {
  return withStudio(
    'The unpublished version',
    await request<unknown>(`${studioPath(useCaseId)}/versions/${sha256}/unpublish`, {
      method: 'POST',
    }),
  )
}

export async function deleteUseCase(useCaseId: string): Promise<{ deleted: string }> {
  return validate<{ deleted: string }>(
    'The deleted use case',
    await request<unknown>(`/graph-use-cases/${encodeURIComponent(useCaseId)}`, {
      method: 'DELETE',
    }),
    DELETED_PAYLOAD,
  )
}

export async function getDb(): Promise<DbPayload> {
  const raw = await request<unknown>('/db')
  return validate<DbPayload>("The db.json document", raw, DB_PAYLOAD)
}

export async function putDb(
  db: unknown,
): Promise<{ saved: boolean; sections: DbSection[] }> {
  return validate<{ saved: boolean; sections: DbSection[] }>(
    'The saved db.json',
    await request<unknown>('/db', { method: 'PUT', body: { db } }),
    DB_SAVED_PAYLOAD,
  )
}

export async function putDbSection(
  section: string,
  value: unknown,
): Promise<{ saved: boolean; section: string; sections: DbSection[] }> {
  return validate<{ saved: boolean; section: string; sections: DbSection[] }>(
    'The saved section',
    await request<unknown>(`/db/${encodeURIComponent(section)}`, {
      method: 'PUT',
      body: { value },
    }),
    DB_SECTION_SAVED_PAYLOAD,
  )
}

/* ---------------- Ask ---------------- */

interface RawAskGraph {
  use_case_id: string
  name: string
  domain_id: string | null
  version: string
  published_at: string | null
  published_by: string | null
  caveats: string[]
  suggested_questions: string[]
  entity_count: number
  relationship_count: number
}

const toAskGraph = (raw: RawAskGraph): AskGraph => ({
  useCaseId: raw.use_case_id,
  name: raw.name,
  domainId: raw.domain_id,
  version: raw.version,
  publishedAt: raw.published_at,
  publishedBy: raw.published_by,
  caveats: raw.caveats,
  suggestedQuestions: raw.suggested_questions,
  entityCount: raw.entity_count,
  relationshipCount: raw.relationship_count,
})

/** A served format, in the shape the page reads. */
const toAnswerFormat = (f: {
  format_id: string
  name: string
  format: string
}): AnswerFormat => ({ formatId: f.format_id, name: f.name, format: f.format })

/** The graphs that are live. An empty list is the page's whole story. */
export async function listAskGraphs(): Promise<AskGraphsPayload> {
  const raw = validate<{
    graphs: RawAskGraph[]
    count: number
    sources: {
      source_id: string
      name: string
      kind: string
      connector: string
      account: string | null
      scope: string
      suggested_questions: string[]
    }[]
    source_count: number
    built_count: number
    draft_count: number
    answer_requirements: {
      citations_options: { value: Citations; label: string }[]
      default_citations: Citations
      formats: { format_id: string; name: string; format: string }[]
      note: string
    }
  }>('The live graphs', await request<unknown>('/ask'), ASK_GRAPHS_PAYLOAD)

  return {
    graphs: raw.graphs.map(toAskGraph),
    count: raw.count,
    sources: raw.sources.map((r) => ({
      sourceId: r.source_id,
      name: r.name,
      kind: r.kind,
      connector: r.connector,
      account: r.account,
      scope: r.scope,
      suggestedQuestions: r.suggested_questions,
    })),
    sourceCount: raw.source_count,
    builtCount: raw.built_count,
    draftCount: raw.draft_count,
    answerRequirements: {
      citationsOptions: raw.answer_requirements.citations_options,
      defaultCitations: raw.answer_requirements.default_citations,
      formats: raw.answer_requirements.formats.map(toAnswerFormat),
      note: raw.answer_requirements.note,
    },
  }
}

type RawAskAnswer = {
  question: string
  use_case_id: string | null
  graph_name: string | null
  version: string | null
  source_ids?: string[] | null
  answered: boolean
  reason: string
  answer: string | null
  confidence: number | null
  entities: string[]
  path: string[]
  hops: number
  reasoning: AskStep[]
  citations: RawAskCitation[]
  caveats: string[]
  asked_at: string
  summary: string | null
  blocks: AnswerBlock[]
  answer_id: string | null
  requirements: {
    citations: Citations
    formats: { format_id: string; name: string; format: string }[]
    satisfied: boolean
    note: string
  }
}

/*
 * The wire shape of one citation. Spelled out rather than reusing `AskCitation`, which is
 * the *camelCase* one the UI reads — declaring the raw payload as the mapped type is the
 * mistake CLAUDE.md records as "a payload field name is a contract the compiler cannot
 * check": it compiles, and then `asOf` is `undefined` on every citation at runtime.
 *
 * The four optional fields are optional on the wire too, because the graph walk emits
 * citations with only a label and a detail.
 */
interface RawAskCitation {
  label: string
  detail: string
  confidence: number | null
  kind?: string | null
  source_id?: string | null
  runtime?: boolean | null
  as_of?: string | null
  authoritative?: boolean | null
  why_not_authoritative?: string | null
  n?: number | null
}

/* `?? null` rather than left undefined: the UI tests each mark against null, and an absent
   key and a stated null mean the same thing here — the answer did not say. */
const toAskCitation = (c: RawAskCitation): AskCitation => ({
  label: c.label,
  detail: c.detail,
  confidence: c.confidence ?? null,
  kind: c.kind ?? null,
  sourceId: c.source_id ?? null,
  runtime: c.runtime ?? null,
  asOf: c.as_of ?? null,
  authoritative: c.authoritative ?? null,
  whyNotAuthoritative: c.why_not_authoritative ?? null,
  n: c.n ?? null,
})

const toAskAnswer = (raw: RawAskAnswer): AskAnswer => ({
  question: raw.question,
  useCaseId: raw.use_case_id,
  graphName: raw.graph_name,
  version: raw.version,
  sourceIds: raw.source_ids ?? [],
  answered: raw.answered,
  reason: raw.reason,
  answer: raw.answer,
  confidence: raw.confidence,
  entities: raw.entities,
  path: raw.path,
  hops: raw.hops,
  reasoning: raw.reasoning,
  citations: raw.citations.map(toAskCitation),
  caveats: raw.caveats,
  askedAt: raw.asked_at,
  summary: raw.summary,
  blocks: raw.blocks,
  answerId: raw.answer_id,
  requirements: {
    citations: raw.requirements.citations,
    formats: raw.requirements.formats.map(toAnswerFormat),
    satisfied: raw.requirements.satisfied,
    note: raw.requirements.note,
  },
})

/** What arrives while an answer is being composed. */
export type AskEvent =
  | { kind: 'stage'; step: string; detail: string }
  | {
      kind: 'summary'
      answered: boolean
      summary: string | null
      reason: string
      answer: string | null
      /** How many blocks are still to come — what the shimmers are counted from. */
      blockCount: number
    }
  | { kind: 'block'; index: number; block: AnswerBlock }
  | { kind: 'done'; answer: AskAnswer }

const ASK_STAGE_EVENT = shape({ step: str, detail: str })
const ASK_SUMMARY_EVENT = shape({
  answered: bool,
  summary: nullable(str),
  reason: str,
  answer: nullable(str),
  /* How many blocks follow. The page draws one shimmer per paragraph it is waiting for, so
     this is a promise the server keeps rather than a guess the client makes. */
  block_count: num,
})
const ASK_BLOCK_EVENT = shape({ index: num, block: ANSWER_BLOCK })

/**
 * Asks, and reports the answer as it is composed.
 *
 * `/ask` answers with an event stream, so this cannot go through the shared
 * transport helper — that reads one JSON body. **Every event is still
 * validated**, by its own schema, and the final `done` carries the whole envelope
 * so the answer the store keeps has been checked as one object rather than
 * assembled from fragments the page happened to receive.
 *
 * (The words above avoid naming that helper with parentheses on purpose:
 * `check-docs` finds fetchers by scanning declaration bodies for it, and a
 * mention in a comment made the schema *above* this one look like an unvalidated
 * fetcher. The check is deliberately crude — it is cheaper to word around it than
 * to teach it to parse.)
 *
 * A refusal still arrives as a JSON 400 before the stream opens, so the existing
 * `ApiError` path is unchanged: only the success case streams.
 */
export async function askQuestionStreaming(
  /** The published graph, or null when connected sources are what is being asked. */
  useCaseId: string | null,
  question: string,
  /* What the reader required of this answer. Sent with the question because it is a
     property of the asking, not of the graph — the brief no longer declares it. */
  requirements: { citations: Citations; formats: string[] },
  /* Which connected sources to read at question time. Sent whether or not a graph was
     named, because the server is what decides how the two combine — a client that dropped
     them when a graph was selected would be making that decision here. */
  sourceIds: string[],
  onEvent: (event: AskEvent) => void,
  /* The signed-in address. The server cannot look it up — the identity is client-held —
     so a greeting naming the reader is only as true as this argument, the same contract
     `publishVersion`'s `as` has. Omitted or unresolved, the greeting answers with no name
     rather than inventing one. */
  as?: string | null,
): Promise<AskAnswer> {
  const response = await fetch(`${BASE}/ask`, {
    method: 'POST',
    /* The stream carries the selection too — an answer belongs to the dataset it was asked of. */
    headers: {
      'content-type': 'application/json',
      accept: 'text/event-stream',
      'x-dataset': currentDataset(),
    },
    body: JSON.stringify({
      use_case_id: useCaseId,
      question,
      source_ids: sourceIds,
      citations: requirements.citations,
      formats: requirements.formats,
      as: as ?? undefined,
    }),
  })

  if (!response.ok) {
    // Same shape of failure as request(): the server's own sentence, verbatim.
    const body = (await response.json().catch(() => null)) as { error?: string } | null
    throw new ApiError(
      body?.error ?? `The answer could not be read (HTTP ${response.status}).`,
      response.status,
    )
  }
  if (!response.body) {
    throw new ApiError('The answer stream was empty — restart the mock server.', 500)
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let final: AskAnswer | null = null

  const handle = (event: string, data: unknown) => {
    if (event === 'stage') {
      const e = validate<{ step: string; detail: string }>(
        'An answer step',
        data,
        ASK_STAGE_EVENT,
      )
      onEvent({ kind: 'stage', ...e })
    } else if (event === 'summary') {
      const e = validate<{
        answered: boolean
        summary: string | null
        reason: string
        answer: string | null
        block_count: number
      }>('The answer summary', data, ASK_SUMMARY_EVENT)
      onEvent({
        kind: 'summary',
        answered: e.answered,
        summary: e.summary,
        reason: e.reason,
        answer: e.answer,
        blockCount: e.block_count,
      })
    } else if (event === 'block') {
      const e = validate<{ index: number; block: AnswerBlock }>(
        'An answer block',
        data,
        ASK_BLOCK_EVENT,
      )
      onEvent({ kind: 'block', ...e })
    } else if (event === 'done') {
      final = toAskAnswer(validate<RawAskAnswer>('The answer', data, ASK_ANSWER_PAYLOAD))
      onEvent({ kind: 'done', answer: final })
    }
    // An unknown event name is ignored on purpose: a newer server adding one
    // must not break an older page, and nothing is rendered from it.
  }

  for (;;) {
    const { done, value } = await reader.read()
    if (value) buffer += decoder.decode(value, { stream: true })
    // SSE frames are separated by a blank line; a partial frame stays buffered.
    let cut = buffer.indexOf('\n\n')
    while (cut >= 0) {
      const frame = buffer.slice(0, cut)
      buffer = buffer.slice(cut + 2)
      const name = frame.match(/^event: (.+)$/m)?.[1]
      const payload = frame.match(/^data: ([\s\S]+)$/m)?.[1]
      if (name && payload) handle(name, JSON.parse(payload) as unknown)
      cut = buffer.indexOf('\n\n')
    }
    if (done) break
  }

  if (!final) {
    throw new ApiError(
      'The answer stream ended before the answer did — restart the mock server (npm run mock) and ask again.',
      500,
    )
  }
  return final
}

export async function getAudit(): Promise<AuditPayload> {
  const raw = await request<unknown>('/audit')
  return validate<AuditPayload>("The audit data", raw, AUDIT_PAYLOAD)
}

export async function getTraces(): Promise<TracesPayload> {
  const raw = await request<unknown>('/traces')
  return validate<TracesPayload>("The trace data", raw, TRACES_PAYLOAD)
}

export async function getEvals(): Promise<EvalsPayload> {
  const raw = validate<RawEvalsPayload>(
    'The evals data',
    await request<unknown>('/evals'),
    EVALS_PAYLOAD,
  )
  return {
    ...raw,
    runs: raw.runs.map((r) => ({
      suite: r.suite,
      target: r.target,
      checks: r.checks,
      passRate: r.pass_rate,
      status: r.status,
      tone: r.tone,
      ranAt: r.ran_at,
    })),
  }
}

/* ---------------- The What-if lens ---------------- */

/**
 * A candidate generator — one possible load.
 *
 * Every figure here is a federal record the graph already holds, not a projection:
 * `evaluations` and `violations` come from RCRAInfo, `enforcement` and `penalty` from
 * ECHO, `manifests` and `tons` from e-Manifest, `consentDecree` from an extracted
 * document. Nothing on this page is predicted.
 */
export interface WhatIfGenerator {
  id: string
  name: string
  state: string
  risk: 'high' | 'med' | 'low'
  transporter: string
  evaluations: number
  violations: number
  enforcement: number
  penalty: number
  tons: number
  manifests: number
  consentDecree: boolean
  lastEnforcement: string
}

/** A measure that can be watched, because the graph already computes it. */
export interface WhatIfMeasure {
  key: string
  label: string
  unit: string
  /** Which federal source it comes from — ECHO, RCRA, DOC. */
  source: string
  /** The relationship or measure element it grounds to. */
  grounds: string
  /** True where the measure is inherited from the load rather than the facility's own. */
  inherited: boolean
}

/** A pool of candidate loads, carrying its own count. */
export interface WhatIfPool {
  key: string
  label: string
  count: number
}

/**
 * The inverse question, per pool: how many more enforcement-carrying loads fit.
 *
 * `room` is `null` where nothing in the pool carries enforcement — there is no break
 * point to state, and a `0` there would read as "no room left" when the truth is "no
 * load in this pool moves the figure".
 */
export interface WhatIfHeadroom {
  pool: string
  room: number | null
  avg: number | null
  carrying: number
  appetite: number
}

/** One case inside a scenario: the admitted load, and what it is called. */
export interface WhatIfCase {
  name: string
  generatorId: string
}

/** Somebody a scenario can be published to. The tenant's own users, with their persona. */
export interface WhatIfReader {
  email: string
  name: string
  roleId: string
  roleLabel: string
  /** What that persona may see. Stated beside them — this lens applies no filter. */
  accessNote: string
}

/** A published graph a scenario can be bound to. */
export interface WhatIfGraphOption {
  useCaseId: string
  name: string
  version: string | null
  sha256: string | null
  /**
   * When the build behind the live content was made.
   *
   * Publishing mints no date of its own, so this is the build's — which is what the
   * confirmation's graph line dates. Null for a version built before the field existed,
   * and then the line says which graph without claiming a day.
   */
  builtAt: string | null
}

/** How often a reader's figures re-traverse. Declared, never a promise this mock keeps. */
export interface WhatIfFreshness {
  preset: string
  every: number
  unit: string
  days: string[]
  time: string
}

/** What a published scenario records: who is told, which content answers it, how often. */
export interface WhatIfPublication {
  readers: string[]
  graphUseCaseId: string
  graphName: string
  graphVersion: string | null
  graphSha256: string | null
  freshness: WhatIfFreshness
  publishedBy: string
  publishedAt: string
  /** Where the readers go. Composed by the server, never assembled in a component. */
  link: string
}

/**
 * A saved scenario: the frame, its cases, and its publication.
 *
 * **Stores the admitted load, never the figures.** That is what lets it stay true as the
 * graph changes — re-opening it recomputes every measure by traversal rather than
 * reading a number somebody cached last week.
 */
export interface WhatIfSaved {
  savedId: string
  name: string
  /** When it was created — never confused with when it was published. */
  createdAt: string
  /** When its frame or its cases were last written. */
  updatedAt: string
  /** The frame: which measures were watched and which pool the cases may draw from. */
  watch: string[]
  pool: string
  cases: WhatIfCase[]
  /** Null while it is a library entry nobody has published. */
  published: WhatIfPublication | null
}

/** One watched measure, computed for one candidate load. */
export interface WhatIfScenarioMeasure {
  key: string
  label: string
  source: string
  grounds: string
  unit: string
  /** The figure judged against the appetite line: baseline plus what is inherited. */
  value: number | boolean
  valueText: string
  /** What this load brings. */
  inherited: number | boolean
  inheritedText: string
  /** What the facility already carries, or `null` where it keeps no running count. */
  baseline: number | boolean | null
  baselineText: string | null
  appetite: number | null
  /** True where `value` crosses the facility's stated appetite. */
  breached: boolean
  /** False where this load moves the figure not at all — a real answer. */
  moved: boolean
}

/** A node in the subgraph one admitted load traverses. */
export interface WhatIfSubgraphNode {
  key: string
  label: string
  /** The figure inside the circle — null on a node that is not a count. */
  count: number | null
  /** Only the generator carries one; the tier is a state, so it is drawn as one. */
  risk: 'high' | 'med' | 'low' | null
}

/** One traversal step. `label` is a relationship the graph declares, never a phrase. */
export interface WhatIfSubgraphEdge {
  from: string
  to: string
  label: string
}

/** A node type in the legend: what it is called, and the colour the package gave it. */
export interface WhatIfNodeType {
  key: string
  label: string
  color: string
  /** On the generator only: the colour per risk tier. */
  riskColors?: Record<string, string>
}

/** How the pool frame is drawn — the package states the centre, the edge and the cap. */
export interface WhatIfGraphFrame {
  description: string
  centerNode: string
  edge: string
  maxDrawn: number
}

/** One scenario column: what admitting this load would inherit. */
export interface WhatIfScenario {
  generator: WhatIfGenerator
  measures: WhatIfScenarioMeasure[]
  /** The federal record behind each figure. "No value is invented" is the promise. */
  sources: { key: string; label: string; line: string }[]
  /** True where anything at all connects to this load. */
  flagged: boolean
  /** Said plainly when nothing does — an empty trace panel reads as "not checked". */
  cleanNote: string | null
  /** What the scenario cannot see, stated rather than hidden. */
  residualNote: string
  subgraph: {
    nodes: WhatIfSubgraphNode[]
    edges: WhatIfSubgraphEdge[]
    relationships: string[]
  }
}

/**
 * What the graph said about a typed measure.
 *
 * Three verdicts, and the refusal is the important one: a measure that does not ground
 * to a relationship cannot be watched, and saying so is the difference between a
 * governed measure and a made-up one.
 */
export interface WhatIfResolution {
  text: string
  verdict: 'resolved' | 'grounds_not_inherited' | 'refused'
  /** The measure it added, or null for the two verdicts that add nothing. */
  measureKey: string | null
  tone: 'ok' | 'warn' | 'bad'
  title: string
  body: string
}

/** The copy the page prints. All of it server-side, none of it written in a component. */
export interface WhatIfCopy {
  pageTitle: string
  banner: string
  subtitle: string
  overlayPill: string
  dataNote: string
  tabs: { key: string; label: string }[]
}

export interface WhatIfAuthoringStep {
  n: number
  key: string
  title: string
  heading: string
  help: string
}

/**
 * The publish dialog's copy — all of it the tenant's, none of it written in a component.
 *
 * A freshness preset carries its own `sentence` because the recurrence line has to change
 * as the control does; `custom` interpolates `{n}`, `{when}` and `{time}`, the same
 * arrangement `runtime.headroom.sentence` uses for `{room}` and `{appetite}`.
 */
export interface WhatIfPublishing {
  publishTitle: string
  manageTitle: string
  call: string
  readers: {
    label: string
    placeholder: string
    emptyError: string
    caveat: string
    scopeNote: string
  }
  graph: { label: string; note: string; empty: string }
  freshness: {
    label: string
    presets: { id: string; label: string; sentence: string }[]
    days: string[]
    times: string[]
    units: string[]
    default: WhatIfFreshness
    noDayError: string
  }
  /**
   * The confirmation shown once a publish has succeeded.
   *
   * Every line of it restates something the publication *stored*, which is why the copy
   * is the tenant's and the values are the record's: `body` interpolates `{name}` and
   * `{n}`, `graphNote` interpolates `{when}`. It states and never counts a figure — a
   * publication holds each case's admitted load and no numbers at all.
   */
  done: {
    title: string
    body: string
    stored: string
    link: { label: string; copied: string }
    labels: { cases: string; readers: string; graph: string; numbers: string; access: string }
    graphNote: string
    accessNote: string
    auditLink: string
    buttons: { again: string; close: string }
  }
  buttons: {
    publish: string
    update: string
    unpublish: string
    manage: string
    open: string
  }
  unpublishedNote: string
}

/**
 * A rendered What-if lens: a finished page this dataset ships instead of a traversal to compute.
 *
 * Every field is read out of the document by `npm run ingest:capex` — its `<title>` carries the name, the
 * stage and the version, its `<h1>` and standfirst carry what it says it is for, and its tab buttons carry
 * its own two tabs. None of it is typed in this repo, for the reason a report's figures are not: a
 * transcription is right until the file is next exported, and then it is wrong and looks fine.
 */
export interface WhatIfDocument {
  documentId: string
  /** The file, relative to the dataset's lens folder. Resolved to a URL by the page, not here. */
  file: string
  title: string
  version: string
  /** The document's own word for how finished it is — "draft". Not a governance state. */
  stage: string
  heading: string
  subtitle: string
  tabs: { key: string; label: string }[]
}

export interface WhatIfFrame {
  connectedSources: number
  /** 0 while no graph is published — the lens overlays the published graph. */
  publishedCount: number
  builtCount: number
  draftCount: number
  facility: {
    id: string
    name: string
    role: string
    baseline: Record<string, number>
    appetite: Record<string, number>
  } | null
  generators: WhatIfGenerator[]
  measures: WhatIfMeasure[]
  pools: WhatIfPool[]
  headroom: WhatIfHeadroom[]
  saved: WhatIfSaved[]
  /**
   * Who a scenario can be published to, and which content it can be bound to.
   *
   * Both are the app's own pools — `settings.json`'s users and the graphs that are
   * actually published — served rather than held here, because a client-side copy of
   * either is a second answer to "who exists" and can offer what the API refuses.
   */
  readers: WhatIfReader[]
  graphs: WhatIfGraphOption[]
  copy: WhatIfCopy
  /**
   * The rendered lens this dataset ships, or `null` where the lens is computed.
   *
   * Present for a dataset whose What-if is a document rather than a traversal, and served on **both**
   * branches of `GET /whatif` — the publish gate is about questions, and a finished page asked nothing
   * of a graph. The page frames it in place of the lens.
   */
  document: WhatIfDocument | null
  publishing: WhatIfPublishing
  defaults: { tab: string; step: number; count: number; watch: string[]; pool: string }
  authoring: {
    steps: WhatIfAuthoringStep[]
    addMeasure: { label: string; placeholder: string; button: string; help: string }
    previewRows: number
    reviewNote: string
    scenarioCount: { heading: string; help: string; options: number[]; default: number }
    cta: [string, string, string]
    graphLink: string
  }
  runtime: {
    compare: { min: number; max: number; default: number; help: string }
    card: {
      loadLabel: string
      namePlaceholder: string
      traceLink: string
      traceHeader: string
      graphLink: string
    }
    headroom: { label: string; sentence: string; help: string }
    library: {
      title: string
      empty: string
      fullHelp: string
      saveBtn: string
      updateBtn: string
      savedFlag: string
      addBtn: string
    }
    closingNote: string
  }
  graphReference: {
    nodeTypes: WhatIfNodeType[]
    relationships: string[]
    /** How the pool frame is drawn: what sits at the centre, the edge, and the cap. */
    frame: WhatIfGraphFrame
  }
}

/*
 * The schemas. Every field the page reads is checked at the boundary, because `/db`
 * lets a user edit this data live and a measure reading `undefined` renders as "no
 * inherited risk" — an answer, and the wrong one.
 */

/** A measure's value is a number or a boolean: a consent decree is yes/no, and
 *  coercing it to 0/1 would print "0" where the answer is "no". */
const numOrBool: FieldCheck = (v, path, issues) => {
  if (typeof v !== 'number' && typeof v !== 'boolean') {
    issues.push(`${path} should be a number or a boolean, got ${typeof v}`)
  }
}

/** An object whose keys are the tenant's, so the keys are not enumerable here — but
 *  it still has to *be* an object, which is what a bare `shape({})` asserts. */
const objectOnly = shape({})

const WHATIF_GENERATOR = shape({
  id: str,
  name: str,
  state: str,
  risk: oneOf(['high', 'med', 'low']),
  transporter: str,
  evaluations: num,
  violations: num,
  enforcement: num,
  penalty: num,
  tons: num,
  manifests: num,
  consent_decree: bool,
  last_enforcement: str,
})

const WHATIF_MEASURE = shape({
  key: str,
  label: str,
  unit: str,
  source: str,
  grounds: str,
  inherited: bool,
})

const WHATIF_FRESHNESS = shape({
  preset: str,
  every: num,
  unit: str,
  days: arrayOf(str),
  time: str,
})

/*
 * A saved scenario. `cases` carries generator ids and names and *nothing else* — the
 * schema is where that contract is visible, because a server that started answering
 * with cached measures here would otherwise be indistinguishable from one that did not.
 */
const WHATIF_SAVED = shape({
  saved_id: str,
  name: str,
  /* When the scenario was created and when it was last written. Two facts, and
     neither is `published.published_at` — a library entry can wait a week for
     somebody to publish it, so a row showing one date would date the other act. */
  created_at: str,
  updated_at: str,
  watch: arrayOf(str),
  pool: str,
  cases: arrayOf(shape({ name: str, generator_id: str })),
  published: nullable(
    shape({
      readers: arrayOf(str),
      graph_use_case_id: str,
      graph_name: str,
      graph_version: nullable(str),
      graph_sha256: nullable(str),
      freshness: WHATIF_FRESHNESS,
      published_by: str,
      published_at: str,
      /* Not nullable: a publication a reader can be sent has an address, and a blank one
         would print an empty box beside a Copy link button that copies nothing. */
      link: str,
    }),
  ),
})

const WHATIF_READER = shape({
  email: str,
  name: str,
  role_id: str,
  role_label: str,
  access_note: str,
})

const WHATIF_GRAPH_OPTION = shape({
  use_case_id: str,
  name: str,
  version: nullable(str),
  sha256: nullable(str),
  built_at: nullable(str),
})

const WHATIF_PUBLISHING = shape({
  publish_title: str,
  manage_title: str,
  call: str,
  readers: shape({
    label: str,
    placeholder: str,
    empty_error: str,
    caveat: str,
    scope_note: str,
  }),
  graph: shape({ label: str, note: str, empty: str }),
  freshness: shape({
    label: str,
    presets: arrayOf(shape({ id: str, label: str, sentence: str })),
    days: arrayOf(str),
    times: arrayOf(str),
    units: arrayOf(str),
    default: WHATIF_FRESHNESS,
    no_day_error: str,
  }),
  done: shape({
    title: str,
    body: str,
    stored: str,
    link: shape({ label: str, copied: str }),
    labels: shape({ cases: str, readers: str, graph: str, numbers: str, access: str }),
    graph_note: str,
    access_note: str,
    audit_link: str,
    buttons: shape({ again: str, close: str }),
  }),
  buttons: shape({
    publish: str,
    update: str,
    unpublish: str,
    manage: str,
    open: str,
  }),
  unpublished_note: str,
})

const WHATIF_FRAME = shape({
  connected_sources: num,
  /* The publish gate, the same three counts the report section carries. */
  published_count: num,
  built_count: num,
  draft_count: num,
  /* Null before a source is connected — the page shows NoSourceConnected, and a
     fabricated facility would be a claim about a tenant with no data. */
  facility: nullable(
    shape({ id: str, name: str, role: str, baseline: objectOnly, appetite: objectOnly }),
  ),
  generators: arrayOf(WHATIF_GENERATOR),
  watched_measures: arrayOf(WHATIF_MEASURE),
  candidate_pools: arrayOf(shape({ key: str, label: str, count: num })),
  headroom: arrayOf(
    shape({
      pool: str,
      room: nullable(num),
      avg: nullable(num),
      carrying: num,
      appetite: num,
    }),
  ),
  saved: arrayOf(WHATIF_SAVED),
  /* Both empty before a graph is published, and the gate branch sends them so anyway —
     the shape is checked on every branch, not only the one with data. */
  readers: arrayOf(WHATIF_READER),
  graphs: arrayOf(WHATIF_GRAPH_OPTION),
  publishing: WHATIF_PUBLISHING,
  /* `nullable` accepts an absent key as well as null, which is what a dataset with a computed lens
     sends. A *present* one is checked in full — this object is what the page frames instead of the
     lens, so a missing `file` is a blank frame and a missing `title` is a bar labelled `undefined`. */
  document: nullable(
    shape({
      document_id: str,
      file: str,
      title: str,
      version: str,
      stage: str,
      heading: str,
      subtitle: str,
      tabs: arrayOf(shape({ key: str, label: str })),
    }),
  ),
  copy: shape({
    page_title: str,
    banner: str,
    subtitle: str,
    overlay_pill: str,
    data_note: str,
    tabs: arrayOf(shape({ key: str, label: str })),
  }),
  state_defaults: shape({
    tab: str,
    step: num,
    count: num,
    watch: objectOnly,
    pool: str,
  }),
  authoring: shape({
    /* `help` is nullable because step 3 carries a `note` instead — the review step has
       nothing to explain, it has a guarantee to state. Declaring it as a required
       string made the whole frame fail to read, which is the validator doing its job. */
    steps: arrayOf(shape({ n: num, key: str, title: str, heading: str, help: nullable(str) })),
    scenario_count: shape({
      heading: str,
      help: str,
      options: arrayOf(num),
      default: num,
    }),
    cta_step1: str,
    cta_step2: str,
    cta_step3: str,
  }),
  runtime: shape({
    compare: shape({ min: num, max: num, default: num, help: str }),
    scenario_card: shape({
      load_label: str,
      name_placeholder: str,
      trace_link: str,
      trace_header: str,
      residual_note: str,
      clean_note: str,
      graph_link: str,
    }),
    headroom: shape({ label: str, sentence: str, help: str }),
    saved_library: shape({
      title: str,
      empty: str,
      full_help: str,
      save_btn: str,
      update_btn: str,
      saved_flag: str,
      add_btn: str,
    }),
    closing_note: str,
  }),
  graph_reference: shape({
    /* The palette is the package's own: a node type states its colour, and the generator
       states one per risk tier. A component picking hues here would be inventing a legend. */
    node_types: arrayOf(
      shape({ key: str, label: str, color: str, risk_colors: nullable(objectOnly) }),
    ),
    relationships: arrayOf(str),
    frame: shape({
      description: str,
      center_node: str,
      edge: str,
      max_drawn: num,
    }),
  }),
})

const WHATIF_RESOLUTION = shape({
  text: str,
  verdict: oneOf(['resolved', 'grounds_not_inherited', 'refused']),
  measure_key: nullable(str),
  tone: oneOf(['ok', 'warn', 'bad']),
  title: str,
  body: str,
})

const WHATIF_SCENARIO = shape({
  generator: WHATIF_GENERATOR,
  measures: arrayOf(
    shape({
      key: str,
      label: str,
      source: str,
      grounds: str,
      unit: str,
      value: numOrBool,
      value_text: str,
      inherited: numOrBool,
      inherited_text: str,
      baseline: nullable(numOrBool),
      baseline_text: nullable(str),
      appetite: nullable(num),
      breached: bool,
      moved: bool,
    }),
  ),
  sources: arrayOf(shape({ key: str, label: str, line: str })),
  flagged: bool,
  clean_note: nullable(str),
  residual_note: str,
  subgraph: shape({
    nodes: arrayOf(
      shape({
        key: str,
        label: str,
        count: nullable(num),
        risk: nullable(oneOf(['high', 'med', 'low'])),
      }),
    ),
    edges: arrayOf(shape({ from: str, to: str, label: str })),
    relationships: arrayOf(str),
  }),
})

const WHATIF_SAVED_PAYLOAD = shape({ saved: arrayOf(WHATIF_SAVED) })
/* A write answers with the library *and* the id it touched, so the page can link the
   runtime to the entry without guessing which row is new. */
const WHATIF_SAVED_WRITE = shape({ saved: arrayOf(WHATIF_SAVED), saved_id: str })

interface RawWhatIfGenerator {
  id: string
  name: string
  state: string
  risk: 'high' | 'med' | 'low'
  transporter: string
  evaluations: number
  violations: number
  enforcement: number
  penalty: number
  tons: number
  manifests: number
  consent_decree: boolean
  last_enforcement: string
}

interface RawWhatIfFreshness {
  preset: string
  every: number
  unit: string
  days: string[]
  time: string
}

interface RawWhatIfSaved {
  saved_id: string
  name: string
  created_at: string
  updated_at: string
  watch: string[]
  pool: string
  cases: { name: string; generator_id: string }[]
  published: {
    readers: string[]
    graph_use_case_id: string
    graph_name: string
    graph_version: string | null
    graph_sha256: string | null
    freshness: RawWhatIfFreshness
    published_by: string
    published_at: string
    link: string
  } | null
}

const toWhatIfGenerator = (g: RawWhatIfGenerator): WhatIfGenerator => ({
  id: g.id,
  name: g.name,
  state: g.state,
  risk: g.risk,
  transporter: g.transporter,
  evaluations: g.evaluations,
  violations: g.violations,
  enforcement: g.enforcement,
  penalty: g.penalty,
  tons: g.tons,
  manifests: g.manifests,
  consentDecree: g.consent_decree,
  lastEnforcement: g.last_enforcement,
})

const toWhatIfSaved = (s: RawWhatIfSaved): WhatIfSaved => ({
  savedId: s.saved_id,
  name: s.name,
  createdAt: s.created_at,
  updatedAt: s.updated_at,
  watch: s.watch,
  pool: s.pool,
  cases: s.cases.map((c) => ({ name: c.name, generatorId: c.generator_id })),
  published: s.published
    ? {
        readers: s.published.readers,
        graphUseCaseId: s.published.graph_use_case_id,
        graphName: s.published.graph_name,
        graphVersion: s.published.graph_version,
        graphSha256: s.published.graph_sha256,
        freshness: s.published.freshness,
        publishedBy: s.published.published_by,
        publishedAt: s.published.published_at,
        link: s.published.link,
      }
    : null,
})

interface RawWhatIfStep {
  n: number
  key: string
  title: string
  heading: string
  help: string | null
  add_measure?: { label: string; placeholder: string; button: string; help: string }
  preview_rows?: number
  graph_link?: string
  note?: string
}

interface RawWhatIfFrame {
  connected_sources: number
  published_count: number
  built_count: number
  draft_count: number
  facility: WhatIfFrame['facility']
  generators: RawWhatIfGenerator[]
  watched_measures: WhatIfMeasure[]
  candidate_pools: WhatIfPool[]
  headroom: WhatIfHeadroom[]
  saved: RawWhatIfSaved[]
  readers: {
    email: string
    name: string
    role_id: string
    role_label: string
    access_note: string
  }[]
  graphs: {
    use_case_id: string
    name: string
    version: string | null
    sha256: string | null
    built_at: string | null
  }[]
  document: {
    document_id: string
    file: string
    title: string
    version: string
    stage: string
    heading: string
    subtitle: string
    tabs: { key: string; label: string }[]
  } | null
  publishing: {
    publish_title: string
    manage_title: string
    call: string
    readers: {
      label: string
      placeholder: string
      empty_error: string
      caveat: string
      scope_note: string
    }
    graph: { label: string; note: string; empty: string }
    freshness: {
      label: string
      presets: { id: string; label: string; sentence: string }[]
      days: string[]
      times: string[]
      units: string[]
      default: RawWhatIfFreshness
      no_day_error: string
    }
    done: {
      title: string
      body: string
      stored: string
      link: { label: string; copied: string }
      labels: { cases: string; readers: string; graph: string; numbers: string; access: string }
      graph_note: string
      access_note: string
      audit_link: string
      buttons: { again: string; close: string }
    }
    buttons: {
      publish: string
      update: string
      unpublish: string
      manage: string
      open: string
    }
    unpublished_note: string
  }
  copy: {
    page_title: string
    banner: string
    subtitle: string
    overlay_pill: string
    data_note: string
    tabs: { key: string; label: string }[]
  }
  state_defaults: {
    tab: string
    step: number
    count: number
    watch: Record<string, boolean>
    pool: string
  }
  authoring: {
    steps: RawWhatIfStep[]
    scenario_count: { heading: string; help: string; options: number[]; default: number }
    cta_step1: string
    cta_step2: string
    cta_step3: string
  }
  runtime: {
    compare: { min: number; max: number; default: number; help: string }
    scenario_card: {
      load_label: string
      name_placeholder: string
      trace_link: string
      trace_header: string
      residual_note: string
      clean_note: string
      graph_link: string
    }
    headroom: { label: string; sentence: string; help: string }
    saved_library: {
      title: string
      empty: string
      full_help: string
      save_btn: string
      update_btn: string
      saved_flag: string
      add_btn: string
    }
    closing_note: string
  }
  graph_reference: {
    node_types: {
      key: string
      label: string
      color: string
      risk_colors?: Record<string, string>
    }[]
    relationships: string[]
    frame: { description: string; center_node: string; edge: string; max_drawn: number }
  }
}

const EMPTY_ADD_MEASURE = { label: '', placeholder: '', button: '', help: '' }

/** The frame: the facility, what can be watched, and what a scenario can draw from. */
export async function getWhatIfFrame(): Promise<WhatIfFrame> {
  const raw = validate<RawWhatIfFrame>(
    'The What-if lens',
    await request<unknown>('/whatif'),
    WHATIF_FRAME,
  )

  const steps = raw.authoring.steps
  const step = (key: string) => steps.find((s) => s.key === key)

  return {
    connectedSources: raw.connected_sources,
    publishedCount: raw.published_count,
    builtCount: raw.built_count,
    draftCount: raw.draft_count,
    facility: raw.facility,
    generators: raw.generators.map(toWhatIfGenerator),
    measures: raw.watched_measures,
    pools: raw.candidate_pools,
    headroom: raw.headroom,
    saved: raw.saved.map(toWhatIfSaved),
    readers: raw.readers.map((r) => ({
      email: r.email,
      name: r.name,
      roleId: r.role_id,
      roleLabel: r.role_label,
      accessNote: r.access_note,
    })),
    graphs: raw.graphs.map((g) => ({
      useCaseId: g.use_case_id,
      name: g.name,
      version: g.version,
      sha256: g.sha256,
      builtAt: g.built_at,
    })),
    publishing: {
      publishTitle: raw.publishing.publish_title,
      manageTitle: raw.publishing.manage_title,
      call: raw.publishing.call,
      readers: {
        label: raw.publishing.readers.label,
        placeholder: raw.publishing.readers.placeholder,
        emptyError: raw.publishing.readers.empty_error,
        caveat: raw.publishing.readers.caveat,
        scopeNote: raw.publishing.readers.scope_note,
      },
      graph: raw.publishing.graph,
      freshness: {
        label: raw.publishing.freshness.label,
        presets: raw.publishing.freshness.presets,
        days: raw.publishing.freshness.days,
        times: raw.publishing.freshness.times,
        units: raw.publishing.freshness.units,
        default: raw.publishing.freshness.default,
        noDayError: raw.publishing.freshness.no_day_error,
      },
      done: {
        title: raw.publishing.done.title,
        body: raw.publishing.done.body,
        stored: raw.publishing.done.stored,
        link: raw.publishing.done.link,
        labels: raw.publishing.done.labels,
        graphNote: raw.publishing.done.graph_note,
        accessNote: raw.publishing.done.access_note,
        auditLink: raw.publishing.done.audit_link,
        buttons: raw.publishing.done.buttons,
      },
      buttons: raw.publishing.buttons,
      unpublishedNote: raw.publishing.unpublished_note,
    },
    document:
      raw.document === null || raw.document === undefined
        ? null
        : {
            documentId: raw.document.document_id,
            file: raw.document.file,
            title: raw.document.title,
            version: raw.document.version,
            stage: raw.document.stage,
            heading: raw.document.heading,
            subtitle: raw.document.subtitle,
            tabs: raw.document.tabs,
          },
    copy: {
      pageTitle: raw.copy.page_title,
      banner: raw.copy.banner,
      subtitle: raw.copy.subtitle,
      overlayPill: raw.copy.overlay_pill,
      dataNote: raw.copy.data_note,
      tabs: raw.copy.tabs,
    },
    /* The defaults arrive as an object of flags because that is how the prototype held
       them; the store wants the keys that are on, which is the same fact in the shape
       the UI uses. */
    defaults: {
      tab: raw.state_defaults.tab,
      step: raw.state_defaults.step,
      count: raw.state_defaults.count,
      watch: Object.entries(raw.state_defaults.watch)
        .filter(([, on]) => on)
        .map(([key]) => key),
      pool: raw.state_defaults.pool,
    },
    authoring: {
      steps: steps.map((s) => ({
        n: s.n,
        key: s.key,
        title: s.title,
        heading: s.heading,
        /* Defaulted here so every component reads a string. Step 3's guarantee lands in
           `reviewNote` instead, which is where its `note` goes. */
        help: s.help ?? '',
      })),
      /* Step 1's add-measure copy, step 2's preview size and step 3's note live on
         their own steps in the package; lifted here so each component reads one flat
         object rather than hunting the array for its own key. */
      addMeasure: step('watch')?.add_measure ?? EMPTY_ADD_MEASURE,
      previewRows: step('pool')?.preview_rows ?? 8,
      reviewNote: step('review')?.note ?? '',
      scenarioCount: raw.authoring.scenario_count,
      cta: [raw.authoring.cta_step1, raw.authoring.cta_step2, raw.authoring.cta_step3],
      graphLink: step('pool')?.graph_link ?? '',
    },
    runtime: {
      compare: raw.runtime.compare,
      card: {
        loadLabel: raw.runtime.scenario_card.load_label,
        namePlaceholder: raw.runtime.scenario_card.name_placeholder,
        traceLink: raw.runtime.scenario_card.trace_link,
        traceHeader: raw.runtime.scenario_card.trace_header,
        graphLink: raw.runtime.scenario_card.graph_link,
      },
      headroom: raw.runtime.headroom,
      library: {
        title: raw.runtime.saved_library.title,
        empty: raw.runtime.saved_library.empty,
        fullHelp: raw.runtime.saved_library.full_help,
        saveBtn: raw.runtime.saved_library.save_btn,
        updateBtn: raw.runtime.saved_library.update_btn,
        savedFlag: raw.runtime.saved_library.saved_flag,
        addBtn: raw.runtime.saved_library.add_btn,
      },
      closingNote: raw.runtime.closing_note,
    },
    graphReference: {
      nodeTypes: raw.graph_reference.node_types.map((t) => ({
        key: t.key,
        label: t.label,
        color: t.color,
        riskColors: t.risk_colors,
      })),
      relationships: raw.graph_reference.relationships,
      frame: {
        description: raw.graph_reference.frame.description,
        centerNode: raw.graph_reference.frame.center_node,
        edge: raw.graph_reference.frame.edge,
        maxDrawn: raw.graph_reference.frame.max_drawn,
      },
    },
  }
}

/**
 * Ask the graph whether a typed measure grounds.
 *
 * The answer comes from the server because the *graph* decides what grounds — the
 * keyword list is deliberately absent from the frame payload, so this is the only way
 * to ask and a refusal cannot be faked client-side.
 */
export async function resolveWhatIfMeasure(text: string): Promise<WhatIfResolution> {
  const raw = validate<{
    text: string
    verdict: 'resolved' | 'grounds_not_inherited' | 'refused'
    measure_key: string | null
    tone: 'ok' | 'warn' | 'bad'
    title: string
    body: string
  }>(
    'The measure resolution',
    await request<unknown>('/whatif/resolve', { method: 'POST', body: { text } }),
    WHATIF_RESOLUTION,
  )
  return {
    text: raw.text,
    verdict: raw.verdict,
    measureKey: raw.measure_key,
    tone: raw.tone,
    title: raw.title,
    body: raw.body,
  }
}

interface RawWhatIfScenario {
  generator: RawWhatIfGenerator
  measures: {
    key: string
    label: string
    source: string
    grounds: string
    unit: string
    value: number | boolean
    value_text: string
    inherited: number | boolean
    inherited_text: string
    baseline: number | boolean | null
    baseline_text: string | null
    appetite: number | null
    breached: boolean
    moved: boolean
  }[]
  sources: { key: string; label: string; line: string }[]
  flagged: boolean
  clean_note: string | null
  residual_note: string
  subgraph: {
    nodes: WhatIfSubgraphNode[]
    edges: WhatIfSubgraphEdge[]
    relationships: string[]
  }
}

/** What admitting one load would inherit. Recomputed every time; nothing is stored. */
export async function computeWhatIfScenario(input: {
  generatorId: string
  watch: string[]
}): Promise<WhatIfScenario> {
  const raw = validate<RawWhatIfScenario>(
    'The scenario',
    await request<unknown>('/whatif/scenario', {
      method: 'POST',
      body: { generator_id: input.generatorId, watch: input.watch },
    }),
    WHATIF_SCENARIO,
  )
  return {
    generator: toWhatIfGenerator(raw.generator),
    measures: raw.measures.map((m) => ({
      key: m.key,
      label: m.label,
      source: m.source,
      grounds: m.grounds,
      unit: m.unit,
      value: m.value,
      valueText: m.value_text,
      inherited: m.inherited,
      inheritedText: m.inherited_text,
      baseline: m.baseline,
      baselineText: m.baseline_text,
      appetite: m.appetite,
      breached: m.breached,
      moved: m.moved,
    })),
    sources: raw.sources,
    flagged: raw.flagged,
    cleanNote: raw.clean_note,
    residualNote: raw.residual_note,
    subgraph: raw.subgraph,
  }
}

/**
 * Save or update a library entry — the **whole scenario**, frame included.
 *
 * The frame travels with the cases because it is what makes them mean anything: a case
 * re-opened without the measures it was judged against and the pool it was drawn from is
 * a load with no question attached. Stores the admitted loads, never the figures.
 */
export async function saveWhatIfScenario(input: {
  savedId?: string | null
  name: string
  watch: string[]
  pool: string
  cases: WhatIfCase[]
}): Promise<{ saved: WhatIfSaved[]; savedId: string }> {
  const raw = validate<{ saved: RawWhatIfSaved[]; saved_id: string }>(
    'The saved scenario',
    await request<unknown>('/whatif/saved', {
      method: 'POST',
      body: {
        saved_id: input.savedId ?? null,
        name: input.name,
        watch: input.watch,
        pool: input.pool,
        cases: input.cases.map((c) => ({ name: c.name, generator_id: c.generatorId })),
      },
    }),
    WHATIF_SAVED_WRITE,
  )
  return { saved: raw.saved.map(toWhatIfSaved), savedId: raw.saved_id }
}

/**
 * Publish a saved scenario: who is told, which published graph answers it, how often.
 *
 * `as` is the signed-in address, sent for the reason every "who did this" field in this
 * app is sent — the identity is client-held and the server has nothing to look it up
 * from. The server refuses a reader outside the directory and a graph that is not
 * currently published, so neither can be invented here.
 */
export async function publishWhatIfScenario(input: {
  savedId: string
  readers: string[]
  graphUseCaseId: string
  freshness: WhatIfFreshness
  as?: string | null
}): Promise<WhatIfSaved[]> {
  const query = input.as ? `?as=${encodeURIComponent(input.as)}` : ''
  const raw = validate<{ saved: RawWhatIfSaved[]; saved_id: string }>(
    'The published scenario',
    await request<unknown>(`/whatif/saved/${encodeURIComponent(input.savedId)}/publish${query}`, {
      method: 'POST',
      body: {
        readers: input.readers,
        graph_use_case_id: input.graphUseCaseId,
        freshness: input.freshness,
      },
    }),
    WHATIF_SAVED_WRITE,
  )
  return raw.saved.map(toWhatIfSaved)
}

/** Stop a scenario being readable. It stays in the library — that is the promise made. */
export async function unpublishWhatIfScenario(savedId: string): Promise<WhatIfSaved[]> {
  const raw = validate<{ saved: RawWhatIfSaved[]; saved_id: string }>(
    'The unpublished scenario',
    await request<unknown>(`/whatif/saved/${encodeURIComponent(savedId)}/publish`, {
      method: 'DELETE',
    }),
    WHATIF_SAVED_WRITE,
  )
  return raw.saved.map(toWhatIfSaved)
}

/** Remove a library entry. Any open column stays put, just unlinked. */
export async function deleteWhatIfScenario(savedId: string): Promise<WhatIfSaved[]> {
  const raw = validate<{ saved: RawWhatIfSaved[] }>(
    'The saved scenario',
    await request<unknown>(`/whatif/saved/${encodeURIComponent(savedId)}`, {
      method: 'DELETE',
    }),
    WHATIF_SAVED_PAYLOAD,
  )
  return raw.saved.map(toWhatIfSaved)
}

/* ---------------- Reports ---------------- */

/*
 * The report section: five written reports over four rosters.
 *
 * **Every figure here was computed by the server**, including each chart's series and
 * each table's order — a report is a question re-asked of the roster, not a stored
 * result, so nothing on this side sums a column. The one thing the client decides is
 * the chart *form*, and `AnswerChart` already owns that decision.
 *
 * A row is deliberately **not** camelCased. Its keys are the field keys the report's own
 * columns name (`last_enf`, `gen_state`), and a table looks a cell up by that key —
 * renaming them here would leave every column reading its header from the data and its
 * value from nowhere.
 */

/**
 * A summary tile, as the package's report rendered it.
 *
 * `tone` excludes `info` because these are the four tones a `Stat` accepts and a tile
 * *is* a `Stat` — the report's own reading of its figure, carried through unchanged.
 */
export interface ReportTile {
  label: string
  /** Formatted by the report: "$1.80M", "26 / 46", "Class I". */
  value: string
  unit: string
  tone: Exclude<Tone, 'info'> | null
}

/** One labelled segment of a report's footer — "Source.", "Confidence.", "Bridge.". */
export interface ReportFootnote {
  label: string
  text: string
}

export interface ReportColumn {
  key: string
  label: string
  /** `num` is right-aligned and tabular; `cat` reads as text. */
  kind: 'num' | 'cat'
}

/** A cell is whatever the roster carries — a trace's custody chain is a list. */
export type ReportCell = string | number | boolean | string[]
export type ReportRow = Record<string, ReportCell>

/**
 * Charts are the answer-chart shape exactly, so one component draws both.
 *
 * A report's chart may carry a **companion** — the share beside the ranking, as the package's
 * decree report draws them side by side. It is a chart in its own right, computed on the
 * server; the block does not become a container of two, because the second answers a question
 * the first raises rather than standing alone.
 */
export type ReportChart = Extract<AnswerBlock, { type: 'chart' }> & {
  companion?: Extract<AnswerBlock, { type: 'chart' }> | null
}

export type ReportBlock =
  | ReportChart
  | {
      type: 'table'
      title: string
      columns: ReportColumn[]
      rows: ReportRow[]
      /** What the ranking is, stated: an unexplained order reads as significant. */
      sortedBy: string | null
    }
  | {
      type: 'facilities'
      title: string
      columns: ReportColumn[]
      rows: ReportRow[]
      /** The facility the scorecard is about, so its row can be marked. */
      subject: string | null
      charts: ReportChart[]
    }
  | {
      type: 'quarterly'
      title: string
      columns: ReportColumn[]
      rows: ReportRow[]
      charts: ReportChart[]
    }
  | { type: 'traces'; title: string; columns: ReportColumn[]; rows: ReportRow[] }

/** One card in the section list. */
export interface ReportSummary {
  reportId: string
  reportTag: string
  heading: string
  subtitle: string
  question: string
  spine: string
  /** Rows this report is about, and rows on its spine — 4 of 36 is the report. */
  rowCount: number
  spineTotal: number
  blockKinds: string[]
  tiles: ReportTile[]
}

/**
 * A **rendered** report a dataset ships as a finished document rather than as a question.
 *
 * EPA has none: its five reports are computed per request from the rosters, which is what makes a
 * figure there current rather than stored. CAPEX ships three standalone HTML documents and no roster to
 * compute from, so they are listed as documents and every figure stays inside the file — transcribing
 * one into a component is the change that would look right on screen and break the section's premise.
 *
 * Every field here is read out of the document itself by `npm run ingest:capex`, including the title, so
 * the Library prints the name the report gives itself.
 */
export interface ReportDocument {
  documentId: string
  /** The id baked into the document, which is what selects the report inside it. */
  reportId: string
  /** The file, relative to the dataset's report folder. Resolved to a URL by the page, not here. */
  file: string
  /**
   * The specification document that says how this report is built, or null where the dataset ships none.
   *
   * Framed while the report is being built, in place of the narrated build steps — the dataset's own
   * account of what the agent resolved and which measures it bound, rather than a summary of composing a
   * report in general. Resolved to a URL by the page like `file`, and nullable because a document
   * predating the specs is a document with none rather than a malformed one.
   */
  specFile: string | null
  title: string
  subtitle: string
  category: string
  /** One of the governance state pool's keys, so a card and a chip cannot disagree about it. */
  status: string
  version: string
  slug: string
  author: string
  /** The document's own refresh sentence — "Daily 07:00 UTC" — rather than its cron. */
  refresh: string
  updatedAt: string
}

export interface ReportsIndex {
  connectedSources: number
  /**
   * The publish gate. `publishedCount` is the precondition; `builtCount` and `draftCount`
   * are what the empty state needs to name the right fix — "finish the wizard" and
   * "press Publish" are different problems.
   */
  publishedCount: number
  builtCount: number
  draftCount: number
  /**
   * The rendered documents this dataset ships, and its authoring exploration.
   *
   * Both ride on the payload whether or not a graph is published, because the publish gate is about
   * questions asked of a graph and a rendered document asked nothing of one.
   */
  documents: ReportDocument[]
  authoringDocument: string | null
  /** Every published graph a question may be asked of, newest build first. */
  graphs: ReportGraph[]
  /** The default — the newest published — for a report opened straight off the section. */
  graph: ReportGraph | null
  reports: ReportSummary[]
  saved: SavedReport[]
  /** Null while either gate is closed — the wizard has nothing to ask against. */
  authoring: ReportAuthoring | null
  /** The three tabs' payload. Null while the publish gate is closed, like `authoring`. */
  governance: ReportGovernance | null
}

export interface Report {
  reportId: string
  reportTag: string
  heading: string
  subtitle: string
  badge: string
  /** Only two of the five carry a lead note. */
  note: string | null
  title: string
  question: string
  spine: string
  rowCount: number
  spineTotal: number
  /** The question as a sentence, with its assumptions filled in. */
  reading: string
  assumptions: { slot: string; label: string }[]
  /** What this report can be sliced by — rendered as its chip bar. */
  facets: ReportFacet[]
  /** The frame it was built under, in values: what a chip re-asks it with. */
  frame: ReportFrame
  tiles: ReportTile[]
  footer: ReportFootnote[]
  blocks: ReportBlock[]
  sourceTrace: string
  /** The published graph this was answered against — null only before one exists. */
  graph: ReportGraph | null
}

/**
 * The published graph the section is asked of.
 *
 * A report is available once a graph has been published, so the content that answered it
 * is reportable — the same claim Ask makes about its own answers, for the same reason.
 */
export interface ReportGraph {
  useCaseId: string
  name: string
  domainId: string | null
  version: string | null
  /** Null on a graph that is no longer published — there is no live content to name. */
  sha256: string | null
  builtAt: string | null
  /**
   * Who published it: the account that pressed Publish, which the publish route is told as
   * `?as=`. Null only where nothing is published; the tenant's own account stands in for a
   * version published before this was recorded.
   */
  publishedBy: string | null
  entityCount: number | null
  relationshipCount: number | null
  /** False on a saved report whose graph has since been unpublished. */
  live: boolean
}

const REPORT_TILE = shape({
  label: str,
  value: str,
  unit: str,
  tone: nullable(oneOf(['good', 'warn', 'crit', 'neutral'])),
})

const REPORT_COLUMNS = arrayOf(shape({ key: str, label: str, kind: oneOf(['num', 'cat']) }))
/* A row's own keys are the report's field keys, so only its object-ness is checked here.
   The columns are what a table renders, and every one of those is checked above. */
const REPORT_ROWS = arrayOf(shape({}))

/* One field list, two shapes: a chart, and a chart that may carry a companion. */
const REPORT_CHART_FIELDS = {
  type: oneOf(['chart']),
  chart: oneOf(['bar', 'line', 'column', 'grouped', 'pie', 'donut']),
  title: str,
  x_label: nullable(str),
  y_label: nullable(str),
  note: nullable(str),
  width: nullable(num),
  series: nullable(arrayOf(shape({ key: str, label: str }))),
  data: arrayOf(
    shape({
      label: str,
      value: num,
      tone: nullable(oneOf(['good', 'warn', 'crit'])),
      values: nullable(objectOnly),
    }),
  ),
}

const REPORT_CHART = shape(REPORT_CHART_FIELDS)

const REPORT_CHART_WITH_COMPANION = shape({
  ...REPORT_CHART_FIELDS,
  companion: nullable(shape(REPORT_CHART_FIELDS)),
})

const REPORT_BLOCK = variant('type', {
  chart: REPORT_CHART_WITH_COMPANION,
  table: shape({
    title: str,
    columns: REPORT_COLUMNS,
    rows: REPORT_ROWS,
    sorted_by: nullable(str),
  }),
  facilities: shape({
    title: str,
    columns: REPORT_COLUMNS,
    rows: REPORT_ROWS,
    subject: nullable(str),
    charts: arrayOf(REPORT_CHART),
  }),
  quarterly: shape({
    title: str,
    columns: REPORT_COLUMNS,
    rows: REPORT_ROWS,
    charts: arrayOf(REPORT_CHART),
  }),
  traces: shape({ title: str, columns: REPORT_COLUMNS, rows: REPORT_ROWS }),
})

/* Nullable because it is null until a graph is published, which is the gate itself. */
const REPORT_GRAPH_FIELDS = {
  use_case_id: str,
  name: str,
  domain_id: nullable(str),
  version: nullable(str),
  sha256: nullable(str),
  built_at: nullable(str),
  published_by: nullable(str),
  entity_count: nullable(num),
  relationship_count: nullable(num),
  live: nullable(bool),
}
const REPORT_GRAPH = nullable(shape(REPORT_GRAPH_FIELDS))
const REPORT_GRAPHS = arrayOf(shape(REPORT_GRAPH_FIELDS))

/* ---------------- Reports: authoring ---------------- */

/*
 * Authoring a report is three steps and two calls, and the split is the promise the page
 * makes: **"nothing runs against your compliance data until you're happy with it"**.
 *
 *   POST /reports/read   → a sentence and a frame. No figures. Paced, because reading a
 *                          question back is the one act here that reads as a model call.
 *   POST /reports/build  → the report. Every figure computed server-side, and the payload
 *                          says whether it is the *written* report or a **generated** one.
 *
 * A saved report holds its frame and never its figures, so re-opening one re-asks it —
 * the same rule the What-if library follows.
 */

/** One option on a picker, with the tenant's own gloss. */
export interface ReportOption {
  value: string
  label: string
  detail: string
}

/** The three questions a frame answers, and what each may be set to. */
export interface ReportOpts {
  scope: { question: string; options: ReportOption[] }
  measure: { question: string; options: ReportOption[] }
  horizon: { question: string; options: ReportOption[] }
}

/** A facet a generator report can be sliced by, with the values present in the roster. */
export interface ReportFacet {
  key: string
  label: string
  values: { value: string; label: string; count: number }[]
}

export interface ReportAuthoring {
  opts: ReportOpts
  facets: ReportFacet[]
  defaults: { scope: string; measure: string; horizon: string }
}

/** What a report is asked under. Sent to /reports/build and stored in the library. */
export interface ReportFrame {
  reportId: string
  /** The published graph this is asked of — part of the frame, not of the request. */
  useCaseId: string | null
  scope: string
  measure: string
  horizon: string
  filters: { key: string; value: string }[]
}

/** A filter as the built report reports it back, with both labels resolved. */
export interface ReportFilter {
  key: string
  label: string
  value: string
  valueLabel: string
}

/** The read-back: what the question was understood as, before anything runs. */
export interface ReportReadBack {
  question: string
  /** The graph the question is being asked of, echoed back. */
  graph: ReportGraph | null
  /** False is a real outcome: it was read as the register and says so. */
  matched: boolean
  why: string
  reportTag: string
  heading: string
  spine: string
  frame: ReportFrame
  reading: string
  assumptions: { slot: string; label: string }[]
  caveats: string[]
}

/** A built report: a `Report`, plus what makes it this frame's rather than the written one. */
export interface BuiltReport extends Report {
  /** `written` = the frame the report was written for; `generated` = re-asked. */
  variant: 'written' | 'generated'
  filters: ReportFilter[]
  /** Null unless the spine has no summary to compute — said rather than left blank. */
  summaryNote: string | null
  caveats: string[]
}

export interface SavedReport {
  savedId: string
  name: string
  question: string | null
  reportId: string
  /** The graph it was asked of — `live: false` if that graph is no longer published. */
  graph: ReportGraph | null
  /** The signed-in address the browser sent when it was saved. */
  savedBy: string | null
  /**
   * The roles this report is meant for.
   *
   * A demo control, not a permission: the role is client-held, so it narrows what the section
   * shows a reader rather than what the API will serve. Defaults to every role.
   */
  viewerRoles: { roleId: string; label: string }[]
  reportTag: string
  heading: string
  scope: string
  measure: string
  horizon: string
  scopeLabel: string
  measureLabel: string
  horizonLabel: string
  filters: ReportFilter[]
  savedAt: string
}

const REPORT_OPTS = shape({
  scope: shape({ q: str, options: arrayOf(shape({ value: str, label: str, d: str })) }),
  measure: shape({ q: str, options: arrayOf(shape({ value: str, label: str, d: str })) }),
  horizon: shape({ q: str, options: arrayOf(shape({ value: str, label: str, d: str })) }),
})

const REPORT_AUTHORING = nullable(
  shape({
    opts: REPORT_OPTS,
    facets: arrayOf(
      shape({
        key: str,
        label: str,
        values: arrayOf(shape({ value: str, label: str, count: num })),
      }),
    ),
    defaults: shape({ scope: str, measure: str, horizon: str }),
  }),
)

const REPORT_FILTERS = arrayOf(shape({ key: str, label: str, value: str, value_label: str }))

const REPORT_FRAME = shape({
  report_id: str,
  use_case_id: nullable(str),
  scope: str,
  measure: str,
  horizon: str,
  filters: arrayOf(shape({ key: str, value: str })),
})

const REPORT_READBACK = shape({
  question: str,
  graph: REPORT_GRAPH,
  matched: bool,
  why: str,
  report_tag: str,
  heading: str,
  spine: str,
  frame: REPORT_FRAME,
  reading: str,
  assumptions: arrayOf(shape({ slot: str, label: str })),
  caveats: arrayOf(str),
})

const REPORT_SAVED_ROW = shape({
  saved_id: str,
  name: str,
  question: nullable(str),
  report_id: str,
  use_case_id: nullable(str),
  graph: REPORT_GRAPH,
  saved_by: nullable(str),
  viewer_roles: arrayOf(shape({ role_id: str, label: str })),
    report_tag: str,
    heading: str,
    scope: str,
    measure: str,
    horizon: str,
    scope_label: str,
    measure_label: str,
    horizon_label: str,
  filters: REPORT_FILTERS,
  saved_at: str,
})

const REPORT_SAVED = arrayOf(REPORT_SAVED_ROW)
const REPORT_SAVED_PAYLOAD = shape({ saved: REPORT_SAVED })



/*
 * ---------------- the section's governance view ----------------
 *
 * The three tabs — Library, Author, Operations & audience — are one payload, computed by the
 * server on every request. Nothing here is figures a component could recompute: the chip counts,
 * the floor line, each entitlement cell and every check arrive decided, because a governance grid
 * is exactly where a second source becomes a second answer.
 */

/** One card in the Library, written or composed. */
export interface GovernedReport {
  reportId: string
  /** `written` is one of the tenant's five definitions; `saved` is one someone composed. */
  kind: 'written' | 'saved'
  savedId: string | null
  reportTag: string
  title: string
  /** The report's own question, quoted on the card rather than paraphrased. */
  question: string
  lead: string
  status: string
  statusLabel: string
  tone: Tone
  version: string | null
  author: string | null
  category: string
  asOf: string | null
  schedule: string
  /** null when nothing was recorded — never the word "none" pretending to be an approval. */
  approval: string | null
  note: string | null
  floor: string | null
  parameterized: boolean
  rowCount: number
  spineTotal: number
  /** Shared with nobody — a decision Share made, not an audience that failed to resolve. */
  private: boolean
  /** How many role ids the audience *names*, beside how many resolved in `entitledRoles`. */
  audienceNamed: number
  /**
   * The roles the audience names, resolved.
   *
   * **Stated, not enforced.** A per-row `access` block once said whether the calling role could open
   * a report and what it had requested; it and its endpoint were removed. Nothing replaced them,
   * which is the honest position: the role is client-held and the login authenticates by shape, so
   * the API serves every row to a caller that names none and a gate built on this was never access
   * control. `as_role` still narrows the *saved* rows and still reports `viewer.notEntitledCount`.
   */
  entitledRoles: { roleId: string; label: string }[]
}

export interface GovernanceStatus {
  key: string
  label: string
  tone: Tone
  count: number
}

/** The data scope a persona carries — declared, and the page says it is not applied. */
export interface DataScopeRow {
  roleId: string
  label: string
  scope: string
  predicate: string
  grain: string
  masked: string
  mayAuthor: boolean
}

export interface EntitlementCell {
  reportId: string
  state: string
  label: string
  tone: Tone
}

/**
 * The publish dialog's copy.
 *
 * Authored in the governance seed rather than shipped by the package, because the prototype's own
 * dialog states that "a Domain Architect approves before the audience sees it" — a claim that
 * stopped being true when publish → approve → activate collapsed to publish/unpublish. A freshness
 * preset carries its own `sentence` so the line under the select is the tenant's words.
 */
export interface ReportPublishing {
  title: string
  republishTitle: string
  lead: string
  name: { label: string; help: string; placeholder: string }
  readers: {
    label: string
    placeholder: string
    empty: string
    note: string
    caveat: string
    localCaveat: string
  }
  freshness: {
    label: string
    presets: { id: string; label: string; sentence: string }[]
    default: string
  }
  foot: string
  buttons: { publish: string; republish: string; cancel: string }
}

export interface ReportGovernance {
  reports: GovernedReport[]
  /**
   * Definitions the tenant has that nothing governs — normally empty.
   *
   * A report is a definition (`db.reports.reports`, ingested) plus the decision to govern it
   * (`governance.reports`, seeded). Delete drops the second, and the row then leaves the Library with
   * nothing saying why: the list is just shorter, which reads as data loss. This is that gap, named,
   * so the page can state it instead of leaving somebody to count cards. It is also what a **stale
   * process** looks like — one that deleted a row before `db.json` was re-seeded keeps serving the
   * short list from memory, and this says which one it is short.
   */
  ungoverned: { reportId: string; reportTag: string; title: string }[]
  /** The command that re-authors them. Served, so one string says it everywhere. */
  restore: string
  /**
   * Who the publish dialog can pick, and what each of them may see.
   *
   * The tenant's own users with the persona they sign in as. A person is picked and their **role**
   * is what a report's audience stores, because `viewer_roles` is the audience model the
   * entitlement matrix and `?as_role=` already read — an address here would be a second one.
   *
   * `scope` and `masked` are the persona's *declared* data scope, the same `data_scope` row gate 2
   * renders. Stated beside a name, never applied: no roster in this section is filtered per
   * persona, so a count would claim a filter that never ran.
   */
  people: {
    email: string
    name: string
    roleId: string
    roleLabel: string
    scope: string | null
    masked: string | null
  }[]
  /** The publish dialog's copy, authored by `npm run seed:governance`. */
  publishing: ReportPublishing
  statuses: GovernanceStatus[]
  categories: string[]
  viewer: {
    roleId: string | null
    label: string | null
    entitledCount: number
    notEntitledCount: number
    scope: DataScopeRow | null
  }
  author: { mayAuthor: boolean; note: string; authors: string[] }
  gates: {
    note: string
    entitlement: {
      note: string
      columns: { reportId: string; title: string; reportTag: string; status: string }[]
      roles: { roleId: string; label: string; cells: EntitlementCell[] }[]
    }
    dataScope: { note: string; rows: DataScopeRow[] }
  }
  schedule: {
    reportId: string
    title: string
    schedule: string
    asOf: string | null
    floor: string | null
    parameterized: boolean
    statusLabel: string
    tone: Tone
  }[]
  audit: {
    reportId: string
    title: string
    act: string
    actor: string
    at: string | null
    detail: string
    tone: Tone
  }[]
  publishChecks: {
    reportId: string
    title: string
    checks: { key: string; label: string; pass: boolean; detail: string }[]
  }[]
}

const TONE = oneOf(['good', 'warn', 'crit', 'info', 'neutral'])

const GOVERNED_REPORT = shape({
  report_id: str,
  kind: oneOf(['written', 'saved']),
  saved_id: nullable(str),
  report_tag: str,
  title: str,
  question: str,
  lead: str,
  status: str,
  status_label: str,
  tone: TONE,
  version: nullable(str),
  author: nullable(str),
  category: str,
  as_of: nullable(str),
  schedule: str,
  approval: nullable(str),
  note: nullable(str),
  floor: nullable(str),
  parameterized: bool,
  row_count: num,
  spine_total: num,
  private: bool,
  audience_named: num,
  entitled_roles: arrayOf(shape({ role_id: str, label: str })),
})

const DATA_SCOPE_ROW = shape({
  role_id: str,
  /*
   * Absent on the banner's own row.
   *
   * Gate 2's rows are resolved against `auth_roles` on the way out and carry a label; the
   * viewer's scope is the governance row itself, and the persona's name is already beside it as
   * `viewer.label`. So the label is optional here and falls back to the id rather than being
   * required of a payload that has no reason to repeat it.
   */
  label: nullable(str),
  scope: str,
  predicate: str,
  grain: str,
  masked: str,
  may_author: bool,
})

const REPORT_GOVERNANCE = shape({
  reports: arrayOf(GOVERNED_REPORT),
  ungoverned: arrayOf(shape({ report_id: str, report_tag: str, title: str })),
  restore: str,
  people: arrayOf(
    shape({
      email: str,
      name: str,
      role_id: str,
      role_label: str,
      /* Nullable: a persona with no `data_scope` row has no declared scope to state, and an
         invented one would be the dialog answering for gate 2. */
      scope: nullable(str),
      masked: nullable(str),
    }),
  ),
  publishing: shape({
    title: str,
    republish_title: str,
    lead: str,
    name: shape({ label: str, help: str, placeholder: str }),
    readers: shape({
      label: str,
      placeholder: str,
      empty: str,
      note: str,
      caveat: str,
      local_caveat: str,
    }),
    freshness: shape({
      label: str,
      presets: arrayOf(shape({ id: str, label: str, sentence: str })),
      default: str,
    }),
    foot: str,
    buttons: shape({ publish: str, republish: str, cancel: str }),
  }),
  statuses: arrayOf(shape({ key: str, label: str, tone: TONE, count: num })),
  categories: arrayOf(str),
  viewer: shape({
    role_id: nullable(str),
    label: nullable(str),
    entitled_count: num,
    not_entitled_count: num,
    scope: nullable(DATA_SCOPE_ROW),
  }),
  author: shape({ may_author: bool, note: str, authors: arrayOf(str) }),
  gates: shape({
    note: str,
    entitlement: shape({
      note: str,
      columns: arrayOf(shape({ report_id: str, title: str, report_tag: str, status: str })),
      roles: arrayOf(
        shape({
          role_id: str,
          label: str,
          cells: arrayOf(shape({ report_id: str, state: str, label: str, tone: TONE })),
        }),
      ),
    }),
    data_scope: shape({ note: str, rows: arrayOf(DATA_SCOPE_ROW) }),
  }),
  schedule: arrayOf(
    shape({
      report_id: str,
      title: str,
      schedule: str,
      as_of: nullable(str),
      floor: nullable(str),
      parameterized: bool,
      status_label: str,
      tone: TONE,
    }),
  ),
  audit: arrayOf(
    shape({
      report_id: str,
      title: str,
      act: str,
      actor: str,
      at: nullable(str),
      detail: str,
      tone: TONE,
    }),
  ),
  publish_checks: arrayOf(
    shape({
      report_id: str,
      title: str,
      checks: arrayOf(shape({ key: str, label: str, pass: bool, detail: str })),
    }),
  ),
})

interface RawDataScope {
  role_id: string
  label?: string | null
  scope: string
  predicate: string
  grain: string
  masked: string
  may_author: boolean
}

const toScope = (s: RawDataScope): DataScopeRow => ({
  roleId: s.role_id,
  label: s.label ?? s.role_id,
  scope: s.scope,
  predicate: s.predicate,
  grain: s.grain,
  masked: s.masked,
  mayAuthor: s.may_author,
})

/* eslint-disable @typescript-eslint/no-explicit-any */
const toGovernance = (g: any): ReportGovernance => ({
  reports: g.reports.map((r: any) => ({
    reportId: r.report_id,
    kind: r.kind,
    savedId: r.saved_id ?? null,
    reportTag: r.report_tag,
    title: r.title,
    question: r.question,
    lead: r.lead,
    status: r.status,
    statusLabel: r.status_label,
    tone: r.tone,
    version: r.version,
    author: r.author,
    category: r.category,
    asOf: r.as_of,
    schedule: r.schedule,
    approval: r.approval,
    note: r.note,
    floor: r.floor,
    parameterized: r.parameterized,
    rowCount: r.row_count,
    spineTotal: r.spine_total,
    private: r.private,
    audienceNamed: r.audience_named,
    entitledRoles: r.entitled_roles.map((e: any) => ({ roleId: e.role_id, label: e.label })),
  })),
  ungoverned: (g.ungoverned ?? []).map((r: any) => ({
    reportId: r.report_id,
    reportTag: r.report_tag,
    title: r.title,
  })),
  restore: g.restore,
  people: (g.people ?? []).map((p: any) => ({
    email: p.email,
    name: p.name,
    roleId: p.role_id,
    roleLabel: p.role_label,
    scope: p.scope,
    masked: p.masked,
  })),
  publishing: {
    title: g.publishing.title,
    republishTitle: g.publishing.republish_title,
    lead: g.publishing.lead,
    name: g.publishing.name,
    readers: {
      label: g.publishing.readers.label,
      placeholder: g.publishing.readers.placeholder,
      empty: g.publishing.readers.empty,
      note: g.publishing.readers.note,
      caveat: g.publishing.readers.caveat,
      localCaveat: g.publishing.readers.local_caveat,
    },
    freshness: g.publishing.freshness,
    foot: g.publishing.foot,
    buttons: g.publishing.buttons,
  },
  statuses: g.statuses,
  categories: g.categories,
  viewer: {
    roleId: g.viewer.role_id,
    label: g.viewer.label,
    entitledCount: g.viewer.entitled_count,
    notEntitledCount: g.viewer.not_entitled_count,
    scope: g.viewer.scope ? toScope(g.viewer.scope) : null,
  },
  author: { mayAuthor: g.author.may_author, note: g.author.note, authors: g.author.authors },
  gates: {
    note: g.gates.note,
    entitlement: {
      note: g.gates.entitlement.note,
      columns: g.gates.entitlement.columns.map((c: any) => ({
        reportId: c.report_id,
        title: c.title,
        reportTag: c.report_tag,
        status: c.status,
      })),
      roles: g.gates.entitlement.roles.map((r: any) => ({
        roleId: r.role_id,
        label: r.label,
        cells: r.cells.map((c: any) => ({
          reportId: c.report_id,
          state: c.state,
          label: c.label,
          tone: c.tone,
        })),
      })),
    },
    dataScope: {
      note: g.gates.data_scope.note,
      rows: g.gates.data_scope.rows.map(toScope),
    },
  },
  schedule: g.schedule.map((s: any) => ({
    reportId: s.report_id,
    title: s.title,
    schedule: s.schedule,
    asOf: s.as_of,
    floor: s.floor,
    parameterized: s.parameterized,
    statusLabel: s.status_label,
    tone: s.tone,
  })),
  audit: g.audit.map((a: any) => ({
    reportId: a.report_id,
    title: a.title,
    act: a.act,
    actor: a.actor,
    at: a.at,
    detail: a.detail,
    tone: a.tone,
  })),
  publishChecks: g.publish_checks.map((p: any) => ({
    reportId: p.report_id,
    title: p.title,
    checks: p.checks,
  })),
})
/* eslint-enable @typescript-eslint/no-explicit-any */

const REPORTS_INDEX = shape({
  connected_sources: num,
  /* Null while the publish gate is closed: the section has no library to govern until a graph
     is published, and a governance block full of empty lists would read as "nothing governed". */
  governance: nullable(REPORT_GOVERNANCE),
  published_count: num,
  built_count: num,
  draft_count: num,
  graph: REPORT_GRAPH,
  graphs: REPORT_GRAPHS,
  saved: REPORT_SAVED,
  authoring: REPORT_AUTHORING,
  documents: arrayOf(
    shape({
      document_id: str,
      report_id: str,
      file: str,
      /* Nullable, and the ingest still refuses to write a document without one: an absent spec can
         only mean a document from before they existed, which is exactly what nullable is for.
         Declaring it `str` would refuse a whole payload over a field nothing on the page needs. */
      spec_file: nullable(str),
      title: str,
      subtitle: str,
      category: str,
      status: str,
      version: str,
      slug: str,
      author: str,
      refresh: str,
      updated_at: str,
    }),
  ),
  authoring_document: nullable(str),
  reports: arrayOf(
    shape({
      report_id: str,
      report_tag: str,
      heading: str,
      subtitle: str,
      question: str,
      spine: str,
      row_count: num,
      spine_total: num,
      block_kinds: arrayOf(str),
      tiles: arrayOf(REPORT_TILE),
    }),
  ),
})

/* One report's fields, shared by the written payload and the built one — a built report
   is the same report asked under a chosen frame, so its shape cannot drift from this. */
const REPORT_FIELDS = {
  report_id: str,
  report_tag: str,
  heading: str,
  subtitle: str,
  badge: str,
  note: nullable(str),
  title: str,
  question: str,
  spine: str,
  row_count: num,
  spine_total: num,
  reading: str,
  assumptions: arrayOf(shape({ slot: str, label: str })),
  facets: arrayOf(
    shape({
      key: str,
      label: str,
      values: arrayOf(shape({ value: str, label: str, count: num })),
    }),
  ),
  frame: REPORT_FRAME,
  tiles: arrayOf(REPORT_TILE),
  footer: arrayOf(shape({ label: str, text: str })),
  blocks: arrayOf(REPORT_BLOCK),
  source_trace: str,
  graph: REPORT_GRAPH,
}

const REPORT_PAYLOAD = shape({
  connected_sources: num,
  published_count: num,
  built_count: num,
  draft_count: num,
  report: nullable(shape(REPORT_FIELDS)),
})

interface RawReportSummary {
  report_id: string
  report_tag: string
  heading: string
  subtitle: string
  question: string
  spine: string
  row_count: number
  spine_total: number
  block_kinds: string[]
  tiles: ReportTile[]
}

interface RawReportBlock {
  type: ReportBlock['type']
  title: string
  columns?: ReportColumn[]
  rows?: ReportRow[]
  sorted_by?: string | null
  subject?: string | null
  charts?: ReportChart[]
  chart?: ReportChart['chart']
  data?: ReportChart['data']
  x_label?: string | null
  y_label?: string | null
  note?: string | null
}

interface RawReport {
  report_id: string
  report_tag: string
  heading: string
  subtitle: string
  badge: string
  note: string | null
  title: string
  question: string
  spine: string
  row_count: number
  spine_total: number
  reading: string
  assumptions: { slot: string; label: string }[]
  facets: ReportFacet[]
  frame: RawReportFrame
  tiles: ReportTile[]
  footer: ReportFootnote[]
  blocks: RawReportBlock[]
  source_trace: string
  graph: RawReportGraph | null
}

interface RawReportGraph {
  use_case_id: string
  name: string
  domain_id?: string | null
  version: string | null
  sha256: string | null
  built_at: string | null
  published_by?: string | null
  entity_count?: number | null
  relationship_count?: number | null
  live?: boolean
}

const toReportGraph = (g: RawReportGraph | null): ReportGraph | null =>
  g
    ? {
        useCaseId: g.use_case_id,
        name: g.name,
        domainId: g.domain_id ?? null,
        version: g.version,
        sha256: g.sha256,
        builtAt: g.built_at,
        publishedBy: g.published_by ?? null,
        entityCount: g.entity_count ?? null,
        relationshipCount: g.relationship_count ?? null,
        /* Absent means live: only a saved report's graph carries the flag, and only
           because it can name one that has since been unpublished. */
        live: g.live ?? true,
      }
    : null

/* `sorted_by` is the only snake_case field a block carries that the UI reads; every
   other block arrives in the shape its chart or table component already takes. */
const toReportBlock = (b: RawReportBlock): ReportBlock =>
  b.type === 'table'
    ? {
        type: 'table',
        title: b.title,
        columns: b.columns ?? [],
        rows: b.rows ?? [],
        sortedBy: b.sorted_by ?? null,
      }
    : (b as unknown as ReportBlock)

/** The section: what has been written, and what this dataset cannot answer. */
export async function getReports(asRole?: string | null): Promise<ReportsIndex> {
  const raw = validate<{
    connected_sources: number
    published_count: number
    built_count: number
    draft_count: number
    graph: RawReportGraph | null
    graphs: RawReportGraph[]
    saved: RawSavedReport[]
    authoring: RawReportAuthoring | null
    documents: {
      document_id: string
      report_id: string
      file: string
      /* Absent on a document from before the specs existed, which is why the mapping defaults it. */
      spec_file?: string | null
      title: string
      subtitle: string
      category: string
      status: string
      version: string
      slug: string
      author: string
      refresh: string
      updated_at: string
    }[]
    authoring_document: string | null
    reports: RawReportSummary[]
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    governance: any
  }>(
    'The report section',
    await request<unknown>(
      asRole ? `/reports?as_role=${encodeURIComponent(asRole)}` : '/reports',
    ),
    REPORTS_INDEX,
  )

  return {
    connectedSources: raw.connected_sources,
    publishedCount: raw.published_count,
    builtCount: raw.built_count,
    draftCount: raw.draft_count,
    graph: toReportGraph(raw.graph),
    graphs: raw.graphs.map((g) => toReportGraph(g)).filter((g): g is ReportGraph => g !== null),
    saved: raw.saved.map(toSaved),
    authoring: raw.authoring ? toAuthoring(raw.authoring) : null,
    documents: raw.documents.map((d) => ({
      documentId: d.document_id,
      reportId: d.report_id,
      file: d.file,
      specFile: d.spec_file ?? null,
      title: d.title,
      subtitle: d.subtitle,
      category: d.category,
      status: d.status,
      version: d.version,
      slug: d.slug,
      author: d.author,
      refresh: d.refresh,
      updatedAt: d.updated_at,
    })),
    authoringDocument: raw.authoring_document,
    governance: raw.governance ? toGovernance(raw.governance) : null,
    reports: raw.reports.map((r) => ({
      reportId: r.report_id,
      reportTag: r.report_tag,
      heading: r.heading,
      subtitle: r.subtitle,
      question: r.question,
      spine: r.spine,
      rowCount: r.row_count,
      spineTotal: r.spine_total,
      blockKinds: r.block_kinds,
      tiles: r.tiles,
    })),
  }
}

/* One mapper for a report however it arrived — read by id, or built from a frame. */
const toReport = (r: RawReport): Report => ({
  reportId: r.report_id,
  reportTag: r.report_tag,
  heading: r.heading,
  subtitle: r.subtitle,
  badge: r.badge,
  note: r.note,
  title: r.title,
  question: r.question,
  spine: r.spine,
  rowCount: r.row_count,
  spineTotal: r.spine_total,
  reading: r.reading,
  assumptions: r.assumptions,
  facets: r.facets,
  frame: toFrame(r.frame),
  tiles: r.tiles,
  footer: r.footer,
  blocks: r.blocks.map(toReportBlock),
  sourceTrace: r.source_trace,
  graph: toReportGraph(r.graph),
})

/** One report, with every figure already computed against its roster. */
export async function getReport(reportId: string): Promise<{
  connectedSources: number
  publishedCount: number
  builtCount: number
  draftCount: number
  report: Report | null
}> {
  const raw = validate<{
    connected_sources: number
    published_count: number
    built_count: number
    draft_count: number
    report: RawReport | null
  }>(
    'The report',
    await request<unknown>(`/reports/${encodeURIComponent(reportId)}`),
    REPORT_PAYLOAD,
  )

  return {
    connectedSources: raw.connected_sources,
    publishedCount: raw.published_count,
    builtCount: raw.built_count,
    draftCount: raw.draft_count,
    report: raw.report ? toReport(raw.report) : null,
  }
}

interface RawReportOptSlot {
  q: string
  options: { value: string; label: string; d: string }[]
}

interface RawReportAuthoring {
  opts: Record<'scope' | 'measure' | 'horizon', RawReportOptSlot>
  facets: ReportFacet[]
  defaults: { scope: string; measure: string; horizon: string }
}

interface RawReportFrame {
  report_id: string
  use_case_id: string | null
  scope: string
  measure: string
  horizon: string
  filters: { key: string; value: string }[]
}

interface RawReportFilter {
  key: string
  label: string
  value: string
  value_label: string
}

interface RawSavedReport {
  saved_id: string
  name: string
  question: string | null
  report_id: string
  use_case_id: string | null
  graph: RawReportGraph | null
  saved_by: string | null
  viewer_roles: { role_id: string; label: string }[]
  report_tag: string
  heading: string
  scope: string
  measure: string
  horizon: string
  scope_label: string
  measure_label: string
  horizon_label: string
  filters: RawReportFilter[]
  saved_at: string
}

/* `q`/`d` are the prototype's field names for the question and the gloss; spelled out
   here because a picker's help text is read by a user, not by the prototype. */
const toOptSlot = (slot: RawReportOptSlot) => ({
  question: slot.q,
  options: slot.options.map((o) => ({ value: o.value, label: o.label, detail: o.d })),
})

const toAuthoring = (raw: RawReportAuthoring): ReportAuthoring => ({
  opts: {
    scope: toOptSlot(raw.opts.scope),
    measure: toOptSlot(raw.opts.measure),
    horizon: toOptSlot(raw.opts.horizon),
  },
  facets: raw.facets,
  defaults: raw.defaults,
})

const toFrame = (raw: RawReportFrame): ReportFrame => ({
  reportId: raw.report_id,
  useCaseId: raw.use_case_id ?? null,
  scope: raw.scope,
  measure: raw.measure,
  horizon: raw.horizon,
  filters: raw.filters,
})

const fromFrame = (frame: ReportFrame) => ({
  report_id: frame.reportId,
  use_case_id: frame.useCaseId,
  scope: frame.scope,
  measure: frame.measure,
  horizon: frame.horizon,
  filters: frame.filters,
})

const toFilter = (f: RawReportFilter): ReportFilter => ({
  key: f.key,
  label: f.label,
  value: f.value,
  valueLabel: f.value_label,
})

const toSaved = (s: RawSavedReport): SavedReport => ({
  savedId: s.saved_id,
  name: s.name,
  question: s.question,
  reportId: s.report_id,
  graph: toReportGraph(s.graph),
  savedBy: s.saved_by,
  viewerRoles: s.viewer_roles.map((r) => ({ roleId: r.role_id, label: r.label })),
  reportTag: s.report_tag,
  heading: s.heading,
  scope: s.scope,
  measure: s.measure,
  horizon: s.horizon,
  scopeLabel: s.scope_label,
  measureLabel: s.measure_label,
  horizonLabel: s.horizon_label,
  filters: s.filters.map(toFilter),
  savedAt: s.saved_at,
})

/**
 * Read a typed question back as one sentence — or start from a standard report.
 *
 * Nothing is built here. Pass `reportId` to start from a chip, in which case there is no
 * question to interpret and the answer is immediate; a typed question is paced.
 */
export async function readReportQuestion(input: {
  question?: string
  reportId?: string
  /** The published graph the question is asked of. */
  useCaseId?: string | null
}): Promise<ReportReadBack> {
  const raw = validate<{
    question: string
    graph: RawReportGraph | null
    matched: boolean
    why: string
    report_tag: string
    heading: string
    spine: string
    frame: RawReportFrame
    reading: string
    assumptions: { slot: string; label: string }[]
    caveats: string[]
  }>(
    'The read-back',
    await request<unknown>('/reports/read', {
      method: 'POST',
      body: {
        question: input.question ?? null,
        report_id: input.reportId ?? null,
        use_case_id: input.useCaseId ?? null,
      },
    }),
    REPORT_READBACK,
  )

  return {
    question: raw.question,
    graph: toReportGraph(raw.graph),
    matched: raw.matched,
    why: raw.why,
    reportTag: raw.report_tag,
    heading: raw.heading,
    spine: raw.spine,
    frame: toFrame(raw.frame),
    reading: raw.reading,
    assumptions: raw.assumptions,
    caveats: raw.caveats,
  }
}

/* The built-report shape and its mapper, shared by `POST /reports/build` and
   `GET /reports/saved/:id` — the two ways one arrives. Two copies would drift. */
const BUILT_REPORT_FIELDS = {
  ...REPORT_FIELDS,
  variant: oneOf(['written', 'generated']),
  filters: REPORT_FILTERS,
  summary_note: nullable(str),
  caveats: arrayOf(str),
}

const toBuiltReport = (
  r: RawReport & {
    variant: 'written' | 'generated'
    filters: RawReportFilter[]
    summary_note: string | null
    caveats: string[]
  },
): BuiltReport => ({
  ...toReport(r),
  variant: r.variant,
  filters: r.filters.map(toFilter),
  summaryNote: r.summary_note,
  caveats: r.caveats,
})

/** Build the report this frame describes. Every figure comes back computed. */
export async function buildReport(frame: ReportFrame): Promise<BuiltReport> {
  const raw = validate<{
    report: RawReport & {
      variant: 'written' | 'generated'
      filters: RawReportFilter[]
      summary_note: string | null
      caveats: string[]
    }
  }>(
    'The built report',
    await request<unknown>('/reports/build', { method: 'POST', body: fromFrame(frame) }),
    shape({ report: shape(BUILT_REPORT_FIELDS) }),
  )

  return toBuiltReport(raw.report)
}


/** Save a question to the library — the frame, never the figures. */
export async function saveReport(input: {
  savedId?: string | null
  name: string
  question: string | null
  frame: ReportFrame
  /** The signed-in address. The server cannot look it up — the identity is client-held. */
  savedBy?: string | null
}): Promise<SavedReport[]> {
  const raw = validate<{ saved: RawSavedReport[] }>(
    'The saved report',
    await request<unknown>('/reports/saved', {
      method: 'POST',
      body: {
        saved_id: input.savedId ?? null,
        name: input.name,
        question: input.question,
        saved_by: input.savedBy ?? null,
        ...fromFrame(input.frame),
      },
    }),
    REPORT_SAVED_PAYLOAD,
  )
  return raw.saved.map(toSaved)
}

/**
 * Set which roles a saved report is meant for.
 *
 * Its own call rather than a re-save: the frame, the name and the question are untouched, and
 * re-posting all three to change an audience invites one of them to arrive stale.
 */
export async function setSavedReportRoles(
  savedId: string,
  roleIds: string[],
): Promise<SavedReport[]> {
  const raw = validate<{ saved: RawSavedReport[] }>(
    'The report audience',
    await request<unknown>(`/reports/saved/${encodeURIComponent(savedId)}/roles`, {
      method: 'POST',
      body: { viewer_roles: roleIds },
    }),
    REPORT_SAVED_PAYLOAD,
  )
  return raw.saved.map(toSaved)
}

/** Remove a saved question. */
/*
 * ---------------- the two acts on a governed definition ----------------
 *
 * Share and Delete. Each answers with the whole governance view rather than an acknowledgement, so
 * the caller renders a validated payload instead of patching its own copy of what it just changed —
 * and each is validated on the way in for the reason every read is: `/db` makes a malformed payload
 * reachable, and a write's answer is rendered exactly like a fetched one.
 *
 * A third act, `POST /reports/access-requests`, was removed with the pending-approval state.
 *
 * **Neither is access control.** They record and report decisions; the role travels from the browser,
 * which the login authenticates by shape.
 */
const GOVERNANCE_REPLY = shape({ governance: REPORT_GOVERNANCE })

/**
 * Who may see that a report exists. An **empty** list makes it private, which is a decision the
 * server records rather than a refusal — so this takes the roles and does not require one.
 */
export async function setReportAudience(
  reportId: string,
  audience: string[],
  asRole?: string | null,
): Promise<ReportGovernance> {
  const raw = validate<{ governance: any }>(
    'The report audience',
    await request<unknown>(
      `/reports/governance/${encodeURIComponent(reportId)}/audience${asRoleQuery(asRole)}`,
      { method: 'PATCH', body: { audience } },
    ),
    GOVERNANCE_REPLY,
  )
  return toGovernance(raw.governance)
}

/**
 * Removes a report's **governance row**, which is what makes it a governed definition.
 *
 * The definition itself is the package's and stays in `db.reports`, so this is recoverable by
 * re-seeding — `restore` carries the command, and a caller that promises "gone for good" would be
 * promising something the server did not do.
 */
export async function deleteGovernedReport(
  reportId: string,
  asRole?: string | null,
): Promise<{ removed: string; restore: string; governance: ReportGovernance }> {
  const raw = validate<{ removed: string; restore: string; governance: any }>(
    'The governed report',
    await request<unknown>(
      `/reports/governance/${encodeURIComponent(reportId)}${asRoleQuery(asRole)}`,
      { method: 'DELETE' },
    ),
    shape({ removed: str, restore: str, governance: REPORT_GOVERNANCE }),
  )
  return { removed: raw.removed, restore: raw.restore, governance: toGovernance(raw.governance) }
}

/* One place that spells the role parameter, so a write cannot ask for a different reader's view. */
const asRoleQuery = (asRole?: string | null) =>
  asRole ? `?as_role=${encodeURIComponent(asRole)}` : ''

export async function deleteSavedReport(savedId: string): Promise<SavedReport[]> {
  const raw = validate<{ saved: RawSavedReport[] }>(
    'The saved report',
    await request<unknown>(`/reports/saved/${encodeURIComponent(savedId)}`, { method: 'DELETE' }),
    REPORT_SAVED_PAYLOAD,
  )
  return raw.saved.map(toSaved)
}

/**
 * Open a saved report: its frame, re-asked now.
 *
 * The row comes back beside the report because the page states what the figures do not —
 * who saved it, when, and which graph it was asked of.
 */
export async function getSavedReport(savedId: string): Promise<{
  connectedSources: number
  publishedCount: number
  builtCount: number
  draftCount: number
  saved: SavedReport | null
  report: BuiltReport | null
}> {
  const raw = validate<{
    connected_sources: number
    published_count: number
    built_count: number
    draft_count: number
    saved: RawSavedReport | null
    report:
      | (RawReport & {
          variant: 'written' | 'generated'
          filters: RawReportFilter[]
          summary_note: string | null
          caveats: string[]
        })
      | null
  }>(
    'The saved report',
    await request<unknown>(`/reports/saved/${encodeURIComponent(savedId)}`),
    shape({
      connected_sources: num,
      published_count: num,
      built_count: num,
      draft_count: num,
      saved: nullable(REPORT_SAVED_ROW),
      report: nullable(shape(BUILT_REPORT_FIELDS)),
    }),
  )

  return {
    connectedSources: raw.connected_sources,
    publishedCount: raw.published_count,
    builtCount: raw.built_count,
    draftCount: raw.draft_count,
    saved: raw.saved ? toSaved(raw.saved) : null,
    report: raw.report ? toBuiltReport(raw.report) : null,
  }
}

/* ---------------- Audit & Governance ---------------- */

/*
 * Who sees what, and what this server has recorded about it.
 *
 * **A rule is recorded, not enforced**, and the payload says so rather than leaving it to the page:
 * no roster in this app is filtered per persona, so `resolution` states what a rule *would* admit
 * against today's register — never what a reader saw. That distinction is the whole reason the
 * field is called a resolution and carries its own sample.
 */

/** A field a restriction may run on: the register's identity column, plus its filterable fields. */
export interface GovernanceBasis {
  basis: string
  label: string
  /** True on the spine's own identity column — restricting by it names rows one at a time. */
  identity: boolean
  values: { value: string; label: string; count: number }[]
}

/** What a persona's rule admits against today's register. */
export interface GovernanceResolution {
  kind: 'full' | 'mask' | 'part' | 'none'
  count: number
  total: number
  summary: string
  /** The rows it names. A list is checkable in a way "32 of 36" is not. */
  sample: string[]
}

export interface GovernancePerson {
  email: string
  name: string
  roleId: string
  roleLabel: string
  /** The tenant's authored prose for this persona's scope — beside the rule, never instead of it. */
  declared: string | null
  maskedColumns: string | null
  full: boolean
  mask: boolean
  rule: { basis: string; values: string[] } | null
  resolution: GovernanceResolution
}

/** A published report or scenario, with its audience resolved to people. */
export interface GovernanceArtifact {
  artifactId: string
  kind: 'report' | 'whatif'
  kindLabel: string
  name: string
  publishedBy: string | null
  live: boolean
  statusLabel: string
  freshness: string | null
  cases: string[] | null
  readers: string[]
  /** What this artifact's audience is actually made of — the two kinds differ. */
  audienceNote: string
  /** False on a report: the section has no unpublish, and the row must not offer one. */
  canUnpublish: boolean
}

export interface GovernanceEvent {
  eventId: string
  at: string
  category: string
  actor: string
  text: string
  detail: string
}

/**
 * The rendered Audit & Governance screen a dataset ships, or `null` where the screen is computed.
 *
 * The same arrangement as `WhatIfDocument`: a dataset can ship a finished page instead of a set of
 * figures to resolve per request, and the page frames it rather than transcribing what it says.
 */
export interface GovernanceDocument {
  documentId: string
  /** The file, relative to the dataset's `audit-governance` folder. Resolved to a URL by the page. */
  file: string
  title: string
  heading: string
  subtitle: string
  tabs: { key: string; label: string }[]
  /** Where the screen came from — the package, which screen of it, and when it was generated. */
  package: string
  screen: string
  generated: string
  /** The roster every count on the page is resolved against, stated rather than recomputed here. */
  rosterTotal: number
}

export interface GovernanceView {
  connectedSources: number
  publishedCount: number
  builtCount: number
  draftCount: number
  /**
   * The rendered screen this dataset ships, or `null`.
   *
   * Served on the **open branch only**: this page governs published artifacts, so a framed screen with
   * nothing published would describe reports and scenarios nobody released. The gate is tested before
   * this field is read, exactly as the What-if page tests it before `frame.document`.
   */
  document: GovernanceDocument | null
  rosterTotal: number
  bases: GovernanceBasis[]
  people: GovernancePerson[]
  artifacts: GovernanceArtifact[]
  log: GovernanceEvent[]
  logCategories: { key: string; label: string }[]
  copy: {
    title: string
    lead: string
    gates: { key: string; title: string; detail: string }[]
    /** The sentence the page turns on: a rule is recorded, not enforced. */
    notEnforced: string
    emptyLog: string
    logNote: string
    basisNote: string
  }
}

const GOVERNANCE_VIEW = shape({
  connected_sources: num,
  published_count: num,
  built_count: num,
  draft_count: num,
  /* `nullable` accepts an absent key as well as null, which is what a dataset with a computed screen
     sends. A *present* one is checked in full — it is what the page frames instead of the rules, so a
     missing `file` is a blank frame and a missing `title` is a frame with no accessible name. */
  document: nullable(
    shape({
      document_id: str,
      file: str,
      title: str,
      heading: str,
      subtitle: str,
      tabs: arrayOf(shape({ key: str, label: str })),
      package: str,
      screen: str,
      generated: str,
      roster_total: num,
    }),
  ),
  roster_total: num,
  bases: arrayOf(
    shape({
      basis: str,
      label: str,
      identity: bool,
      values: arrayOf(shape({ value: str, label: str, count: num })),
    }),
  ),
  people: arrayOf(
    shape({
      email: str,
      name: str,
      role_id: str,
      role_label: str,
      declared: nullable(str),
      masked_columns: nullable(str),
      full: bool,
      mask: bool,
      rule: nullable(shape({ basis: str, values: arrayOf(str) })),
      resolution: shape({
        kind: oneOf(['full', 'mask', 'part', 'none']),
        count: num,
        total: num,
        summary: str,
        sample: arrayOf(str),
      }),
    }),
  ),
  artifacts: arrayOf(
    shape({
      artifact_id: str,
      kind: oneOf(['report', 'whatif']),
      kind_label: str,
      name: str,
      published_by: nullable(str),
      live: bool,
      status_label: str,
      freshness: nullable(str),
      cases: nullable(arrayOf(str)),
      readers: arrayOf(str),
      audience_note: str,
      can_unpublish: bool,
    }),
  ),
  log: arrayOf(
    shape({ event_id: str, at: str, category: str, actor: str, text: str, detail: str }),
  ),
  log_categories: arrayOf(shape({ key: str, label: str })),
  copy: shape({
    title: str,
    lead: str,
    gates: arrayOf(shape({ key: str, title: str, detail: str })),
    not_enforced: str,
    empty_log: str,
    log_note: str,
    basis_note: str,
  }),
})

interface RawGovernanceView {
  connected_sources: number
  published_count: number
  built_count: number
  draft_count: number
  document: {
    document_id: string
    file: string
    title: string
    heading: string
    subtitle: string
    tabs: { key: string; label: string }[]
    package: string
    screen: string
    generated: string
    roster_total: number
  } | null
  roster_total: number
  bases: GovernanceBasis[]
  people: {
    email: string
    name: string
    role_id: string
    role_label: string
    declared: string | null
    masked_columns: string | null
    full: boolean
    mask: boolean
    rule: { basis: string; values: string[] } | null
    resolution: GovernanceResolution
  }[]
  artifacts: {
    artifact_id: string
    kind: 'report' | 'whatif'
    kind_label: string
    name: string
    published_by: string | null
    live: boolean
    status_label: string
    freshness: string | null
    cases: string[] | null
    readers: string[]
    audience_note: string
    can_unpublish: boolean
  }[]
  log: {
    event_id: string
    at: string
    category: string
    actor: string
    text: string
    detail: string
  }[]
  log_categories: { key: string; label: string }[]
  copy: {
    title: string
    lead: string
    gates: { key: string; title: string; detail: string }[]
    not_enforced: string
    empty_log: string
    log_note: string
    basis_note: string
  }
}

const toGovernanceView = (raw: RawGovernanceView): GovernanceView => ({
  connectedSources: raw.connected_sources,
  publishedCount: raw.published_count,
  builtCount: raw.built_count,
  draftCount: raw.draft_count,
  document: raw.document
    ? {
        documentId: raw.document.document_id,
        file: raw.document.file,
        title: raw.document.title,
        heading: raw.document.heading,
        subtitle: raw.document.subtitle,
        tabs: raw.document.tabs,
        package: raw.document.package,
        screen: raw.document.screen,
        generated: raw.document.generated,
        rosterTotal: raw.document.roster_total,
      }
    : null,
  rosterTotal: raw.roster_total,
  bases: raw.bases,
  people: raw.people.map((p) => ({
    email: p.email,
    name: p.name,
    roleId: p.role_id,
    roleLabel: p.role_label,
    declared: p.declared,
    maskedColumns: p.masked_columns,
    full: p.full,
    mask: p.mask,
    rule: p.rule,
    resolution: p.resolution,
  })),
  artifacts: raw.artifacts.map((a) => ({
    artifactId: a.artifact_id,
    kind: a.kind,
    kindLabel: a.kind_label,
    name: a.name,
    publishedBy: a.published_by,
    live: a.live,
    statusLabel: a.status_label,
    freshness: a.freshness,
    cases: a.cases,
    readers: a.readers,
    audienceNote: a.audience_note,
    canUnpublish: a.can_unpublish,
  })),
  log: raw.log.map((e) => ({
    eventId: e.event_id,
    at: e.at,
    category: e.category,
    actor: e.actor,
    text: e.text,
    detail: e.detail,
  })),
  logCategories: raw.log_categories,
  copy: {
    title: raw.copy.title,
    lead: raw.copy.lead,
    gates: raw.copy.gates,
    notEnforced: raw.copy.not_enforced,
    emptyLog: raw.copy.empty_log,
    logNote: raw.copy.log_note,
    basisNote: raw.copy.basis_note,
  },
})

/** The whole page. */
export async function getGovernance(): Promise<GovernanceView> {
  return toGovernanceView(
    validate<RawGovernanceView>(
      'Audit & Governance',
      await request<unknown>('/governance'),
      GOVERNANCE_VIEW,
    ),
  )
}

/** `as` is the signed-in address — client-held, so every route that records who has to be told. */
const asQuery = (as?: string | null) => (as ? `?as=${encodeURIComponent(as)}` : '')

/** Set a persona's access rule. Every writer answers with the whole view, so there is one path in. */
export async function setGovernanceScope(input: {
  roleId: string
  rule?: { basis: string; values: string[] } | null
  full?: boolean
  mask?: boolean
  as?: string | null
}): Promise<GovernanceView> {
  const body: Record<string, unknown> = {}
  if (input.rule !== undefined) body.rule = input.rule
  if (input.full !== undefined) body.full = input.full
  if (input.mask !== undefined) body.mask = input.mask
  return toGovernanceView(
    validate<RawGovernanceView>(
      'The access rule',
      await request<unknown>(
        `/governance/scope/${encodeURIComponent(input.roleId)}${asQuery(input.as)}`,
        { method: 'PATCH', body },
      ),
      GOVERNANCE_VIEW,
    ),
  )
}

/** Give somebody access. The server writes to whichever pool the artifact keeps. */
export async function addGovernanceReader(input: {
  artifactId: string
  email: string
  as?: string | null
}): Promise<GovernanceView> {
  return toGovernanceView(
    validate<RawGovernanceView>(
      'The reader',
      await request<unknown>(
        `/governance/artifacts/${encodeURIComponent(input.artifactId)}/readers${asQuery(input.as)}`,
        { method: 'POST', body: { email: input.email } },
      ),
      GOVERNANCE_VIEW,
    ),
  )
}

export async function removeGovernanceReader(input: {
  artifactId: string
  email: string
  as?: string | null
}): Promise<GovernanceView> {
  const path =
    `/governance/artifacts/${encodeURIComponent(input.artifactId)}` +
    `/readers/${encodeURIComponent(input.email)}${asQuery(input.as)}`
  return toGovernanceView(
    validate<RawGovernanceView>(
      'The reader',
      await request<unknown>(path, { method: 'DELETE' }),
      GOVERNANCE_VIEW,
    ),
  )
}

/** Withdraw a published scenario. Refused on a report, which has no such act. */
export async function unpublishGovernanceArtifact(input: {
  artifactId: string
  as?: string | null
}): Promise<GovernanceView> {
  return toGovernanceView(
    validate<RawGovernanceView>(
      'The withdrawal',
      await request<unknown>(
        `/governance/artifacts/${encodeURIComponent(input.artifactId)}/unpublish${asQuery(input.as)}`,
        { method: 'POST' },
      ),
      GOVERNANCE_VIEW,
    ),
  )
}

/* ================= Graph Studio — one studio, whichever lanes a use case has =================
 *
 * **Two graphs, one approval.** A use case's structured lane and its document lane build separately,
 * draw separately and never resolve their entities against each other; what is unified is the use
 * case and its *publication* — a version names the artifacts approved together, so "publish this use
 * case" is one act with one outcome rather than two calls that can half-succeed.
 *
 * Every payload below is validated at this boundary like every other one here. That matters more on
 * this surface than most: a build is polled, so a shape the server stopped sending would otherwise
 * surface as a spinner that never resolves rather than as an error naming the field.
 */

/** Which lanes a use case has — **derived from what is attached, never declared.** A single-valued
 *  kind field could not express "both", and frozen at commit it could not grow into a second lane. */
export interface StudioUseCase {
  useCaseId: string
  name: string | null
  domain: string | null
  status: string
  hasStructured: boolean
  hasDocuments: boolean
  documentCount: number
  structuredTableCount: number
  /** Truthy means "a graph can be built from it". Deliberately read as truthiness rather than
   *  `!== null`: a row whose version id is absent must never reach the picker, and `undefined` is not
   *  `null` — that exact gap put unbuildable drafts in the list once. */
  latestCommittedVersionId: string | null
  updatedAt: string | null
}

export interface StudioUseCaseDetail extends StudioUseCase {
  businessNeed: string | null
  requiredSources: string[]
}

export interface StudioSource {
  sourceId: string
  sourceType: string
  name: string
  connector: string
}

/* ---------------- the structured lane ---------------- */

export interface SgbStageStep {
  step: string
  state: 'pending' | 'running' | 'complete'
}

export interface SgbStage {
  stage: string
  label: string
  state: 'pending' | 'running' | 'complete'
  /** What the trace prints beyond the state — `202 accepted`, or the substep in flight. */
  detail: string | null
  steps: SgbStageStep[]
}

/**
 * One structured build.
 *
 * `nodeCount` deliberately excludes columns: the canvas folds a column into its table's card, so
 * counting them would report a number the drawing never draws. Both counts are **nullable** — a build
 * that has not finished has not counted anything, and 0 would say the graph is empty.
 */
export interface SgbBuild {
  buildId: string
  useCaseId: string
  status: string
  buildNumber: number
  name: string
  nodeCount: number | null
  relationCount: number | null
  tableCount: number | null
  columnCount: number | null
  conceptCount: number | null
  createdAt: string
  updatedAt: string
  publishedAt: string | null
  publishedBy: string | null
  errorMessage: string | null
  cursor: number
  stepTotal: number
  /** The server's pace, so the panel's "about N left" derives from it rather than restating a
   *  number. Change it on the server and the page follows. */
  stepMs: number
  stages: SgbStage[]
}

export interface SgbTable {
  tableRef: string
  tableId: string
  sourceId: string
  schemaName: string | null
  tableName: string
  rowCountEstimate: number | null
  tableKind: string
  selected: boolean
  comment: string | null
}

export interface SgbColumn {
  columnRef: string
  tableRef: string
  columnName: string
  ordinalPosition: number | null
  dataType: string
  description: string | null
  semanticRole: string | null
  conceptName: string | null
  profile: {
    distinctCountInSample: number | null
    nullRatio: number | null
    isSampleClaim: boolean
  }
}

export interface SgbConcept {
  conceptRef: string
  name: string
  description: string | null
  declared: boolean
}

export interface SgbEdge {
  edgeType: string
  srcKind: string
  srcRef: string
  dstKind: string
  dstRef: string
  declared: boolean
}

export interface SgbStory {
  storyGroupId: string
  story: string
  grain: Record<string, unknown>
  uncertainties: string[]
  /** True only where somebody really typed it, so the tenant's own words are distinguishable from
   *  the ones the server composed out of their brief. */
  editedByUser: boolean
}

export interface SgbGraph {
  buildId: string
  tables: SgbTable[]
  columns: SgbColumn[]
  concepts: SgbConcept[]
  edges: SgbEdge[]
  storyGroup: SgbStory | null
}

export interface StoryDraft {
  story: string
  /** Whether a model produced this. **False would be a claim**, and none ran here: the prose is the
   *  use case's own business need rearranged. */
  degraded: boolean
  degradeReason: string | null
  tablesConsidered: number
  columnsConsidered: number
  declaredRelationshipsConsidered: number
  intentConsidered: boolean
  heroQuestionsConsidered: number
}

/* ---------------- the document lane ---------------- */

export interface DgbStage {
  stage: string
  label: string
  state: 'pending' | 'running' | 'complete'
  counts: Record<string, unknown> | null
}

export interface DgbJob {
  jobId: string
  status: string
  documentsProcessed: number
  documentTotal: number
  createdAt: string | null
  completedAt: string | null
  stageMs: number
  stages: DgbStage[]
  /** What the running stage is doing, in words. The long stages have no honest denominator, so they
   *  report a phrase rather than a percentage nobody measures. */
  /** What the running stage is doing, in words, and the unix second it began — the panel turns
   *  `since` into an elapsed timer. The long stages have no honest denominator, so they report a
   *  phrase rather than a percentage nobody measures. */
  phase: { stage: string; phase: string; since: number } | null
}

export interface DgbBuild {
  buildId: string
  documentCorpusId: string
  graphVersion: number
  documentCount: number
  entityCount: number
  relationCount: number
  classCount: number
  completedAt: string
  /** `superseded` is distinct from `unpublished` on purpose: "a newer version took over" and "a
   *  human withdrew this" are different facts and a history that conflates them lies. */
  publishStatus: 'unpublished' | 'published' | 'superseded'
  publishedAt: string | null
  /** Server-derived, so the UI never re-implements the rule. */
  isQueryable: boolean
}

export interface DgbEntity {
  entityId: string
  canonicalName: string
  entityType: string
  aliases: string[]
  mentionCount: number
  /** A document, or the thing a document was found to be about. */
  kind?: string
  resolvedType?: string | null
}

export interface DgbRelation {
  relationId: string
  subjectEntityId: string
  objectEntityId: string
  relationType: string
  chunkId: string
  documentId: string | null
  classes: string[]
  confidence: number | null
}

/**
 * The passage a relation was asserted from.
 *
 * **`chunkText` is nullable and is null in this tenant**, because no document here stores its body.
 * The panel prints that rather than a sentence: text composed by the server and labelled "what this
 * was extracted from" is the one invention a reader could not catch, and checking exactly that is
 * what an evidence panel is for.
 */
export interface ChunkEvidence {
  chunkId: string
  documentId: string
  chunkText: string | null
  documentName: string
  docTypeLabel: string | null
  linkedEntity: string | null
  pageStart: number | null
  pageEnd: number | null
}

export interface CorpusDocument {
  documentId: string
  filename: string
  mimeType: string | null
  docType: string | null
  docTypeLabel: string | null
  linkedEntity: string | null
  pages: number | null
  folder: string
  drive: string
}

/* ---------------- the Bridge ---------------- */

export type TypeLinkDecision = 'identity' | 'attribute' | 'reject'

/**
 * One correspondence between a document entity type and a structured concept.
 *
 * **The Bridge stops at the type level.** It names no column, projects onto no individual entity and
 * queries no warehouse — so nothing here can become a `WHERE` clause and no screen may imply
 * otherwise. `reject` rows are carried, not dropped: the list records what was *considered*, so a
 * pair the deriver declined is distinguishable from one it never saw.
 */
export interface TypeLink {
  typeLinkId: string
  bridgeBuildId: string
  entityType: string
  conceptRef: string
  conceptName: string
  conceptDeclared: boolean
  decision: TypeLinkDecision
  /** Categorical — `high` | `low` — never a numeric score, which would invite being read as a
   *  measurement when nothing measured it. */
  confidence: string
  reason: string
  /** `llm` for a derived row, `human` once somebody decided it. */
  decidedBy: string
  originalDecision: string | null
  originalConfidence: string | null
  originalReason: string | null
  decidedByUser: string | null
  decidedAt: string | null
  updatedAt: string
}

export interface BridgeStage {
  stage: string
  label: string
  state: 'pending' | 'running' | 'complete'
}

export interface BridgeBuild {
  bridgeBuildId: string
  useCaseId: string
  buildNumber: number
  sgbBuildId: string
  documentCorpusId: string
  dgbGraphVersion: number
  status: string
  createdAt: string
  updatedAt: string
  stageMs: number
  /** One model call is one Concept, put to the model against every Entity Type the corpus holds —
   *  so `linksWritten` is the product rather than a third figure counted beside them. */
  modelCallsDone: number
  modelCallsTotal: number
  conceptCount: number
  entityTypeCount: number
  linksWritten: number
  stages: BridgeStage[]
}

/* ---------------- the Playground ---------------- */

/**
 * A metric on the Playground — **one of the ones accepted on step 4 of New Graph**, with the query
 * it is answered by.
 *
 * It is the brief's own row rather than a copy: the Playground reads and writes
 * `graph_use_cases[].metrics`, so it cannot come to disagree with the wizard about what this use
 * case asked for.
 */
export interface PlaygroundMetric {
  name: string
  description: string
  source: 'ai' | 'user'
  origin: 'document' | null
  /**
   * The query this metric is answered by — **composed by the server where the brief carries none**,
   * so it arrives with the metric exactly as a hero question's does rather than waiting for somebody
   * to write it. Still `null` where nothing in the profiled schema matched, because a plausible
   * query naming a column this tenant may not have is worse than none.
   */
  sql: string | null
  /** Why there is none, where there is none — the server's own sentence, printed in the row it is
   *  about so a reader is not left to read a blank as a query that failed to load. */
  sqlNote: string | null
}

/** A golden query — a hero question accepted on step 5, with the SQL that answers it. */
export interface GoldenQuery {
  text: string
  priority: 'high' | 'normal'
  source: 'ai' | 'user'
  sql: string | null
}

/** A file attached to this use case's golden queries. **Its name, and nothing else** — no bytes
 *  travel, and the panel says so. */
export interface PlaygroundFile {
  name: string
  uploadedAt: string
  uploadedBy: string | null
}

export interface Playground {
  useCaseId: string
  metrics: PlaygroundMetric[]
  goldenQueries: GoldenQuery[]
  files: PlaygroundFile[]
  /** The server's caps, served rather than restated here: a cap the page held its own copy of would
   *  let Add offer a row the save then refuses. Metrics have none — that limit was removed on
   *  request, so the payload serves no number for them. */
  queryCap: number
  fileCap: number
}

export interface TypeLinkList {
  typeLinks: TypeLink[]
  /** The server's own count of what still blocks publishing. **Never derived here**: a second
   *  expression of the gate's predicate is a screen reading "nothing left" over a server that
   *  refuses the publish. */
  unreviewedCount: number
}

/**
 * Does this Type Link still block publishing?
 *
 * **The criterion, and the whole of it: no person has decided it.** Every pair the deriver was put
 * counts, rejects included — a decline is its proposal too, and "no correspondence here" is a claim
 * a reviewer can disagree with. Rejects were excluded until this was **changed on request**; the
 * reasoning that excluded them is about the *publication* rather than the review, and it is recorded
 * beside `needsReview` in `backend/studioLanes.js`, which this must agree with exactly.
 *
 * Confidence is excluded deliberately — it is the deriver's own self-report, so gating on it would
 * let the deriver choose which rows a human must look at, and a confidently-wrong `identity`, the
 * one that does damage, is exactly the row that would escape. Confidence *orders* the queue; it does
 * not define it. Agreement is a decision, so a row leaves this set whether the person confirmed or
 * changed it.
 */
export const typeLinkNeedsReview = (link: TypeLink): boolean => link.decidedBy === 'llm'

/* ---------------- versions ---------------- */

/** One Combined Graph Version — the artifacts approved **together**. It records an approval; it is
 *  never a merged or copied graph. */
export interface StudioVersion {
  graphVersionId: string
  useCaseId: string
  versionNumber: number
  sgbBuildId: string | null
  documentCorpusId: string | null
  dgbGraphVersion: number | null
  bridgeBuildId: string | null
  publishedAt: string | null
  publishedBy: string | null
  createdAt: string
}

/** One version plus the two staleness questions, **reported separately and never fused.** A
 *  mismatched Bridge triple is a *defect*; a newer lane build is just a new *candidate* the published
 *  version is entitled to ignore until somebody adopts it. One "stale" boolean would make those read
 *  the same. Nothing is stored, so neither answer can drift. */
export interface StudioVersionDetail {
  version: StudioVersion
  bridgeMatchesNamedTriple: boolean | null
  bridgeStatus: string | null
  newerSgbBuildId: string | null
  newerDgbGraphVersion: number | null
}

export interface PublishedBridge {
  bridgeBuildId: string
  buildNumber: number
  status: string
}

/* ---------------- schemas ---------------- */

const STAGE_STATE = oneOf(['pending', 'running', 'complete'])

const STUDIO_USE_CASE = shape({
  use_case_config_id: str,
  name: nullable(str),
  domain: nullable(str),
  status: str,
  has_structured: bool,
  has_documents: bool,
  document_count: num,
  structured_table_count: num,
  latest_committed_version_id: nullable(str),
  updated_at: nullable(str),
})

const STUDIO_USE_CASES = shape({
  configs: arrayOf(STUDIO_USE_CASE),
  connected_sources: num,
})

const STUDIO_USE_CASE_DETAIL = shape({
  use_case_config_id: str,
  name: nullable(str),
  domain: nullable(str),
  status: str,
  business_need: nullable(str),
  required_sources: arrayOf(str),
  has_structured: bool,
  has_documents: bool,
  document_count: num,
  structured_table_count: num,
})

const STUDIO_SOURCES = shape({
  sources: arrayOf(
    shape({ source_id: str, source_type: str, name: str, connector: str }),
  ),
})

const SGB_BUILD = shape({
  build_id: str,
  use_case_config_id: str,
  status: str,
  build_number: num,
  name: str,
  /* Nullable because an unfinished build has counted nothing — and `?? 0` at a reader would say the
     graph is empty, which is the `rows: num` pitfall this repo has already been bitten by twice. */
  node_count: nullable(num),
  relation_count: nullable(num),
  table_count: nullable(num),
  column_count: nullable(num),
  concept_count: nullable(num),
  created_at: str,
  updated_at: str,
  published_at: nullable(str),
  published_by_user_id: nullable(str),
  error_message: nullable(str),
  cursor: num,
  step_total: num,
  step_ms: num,
  stages: arrayOf(
    shape({
      stage: str,
      label: str,
      state: STAGE_STATE,
      /* What the trace prints on the right beyond the state — `202 accepted` on the trigger, the
         substep in flight on the running phase. Null where the state says it all. */
      detail: nullable(str),
      steps: arrayOf(shape({ step: str, state: STAGE_STATE })),
    }),
  ),
})

const SGB_BUILDS = shape({ builds: arrayOf(SGB_BUILD) })

const SGB_TRIGGERED = shape({ build_id: str, status: str })

/**
 * The story group, as the **graph** carries it.
 *
 * **It has no `build_id`, and sharing one schema with the story *endpoint* was a real bug.** A story
 * group is a thing the graph contains, so it is identified by `story_group_id`; `GET …/builds/:id/
 * story` answers *about a build*, so that reply names one. Declared together, every structured graph
 * was refused with `story_group.build_id should be a string, got undefined` — under the message that
 * tells a reader to restart the mock server, which was answering perfectly.
 *
 * Two shapes, two schemas. `SGB_STORY` below is this plus the build it was read for.
 */
const SGB_STORY_GROUP = shape({
  story_group_id: str,
  story: str,
  grain: shape({}),
  uncertainties: arrayOf(str),
  edited_by_user: bool,
})

/** The story endpoint's own reply: the group, plus the build it answers about. */
const SGB_STORY = shape({
  build_id: str,
  story_group_id: str,
  story: str,
  grain: shape({}),
  uncertainties: arrayOf(str),
  edited_by_user: bool,
})

const SGB_GRAPH = shape({
  build_id: str,
  tables: arrayOf(
    shape({
      table_ref: str,
      table_id: str,
      source_id: str,
      schema_name: nullable(str),
      table_name: str,
      row_count_estimate: nullable(num),
      table_kind: str,
      selected: bool,
      comment: nullable(str),
    }),
  ),
  columns: arrayOf(
    shape({
      column_ref: str,
      table_ref: str,
      column_name: str,
      ordinal_position: nullable(num),
      data_type: str,
      description: nullable(str),
      semantic_role: nullable(str),
      concept_name: nullable(str),
      profile: shape({
        distinct_count_in_sample: nullable(num),
        null_ratio: nullable(num),
        is_sample_claim: bool,
      }),
    }),
  ),
  concepts: arrayOf(
    shape({ concept_ref: str, name: str, description: nullable(str), declared: bool }),
  ),
  edges: arrayOf(
    shape({
      edge_type: str,
      src_kind: str,
      src_ref: str,
      dst_kind: str,
      dst_ref: str,
      declared: bool,
    }),
  ),
  story_group: nullable(SGB_STORY_GROUP),
})

const STORY_DRAFT = shape({
  story: str,
  degraded: bool,
  degrade_reason: nullable(str),
  tables_considered: num,
  columns_considered: num,
  declared_relationships_considered: num,
  intent_considered: bool,
  hero_questions_considered: num,
})

const DGB_JOB = shape({
  job_id: str,
  status: str,
  documents_processed: num,
  document_total: num,
  created_at: nullable(str),
  completed_at: nullable(str),
  stage_ms: num,
  stages: arrayOf(
    shape({ stage: str, label: str, state: STAGE_STATE, counts: nullable(shape({})) }),
  ),
  phase: nullable(shape({ stage: str, phase: str, since: num })),
})

const DGB_BUILD = shape({
  build_id: str,
  document_corpus_id: str,
  graph_version: num,
  document_count: num,
  entity_count: num,
  relation_count: num,
  class_count: num,
  completed_at: str,
  publish_status: oneOf(['unpublished', 'published', 'superseded']),
  published_at: nullable(str),
  is_queryable: bool,
})

const DGB_BUILDS = shape({ builds: arrayOf(DGB_BUILD) })

const DGB_ENTITY = shape({
  entity_id: str,
  canonical_name: str,
  entity_type: str,
  aliases: arrayOf(str),
  mention_count: num,
})

const DGB_RELATION = shape({
  relation_id: str,
  subject_entity_id: str,
  object_entity_id: str,
  relation_type: str,
  chunk_id: str,
  document_id: nullable(str),
  classes: arrayOf(str),
  confidence: nullable(num),
})

const DGB_PAGE = (item: FieldCheck) =>
  shape({ items: arrayOf(item), limit: num, offset: num, has_more: bool })

const DGB_CLASSES = shape({ classes: arrayOf(str) })

const CHUNK_EVIDENCE = shape({
  chunk_id: str,
  document_id: str,
  /* Nullable, and null in this tenant: no document here stores its body. A string would be a
     fabricated quotation sitting under a heading that says it is verbatim. */
  chunk_text: nullable(str),
  document_name: str,
  doc_type_label: nullable(str),
  linked_entity: nullable(str),
  page_start: nullable(num),
  page_end: nullable(num),
})

const CORPUS_DOCUMENTS = shape({
  documents: arrayOf(
    shape({
      document_id: str,
      filename: str,
      mime_type: nullable(str),
      doc_type: nullable(str),
      doc_type_label: nullable(str),
      linked_entity: nullable(str),
      pages: nullable(num),
      folder: str,
      drive: str,
    }),
  ),
})

const TYPE_LINK = shape({
  type_link_id: str,
  bridge_build_id: str,
  entity_type: str,
  concept_ref: str,
  concept_name: str,
  concept_declared: bool,
  decision: oneOf(['identity', 'attribute', 'reject']),
  confidence: str,
  reason: str,
  decided_by: str,
  original_decision: nullable(str),
  original_confidence: nullable(str),
  original_reason: nullable(str),
  decided_by_user_id: nullable(str),
  decided_at: nullable(str),
  /* The row's own stamp, read by the decision control to reset itself after a save: without it
     the next edit starts from whatever the person chose last time rather than from what now
     stands. */
  updated_at: str,
})

const TYPE_LINKS = shape({ type_links: arrayOf(TYPE_LINK), unreviewed_count: num })

const ACCEPT_OUTSTANDING = shape({ accepted_count: num, unreviewed_count: num })

const BRIDGE_BUILD = shape({
  bridge_build_id: str,
  use_case_config_id: str,
  build_number: num,
  sgb_build_id: str,
  document_corpus_id: str,
  dgb_graph_version: num,
  status: str,
  created_at: str,
  updated_at: str,
  stage_ms: num,
  /* The run's position in the unit it works in — one model call per Concept, each put against every
     Entity Type. `links_written` is the product of the two, so a panel cannot report links a call
     never wrote. */
  model_calls_done: num,
  model_calls_total: num,
  concept_count: num,
  entity_type_count: num,
  links_written: num,
  stages: arrayOf(shape({ stage: str, label: str, state: STAGE_STATE })),
})

const BRIDGE_BUILDS = shape({ bridge_builds: arrayOf(BRIDGE_BUILD) })

const PLAYGROUND = shape({
  use_case_config_id: str,
  metrics: arrayOf(
    shape({
      name: str,
      description: str,
      source: oneOf(['ai', 'user']),
      origin: nullable(str),
      sql: nullable(str),
      /* Why there is no query, where there is none. Nullable, so an older server that composed
         nothing still validates — it simply has no reason to give. */
      sql_note: nullable(str),
    }),
  ),
  /* The same `HERO_QUESTION` shape the wizard validates, because these are the same rows — a second
     schema over one list is how the two screens come to disagree about what a question carries. */
  golden_queries: arrayOf(HERO_QUESTION),
  files: arrayOf(shape({ name: str, uploaded_at: str, uploaded_by: nullable(str) })),
  query_cap: num,
  file_cap: num,
})

const BRIDGE_TRIGGERED = shape({ bridge_build_id: str, build_number: num, status: str })

const COMBINED_TRIGGERED = shape({
  use_case_config_id: str,
  sgb_build_id: nullable(str),
  dgb_job_id: nullable(str),
  /* Whether a Bridge follows once both lanes land, so the Build tab can say so while they are still
     running rather than discovering it when one appears. */
  bridge_follows: bool,
  status: str,
})

const PUBLISHED_BRIDGE = shape({
  published_bridge: nullable(
    shape({ bridge_build_id: str, build_number: num, status: str }),
  ),
})

const GRAPH_VERSION = shape({
  graph_version_id: str,
  use_case_config_id: str,
  version_number: num,
  sgb_build_id: nullable(str),
  document_corpus_id: nullable(str),
  dgb_graph_version: nullable(num),
  bridge_build_id: nullable(str),
  published_at: nullable(str),
  published_by_user_id: nullable(str),
  created_at: str,
})

const GRAPH_VERSIONS = shape({ versions: arrayOf(GRAPH_VERSION) })
const ONE_GRAPH_VERSION = shape({ version: nullable(GRAPH_VERSION) })

const GRAPH_VERSION_DETAIL = shape({
  version: GRAPH_VERSION,
  bridge_matches_named_triple: nullable(bool),
  bridge_status: nullable(str),
  newer_sgb_build_id: nullable(str),
  newer_dgb_graph_version: nullable(num),
})

/* ---------------- mappers ---------------- */

const toStudioUseCase = (raw: {
  use_case_config_id: string
  name: string | null
  domain: string | null
  status: string
  has_structured: boolean
  has_documents: boolean
  document_count: number
  structured_table_count: number
  latest_committed_version_id: string | null
  updated_at: string | null
}): StudioUseCase => ({
  useCaseId: raw.use_case_config_id,
  name: raw.name,
  domain: raw.domain,
  status: raw.status,
  hasStructured: raw.has_structured,
  hasDocuments: raw.has_documents,
  documentCount: raw.document_count,
  structuredTableCount: raw.structured_table_count,
  latestCommittedVersionId: raw.latest_committed_version_id,
  updatedAt: raw.updated_at,
})

const toSgbBuild = (raw: Record<string, unknown>): SgbBuild => ({
  buildId: raw.build_id as string,
  useCaseId: raw.use_case_config_id as string,
  status: raw.status as string,
  buildNumber: raw.build_number as number,
  name: raw.name as string,
  nodeCount: raw.node_count as number | null,
  relationCount: raw.relation_count as number | null,
  tableCount: raw.table_count as number | null,
  columnCount: raw.column_count as number | null,
  conceptCount: raw.concept_count as number | null,
  createdAt: raw.created_at as string,
  updatedAt: raw.updated_at as string,
  publishedAt: raw.published_at as string | null,
  publishedBy: raw.published_by_user_id as string | null,
  errorMessage: raw.error_message as string | null,
  cursor: raw.cursor as number,
  stepTotal: raw.step_total as number,
  stepMs: raw.step_ms as number,
  stages: raw.stages as SgbStage[],
})

const toSgbStory = (raw: Record<string, unknown>): SgbStory => ({
  storyGroupId: raw.story_group_id as string,
  story: raw.story as string,
  grain: raw.grain as Record<string, unknown>,
  uncertainties: raw.uncertainties as string[],
  editedByUser: raw.edited_by_user as boolean,
})

const toDgbBuild = (raw: Record<string, unknown>): DgbBuild => ({
  buildId: raw.build_id as string,
  documentCorpusId: raw.document_corpus_id as string,
  graphVersion: raw.graph_version as number,
  documentCount: raw.document_count as number,
  entityCount: raw.entity_count as number,
  relationCount: raw.relation_count as number,
  classCount: raw.class_count as number,
  completedAt: raw.completed_at as string,
  publishStatus: raw.publish_status as DgbBuild['publishStatus'],
  publishedAt: raw.published_at as string | null,
  isQueryable: raw.is_queryable as boolean,
})

const toTypeLink = (raw: Record<string, unknown>): TypeLink => ({
  typeLinkId: raw.type_link_id as string,
  bridgeBuildId: raw.bridge_build_id as string,
  entityType: raw.entity_type as string,
  conceptRef: raw.concept_ref as string,
  conceptName: raw.concept_name as string,
  conceptDeclared: raw.concept_declared as boolean,
  decision: raw.decision as TypeLinkDecision,
  confidence: raw.confidence as string,
  reason: raw.reason as string,
  decidedBy: raw.decided_by as string,
  originalDecision: raw.original_decision as string | null,
  originalConfidence: raw.original_confidence as string | null,
  originalReason: raw.original_reason as string | null,
  decidedByUser: raw.decided_by_user_id as string | null,
  decidedAt: raw.decided_at as string | null,
  updatedAt: raw.updated_at as string,
})

const toBridgeBuild = (raw: Record<string, unknown>): BridgeBuild => ({
  bridgeBuildId: raw.bridge_build_id as string,
  useCaseId: raw.use_case_config_id as string,
  buildNumber: raw.build_number as number,
  sgbBuildId: raw.sgb_build_id as string,
  documentCorpusId: raw.document_corpus_id as string,
  dgbGraphVersion: raw.dgb_graph_version as number,
  status: raw.status as string,
  createdAt: raw.created_at as string,
  updatedAt: raw.updated_at as string,
  stageMs: raw.stage_ms as number,
  modelCallsDone: raw.model_calls_done as number,
  modelCallsTotal: raw.model_calls_total as number,
  conceptCount: raw.concept_count as number,
  entityTypeCount: raw.entity_type_count as number,
  linksWritten: raw.links_written as number,
  stages: raw.stages as BridgeStage[],
})

const toGraphVersion = (raw: Record<string, unknown>): StudioVersion => ({
  graphVersionId: raw.graph_version_id as string,
  useCaseId: raw.use_case_config_id as string,
  versionNumber: raw.version_number as number,
  sgbBuildId: raw.sgb_build_id as string | null,
  documentCorpusId: raw.document_corpus_id as string | null,
  dgbGraphVersion: raw.dgb_graph_version as number | null,
  bridgeBuildId: raw.bridge_build_id as string | null,
  publishedAt: raw.published_at as string | null,
  publishedBy: raw.published_by_user_id as string | null,
  createdAt: raw.created_at as string,
})

/* ---------------- fetchers ---------------- */

const ucPath = (useCaseId: string) => `/use-cases/${encodeURIComponent(useCaseId)}`

/**
 * Every use case, with the lanes it has.
 *
 * **Not filtered to the committed ones.** A draft can already have been built, so a shortened list
 * would hide graphs that exist; the selector states each row's lanes instead, which is the answer to
 * "why does this one offer no document build" that a missing row cannot give.
 */
export async function listStudioUseCases(): Promise<{
  useCases: StudioUseCase[]
  /** How many sources this tenant has connected. **The studio's outer precondition**: every lane
   *  derives from one, so with none connected there is nothing to build from — a different dead end
   *  from "no use case yet", and fixed on a different page. */
  connectedSources: number
}> {
  const raw = validate<{
    configs: Parameters<typeof toStudioUseCase>[0][]
    connected_sources: number
  }>('The use cases', await request<unknown>('/use-case-configs'), STUDIO_USE_CASES)
  return {
    useCases: raw.configs.map(toStudioUseCase),
    connectedSources: raw.connected_sources,
  }
}

export async function getStudioUseCase(useCaseId: string): Promise<StudioUseCaseDetail> {
  const raw = validate<Record<string, unknown>>(
    'The use case',
    await request<unknown>(`/use-case-configs/${encodeURIComponent(useCaseId)}`),
    STUDIO_USE_CASE_DETAIL,
  )
  return {
    ...toStudioUseCase(raw as never),
    latestCommittedVersionId: null,
    updatedAt: null,
    businessNeed: raw.business_need as string | null,
    requiredSources: raw.required_sources as string[],
  }
}

export async function listStudioSources(): Promise<StudioSource[]> {
  const raw = validate<{
    sources: { source_id: string; source_type: string; name: string; connector: string }[]
  }>('The sources', await request<unknown>('/metadata-profiler/sources'), STUDIO_SOURCES)
  return raw.sources.map((s) => ({
    sourceId: s.source_id,
    sourceType: s.source_type,
    name: s.name,
    connector: s.connector,
  }))
}

/* ---- structured lane ---- */

export async function draftStory(useCaseId: string): Promise<StoryDraft> {
  const raw = validate<Record<string, unknown>>(
    'The drafted story',
    await request<unknown>('/structured-graph-builder/story-drafts', {
      method: 'POST',
      body: { use_case_config_id: useCaseId },
    }),
    STORY_DRAFT,
  )
  return {
    story: raw.story as string,
    degraded: raw.degraded as boolean,
    degradeReason: raw.degrade_reason as string | null,
    tablesConsidered: raw.tables_considered as number,
    columnsConsidered: raw.columns_considered as number,
    declaredRelationshipsConsidered: raw.declared_relationships_considered as number,
    intentConsidered: raw.intent_considered as boolean,
    heroQuestionsConsidered: raw.hero_questions_considered as number,
  }
}

export async function triggerSgbBuild(input: {
  useCaseId: string
  story?: string
}): Promise<{ buildId: string; status: string }> {
  const raw = validate<{ build_id: string; status: string }>(
    'The queued build',
    await request<unknown>('/structured-graph-builder/builds', {
      method: 'POST',
      body: { use_case_config_id: input.useCaseId, story: input.story },
    }),
    SGB_TRIGGERED,
  )
  return { buildId: raw.build_id, status: raw.status }
}

export async function listSgbBuilds(useCaseId: string): Promise<SgbBuild[]> {
  const raw = validate<{ builds: Record<string, unknown>[] }>(
    'The structured builds',
    await request<unknown>(
      `/structured-graph-builder/builds?use_case_config_id=${encodeURIComponent(useCaseId)}`,
    ),
    SGB_BUILDS,
  )
  return raw.builds.map(toSgbBuild)
}

export async function getSgbBuild(buildId: string): Promise<SgbBuild> {
  return toSgbBuild(
    validate<Record<string, unknown>>(
      'The build',
      await request<unknown>(`/structured-graph-builder/builds/${encodeURIComponent(buildId)}`),
      SGB_BUILD,
    ),
  )
}

/** The typed graph. **200 with an empty graph while the build runs**, so callers gate on the build's
 *  own status rather than on this being non-empty. */
export async function getSgbGraph(buildId: string): Promise<SgbGraph> {
  const raw = validate<Record<string, unknown>>(
    'The structured graph',
    await request<unknown>(
      `/structured-graph-builder/builds/${encodeURIComponent(buildId)}/graph`,
    ),
    SGB_GRAPH,
  )
  return {
    buildId: raw.build_id as string,
    tables: (raw.tables as Record<string, unknown>[]).map((t) => ({
      tableRef: t.table_ref as string,
      tableId: t.table_id as string,
      sourceId: t.source_id as string,
      schemaName: t.schema_name as string | null,
      tableName: t.table_name as string,
      rowCountEstimate: t.row_count_estimate as number | null,
      tableKind: t.table_kind as string,
      selected: t.selected as boolean,
      comment: t.comment as string | null,
    })),
    columns: (raw.columns as Record<string, unknown>[]).map((c) => ({
      columnRef: c.column_ref as string,
      tableRef: c.table_ref as string,
      columnName: c.column_name as string,
      ordinalPosition: c.ordinal_position as number | null,
      dataType: c.data_type as string,
      description: c.description as string | null,
      semanticRole: c.semantic_role as string | null,
      conceptName: c.concept_name as string | null,
      profile: {
        distinctCountInSample: (c.profile as Record<string, unknown>)
          .distinct_count_in_sample as number | null,
        nullRatio: (c.profile as Record<string, unknown>).null_ratio as number | null,
        isSampleClaim: (c.profile as Record<string, unknown>).is_sample_claim as boolean,
      },
    })),
    concepts: (raw.concepts as Record<string, unknown>[]).map((c) => ({
      conceptRef: c.concept_ref as string,
      name: c.name as string,
      description: c.description as string | null,
      declared: c.declared as boolean,
    })),
    edges: (raw.edges as Record<string, unknown>[]).map((e) => ({
      edgeType: e.edge_type as string,
      srcKind: e.src_kind as string,
      srcRef: e.src_ref as string,
      dstKind: e.dst_kind as string,
      dstRef: e.dst_ref as string,
      declared: e.declared as boolean,
    })),
    storyGroup: raw.story_group ? toSgbStory(raw.story_group as Record<string, unknown>) : null,
  }
}

export async function getSgbStory(buildId: string): Promise<SgbStory> {
  return toSgbStory(
    validate<Record<string, unknown>>(
      'The story',
      await request<unknown>(`/structured-graph-builder/builds/${encodeURIComponent(buildId)}/story`),
      SGB_STORY,
    ),
  )
}

/** Edit the story. The build goes back to `running` while it re-extracts — re-poll exactly as for a
 *  fresh trigger. A published build refuses: nothing may change under an approval without a version
 *  moving to say so. */
export async function editSgbStory(input: {
  buildId: string
  story: string
}): Promise<{ status: string }> {
  const raw = validate<{ status: string }>(
    'The story edit',
    await request<unknown>(
      `/structured-graph-builder/builds/${encodeURIComponent(input.buildId)}/story`,
      { method: 'PUT', body: { story: input.story } },
    ),
    shape({ build_id: str, story_group_id: str, status: str }),
  )
  return { status: raw.status }
}

/* ---- document lane ---- */

export async function triggerDgbBuild(useCaseId: string): Promise<{ jobId: string; status: string }> {
  const raw = validate<{ job_id: string; status: string }>(
    'The queued document build',
    await request<unknown>(
      `/document-graph-builder/corpora/${encodeURIComponent(useCaseId)}/build`,
      { method: 'POST' },
    ),
    shape({ job_id: str, status: str, report: shape({}) }),
  )
  return { jobId: raw.job_id, status: raw.status }
}

export async function getDgbJob(jobId: string): Promise<DgbJob> {
  const raw = validate<Record<string, unknown>>(
    'The document build',
    await request<unknown>(`/document-graph-builder/jobs/${encodeURIComponent(jobId)}`),
    DGB_JOB,
  )
  return {
    jobId: raw.job_id as string,
    status: raw.status as string,
    documentsProcessed: raw.documents_processed as number,
    documentTotal: raw.document_total as number,
    createdAt: raw.created_at as string | null,
    completedAt: raw.completed_at as string | null,
    stageMs: raw.stage_ms as number,
    stages: raw.stages as DgbStage[],
    phase: raw.phase as DgbJob['phase'],
  }
}

export async function listDgbBuilds(useCaseId: string): Promise<DgbBuild[]> {
  const raw = validate<{ builds: Record<string, unknown>[] }>(
    'The document graph versions',
    await request<unknown>(
      `/document-graph-builder/graph/builds?document_corpus_id=${encodeURIComponent(useCaseId)}`,
    ),
    DGB_BUILDS,
  )
  return raw.builds.map(toDgbBuild)
}

export async function listDgbEntities(input: {
  useCaseId: string
  limit?: number
}): Promise<DgbEntity[]> {
  const raw = validate<{ items: Record<string, unknown>[] }>(
    'The document entities',
    await request<unknown>(
      `/document-graph-builder/graph/entities?document_corpus_id=${encodeURIComponent(input.useCaseId)}` +
        `&limit=${input.limit ?? 500}`,
    ),
    DGB_PAGE(DGB_ENTITY),
  )
  return raw.items.map((e) => ({
    entityId: e.entity_id as string,
    canonicalName: e.canonical_name as string,
    entityType: e.entity_type as string,
    aliases: e.aliases as string[],
    mentionCount: e.mention_count as number,
    kind: e.kind as string | undefined,
    resolvedType: (e.resolved_type as string | null) ?? null,
  }))
}

export async function listDgbRelations(input: {
  useCaseId: string
  limit?: number
}): Promise<DgbRelation[]> {
  const raw = validate<{ items: Record<string, unknown>[] }>(
    'The document relations',
    await request<unknown>(
      `/document-graph-builder/graph/relations?document_corpus_id=${encodeURIComponent(input.useCaseId)}` +
        `&limit=${input.limit ?? 500}`,
    ),
    DGB_PAGE(DGB_RELATION),
  )
  return raw.items.map((r) => ({
    relationId: r.relation_id as string,
    subjectEntityId: r.subject_entity_id as string,
    objectEntityId: r.object_entity_id as string,
    relationType: r.relation_type as string,
    chunkId: r.chunk_id as string,
    documentId: r.document_id as string | null,
    classes: r.classes as string[],
    confidence: r.confidence as number | null,
  }))
}

export async function listDgbClasses(useCaseId: string): Promise<string[]> {
  return validate<{ classes: string[] }>(
    'The document classes',
    await request<unknown>(
      `/document-graph-builder/graph/classes?document_corpus_id=${encodeURIComponent(useCaseId)}`,
    ),
    DGB_CLASSES,
  ).classes
}

export async function getChunkEvidence(input: {
  useCaseId: string
  chunkId: string
}): Promise<ChunkEvidence> {
  const raw = validate<Record<string, unknown>>(
    'The evidence',
    await request<unknown>(
      `/document-graph-builder/graph/evidence/${encodeURIComponent(input.chunkId)}` +
        `?document_corpus_id=${encodeURIComponent(input.useCaseId)}`,
    ),
    CHUNK_EVIDENCE,
  )
  return {
    chunkId: raw.chunk_id as string,
    documentId: raw.document_id as string,
    chunkText: raw.chunk_text as string | null,
    documentName: raw.document_name as string,
    docTypeLabel: raw.doc_type_label as string | null,
    linkedEntity: raw.linked_entity as string | null,
    pageStart: raw.page_start as number | null,
    pageEnd: raw.page_end as number | null,
  }
}

export async function listCorpusDocuments(useCaseId: string): Promise<CorpusDocument[]> {
  const raw = validate<{ documents: Record<string, unknown>[] }>(
    'The corpus documents',
    await request<unknown>(
      `/document-graph-builder/corpora/${encodeURIComponent(useCaseId)}/documents`,
    ),
    CORPUS_DOCUMENTS,
  )
  return raw.documents.map((d) => ({
    documentId: d.document_id as string,
    filename: d.filename as string,
    mimeType: d.mime_type as string | null,
    docType: d.doc_type as string | null,
    docTypeLabel: d.doc_type_label as string | null,
    linkedEntity: d.linked_entity as string | null,
    pages: d.pages as number | null,
    folder: d.folder as string,
    drive: d.drive as string,
  }))
}

/* ---- combined build ---- */

/** Build everything this use case has, in order. The Bridge stage is **skipped, not failed**, for a
 *  single-lane use case — no bridge id comes back because the Bridge does not exist yet. */
export async function triggerCombinedBuild(input: {
  useCaseId: string
  story?: string
}): Promise<{ sgbBuildId: string | null; dgbJobId: string | null; bridgeFollows: boolean }> {
  const raw = validate<{
    sgb_build_id: string | null
    dgb_job_id: string | null
    bridge_follows: boolean
  }>(
    'The combined build',
    await request<unknown>(`${ucPath(input.useCaseId)}/combined-builds`, {
      method: 'POST',
      body: { story: input.story },
    }),
    COMBINED_TRIGGERED,
  )
  return {
    sgbBuildId: raw.sgb_build_id,
    dgbJobId: raw.dgb_job_id,
    bridgeFollows: raw.bridge_follows,
  }
}

/* ---- the Playground ---- */

const toPlayground = (raw: Record<string, unknown>): Playground => ({
  useCaseId: raw.use_case_config_id as string,
  metrics: (raw.metrics as Record<string, unknown>[]).map((m) => ({
    name: m.name as string,
    description: m.description as string,
    source: m.source as 'ai' | 'user',
    /* Narrowed here rather than passed through: the schema accepts any string, and only
       `'document'` means anything to a reader. */
    origin: m.origin === 'document' ? 'document' : null,
    sql: (m.sql as string | null) ?? null,
    sqlNote: (m.sql_note as string | null) ?? null,
  })),
  goldenQueries: (raw.golden_queries as Record<string, unknown>[]).map((q) => ({
    text: q.text as string,
    priority: q.priority as 'high' | 'normal',
    source: q.source as 'ai' | 'user',
    sql: (q.sql as string | null) ?? null,
  })),
  files: (raw.files as Record<string, unknown>[]).map((f) => ({
    name: f.name as string,
    uploadedAt: f.uploaded_at as string,
    uploadedBy: (f.uploaded_by as string | null) ?? null,
  })),
  queryCap: raw.query_cap as number,
  fileCap: raw.file_cap as number,
})

export async function getPlayground(useCaseId: string): Promise<Playground> {
  return toPlayground(
    validate<Record<string, unknown>>(
      'The Playground',
      await request<unknown>(`${ucPath(useCaseId)}/playground`),
      PLAYGROUND,
    ),
  )
}

/**
 * Write one or both lists back. **Absent means unchanged** — the Metrics tab sends metrics and the
 * Golden Queries tab sends questions, and neither may erase the other's work by not mentioning it,
 * which is the rule `POST /data-model/entities` already keeps.
 */
export async function savePlayground(input: {
  useCaseId: string
  metrics?: PlaygroundMetric[]
  goldenQueries?: GoldenQuery[]
  files?: PlaygroundFile[]
  as: string | null
}): Promise<Playground> {
  const body: Record<string, unknown> = {}
  if (input.metrics) body.metrics = input.metrics
  if (input.goldenQueries) body.golden_queries = input.goldenQueries
  if (input.files) {
    body.files = input.files.map((f) => ({
      name: f.name,
      uploaded_at: f.uploadedAt,
      uploaded_by: f.uploadedBy,
    }))
  }
  return toPlayground(
    validate<Record<string, unknown>>(
      'The Playground',
      await request<unknown>(
        `${ucPath(input.useCaseId)}/playground${input.as ? `?as=${encodeURIComponent(input.as)}` : ''}`,
        { method: 'PATCH', body },
      ),
      PLAYGROUND,
    ),
  )
}

/* ---- Bridge ---- */

export async function triggerBridgeBuild(useCaseId: string): Promise<{ bridgeBuildId: string }> {
  const raw = validate<{ bridge_build_id: string }>(
    'The Bridge',
    await request<unknown>(`${ucPath(useCaseId)}/bridge-builds`, { method: 'POST' }),
    BRIDGE_TRIGGERED,
  )
  return { bridgeBuildId: raw.bridge_build_id }
}

export async function listBridgeBuilds(useCaseId: string): Promise<BridgeBuild[]> {
  const raw = validate<{ bridge_builds: Record<string, unknown>[] }>(
    'The Bridges',
    await request<unknown>(`${ucPath(useCaseId)}/bridge-builds`),
    BRIDGE_BUILDS,
  )
  return raw.bridge_builds.map(toBridgeBuild)
}

export async function getBridgeBuild(input: {
  useCaseId: string
  bridgeBuildId: string
}): Promise<BridgeBuild> {
  return toBridgeBuild(
    validate<Record<string, unknown>>(
      'The Bridge',
      await request<unknown>(
        `${ucPath(input.useCaseId)}/bridge-builds/${encodeURIComponent(input.bridgeBuildId)}`,
      ),
      BRIDGE_BUILD,
    ),
  )
}

export async function listTypeLinks(input: {
  useCaseId: string
  bridgeBuildId: string
}): Promise<TypeLinkList> {
  const raw = validate<{ type_links: Record<string, unknown>[]; unreviewed_count: number }>(
    'The Type Links',
    await request<unknown>(
      `${ucPath(input.useCaseId)}/bridge-builds/${encodeURIComponent(input.bridgeBuildId)}/type-links`,
    ),
    TYPE_LINKS,
  )
  return { typeLinks: raw.type_links.map(toTypeLink), unreviewedCount: raw.unreviewed_count }
}

/** Override one decision. The deriver's own recommendation is preserved beside it, never replaced —
 *  which is what lets the deriver be measured rather than silently corrected. */
export async function overrideTypeLink(input: {
  useCaseId: string
  bridgeBuildId: string
  typeLinkId: string
  decision: TypeLinkDecision
  as?: string | null
}): Promise<TypeLink> {
  return toTypeLink(
    validate<Record<string, unknown>>(
      'The decision',
      await request<unknown>(
        `${ucPath(input.useCaseId)}/bridge-builds/${encodeURIComponent(input.bridgeBuildId)}` +
          `/type-links/${encodeURIComponent(input.typeLinkId)}${asQuery(input.as)}`,
        { method: 'PATCH', body: { decision: input.decision } },
      ),
      TYPE_LINK,
    ),
  )
}

/** Accept every still-undecided correspondence as derived, in one attributed act. Accepting nothing
 *  is a success, not an error. */
export async function acceptOutstandingTypeLinks(input: {
  useCaseId: string
  bridgeBuildId: string
  as?: string | null
}): Promise<{ acceptedCount: number; unreviewedCount: number }> {
  const raw = validate<{ accepted_count: number; unreviewed_count: number }>(
    'The accepted correspondences',
    await request<unknown>(
      `${ucPath(input.useCaseId)}/bridge-builds/${encodeURIComponent(input.bridgeBuildId)}` +
        `/type-links/accept-outstanding${asQuery(input.as)}`,
      { method: 'POST' },
    ),
    ACCEPT_OUTSTANDING,
  )
  return { acceptedCount: raw.accepted_count, unreviewedCount: raw.unreviewed_count }
}

/** Copy this Bridge into a new, editable one over the same pair — the supported way out of a frozen
 *  published Bridge. No re-derivation and no lane rebuild: every decision travels, so it opens with
 *  nothing outstanding. */
export async function reviseBridgeBuild(input: {
  useCaseId: string
  bridgeBuildId: string
}): Promise<BridgeBuild> {
  return toBridgeBuild(
    validate<Record<string, unknown>>(
      'The revised Bridge',
      await request<unknown>(
        `${ucPath(input.useCaseId)}/bridge-builds/${encodeURIComponent(input.bridgeBuildId)}/revise`,
        { method: 'POST' },
      ),
      BRIDGE_BUILD,
    ),
  )
}

export async function getPublishedBridge(useCaseId: string): Promise<PublishedBridge | null> {
  const raw = validate<{
    published_bridge: { bridge_build_id: string; build_number: number; status: string } | null
  }>(
    'The published Bridge',
    await request<unknown>(`${ucPath(useCaseId)}/published-bridge`),
    PUBLISHED_BRIDGE,
  )
  return raw.published_bridge
    ? {
        bridgeBuildId: raw.published_bridge.bridge_build_id,
        buildNumber: raw.published_bridge.build_number,
        status: raw.published_bridge.status,
      }
    : null
}

/* ---- versions ---- */

export async function listGraphVersions(useCaseId: string): Promise<StudioVersion[]> {
  const raw = validate<{ versions: Record<string, unknown>[] }>(
    'The versions',
    await request<unknown>(`${ucPath(useCaseId)}/graph-versions`),
    GRAPH_VERSIONS,
  )
  return raw.versions.map(toGraphVersion)
}

export async function getPublishedGraphVersion(useCaseId: string): Promise<StudioVersion | null> {
  const raw = validate<{ version: Record<string, unknown> | null }>(
    'The published version',
    await request<unknown>(`${ucPath(useCaseId)}/graph-versions/published`),
    ONE_GRAPH_VERSION,
  )
  return raw.version ? toGraphVersion(raw.version) : null
}

/** Name this use case's finished builds with a version if they are not already. **Idempotent** — safe
 *  on every studio load, and `null` rather than an invented version when nothing has finished. */
export async function reconcileGraphVersions(useCaseId: string): Promise<StudioVersion | null> {
  const raw = validate<{ version: Record<string, unknown> | null }>(
    'The version',
    await request<unknown>(`${ucPath(useCaseId)}/graph-versions/reconcile`, { method: 'POST' }),
    ONE_GRAPH_VERSION,
  )
  return raw.version ? toGraphVersion(raw.version) : null
}

export async function getGraphVersionDetail(input: {
  useCaseId: string
  graphVersionId: string
}): Promise<StudioVersionDetail> {
  const raw = validate<Record<string, unknown>>(
    'The version',
    await request<unknown>(
      `${ucPath(input.useCaseId)}/graph-versions/${encodeURIComponent(input.graphVersionId)}`,
    ),
    GRAPH_VERSION_DETAIL,
  )
  return {
    version: toGraphVersion(raw.version as Record<string, unknown>),
    bridgeMatchesNamedTriple: raw.bridge_matches_named_triple as boolean | null,
    bridgeStatus: raw.bridge_status as string | null,
    newerSgbBuildId: raw.newer_sgb_build_id as string | null,
    newerDgbGraphVersion: raw.newer_dgb_graph_version as number | null,
  }
}

/**
 * Approve a version — **every artifact it names, or none of them.**
 *
 * `as` is required in practice and validated by the server: the identity is client-held, so a route
 * has nothing to look a publisher up from, and a publication credited to the seeded account would
 * name somebody who did not press the button.
 */
export async function publishGraphVersion(input: {
  useCaseId: string
  graphVersionId: string
  as?: string | null
}): Promise<StudioVersion> {
  const raw = validate<{ version: Record<string, unknown> }>(
    'The publication',
    await request<unknown>(
      `${ucPath(input.useCaseId)}/graph-versions/${encodeURIComponent(input.graphVersionId)}/publish${asQuery(input.as)}`,
      { method: 'POST' },
    ),
    shape({ version: GRAPH_VERSION }),
  )
  return toGraphVersion(raw.version)
}

/** Withdraw the approval — both lanes' gates clear with it, so the use case answers from nothing
 *  rather than silently falling back to an older version. Idempotent, and never refused. */
export async function unpublishGraphVersion(input: {
  useCaseId: string
  graphVersionId: string
}): Promise<StudioVersion> {
  const raw = validate<{ version: Record<string, unknown> }>(
    'The withdrawal',
    await request<unknown>(
      `${ucPath(input.useCaseId)}/graph-versions/${encodeURIComponent(input.graphVersionId)}/unpublish`,
      { method: 'POST' },
    ),
    shape({ version: GRAPH_VERSION }),
  )
  return toGraphVersion(raw.version)
}

/* ---------------- a hero question's query ---------------- */

/**
 * The query a hero question would be answered by.
 *
 * **`sql` is nullable and a null is an answer**, not a failure: a question whose words reach no
 * profiled column has no query that could be written without naming a table this tenant may not
 * have, and `reason` says so. The box prints that rather than sitting blank.
 */
export interface QuestionSql {
  sql: string | null
  reason: string | null
  /** The table it composed against, and the columns it matched on — the falsifiable part, so a
   *  reader can check the query against the Data Catalog rather than taking it on trust. */
  table: string | null
  columns: string[]
  /** Whether a model produced it. **Always true here**: this is a scan over the profiled columns,
   *  and a payload implying otherwise is the one claim on that box nobody could check. */
  degraded: boolean
  tablesConsidered: number
}

const QUESTION_SQL = shape({
  sql: nullable(str),
  reason: nullable(str),
  table: nullable(str),
  columns: arrayOf(str),
  degraded: bool,
  tables_considered: num,
})

export async function questionSql(input: {
  useCaseId: string
  question: string
}): Promise<QuestionSql> {
  const raw = validate<{
    sql: string | null
    reason: string | null
    table: string | null
    columns: string[]
    degraded: boolean
    tables_considered: number
  }>(
    'The query',
    await request<unknown>('/graph-questions/sql', {
      method: 'POST',
      body: { use_case_id: input.useCaseId, question: input.question },
    }),
    QUESTION_SQL,
  )
  return {
    sql: raw.sql,
    reason: raw.reason,
    table: raw.table,
    columns: raw.columns,
    degraded: raw.degraded,
    tablesConsidered: raw.tables_considered,
  }
}
