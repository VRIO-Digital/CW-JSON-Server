import { now as clockNow } from '../data/pace'
import { create } from 'zustand'
import { AGENT_POOL, GENERIC_PLAN, GOALS, ONCE_ID, WATCH_ID, WATCHERS, type Drill, type Goal, type LogEntry, type PlanStep, type Trigger, type Watcher } from '../data/goalCases'
import { count, findingsSummary, type Tab } from '../data/goalChat'

/*
 * Goal state for the offline prototype. The two seeded goals come from `goalCases.ts`. A goal started
 * from the page is added here, in memory, and the agent's part is simulated on timers so every
 * journey is visible end to end. The analyst drives a goal by talking to its agent; every agent
 * message lives in `chats`, and what the left pane shows lives in `views`.
 *
 *   person   : approach for review → approve → analysing → findings (or needs your input)
 *   schedule : approach for review → approve → armed → runs by itself when due → findings
 *   rule     : approach for review → approve and save → armed (shown only under "Watching for you")
 *              → the rule fires (or is simulated) → the saved approach runs by itself → findings
 *
 * Every firing, run and landing writes a notice to `notices`; the bell shows the unread ones.
 * A goal created from an example (`exampleOf`) ends with that example's real findings, options and
 * recommendation. A goal with no example ends at "needs your input". Nothing is written back.
 */

export interface SavedApproach {
  id: string
  name: string
  fromGoal: string
  savedBy: string
  savedAt: string
  scope: string[]
  constraints: string[]
  plan: PlanStep[]
  /** The recorded analysis this approach was saved from, so a goal started from it lands those findings. */
  exampleOf?: string
}

export interface Notice {
  id: string
  at: string
  kind: 'fired' | 'ran' | 'findings' | 'needs-input' | 'executed'
  goalId: string
  title: string
  text: string
  read: boolean
  /** For a standing goal that fired: what it found, and what it recommends. Shown in the toast and the bell. */
  found?: string
  rec?: string
  /** The button on the toast. */
  cta?: string
  /** The tab the notice opens the goal at. */
  tab: 'approach' | 'findings' | 'runs'
}

export interface ChatMsg {
  id: string
  at: string
  who: 'agent' | 'me' | 'event'
  text: string
  /** A file the analyst dropped into the chat. */
  file?: { name: string; size: number }
  /** A small screen inside the conversation (a step to answer, the approach, the findings, the decision…). */
  card?: string
}

/** What the left pane of a goal shows: a tab, and inside it the finding, drill, story or step in focus. */
export interface GoalView {
  tab: Tab
  finding?: string
  drill?: Drill
  story?: string
  step?: string
}

export interface NewGoalInput {
  goal: string
  measure: string
  target: string
  scope: string
  constraints: string
  trigger: Trigger
  when: string
  owner: string
  approachId?: string
  exampleOf?: string
  agentName?: string
  /** For a rule: where the condition is checked. */
  conditionSource?: 'data' | 'external'
  /** The conversation that created the goal, carried into its chat. */
  chat?: ChatMsg[]
  files?: { name: string; size: number; read: string; problem?: string }[]
}

interface GoalState {
  goals: Goal[]
  approaches: SavedApproach[]
  watchers: Watcher[]
  notices: Notice[]
  chats: Record<string, ChatMsg[]>
  views: Record<string, GoalView>
  typing: Record<string, boolean>
  markRead: (id: string) => void
  markAllRead: () => void
  say: (id: string, who: ChatMsg['who'], text: string, file?: ChatMsg['file']) => void
  /** Put a card in the goal's conversation. */
  post: (id: string, card: string) => void
  setTyping: (id: string, on: boolean) => void
  setView: (id: string, v: Partial<GoalView> & { tab: Tab }) => void
  start: (input: NewGoalInput) => string
  setPlan: (id: string, plan: PlanStep[], who: string) => void
  approvePlan: (id: string, who: string) => void
  revisePlan: (id: string, who: string) => void
  fire: (id: string, who: string) => void
  addLog: (id: string, who: string, what: string) => void
  answer: (id: string, who: string, text: string) => void
  saveApproach: (id: string, name: string, who: string) => string
  choose: (id: string, recId: string, who: string) => void
  acceptFindings: (id: string, ids: string[], who: string) => void
  /** Demo control: finish a running approach now, with every step's actions, and land the findings. */
  finishNow: (id: string, who: string) => void
  /** A scheduled goal that has already run can be run again on demand (the next scheduled run, now). */
  rearm: (id: string) => void
  attach: (id: string, file: { name: string; size: number; read: string; problem?: string }, who: string) => void
}

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 40)
const now = () => clockNow().toISOString()
let seq = 0
const msg = (who: ChatMsg['who'], text: string, at = now()): ChatMsg => ({ id: `m${(seq += 1)}-${Date.now().toString(36)}`, at, who, text })
const fmt = (iso: string) => new Date(iso).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })

/** A seeded rule goal that has not fired is armed: its approach was approved and saved with the rule; its
 *  recorded findings land only when the rule fires, so it is stripped here and points at itself as the example. */
const isArmedRule = (g: Goal) => g.trigger === 'rule' && (g.status === 'armed' || g.status === 'fired')
const seedGoal = (g: Goal): Goal => {
  const armed = isArmedRule(g)
  const plan = g.plan.map((p) => ({ ...p, trace: p.state === 'done' && !armed ? p.actions ?? [] : [], state: armed ? ('pending' as const) : p.state }))
  if (!armed) return { ...g, plan }
  return { ...g, status: 'armed', plan, findings: [], gaps: [], recommendations: [], submissions: [], askRefs: [], exampleOf: g.id, target: { ...g.target, current: 'Read when the approach runs' } }
}

const SEEDED_GOALS = GOALS.map(seedGoal)

const SEEDED_CHATS: Record<string, ChatMsg[]> = Object.fromEntries(
  SEEDED_GOALS.map((g) => {
    if (g.status === 'armed') {
      return [g.id, [
        msg('event', `Rule set by ${g.owner} · ${fmt(g.planApproved?.at ?? g.startedAt)}`, g.planApproved?.at ?? g.startedAt),
        msg('agent', `The approach is approved and saved with the rule: ${count(g.plan.length)} steps, on the right. I check every snapshot. When a project crosses 10% I run it by myself and bring you the findings.\n\nSay "simulate the rule" to see it fire.`, g.planApproved?.at ?? g.startedAt),
        { ...msg('agent', '', g.planApproved?.at ?? g.startedAt), card: 'armed' },
      ]]
    }
    const first = g.log[0]
    return [g.id, [
      msg('event', `${g.trigger === 'schedule' ? 'Scheduled run' : 'Started'} · ${fmt(first?.at ?? g.startedAt)}`, first?.at ?? g.startedAt),
      msg('agent', findingsSummary(g), g.log[g.log.length - 1]?.at ?? g.startedAt),
      { ...msg('agent', '', g.log[g.log.length - 1]?.at ?? g.startedAt), card: 'findings' },
    ]]
  }),
)

const SEEDED_VIEWS: Record<string, GoalView> = Object.fromEntries(SEEDED_GOALS.map((g) => [g.id, { tab: g.findings.length ? 'findings' : 'approach' } as GoalView]))

const SEEDED_APPROACHES: SavedApproach[] = GOALS.filter((g) => g.approachName).map((g) => ({
  id: `ap-${g.id}`,
  exampleOf: g.id,
  name: g.approachName!,
  fromGoal: g.title,
  savedBy: g.planApproved?.by ?? g.owner,
  savedAt: g.planApproved?.at ?? g.startedAt,
  scope: g.scope,
  constraints: g.constraints,
  plan: g.plan.map((s) => ({ ...s, state: 'pending' as const, editedBy: undefined })),
}))

/** The goal as an example, so the whole journey can be walked with real content. */
export const exampleInput = (g: Goal, owner: string): Omit<NewGoalInput, 'owner'> & { owner: string } => ({
  goal: g.goal,
  measure: g.target.measure,
  target: g.target.target,
  scope: g.scope.join('\n'),
  constraints: g.constraints.join('\n'),
  trigger: g.trigger,
  when: g.trigger === 'rule' ? 'A contract changes rating, a factor moves a full point, or a sign appears outside the scorecard' : g.trigger === 'schedule' ? 'Before every quarterly portfolio review' : g.target.deadline,
  owner,
  exampleOf: g.id,
  conditionSource: g.trigger === 'rule' ? 'data' : undefined,
})

export const useGoalStore = create<GoalState>((set, get) => {
  const patch = (id: string, fn: (g: Goal) => Goal) => set({ goals: get().goals.map((g) => (g.id === id ? fn(g) : g)) })
  const log = (id: string, who: string, what: string) => patch(id, (g) => ({ ...g, log: [...g.log, { at: now(), who: who === 'Agent' ? g.agent.name : who, what }] }))
  const say = (id: string, who: ChatMsg['who'], text: string, file?: ChatMsg['file']) => set({ chats: { ...get().chats, [id]: [...(get().chats[id] ?? []), { ...msg(who, text), file }] } })
  const post = (id: string, card: string) => set({ chats: { ...get().chats, [id]: [...(get().chats[id] ?? []), { ...msg('agent', ''), card }] } })
  const view = (id: string, v: GoalView) => set({ views: { ...get().views, [id]: v } })
  const patchWatcher = (goalId: string, fn: (w: Watcher) => Watcher) => set({ watchers: get().watchers.map((w) => (w.goalId === goalId ? fn(w) : w)) })
  const notify = (goalId: string, kind: Notice['kind'], title: string, text: string, tab: Notice['tab']) =>
    set({ notices: [{ id: `n-${goalId}-${Date.now().toString(36)}`, at: now(), kind, goalId, title, text, read: false, tab }, ...get().notices] })

  /* Run the approved steps one by one, showing each agent action as it happens, then land the goal.
   * Reading a table or a mailbox is slow, a sum or a comparison quick, composing options a moment, a
   * check short; a little jitter, and a pause opening each step. */
  const ACTION_MS: [RegExp, number][] = [
    [/^rule\b|^resolve\b/, 2600], [/^read_document\b/, 2800], [/^read_mail\b/, 2400], [/^read_table\b/, 2000],
    [/^sum\b|^compute\b|^compare\b|^trace\b|^mark\b/, 1300], [/^rank\b|^assign\b|^compose\b/, 2200], [/^check\b/, 900],
  ]
  const actionMs = (a: string) => Math.round((ACTION_MS.find(([re]) => re.test(a))?.[1] ?? 1600) * 0.6 * (0.85 + Math.random() * 0.3))
  const STEP_OPEN_MS = 900
  const timers: Record<string, number[]> = {}
  const later = (id: string, fn: () => void, ms: number) => { (timers[id] ??= []).push(window.setTimeout(fn, ms)) }
  const actionsOf = (step: PlanStep) => (step.actions?.length ? step.actions : [`resolve → ${step.title}.`, `read_table ${step.sources[0] ?? 'graph'} → read for the step.`, `check → ${step.check} Passed.`])
  /* The approach has run: write the findings (from the example it was started from), or ask the one question. */
  const land = (id: string) => {
    const cur = get().goals.find((x) => x.id === id)!
    /* A goal started from an example lands that example's analysis; a seeded goal that runs again lands its own. */
    const ex = GOALS.find((e) => e.id === (cur.exampleOf ?? cur.id))
    const follow = get().views[id]?.tab === 'approach'
    /* What is watching for you says how the run ended, not that it is still running. */
    if (cur.trigger !== 'person') patchWatcher(id, (w) => ({ ...w, state: cur.trigger === 'rule' ? 'Watching' : 'Scheduled', last: `Last run ${fmt(now())} · ${ex?.question || !ex ? 'one question for you' : 'findings ready'}` }))
    if (ex) {
      patch(id, (x) => ({
        ...x,
        status: ex.question ? 'needs-input' : 'findings-ready',
        question: ex.question,
        target: { ...x.target, current: ex.target.current, tolerance: ex.target.tolerance, decision: ex.target.decision },
        findings: ex.findings, gaps: ex.gaps, recommendations: ex.recommendations, submissions: ex.submissions, askRefs: ex.askRefs,
      }))
      log(id, 'Agent', `Findings ready: ${ex.findings.length} findings, ${ex.recommendations.length} recommendations, one preferred.`)
      say(id, 'agent', findingsSummary(ex))
      post(id, 'findings')
      if (ex.question) { say(id, 'agent', `One question before the recommendation is final: ${ex.question}`); post(id, 'question') }
      if (follow) view(id, { tab: 'findings', finding: ex.findings[0]?.id })
      notify(id, ex.question ? 'needs-input' : 'findings', `${ex.question ? 'One question for you' : 'Findings ready'}: ${cur.title}`, `${cur.agent.name} brings ${ex.findings.length} findings and ${ex.recommendations.length} recommendations, one preferred.`, 'findings')
    } else {
      const q = 'The goal names a measure the graph does not compute today (a final or predicted cost). Should I drop it from the goal, or state it as a range from the recorded positions?'
      patch(id, (x) => ({ ...x, status: 'needs-input', question: q }))
      log(id, 'Agent', 'All steps run. One question before findings are written.')
      say(id, 'agent', `All steps run. One question before I write the findings:\n\n${q}`)
      post(id, 'question')
      notify(id, 'needs-input', `One question for you: ${cur.title}`, `${cur.agent.name} needs an answer before findings are written.`, 'findings')
    }
  }
  const run = (id: string) => {
    const g = get().goals.find((x) => x.id === id)
    if (!g) return
    ;(timers[id] ?? []).forEach((t) => window.clearTimeout(t))
    timers[id] = []
    post(id, 'run')
    const live = g.plan.filter((s) => s.state !== 'removed')
    patch(id, (x) => ({ ...x, status: 'analysing', plan: x.plan.map((s) => (s.state === 'removed' ? s : { ...s, trace: [], state: s.id === live[0]?.id ? 'running' : 'pending' })) }))
    view(id, { tab: 'approach', step: live[0]?.id })
    /* Paced like real work, but a whole run stays under about twenty seconds in the demo. */
    const planned = live.reduce((acc, st) => acc + STEP_OPEN_MS + 600 + actionsOf(st).reduce((a2, a) => a2 + actionMs(a), 0), 400)
    const k = Math.min(1, 20000 / planned)
    let t = 400
    live.forEach((step, i) => {
      t += STEP_OPEN_MS * k
      actionsOf(step).forEach((a) => {
        t += actionMs(a) * k
        later(id, () => patch(id, (x) => ({ ...x, plan: x.plan.map((s) => (s.id === step.id ? { ...s, trace: [...(s.trace ?? []), a] } : s)) })), t)
      })
      t += 600 * k
      later(id, () => {
        patch(id, (x) => ({ ...x, plan: x.plan.map((s) => (s.id === step.id ? { ...s, state: 'done' } : live[i + 1]?.id === s.id ? { ...s, state: 'running' } : s)) }))
        log(id, 'Agent', `Step ${i + 1} done: ${step.title}.`)
        const v = get().views[id]
        if (live[i + 1] && v?.tab === 'approach') view(id, { ...v, step: live[i + 1].id })
        if (i === live.length - 1) land(id)
      }, t)
    })
  }

  return {
    goals: SEEDED_GOALS.filter((g) => g.id === ONCE_ID),
    approaches: SEEDED_APPROACHES,
    watchers: WATCHERS,
    notices: [],
    chats: SEEDED_CHATS,
    views: SEEDED_VIEWS,
    typing: {},
    markRead: (id) => set({ notices: get().notices.map((n) => (n.id === id ? { ...n, read: true } : n)) }),
    markAllRead: () => set({ notices: get().notices.map((n) => ({ ...n, read: true })) }),
    say,
    post,
    setTyping: (id, on) => set({ typing: { ...get().typing, [id]: on } }),
    setView: (id, v) => view(id, v),

    start: ({ goal, measure, target, scope, constraints, trigger, when, owner, approachId, exampleOf, agentName, conditionSource, chat, files }) => {
      const id = `g-${slug(goal) || 'new'}-${Date.now().toString(36)}`
      const t = now()
      const approach = approachId ? get().approaches.find((a) => a.id === approachId) : undefined
      /* Which recorded analysis the goal can land: the example picked, the one its words name (the Q3 committee
         pack, the P-VM-046 washing plant), or the one its saved approach came from when it is the same goal again.
         A saved approach used on another project (say P-VM-031) has no recorded analysis in this copy, and says so. */
      const named = (t: string) => (/\b(renewal|renewals|calder|evergreen)\b/i.test(t) ? ONCE_ID : /\b(scorecard|contract risk|harlow|demand letter)\b/i.test(t) ? WATCH_ID : undefined)
      exampleOf = exampleOf ?? named(goal) ?? (approach && goal.trim() === approach.fromGoal.trim() ? approach.exampleOf : undefined)
      const picked = !!exampleOf && !approach && GOALS.some((e) => e.id === exampleOf && e.goal === goal)
      const ex = exampleOf ? GOALS.find((e) => e.id === exampleOf) : undefined
      const triggerDetail =
        trigger === 'person' ? `${owner} started it${when ? `, deadline ${when}` : ''}.` : trigger === 'schedule' ? `Runs ${when || 'on a schedule'}.` : `Fires when: ${when || 'the rule matches'}${conditionSource === 'external' ? ' (checked on the internet every morning)' : ' (checked in our data at every snapshot)'}.`
      const used = new Set(get().goals.map((x) => x.agent.name))
      const free = AGENT_POOL.find((a) => !used.has(a.name)) ?? AGENT_POOL[get().goals.length % AGENT_POOL.length]
      const typed = agentName?.trim()
      const agent = typed ? { ...free, name: /^agent\b/i.test(typed) ? typed : `Agent ${typed}` } : free
      const planNow = approach ? approach.plan.map((s) => ({ ...s, state: 'pending' as const, trace: [] })) : ex ? ex.plan.map((s) => ({ ...s, state: 'pending' as const, editedBy: undefined, trace: [] })) : GENERIC_PLAN(goal)
      const g: Goal = {
        id,
        title: picked && ex ? ex.title : goal.length > 72 ? `${goal.slice(0, 70)}…` : goal,
        agent,
        goal,
        target: { measure, target, current: 'Read when the approach runs', tolerance: ex?.target.tolerance ?? 'Not stated', deadline: trigger === 'person' ? when || 'Not stated' : ex?.target.deadline ?? 'Set by the trigger', decision: ex?.target.decision ?? 'Stated in the goal' },
        trigger,
        triggerDetail,
        status: 'plan-review',
        owner,
        ownerRole: 'Accountable',
        startedAt: t,
        scope: scope ? scope.split('\n').filter(Boolean) : approach?.scope ?? ['Role graph: Contract Risk Analyst, Northline Water Group v1'],
        constraints: constraints ? constraints.split('\n').filter(Boolean) : approach?.constraints ?? [],
        plan: [],
        findings: [], gaps: [], recommendations: [], submissions: [], askRefs: [],
        log: [{ at: t, who: owner, what: `Created the goal. ${triggerDetail}${approach ? ` Starting from the saved approach "${approach.name}".` : ''}` }],
        exampleOf,
        files,
      }
      set({
        goals: [g, ...get().goals],
        chats: { ...get().chats, [id]: [...(chat ?? []), msg('event', `Goal created · ${agent.name}`)] },
        views: { ...get().views, [id]: { tab: 'approach' } },
        typing: { ...get().typing, [id]: true },
      })
      if (trigger !== 'person') {
        set({ watchers: [{ id: `wn-${id}`, kind: trigger, label: trigger === 'rule' ? `Rule: ${g.title}` : `Schedule: ${g.title}`, condition: when || (trigger === 'rule' ? 'Condition to be stated' : 'Schedule to be stated'), last: 'Approach for your review', state: trigger === 'rule' ? 'Watching' : 'Scheduled', goalId: id, source: trigger === 'rule' ? (conditionSource ?? 'data') : undefined }, ...get().watchers] })
      }
      window.setTimeout(() => {
        patch(id, (x) => ({ ...x, plan: planNow }))
        log(id, 'Agent', `Proposed a ${planNow.length}-step approach.`)
        set({ typing: { ...get().typing, [id]: false } })
        const ending = trigger === 'rule'
          ? 'When it is right, say "approve". I save it with the rule, and when the rule fires I run it by myself and bring you the findings.'
          : trigger === 'schedule' ? 'When it is right, say "approve". It then runs by itself on the schedule.' : 'When it is right, say "approve" and I start.'
        say(id, 'agent', `Here is how I would go about it: ${count(planNow.filter((s) => s.state !== 'removed').length)} steps.${approach ? ` (From your saved approach "${approach.name}".)` : ''} Click a step to see it in full on the right. Change it here or in your own words: "remove step 3", "add a step to read the supplier mail", "move step 4 up".\n\n${ending}`)
        post(id, 'approach')
      }, 2600)
      return id
    },

    setPlan: (id, plan, who) => {
      patch(id, (g) => ({ ...g, plan }))
      log(id, who, 'Changed the approach.')
    },

    approvePlan: (id, who) => {
      const g = get().goals.find((x) => x.id === id)
      if (!g) return
      patch(id, (x) => ({ ...x, planApproved: { by: who, at: now() } }))
      if (g.trigger === 'person') {
        log(id, who, 'Approved the approach. The agent starts now.')
        say(id, 'agent', 'Approved. Starting now; follow each step below, and open any of them on the right.')
        run(id)
        return
      }
      patch(id, (x) => ({ ...x, status: 'armed' }))
      const w = get().watchers.find((x) => x.goalId === id)
      if (g.trigger === 'rule') {
        patchWatcher(id, (x) => ({ ...x, state: 'Watching', last: 'Armed · watching' }))
        log(id, who, 'Approved and saved the approach with the rule. It runs by itself when the rule fires.')
        say(id, 'agent', `Approved and saved with the rule. Nothing runs until it fires${w ? `: ${w.condition.charAt(0).toLowerCase()}${w.condition.slice(1)}` : ''}. Then I run this approach by myself and bring you the findings.\n\nIt is now in your list under "Watching for you". You can leave it there, or simulate the rule to see what happens when it fires.`)
        post(id, 'armed')
      } else {
        patchWatcher(id, (x) => ({ ...x, state: 'Scheduled', last: 'Armed · next run per schedule' }))
        log(id, who, 'Approved the approach. The agent runs it on the schedule by itself.')
        say(id, 'agent', `Approved and saved. It runs by itself${w ? ` ${w.condition.charAt(0).toLowerCase()}${w.condition.slice(1)}` : ' on the schedule'}, and you hear from me when the findings land.\n\nSay "simulate: run now" to see a run.`)
        post(id, 'armed')
      }
    },

    fire: (id, who) => {
      const g = get().goals.find((x) => x.id === id)
      if (!g || g.status !== 'armed') return
      const stamp = fmt(now())
      const w = get().watchers.find((x) => x.goalId === id)
      if (g.trigger === 'rule') {
        patchWatcher(id, (x) => ({ ...x, state: 'Fired', last: `Fired ${stamp} · running the saved approach` }))
        set({ goals: [...get().goals.filter((x) => x.id === id), ...get().goals.filter((x) => x.id !== id)] })
        log(id, 'Rule', `Condition met${w?.source === 'external' ? ' on the internet' : ' in our data'}: ${w?.condition ?? g.triggerDetail}. Running the approach approved with the rule.`)
        say(id, 'event', `Rule fired · ${stamp}`)
        const cond = (w?.condition ?? g.triggerDetail).replace(/\.$/, '')
        say(id, 'agent', `The rule fired: ${cond.charAt(0).toLowerCase()}${cond.slice(1)}. Running the approach you approved.`)
        notify(id, 'fired', `Rule fired: ${g.title}`, `${g.agent.name} is running the approved approach. Findings follow.`, 'approach')
      } else {
        patchWatcher(id, (x) => ({ ...x, state: 'Scheduled', last: `Ran ${stamp}` }))
        log(id, who === 'Agent' ? 'Schedule' : who, 'Scheduled run started; the approved approach runs by itself.')
        say(id, 'event', `Scheduled run · ${stamp}`)
        say(id, 'agent', 'Scheduled run started. Running the approved approach.')
        notify(id, 'ran', `Scheduled run started: ${g.title}`, `${g.agent.name} is running the approved approach.`, 'approach')
      }
      run(id)
    },

    revisePlan: (id, who) => {
      const g = get().goals.find((x) => x.id === id)
      patch(id, (x) => ({ ...x, status: 'plan-review', planApproved: undefined, plan: x.plan.map((s) => ({ ...s, trace: [], state: s.state === 'removed' ? 'removed' : 'pending' })) }))
      if (g?.trigger !== 'person') patchWatcher(id, (x) => ({ ...x, last: 'Approach reopened · not armed' }))
      log(id, who, 'Reopened the approach.')
      view(id, { tab: 'approach' })
      say(id, 'agent', `Reopened. ${g?.trigger === 'person' ? '' : 'The trigger is paused until you approve again. '}Tell me what to change.`)
      post(id, 'approach')
    },

    addLog: (id, who, what) => log(id, who, what),

    answer: (id, who, text) => {
      const g = get().goals.find((x) => x.id === id)
      patch(id, (x) => ({ ...x, status: 'findings-ready', question: undefined }))
      const entries: LogEntry[] = [
        { at: now(), who, what: `Answered: ${text}` },
        { at: now(), who: g?.agent.name ?? 'Agent', what: 'Answer taken into account.' },
      ]
      patch(id, (x) => ({ ...x, log: [...x.log, ...entries] }))
    },

    choose: (id, recId, who) => {
      const g = get().goals.find((x) => x.id === id)
      const r = g?.recommendations.find((x) => x.id === recId)
      if (!g || !r) return
      patch(id, (x) => ({ ...x, status: 'accepted', recommendations: x.recommendations.map((o) => ({ ...o, preferred: o.id === recId })) }))
      log(id, who, `Chose the recommendation "${r.title}".`)
    },

    rearm: (id) => {
      const g = get().goals.find((x) => x.id === id)
      if (!g || g.trigger === 'person' || g.status === 'analysing') return
      patch(id, (x) => ({ ...x, status: 'armed', question: undefined }))
    },

    finishNow: (id, who) => {
      const g = get().goals.find((x) => x.id === id)
      if (!g || g.status !== 'analysing') return
      ;(timers[id] ?? []).forEach((t) => window.clearTimeout(t))
      timers[id] = []
      patch(id, (x) => ({ ...x, plan: x.plan.map((s) => (s.state === 'removed' ? s : { ...s, state: 'done', trace: actionsOf(s) })) }))
      log(id, who, 'Fast-forwarded the run (demo).')
      land(id)
    },

    acceptFindings: (id, ids, who) => {
      patch(id, (x) => ({ ...x, acceptedFindings: [...new Set([...(x.acceptedFindings ?? []), ...ids])] }))
      const g = get().goals.find((x) => x.id === id)
      const nums = ids.map((fid) => (g?.findings.findIndex((f) => f.id === fid) ?? -1) + 1).filter((n) => n > 0)
      log(id, who, `Accepted finding${nums.length === 1 ? '' : 's'} ${nums.join(', ')}.`)
    },

    attach: (id, file, who) => {
      patch(id, (x) => ({ ...x, files: [...(x.files ?? []).filter((f) => f.name !== file.name), file] }))
      log(id, who, `Added the file ${file.name} (${file.read}).`)
    },

    saveApproach: (id, name, who) => {
      const g = get().goals.find((x) => x.id === id)
      if (!g) return ''
      const apId = `ap-${slug(name)}-${Date.now().toString(36)}`
      set({
        approaches: [
          { id: apId, exampleOf: g.exampleOf ?? (GOALS.some((e) => e.id === g.id) ? g.id : undefined), name, fromGoal: g.title, savedBy: who, savedAt: now(), scope: g.scope, constraints: g.constraints, plan: g.plan.filter((s) => s.state !== 'removed').map((s) => ({ ...s, state: 'pending' as const, editedBy: undefined, trace: [] })) },
          ...get().approaches,
        ],
      })
      patch(id, (x) => ({ ...x, approachName: name }))
      log(id, who, `Saved the approach for reuse as "${name}".`)
      return apId
    },
  }
})
