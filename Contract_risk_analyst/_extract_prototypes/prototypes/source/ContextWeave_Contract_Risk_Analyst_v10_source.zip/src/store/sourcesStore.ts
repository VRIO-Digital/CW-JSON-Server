import { create } from 'zustand'
import {
  deleteSource,
  disconnectSource,
  listSources,
  reconnectSource,
  updateSourceDatasets,
  updateSourceFolders,
  type ReleasedDeclarations,
  type SourceRow,
} from '../api/client'
import { toMessage, type Result } from './asyncState'

export type { Result }

interface SourcesPayload {
  sources: SourceRow[]
  registeredCount: number
  connectedSources: number
  profiledTables: number
  profiledColumns: number
  profiledDocuments: number
  profiledEntities: number
}

interface SourcesState {
  data: SourcesPayload | null
  loading: boolean
  error: string | null
  /** sourceId of the row whose action is in flight, so only its button spins. */
  pending: string | null

  load: () => Promise<void>
  disconnect: (sourceId: string) => Promise<Result>
  /** The undo for `disconnect` — the source keeps everything it had profiled. */
  reconnect: (sourceId: string) => Promise<Result>
  /*
   * Carries back what the delete *released* as well as whether it worked, because the page reports
   * it — the acceptances the source's declarations held, cleared so those rows read *Curated by AI*
   * again. A bare `Result` would leave the page composing that sentence from the row it submitted,
   * which is a claim about writes rather than a report of them.
   */
  remove: (sourceId: string) => Promise<Result & { released?: ReleasedDeclarations }>
  setDatasets: (sourceId: string, datasets: string[]) => Promise<Result>
  setFolders: (sourceId: string, folders: string[]) => Promise<Result>
}

const EMPTY: SourceRow[] = []

export const useSourcesStore = create<SourcesState>()((set, get) => ({
  data: null,
  loading: false,
  error: null,
  pending: null,

  load: async () => {
    set({ loading: true })
    try {
      set({ data: await listSources(), error: null, loading: false })
    } catch (error) {
      set({ error: toMessage(error), loading: false })
    }
  },

  disconnect: async (sourceId) => {
    set({ pending: sourceId })
    try {
      await disconnectSource(sourceId)
      await get().load()
      return { ok: true }
    } catch (error) {
      return { ok: false, error: toMessage(error) }
    } finally {
      set({ pending: null })
    }
  },

  reconnect: async (sourceId) => {
    set({ pending: sourceId })
    try {
      await reconnectSource(sourceId)
      await get().load()
      return { ok: true }
    } catch (error) {
      /* Re-read before reporting: a request whose *response* was lost has still been carried
         out, and "the write failed" and "I did not hear whether it succeeded" are different
         facts. See docs/REGRESSIONS.md. */
      await get().load()
      return { ok: false, error: toMessage(error) }
    } finally {
      set({ pending: null })
    }
  },

  remove: async (sourceId) => {
    set({ pending: sourceId })
    try {
      const { released } = await deleteSource(sourceId)
      await get().load()
      return { ok: true, released }
    } catch (error) {
      return { ok: false, error: toMessage(error) }
    } finally {
      set({ pending: null })
    }
  },

  setDatasets: async (sourceId, datasets) => {
    // Guard before the request: the server rejects this too, but a local check
    // keeps a pointless round-trip out of the way.
    if (datasets.length === 0) {
      return { ok: false, error: 'Keep at least one dataset in the allowlist.' }
    }
    set({ pending: sourceId })
    try {
      await updateSourceDatasets(sourceId, datasets)
      await get().load()
      return { ok: true }
    } catch (error) {
      return { ok: false, error: toMessage(error) }
    } finally {
      set({ pending: null })
    }
  },

  /** The Drive allowlist: same contract, folders instead of datasets. */
  setFolders: async (sourceId, folders) => {
    if (folders.length === 0) {
      return { ok: false, error: 'Keep at least one folder in the allowlist.' }
    }
    set({ pending: sourceId })
    try {
      await updateSourceFolders(sourceId, folders)
      await get().load()
      return { ok: true }
    } catch (error) {
      return { ok: false, error: toMessage(error) }
    } finally {
      set({ pending: null })
    }
  },
}))

/** Stable empty array so selectors don't churn on every render. */
export const selectSources = (s: SourcesState) => s.data?.sources ?? EMPTY
