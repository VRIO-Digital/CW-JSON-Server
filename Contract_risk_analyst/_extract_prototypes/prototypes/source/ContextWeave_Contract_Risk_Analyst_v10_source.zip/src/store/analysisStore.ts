import { create } from 'zustand'
import { ANALYSES, type Analysis, type LogEntry, type Trigger } from '../data/analysisCases'

/*
 * Analysis state for the offline prototype. The two seeded cases come from `analysisCases.ts`; a new
 * analysis started from the page is added here, in memory, and progresses through its first steps on
 * a timer so the list shows what "investigating" looks like. Nothing is written back anywhere: this
 * is the experience being designed, not an engine.
 */

interface NewAnalysisInput {
  goal: string
  scope: string
  constraints: string
  trigger: Trigger
  when: string
  owner: string
}

interface AnalysisState {
  analyses: Analysis[]
  start: (input: NewAnalysisInput) => string
  addLog: (id: string, who: string, what: string) => void
  accept: (id: string, who: string) => void
  answer: (id: string, who: string, text: string) => void
}

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 40)

export const useAnalysisStore = create<AnalysisState>((set, get) => ({
  analyses: ANALYSES,

  start: ({ goal, scope, constraints, trigger, when, owner }) => {
    const id = `an-${slug(goal) || 'new'}-${Date.now().toString(36)}`
    const now = new Date().toISOString()
    const triggerDetail =
      trigger === 'person'
        ? `${owner} started it ${when ? `with the deadline "${when}"` : 'now'}.`
        : trigger === 'schedule'
          ? `Runs ${when || 'on a schedule'}; first run now.`
          : `Fires when ${when || 'the rule matches'}; opened now for the first match.`
    const a: Analysis = {
      id,
      title: goal.length > 72 ? `${goal.slice(0, 70)}…` : goal,
      goal,
      trigger,
      triggerDetail,
      status: 'investigating',
      owner,
      ownerRole: 'Accountable',
      startedAt: now,
      scope: scope ? scope.split('\n').filter(Boolean) : ['Role graph: Capital Project Analyst, Keolis Valmont v1'],
      constraints: constraints ? constraints.split('\n').filter(Boolean) : [],
      findings: [],
      gaps: [],
      options: [],
      recommendation: '',
      recommendationWhy: [],
      submissions: [],
      log: [{ at: now, who: owner, what: `Started the analysis. ${triggerDetail}` }],
      askRefs: [],
    }
    set({ analyses: [a, ...get().analyses] })
    /* The first steps every analysis takes, so the list is honest about what "investigating" means. */
    const steps: [number, string][] = [
      [1500, 'Grounded the goal in the published graph: 29 projects, 12 governed measures, 25 documents, 10 mail threads in scope.'],
      [4000, 'Reading forecast snapshots, budget lines and commitments for the projects in scope.'],
      [7000, 'Reading contracts, change requests and supplier correspondence that touch those projects.'],
      [10000, 'Waiting for the accountable person: the scope names a measure the graph does not compute (final cost). Say whether to drop it or state it as a range.'],
    ]
    steps.forEach(([ms, what], i) =>
      window.setTimeout(() => {
        const cur = get().analyses.find((x) => x.id === id)
        if (!cur) return
        const entry: LogEntry = { at: new Date().toISOString(), who: 'Context Weave analyst', what }
        set({
          analyses: get().analyses.map((x) =>
            x.id === id ? { ...x, log: [...x.log, entry], status: i === steps.length - 1 ? 'needs-input' : x.status } : x,
          ),
        })
      }, ms),
    )
    return id
  },

  addLog: (id, who, what) =>
    set({
      analyses: get().analyses.map((x) => (x.id === id ? { ...x, log: [...x.log, { at: new Date().toISOString(), who, what }] } : x)),
    }),

  accept: (id, who) =>
    set({
      analyses: get().analyses.map((x) =>
        x.id === id
          ? { ...x, status: 'accepted', log: [...x.log, { at: new Date().toISOString(), who, what: 'Accepted the recommendation. Findings are now reusable by AI Submissions.' }] }
          : x,
      ),
    }),

  answer: (id, who, text) =>
    set({
      analyses: get().analyses.map((x) =>
        x.id === id
          ? {
              ...x,
              status: 'findings-ready',
              question: undefined,
              log: [
                ...x.log,
                { at: new Date().toISOString(), who, what: `Answered the open question: ${text}` },
                { at: new Date().toISOString(), who: 'Context Weave analyst', what: 'Recommendation confirmed with the answer taken into account. Findings ready.' },
              ],
            }
          : x,
      ),
    }),
}))
