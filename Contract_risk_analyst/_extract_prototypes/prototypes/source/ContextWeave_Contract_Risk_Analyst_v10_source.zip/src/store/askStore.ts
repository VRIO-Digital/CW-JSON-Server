import { create } from 'zustand'
import {
  askQuestionStreaming,
  listAskGraphs,
  type AnswerBlock,
  type AskAnswer,
  type AskGraph,
  type AskGraphsPayload,
  type AskSource,
  type AskStep,
  type Citations,
} from '../api/client'
import {
  chatTitle,
  clearChats,
  loadChats,
  newId,
  saveChats,
  type AskChat,
  type AskTurn,
} from '../data/askChats'
import { toMessage, type Result } from './asyncState'
import { useAuthStore } from './authStore'

/*
 * Restored from the live demo (cw.vriodigital.com, 13 Oct 2026). The long design comments of the
 * original are omitted; the state, actions and selectors are the same.
 */
interface AskState {
  data: AskGraphsPayload | null
  loading: boolean
  error: string | null
  useCaseId: string | null
  asking: boolean
  chats: AskChat[]
  activeChatId: string | null
  askedNow: string
  streamedSteps: AskStep[]
  streamedSummary: { answered: boolean; text: string } | null
  streamedBlocks: AnswerBlock[]
  streamedBlockCount: number
  citations: Citations | null
  formatIds: string[]
  load: () => Promise<void>
  select: (useCaseId: string | null) => void
  setCitations: (citations: Citations) => void
  toggleFormat: (formatId: string, on: boolean) => void
  ask: (question: string) => Promise<Result>
  newChat: () => void
  openChat: (chatId: string) => void
  deleteChat: (chatId: string) => void
  clearHistory: () => void
  syncHistory: () => void
}

const EMPTY_GRAPHS: AskGraph[] = []
const EMPTY_STEPS: AskStep[] = []
const EMPTY_BLOCKS: AnswerBlock[] = []
const EMPTY_FORMATS: string[] = []
const EMPTY_CHATS: AskChat[] = []
const EMPTY_SOURCE_IDS: string[] = []
const EMPTY_SOURCES: AskSource[] = []

const signedInAs = () => useAuthStore.getState().identity?.email ?? null

export const useAskStore = create<AskState>()((set, get) => ({
  data: null,
  loading: false,
  error: null,
  useCaseId: null,
  asking: false,
  chats: EMPTY_CHATS,
  activeChatId: null,
  askedNow: '',
  citations: null,
  formatIds: EMPTY_FORMATS,
  streamedSteps: EMPTY_STEPS,
  streamedBlocks: EMPTY_BLOCKS,
  streamedSummary: null,
  streamedBlockCount: 0,

  load: async () => {
    set({ loading: true })
    try {
      const data = await listAskGraphs()
      const current = get().useCaseId
      const stillLive = data.graphs.some((g) => g.useCaseId === current)
      const useCaseId = stillLive ? current : (data.graphs[0]?.useCaseId ?? null)
      set({
        data,
        error: null,
        loading: false,
        useCaseId,
        ...(stillLive ? {} : { activeChatId: null }),
      })
      get().syncHistory()
    } catch (error) {
      set({ error: toMessage(error), loading: false })
    }
  },

  select: (useCaseId) => {
    if (get().useCaseId === useCaseId) return
    set({ useCaseId, activeChatId: null })
  },

  setCitations: (citations) => set({ citations }),

  toggleFormat: (formatId, on) =>
    set((state) => ({
      formatIds: on
        ? [...state.formatIds, formatId]
        : state.formatIds.filter((id) => id !== formatId),
    })),

  newChat: () => set({ activeChatId: null }),

  openChat: (chatId) => {
    const chat = get().chats.find((c) => c.chatId === chatId)
    if (!chat) return
    set({
      activeChatId: chatId,
      useCaseId: get().data?.graphs.some((g) => g.useCaseId === chat.useCaseId)
        ? chat.useCaseId
        : get().useCaseId,
    })
  },

  deleteChat: (chatId) => {
    const chats = get().chats.filter((c) => c.chatId !== chatId)
    saveChats(signedInAs(), chats)
    set({
      chats,
      activeChatId: get().activeChatId === chatId ? null : get().activeChatId,
    })
  },

  clearHistory: () => {
    clearChats(signedInAs())
    set({ chats: EMPTY_CHATS, activeChatId: null })
  },

  syncHistory: () => {
    const chats = loadChats(signedInAs())
    const activeChatId = chats.some((c) => c.chatId === get().activeChatId)
      ? get().activeChatId
      : null
    set({ chats, activeChatId })
  },

  ask: async (question) => {
    const useCaseId = get().useCaseId
    const sourceIds = useCaseId
      ? EMPTY_SOURCE_IDS
      : (get().data?.sources ?? []).map((s) => s.sourceId)
    if (!useCaseId && sourceIds.length === 0) {
      return {
        ok: false,
        error: 'Publish a graph, or connect a source on Sources, to ask a question.',
      }
    }
    if (!question.trim()) return { ok: false, error: 'Ask a question first.' }
    const asked = question.trim()

    set({
      asking: true,
      askedNow: asked,
      streamedSteps: EMPTY_STEPS,
      streamedBlocks: EMPTY_BLOCKS,
      streamedSummary: null,
      streamedBlockCount: 0,
    })
    const required =
      get().citations ?? get().data?.answerRequirements.defaultCitations ?? 'required'
    try {
      const answer = await askQuestionStreaming(
        useCaseId,
        asked,
        { citations: required, formats: get().formatIds },
        sourceIds,
        (event) => {
          if (get().useCaseId !== useCaseId) return
          if (event.kind === 'stage') {
            set({ streamedSteps: [...get().streamedSteps, event] })
          } else if (event.kind === 'summary') {
            set({
              streamedSummary: {
                answered: event.answered,
                text: event.answered ? (event.summary ?? event.answer ?? '') : event.reason,
              },
              streamedBlockCount: event.blockCount,
            })
          } else if (event.kind === 'block') {
            set({ streamedBlocks: [...get().streamedBlocks, event.block] })
          }
        },
        signedInAs(),
      )
      if (get().useCaseId !== useCaseId) return { ok: true }
      appendTurn(asked, answer)
      return { ok: true }
    } catch (error) {
      set({
        streamedSteps: EMPTY_STEPS,
        streamedBlocks: EMPTY_BLOCKS,
        streamedSummary: null,
        streamedBlockCount: 0,
      })
      return { ok: false, error: toMessage(error) }
    } finally {
      set({ asking: false, askedNow: '' })
    }
  },
}))

function appendTurn(asked: string, answer: AskAnswer) {
  const state = useAskStore.getState()
  const graph = state.data?.graphs.find((g) => g.useCaseId === state.useCaseId)
  const sources = state.data?.sources ?? []
  const subject = graph?.name ?? sources.map((r) => r.name).join(', ')
  if (!state.useCaseId && sources.length === 0) return

  const turn: AskTurn = {
    turnId: newId(),
    question: asked,
    answer,
    askedAt: answer.askedAt,
  }
  const now = new Date().toISOString()
  const existing = state.chats.find((c) => c.chatId === state.activeChatId)

  const chat: AskChat = existing
    ? { ...existing, turns: [...existing.turns, turn], updatedAt: now }
    : {
        chatId: newId(),
        useCaseId: state.useCaseId,
        graphName: graph?.name ?? null,
        subject,
        title: chatTitle(asked),
        turns: [turn],
        createdAt: now,
        updatedAt: now,
      }

  const chats = [chat, ...state.chats.filter((c) => c.chatId !== chat.chatId)]
  saveChats(useAuthStore.getState().identity?.email ?? null, chats)
  useAskStore.setState({ chats, activeChatId: chat.chatId })
}

export const selectAskGraphs = (s: AskState) => s.data?.graphs ?? EMPTY_GRAPHS
export const selectAskSources = (s: AskState) => s.data?.sources ?? EMPTY_SOURCES
export const selectRequirementOptions = (s: AskState) => s.data?.answerRequirements ?? null
export const selectCitations = (s: AskState): Citations =>
  s.citations ?? s.data?.answerRequirements.defaultCitations ?? 'required'
export const selectCurrentGraph = (s: AskState) =>
  s.data?.graphs.find((g) => g.useCaseId === s.useCaseId) ?? null
export const selectActiveChat = (s: AskState) =>
  s.chats.find((c) => c.chatId === s.activeChatId) ?? null
export const selectChats = (s: AskState) => s.chats
