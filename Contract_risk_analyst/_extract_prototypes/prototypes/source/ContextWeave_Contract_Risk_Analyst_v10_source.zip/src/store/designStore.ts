/*
 * The scorecard design is one object (DESIGN in data/risk.ts) that the person shapes at set-up and can change later.
 * Every change goes through here, so every screen that shows a score redraws with it.
 */
import { create } from 'zustand'
import { DESIGN, FACTORS, PANELS, SIGNALS, CONTRACTS, addCustomFactor, addCustomSignal, setBandText, applyHist, applyTemplate, ruleAsWritten, useHist as histFor, type TplRow, applyProtect, rankWeights, rating, resetDesign, sectionSignals, snapshotNow, saveDesign, restoreDesign, score, ratingOf, priorityOf, planFor, shortSite, likelihoodSignals, activeFactors, type SavedDesign, type DashSnapshot, type Design, type Protect, type Rule, type Section, type Size, type When } from '../data/risk'

/** A published version of the dashboard: when, why, and what it showed. */
/** A version of the dashboard. The number changes only when the scoring changes; a morning check refreshes the figures of the version in force. */
export interface DashVersion { v: number; at: string; why: string; snap: DashSnapshot; edits: number; refreshed?: string }
interface S { v: number; versions: DashVersion[]; touch: () => void; publish: (at: string, why: string, when: When) => DashVersion; refresh: (at: string, when: When) => void; clearVersions: () => void }
/* The scoring and the scores of the version in force. A change made after it is a draft until it is published; this is what the draft is compared with, and what a discard goes back to. */
interface PubRow { s: number; r: number; p: string; plan: string }
let PUB: { saved: SavedDesign; rows: Record<string, PubRow>; when: When; signals: number; factors: number } | null = null
const rowsNow = (when: When): Record<string, PubRow> => Object.fromEntries(CONTRACTS.map((c) => { const sc = score(c, DESIGN.rule, when); return [c.id, { s: sc, r: ratingOf(sc), p: priorityOf(c, when), plan: planFor(c, when).filter((x) => !x.fixed && !x.later).map((x) => `${x.s.id}>${x.to}`).join(',') }] }))
const capture = (when: When) => { PUB = { saved: saveDesign(), rows: rowsNow(when), when, signals: likelihoodSignals().length, factors: activeFactors().length } }
export const useDesign = create<S>((set, get) => ({
  v: 0, versions: [],
  touch: () => set((s) => ({ v: s.v + 1 })),
  publish: (at, why, when) => { const ver: DashVersion = { v: get().versions.length + 1, at, why, snap: snapshotNow(when), edits: DESIGN.edits }; set((s) => ({ versions: [...s.versions, ver], v: s.v + 1 })); capture(when); return ver },
  refresh: (at, when) => {
    set((s) => ({ versions: s.versions.map((x, i) => (i === s.versions.length - 1 ? { ...x, snap: snapshotNow(when), refreshed: at } : x)), v: s.v + 1 }))
    /* the figures of the version in force moved; a draft that is open stays a draft */
    if (PUB) { const draft = unpublished() ? saveDesign() : null; if (draft) restoreDesign(PUB.saved); PUB.rows = rowsNow(when); PUB.when = when; if (draft) restoreDesign(draft) }
  },
  clearVersions: () => { PUB = null; set({ versions: [] }) },
}))
/** Has the scoring changed since the dashboard was last published. */
export const unpublished = () => { const vs = useDesign.getState().versions; return vs.length > 0 && DESIGN.edits !== vs[vs.length - 1].edits }
/** What changed in the scoring since a point, in a few words, for the version note. */
let LASTNOTE: string[] = []
const note = (t: string) => { if (!LASTNOTE.includes(t)) LASTNOTE.push(t) }
export const takeNotes = () => { const n = LASTNOTE; LASTNOTE = []; return n }
/** What the draft changes, without clearing it. */
export const peekNotes = () => LASTNOTE.slice()

/** What a draft of the scoring does to the scores, against the version in force. */
export interface ChangeEffect {
  version: number; next: number; when: When
  signals: [number, number]; factors: [number, number]
  dist: [number[], number[]]; n34: [number, number]; act: [number, number]; rev34: [number, number]
  scoresMoved: number; largest: number; plans: number
  up: { id: string; site: string; from: number; to: number; s0: number; s1: number }[]
  down: { id: string; site: string; from: number; to: number; s0: number; s1: number }[]
  biggest: { id: string; site: string; s0: number; s1: number; r: number }[]
}
export function changeEffect(): ChangeEffect | null {
  if (!PUB) return null
  const cur = rowsNow(PUB.when), v = useDesign.getState().versions.length
  const d0 = [0, 0, 0, 0, 0], d1 = [0, 0, 0, 0, 0]; let moved = 0, largest = 0, plans = 0, rev0 = 0, rev1 = 0, act0 = 0, act1 = 0
  const up: ChangeEffect['up'] = [], down: ChangeEffect['down'] = [], all: ChangeEffect['biggest'] = []
  for (const c of CONTRACTS) {
    const a = PUB.rows[c.id], b = cur[c.id]
    d0[a.r] += 1; d1[b.r] += 1
    if (a.r >= 3) rev0 += c.revenue; if (b.r >= 3) rev1 += c.revenue
    if (a.p === 'Act now') act0 += 1; if (b.p === 'Act now') act1 += 1
    if (Math.abs(a.s - b.s) > Math.abs(largest)) largest = b.s - a.s
    if (Math.abs(a.s - b.s) >= 0.001) { moved += 1; all.push({ id: c.id, site: shortSite(c), s0: a.s, s1: b.s, r: b.r }) }
    if (a.plan !== b.plan) plans += 1
    const row = { id: c.id, site: shortSite(c), from: a.r, to: b.r, s0: a.s, s1: b.s }
    if (b.r > a.r) up.push(row); else if (b.r < a.r) down.push(row)
  }
  const byMove = (x: { s0: number; s1: number }, y: { s0: number; s1: number }) => Math.abs(y.s1 - y.s0) - Math.abs(x.s1 - x.s0)
  return { version: v, next: v + 1, when: PUB.when, signals: [PUB.signals, likelihoodSignals().length], factors: [PUB.factors, activeFactors().length], dist: [d0, d1], n34: [d0[3] + d0[4], d1[3] + d1[4]], act: [act0, act1], rev34: [rev0, rev1], scoresMoved: moved, largest, plans, up: up.sort(byMove), down: down.sort(byMove), biggest: all.sort(byMove).slice(0, 6) }
}
/** Subscribe a component to the design. */
export const useDesignV = () => useDesign((s) => s.v)
const done = () => { DESIGN.edits += 1; useDesign.getState().touch() }

/** The ratings of the starting point, to say what your changes moved. */
let BASE: Record<string, number> | null = null
const snapshot = () => { BASE = {}; for (const c of CONTRACTS) BASE[c.id] = rating(c, DESIGN.rule, 'before') }
export function movedByYou() {
  if (!BASE) snapshot()
  let up = 0, down = 0
  for (const c of CONTRACTS) { const r = rating(c, DESIGN.rule, 'before'); if (r > BASE![c.id]) up += 1; else if (r < BASE![c.id]) down += 1 }
  return { up, down }
}
export const design = {
  reset: (source: Design['source']) => { resetDesign(source); DESIGN.edits = 0; LASTNOTE = []; snapshot(); useDesign.getState().clearVersions(); useDesign.getState().touch() },
  section: (k: Section, on: boolean) => { for (const x of sectionSignals(k)) DESIGN.on[x.id] = on; if (k === 'A') DESIGN.size = on ? 'beside' : 'none'; rankWeights(); if (on && (k === 'C')) DESIGN.flag.cp3 = true; note(`section ${k} ${on ? 'added' : 'removed'}`); done() },
  assume: (k: keyof Design['assume'], val: string) => { if (k === 'hist') { applyHist(val === 'hist'); DESIGN.ok.hist = true; note(val === 'hist' ? 'thresholds taken from history' : 'thresholds back to the rule as written'); done(); return } (DESIGN.assume as Record<string, string>)[k] = val; DESIGN.ok[k] = true; note('an assumption of the data check changed'); done() },
  /** One figure: take its thresholds from its own history. */
  hist: (sid: string) => { histFor(sid); note(`thresholds of ${SIGNALS.find((s) => s.id === sid)!.name} from history`); done() },
  written: (sid: string) => { ruleAsWritten(sid); note(`rule of ${SIGNALS.find((s) => s.id === sid)!.name} back as written`); done() },
  /** Use an uploaded template as written. */
  template: (rows: TplRow[], name = '') => { const r = applyTemplate(rows); DESIGN.tplName = name; DESIGN.edits = 0; LASTNOTE = []; snapshot(); useDesign.getState().clearVersions(); useDesign.getState().touch(); return r },
  confirm: (k: string) => { DESIGN.ok[k] = true; useDesign.getState().touch() },
  confirmAll: (keys: string[]) => { for (const k of keys) DESIGN.ok[k] = true; useDesign.getState().touch() },
  protect: (p: Protect) => { applyProtect(p); snapshot(); useDesign.getState().touch() },
  rule: (r: Rule) => { DESIGN.rule = r; DESIGN.ok.score = true; note('how the two halves combine'); done() },
  size: (s: Size) => { DESIGN.size = s; for (const x of SIGNALS) if (x.f === 'im') DESIGN.on[x.id] = s !== 'none'; for (const p of PANELS) if (p.needs === 'impact') DESIGN.panels[p.k] = s !== 'none' && p.rec; snapshot(); useDesign.getState().touch() },
  on: (sid: string, on: boolean) => { DESIGN.on[sid] = on; if (on && DESIGN.tpl && !DESIGN.tpl.includes(sid)) DESIGN.tpl.push(sid); note(`${SIGNALS.find((s) => s.id === sid)!.name} ${on ? 'put back' : 'dropped'}`); const f = SIGNALS.find((s) => s.id === sid)!.f; const ss = SIGNALS.filter((s) => s.f === f && DESIGN.on[s.id]); if (on && !DESIGN.sw[sid]) DESIGN.sw[sid] = 1; if (!ss.length) { /* a factor with nothing in it carries no weight */ } done() },
  onMany: (sids: string[], on: boolean) => { for (const sid of sids) DESIGN.on[sid] = on; rankWeights(); done() },
  factorWeight: (fid: string, d: number) => { note(`weight of ${FACTORS.find((f) => f.id === fid)!.name}`); DESIGN.fw[fid] = Math.max(0, Math.min(60, (DESIGN.fw[fid] ?? FACTORS.find((f) => f.id === fid)!.weight) + d)); done() },
  signalWeight: (sid: string, d: number) => { note(`weight of ${SIGNALS.find((s) => s.id === sid)!.name}`); DESIGN.sw[sid] = Math.max(1, Math.min(12, (DESIGN.sw[sid] ?? 1) + d)); done() },
  cuts: (sid: string, i: number, val: number) => { note(`thresholds of ${SIGNALS.find((s) => s.id === sid)!.name}`); const s = SIGNALS.find((x) => x.id === sid)!; const c = (DESIGN.cuts[sid] ?? s.num!.cuts).slice(); c[i] = val; DESIGN.cuts[sid] = c; done() },
  map: (sid: string, band: number, to: number) => { note(`scores of ${SIGNALS.find((s) => s.id === sid)!.name}`); const m = (DESIGN.map[sid] ?? [1, 2, 3, 4]).slice(); m[band - 1] = to; DESIGN.map[sid] = m; done() },
  /** Rewrite when a signal scores 1, 2, 3 or 4. */
  text: (sid: string, band: number, text: string) => { const r = setBandText(sid, band, text); if (r.changed) { note(`rule of ${SIGNALS.find((s) => s.id === sid)!.name}`); done() } return r },
  flag: (sid: string) => { DESIGN.flag[sid] = !DESIGN.flag[sid]; note(`red flag on ${SIGNALS.find((s) => s.id === sid)!.name}`); done() },
  /** Add signals together with the red flags the proposal carries for them. */
  adopt: (sids: string[]) => { for (const sid of sids) { DESIGN.on[sid] = true; if (DESIGN.tpl && !DESIGN.tpl.includes(sid)) DESIGN.tpl.push(sid); note(`signal added: ${SIGNALS.find((s) => s.id === sid)!.name}`) } rankWeights(); for (const f of ['li3', 'cp3']) if (DESIGN.on[f]) DESIGN.flag[f] = true; done() },
  panel: (k: string, on: boolean) => { DESIGN.panels[k] = on; note('views of the dashboard'); done() },
  /** Set all three thresholds of a figure at once. */
  cutsTo: (sid: string, cuts: number[]) => { DESIGN.cuts[sid] = cuts.slice(); note(`thresholds of ${SIGNALS.find((s) => s.id === sid)!.name}`); done() },
  /** Set the weight of a factor. */
  factorWeightTo: (fid: string, to: number) => { DESIGN.fw[fid] = Math.max(0, Math.min(60, to)); note(`weight of ${FACTORS.find((f) => f.id === fid)!.name}`); done() },
  /** Drop the draft: the scoring goes back to the version in force. */
  discard: () => { if (!PUB) return false; restoreDesign(PUB.saved); LASTNOTE = []; useDesign.getState().touch(); return true },
  custom: (text: string, into?: string, bands?: string[]) => { const s = addCustomSignal(text, into, bands); note(`new signal: ${s.name}`); useDesign.getState().touch(); return s },
  factor: (group: 'internal' | 'external', name: string) => { const f = addCustomFactor(group, name); note(`new factor: ${f.name}`); useDesign.getState().touch(); return f },
}
if (typeof window !== 'undefined') (window as unknown as { __cwDesign: unknown }).__cwDesign = { DESIGN, design }
