import { create } from 'zustand'
import { AGENT_POOL, type Agent, type Drill, type Goal, type Recommendation, type SubmissionSuggestion } from '../data/goalCases'
import { useGoalStore } from './goalStore'
import { useSubmissionStore } from './submissionStore'
import { applyNight, ASSUME_KEYS, CONTRACTS, DESIGN, FACTORS, LOST, NOT_FOUND, PANELS, PEOPLE, RATING_NAME, SIGNALS, TEMPLATE_FILE, activeFactors, histFlagged, likelihoodSignals, lostCaught, numericSignals, inTemplate, planFor, rating, shortSite, templateRows, REG_RULE, bandsOf, finalShare, histOf, valOf, type Rule, type TplResult } from '../data/risk'
import { changeEffect, design, peekNotes, takeNotes, unpublished, useDesign } from './designStore'
import { readTemplate } from '../data/templateFile'
import { useAuthStore } from './authStore'
import { P, now } from '../data/pace'
import { EXTRA_OFFERS, GENERIC_ACTIONS, GENERIC_SPECS, SCHEDULE_ACTIONS, WATCH_ACTIONS, scheduleActionsFor, specFromSuggestion, specReady, templateOf, tellNames, watchActionsFor, type ActionCat, type ActMode, type DelivSpec, type ExecAction } from '../data/deliverFlow'
import { designOutline, templateFromOutline } from '../data/outputDesigner'
import type { OutputFormat, Template } from '../data/submissionTemplates'
import {
  FOUR, GENERIC_EDGES, GENERIC_NODES, GENERIC_READS, LIB, ONCE_BASE, ONCE_EDGES, ONCE_FILES, ONCE_FORKS, ONCE_GAPS, ONCE_NODES, ONCE_OUTPUTS, ONCE_PROMPT, ONCE_QUESTIONS, ONCE_READS, ONCE_READ_WEB, ONCE_RECS,
  SCHEDULE_READS, WATCH_BASE, WATCH_EDGES, WATCH_GAPS, WATCH_NODES, WATCH_OUTPUTS, WATCH_PROMPT, WATCH_QUESTIONS, WATCH_READS, WATCH_RECS, SCHEDULE_QUESTIONS,
  WATCH_EXECUTE, forkContent, genericContent, m1, onceContent, onceFindings, onceRecs, portfolioFigures, rbFigures, watchContent, watchFindings, watchStory,
  type JFinding, type Mode, type Node, type NodeContent, type Question, type Read,
} from '../data/journeyCases'

/*
 * Goals v30. One store holds every goal (the two seeded ones and any started in the session), each as a
 * journey: what was read, what the plan says and where each line came from, which questions are open,
 * the workflow and the state of every step, the findings, the recommendation, the outputs, and the
 * conversation with the agent. The agent's part is simulated on timers that can be paused; everything
 * the analyst does is logged against the plan's version.
 */

export type Stage = 'reading' | 'questions' | 'plan' | 'running' | 'armed'
export type Status = 'draft' | 'running' | 'wait' | 'paused' | 'ready' | 'accepted' | 'sent' | 'armed' | 'fired' | 'executing' | 'executed' | 'delivered'
export type NodeRun = 'pending' | 'running' | 'wait' | 'done' | 'stale'
export type Case = 'once' | 'watch' | 'schedule' | 'generic' | 'overrun-once'

export interface Card {
  kind: 'reads' | 'q' | 'upload' | 'cp' | 'diff' | 'forkpick' | 'findings' | 'decision' | 'send' | 'fired' | 'note' | 'execute' | 'deliv' | 'delivered' | 'actions' | 'change'
  key?: string
  lines?: { tool: string; res: string; warn?: boolean; live?: boolean }[]
  diff?: { title: string; rows: { k: 'add' | 'chg' | 'rerun' | 'caveat'; text: string }[]; apply: string }
  done?: string
  left?: boolean
}
export interface Msg { id: string; who: 'agent' | 'me' | 'event'; text: string; files?: { n: string; s: string }[]; card?: Card; at: string }
export interface Att { id?: string; n: string; s: string }

export interface Journey {
  id: string
  mode: Mode
  kind: 'once' | 'rule' | 'schedule'
  case: Case
  title: string
  agent: Agent
  prompt: string
  files: Att[]
  stage: Stage
  status: Status
  rv: string[]
  reads: Read[]
  questions: Question[]
  answers: Record<string, string>
  over: Record<string, string>
  who?: string
  dateSrc?: 'you' | 'doc'
  extraDocs: { n: string; took: string; mine?: boolean; drill?: Drill }[]
  web: boolean
  fixedExtra: string[]
  version: number
  agreedV: number
  agreedAt?: string
  history: { t: string; what: string }[]
  autonomy: 'every' | 'blocked' | 'end'
  nodes: Node[]
  edges: [string, string][]
  removed: string[]
  ns: Record<string, { state: NodeRun; at?: string; text?: string; contentKey?: string; caveat?: boolean; t0?: number }>
  /** While the scorecard is being drafted after the template answer: the steps, and how many are done. */
  draft?: { title: string; steps: string[]; done: number } | null
  /** A live goal whose scoring is being changed: the changes asked for in the chat since the last published version. */
  changes?: { k: 'add' | 'chg'; text: string; asked: string; own: string[] }[]
  changing?: boolean
  /** Every version of the dashboard published after the first: what changed and what it did to the scores. */
  published?: { v: number; at: string; why: string; changes: string[]; effect: { ratings_before: number[]; ratings_after: number[]; scores_moved: number; up: string[]; down: string[]; plans_changed: number } | null }[]
  /** While deliverables are being built: which one, and how many of its parts are on screen. */
  prog?: { sids: string[]; i: number; shown: number } | null
  forkKind?: 'rc' | 't3' | 'four'
  findings: string[]
  recs: Recommendation[]
  chosen?: string
  sentAt?: string
  outputs: SubmissionSuggestion[]
  started: string[]
  gaps: string[]
  chat: Msg[]
  chips: string[]
  typing: boolean
  composer: { on: boolean; ph: string }
  log: { t: string; who: string; what: string }[]
  runs: { id: string; at: string; label: string; status: 'running' | 'ready' | 'executed' }[]
  /** After a standing goal's recommendation is chosen: what the agent does about it, and how far it has got. */
  exec?: { rec: string; title: string; steps: string[]; done: number; state: 'confirm' | 'running' | 'done'; at?: string; sid?: string; doneText?: string }
  executedAt?: string
  flags: { cpAnswered?: boolean; steered?: boolean; steerAvail?: boolean; saved?: boolean; forked?: boolean; genericQ?: boolean; answeredQ?: boolean }
  doneCount: number
  paused: boolean
  prevStatus?: Status
  armedAt?: string
  armedBy?: string
  from?: string
  nextCheck?: string
  /** What the run hands over at the end, agreed while planning, and the template for each. */
  deliv: DelivSpec[]
  delivConfirmed: boolean
  /** A standing goal: what it may do when it fires, each done by itself or held for your OK. */
  acts: ActionCat[]
  /** The actions of the latest run, and where each stands. */
  execActs: ExecAction[]
  /** Deliverable id to the submission it was built as. */
  built: Record<string, string>
  buildV: number
  deliveredAt?: string
  chosenBy?: 'auto' | 'you'
}

export interface SavedPlan { id: string; name: string; mode: Mode; kind: Journey['kind']; prompt: string; files: Att[]; steps: string[]; from: string; by: string; at: string; case: Case }

interface S {
  goals: Record<string, Journey>
  order: string[]
  saved: SavedPlan[]
  current: string | null
  start: { mode: Mode; prompt: string; files: Att[]; web: boolean; approachId?: string }
  setStart: (p: Partial<S['start']>) => void
  open: (id: string | null) => void
  begin: () => string
  input: (id: string, text: string) => void
  attach: (id: string, atts: Att[], text?: string) => void
  toggleWeb: (id: string) => void
  answer: (id: string, key: string, v: string, label?: string) => void
  rowEdit: (id: string, key: string, text: string) => void
  setAutonomy: (id: string, a: Journey['autonomy']) => void
  agree: (id: string) => void
  pause: (id: string, on?: boolean) => void
  applyDiff: (id: string, msgId: string) => void
  leaveDiff: (id: string, msgId: string) => void
  forkPrompt: (id: string) => void
  applyFork: (id: string, kind: 'rc' | 't3' | 'four') => void
  checkpoint: (id: string, v: string) => void
  steer: (id: string) => void
  acceptFinding: (id: string, key: string | 'all') => void
  challenge: (id: string, key: string, text: string) => void
  choose: (id: string, recId: string) => void
  swapReco: (id: string, recId: string) => void
  markSent: (id: string) => void
  markStarted: (id: string, outId: string) => void
  savePlan: (id: string, name?: string) => void
  fire: (id: string) => void
  rmDoc: (id: string, n: string) => void
  content: (id: string, nodeId: string) => NodeContent | null
  findingsOf: (id: string) => Record<string, JFinding>
  removeStep: (id: string, nodeId: string) => void
  restoreStep: (id: string, nodeId: string) => void
  makeStanding: (id: string) => void
  execute: (id: string) => void
  notNow: (id: string) => void
  setDeliv: (id: string, specs: DelivSpec[]) => void
  confirmDeliv: (id: string) => void
  setActMode: (id: string, key: string, mode: ActMode) => void
  setActs: (id: string, acts: ActionCat[]) => void
  /** The scoring of a live goal changed: score every project again and publish the dashboard as a new version. */
  republish: (id: string) => void
  /** Drop the draft change to the scoring; the dashboard stays as published. */
  discardChange: (id: string) => void
  /** The scoring template is handed over: a file, or nothing for the sample. */
  uploadTemplate: (id: string, file?: File) => Promise<void>
  approveAct: (id: string, i: number, ok: boolean) => void
  /** Submissions: more deliverables from a run that is done, on the decision as it stands. Returns the new submission ids. */
  makeMore: (id: string, specs: DelivSpec[]) => string[]
  /** The recommended deliverables of a run, with the ones already made marked. */
  offerFor: (id: string) => DelivSpec[]
  /** The Submissions-only build has no Goals to run: it opens on the two recorded runs, already executed. */
  seedExecuted: () => void
}

/** The seeded standing goal: Renee Halvorsen's contract risk watch. */
export const SEED_WATCH_ID = 'g-rule-contract-risk'
/* Free-text answers to the two once questions. */
/* The run no longer stops half way to ask, so "wait" or "ask me later" settles on counting the evergreen contracts; it can be switched once the deliverables are out. */
const parseFour = (t: string) => (/leave|left|exclude|without|no end date/i.test(t) && !/count/i.test(t) ? 'standin' : 'june')
const parseT3 = (t: string) => (/as surveyed|no flag|as it is today/i.test(t) ? 'approved' : /separate|list them/i.test(t) ? 'expected' : 'out')
const hhmm = (d = now()) => d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
const dmy = (d = now()) => d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
const STEER = 'Leave the evergreen contracts out'
const NUM = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty']
const word = (n: number, cap = false) => { const t = NUM[n] ?? n.toLocaleString('en-US'); return cap ? t[0].toUpperCase() + t.slice(1) : t }
let seq = 0
const mid = () => `j${(seq += 1)}-${Date.now().toString(36)}`
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 36)
const wait = (ms: number) => new Promise((r) => window.setTimeout(r, P(ms)))

/* A sequence of timed steps that can be paused between steps. */
class Seq {
  i = 0; t = 0; paused = false
  steps: { d: number; fn: () => void }[]
  onEnd?: () => void
  constructor(steps: { d: number; fn: () => void }[], onEnd?: () => void) { this.steps = steps; this.onEnd = onEnd }
  next() { if (this.paused) return; if (this.i >= this.steps.length) { this.onEnd?.(); return } const st = this.steps[this.i]; this.t = window.setTimeout(() => { this.i += 1; st.fn(); this.next() }, P(st.d)) }
  pause() { window.clearTimeout(this.t); this.paused = true }
  resume() { this.paused = false; this.next() }
  kill() { window.clearTimeout(this.t); this.paused = true; this.i = this.steps.length }
}
const seqs: Record<string, Seq> = {}

const WHO_LABEL: Record<string, string> = { four: 'Evergreen contracts', t3: 'NPS from a predecessor', combine: 'One rating from two halves', fires: 'Fires when', tell: 'Who is told' }
const ANSWER_TEXT: Record<string, Record<string, string>> = {
  four: { june: 'count the evergreen contracts', standin: 'leave the evergreen contracts out', wait: 'count the evergreen contracts', ask: 'count the evergreen contracts' },
  t3: { expected: 'keep the score and list the contracts separately', approved: 'keep the score as surveyed, no flag', out: 'keep the scorecard you agreed and flag the score as a predecessor’s' },
  combine: { max: 'the higher of the two', avg: 'the average of the two', sep: 'two ratings side by side' },
  fires: { breach: 'only when a contract changes rating', early: 'a rating change, a factor moving a full point, or a sign outside the scorecard', always: 'a digest every morning' },
  tell: { me: 'just you', pm: 'you and the Regional VP of the contract', controller: 'you, the Regional VP, the project leader, and Legal for a claim' },
}
/* The renewal review as the analyst has it: the evergreen contracts counted unless left out. */
const rbOf = (j: Journey) => rbFigures(j.answers.four !== 'standin')

const caseOf = (mode: Mode, prompt: string, kind: Journey['kind']): Case => {
  const t = prompt.toLowerCase()
  if (mode === 'watch' && kind === 'schedule') return 'schedule'
  if (mode === 'watch') return /risk|scorecard|contract|monitor|rating|mitigat/.test(t) || !t.trim() ? 'watch' : 'generic'
  if (/renew|lose|lost|18 months|calder|evergreen|re-?bid|expir/.test(t)) return 'once'
  if (/harlow|demand letter|moved from 2 to 3|overnight|red mesa|ashby|odor/.test(t)) return 'overrun-once'
  return 'generic'
}

/* The once plan had a checkpoint half way; the run now goes to the end, so the checkpoint leaves the workflow, its edges are routed round it and the later steps move up a column. */
const reroute = (edges: [string, string][], drop: string[]): [string, string][] => {
  let out = edges.slice()
  for (const r of drop) {
    const ins = out.filter(([, b]) => b === r).map(([a]) => a), outs = out.filter(([a]) => a === r).map(([, b]) => b)
    const kept = out.filter(([a, b]) => a !== r && b !== r)
    ins.forEach((a) => outs.forEach((b) => { if (!kept.some(([x, y]) => x === a && y === b)) kept.push([a, b]) }))
    out = kept
  }
  return out
}
const hideCp = (c: Case, nodes: Node[], edges: [string, string][]) => {
  const cp = nodes.find((n) => n.id === 'cp')
  if (!cp || !(c === 'once' || c === 'schedule')) return { nodes: nodes.map((n) => ({ ...n })), edges: edges.slice() }
  return { nodes: nodes.filter((n) => n.id !== 'cp').map((n) => ({ ...n, col: n.col > cp.col ? n.col - 1 : n.col, ...(n.id === 'n6' ? { title: 'Build the deliverables you chose' } : {}) })), edges: reroute(edges, ['cp']) }
}

const makeJourney = (mode: Mode, kind: Journey['kind'], prompt: string, files: Att[], web: boolean, agent: Agent, approachId?: string): Journey => {
  const c = caseOf(mode, prompt, kind)
  const nodes = c === 'once' || c === 'schedule' ? ONCE_NODES : c === 'watch' || c === 'overrun-once' ? WATCH_NODES : GENERIC_NODES
  const edges = c === 'once' || c === 'schedule' ? ONCE_EDGES : c === 'watch' || c === 'overrun-once' ? WATCH_EDGES : GENERIC_EDGES
  const reads = c === 'once' ? ONCE_READS.slice() : c === 'schedule' ? SCHEDULE_READS : c === 'watch' ? WATCH_READS : c === 'overrun-once' ? WATCH_READS.filter((r) => !/distribution|list/.test(r.tool)) : GENERIC_READS(prompt)
  if (c === 'once' && web) reads[reads.length - 1] = ONCE_READ_WEB
  /* Two answers only: the run does not stop half way to ask, so "wait" and "ask me again" are gone; counting the evergreen contracts is recommended. */
  const onceQs = ONCE_QUESTIONS.map((q) => (q.key === 'four' ? { ...q, tiles: q.tiles.filter((t) => t.v === 'june' || t.v === 'standin').map((t) => ({ ...t, rec: t.v === 'june' })) } : q))
  const questions = c === 'once' ? onceQs : c === 'watch' ? WATCH_QUESTIONS : c === 'schedule' ? SCHEDULE_QUESTIONS : []
  const tpls = useSubmissionStore.getState().templates
  const deliv = c === 'once' || c === 'schedule' ? [...ONCE_OUTPUTS.map((x) => specFromSuggestion(x, tpls)), ...EXTRA_OFFERS.once.map((x) => specFromSuggestion(x, tpls, false))] : c === 'watch' || c === 'overrun-once' ? [...WATCH_OUTPUTS.map((x) => specFromSuggestion(x, tpls)), ...EXTRA_OFFERS.watch.map((x) => specFromSuggestion(x, tpls, false))] : GENERIC_SPECS.map((x) => ({ ...x }))
  const acts = mode === 'watch' ? (c === 'schedule' ? SCHEDULE_ACTIONS : c === 'watch' ? WATCH_ACTIONS : GENERIC_ACTIONS).map((a) => ({ ...a })) : []
  const shown = hideCp(c, nodes, edges)
  shown.nodes = shown.nodes.map((n) => (n.id === 'w5' ? { ...n, title: mode === 'watch' ? 'Build the deliverables, act and tell you' : 'Build the deliverables you chose', purpose: mode === 'watch' ? 'Build what was agreed at set-up, take the actions that run by themselves, hold the others for your OK, and tell the people you chose.' : n.purpose } : n))
  const title = c === 'once' ? ONCE_BASE.title : c === 'schedule' ? 'Quarterly renewal review: before every portfolio review' : c === 'watch' ? 'Contract risk: every contract scored, and watched every morning' : c === 'overrun-once' ? WATCH_BASE.title : prompt.length > 72 ? `${prompt.slice(0, 70)}…` : prompt
  const id = `g-${slug(title)}-${Date.now().toString(36)}`
  return {
    id, mode, kind, case: c, title, agent, prompt, files, stage: 'reading', status: 'draft', rv: [], reads, questions, answers: {}, over: {}, extraDocs: [], web, fixedExtra: [],
    version: 1, agreedV: 1, history: [], autonomy: 'end', nodes: shown.nodes, edges: shown.edges, removed: [], ns: {},
    findings: [], recs: [], outputs: [], started: [], gaps: [], chat: [], chips: [], typing: false, composer: { on: false, ph: 'Reading…' }, log: [], runs: [], flags: {}, doneCount: 0, paused: false,
    from: approachId, deliv, delivConfirmed: false, acts, execActs: [], built: {}, buildV: 0,
  }
}

/* The seeded rule: set and armed by Renee Halvorsen, SVP Contract Operations, on 12 November. */
const SEEDED = typeof window !== 'undefined' && /[?&]seed=1/.test(window.location.search)
const seedWatch = (): Journey => {
  const j = makeJourney('watch', 'rule', WATCH_PROMPT, [], false, AGENT_POOL[0])
  j.id = SEED_WATCH_ID
  j.stage = 'armed'; j.status = 'armed'
  j.rv = ['against', 'memory', 'watch', 'src:fin', 'src:proc', 'src:mail', 'src:web', 'where', 'prior', 'until', 'steps', 'fixed', 'frame', 'sheet', 'protect', 'size', 'combine', 'design', 'deliv']
  j.answers = { frame: 'none', design: 'ok', check: 'ok' }
  j.delivConfirmed = true
  j.history = []
  j.agreedAt = '12 Nov, 15:10'; j.armedAt = '12 Nov 2026, 15:10'; j.armedBy = 'Renee Halvorsen'; j.nextCheck = 'tomorrow’s morning check, 06:00 on 20 November'
  j.nodes.forEach((n) => { j.ns[n.id] = { state: 'pending' } })
  j.composer = { on: true, ph: 'Ask about the watch, or change it between checks…' }
  j.chips = ['Simulate tomorrow’s morning check (20 November)', 'What will it look like when it fires?', 'Open the renewal review']
  j.log = [{ t: '12 Nov, 15:10', who: 'Renee Halvorsen', what: 'Armed the watch (v1). Checks every contract each morning at 06:00.' }, { t: '19 Nov, 06:04', who: j.agent.name, what: 'Checked 300 contracts: 2 readings changed, no rating moved.' }]
  j.chat = [
    { id: mid(), who: 'me', text: WATCH_PROMPT, at: '12 Nov, 15:02' },
    { id: mid(), who: 'event', text: 'Watch armed · v1 · 12 Nov, 15:10 · Renee Halvorsen', at: '12 Nov, 15:10' },
    { id: mid(), who: 'agent', text: 'Watching. Every morning at 06:00 I read every signal of all 300 contracts again, from the operations data, the contracts, the mailboxes and the web, and score them on the scorecard agreed on 12 November. When the risk of a contract goes up I do what the rules on the Plan tab say, and tell you. The dashboard is on the right.', at: '12 Nov, 15:10' },
    { id: mid(), who: 'event', text: '19 Nov · 300 contracts checked · 2 readings changed, no rating moved · next: tomorrow, 06:00', at: '19 Nov, 06:04' },
  ]
  return j
}

const SEED_SAVED: SavedPlan[] = [
  { id: 'ap-q3', name: 'Renewals: likelihood, client side, what is at stake', mode: 'once', kind: 'once', prompt: ONCE_PROMPT, files: ONCE_FILES, steps: ONCE_NODES.filter((n) => n.type !== 'checkpoint').map((n) => n.title), from: 'Renewal review, December 2025', by: 'Renee Halvorsen', at: '3 Dec 2025', case: 'once' },
]


/* Edges route around removed steps so the workflow still reads left to right; a fork keeps its own edges. */
const rebuildEdges = (j: Journey, removed: string[]): [string, string][] => {
  const hasCp = j.nodes.some((n) => n.id === 'cp')
  const raw: [string, string][] = (j.case === 'once' || j.case === 'schedule' ? ONCE_EDGES : j.case === 'watch' || j.case === 'overrun-once' ? WATCH_EDGES : GENERIC_EDGES).slice()
  const base = hasCp ? raw : reroute(raw, ['cp'])
  if (j.ns.f1) base.push([hasCp ? 'cp' : 'n3', 'f1'], ['f1', 'n5'])
  let edges = base
  for (const r of removed) {
    const ins = edges.filter(([, b]) => b === r).map(([a]) => a), outs = edges.filter(([a]) => a === r).map(([, b]) => b)
    const kept = edges.filter(([a, b]) => a !== r && b !== r)
    ins.forEach((a) => outs.forEach((b) => { if (!kept.some(([x, y]) => x === a && y === b)) kept.push([a, b]) }))
    edges = kept
  }
  return edges
}


/** The goal in the shape Submissions and the analysis pack read: the recorded analysis under the base id, with this journey's state. */
export const baseIdOf = (j: Journey) => (j.case === 'once' || j.case === 'schedule' ? ONCE_BASE.id : WATCH_BASE.id)
export const toGoal = (j: Journey): Goal => {
  const base = j.case === 'once' || j.case === 'schedule' ? ONCE_BASE : WATCH_BASE
  const fm = j.case === 'once' || j.case === 'schedule' ? onceFindings(j.answers) : watchFindings()
  const findings = j.findings.length ? j.findings.map((k) => fm[k]?.base).filter((f): f is NonNullable<typeof f> => !!f) : base.findings
  return { ...base, gaps: j.gaps.length ? j.gaps : base.gaps, findings: findings.length ? findings : base.findings, id: baseIdOf(j), title: j.title, agent: j.agent, status: j.chosen ? 'accepted' : j.findings.length ? 'findings-ready' : 'armed', recommendations: j.recs.length ? j.recs : base.recommendations, acceptedFindings: j.findings.filter((k) => j.over[`acc:${k}`]).map((k) => fm[k]?.base?.id ?? k), planApproved: { by: j.armedBy ?? 'You', at: new Date().toISOString() } }
}
/* Submissions draw on goals from the older store; a journey with findings is registered there under its base id. */
const register = (j: Journey) => { if (j.case === 'generic' || !j.findings.length) return; const g = toGoal(j); useGoalStore.setState({ goals: [g, ...useGoalStore.getState().goals.filter((x) => x.id !== g.id)] }) }
/* The bell and the toast. A standing goal's news carries what it found and what it recommends. */
const notify = (j: Journey, kind: 'fired' | 'findings' | 'executed', title: string, text: string, extra: { found?: string; rec?: string; cta?: string } = {}) =>
  useGoalStore.setState({ notices: [{ id: `n-${j.id}-${Date.now().toString(36)}-${kind}`, at: now().toISOString(), kind, goalId: j.id, title, text, read: false, tab: (kind === 'executed' ? 'deliverables' : 'runs') as 'runs', ...extra }, ...useGoalStore.getState().notices] })

export const useJourney = create<S>((set, get) => {
  const g = (id: string) => get().goals[id]
  const patch = (id: string, fn: (j: Journey) => Partial<Journey>) => { const j = get().goals[id]; if (!j) return; set({ goals: { ...get().goals, [id]: { ...j, ...fn(j) } } }) }
  const push = (id: string, m: Omit<Msg, 'id' | 'at'>) => { const msg: Msg = { ...m, id: mid(), at: hhmm() }; patch(id, (j) => ({ chat: [...j.chat, msg] })); return msg.id }
  const say = (id: string, text: string, card?: Card) => push(id, { who: 'agent', text, card })
  const me = (id: string, text: string, files?: Att[]) => push(id, { who: 'me', text, files: files?.map((f) => ({ n: f.n, s: f.s })) })
  const ev = (id: string, text: string) => push(id, { who: 'event', text })
  const log = (id: string, who: string, what: string) => patch(id, (j) => ({ log: [...j.log, { t: hhmm(), who, what }] }))
  const typing = async (id: string, ms: number) => { patch(id, () => ({ typing: true })); await wait(Math.max(900, ms * 2)); patch(id, () => ({ typing: false })) }
  const change = (id: string, what: string, flash?: string[]) => patch(id, (j) => ({ version: ['plan', 'running', 'armed'].includes(j.stage) ? j.version + 1 : j.version, history: ['plan', 'running', 'armed'].includes(j.stage) ? [...j.history, { t: hhmm(), what }] : j.history, log: [...j.log, { t: hhmm(), who: 'You', what }], rv: flash ? [...new Set([...j.rv, ...flash])] : j.rv }))
  const setNode = (id: string, nodeId: string, state: NodeRun, extra: Partial<Journey['ns'][string]> = {}) => patch(id, (j) => {
    const ns = { ...j.ns, [nodeId]: { ...(j.ns[nodeId] ?? {}), ...extra, state, ...(state === 'running' || state === 'stale' ? { t0: Date.now() } : {}) } }
    const live = j.nodes.filter((n) => !j.removed.includes(n.id))
    const doneCount = live.filter((n) => ns[n.id]?.state === 'done' && n.type !== 'checkpoint' && !n.fork).length
    return { ns, doneCount }
  })
  const chips = (id: string, c: string[]) => patch(id, () => ({ chips: c }))
  const rmChip = (id: string, c: string) => patch(id, (j) => ({ chips: j.chips.filter((x) => x !== c) }))
  const composer = (id: string, on: boolean, ph: string) => patch(id, () => ({ composer: { on, ph } }))
  const needs = (j: Journey) => j.questions.filter((q) => !j.answers[q.key] && !j.over[`q:${q.key}`])
  const openQ = (j: Journey) => { for (let i = j.chat.length - 1; i >= 0; i -= 1) { const c = j.chat[i].card; if (c?.kind === 'q' && !c.done) return c.key } return null }
  const nextQuestion = (id: string) => {
    const j = g(id); if (!j || j.stage !== 'questions') return
    if (openQ(j)) return
    const q = needs(j)[0]
    if (q) { say(id, '', { kind: 'q', key: q.key }); return }
    if (!j.delivConfirmed) { if (!openDeliv(j)) askDeliv(id); return }
    void finishSetup(id)
  }
  /* The next question comes after a short pause, as if the agent read your answer first. */
  const nextQuestionTyped = async (id: string) => { const j = g(id); if (!j || j.stage !== 'questions' || openQ(j)) return; await typing(id, needs(j).length ? 800 : 1100); nextQuestion(id) }
  const openDeliv = (j: Journey) => j.chat.some((m) => m.card?.kind === 'deliv' && !m.card.done)
  /* The last thing asked before the run: what it hands over, on which template; for a standing goal also what it may do. */
  const askDeliv = (id: string) => {
    const j = g(id)
    const on = j.deliv.filter((d) => d.on)
    const lead = j.case === 'once' ? `Last thing before I start: what should I hand you at the end? Your brief asks for ${on.length === 3 ? 'all three' : 'these'}, so they are ticked. Untick any you do not need, pick the template for each, or add another.`
      : j.case === 'schedule' ? 'Last thing: what it builds before every portfolio review, and what it may do with it. Ticked is what the renewal review built.'
      : j.mode === 'watch' ? 'Last thing before I score everything. Two more things on the plan are yours to set: **what the dashboard shows**, and **what I do when a score rises**. Every site with a poor signal gets a mitigation plan in any case. Change them on the right, then build.'
      : j.case === 'overrun-once' ? 'Last thing before I start: what should I hand you at the end?' : 'Last thing before I start: what should I hand you at the end? No template in your library matches this goal, so I would design the structure.'
    say(id, lead, { kind: 'deliv' })
    composer(id, true, j.mode === 'watch' ? 'Or say it: "also the monthly review", "arm it"…' : 'Or say it: "only the pack", "also a back-test note", "run it"…')
    chips(id, [])
  }
  /* A card of steps that fill in one by one, as when the plan is first read. */
  const stepsCard = (id: string, intro: string) => {
    const msgId = say(id, intro, { kind: 'reads', lines: [] })
    const upd = (fn: (lines: NonNullable<Card['lines']>) => NonNullable<Card['lines']>) => patch(id, (jj) => ({ chat: jj.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: fn(m.card!.lines ?? []) } } : m)) }))
    return {
      start: (tool: string) => upd((l) => [...l.map((x) => ({ ...x, live: false })), { tool, res: '…', live: true }]),
      end: (res: string, warn?: boolean) => upd((l) => l.map((x, i) => (i === l.length - 1 ? { ...x, res, warn } : x))),
      settle: () => upd((l) => l.map((x) => ({ ...x, live: false }))),
    }
  }
  const distText = () => { const d = [0, 0, 0, 0, 0]; for (const c of CONTRACTS) d[rating(c, DESIGN.rule, 'before')] += 1; return [1, 2, 3, 4].map((r) => `${d[r]} ${RATING_NAME[r].toLowerCase()}`).join(', ') }
  /* After the template answer: the scorecard is read or drafted step by step. Only then does it appear on the plan. */
  const draftScorecard = async (id: string, up: boolean, tpl?: TplResult) => {
    const nF = activeFactors().length, nS = likelihoodSignals().length
    const stake = SIGNALS.filter((x) => x.f === 'im' && DESIGN.on[x.id]).length
    const miss = Object.keys(NOT_FOUND).length
    const nums = numericSignals().filter((x) => x.f !== 'im'), flagged = histFlagged(), reg = nums.filter((x) => REG_RULE.has(x.id)).length
    const histLine = `${nums.length} signals are scored on a figure. ${reg} follow a regulatory limit and stay as written. ${flagged.length ? `${flagged.length} put most projects in one score: ${flagged.map((x) => x.name.toLowerCase()).join('; ')}. I show the curve and a suggestion at the data check` : 'All of them spread your projects well'}`
    const file = DESIGN.tplName || TEMPLATE_FILE
    const steps: [string, string][] = up ? [
      [`open ${file}`, 'One row per signal: factor, weights, and when it scores 1, 2, 3 and 4'],
      ['read the factors and their weights', `${nF} factors: ${activeFactors('internal').length} we control and ${activeFactors('external').length} we do not${stake ? ', plus what is at stake' : ''}`],
      ['read the signals and the rule for 1 to 4 on each', `${tpl?.signals ?? nS + stake + miss} signals${tpl?.flags ? `, ${tpl.flags} marked as red flags` : ''}. Used exactly as written${tpl?.fresh.length ? `. ${tpl.fresh.length} ${tpl.fresh.length === 1 ? 'is' : 'are'} new to me: ${tpl.fresh.slice(0, 3).join('; ').toLowerCase()}` : ''}`],
      ['match every signal to a connected source', `${nS + stake} have a source${tpl?.noSource.length ? `. ${tpl.noSource.length} has none: ${tpl.noSource.join('; ').toLowerCase()}` : ''}`],
      ['look at three years of history behind every figure', histLine],
      [`score all ${CONTRACTS.length} projects once, exactly as written`, distText()],
    ] : [
      ['list what can make a contract go wrong', `${nF} factors in two halves, what we control and what we do not, plus what is at stake`],
      ['choose the signals the connected data can feed', `${nS + stake} signals with a source. ${miss} has none and stays out: the year of the last major upgrade`],
      ['write the rule for 1 to 4 on every signal', '1 is good, 4 is bad. Figures get thresholds; the rest get four written cases'],
      ['look at three years of history behind every figure', histLine],
      ['set the weights', `Each factor has a share of the score, each signal a weight in its factor. What came before the 7 contracts lost or left since 2021 counts more`],
      [`score all ${CONTRACTS.length} projects once to test it`, `${distText()}. ${lostCaught()} of the ${LOST.length} contracts lost at renewal would have rated 3 or more a year before`],
    ]
    patch(id, () => ({ draft: { title: up ? 'Reading your template' : 'Drafting the scorecard', steps: steps.map((x) => x[0]), done: 0 } }))
    const toPart = (sel: string, block: 'start' | 'center' = 'start') => { for (const ms of [240, 1000]) window.setTimeout(() => document.querySelector(sel)?.scrollIntoView({ block, behavior: 'smooth' }), ms) }
    window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'plan' } })); toPart('[data-testid="sdz-drafting"]', 'center')
    await typing(id, 450)
    const card = stepsCard(id, up ? `Reading **${file}** now. It appears on the right, exactly as you wrote it, when I am through.` : 'No template, so I draft the scorecard now. It appears on the right when it is ready.')
    for (let i = 0; i < steps.length; i += 1) {
      card.start(steps[i][0]); await wait(3000 + Math.random() * 1400)
      card.end(steps[i][1]); patch(id, (x) => ({ draft: x.draft ? { ...x.draft, done: i + 1 } : x.draft })); await wait(550)
    }
    card.settle(); await wait(600)
    if (!g(id)) return
    patch(id, (x) => ({ draft: null, rv: [...new Set([...x.rv, 'sheet'])] }))
    toPart('[data-part="sheet"]')
    if (up) { patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: file, took: `${nF} factors and ${tpl?.signals ?? nS + stake + miss} signals, with weights and a rule for 1 to 4 on each; used as written` }] })); say(id, `Your template is on the right, **exactly as you wrote it**: ${nF} factors with their weights${stake ? ', what is at stake,' : ''} and ${tpl?.signals ?? nS + stake + miss} signals with a rule for 1 to 4 on each. I added nothing and left nothing out.${tpl?.fresh.length ? ` ${tpl.fresh.length} ${tpl.fresh.length === 1 ? 'signal is' : 'signals are'} new to me (${tpl.fresh.slice(0, 3).join('; ')}); I found where to read ${tpl.fresh.length === 1 ? 'it' : 'them'}.` : ''}\n\nYou can still change anything, there or here in the chat.`) }
    else say(id, `The scorecard is on the right: **${nF} factors and ${nS} signals in one framework**, plus what is at stake. Each factor has its share of the score, each signal its weight and its rule for 1 to 4.\n\nIt is yours to change, there or here in the chat: “drop odor complaints”, “add a factor Energy cost”, “add a signal late invoices to Financial Performance”.`)
    await nextQuestionTyped(id)
    toPart('[data-part="sheet"]')
  }

  /* The scorecard can be changed by saying it: drop or put back a signal or a factor, add a factor, add a signal to a factor. */
  const norm = (x: string) => x.toLowerCase().replace(/[^a-z0-9% ]+/g, ' ').replace(/\b(the|a|an|signal|factor|from|scorecard|please)\b/g, ' ').replace(/\s+/g, ' ').trim()
  const pick = <T extends { name: string }>(list: T[], q: string): T | null => {
    const n = norm(q); if (n.length < 3) return null
    const exact = list.find((x) => norm(x.name) === n); if (exact) return exact
    const inc = list.filter((x) => norm(x.name).includes(n) || n.includes(norm(x.name))); if (inc.length) return inc.sort((a, b) => Math.abs(norm(a.name).length - n.length) - Math.abs(norm(b.name).length - n.length))[0]
    const words = n.split(' ').filter((w) => w.length > 2); let best: T | null = null, top = 0
    for (const x of list) { const nn = norm(x.name); const hit = words.filter((w) => nn.includes(w)).length / Math.max(1, words.length); if (hit > top) { top = hit; best = x } }
    return top >= 0.6 ? best : null
  }
  const scoreCmd = (id: string, text: string): boolean => {
    const j = g(id); if (!j || j.case !== 'watch' || !j.rv.includes('sheet') || !['questions', 'plan', 'armed'].includes(j.stage)) return false
    const t = text.trim().replace(/[.!]+$/, '')
    const tail = () => `The scorecard now has ${activeFactors().length} factors and ${likelihoodSignals().length} signals: ${distText()}.${j.stage === 'armed' ? ' The dashboard still shows the last version; **Publish** on the Plan tab scores every project again.' : ''}`
    const reply = (msg: string, sel?: string) => { me(id, text); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'plan' } })); if (sel) window.setTimeout(() => document.querySelector(sel)?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 260); window.setTimeout(() => say(id, msg), P(350)) }
    let m: RegExpMatchArray | null
    if ((m = t.match(/^add (?:a |an |the |new |another )*factor\s*(?:called |named |for |: )?(.+?)(?:\s+(?:to|under|in)\s+(what we do not control|what we don.?t control|what we control|the external (?:half|factors)|the internal (?:half|factors)))?$/i))) {
      const grp = m[2] && /not|don|external/i.test(m[2]) ? 'external' : 'internal'
      const f = design.factor(grp, m[1].replace(/^["“]|["”]$/g, ''))
      reply(`Added the factor **${f.name}** under ${grp === 'internal' ? 'what we control' : 'what we do not control'}, at a weight of 10. It counts once it has a signal. Add one on the right, or say “add a signal … to ${f.name}”.`, `[data-factor="${f.id}"]`)
      return true
    }
    if ((m = t.match(/^add (?:a |an |the |new |another )*signal\s*(?:called |named |for |: )?(.+)$/i))) {
      let rest = m[1], bands: string[] | undefined
      const bm = [...rest.matchAll(/\b([1-4])\s*(?:=|:|is|when|if)\s*([^;,]+)/gi)]
      if (bm.length >= 2) { bands = ['', '', '', '']; for (const x of bm) bands[Number(x[1]) - 1] = x[2].trim(); rest = rest.slice(0, bm[0].index).replace(/[\s,;:]+(?:scored?|scoring|with|rule)?[\s,;:]*$/i, '') }
      const fm = rest.match(/^(.+?)\s+(?:to|under|in|into)\s+(?:the factor |factor |the )?(.+)$/i)
      const f = fm ? pick(FACTORS, fm[2]) : null
      const name = (f ? fm![1] : rest).replace(/^["“]|["”]$/g, '').trim()
      if (name.length < 4) return false
      const sig = design.custom(name, f?.id, bands)
      const ff = FACTORS.find((x) => x.id === sig.f)!
      reply(`Added **${sig.name}** to **${ff.name}**${f ? '' : ', where it fits best'}. I read it from the ${sig.src.name.toLowerCase()} for all ${CONTRACTS.length} projects. ${bands ? 'It scores on the rule you gave.' : 'You gave no rule for 1 to 4, so I proposed one; open the signal on the right to change it.'} ${tail()}`, `.sdz-sig[data-signal="${sig.id}"]`)
      return true
    }
    if ((m = t.match(/^(drop|remove|delete|take out|leave out|put back|restore|bring back)\s+(.+)$/i))) {
      const on = /put back|restore|bring back/i.test(m[1]), q = m[2]
      const wantF = /\bfactor\b/i.test(q)
      const sig = wantF ? null : pick(SIGNALS, q), fac = sig ? null : pick(FACTORS.filter((x) => x.group !== 'impact'), q)
      if (sig) {
        if (NOT_FOUND[sig.id]) { reply(`**${sig.name}** has no source in the connected data, so it is not in use.`); return true }
        design.on(sig.id, on)
        reply(`${on ? 'Put back' : 'Dropped'} **${sig.name}** ${on ? 'in' : 'from'} ${FACTORS.find((x) => x.id === sig.f)!.name}. ${tail()}${on ? '' : ` Say “put back ${sig.name.toLowerCase()}” to undo.`}`, `.sdz-sig[data-signal="${sig.id}"]`)
        return true
      }
      if (fac) {
        const ids = SIGNALS.filter((x) => x.f === fac.id && !NOT_FOUND[x.id] && inTemplate(x)).map((x) => x.id)
        if (!ids.length) return false
        design.onMany(ids, on)
        reply(`${on ? 'Put back' : 'Dropped'} the factor **${fac.name}** with its ${ids.length} signals. ${tail()}`, `[data-factor="${fac.id}"]`)
        return true
      }
      return false
    }
    return false
  }

  const foldQ = (id: string, key: string, done: string) => patch(id, (j) => ({ chat: j.chat.map((m) => (m.card?.kind === 'q' && m.card.key === key && !m.card.done ? { ...m, card: { ...m.card, done } } : m)) }))
  /* Everything is clarified and the deliverables are agreed: a one-off goal runs, a standing goal arms. No second agreement. */
  const finishSetup = async (id: string) => {
    const j = g(id); if (!j) return
    patch(id, () => ({ stage: 'plan' }))
    await typing(id, 450)
    if (g(id)?.stage !== 'plan') return
    if (j.mode === 'watch' && j.case === 'watch') {
      const nS = likelihoodSignals().length, nR = CONTRACTS.reduce((n, c) => n + likelihoodSignals().filter((x) => c.v[x.id]).length, 0)
      const by = (k: string) => likelihoodSignals().filter((x) => x.src.kind === k).length
      const sites = CONTRACTS.filter((c) => planFor(c, 'before').some((x) => !x.fixed && !x.later)).length
      const build: [string, string][] = [
        ['read the operations data', `${by('table')} signals from the tables, by project, profit center and facility`],
        ['read the contracts and site documents', `${by('document')} signals, clause by clause`],
        ['read the mail and the public web', `${by('mail') + by('web')} signals: client mail, agendas, local media, public records`],
        [`score all ${CONTRACTS.length} projects`, `${nR.toLocaleString('en-US')} readings. ${distText()}`],
        ['write a mitigation plan for every site with a poor signal', `${sites} sites, each from its own records`],
        ['build the dashboard', `${PANELS.filter((p) => DESIGN.panels[p.k]).length} views · published as version 1`],
      ]
      const card = stepsCard(id, `Building it: ${nS} signals for ${CONTRACTS.length} projects.`)
      for (const [tool, res] of build) { card.start(tool); await wait(1300 + Math.random() * 800); card.end(res); await wait(320) }
      card.settle(); await wait(500)
      if (g(id)?.stage !== 'plan') return
    }
    if (j.mode === 'watch') arm(id)
    else agree(id)
  }

  /* ---------------- reading: the feed in the chat fills the plan on the right */
  const startReading = async (id: string) => {
    const j = g(id); if (!j) return
    const extra = j.files.filter((f) => f.id && f.id !== 'seed' && f.id !== 'up')
    me(id, j.prompt, j.files)
    await typing(id, 900)
    const intro = j.mode === 'watch' ? 'Working out what to watch, where it lives, and when it settles enough to check. The plan fills in on the right.' : 'Reading what you gave me, then checking what is connected. The plan fills in on the right as I go.'
    const msgId = say(id, intro, { kind: 'reads', lines: [] })
    const line = (tool: string, res: string, warn?: boolean) => patch(id, (jj) => ({ chat: jj.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: [...(m.card!.lines ?? []).map((l) => ({ ...l, live: false })), { tool, res, warn, live: true }] } } : m)) }))
    const settle = () => patch(id, (jj) => ({ chat: jj.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: (m.card!.lines ?? []).map((l) => ({ ...l, live: false })) } } : m)) }))
    for (const r of j.reads) { line(r.tool, '…'); await wait(900 + Math.random() * 700); patch(id, (jj) => ({ rv: [...new Set([...jj.rv, ...r.rv])], chat: jj.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: (m.card!.lines ?? []).map((l, i, arr) => (i === arr.length - 1 ? { ...l, res: r.res, warn: r.warn } : l)) } } : m)) })); await wait(300 + Math.random() * 300) }
    for (const a of extra) { line(`read ${a.n}`, '…'); await wait(600); const eff = applyEffect(id, a, true); patch(id, (jj) => ({ chat: jj.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: (m.card!.lines ?? []).map((l, i, arr) => (i === arr.length - 1 ? { ...l, res: eff?.res ?? 'Read' } : l)) } } : m)) })) }
    for (const a of j.files.filter((f) => f.id === 'up')) { line(`read ${a.n}`, '…'); await wait(600); patch(id, (jj) => ({ extraDocs: [...jj.extraDocs, { n: a.n, took: 'Read · nothing in it changes the plan as it stands', mine: true }], chat: jj.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: (m.card!.lines ?? []).map((l, i, arr) => (i === arr.length - 1 ? { ...l, res: 'Read · listed under what I’m working from' } : l)) } } : m)) })) }
    const jj = g(id)
    const live = jj.nodes.filter((n) => !jj.removed.includes(n.id))
    const cps = live.filter((n) => n.type === 'checkpoint').length
    const cols = new Set(live.map((n) => n.col))
    const side = live.length - cols.size
    line(jj.mode === 'watch' ? (jj.case === 'schedule' ? 'draft what I do when it runs' : 'draft what I do when it fires') : jj.from ? 'apply your saved approach' : 'draft the plan', `${live.filter((n) => n.type !== 'checkpoint').length} steps${side ? ` · ${side === 1 ? 'two' : side === 2 ? 'three' : side + 1} side by side` : ''} · ${cps ? 'one checkpoint' : 'no checkpoint'}`)
    await wait(2200)
    patch(id, (x) => ({ rv: [...new Set([...x.rv, 'steps'])], ns: Object.fromEntries(x.nodes.map((n) => [n.id, x.ns[n.id] ?? { state: 'pending' }])) }))
    settle()
    patch(id, () => ({ stage: 'questions' }))
    const n = needs(g(id)).length
    await typing(id, 600)
    const base = jj.mode === 'watch' ? 'The plan for the watch is on the right.' : 'The plan is on the right: what we are answering, what I am working from, and how I would go about it.'
    say(id, n ? `${base} ${n === 1 ? 'One thing I could not find' : `${word(n, true)} things I could not find`}, then what you want at the end; one at a time. After that I run it to the end without stopping.` : jj.case === 'generic' ? `${base} No recorded analysis in this copy matches this goal, so the run will show the position and end on a question rather than land findings. The two examples carry full analyses.` : `${base} Nothing is missing; only what you want at the end, then I run it.`)
    composer(id, true, n ? 'Answer here, or pick an option above' : 'Change anything in plain words…')
    await wait(350)
    nextQuestion(id)
  }

  /* ---------------- what a document from a connector changes */
  const applyEffect = (id: string, a: Att, silent: boolean): { res: string; msg: string } | null => {
    const j = g(id); if (!j) return null
    const f = a.id ? LIB[a.id] : undefined
    const record = (what: string, flash: string[]) => { if (!silent) change(id, what, flash); else patch(id, (x) => ({ rv: [...new Set([...x.rv, ...flash])] })) }
    if (!f || j.case !== 'once') {
      patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Read · nothing in it changes the plan as it stands', mine: true, drill: f?.drill }] }))
      record(`Added ${a.n}`, [`doc:${a.n}`])
      return { res: 'Read · nothing in it changes the plan', msg: `Read **${a.n}**. It is listed under what I’m working from; nothing in it changes the plan as it stands.` }
    }
    if (f.id === 'deck') { record(`Added ${a.n}`, ['doc:q2']); return { res: 'Already read', msg: 'Last year’s review was already in: it is listed under what I’m working from, and its five sections are the structure for the new pack.' } }
    if (f.id === 'fcwork') {
      patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Took: your notes count the evergreen contracts and treat an NPS from a predecessor as not to rely on', mine: true, drill: f.drill }], answers: j.stage === 'running' ? x.answers : { ...x.answers, four: x.answers.four ?? 'june', t3: x.answers.t3 ?? 'out' }, dateSrc: x.dateSrc }))
      if (j.stage !== 'running') { record('The evergreen contracts and the predecessors’ NPS are treated as in your working notes', ['as:four', 'as:t3', 'doc:fcwork']); foldQ(id, 'four', 'from your working notes'); foldQ(id, 't3', 'from your working notes') }
      return { res: 'The evergreen contracts counted · a predecessor’s NPS flagged', msg: j.stage === 'running' ? 'Added. The run already counts the evergreen contracts, which is what your notes do too.' : 'Your working notes settle both questions: the evergreen contracts are **counted**, because a client that can leave on notice decides every year, and an NPS given by a predecessor is **flagged, with the scorecard left as written**. The plan says so.' }
    }
    if (f.id === 'q2min') {
      patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Took: Calder Valley was lost after a new client lead, an adviser and a stale NPS; treat a predecessor’s score as no score', mine: true, drill: f.drill }], answers: j.stage === 'running' ? x.answers : { ...x.answers, t3: x.answers.t3 ?? 'out' } }))
      if (j.stage !== 'running') { record('A predecessor’s NPS is flagged, as the Calder Valley review recommends', ['as:t3', 'doc:q2min']); foldQ(id, 't3', 'from the Calder Valley review') }
      return { res: 'A score given by a predecessor is treated as no score', msg: 'The loss review answers the question on the NPS: it recommends **treating a score given by a predecessor as no score**. I keep the scorecard you agreed and flag those contracts. The plan says so.' }
    }
    if (f.id === 'rc') {
      patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Took: the factors, weights and bands the ratings in this review come from; used as written', mine: true, drill: f.drill }] }))
      record(`Added ${a.n}`, ['doc:rc'])
      return { res: 'factors, signals and bands read', msg: 'Read the scorecard. The ratings in this review are **the scorecard you agreed**: 12 factors, 42 signals, bands 1 to 4. Client-side signs are shown beside it, not mixed in. Ask for a what-if and I show it beside step 4.' }
    }
    if (f.id === 'p5' && j.stage !== 'running') {
      patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Took: Tom Brandvold asks for the evergreen contracts to be counted', mine: true, drill: f.drill }], answers: { ...x.answers, four: x.answers.four ?? 'june' } }))
      record('The evergreen contracts are counted, as Tom Brandvold asks', ['as:four', 'doc:p5']); foldQ(id, 'four', 'from Tom Brandvold’s reply')
      return { res: 'Count the evergreen contracts', msg: 'Tom’s reply answers the question on the evergreen contracts: **count them**, because a client who can walk on notice is deciding every year. The plan says so.' }
    }
    if (f.id === 'c3' && j.stage !== 'running') {
      patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Took: the Ashby Falls client lead changed on 17 August; the NPS on file is her predecessor’s', mine: true, drill: f.drill }], answers: { ...x.answers, t3: x.answers.t3 ?? 'expected' } }))
      record('Contracts with a predecessor’s NPS are kept and listed separately', ['as:t3', 'doc:c3']); foldQ(id, 't3', 'from the Ashby Falls thread')
      return { res: 'Keep the score; list those contracts separately', msg: 'The thread shows how it happens: a new client lead, and a score on file from someone who has left. I **keep the score and list those contracts separately** for the client experience team. The plan says so.' }
    }
    patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Already read from Outlook; nothing new', mine: true, drill: f.drill }] }))
    record(`Added ${a.n}`, [`doc:${f.id}`])
    return { res: 'Already read from Outlook', msg: `That thread was already read from Outlook; it is listed under what I’m working from.` }
  }

  /* ---------------- the run */
  const reachCheckpoint = (id: string) => {
    patch(id, () => ({ status: 'wait' }))
    setNode(id, 'cp', 'wait')
    say(id, '', { kind: 'cp' })
    ev(id, 'Checkpoint · waits for you')
    log(id, g(id).agent.name, 'Reached the checkpoint; waiting for how the evergreen contracts are treated.')
    chips(id, ['What are you doing now?'])
  }
  const runOnce = (id: string, fromCheckpoint = false) => {
    const j = g(id); if (!j) return
    const A = j.agent.name
    const evl = (txt: string, what?: string) => { ev(id, txt); log(id, A, what ?? txt) }
    const four = j.answers.four
    const has = (n: string) => !g(id).removed.includes(n)
    const steps: { d: number; fn: () => void }[] = fromCheckpoint ? [] : [
      { d: 1400, fn: () => setNode(id, 'n1', 'running', { at: hhmm() }) },
      { d: 10500, fn: () => { const f = rbOf(g(id)); setNode(id, 'n1', 'done', { text: `Done · ${f.n} contracts` }); patch(id, (x) => ({ findings: [...x.findings, 'F1'] })); ['n2', 'n3'].filter(has).forEach((n) => setNode(id, n, 'running', { at: hhmm() })); evl(`Step 1 done · ${f.n} contracts decide in 18 months, ${m1(f.revenue)} a year`); ev(id, `Provisional finding · ${f.high.length} of them rate 3 or 4 on the scorecard`) } },
      { d: 9000, fn: () => { if (has('n3')) { const f = rbOf(g(id)); setNode(id, 'n3', 'done', { text: `Done · ${m1(f.rate)} need a plan` }); patch(id, (x) => ({ findings: [...x.findings, 'F3'] })); evl(`Step 3 done · ${f.plan.length} contracts need a renewal plan, ${m1(f.rate)} a year`) } } },
      { d: 3000, fn: () => {
        const f = rbOf(g(id)); if (four === 'standin') { setNode(id, 'n2', 'done', { text: 'Done · evergreen left out', contentKey: 'n2b', caveat: true }); patch(id, (x) => ({ findings: [...x.findings, 'F2b'] })); evl(`Step 2 done · ${f.quiet.length} quiet contracts with a client-side sign, the evergreen contracts left out · 1 judgement`) }
        else { setNode(id, 'n2', 'done', { text: `Done · ${f.quiet.length} quiet ones with a sign`, caveat: true }); patch(id, (x) => ({ findings: [...x.findings, 'F2'], flags: { ...x.flags, steerAvail: true } })); evl(`Step 2 done · ${f.quiet.length} contracts rated 1 or 2 show a client-side sign, ${m1(f.quietRev)} a year`, `Step 2 done. ${f.quiet.length} contracts rated 1 or 2 show a client-side sign; ${f.newLead.length} have a new client lead since their NPS answer.`) }
        /* No stop here any more: how the evergreen contracts are treated was settled while planning. */
        void reachCheckpoint
        patch(id, (x) => ({ flags: { ...x.flags, cpAnswered: true } })); seqs[id] = new Seq(tail()); seqs[id].next()
      } },
    ]
    const tail = (): { d: number; fn: () => void }[] => [
      { d: 900, fn: () => { if (has('n4')) setNode(id, 'n4', 'running', { at: hhmm() }); else setNode(id, 'n5', 'running', { at: hhmm() }); if (g(id).ns.f1) setNode(id, 'f1', 'running', { at: hhmm() }); ev(id, has('n4') ? 'Back-test running' : 'Recommendation running') } },
      { d: 10000, fn: () => { if (has('n4')) { setNode(id, 'n4', 'done', { text: 'Done · 2 of 3 rated 2' }); patch(id, (x) => ({ findings: [...x.findings, 'F4'] })); evl('Step 4 done · 2 of the 3 lost renewals rated 2 a year before the loss') } if (g(id).ns.f1) setNode(id, 'f1', 'done', { text: 'Done · side by side' }); setNode(id, 'n5', 'running', { at: hhmm() }) } },
      { d: 10500, fn: () => { const f = rbOf(g(id)); setNode(id, 'n5', 'done', { text: 'Done · 1 preferred, 2 alternatives' }); patch(id, (x) => ({ recs: onceRecs(x.answers) })); evl(`Step 5 done · recommendation: ${f.plan.length} contracts on a renewal plan, ${m1(f.rate)} a year`); decideThenBuild(id, 'n6', () => { const nb = g(id).deliv.filter((d) => d.on).length; setNode(id, 'n6', 'done', { text: `Done · ${word(nb)} deliverable${nb === 1 ? '' : 's'} built` }); finishOnce(id) }) } },
    ]
    if (fromCheckpoint) { seqs[id] = new Seq(tail()); seqs[id].next(); return }
    seqs[id] = new Seq(steps)
    seqs[id].next()
  }
  /* ---------------- deciding and building by itself */
  const recNo = (j: Journey, recId?: string) => j.recs.findIndex((r) => r.id === recId) + 1
  const shortT = (t: string) => (t.split(/[;:,]\s/)[0] ?? t)
  const basisOf = (j: Journey) => { const r = j.recs.find((x) => x.id === j.chosen); return r ? `option ${recNo(j, r.id)}, ${shortT(r.title).replace(/^./, (c) => c.toLowerCase())}` : 'the findings' }
  /* The agent takes a moment over each decision, then the deliverables are built part by part on the right. */
  const decideThenBuild = (id: string, node: string, onBuilt: () => void) => {
    ev(id, 'Weighing the findings against the brief and the policies')
    seqs[id] = new Seq([
      { d: 3200, fn: () => { const j = g(id); patch(id, (x) => ({ over: { ...x.over, ...Object.fromEntries(x.findings.map((k) => [`acc:${k}`, x.over[`acc:${k}`] ?? 'auto'])) } })); ev(id, `Findings accepted automatically · ${j.findings.length} of ${j.findings.length}`) } },
      { d: 2800, fn: () => { autoDecide(id, true) } },
      { d: 1500, fn: () => { setNode(id, node, 'running', { at: hhmm() }); buildAll(id); reveal(id, 950, onBuilt) } },
    ])
    seqs[id].next()
  }
  /** Show the deliverables being built: one at a time, part by part, in the panel on the right. */
  const reveal = (id: string, perPart: number, onEnd?: () => void) => {
    const j = g(id)
    const all = useSubmissionStore.getState().submissions
    const sids = j.deliv.filter((d) => d.on && j.built[d.id]).map((d) => j.built[d.id])
    const subs = sids.map((sid) => all.find((x) => x.id === sid)).filter((x): x is NonNullable<typeof x> => !!x)
    patch(id, () => ({ prog: { sids: subs.map((x) => x.id), i: 0, shown: 0 } }))
    window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'deliverables' } }))
    const steps: { d: number; fn: () => void }[] = []
    subs.forEach((x, i) => {
      const n = x.sections.filter((y) => y.included).length
      steps.push({ d: i === 0 ? 400 : perPart * 1.4, fn: () => patch(id, (y) => ({ prog: { ...(y.prog ?? { sids: [] }), sids: y.prog?.sids ?? [], i, shown: 0 } })) })
      for (let k = 1; k <= n; k += 1) steps.push({ d: perPart, fn: () => patch(id, (y) => ({ prog: y.prog ? { ...y.prog, shown: k } : y.prog })) })
      steps.push({ d: 350, fn: () => ev(id, `Built · ${x.title.split(':')[0]} · ${n} ${x.format === 'Slide pack' ? 'slides' : x.format === 'Workbook' ? 'sheets' : x.format === 'Dashboard' ? 'panels' : 'sections'}`) })
    })
    seqs[id] = new Seq(steps, () => { patch(id, () => ({ prog: null })); onEnd?.() })
    seqs[id].next()
  }
  /** Findings are accepted and the top recommendation is chosen without asking; both stay open to change afterwards. */
  const autoDecide = (id: string, quiet = false) => {
    const j = g(id); if (!j || !j.recs.length) return
    const top = j.recs.find((r) => r.preferred) ?? j.recs[0]
    patch(id, (x) => ({ over: { ...x.over, ...Object.fromEntries(x.findings.map((k) => [`acc:${k}`, x.over[`acc:${k}`] ?? 'auto'])) }, chosen: top.id, chosenBy: 'auto', recs: x.recs.map((o) => ({ ...o, preferred: o.id === top.id })) }))
    register(g(id))
    const A = j.agent.name
    if (!quiet) ev(id, `Findings accepted automatically · ${j.findings.length} of ${j.findings.length}`)
    ev(id, `Top recommendation chosen · option ${recNo(g(id), top.id)}`)
    log(id, A, `Accepted the ${j.findings.length} findings and chose the top recommendation: ${top.title}.`)
  }
  /* A template for each deliverable: the one in the library, your file, or one designed for this reader. */
  const resolveTpl = (id: string, d: DelivSpec, goal: Goal): Template | undefined => {
    const sub = useSubmissionStore.getState()
    const t = templateOf(d, sub.templates)
    if (t) return t
    if (d.mode !== 'ai') return undefined
    const made = d.templateId ? sub.templates.find((x) => x.id === d.templateId) : undefined
    if (made) return made
    const desc = d.describe?.trim() || `${d.label}. ${d.purpose}. For ${d.audience}.`
    const p = designOutline(d.format, desc, goal)
    const tpl = { ...templateFromOutline(`${d.label} (designed for this goal)`, p, desc), id: `t-desc-${d.id}-${Date.now().toString(36)}` }
    sub.addTemplate(tpl, g(id).agent.name)
    patch(id, (x) => ({ deliv: x.deliv.map((y) => (y.id === d.id ? { ...y, templateId: tpl.id } : y)) }))
    return tpl
  }
  /** Build (or rebuild) every deliverable agreed at the start, on the decision as it stands. */
  const buildAll = (id: string, only?: string) => {
    const j = g(id); if (!j || j.case === 'generic') return
    const goal = toGoal(j)
    register(j)
    const who = useAuthStore.getState().identity?.name ?? 'You'
    const sub = useSubmissionStore.getState()
    const basis = basisOf(j)
    const built = { ...j.built }
    for (const d of j.deliv.filter((x) => x.on && (!only || x.id === only))) {
      const tpl = resolveTpl(id, d, goal)
      if (!tpl) continue
      const prev = built[d.id] && sub.submissions.some((x) => x.id === built[d.id]) ? built[d.id] : undefined
      if (prev) useSubmissionStore.getState().rebuildDeliverable(prev, goal, j.agent.name, basis)
      else built[d.id] = useSubmissionStore.getState().buildDeliverable(goal, { id: d.id, label: d.label, audience: d.audience, purpose: d.purpose, template: tpl.name, templateId: tpl.id, why: d.why ?? '' }, tpl, who, { journeyId: id, delivId: d.id, basis, agentName: j.agent.name })
    }
    patch(id, (x) => ({ built, buildV: x.buildV + 1, deliveredAt: hhmm(), started: [...new Set([...x.started, ...Object.keys(built)])] }))
  }
  const delivNames = (j: Journey) => { const l = j.deliv.filter((d) => d.on).map((d) => `**${d.label.split(':')[0]}**`); return l.length > 1 ? `${l.slice(0, -1).join(', ')} and ${l[l.length - 1]}` : l[0] ?? 'nothing' }
  const AFTER_CHIPS = (j: Journey) => (j.case === 'once' ? [j.answers.four === 'standin' || j.flags.steered ? 'Why option 1?' : STEER, 'Use option 3 instead', 'Show me the findings', 'Make more deliverables in Submissions'] : ['Why option 1?', 'Show me the findings', 'Make more deliverables in Submissions'])

  const finishOnce = (id: string) => {
    const j = g(id)
    const watchMode = j.mode === 'watch'
    patch(id, (x) => ({ status: watchMode ? 'executed' : 'delivered', outputs: ONCE_OUTPUTS, gaps: ONCE_GAPS, runs: x.runs.map((r) => ({ ...r, status: 'executed' as const })), executedAt: hhmm() }))
    if (!g(id).chosen) autoDecide(id)
    if (!Object.keys(g(id).built).length) buildAll(id)
    const jj = g(id)
    const f = rbOf(jj)
    log(id, j.agent.name, `Built ${jj.deliv.filter((d) => d.on).length} deliverables on ${basisOf(jj)}.`)
    ev(id, `Delivered · ${hhmm()} · moved to Executed`)
    const head = `Done. ${delivNames(jj)} ${jj.deliv.filter((d) => d.on).length === 1 ? 'is' : 'are'} built and open on the right.`
    const what = `**Put ${f.plan.length} contracts on a renewal plan now: ${m1(f.rate)} a year${jj.answers.four === 'standin' ? ', with the evergreen contracts left out' : ''}.** That is every contract rated 3 or 4 and the ${word(f.quiet.length)} quiet ones with a client-side sign, of ${f.n} that decide in 18 months.`
    const how = `I accepted the ${word(jj.findings.length)} findings and chose option ${recNo(jj, jj.chosen)} of ${word(jj.recs.length)}; both are under Findings if you want to check them. To change anything, say so here: another option, a treatment to change, a section to rewrite. The deliverables are rebuilt.`
    if (watchMode) { runActions(id, scheduleActionsFor()); return }
    say(id, `${head}\n\n${what} Ashby Falls is the one I would start with: $7.4M a year, seven months left, and its Select Board discusses in-house operation on 2 December.\n\n${how}`, { kind: 'delivered' })
    chips(id, AFTER_CHIPS(g(id)))
    composer(id, true, 'Change anything: another option, a treatment, a section…')
    window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'deliverables' } }))
  }
  const caveatCount = (j: Journey) => { let n = 1; if (j.answers.four !== 'standin' && !j.flags.steered) n += 1; if (j.answers.t3 !== 'out') n += 1; return n }
  void caveatCount

  const runWatch = (id: string) => {
    const j = g(id); if (!j) return
    const A = j.agent.name
    const evl = (txt: string) => { ev(id, txt); log(id, A, txt) }
    const has = (n: string) => !g(id).removed.includes(n)
    const steps: { d: number; fn: () => void }[] = [
      { d: 1500, fn: () => setNode(id, 'w1', 'running', { at: hhmm() }) },
      { d: 10000, fn: () => { setNode(id, 'w1', 'done', { text: `Done · ${watchStory().mv.length} changed · ${watchStory().up.length} moved up`, caveat: true }); patch(id, (x) => ({ findings: [...x.findings, 'W1'] })); ['w2', 'w3'].filter(has).forEach((n) => setNode(id, n, 'running', { at: hhmm() })); evl(`Step 1 done · every reading re-read · ${watchStory().mv.length} contracts changed · ${watchStory().short}`) } },
      { d: 9500, fn: () => { if (has('w2')) { setNode(id, 'w2', 'done', { text: 'Done · demand letter' }); patch(id, (x) => ({ findings: [...x.findings, 'W2'] })); evl('Step 2 done · a demand letter for 23 residents at Harlow Creek; in-house operation on the Ashby Falls agenda; a second missed sample at Red Mesa') } } },
      { d: 2500, fn: () => { if (has('w3')) { setNode(id, 'w3', 'done', { text: `Done · ${watchStory().mv.filter((m) => m.p1 === 'Act now').length} to act on now`, caveat: true }); patch(id, (x) => ({ findings: [...x.findings, 'W3', 'W4'] })); evl(`Step 3 done · what is at stake weighed · ${watchStory().mv.filter((m) => m.p1 === 'Act now').map((m) => shortSite(m.c)).join(' and ') || 'none'} now high risk with a lot at stake`) } if (has('w4')) setNode(id, 'w4', 'running', { at: hhmm() }); else setNode(id, 'w5', 'running', { at: hhmm() }) } },
      { d: 10000, fn: () => { if (has('w4')) { setNode(id, 'w4', 'done', { text: 'Done · a plan for each site' }); patch(id, () => ({ recs: WATCH_RECS.map((r) => ({ ...r })) })); evl('Step 4 done · a mitigation plan written for each site that rose') } else patch(id, () => ({ recs: WATCH_RECS.map((r) => ({ ...r })) })); decideThenBuild(id, 'w5', () => finishWatch(id)) } },
    ]
    seqs[id] = new Seq(steps)
    seqs[id].next()
  }
  const finishWatch = (id: string) => {
    const j = g(id)
    patch(id, (x) => ({ outputs: WATCH_OUTPUTS, gaps: WATCH_GAPS, recs: x.recs.length ? x.recs : WATCH_RECS.map((r) => ({ ...r })) }))
    if (!g(id).chosen) autoDecide(id)
    if (!Object.keys(g(id).built).length) buildAll(id)
    log(id, j.agent.name, `Built ${j.deliv.filter((d) => d.on).length} deliverables on ${basisOf(g(id))}.`)
    if (j.mode === 'watch') { runActions(id, ruleActions(g(id))); return }
    /* The same positions as a one-off: the deliverables, nothing executed. */
    setNode(id, 'w5', 'done', { text: `Done · ${word(j.deliv.filter((d) => d.on).length)} built` })
    patch(id, () => ({ status: 'delivered', executedAt: hhmm() }))
    ev(id, `Delivered · ${hhmm()} · moved to Executed`)
    const jj = g(id)
    say(id, `Done. ${delivNames(jj)} ${jj.deliv.filter((d) => d.on).length === 1 ? 'is' : 'are'} built on option ${recNo(jj, jj.chosen)} and open on the right: **act on all three contracts today**, Legal and an odor plan at Harlow Creek, cover at Red Mesa, a renewal plan at Ashby Falls.\n\nI accepted the four findings and chose the top option; both are under Findings. Nothing is executed from a one-off goal; a standing goal can do that. Change anything here and the deliverables are rebuilt.`, { kind: 'delivered' })
    chips(id, AFTER_CHIPS(jj))
    window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'deliverables' } }))
  }
  /* A standing goal acts on the option it chose: what was agreed to run by itself is done, the rest waits for your OK. Then it tells you. */
  const modeOf = (j: Journey, cat: string): ActMode => j.acts.find((a) => a.key === cat)?.mode ?? 'ask'
  /* What your rules say to do about what changed this morning. Only rules that are on, and only where they apply. */
  const ruleActions = (j: Journey): { cat: string; text: string }[] => {
    const S = watchStory(), out: { cat: string; text: string }[] = []
    const on = (k: string) => j.acts.some((a) => a.key === k && a.on !== false)
    const names = (xs: typeof S.mv) => xs.map((m) => shortSite(m.c)).join(' and ')
    if (on('dash')) out.push({ cat: 'dash', text: `Refresh the dashboard for all ${CONTRACTS.length} contracts` })
    for (const m of S.up) {
      if (on('tell')) out.push({ cat: 'tell', text: `Tell ${m.c.rvp}, Regional VP, and ${m.c.leader}, project leader: ${shortSite(m.c)} moved from ${m.r0} to ${m.r1}, with the reason and the evidence` })
      if (on('deck')) out.push({ cat: 'deck', text: `Build the deck: why ${shortSite(m.c)} moved from ${m.r0} to ${m.r1}` })
    }
    if (on('plan')) for (const m of S.mv.filter((x) => x.sigs.some((y) => y.to >= 3))) out.push({ cat: 'plan', text: `Write the mitigation plan for ${shortSite(m.c)}: ${planFor(m.c, 'after').filter((x) => !x.fixed && !x.later).length} actions, each with an owner and a date` })
    if (on('svp')) for (const m of S.mv.filter((x) => x.p1 === 'Act now' && x.p0 !== 'Act now')) out.push({ cat: 'svp', text: `Tell ${PEOPLE.owner}, ${PEOPLE.ownerRole}: ${shortSite(m.c)} is now high risk with a lot at stake` })
    if (on('digest') && S.rose.length) out.push({ cat: 'digest', text: `List ${names(S.rose)} in the Monday digest: the score rose, the rating held` })
    for (const a of j.acts.filter((x) => x.custom && x.on !== false)) { if ((a.when === 'A rating goes up' && S.up.length) || a.when === 'After every check' || (a.when === 'A signal reaches 3 or 4' && S.mv.some((m) => m.sigs.some((y) => y.to >= 3)))) out.push({ cat: a.key, text: `${a.text}${S.up.length ? ` (${names(S.up)})` : ''}` }) }
    if (!out.length) out.push({ cat: 'dash', text: 'Nothing to do: no rule of yours applies to what changed this morning' })
    return out
  }
  const runActions = (id: string, list: { cat: string; text: string }[]) => {
    const j = g(id)
    const A = j.agent.name
    const node = j.nodes.some((n) => n.id === 'w5') ? 'w5' : 'n6'
    patch(id, () => ({ status: 'executing', execActs: list.map((x) => ({ ...x, state: 'todo' as const })) }))
    say(id, '', { kind: 'actions' })
    const steps = list.map((x, i) => ({ d: i === 0 ? 2000 : 1700, fn: () => {
      const auto = modeOf(g(id), x.cat) === 'auto'
      patch(id, (y) => ({ execActs: y.execActs.map((a, k) => (k === i ? { ...a, state: auto ? 'done' : 'waiting' } : a)) }))
      log(id, A, auto ? `Done: ${x.text}.` : `Held for your OK: ${x.text}.`)
    } }))
    seqs[id] = new Seq(steps, () => {
      const jj = g(id); const t = hhmm()
      const waiting = jj.execActs.filter((a) => a.state === 'waiting')
      const done = jj.execActs.filter((a) => a.state === 'done')
      if (node === 'w5') setNode(id, 'w5', 'done', { text: `Done · ${done.length} done${waiting.length ? `, ${waiting.length} for your OK` : ''}` })
      patch(id, (x) => ({ status: 'executed', executedAt: t, runs: x.runs.map((r) => ({ ...r, status: 'executed' as const })) }))
      register(g(id))
      ev(id, `Executed · ${t} · ${done.length} action${done.length === 1 ? '' : 's'} done${waiting.length ? ` · ${waiting.length} waits for your OK` : ''} · moved to Executed`)
      const opt = jj.recs.find((r) => r.id === jj.chosen)
      if (jj.case === 'schedule') {
        notify(g(id), 'executed', 'Renewal review refreshed: the deliverables are rebuilt', `${A} ran the plan, chose option ${recNo(jj, jj.chosen)} and sent the deliverables.`, { found: opt?.title, cta: 'Open it' })
        say(id, `Done. ${delivNames(jj)} ${jj.deliv.filter((d) => d.on).length === 1 ? 'is' : 'are'} rebuilt on option ${recNo(jj, jj.chosen)} and open on the right; ${done.length} action${done.length === 1 ? '' : 's'} done. The goal stays armed for the next review.`, { kind: 'delivered' })
        chips(id, ['Show me the findings', 'Make more deliverables in Submissions'])
      } else {
        const S = watchStory()
        useDesign.getState().refresh('20 Nov, 06:08', 'after')
        notify(g(id), 'executed', `${S.head}: handled${waiting.length ? `, ${waiting.length} ${waiting.length === 1 ? 'action waits' : 'actions wait'} for your OK` : ''}`, `${A} re-scored ${CONTRACTS.length} contracts, read the evidence, wrote the plan for each site and did ${done.length} of ${jj.execActs.length} things your rules ask for.`, { found: S.mv.map((m) => shortSite(m.c)).join(', '), cta: 'Open it' })
        say(id, `Handled. ${S.line}\n\n${S.up.length ? `For ${S.up.map((m) => shortSite(m.c)).join(' and ')} the owners are told, and ${delivNames(jj)} ${jj.deliv.filter((d) => d.on).length === 1 ? 'is' : 'are'} built and open on the right. ` : ''}The dashboard is refreshed with the new position (open it in **Submissions** or on the Deliverables tab). It keeps its version number, because the scoring did not change. Also, ${done.length} of ${jj.execActs.length} actions from your rules are done${waiting.length ? `; ${waiting.length} ${waiting.length === 1 ? 'waits' : 'wait'} for your OK` : ''}. I keep watching; the next check is tomorrow at 06:00.`, { kind: 'delivered' })
        chips(id, [...(waiting.length ? ['Approve it'] : []), 'Show me the findings', 'Change the scorecard', 'Make more deliverables in Submissions'])
      }
      window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'deliverables' } }))
    })
    seqs[id].next()
  }
  void tellNames
  const runGeneric = (id: string) => {
    const j = g(id); if (!j) return
    const live = j.nodes.filter((n) => !j.removed.includes(n.id))
    const steps: { d: number; fn: () => void }[] = []
    live.forEach((n, i) => {
      steps.push({ d: i === 0 ? 1400 : 9000, fn: () => { if (i > 0) setNode(id, live[i - 1].id, 'done', { text: 'Done' }); setNode(id, n.id, 'running', { at: hhmm() }); if (i > 0) ev(id, `Step ${i} done · ${live[i - 1].title}`) } })
    })
    steps.push({ d: 9000, fn: () => { setNode(id, live[live.length - 1].id, 'done', { text: 'Done' }); ev(id, `Step ${live.length} done · ${live[live.length - 1].title}`); patch(id, (x) => ({ status: 'ready', flags: { ...x.flags, genericQ: true } })); say(id, 'All steps run. The goal names a measure the graph does not compute in this copy, so I have the position but no recorded analysis to land as findings.\n\nShould I drop that measure from the goal, or state it as a range from the recorded positions? Either way, the two example goals are where the full journeys are.'); chips(id, ['Drop it from the goal', 'State it as a range', 'Open the data']) } })
    seqs[id] = new Seq(steps)
    seqs[id].next()
  }

  /* ---------------- plan-stage changes from the chat */
  const handlePlan = async (id: string, text: string) => {
    const j = g(id)
    const t = text.toLowerCase()
    if (/^(agree|agree and run|run it|approve|go ahead|arm|arm it|arm the watch)/.test(t)) { if (j.mode === 'watch') arm(id); else agree(id); return }
    me(id, text)
    await typing(id, 600)
    if (j.mode === 'once' && j.case === 'once') {
      if (/only the (next )?12 months|12 months only|only twelve/.test(t)) { patch(id, (x) => ({ over: { ...x.over, scope: 'Only the contracts that decide in the next 12 months; those 13 to 18 months out are left for the next quarterly review.' } })); change(id, 'Scope narrowed to the next 12 months', ['scope', 'step:n1']); say(id, 'Scoped to the next 12 months. The contracts 13 to 18 months out are left for the next quarterly review; the pack says so.'); rmChip(id, 'Only the next 12 months'); return }
      if (/what-?if|24 months|wider window/.test(t)) { say(id, 'Here is what that changes in the plan. Nothing moves until you apply it.', { kind: 'diff', key: 'fork:rc', diff: { title: 'What-if: the window is 24 months', rows: [{ k: 'add', text: '**What-if: the window is 24 months** beside step 4. The set re-read with contracts that decide 18 to 24 months out; shares steps 1 to 3.' }, { k: 'chg', text: 'Steps 5 and 6 read both and show them side by side; the pack still uses 18 months.' }], apply: 'Apply' } }); rmChip(id, 'Add a what-if: a 24-month window'); return }
      if (/(drop|remove).*(back-?test|step 4)/.test(t)) { say(id, 'Here is what dropping it costs. Nothing moves until you apply it.', { kind: 'diff', key: 'drop:n4', diff: { title: 'Drop: Test the scorecard against the renewals we lost', rows: [{ k: 'chg', text: '**Test the scorecard against the renewals we lost** removed. The pack loses its lessons section, and the case for planning the quiet contracts rests on the signs alone.' }, { k: 'caveat', text: 'Steps 5 and 6 carry "scorecard not back-tested"; it reaches the pack and the brief.' }], apply: 'Apply' } }); rmChip(id, 'Drop the back-test step'); return }
      if (/working from|sources|context/.test(t)) { say(id, 'Everything I may draw on is in the plan under **What I’m working from**. Add to it here: upload, pick a file from OneDrive or Outlook, or tell me what to leave out.'); return }
    }
    if (j.mode === 'watch') {
      if (/client lead changes|new client lead|lead changes/.test(t)) { patch(id, (x) => ({ over: { ...x.over, fires: 'Before every quarterly portfolio review, and whenever a client lead changes on a contract with 18 months or less to run.' } })); change(id, 'Also runs when a client lead changes', ['fires']); say(id, 'Added: the review also runs when a client lead changes on a contract with 18 months or less to run, so Renee is not the last to hear.'); rmChip(id, 'Also run when a client lead changes'); return }
      if (/full point|factor moves|outside the scorecard|sign/.test(t)) { patch(id, (x) => ({ answers: { ...x.answers, fires: 'early' } })); change(id, 'Also fires when a factor moves a full point or a sign appears outside the scorecard', ['fires']); say(id, 'Now also fires when a factor moves a full point, or a sign appears that the scorecard has no signal for, such as in-house operation on a council agenda. Those get a lighter note.'); rmChip(id, 'Also fire on signs outside the scorecard'); return }
      if (/as it arrives|real time|not only in the morning|every hour/.test(t)) { patch(id, (x) => ({ over: { ...x.over, where: 'The legal notices mailbox is read as each message arrives; everything else each morning at 06:00.' } })); change(id, 'Legal notices read as they arrive', ['where']); say(id, 'The legal notices mailbox is now read as each message arrives, so a demand letter reaches Legal within the hour and not the next morning. Everything else stays on the 06:00 check.'); rmChip(id, 'Read legal notices as they arrive'); return }
      if (/(drop|remove).*(option|step 4)/.test(t)) { say(id, 'Here is what dropping it costs. Nothing changes until you apply it.', { kind: 'diff', key: 'drop:w4', diff: { title: 'Drop: What to do about each contract', rows: [{ k: 'chg', text: '**What to do about each contract, including nothing** removed. The brief will state what changed and why but offer no actions, and nothing is opened in the tracker.' }], apply: 'Apply' } }); rmChip(id, 'Drop the options step'); return }
      if (/(drop|remove).*(back-?test)/.test(t)) { say(id, 'Here is what dropping it costs. Nothing changes until you apply it.', { kind: 'diff', key: 'drop:n4', diff: { title: 'Drop: Test the scorecard against the renewals we lost', rows: [{ k: 'chg', text: '**Test the scorecard against the renewals we lost** removed from every run. The pack loses its lessons section.' }], apply: 'Apply' } }); rmChip(id, 'Drop the back-test step'); return }
    }
    patch(id, (x) => ({ fixedExtra: [...x.fixedExtra, text.replace(/\.$/, '').replace(/^also fixed:\s*/i, '')] }))
    change(id, 'Added to what is taken as given', ['fixedx'])
    say(id, j.mode === 'watch' ? 'Added to the plan under what I take as given.' : 'Added to what I take as given. Anything there is never varied in a what-if; say "test it" if you want me to vary it instead.')
  }

  const agree = (id: string) => {
    const j = g(id); if (!j || j.stage !== 'plan' || j.mode !== 'once') return
    const t = hhmm()
    patch(id, (x) => ({ stage: 'running', status: 'running', agreedAt: t, agreedV: x.version, runs: [{ id: 'r1', at: `${dmy()}, ${t}`, label: x.title, status: 'running' }], chips: ['What are you doing now?'], composer: { on: true, ph: 'Ask where it is, or pause it…' } }))
    log(id, 'You', `Started the run (plan v${j.version}).`)
    ev(id, `Running · plan v${j.version} · ${t}`)
    const nd = j.deliv.filter((d) => d.on).length
    say(id, j.case === 'generic' ? `That is everything. Running the four steps now; you do not need to stay.` : `That is everything I need. Running it now, start to finish: ${j.case === 'overrun-once' ? 'five' : 'six'} steps, then I accept the findings, choose the top recommendation and build the ${nd === 1 ? 'deliverable' : `${word(nd)} deliverables`}. You do not need to stay; it lands under Executed on the left, and the workflow is on the right if you want to watch.`)
    if (j.case === 'once') runOnce(id)
    else if (j.case === 'overrun-once') runWatch(id)
    else runGeneric(id)
  }
  const armedText = (j: Journey, next: string) => {
    const n34 = CONTRACTS.filter((c) => rating(c, DESIGN.rule, 'before') >= 3).length
    const rulesOn = j.acts.filter((a) => a.on !== false)
    return `Done. **All ${CONTRACTS.length} projects have one risk score each: ${n34} rate 3 or 4.** The **contract risk dashboard, version 1**, is published. Open any project for its score, why it scores that, and a mitigation plan written for that site.\n\n**Where you open it, every time:** **Submissions** in the left menu, under “Contract risk dashboard”. It is also on this goal’s **Deliverables** tab, which is open on the right now. Both show the same dashboard.\n\nFrom now on I read every signal each morning at 06:00 and refresh the dashboard, so what you open is always the latest. The version number changes only when you change the scoring: a signal, a weight or a rule. The next check is ${next}. When a score rises I follow your ${rulesOn.length} rules: ${rulesOn.filter((a) => a.mode === 'auto').length} run by themselves, ${rulesOn.filter((a) => a.mode === 'ask').length} wait for your OK. You can change the scoring at any time on the Plan tab; that is what makes version 2.`
  }
  const arm = (id: string) => {
    const j = g(id); if (!j || j.stage !== 'plan' || j.mode !== 'watch') return
    const t = hhmm()
    const next = j.case === 'schedule' ? 'the week before the 3 February review, then every quarter' : 'tomorrow’s morning check, 06:00 on 20 November'
    patch(id, (x) => ({ stage: 'armed', status: 'armed', agreedAt: t, agreedV: x.version, armedAt: `${dmy()}, ${t}`, armedBy: 'You', nextCheck: next, composer: { on: true, ph: 'Ask about the watch, or change it between checks…' }, chips: x.case === 'schedule' ? ['Simulate: run now', 'What will it look like when it runs?'] : ['Simulate tomorrow’s morning check (20 November)', 'Change the scorecard', 'What will it look like when it fires?'] }))
    if (j.case === 'watch') { buildAll(id, 'sub-risk-scorecard'); useDesign.getState().publish(`19 Nov, ${t}`, 'First scoring', 'before'); takeNotes(); log(id, j.agent.name, 'Published the contract risk dashboard, version 1.'); window.setTimeout(() => { window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'deliverables' } })); window.setTimeout(() => document.querySelector('.hub-panel')?.scrollTo({ top: 0 }), 80) }, 50) }
    log(id, 'You', `Armed the watch (v${j.version}).`)
    log(id, j.agent.name, `Armed. First check: ${next}.`)
    ev(id, `Watch armed · v${j.version} · ${dmy()}, ${t}`)
    const nd = j.deliv.filter((d) => d.on).length
    const autoN = j.acts.filter((a) => a.mode === 'auto').length
    void autoN
    say(id, j.case === 'schedule' ? `Armed. It runs in ${next}: the six steps, the top option, the ${word(nd)} deliverables rebuilt and sent. You hear from me when it is done. Nothing runs until then.` : armedText(g(id), next))
  }

  /* ---------------- after the run: change the decision, look at the findings, make more */
  const afterRun = async (id: string, t: string): Promise<boolean> => {
    const j = g(id)
    const tab = (x: string) => window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: x } }))
    let m: RegExpMatchArray | null
    if ((m = t.match(/(?:use|choose|go with|switch to|take|pick)\s+option\s+(\d)|option\s+(\d)\s+instead/)) && j.recs.length) {
      const n = Number(m[1] ?? m[2]); const r = j.recs[n - 1]
      await typing(id, 500)
      if (!r) { say(id, `There ${j.recs.length === 1 ? 'is one option' : `are ${word(j.recs.length)} options`}.`); return true }
      choose(id, r.id); rmChip(id, `Use option ${n} instead`); return true
    }
    if (/^approve|^ok,? (do|book) it|^go ahead with/.test(t)) {
      const i = j.execActs.findIndex((a) => a.state === 'waiting'); await typing(id, 300)
      if (i < 0) say(id, 'Nothing waits for your OK.'); else approveAct(id, i, true)
      return true
    }
    if (/^(decline|leave it|don'?t book|do not book)/.test(t) && j.execActs.some((a) => a.state === 'waiting')) { await typing(id, 300); approveAct(id, j.execActs.findIndex((a) => a.state === 'waiting'), false); return true }
    if (/(show|open|see).*(finding|recommendation|options|tables)|^findings$/.test(t)) { await typing(id, 300); tab(j.mode === 'watch' && j.case !== 'schedule' ? 'runs' : 'findings'); say(id, `The findings, the tables behind them and all ${word(j.recs.length || 3)} options are on the right. Each finding says which step produced it; "Use this instead" on another option rebuilds the deliverables on it.`); rmChip(id, 'Show me the findings'); return true }
    if (/more deliverables|in submissions|another deliverable|make (a|an|more)\b.*(deck|slide|pack|memo|dashboard|letter|list|workbook|spreadsheet)/.test(t) && Object.keys(j.built).length) {
      await typing(id, 300)
      say(id, 'Opening Submissions with this run picked; choose what else to make from it there.')
      window.setTimeout(() => window.dispatchEvent(new CustomEvent('cw:more', { detail: { id } })), P(900))
      rmChip(id, 'Make more deliverables in Submissions'); return true
    }
    if (/(open|show).*(deliverable|memo|schedule|slides|note|request)|^deliverables?$/.test(t) && Object.keys(j.built).length) { await typing(id, 300); tab('deliverables'); say(id, 'On the right, under Deliverables.'); return true }
    if (/\b(shorter|rewrite|reword|tighten|edit|change the (section|summary|wording|text|title))\b/.test(t) && Object.keys(j.built).length) { await typing(id, 400); say(id, 'For wording, open the deliverable in Submissions ("Edit in Submissions" above it) and select the text to change; it stays linked to this run. For the substance, tell me here: another option, a project to take in or out, a treatment to change, and I rebuild it.'); return true }
    return false
  }

  /* ---------------- steering the run */
  const handleRun = async (id: string, text: string) => {
    const j = g(id)
    const t = text.toLowerCase()
    me(id, text)
    if (j.status === 'delivered' && await afterRun(id, t)) return
    if (/leave the evergreen|evergreen (contracts )?out|without the evergreen|stand-?in/.test(t) && j.case === 'once' && !/^why/.test(t)) { await typing(id, 500); steerDiff(id); return }
    if (/^pause/.test(t)) { pause(id, true); return }
    if (/^(resume|continue)/.test(t)) { pause(id, false); return }
    if (/accept all/.test(t) && j.findings.length) { await typing(id, 400); acceptFinding(id, 'all'); return }
    if (/^accept (finding )?(\d)/.test(t)) { const n = Number(t.match(/(\d)/)![1]); const k = j.findings[n - 1]; await typing(id, 400); if (k) acceptFinding(id, k); return }
    if (/^challenge (finding )?(\d)/.test(t)) { const n = Number(t.match(/(\d)/)![1]); const k = j.findings[n - 1]; await typing(id, 400); if (k) challenge(id, k, text.replace(/^challenge (finding )?\d:?\s*/i, '')); return }
    if (/choose|accept the recommendation|go with/.test(t) && j.recs.length) { await typing(id, 400); const n = t.match(/(\d)/); const r = n ? j.recs[Number(n[1]) - 1] : j.recs.find((x) => x.preferred); if (r) choose(id, r.id); return }
    if (/save.*plan|save this/.test(t)) { await typing(id, 400); savePlan(id); return }
    if (/standing|keep watching|every quarter/.test(t)) { await typing(id, 400); say(id, 'Standing goals are set up separately: they watch something and run on a trigger. From this plan I can start one that refreshes the renewal review **before every quarterly portfolio review**, with the same six steps. Say "make it standing" and I set it up for you to review and arm.'); chips(id, ['Make it standing']); if (/make it standing/.test(t)) makeStanding(id); return }
    if (/^make it standing/.test(t)) { makeStanding(id); return }
    if (/fork|what-?if/.test(t)) { await typing(id, 400); forkPrompt(id); return }
    if (/drop it from the goal|state it as a range/.test(t) && j.flags.genericQ) { await typing(id, 500); patch(id, (x) => ({ flags: { ...x.flags, answeredQ: true }, chips: ['Open the data', 'Save this plan'] })); log(id, 'You', `Answered: ${text}`); say(id, 'Noted and logged against the goal. There are no recorded findings for it in this copy, so the plan, the run and the position are what this goal keeps. Start from an example to see the whole journey.'); return }
    await typing(id, 600)
    if (/doing|now|status|where are you/.test(t)) {
      const run = j.nodes.filter((n) => j.ns[n.id]?.state === 'running')
      const total = j.nodes.filter((n) => !j.removed.includes(n.id) && n.type !== 'checkpoint' && !n.fork).length
      say(id, run.length ? `Running **${run.map((n) => n.title.toLowerCase()).join('** and **')}**. ${j.doneCount} of ${total} steps done${j.case === 'once' ? `; the checkpoint ${j.flags.cpAnswered ? 'is behind us' : 'is next'}` : ''}.` : j.status === 'wait' ? 'Waiting for you at the checkpoint: how the evergreen contracts are treated. Nothing runs until you answer.' : `Nothing is running. ${j.status === 'ready' || j.status === 'accepted' ? 'Findings are ready.' : 'Paused.'}`)
      rmChip(id, 'What are you doing now?'); return
    }
    if (/why.*(quiet|plan|rated 1|rated 2)/.test(t)) { say(id, 'Two of the three renewals lost since 2024 rated 2 on the scorecard a year before: well-run plants, and a client who was deciding. The quiet contracts on the list show the same signs today: a new client lead, an adviser, in-house operation on an agenda. Planning only the rated ones would have missed Calder Valley and Wren Hollow. "Why this" on the right plays the whole path.'); rmChip(id, 'Why plan the quiet ones?'); return }
    if (/open the data|show the data/.test(t)) { say(id, j.mode === 'watch' ? 'The worksheet is on the right under Data: the scorecard for all 300 contracts, each contract signal by signal, the tracked actions, documents, mail and web pages, the same rows every receipt points at.' : 'The worksheet is on the right under Data: the renewals with their end dates, ratings and client-side signs, the scorecard, documents, mail and web pages, the same rows every receipt points at.'); patch(id, () => ({})); rmChip(id, 'Open the data'); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'data' } })); return }
    if (/open the note|the note/.test(t)) { say(id, 'The run and its note are under Runs on the right; the twelve figures in the note link back to the steps there.'); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'runs' } })); rmChip(id, 'Open the note'); return }
    if (/snooze/.test(t)) { log(id, 'You', 'Snoozed the three contracts until the next check.'); say(id, 'Snoozed: I will not fire again on these three contracts until tomorrow’s check, but I read them again then and update the brief if anything changes.'); rmChip(id, 'Snooze these contracts until the next check'); return }
    if (/^why option (\d)|^why this/.test(t) && j.recs.length) { const n = t.match(/(\d)/); const r = n ? j.recs[Number(n[1]) - 1] : j.recs.find((x) => x.preferred); if (r) { say(id, `**${r.title}.** ${r.summary} The trade-off: ${r.tradeoff} "Why this" on the right plays the path, step by step.`); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: j.mode === 'watch' ? 'runs' : 'findings' } })) } rmChip(id, 'Why option 1?'); return }
    if (/change the recommendation/.test(t)) { say(id, 'Tell me what should differ: which contracts go on or off the plan list, a treatment to change, or a constraint to respect, and I re-run step 5 with it. Everything upstream stays as it is.'); return }
    if (/deck|slides|schedule|memo|note|request|draft|output|deliverable/.test(t)) { say(id, j.status === 'delivered' ? 'They are on the right under Deliverables.' : `They are built at the end of the run: ${j.deliv.filter((d) => d.on).map((d) => d.label.split(':')[0].toLowerCase()).join(', ')}.`); if (j.status === 'delivered') window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'deliverables' } })); return }
    say(id, 'Noted and logged. It does not change the plan unless you ask me to change a step, add one, or re-run one.')
    log(id, 'You', text)
  }
  const steerDiff = (id: string) => {
    const j = g(id)
    if (j.flags.steered || j.answers.four === 'standin') { say(id, 'Already done: the evergreen contracts are left out.'); return }
    if (j.ns.n2?.state !== 'done') { say(id, 'Step 2 has not finished yet; I apply it as soon as it has.'); return }
    const later = ['n3', 'n4', 'n5', 'n6'].filter((n) => j.ns[n]?.state === 'done')
    const a = rbFigures(true), b = rbFigures(false)
    say(id, 'Here is what that changes. Nothing re-runs until you apply it.', { kind: 'diff', key: 'steer', diff: { title: 'Leave the evergreen contracts out', rows: [{ k: 'chg', text: `**Step 2:** the ${word(a.ever.length)} evergreen contracts leave the set. It goes from ${a.n} to ${b.n} contracts, and the plan list from ${m1(a.rate)} to **${m1(b.rate)}** a year.` }, { k: 'rerun', text: `Step 2 re-runs (about 40 s)${later.length ? `, then ${later.length > 1 ? `steps ${later[0].slice(1)} to ${later[later.length - 1].slice(1)}, which read it` : `step ${later[0].slice(1)}, which reads it`}` : ''}. Findings 2 and 3 change.` }, { k: 'add', text: 'The treatment becomes your call and is logged as a change to the plan.' }], apply: 'Apply' } })
  }
  const applySteer = (id: string) => {
    const j = g(id)
    const later = ['n3', 'n4', 'n5', 'n6'].filter((n) => j.ns[n]?.state === 'done')
    patch(id, (x) => ({ flags: { ...x.flags, steered: true }, answers: { ...x.answers, four: 'standin' } }))
    rmChip(id, STEER)
    change(id, 'During the run: the evergreen contracts are left out', ['as:four'])
    setNode(id, 'n2', 'stale', { at: hhmm() }); later.forEach((n) => patch(id, (x) => ({ ns: { ...x.ns, [n]: { ...x.ns[n], state: 'stale', t0: undefined } } })))
    const steps = [
      { d: 8000, fn: () => { setNode(id, 'n2', 'done', { text: 'Done · re-run · 1 judgement', caveat: true, contentKey: 'n2b' }); patch(id, (x) => ({ findings: x.findings.map((k) => (k === 'F2' ? 'F2b' : k)), recs: x.recs.length ? onceRecs(x.answers) : x.recs })); ev(id, `Step 2 re-run · ${rbFigures(false).n} contracts in the set with the evergreen ones left out`); log(id, j.agent.name, 'Re-ran step 2 with your steer.'); if (later[0]) setNode(id, later[0], 'stale') } },
      ...later.map((n, k) => ({ d: 4500, fn: () => { setNode(id, n, 'done', { text: n === 'n3' ? `Done · ${m1(rbFigures(false).rate)} · re-run` : `${(g(id).ns[n]?.text ?? 'Done').replace(/ · re-run/, '')} · re-run` }); if (later[k + 1]) setNode(id, later[k + 1], 'stale') } })),
    ]
    new Seq(steps, () => {
      patch(id, (x) => ({ chips: x.chips.map((c) => (c === STEER ? 'Why option 1?' : c)) }))
      const jj = g(id)
      if (Object.keys(jj.built).length) {
        const top = jj.recs.find((r) => r.preferred) ?? jj.recs[0]
        patch(id, (x) => ({ chosen: top.id, chosenBy: 'you', over: { ...x.over, ...Object.fromEntries(x.findings.map((k) => [`acc:${k}`, x.over[`acc:${k}`] ?? 'auto'])) } }))
        buildAll(id)
        reveal(id, 500, () => {
          const v = Math.max(...Object.values(g(id).built).map((sid) => useSubmissionStore.getState().submissions.find((x) => x.id === sid)?.version ?? 1))
          const a = rbFigures(true), b = rbFigures(false)
          ev(id, `Deliverables rebuilt · version ${v} · the evergreen contracts left out`)
          say(id, `Re-ran step 2 and everything after it with your instruction. The review now covers **${b.n} contracts**, and the plan list is **${m1(b.rate)}** a year, ${m1(a.rate - b.rate)} lower, with the evergreen contracts left out. ${delivNames(g(id))} are rebuilt on it as version ${v}, and the plan records leaving them out as your call.`)
        })
        return
      }
      say(id, 'Re-ran step 2 with your instruction. Findings 2 and 3 changed, and the plan now records leaving the evergreen contracts out as your call.')
    }).next()
  }

  const pause = (id: string, force?: boolean) => {
    const j = g(id); if (!j) return
    const toPause = typeof force === 'boolean' ? force : !j.paused
    if (j.status === 'wait') { say(id, 'Already stopped: it waits for you at the checkpoint.'); return }
    if (toPause === j.paused || !seqs[id]) return
    if (toPause) { seqs[id].pause(); patch(id, (x) => ({ paused: true, prevStatus: x.status, status: 'paused', chips: ['Resume', 'What are you doing now?'] })); ev(id, `Paused by you after step ${j.doneCount}`); log(id, 'You', 'Paused the run.') }
    else { seqs[id].resume(); patch(id, (x) => ({ paused: false, status: x.prevStatus ?? 'running', chips: ['Pause after this step', 'What are you doing now?'].concat(x.flags.steerAvail && !x.flags.steered && x.answers.four === 'june' ? [STEER] : []) })); ev(id, 'Resumed'); log(id, 'You', 'Resumed the run.') }
  }

  const forkPrompt = (id: string) => {
    const j = g(id)
    if (j.ns.f1) { say(id, 'One fork at a time in this prototype; the what-if already runs beside step 4.'); return }
    say(id, '', { kind: 'forkpick' })
  }
  const applyFork = (id: string, kind: 'rc' | 't3' | 'four') => {
    const j = g(id)
    const node = ONCE_FORKS[kind]
    const cpIn = j.nodes.some((n) => n.id === 'cp')
    patch(id, (x) => ({ nodes: [...x.nodes, { ...node }], edges: [...x.edges, [cpIn ? 'cp' : 'n3', 'f1'], ['f1', 'n5']], ns: { ...x.ns, f1: { state: x.flags.cpAnswered ? 'running' : 'pending', at: hhmm() } }, forkKind: kind, flags: { ...x.flags, forked: true }, chat: x.chat.map((m) => (m.card?.kind === 'forkpick' && !m.card.done ? { ...m, card: { ...m.card, done: node.title } } : m)) }))
    change(id, `Forked a what-if: ${node.title}`, ['step:f1'])
    if (j.flags.cpAnswered && j.stage === 'running') window.setTimeout(() => { setNode(id, 'f1', 'done', { text: 'Done · side by side' }); ev(id, `${node.title} done · beside the decisions page`) }, 2200)
    else say(id, `Added **${node.title}** to the plan, beside the decisions page. It shares steps 1 to 3 and runs after the checkpoint.`)
  }

  const acceptFinding = (id: string, key: string | 'all') => {
    const j = g(id)
    const keys = key === 'all' ? j.findings : [key]
    patch(id, (x) => ({ flags: { ...x.flags }, over: { ...x.over, ...Object.fromEntries(keys.map((k) => [`acc:${k}`, '1'])) } }))
    const nums = keys.map((k) => j.findings.indexOf(k) + 1)
    register(g(id))
    log(id, 'You', `Accepted finding${nums.length > 1 ? 's' : ''} ${nums.join(', ')}.`)
    const jj = g(id)
    const all = jj.findings.every((k) => jj.over[`acc:${k}`])
    if (all) { say(id, `All ${jj.findings.length} findings accepted. Next, the decision: ${jj.recs.length} ways forward, and I prefer option ${jj.recs.findIndex((r) => r.preferred) + 1}. "Why this" plays how I got there.`, { kind: 'decision' }); chips(id, ['Choose option 1', 'Why option 1?', 'Open the data']); rmChip(id, 'Accept all findings') }
    else { const next = jj.findings.findIndex((k) => !jj.over[`acc:${k}`]) + 1; say(id, `Finding${nums.length > 1 ? 's' : ''} ${nums.join(' and ')} accepted. Next: finding ${next}, or accept the rest.`) }
  }
  const challenge = (id: string, key: string, text: string) => {
    const j = g(id); const n = j.findings.indexOf(key) + 1
    if (!text.trim()) { patch(id, (x) => ({ over: { ...x.over, challenging: key } })); say(id, `What is wrong with finding ${n}? One sentence is enough.`); return }
    log(id, 'You', `Challenged finding ${n}: ${text}`)
    patch(id, (x) => ({ over: { ...x.over, [`chal:${key}`]: text, challenging: '' } }))
    say(id, `Noted against finding ${n}. It stays open until you accept it; I recheck it on the next run and the note carries your challenge.`)
  }
  /* After the run: choosing another option rebuilds the deliverables on it. On a standing goal, what was already done stays done; the new option's actions wait for your OK. */
  const choose = (id: string, recId: string) => {
    const j = g(id)
    const r = j.recs.find((x) => x.id === recId); if (!r) return
    if (j.chosen === recId) { say(id, `Option ${recNo(j, recId)} is already the one the deliverables are built on.`); return }
    patch(id, (x) => ({ chosen: recId, chosenBy: 'you', recs: x.recs.map((o) => ({ ...o, preferred: o.id === recId })) }))
    register(g(id))
    log(id, 'You', `Chose option ${recNo(j, recId)} instead: ${r.title}`)
    ev(id, `Option ${recNo(j, recId)} chosen by you · ${hhmm()}`)
    if (!Object.keys(j.built).length) { say(id, `Recorded: option ${recNo(j, recId)}. The deliverables are built on it when the run ends.`); return }
    say(id, `Rebuilding ${delivNames(j)} on option ${recNo(j, recId)}: **${r.title}**. They come back on the right, part by part.`)
    patch(id, () => ({ typing: true }))
    window.setTimeout(() => {
      patch(id, () => ({ typing: false }))
      buildAll(id)
      reveal(id, 500, () => {
        const jj = g(id)
        const v = Math.max(...Object.values(jj.built).map((sid) => useSubmissionStore.getState().submissions.find((x) => x.id === sid)?.version ?? 1))
        ev(id, `Deliverables rebuilt · version ${v} · on option ${recNo(jj, recId)}`)
        if (j.mode === 'watch' && j.case !== 'schedule' && j.execActs.length) {
          const already = new Set(j.execActs.filter((a) => a.state === 'done' || a.state === 'approved').map((a) => a.text))
          const next = watchActionsFor(recId, j.answers.tell).filter((a) => !already.has(a.text)).map((a) => ({ ...a, state: 'waiting' as const }))
          patch(id, () => ({ execActs: [...j.execActs.filter((a) => a.state === 'done' || a.state === 'approved'), ...next] }))
          say(id, `Rebuilt as version ${v}. What option ${recNo(j, j.chosen)} already did stays done; option ${recNo(jj, recId)}'s ${next.length} action${next.length === 1 ? '' : 's'} wait${next.length === 1 ? 's' : ''} for your OK.`, { kind: 'actions' })
          return
        }
        say(id, `Rebuilt on option ${recNo(jj, recId)}, as version ${v}. The earlier version is in the log.`)
      })
    }, P(2400))
  }
  const approveAct = async (id: string, i: number, ok: boolean) => {
    const j = g(id); const a = j.execActs[i]; if (!a || a.state !== 'waiting') return
    if (ok) await typing(id, 1300)
    patch(id, (x) => ({ execActs: x.execActs.map((y, k) => (k === i ? { ...y, state: ok ? 'approved' : 'declined' } : y)) }))
    log(id, 'You', `${ok ? 'Approved' : 'Declined'}: ${a.text}.`)
    const left = g(id).execActs.filter((y) => y.state === 'waiting').length
    if (g(id).ns.w5?.state === 'done') { const ea = g(id).execActs; const nd = ea.filter((y) => y.state === 'done' || y.state === 'approved').length; setNode(id, 'w5', 'done', { text: `Done · ${nd} done${left ? `, ${left} for your OK` : ''}${ea.some((y) => y.state === 'declined') ? `, ${ea.filter((y) => y.state === 'declined').length} left` : ''}` }) }
    say(id, ok ? `Done: ${a.text.charAt(0).toLowerCase()}${a.text.slice(1)}.${left ? ` ${word(left, true)} more wait${left === 1 ? 's' : ''} for your OK.` : ' Nothing else waits for you.'}` : `Left it: ${a.text.charAt(0).toLowerCase()}${a.text.slice(1)} is not done.${left ? '' : ' Nothing else waits for you.'}`)
    if (!left) chips(id, g(id).chips.filter((c) => c !== 'Approve it'))
  }
  const execute = (id: string) => {
    const j = g(id); if (!j?.exec || j.exec.state !== 'confirm') return
    const A = j.agent.name
    patch(id, (x) => ({ status: 'executing', exec: { ...x.exec!, state: 'running', at: hhmm() }, chips: ['What are you doing now?'] }))
    ev(id, `Executing · ${j.exec.title}`)
    log(id, 'You', `Asked ${A} to execute: ${j.exec.title}.`)
    const steps = j.exec.steps.map((st, i) => ({ d: i === 0 ? 500 : 900, fn: () => {
      patch(id, (x) => ({ exec: { ...x.exec!, done: i + 1 } }))
      log(id, A, `Done: ${st}.`)
      if (i === 0) {
        const jj = g(id); const out = jj.outputs[0]
        if (out) { const sid = useSubmissionStore.getState().startFromGoal(toGoal(jj), out, 'Nishant Srivastav'); patch(id, (x) => ({ exec: { ...x.exec!, sid }, started: [...new Set([...x.started, out.id])] })) }
      }
    } }))
    seqs[id] = new Seq(steps, () => {
      const jj = g(id); const t = hhmm()
      patch(id, (x) => ({ status: 'executed', executedAt: t, exec: { ...x.exec!, state: 'done', doneText: WATCH_EXECUTE[x.exec!.rec]?.done }, runs: x.runs.map((r) => ({ ...r, status: 'executed' as const })), chips: ['Open the draft in Submissions', 'Save this plan'] }))
      register(g(id))
      ev(id, `Executed · ${t} · moved to Executed`)
      notify(g(id), 'executed', `Executed: ${jj.exec!.title}`, `${A} did all ${jj.exec!.steps.length} steps on the three contracts. The goal is under Executed; the watch stays armed for the next check.`, { found: WATCH_EXECUTE[jj.exec!.rec]?.done, cta: 'Open the goal' })
      say(id, `Executed. ${WATCH_EXECUTE[jj.exec!.rec]?.done ?? ''} The brief is also in Submissions as a draft you can finish.\n\nThis run is now under **Executed** on the left. The watch itself stays armed under Standing goals and checks again tomorrow at 06:00.`)
    })
    seqs[id].next()
  }
  const notNow = (id: string) => {
    const j = g(id); if (!j?.exec || j.exec.state !== 'confirm') return
    say(id, 'Left it there. The choice is recorded; nothing is executed. Say execute when you are ready, or choose another option.')
    chips(id, ['Execute', 'Open the data'])
  }
  const savePlan = (id: string, name?: string) => {
    const j = g(id)
    if (j.flags.saved) { say(id, 'Already saved; it is on the left under Saved plans.'); return }
    const nm = name ?? (j.case === 'once' ? 'Renewals: likelihood, client side, what is at stake' : j.case === 'watch' || j.case === 'overrun-once' ? 'Contract risk: what changed, why, what to do' : j.title)
    set({ saved: [{ id: `ap-${slug(nm)}-${Date.now().toString(36)}`, name: nm, mode: j.mode, kind: j.kind, prompt: j.prompt, files: j.files.filter((f) => f.id !== 'up'), steps: j.nodes.filter((n) => !j.removed.includes(n.id) && n.type !== 'checkpoint' && !n.fork).map((n) => n.title), from: j.title, by: 'You', at: `${dmy()} 2026`, case: j.case }, ...get().saved] })
    patch(id, (x) => ({ flags: { ...x.flags, saved: true } }))
    log(id, 'You', `Saved the plan as “${nm}”.`)
    say(id, `Saved as **“${nm}”**, on the left under Saved plans. A new goal can start from it.`)
    rmChip(id, 'Save this plan')
  }
  const makeStanding = (id: string) => {
    const j = g(id)
    set({ start: { mode: 'watch', prompt: 'Before every quarterly portfolio review, refresh the renewal risk review: the contracts that decide in the next 18 months, their rating, the client side, what is at stake, and update the pack.', files: ONCE_FILES, web: j.web, approachId: 'schedule' } })
    say(id, 'Set up on the start screen under Keep watching, with the same plan. Review it and arm it.')
    set({ current: null })
    rmChip(id, 'Make it standing')
  }
  const fire = (id: string) => {
    const j = g(id); if (!j || j.status !== 'armed') return
    const t = hhmm()
    if (j.case === 'schedule') {
      patch(id, (x) => ({ status: 'fired', runs: [...x.runs, { id: `r${x.runs.length + 1}`, at: `${dmy()}, ${t}`, label: 'Scheduled run · before the 3 February review', status: 'running' }], ns: Object.fromEntries(x.nodes.map((n) => [n.id, { state: 'pending' as NodeRun }])), findings: [], recs: [], chosen: undefined, chosenBy: undefined, execActs: [], over: Object.fromEntries(Object.entries(x.over).filter(([k]) => !/^(acc|chal):/.test(k))), chips: ['What are you doing now?'], answers: { ...x.answers, four: x.answers.four ?? 'june', t3: x.answers.t3 ?? 'out' }, flags: { ...x.flags, cpAnswered: true } }))
      log(id, 'Schedule', `Scheduled run started · ${dmy()}, ${t}.`)
      ev(id, `${dmy()} · scheduled run · the plan runs by itself`)
      say(id, '**Running.** The scheduled run has started; the six steps run by themselves and the pack is refreshed at the end. You do not need to be here for this.')
      runOnce(id)
      return
    }
    applyNight()
    patch(id, (x) => ({ status: 'fired', runs: [...x.runs, { id: `r${x.runs.length + 1}`, at: '20 Nov, 06:04', label: `Morning check, 20 November · ${watchStory().short}`, status: 'running' }], ns: Object.fromEntries(x.nodes.map((n) => [n.id, { state: 'pending' as NodeRun }])), findings: [], recs: [], chosen: undefined, chosenBy: undefined, exec: undefined, execActs: [], over: Object.fromEntries(Object.entries(x.over).filter(([k]) => !/^(acc|chal):/.test(k))), chips: ['What are you doing now?'] }))
    log(id, 'Rule', `Fired at the 06:00 check of 20 November: ${watchStory().mv.length} of ${CONTRACTS.length} contracts changed; ${watchStory().head}.`)
    ev(id, `20 Nov · 06:00 check · ${CONTRACTS.length} contracts · rule fired · ${watchStory().mv.length} changed, ${watchStory().up.length} moved up a rating`)
    notify(g(id), 'fired', `Contract risk: ${watchStory().head}`, `${j.agent.name} is handling it now: why, what is at stake, the plan for each site, and what your rules say to do. You hear back when it is done.`, { found: 'A demand letter in the legal notices mailbox, a council agenda on the web and a missed sample in the lab data.', cta: 'Watch it run' })
    say(id, `**Fired.** Since yesterday’s check three things arrived: a demand letter in the legal notices mailbox, a council agenda on the web, and a missed sample in the lab data. ${watchStory().line} Running the five steps now; then I do what your rules say and tell you.`)
    runWatch(id)
  }

  /* ---------------- a live goal is changed in the chat: understand it, draft it, show what it does to the scores, publish it as a new version */
  const changeExamples = () => { const w = DESIGN.fw.li ?? 35, to = Math.max(1, Math.round(w * 0.7)); return [
    'Add a signal for boil water notices in the last twelve months, under Water Quality and Contaminants, and make it a red flag',
    'Change days sales outstanding: score 4 from 75 days',
    'Add a factor for energy cost, with a signal for power cost against budget',
    `Make Legal Action count for ${to} instead of ${w}`,
  ] }
  const ALIAS: [RegExp, string][] = [[/\bdso\b/i, 'cr2'], [/overtime/i, 'st4'], [/odou?r/i, 'co1'], [/negative (media|press|coverage)|media coverage|press coverage/i, 'co2'], [/safety observation/i, 'os3'], [/retention|staff turnover/i, 'st3'], [/\bnps\b|survey score/i, 'cu1'], [/sewer overflow|\bsso\b|\bcso\b/i, 'en5'], [/planned maintenance/i, 'in4'], [/asset age/i, 'in7'], [/open positions?|vacanc/i, 'st1'], [/consent order/i, 'li2'], [/in.?house|re.?bid/i, 'cp3'], [/missed samples?/i, 'en2'], [/notices? of violation/i, 'en3']]
  /** The signal or factor a sentence names, if any. */
  const mention = <T extends { name: string }>(list: T[], text: string): T | null => {
    const n = ` ${norm(text)} `; let best: T | null = null, top = 0
    for (const x of list) {
      const nn = norm(x.name); if (!nn) continue
      if (n.includes(` ${nn} `)) { const sc = 2 + nn.length / 100; if (sc > top) { top = sc; best = x } continue }
      const ws = nn.split(' ').filter((w) => w.length > 2); if (ws.length < 2) continue
      const hit = ws.filter((w) => n.includes(` ${w}`)).length / ws.length
      if (hit >= 0.75 && hit + ws.length / 100 > top) { top = hit + ws.length / 100; best = x }
    }
    return best
  }
  const sigIn = (text: string) => { const live = SIGNALS.filter((x) => inTemplate(x) || DESIGN.custom.includes(x.id)); const a = ALIAS.find(([re]) => re.test(text)); return (a && live.find((x) => x.id === a[1])) || mention(live, text) }
  const facIn = (text: string) => mention(FACTORS.filter((x) => x.group !== 'impact'), text)
  /** What one signal scores for one project on the scoring as it stands. */
  const rating1 = (c: (typeof CONTRACTS)[number], sid: string) => valOf(c, sid, 'before') ?? c.v[sid]?.r ?? 1
  const clean = (x: string) => x.trim().replace(/^["“'`]+|["”'`]+$/g, '').replace(/[\s,;:.]+$/, '').trim()
  const pct = (x: number) => `${(x * 100).toFixed(1)}%`
  interface Change { said: string; run: () => { k: 'add' | 'chg'; line: string; data: [string, string]; focus?: string } }
  const parseChange = (text: string): Change | string | null => {
    const t = text.trim().replace(/[.!]+$/, ''), low = t.toLowerCase()
    let m: RegExpMatchArray | null
    /* a new factor, with a first signal if one is named */
    if (/\b(add|create|include|introduce|bring in|i want|we need)\b.*\bfactor\b/i.test(t) && (m = t.match(/\bfactor\s*(?:for|called|named|on|:)?\s*(.+)$/i))) {
      let rest = m[1], sigName = ''
      const wm = rest.match(/^(.*?)[,;]?\s+(?:with|and)\s+(?:a |one |the |its first )?(?:new )?signal\s*(?:for|called|named|on|:)?\s*(.+)$/i)
      if (wm) { rest = wm[1]; sigName = clean(wm[2]) }
      const gm = rest.match(/^(.*?)\s+(?:under|in|to)\s+(what we do not control|what we don.?t control|what we control|the external (?:half|factors)|the internal (?:half|factors))$/i)
      if (gm) rest = gm[1]
      const name = clean(rest); if (name.length < 3) return 'Give the factor a name, for example “add a factor for energy cost”.'
      const ext = gm ? /not|don|external/i.test(gm[2]) : /market|price of|weather|regulat|econom|climate|politic|competitor|state law|legislat/i.test(name)
      return {
        said: `A new factor, “${name}”, under ${ext ? 'what we do not control' : 'what we control'}${sigName ? `, with a first signal: “${sigName}”` : ''}`,
        run: () => {
          const f = design.factor(ext ? 'external' : 'internal', name)
          const sg = sigName ? design.custom(sigName, f.id) : null
          return { k: 'add', line: `New factor **${f.name}** under ${ext ? 'what we do not control' : 'what we control'}, at a weight of 10 (${pct(finalShare(f.id))} of the final score).${sg ? ` Its first signal is **${sg.name}**, with a rule for 1 to 4 that I proposed.` : ' It counts once it has a signal.'}`, data: sg ? ['look for the data in what is connected', `${sg.src.name}: found for all ${CONTRACTS.length} projects. ${CONTRACTS.filter((c) => (c.v[sg.id]?.r ?? 1) >= 3).length} score 3 or 4 on it`] : ['look for the data in what is connected', 'No signal yet, so nothing to read. Add one and I look for its data'], focus: `[data-factor="${f.id}"]` }
        },
      }
    }
    /* a new signal */
    if ((/\b(add|include|introduce|bring in|i want|we need)\b.*\bsignal\b/i.test(t) || /^(?:please |also |and |let us |let's |i want to |can you )*(?:start )?(?:track|tracking|measure|measuring)\b/i.test(t)) && (m = t.match(/\bsignal\s*(?:for|called|named|on|:)?\s*(.+)$/i) ?? t.match(/\b(?:track|tracking|measure|measuring)\s+(.+)$/i))) {
      let rest = m[1], bands: string[] | undefined
      const fm = rest.match(/[,;]?\s*(?:and\s+)?(?:make|treat|set|flag|mark)\s+(?:it|this|that)(?:\s+as)?\s+a\s+red\s+flag\s*$/i), flag = !!fm
      if (fm) rest = rest.slice(0, fm.index)
      const bm = [...rest.matchAll(/\b([1-4])\s*(?:=|:|is|when|if)\s*([^;,]+)/gi)]
      if (bm.length >= 2) { bands = ['', '', '', '']; for (const x of bm) bands[Number(x[1]) - 1] = x[2].trim(); rest = rest.slice(0, bm[0].index).replace(/[\s,;:]+(?:scored?|scoring|with|rule)?[\s,;:]*$/i, '') }
      let f: (typeof FACTORS)[number] | null = null
      const parts = [...rest.matchAll(/[,;]?\s+(?:under|to|into|in|within)\s+(?:the factor |factor |the )?/gi)]
      for (let i = parts.length - 1; i >= 0 && !f; i -= 1) { const tail = rest.slice(parts[i].index! + parts[i][0].length); const ff = pick(FACTORS.filter((x) => x.group !== 'impact'), tail); if (ff) { f = ff; rest = rest.slice(0, parts[i].index) } }
      const name = clean(rest); if (name.length < 4) return 'Say what the signal measures, for example “add a signal for boil water notices in the last twelve months”.'
      const dup = SIGNALS.find((x) => norm(x.name) === norm(name) && DESIGN.on[x.id]); if (dup) return `**${dup.name}** is already on the scorecard, in ${FACTORS.find((x) => x.id === dup.f)!.name}. Tell me what to change about it.`
      return {
        said: `A new signal, “${name}”${f ? `, in ${f.name}` : ', in the factor where it fits best'}${bands ? ', scored on the rule you gave' : ''}${flag ? ', as a red flag' : ''}`,
        run: () => {
          const sg = design.custom(name, f?.id, bands), ff = FACTORS.find((x) => x.id === sg.f)!
          if (flag) design.flag(sg.id)
          const has = CONTRACTS.filter((c) => c.v[sg.id]), n34 = has.filter((c) => c.v[sg.id].r >= 3).length, n4 = has.filter((c) => c.v[sg.id].r >= 4).length
          const who = sg.only === 'dw' ? `the ${has.length} projects that treat drinking water` : sg.only === 'ww' ? `the ${has.length} projects that treat wastewater` : `all ${has.length} projects`
          return { k: 'add', line: `New signal **${sg.name}** in ${ff.name}. Rule: 1 = ${sg.bands[0].toLowerCase()}; 2 = ${sg.bands[1].toLowerCase()}; 3 = ${sg.bands[2].toLowerCase()}; 4 = ${sg.bands[3].toLowerCase()}${bands ? '' : ' (my proposal; change it on the Plan tab)'}.${flag ? ' It is a **red flag**: at its worst case the project rates at least 3.' : ''}`, data: ['look for the data in what is connected', `${sg.src.name}: found for ${who}. ${n34} score 3 or 4 on it${flag ? `, ${n4} at its worst case` : ''}`], focus: `.sdz-sig[data-signal="${sg.id}"]` }
        },
      }
    }
    const fac = facIn(t), sig = sigIn(t)
    /* the weight of a factor */
    if (fac && /\b(weigh|weight|count|counts|matter|matters|important|importance)\b/i.test(t)) {
      const was = DESIGN.fw[fac.id] ?? fac.weight
      const nums = [...low.replace(norm(fac.name), ' ').matchAll(/\d+(?:\.\d+)?/g)].map((x) => Number(x[0]))
      const toM = low.match(/\bto (\d+(?:\.\d+)?)/)
      const to = /\bdouble\b/.test(low) ? was * 2 : /\bhal(f|ve)\b/.test(low) ? was / 2 : toM ? Number(toM[1]) : nums.length ? nums[0] : /\b(less|lower|reduce|down)\b/.test(low) ? was - 5 : /\b(more|higher|raise|increase|up)\b/.test(low) ? was + 5 : NaN
      if (!Number.isFinite(to) || to < 0 || to > 60) return `Tell me the new weight of ${fac.name}, between 0 and 60. It counts for ${was} now.`
      if (to === was) return `${fac.name} already counts for ${was}.`
      const s0 = finalShare(fac.id)
      return { said: `${fac.name} should count for ${to} instead of ${was}`, run: () => { design.factorWeightTo(fac.id, to); return { k: 'chg', line: `**${fac.name}** counts for ${to} (was ${was}). Its share of the final score goes from ${pct(s0)} to ${pct(finalShare(fac.id))}; the other factors in its half share the rest.`, data: ['check that the weights still add up', `The ${activeFactors().filter((x) => x.group === fac.group).length} factors in its half add to 100% again`], focus: `[data-factor="${fac.id}"]` } } }
    }
    /* a red flag */
    if (sig && /red flag/i.test(t)) {
      const off = /\b(remove|drop|no longer|not a|stop|take off|unflag)\b/i.test(t), has = !!DESIGN.flag[sig.id]
      if (off !== has) return `**${sig.name}** is ${has ? 'already' : 'not'} a red flag.`
      return { said: `${off ? 'Take the red flag off' : 'Make'} “${sig.name}”${off ? '' : ' a red flag'}`, run: () => { design.flag(sig.id); return { k: 'chg', line: off ? `**${sig.name}** is no longer a red flag. It still counts in its factor.` : `**${sig.name}** is a red flag: at its worst case the project rates at least 3, whatever the rest says.`, data: ['find the projects it touches', `${CONTRACTS.filter((c) => (c.v[sig.id]?.r ?? 1) >= 4).length} projects are at its worst case today`], focus: `.sdz-sig[data-signal="${sig.id}"]` } } }
    }
    /* thresholds from history */
    if (sig && /\bhistor/i.test(t)) {
      if (!sig.num) return `**${sig.name}** is not scored on a figure, so there is no history to cut. Tell me the wording for 1 to 4 instead.`
      if (REG_RULE.has(sig.id)) return `**${sig.name}** follows a regulatory or permit limit, so I leave it as written.`
      const h = histOf(sig, true); if (!h) return null
      return { said: `Take the thresholds of “${sig.name}” from three years of history`, run: () => { design.hist(sig.id); return { k: 'chg', line: `**${sig.name}**: thresholds from history, ${h.rec.join(', ')} ${h.unit} (were ${h.cur.join(', ')}). The better half scores 1, the next 30% score 2, the next 15% score 3 and the worst 5% score 4.`, data: [`read three years of history for ${sig.name.toLowerCase()}`, `${h.n} projects, from ${h.lo} to ${h.hi} ${h.unit}; half are at ${h.median} or ${h.up ? 'lower' : 'higher'}`], focus: `.sdz-sig[data-signal="${sig.id}"]` } } }
    }
    /* when a signal scores 1 to 4 */
    if (sig && /\b(scores?|scoring|thresholds?|cut|rule|starts?|begins?)\b/i.test(t) && /\d/.test(t) && !/^(drop|remove|delete)\b/i.test(t)) {
      if (!sig.num) return `**${sig.name}** is scored on wording, not on a figure. Open it on the Plan tab and rewrite the case for 1, 2, 3 or 4.`
      if (REG_RULE.has(sig.id)) return `**${sig.name}** follows a regulatory or permit limit, so I leave it as written.`
      const cur = (DESIGN.cuts[sig.id] ?? sig.num.cuts).slice(), next = cur.slice(), body = low.replace(norm(sig.name), ' ')
      const km = [...body.matchAll(/\b(?:scores?|a|rating|is)?\s*([1-4])\s+(?:from|at|above|over|under|below|starts? at|begins? at|when (?:over|above|under|below|at)|if (?:over|above|under|below))\s*(-?\d+(?:\.\d+)?)/g)]
      const three = body.match(/(-?\d+(?:\.\d+)?)\s*(?:,|and|\/)\s*(-?\d+(?:\.\d+)?)\s*(?:,|and|\/|, and)\s*(-?\d+(?:\.\d+)?)/)
      if (km.length) for (const x of km) { const k = Number(x[1]); next[k === 1 ? 0 : k - 2] = Number(x[2]) }
      else if (three) { next[0] = Number(three[1]); next[1] = Number(three[2]); next[2] = Number(three[3]) }
      else return `Tell me where a score starts, for example “${sig.name.toLowerCase()}: score 4 from ${cur[2]}”, or give all three thresholds.`
      const up = sig.num.dir === 'up'
      if (!(up ? next[0] < next[1] && next[1] < next[2] : next[0] > next[1] && next[1] > next[2])) return `Those thresholds are out of order: ${next.join(', ')} ${sig.num.unit}. They are ${cur.join(', ')} now. Give me a set that ${up ? 'rises' : 'falls'} from 2 to 4.`
      if (next.every((v, i) => v === cur[i])) return `**${sig.name}** already cuts at ${cur.join(', ')} ${sig.num.unit}.`
      const before = [1, 2, 3, 4].map((r) => CONTRACTS.filter((c) => Math.round(rating1(c, sig.id)) === r).length)
      return {
        said: `“${sig.name}” should cut at ${next.join(', ')} instead of ${cur.join(', ')} (${sig.num.unit})`,
        run: () => {
          design.cutsTo(sig.id, next); const b = bandsOf(sig), after = [1, 2, 3, 4].map((r) => CONTRACTS.filter((c) => Math.round(rating1(c, sig.id)) === r).length)
          return { k: 'chg', line: `**${sig.name}**: 1 = ${b[0].toLowerCase()}; 2 = ${b[1].toLowerCase()}; 3 = ${b[2].toLowerCase()}; 4 = ${b[3].toLowerCase()}. The thresholds were ${cur.join(', ')} (${sig.num!.unit}).`, data: [`score ${sig.name.toLowerCase()} again for every project`, `Projects at 1 / 2 / 3 / 4 on it: ${after.join(' / ')} (were ${before.join(' / ')})`], focus: `.sdz-sig[data-signal="${sig.id}"]` }
        },
      }
    }
    /* drop or put back */
    if ((m = t.match(/^(?:please |and |also |let us |let's )*(drop|remove|delete|take out|leave out|stop (?:scoring|using|tracking|counting)|put back|restore|bring back)\s+(.+)$/i))) {
      const on = /put back|restore|bring back/i.test(m[1]), q = m[2], wantF = /\bfactor\b/i.test(q)
      const sg = wantF ? null : pick(SIGNALS, q) ?? sigIn(q), fc = sg ? null : pick(FACTORS.filter((x) => x.group !== 'impact'), q) ?? facIn(q)
      if (sg) {
        if (NOT_FOUND[sg.id]) return `**${sg.name}** has no source in the connected data, so it is not in use.`
        if (!!DESIGN.on[sg.id] === on) return `**${sg.name}** is ${on ? 'already on the scorecard' : 'not on the scorecard'}.`
        const ff = FACTORS.find((x) => x.id === sg.f)!
        return { said: `${on ? 'Put' : 'Take'} “${sg.name}” ${on ? 'back on' : 'off'} the scorecard`, run: () => { design.on(sg.id, on); return { k: 'chg', line: on ? `**${sg.name}** is back in ${ff.name}.` : `**${sg.name}** is dropped from ${ff.name}. The other signals of the factor share its weight.`, data: ['check what else depends on it', DESIGN.flag[sg.id] && !on ? 'It was a red flag; the flag goes with it' : `No red flag and no rule of the watch depends on it. ${ff.name} keeps ${SIGNALS.filter((x) => x.f === ff.id && DESIGN.on[x.id]).length} signals`], focus: `[data-factor="${ff.id}"]` } } }
      }
      if (fc) {
        const ids = SIGNALS.filter((x) => x.f === fc.id && !NOT_FOUND[x.id] && (inTemplate(x) || DESIGN.custom.includes(x.id))).map((x) => x.id); if (!ids.length) return null
        return { said: `${on ? 'Put' : 'Take'} the factor “${fc.name}” ${on ? 'back on' : 'off'} the scorecard, with its ${ids.length} signals`, run: () => { design.onMany(ids, on); return { k: 'chg', line: on ? `The factor **${fc.name}** is back, with its ${ids.length} signals.` : `The factor **${fc.name}** is dropped, with its ${ids.length} signals. The other factors in its half share its weight.`, data: ['check what else depends on it', `${ids.filter((x) => DESIGN.flag[x]).length} of its signals are red flags`], focus: `[data-group="${fc.group}"]` } } }
      }
      return null
    }
    /* how the two halves combine */
    if (/higher of the two|worse of the two|the worse half|maximum of the two/i.test(t)) { if (DESIGN.rule === 'max') return 'The score already takes the higher of the two halves.'; return { said: 'The project score should take the higher of the two halves, not their average', run: () => { design.rule('max' as Rule); return { k: 'chg', line: 'The project score takes **the higher of the two halves** (was their average).', data: ['check that every project still has both halves', `All ${CONTRACTS.length} do`] } } } }
    if (/average of the two/i.test(t)) { if (DESIGN.rule === 'avg') return 'The score already takes the average of the two halves.'; return { said: 'The project score should take the average of the two halves', run: () => { design.rule('avg' as Rule); return { k: 'chg', line: 'The project score takes **the average of the two halves** (was the higher of the two).', data: ['check that every project still has both halves', `All ${CONTRACTS.length} do`] } } } }
    return null
  }
  const foldChanges = (id: string, done: string) => patch(id, (x) => ({ chat: x.chat.map((mm) => (mm.card?.kind === 'change' && !mm.card.done ? { ...mm, card: { ...mm.card, done } } : mm)) }))
  const liveChips = (j: Journey) => [...(j.status === 'armed' ? ['Simulate tomorrow’s morning check (20 November)'] : ['Show me the findings']), 'Change the scorecard']
  const changeFlow = async (id: string, text: string, ch: Change) => {
    me(id, text)
    const v = useDesign.getState().versions.length
    foldChanges(id, 'Carried into the change plan below')
    patch(id, () => ({ changing: true, chips: [] }))
    await typing(id, 450)
    const card = stepsCard(id, `On it. Version ${v} stays live while I work; nothing on the dashboard changes until you publish.`)
    card.start('understand the change'); await wait(1200); card.end(ch.said); await wait(300)
    card.start('apply it to a draft of the scorecard'); await wait(1300)
    const n0 = peekNotes().length
    const r = ch.run()
    const own = peekNotes().slice(n0)
    card.end(`${activeFactors().length} factors and ${likelihoodSignals().length} signals in the draft`)
    window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'plan' } }))
    if (r.focus) window.setTimeout(() => document.querySelector(r.focus!)?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 260)
    await wait(300)
    card.start(r.data[0]); await wait(1400); card.end(r.data[1]); await wait(300)
    const e = changeEffect()
    card.start(`score all ${CONTRACTS.length} projects on the draft`); await wait(1700); card.end(e ? `Ratings 1 / 2 / 3 / 4: ${e.dist[1].slice(1).join(' / ')} (version ${v}: ${e.dist[0].slice(1).join(' / ')})` : distText()); await wait(300)
    card.start(`compare with version ${v}`); await wait(1300); card.end(e ? `${e.scoresMoved} scores move, by ${Math.abs(e.largest).toFixed(2)} at most. ${e.up.length + e.down.length} ${e.up.length + e.down.length === 1 ? 'project changes' : 'projects change'} rating: ${e.up.length} up, ${e.down.length} down` : 'Compared'); await wait(300)
    card.start('write the mitigation plans again where they change'); await wait(1200); card.end(e ? `${e.plans} ${e.plans === 1 ? 'site' : 'sites'}` : 'Done'); await wait(300)
    card.settle(); await wait(450)
    patch(id, (x) => ({ changes: [...(x.changes ?? []), { k: r.k, text: r.line, asked: text, own }], changing: false, log: [...x.log, { t: hhmm(), who: 'You', what: `Asked for a change to the scoring: ${text}` }] }))
    say(id, `Here is the change plan for **version ${v + 1}**. It is a draft: the scorecard on the right shows it, the dashboard still shows version ${v}. Publish it, tell me what else to change, or discard it.`, { kind: 'change', key: String(v + 1) })
    chips(id, [`Publish version ${v + 1}`, 'Discard the change', ...changeExamples().filter((x) => !(g(id).changes ?? []).some((c) => c.asked === x)).slice(0, 1)])
  }
  const publishFlow = async (id: string) => {
    const j = g(id); if (!j || j.case !== 'watch' || !j.built['sub-risk-scorecard'] || j.changing) return
    const v = useDesign.getState().versions.length
    if (!unpublished()) { say(id, `Nothing to publish: the scoring is as in version ${v}.`); return }
    const e = changeEffect(), fired = j.runs.length > 0, w = fired ? 'after' : 'before'
    foldChanges(id, `Published as version ${v + 1}`)
    patch(id, () => ({ changing: true, chips: [] }))
    const nR = CONTRACTS.length * SIGNALS.filter((x) => DESIGN.on[x.id]).length
    const sites = CONTRACTS.filter((c) => planFor(c, w).some((x) => !x.fixed && !x.later)).length
    const card = stepsCard(id, `Publishing version ${v + 1}.`)
    for (const [tool, res] of [
      [`score all ${CONTRACTS.length} projects on the new scoring`, `${nR.toLocaleString('en-US')} readings. ${e ? `Ratings 1 / 2 / 3 / 4: ${e.dist[1].slice(1).join(' / ')}` : distText()}`],
      ['write the mitigation plans again', `${e ? `${e.plans} changed. ` : ''}${sites} sites have a plan`],
      ['build the dashboard', `${PANELS.filter((x) => DESIGN.panels[x.k]).length} views · published as version ${v + 1}`],
      ['update Submissions', `The dashboard there is version ${v + 1}; version ${v} stays in its list`],
    ] as [string, string][]) { card.start(tool); await wait(1100); card.end(res); await wait(250) }
    card.settle(); await wait(300)
    const notes = takeNotes(), why = notes.length ? `Scoring changed: ${notes.slice(0, 3).join('; ')}${notes.length > 3 ? `; and ${notes.length - 3} more` : ''}` : 'Scoring changed'
    buildAll(id, 'sub-risk-scorecard')
    const ver = useDesign.getState().publish(fired ? '20 Nov, 09:12' : `19 Nov, ${hhmm()}`, why, w)
    patch(id, (x) => ({ version: x.version + 1, history: [...x.history, { t: `${dmy()}, ${hhmm()}`, what: why }], changes: [], changing: false, published: [...(x.published ?? []), { v: ver.v, at: ver.at, why, changes: (x.changes ?? []).map((c) => c.text), effect: e ? { ratings_before: e.dist[0].slice(1), ratings_after: e.dist[1].slice(1), scores_moved: e.scoresMoved, up: e.up.map((u) => `${u.site} ${u.from} to ${u.to}`), down: e.down.map((u) => `${u.site} ${u.from} to ${u.to}`), plans_changed: e.plans } : null }] }))
    log(id, 'You', `${why}. Dashboard published as version ${ver.v}.`)
    ev(id, `Scoring changed · dashboard version ${ver.v} published`)
    const moved = e ? (e.up.length + e.down.length ? ` Against version ${v}, ${e.up.length} ${e.up.length === 1 ? 'project moves' : 'projects move'} up a rating and ${e.down.length} down.` : ` No project changes rating against version ${v}; ${e.scoresMoved} scores move.`) : ''
    say(id, `Published. **Version ${ver.v} of the dashboard** scores all ${CONTRACTS.length} projects on the scoring as it stands now: ${ver.snap.n34} rate 3 or 4.${moved} ${why}.\n\nNobody is alerted: these scores moved because the scoring changed, not because something happened at a site. Open the dashboard in Submissions or on the Deliverables tab; version ${v} stays in its version list. The next morning check uses this scoring.`)
    chips(id, liveChips(g(id)))
    window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'deliverables' } }))
    window.setTimeout(() => { document.querySelector('.hub-panel')?.scrollTo({ top: 0, behavior: 'smooth' }); document.querySelector('[data-testid="dash-deliv"]')?.scrollIntoView({ block: 'start', behavior: 'smooth' }) }, 320)
  }
  const discardFlow = (id: string) => {
    const j = g(id); if (!j || j.changing) return
    const v = useDesign.getState().versions.length
    if (!unpublished()) { say(id, 'There is no open change to discard.'); return }
    design.discard(); foldChanges(id, 'Discarded')
    patch(id, (x) => ({ changes: [], log: [...x.log, { t: hhmm(), who: 'You', what: 'Discarded the draft change to the scoring.' }] }))
    say(id, `Discarded. The scorecard is back as in version ${v}: ${activeFactors().length} factors and ${likelihoodSignals().length} signals. The dashboard did not change.`)
    chips(id, liveChips(g(id)))
  }
  /** A message on a live contract risk goal that asks to change the scoring. */
  const changeCmd = (id: string, text: string): boolean => {
    const j = g(id); if (!j || j.case !== 'watch' || j.stage !== 'armed' || !j.built['sub-risk-scorecard']) return false
    const t = text.trim(), v = useDesign.getState().versions.length
    if (j.changing) { if (/\b(add|change|drop|remove|publish|discard|signal|factor|weight)\b/i.test(t)) { me(id, text); say(id, 'One moment: I am still working on the last change. Say it again when the change plan is in the chat.'); return true } return false }
    if (/^publish\b|^go ahead\b|^yes,? publish/i.test(t)) { me(id, text); void publishFlow(id); return true }
    if (/^(discard|undo|cancel|forget|drop) (the |this |that |my )?(change|changes|draft)\b|^never mind/i.test(t)) { me(id, text); discardFlow(id); return true }
    if (/^change the scorecard$|^change the scoring$|\b(how|can|could) (do |can )?(i|we|you) (change|edit|update)\b.*\b(scorecard|scoring|signal|factor|rule|weight)/i.test(t)) {
      me(id, text)
      window.setTimeout(() => { say(id, `Yes. Tell me in your own words what to change: add a signal or a factor, change where a signal scores 1 to 4, change how much a factor counts, drop something, or set a red flag. I draft it, show you what it does to the scores of all ${CONTRACTS.length} projects, and publish it as **version ${v + 1}** of the dashboard only when you say so. For example:`); chips(id, changeExamples()) }, P(350))
      return true
    }
    const ch = parseChange(t)
    if (ch && typeof ch !== 'string') { void changeFlow(id, text, ch); return true }
    if (typeof ch === 'string') { me(id, text); window.setTimeout(() => say(id, ch), P(350)); return true }
    if (/\b(signal|factor|weight|threshold|scorecard|scoring|red flag)\b/i.test(t) && /\b(add|change|drop|remove|set|make|use|tighten|loosen|raise|lower|increase|decrease|include|track|update|edit)\b/i.test(t)) {
      me(id, text)
      window.setTimeout(() => { say(id, 'I did not catch what to change. Say it like one of these, in your own words:'); chips(id, changeExamples()) }, P(350))
      return true
    }
    return false
  }

  const handleArmed = async (id: string, text: string) => {
    const j = g(id)
    const t = text.toLowerCase()
    me(id, text)
    if (j.status === 'executed' && await afterRun(id, t)) return
    if (/simulate|morning check|tomorrow|tonight|run now/.test(t)) { if (j.status === 'armed') { await typing(id, 400); fire(id) } else say(id, 'It has already fired; the run is under Runs.'); return }
    if (/^execute/.test(t)) { if (j.exec?.state === 'confirm') { await typing(id, 300); execute(id) } else say(id, j.exec?.state === 'done' ? 'Already executed; it is under Executed.' : 'Choose a recommendation first; then I can execute it.'); return }
    if (/^not now/.test(t)) { notNow(id); return }
    if (/open the draft/.test(t)) { say(id, j.exec?.sid ? 'The draft is open in Submissions.' : 'No draft yet.'); if (j.exec?.sid) window.dispatchEvent(new CustomEvent('cw:open-sub', { detail: { sid: j.exec.sid } })); rmChip(id, 'Open the draft in Submissions'); return }
    if (/^why option (\d)|^why this/.test(t) && j.recs.length) { const n = t.match(/(\d)/); const r = n ? j.recs[Number(n[1]) - 1] : j.recs.find((x) => x.preferred); if (r) { say(id, `**${r.title}.** ${r.summary} The trade-off: ${r.tradeoff} "Why this" on the right plays the path, step by step.`); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'runs' } })) } rmChip(id, 'Why option 1?'); return }
    if (/accept all/.test(t) && j.findings.length) { await typing(id, 400); acceptFinding(id, 'all'); return }
    if (/^accept (finding )?(\d)/.test(t)) { const n = Number(t.match(/(\d)/)![1]); const k = j.findings[n - 1]; await typing(id, 400); if (k) acceptFinding(id, k); return }
    if (/^challenge (finding )?(\d)/.test(t)) { const n = Number(t.match(/(\d)/)![1]); const k = j.findings[n - 1]; await typing(id, 400); if (k) challenge(id, k, text.replace(/^challenge (finding )?\d:?\s*/i, '')); return }
    if (/choose|go with/.test(t) && j.recs.length) { await typing(id, 400); const n = t.match(/(\d)/); const r = n ? j.recs[Number(n[1]) - 1] : j.recs.find((x) => x.preferred); if (r) choose(id, r.id); return }
    if (/save.*plan/.test(t)) { await typing(id, 400); savePlan(id); return }
    await typing(id, 600)
    if (/look like|when it (fires|runs)/.test(t)) { say(id, j.case === 'schedule' ? 'When it runs you get the pack refreshed, not a run to babysit: the six steps run by themselves, findings land, and the deliverables are rebuilt. The run stays here, every step inspectable.' : 'When the risk of a contract goes up you get a notification, not a dashboard to watch: which contract, which signals changed and the evidence behind each, what is at stake, and a plan written for that site. Then I do what your rules on the Plan tab say: tell the owners, build the deck, write the plan. Try it with "Simulate tomorrow’s morning check".'); rmChip(id, 'What will it look like when it fires?'); rmChip(id, 'What will it look like when it runs?'); return }
    if (/renewal review/.test(t)) { const q = Object.values(get().goals).find((x) => x.case === 'once'); say(id, q ? `The renewal review is on the left${q.status === 'ready' || q.status === 'accepted' ? ', with findings ready. This watch reads its plan list whenever it fires.' : '. This watch reads it whenever it fires.'}` : 'No renewal review has been run in this session yet. Start it from Answer once; this watch reads its plan list whenever it fires.'); rmChip(id, 'Open the renewal review'); return }
    if (/open the note|the note/.test(t)) { say(id, 'The run and its note are under Runs on the right.'); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'runs' } })); rmChip(id, 'Open the note'); return }
    if (/snooze/.test(t)) { log(id, 'You', 'Snoozed the three contracts until the next check.'); say(id, 'Snoozed: I will not fire again on these three contracts until tomorrow’s check, but I read them again then and update the brief if anything changes.'); rmChip(id, 'Snooze these contracts until the next check'); return }
    if (/doing|now|status|where are you/.test(t)) { const run = j.nodes.filter((n) => j.ns[n.id]?.state === 'running'); say(id, run.length ? `Running **${run.map((n) => n.title.toLowerCase()).join('** and **')}**. ${j.doneCount} of ${j.nodes.filter((n) => !j.removed.includes(n.id)).length} steps done.` : j.status === 'armed' ? `Armed, nothing running. Next check: ${j.nextCheck}.` : j.status === 'executed' ? 'Nothing is running. The recommendation is executed; the watch stays armed for the next check.' : 'Nothing is running; the brief is out and the run waits for your review.'); rmChip(id, 'What are you doing now?'); return }
    if (/open the data|show the data/.test(t)) { window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id, tab: 'data' } })); say(id, 'The worksheet is on the right under Data.'); rmChip(id, 'Open the data'); return }
    say(id, 'Noted and logged. The watch itself only changes if you change its plan.')
    log(id, 'You', text)
  }

  /* ---------------- the deliverables card, by click or in words */
  const DWORDS: [RegExp, RegExp][] = [[/\b(pack|deck|slide)/, /pack|review/i], [/\bplan\b/, /renewal plan/i], [/\bbriefs?\b/, /brief/i], [/\b(scorecard|dashboard)\b/, /scorecard/i], [/\b(tracker)\b/, /tracker/i], [/\bback-?test\b/, /back-test/i]]
  const FMT: [RegExp, OutputFormat][] = [[/\b(slide|slides|deck|presentation|powerpoint)\b/, 'Slide pack'], [/\bdashboard\b/, 'Dashboard'], [/\b(spreadsheet|workbook|excel)\b/, 'Workbook'], [/\b(email|e-mail)\b/, 'Email'], [/\bmemo\b/, 'Memo'], [/\b(document|report|brief)\b/, 'Document']]
  const delivText = async (id: string, text: string) => {
    const t = text.toLowerCase()
    await typing(id, 450)
    const j = g(id)
    if (/^(run( it)?|go|go ahead|confirm|arm( it| the watch)?|yes|ok|okay|start|that'?s (it|right|all)|looks good)\b/.test(t)) { confirmDeliv(id); return }
    const hits = (re: RegExp) => j.deliv.filter((d) => DWORDS.some(([w, l]) => w.test(t) && l.test(d.label)) && re.test(t))
    if (/\b(only|just)\b/.test(t) && hits(/./).length) { const keep = new Set(hits(/./).map((d) => d.id)); patch(id, (x) => ({ deliv: x.deliv.map((d) => ({ ...d, on: keep.has(d.id) })) })); say(id, `Only ${g(id).deliv.filter((d) => d.on).map((d) => d.label.split(':')[0].toLowerCase()).join(' and ')}. Say "run it" when ready, or change it above.`); return }
    if (/\b(drop|no|without|not|skip|leave out|remove)\b/.test(t) && hits(/./).length) { const off = new Set(hits(/./).map((d) => d.id)); patch(id, (x) => ({ deliv: x.deliv.map((d) => (off.has(d.id) ? { ...d, on: false } : d)) })); say(id, `Left out: ${[...off].map((k) => j.deliv.find((d) => d.id === k)!.label.split(':')[0].toLowerCase()).join(', ')}.`); return }
    const f = FMT.find(([re]) => re.test(t))
    if (f && !hits(/./).some((d) => !d.custom)) {
      const aud = text.match(/\bfor (the )?([A-Z][\w,.'-]*(?:\s+(?!on\b|about\b|with\b|of\b|to\b)[\w,.'-]+){0,6})/)?.[2]?.trim()
      const spec: DelivSpec = { id: `custom-${Date.now().toString(36)}`, label: text.replace(/^(also|and|plus|add|i need|i want|make)\s+(me\s+)?(a|an)?\s*/i, '').replace(/^./, (c) => c.toUpperCase()).replace(/\.$/, ''), audience: aud ?? 'As you described', purpose: text, format: f[1], on: true, mode: 'ai', describe: text, custom: true }
      patch(id, (x) => ({ deliv: [...x.deliv, spec] }))
      say(id, `Added: **${spec.label}**, a ${f[1].toLowerCase()} on a structure I design for it. Pick a library template or your own file for it above instead, if you have one.`)
      return
    }
    say(id, `Tick what you need above and pick a template for each, or tell me ("only the ${j.deliv[0]?.label.split(':')[0].toLowerCase() ?? 'memo'}", "also a slide pack for the committee"). Then "${j.mode === 'watch' ? 'arm it' : 'run it'}".`)
  }
  const confirmDeliv = (id: string) => {
    const j = g(id); if (!j || j.delivConfirmed) return
    const tpls = useSubmissionStore.getState().templates
    const on = j.deliv.filter((d) => d.on)
    if (!on.length) { say(id, 'Tick at least one deliverable; the run builds it at the end.'); return }
    const notReady = on.filter((d) => !specReady(d, tpls))
    if (notReady.length) { say(id, `Pick a template for ${notReady.map((d) => d.label.split(':')[0].toLowerCase()).join(' and ')} first, or let me recommend or create one.`); return }
    const autoN = j.acts.filter((a) => a.mode === 'auto' && a.on !== false).length
    if (j.case === 'watch') { const rulesOn = j.acts.filter((a) => a.on !== false); patch(id, (x) => ({ deliv: x.deliv.map((d) => (d.id === 'sub-risk-brief' ? { ...d, on: rulesOn.some((a) => a.key === 'deck') } : d.id === 'sub-risk-plan' ? { ...d, on: rulesOn.some((a) => a.key === 'plan') } : d)) })) }
    const sum0 = `${on.map((d) => d.label.split(':')[0]).join(' · ')}${j.acts.length ? ` · ${autoN} kinds of action by itself, ${j.acts.length - autoN} for your OK` : ''}`
    const sum = j.case === 'watch' ? `${Object.values(DESIGN.panels).filter(Boolean).length} views on the dashboard · ${j.acts.filter((a) => a.on !== false).length} rules, ${autoN} by itself` : sum0
    patch(id, (x) => ({ delivConfirmed: true, rv: [...new Set([...x.rv, 'deliv'])], chat: x.chat.map((m) => (m.card?.kind === 'deliv' && !m.card.done ? { ...m, card: { ...m.card, done: sum } } : m)) }))
    log(id, 'You', `Agreed what it hands over: ${on.map((d) => d.label).join('; ')}.`)
    nextQuestion(id)
  }

  /* ---------------- questions, answered by tile, by text, or by an edit on the row */
  const answerQ = (id: string, key: string, v: string, label?: string) => {
    const j = g(id)
    const q = j.questions.find((x) => x.key === key)
    const tile = q?.tiles.find((t) => t.v === v)
    const text = label ?? ANSWER_TEXT[key]?.[v] ?? tile?.t ?? v
    if (key === 'frame' && v === 'upload') {
      patch(id, (x) => ({ answers: { ...x.answers, frame: 'upload' }, rv: [...new Set([...x.rv, 'frame'])] }))
      foldQ(id, key, text)
      window.setTimeout(() => say(id, 'Give me the file. I read your factors, your signals, your weights and your rule for 1 to 4, and I use them exactly as written.', { kind: 'upload' }), P(350))
      return
    }
    if (key === 'frame') design.reset('proposed')
    if (key === 'check') design.confirmAll(ASSUME_KEYS(DESIGN))
    patch(id, (x) => ({ answers: { ...x.answers, [key]: v }, rv: [...new Set([...x.rv, key === 'four' ? 'as:four' : key === 't3' ? 'as:t3' : key])] }))
    foldQ(id, key, text)
    if (key === 'frame') { void draftScorecard(id, false); return }
    window.setTimeout(() => void nextQuestionTyped(id), P(300))
  }
  const matchRowEdit = (text: string): { k: string; val: string } | null => {
    const LABELS: Record<string, string> = { question: 'Question', decision: 'Decision it informs', who: 'Who decides, by when', scope: 'Scope', success: 'What counts as success', 'as:four': 'Evergreen contracts', 'as:t3': 'NPS from a predecessor', watch: 'What I watch', against: 'Against', where: 'Checked where and when', combine: 'One rating from two halves', fires: 'Fires when', tell: 'Who is told', until: 'Runs until', 'g:fixed1': 'The scorecard', 'g:fixed2': 'Client-side signs', 'g:fixed3': 'Pack structure' }
    const lower = text.toLowerCase()
    for (const [k, l] of Object.entries(LABELS)) { const pre = `${l.toLowerCase()}:`; if (lower.startsWith(pre)) return { k, val: text.slice(pre.length).trim() } }
    return null
  }
  const rowEdit = async (id: string, k: string, val: string) => {
    const j = g(id)
    me(id, `${{ question: 'Question', decision: 'Decision it informs', who: 'Who decides, by when', scope: 'Scope', success: 'What counts as success', 'as:four': 'Evergreen contracts', 'as:t3': 'NPS from a predecessor', watch: 'What I watch', against: 'Against', where: 'Checked where and when', combine: 'One rating from two halves', fires: 'Fires when', tell: 'Who is told', until: 'Runs until' }[k] ?? k}: ${val}`)
    if (!val) { await typing(id, 400); say(id, `What should it say instead?`); return }
    await typing(id, 500)
    if (k === 'as:four') { const v = parseFour(val); patch(id, (x) => ({ answers: { ...x.answers, four: v } })); foldQ(id, 'four', 'changed on the plan') }
    else if (k === 'as:t3') { const v = parseT3(val); patch(id, (x) => ({ answers: { ...x.answers, t3: v } })); foldQ(id, 't3', 'changed on the plan') }
    else if (k === 'combine') { const v: Rule = /average|mean/i.test(val) ? 'avg' : /side by side|two ratings|separate|both/i.test(val) ? 'sep' : 'max'; design.rule(v); patch(id, (x) => ({ answers: { ...x.answers, combine: v } })); foldQ(id, 'combine', 'changed on the plan') }
    else if (k === 'fires') { const v = /point|sign|factor|early|outside/i.test(val) ? 'early' : /every|digest|all/i.test(val) ? 'always' : 'breach'; patch(id, (x) => ({ answers: { ...x.answers, fires: v } })); foldQ(id, 'fires', 'changed on the plan') }
    else if (k === 'tell') { const v = /legal|project leader|everyone/i.test(val) ? 'controller' : /regional|vp/i.test(val) ? 'pm' : 'me'; patch(id, (x) => ({ answers: { ...x.answers, tell: v } })); foldQ(id, 'tell', 'changed on the plan') }
    else if (k === 'who') patch(id, (x) => ({ who: val, dateSrc: 'you', over: { ...x.over } }))
    else patch(id, (x) => ({ over: { ...x.over, [k]: val } }))
    const label = { question: 'Question', decision: 'Decision it informs', who: 'Who decides, by when', scope: 'Scope', success: 'What counts as success', 'as:four': 'Evergreen contracts', 'as:t3': 'NPS from a predecessor', watch: 'What I watch', against: 'Against', where: 'Checked where and when', combine: 'One rating from two halves', fires: 'Fires when', tell: 'Who is told', until: 'Runs until' }[k] ?? k
    change(id, `Changed “${label}”`, [k])
    const IMPACT: Record<string, string> = { question: 'Every step still answers it; tell me if one no longer fits.', decision: 'The pack and the plan are framed around it.', who: 'The plan and the drafts are timed to it.', scope: 'Step 1 follows the new scope.', success: 'The recommendation is judged against it.', 'as:four': 'Steps 2 and 3 use it.', 'as:t3': 'Steps 2 and 3 and the pack use it.', watch: 'Step 1 measures it.', against: 'Step 1 checks against it.', where: 'The next check follows it.', fires: 'The next check uses it.', tell: 'The next note goes there.', until: 'Noted.' }
    say(id, `Changed **${label}** in the plan. ${IMPACT[k] ?? 'Noted.'}`)
    if (j.stage === 'questions') window.setTimeout(() => void nextQuestionTyped(id), P(300))
  }

  return {
    goals: (SEEDED ? { [SEED_WATCH_ID]: seedWatch() } : {}) as Record<string, Journey>,
    order: SEEDED ? [SEED_WATCH_ID] : [],
    saved: SEED_SAVED,
    current: null,
    start: { mode: 'once', prompt: '', files: [], web: false },
    setStart: (p) => set({ start: { ...get().start, ...p } }),
    open: (id) => set({ current: id }),

    begin: () => {
      const s = get().start
      const used = new Set(Object.values(get().goals).map((x) => x.agent.name))
      const free = AGENT_POOL.find((a) => !used.has(a.name)) ?? AGENT_POOL[Object.keys(get().goals).length % AGENT_POOL.length]
      const kind: Journey['kind'] = s.mode === 'watch' ? (s.approachId === 'schedule' || /each quarter|every quarter|each month|every monday|on a schedule|two and a half weeks/i.test(s.prompt) ? 'schedule' : 'rule') : 'once'
      const prompt = s.prompt.trim() || (s.files.length ? 'Use these documents; work out what I should be asking.' : '')
      const j = makeJourney(s.mode, kind, prompt, s.files, s.web, free, s.approachId)
      set({ goals: { ...get().goals, [j.id]: j }, order: [j.id, ...get().order], current: j.id, start: { mode: s.mode, prompt: '', files: [], web: false } })
      void startReading(j.id)
      return j.id
    },

    input: (id, raw) => {
      const text = raw.trim(); if (!text) return
      const j = g(id); if (!j) return
      const q = openQ(j)
      if (j.draft) { me(id, text); say(id, 'One moment: I am still working on the scorecard. Say it again when it is on the right.'); return }
      if (changeCmd(id, text)) return
      if (j.stage !== 'armed' && scoreCmd(id, text)) return
      if (['questions', 'plan'].includes(j.stage)) { const m = matchRowEdit(text); if (m) { void rowEdit(id, m.k, m.val); return } }
      switch (j.stage) {
        case 'plan': void handlePlan(id, text); return
        case 'running': void handleRun(id, text); return
        case 'armed': void handleArmed(id, text); return
        case 'questions': {
          me(id, text)
          const t = text.toLowerCase()
          if (q === 'four') answerQ(id, 'four', parseFour(t))
          else if (q === 't3') answerQ(id, 't3', parseT3(t))
          else if (q === 'combine') answerQ(id, 'combine', /average|mean/.test(t) ? 'avg' : /side by side|two ratings|separate|both/.test(t) ? 'sep' : 'max')
          else if (q === 'fires') answerQ(id, 'fires', /point|sign|factor|early|outside/.test(t) ? 'early' : /every|digest|all/.test(t) ? 'always' : 'breach')
          else if (q === 'tell') answerQ(id, 'tell', /legal|project leader|everyone/.test(t) ? 'controller' : /regional|vp/.test(t) ? 'pm' : 'me')
          else if (openDeliv(j)) void delivText(id, text)
          else void handlePlan(id, text)
          return
        }
        default: return
      }
    },

    attach: async (id, atts, text) => {
      const j = g(id); if (!j) return
      me(id, text ?? '', atts)
      await typing(id, 500)
      const msgId = say(id, `Reading ${atts.length === 1 ? 'it' : 'them'} now.`, { kind: 'reads', lines: [] })
      const msgs: string[] = []
      for (const a of atts) {
        patch(id, (x) => ({ chat: x.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: [...(m.card!.lines ?? []).map((l) => ({ ...l, live: false })), { tool: `read ${a.n}`, res: '…', live: true }] } } : m)) }))
        await wait(700)
        const r = a.id && a.id !== 'up' ? applyEffect(id, a, false) : (patch(id, (x) => ({ extraDocs: [...x.extraDocs, { n: a.n, took: 'Read · nothing in it changes the plan as it stands', mine: true }] })), change(id, `Added ${a.n}`, [`doc:${a.n}`]), { res: 'Read · listed under what I’m working from', msg: `Read **${a.n}**. It is listed in the plan under what I’m working from; nothing in it changes the plan as it stands.` })
        if (r) msgs.push(r.msg)
        patch(id, (x) => ({ chat: x.chat.map((m) => (m.id === msgId ? { ...m, card: { ...m.card!, lines: (m.card!.lines ?? []).map((l) => ({ ...l, live: false, res: l.live ? r?.res ?? 'Read' : l.res })) } } : m)) }))
      }
      await typing(id, 400)
      say(id, msgs.join(' ') + (['questions', 'plan'].includes(g(id).stage) ? ' The plan on the right shows what changed.' : ''))
      if (g(id).stage === 'questions') nextQuestion(id)
    },

    toggleWeb: async (id) => {
      const j = g(id); if (!j) return
      const on = !j.web
      patch(id, () => ({ web: on }))
      if (j.stage === 'reading') return
      change(id, on ? 'Turned on web search' : 'Turned off web search', on ? ['web', 'as:t3'] : [])
      await typing(id, 500)
      say(id, on ? (j.mode === 'once' ? 'Web search is on for this goal. I use it for the **council agendas and local news** of the clients in the set, to find signs on the client side. A public agenda does not tell me how the client rates us, so the question on the NPS stays yours. It is listed in the plan under what I’m working from.' : 'Web search is on. It already feeds three signals of the scorecard (the state ranking and local media); I also read council agendas and regulator pages, and cite each page in the brief.') : 'Web search is off again.')
    },

    answer: (id, key, v, label) => { const j = g(id); const q = j?.questions.find((x) => x.key === key); const tile = q?.tiles.find((t) => t.v === v); me(id, label ?? tile?.t ?? v); answerQ(id, key, v, label) },
    rowEdit: (id, key, text) => void rowEdit(id, key, text),
    setAutonomy: (id, a) => { const j = g(id); if (!j || j.autonomy === a) return; patch(id, () => ({ autonomy: a })); if (['plan', 'running'].includes(j.stage)) change(id, `Check-in set to: ${{ every: 'at every step', blocked: 'when blocked or the plan changes', end: 'run to the end' }[a]}`) },
    agree: (id) => { me(id, 'Agree and run'); agree(id) },
    pause: (id, on) => pause(id, on),
    applyDiff: (id, msgId) => {
      const j = g(id); const m = j.chat.find((x) => x.id === msgId); if (!m?.card?.diff || m.card.done) return
      const key = m.card.key ?? ''
      patch(id, (x) => ({ chat: x.chat.map((mm) => (mm.id === msgId ? { ...mm, card: { ...mm.card!, done: 'Applied' } } : mm)) }))
      if (key === 'fork:rc') { applyFork(id, 'rc'); return }
      if (key === 'steer') { applySteer(id); return }
      if (key.startsWith('drop:')) { const n = key.slice(5); get().removeStep(id, n); return }
    },
    leaveDiff: (id, msgId) => patch(id, (x) => ({ chat: x.chat.map((mm) => (mm.id === msgId ? { ...mm, card: { ...mm.card!, done: 'Left as it was', left: true } } : mm)) })),
    forkPrompt: (id) => { me(id, 'Fork a what-if'); forkPrompt(id) },
    applyFork: (id, kind) => applyFork(id, kind),
    checkpoint: (id, v) => {
      const j = g(id); if (j.status !== 'wait') return
      const label = { june: 'Count the evergreen contracts', standin: 'Leave them out', both: 'Count them, and show the review without them beside it' }[v] ?? v
      me(id, label)
      patch(id, (x) => ({ chat: x.chat.map((m) => (m.card?.kind === 'cp' && !m.card.done ? { ...m, card: { ...m.card, done: label } } : m)), flags: { ...x.flags, cpAnswered: true }, status: 'running', answers: { ...x.answers, four: v === 'standin' ? 'standin' : 'june' }, chips: ['Pause after this step', 'What are you doing now?'] }))
      setNode(id, 'cp', 'done', { text: `Answered · ${v === 'standin' ? 'left out' : 'counted'}` })
      log(id, 'You', `Answered the checkpoint: ${label.toLowerCase()}.`)
      if (v === 'standin') { setNode(id, 'n2', 'stale'); if (j.ns.n3?.state === 'done') setNode(id, 'n3', 'stale'); window.setTimeout(() => { setNode(id, 'n2', 'done', { text: 'Done · evergreen left out', contentKey: 'n2b', caveat: true }); if (g(id).ns.n3?.state === 'stale') setNode(id, 'n3', 'done', { text: `Done · ${m1(rbFigures(false).rate)} · re-run` }); patch(id, (x) => ({ findings: x.findings.map((k) => (k === 'F2' ? 'F2b' : k)), flags: { ...x.flags, steered: true } })); ev(id, `Step 2 re-run · the evergreen contracts left out · ${m1(rbFigures(false).rate)} on the plan list`) }, 1200) }
      if (v === 'both' && !j.ns.f1) applyFork(id, 'four')
      runOnce(id, true)
    },
    steer: (id) => { me(id, STEER); steerDiff(id) },
    acceptFinding: (id, key) => { const j = g(id); me(id, key === 'all' ? 'Accept all findings' : `Accept finding ${j.findings.indexOf(key) + 1}`); acceptFinding(id, key) },
    challenge: (id, key, text) => { const j = g(id); me(id, `Challenge finding ${j.findings.indexOf(key) + 1}${text ? `: ${text}` : ''}`); challenge(id, key, text) },
    choose: (id, recId) => { const j = g(id); me(id, `Use option ${j.recs.findIndex((r) => r.id === recId) + 1} instead`); choose(id, recId) },
    swapReco: (id, recId) => { const j = g(id); if (j.chosen) return; patch(id, (x) => ({ recs: x.recs.map((o) => ({ ...o, preferred: o.id === recId })) })); log(id, 'You', `Prefers option ${j.recs.findIndex((r) => r.id === recId) + 1} for now.`); say(id, `Option ${j.recs.findIndex((r) => r.id === recId) + 1} is now the preferred one on the right. Choose it when you are sure.`) },
    markSent: (id) => { const j = g(id); if (j.sentAt) return; patch(id, () => ({ status: 'sent', sentAt: hhmm() })); log(id, 'You', 'Sent the pack, the plan and the briefs to Renee.'); ev(id, `Sent to Renee Halvorsen · ${hhmm()}`); say(id, 'Sent to Renee with the recommendation, the plan list and the back-test set out. This goal is done; it stays under Executed with its plan, every step, receipt and caveat.'); chips(id, ['Save this plan', 'Make it standing']) },
    markStarted: (id, outId) => { patch(id, (x) => ({ started: [...new Set([...x.started, outId])] })); log(id, 'You', `Started the submission ${outId} in Submissions.`); rmChip(id, 'Build the pack in Submissions'); rmChip(id, 'Open the draft in Submissions') },
    execute: (id) => { me(id, 'Execute'); execute(id) },
    notNow: (id) => { me(id, 'Not now'); notNow(id) },
    savePlan: (id, name) => { me(id, 'Save this plan'); savePlan(id, name) },
    fire: (id) => { me(id, g(id)?.case === 'schedule' ? 'Simulate: run now' : 'Simulate tomorrow’s morning check (20 November)'); fire(id) },
    rmDoc: (id, n) => { patch(id, (x) => ({ extraDocs: x.extraDocs.filter((d) => d.n !== n) })); change(id, `Stopped using ${n}`) },
    content: (id, nodeId) => {
      const j = g(id); if (!j) return null
      const key = j.ns[nodeId]?.contentKey ?? nodeId
      if (nodeId === 'f1' && j.forkKind) return forkContent(j.forkKind, j.answers)
      const all = j.case === 'once' || j.case === 'schedule' ? onceContent(j.answers) : j.case === 'watch' || j.case === 'overrun-once' ? watchContent() : genericContent()
      return all[key] ?? null
    },
    findingsOf: (id) => { const j = g(id); return j?.case === 'once' || j?.case === 'schedule' ? onceFindings(j.answers) : watchFindings() },
    removeStep: (id, nodeId) => {
      const j = g(id); if (!j) return
      const n = j.nodes.find((x) => x.id === nodeId); if (!n) return
      const removed = [...j.removed, nodeId]
      patch(id, () => ({ removed, edges: rebuildEdges(j, removed) }))
      change(id, `Dropped the step: ${n.title}`, ['steps'])
    },
    restoreStep: (id, nodeId) => {
      const j = g(id); if (!j) return
      const removed = j.removed.filter((r) => r !== nodeId)
      patch(id, () => ({ removed, edges: rebuildEdges(j, removed) }))
      change(id, `Put back the step: ${j.nodes.find((n) => n.id === nodeId)?.title}`, ['steps'])
    },
    makeStanding: (id) => makeStanding(id),
    setDeliv: (id, specs) => patch(id, () => ({ deliv: specs })),
    makeMore: (id, specs) => {
      const j = g(id); if (!j) return []
      const goal = toGoal(j)
      register(j)
      const who = useAuthStore.getState().identity?.name ?? 'You'
      const basis = basisOf(j)
      const out: string[] = []
      const deliv = [...j.deliv]
      const built = { ...j.built }
      for (const d0 of specs.filter((x) => x.on && !j.built[x.id])) {
        const d = { ...d0, id: deliv.some((x) => x.id === d0.id && j.built[x.id]) ? `${d0.id}-${Date.now().toString(36)}` : d0.id }
        if (!deliv.some((x) => x.id === d.id)) deliv.push(d); else deliv.splice(deliv.findIndex((x) => x.id === d.id), 1, d)
        patch(id, () => ({ deliv }))
        const tpl = resolveTpl(id, d, goal)
        if (!tpl) continue
        const sid = useSubmissionStore.getState().buildDeliverable(goal, { id: d.id, label: d.label, audience: d.audience, purpose: d.purpose, template: tpl.name, templateId: tpl.id, why: d.why ?? '' }, tpl, who, { journeyId: id, delivId: d.id, basis, agentName: j.agent.name })
        built[d.id] = sid
        out.push(sid)
      }
      patch(id, (x) => ({ deliv: x.deliv.map((y) => (built[y.id] ? { ...y, on: true } : y)), built }))
      if (out.length) log(id, who, `Made ${out.length} more deliverable${out.length === 1 ? '' : 's'} from this run in Submissions.`)
      return out
    },
    offerFor: (id) => {
      const j = g(id); if (!j) return []
      /* Everything offered at the start, ticked if it was built; the ones not built are offered again, unticked. */
      return [...j.deliv.filter((d) => j.built[d.id]).map((d) => ({ ...d, on: true })), ...j.deliv.filter((d) => !j.built[d.id] && !d.custom).map((d) => ({ ...d, on: false }))]
    },
    seedExecuted: () => {
      if (Object.values(get().goals).some((x) => x.case === 'once')) return
      /* The renewal review, run on 19 November: planned, clarified, run to the end, three deliverables built. */
      const o = makeJourney('once', 'once', ONCE_PROMPT, ONCE_FILES, false, AGENT_POOL[1])
      o.id = 'g-renewal-review-run-19-nov'
      o.answers = { four: 'june', t3: 'out' }
      o.delivConfirmed = true
      o.stage = 'running'; o.status = 'delivered'; o.agreedAt = '19 Nov, 14:02'; o.executedAt = '19 Nov, 14:06'
      o.rv = [...new Set([...ONCE_READS.flatMap((r) => r.rv), 'steps', 'fixed', 'memory', 'deliv', 'as:four', 'as:t3'])]
      o.nodes.forEach((n) => { o.ns[n.id] = { state: 'done', text: 'Done', at: '19 Nov, 14:03' } })
      o.findings = ['F1', 'F2', 'F3', 'F4']; o.recs = onceRecs(o.answers); o.gaps = ONCE_GAPS; o.outputs = ONCE_OUTPUTS
      o.runs = [{ id: 'r1', at: '19 Nov, 14:02', label: o.title, status: 'executed' }]
      o.chat = [{ id: mid(), who: 'me', text: ONCE_PROMPT, at: '19 Nov, 13:58' }, { id: mid(), who: 'event', text: 'Running · plan v1 · 19 Nov, 14:02', at: '19 Nov, 14:02' }, { id: mid(), who: 'event', text: 'Delivered · 19 Nov, 14:06 · moved to Executed', at: '19 Nov, 14:06' }]
      o.log = [{ t: '19 Nov, 14:02', who: 'You', what: 'Started the run (plan v1).' }, { t: '19 Nov, 14:06', who: o.agent.name, what: 'Accepted the four findings, chose the top recommendation and built three deliverables.' }]
      o.composer = { on: true, ph: 'Change anything: another option, a treatment, a section…' }
      /* The contract risk watch, fired by the 20 November morning check and handled. */
      const w = seedWatch()
      applyNight(); w.status = 'executed'; w.executedAt = '20 Nov, 06:08'
      w.nodes.forEach((n) => { w.ns[n.id] = { state: 'done', text: 'Done', at: '20 Nov, 06:06' } })
      w.findings = ['W1', 'W2', 'W3', 'W4']; w.recs = WATCH_RECS.map((r) => ({ ...r })); w.gaps = WATCH_GAPS; w.outputs = WATCH_OUTPUTS
      w.runs = [{ id: 'r1', at: '20 Nov, 06:04', label: `Morning check, 20 November · ${watchStory().short}`, status: 'executed' }]
      w.execActs = ruleActions(w).map((a) => ({ ...a, state: w.acts.find((c) => c.key === a.cat)?.mode === 'auto' ? 'done' as const : 'waiting' as const }))
      set({ goals: { ...get().goals, [o.id]: o, [w.id]: w }, order: [o.id, w.id, ...get().order.filter((x) => x !== o.id && x !== w.id)] })
      for (const x of [o.id, w.id]) {
        const top = g(x).recs.find((r) => r.preferred) ?? g(x).recs[0]
        patch(x, (y) => ({ over: { ...y.over, ...Object.fromEntries(y.findings.map((k) => [`acc:${k}`, 'auto'])) }, chosen: top.id, chosenBy: 'auto' }))
        buildAll(x)
        patch(x, () => ({ deliveredAt: x === o.id ? '14:06' : '06:08' }))
      }
    },
    confirmDeliv: (id) => { const j = g(id); if (!j || j.delivConfirmed) return; me(id, j.case === 'watch' ? 'Build the scorecard and start watching' : j.mode === 'watch' ? 'Arm the watch' : 'Run it'); confirmDeliv(id) },
    setActs: (id, acts) => { if (g(id)) patch(id, () => ({ acts })) },
    /* The template arrives: a file you chose, or the sample. It is read as written, then shown. */
    uploadTemplate: async (id, file) => {
      const j = g(id); if (!j || j.draft || j.rv.includes('sheet')) return
      const name = file ? file.name : TEMPLATE_FILE
      const rows = file ? readTemplate(await file.arrayBuffer()) : templateRows()
      if (!rows.length) { me(id, '', [{ n: name, s: 'file' }] as never); say(id, `I could not find a scorecard in **${name}**. I look for a table with a Factor column and a Signal column, and when each signal scores 1, 2, 3 and 4. Use the template from the link in the upload box, or the sample.`); return }
      const res = design.template(rows, name)
      if (!res.signals) { say(id, `**${name}** has a table, but no signal in it. Add at least one row with a factor and a signal.`); return }
      patch(id, (x) => ({ chat: x.chat.map((m) => (m.card?.kind === 'upload' && !m.card.done ? { ...m, card: { ...m.card, done: name } } : m)) }))
      me(id, file ? `Uploaded ${name}` : `Use the sample template (${name})`)
      void draftScorecard(id, true, res)
    },
    republish: (id) => { void publishFlow(id) },
    discardChange: (id) => discardFlow(id),
    setActMode: (id, key, mode) => { const j = g(id); if (!j) return; patch(id, (x) => ({ acts: x.acts.map((a) => (a.key === key ? { ...a, mode } : a)) })); if (j.stage === 'armed') change(id, `“${j.acts.find((a) => a.key === key)?.text}” now ${mode === 'auto' ? 'runs by itself' : 'waits for your OK'}`) },
    approveAct: (id, i, ok) => { const j = g(id); const a = j?.execActs[i]; if (!a) return; me(id, `${ok ? 'Approve' : 'Decline'}: ${a.text}`); approveAct(id, i, ok) },
  }
})

export const needsOf = (j: Journey) => j.questions.filter((q) => !j.answers[q.key]).length
export const openQuestion = (j: Journey) => { for (let i = j.chat.length - 1; i >= 0; i -= 1) { const c = j.chat[i].card; if (c?.kind === 'q' && !c.done) return c.key ?? null } return null }
export const liveNodes = (j: Journey) => j.nodes.filter((n) => !j.removed.includes(n.id))
export const WHO = WHO_LABEL
export const FOUR_CODES = FOUR
export { rbOf }

/* For the data package export: the live store and the content, reachable from a script driving the prototype. */
/* The Submissions-only build cannot run a goal, so it opens on the two recorded runs, already executed. Every other build starts empty. */
const ONLY_BUILD = (import.meta as unknown as { env: Record<string, string | undefined> }).env?.VITE_CW_ONLY
if (ONLY_BUILD === 'submissions') useJourney.getState().seedExecuted()

if (typeof window !== 'undefined') (window as unknown as { __cwJourney: unknown }).__cwJourney = { useJourney, useGoalStore, cases: { ONCE_PROMPT, ONCE_FILES, ONCE_READS, ONCE_READ_WEB, ONCE_QUESTIONS, ONCE_NODES, ONCE_EDGES, ONCE_FORKS, ONCE_RECS, ONCE_OUTPUTS, ONCE_GAPS, WATCH_PROMPT, WATCH_READS, WATCH_QUESTIONS, WATCH_NODES, WATCH_EDGES, WATCH_RECS, WATCH_OUTPUTS, WATCH_GAPS, SCHEDULE_READS, GENERIC_NODES, GENERIC_EDGES, GENERIC_READS, LIB, onceContent, watchContent, genericContent, forkContent, onceFindings, watchFindings, portfolioFigures, SEED_SAVED } }
