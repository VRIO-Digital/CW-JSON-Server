import { now as clockNow } from '../data/pace'
import { create } from 'zustand'
import { GOALS, ONCE_ID, type Goal, type SubmissionSuggestion } from '../data/goalCases'
import { TEMPLATES, type OutputFormat, type SectionRole, type Template } from '../data/submissionTemplates'
import { templateFromOutline, type OutlineProposal } from '../data/outputDesigner'

/*
 * Submissions, by my agents. A submission is a business-ready output drafted from one or more goals.
 * Three ways to start, all tied to goals:
 *   recommendation : from a goal, one of the outputs its agent recommends; each recommendation rests on a
 *                    template that exists in the library (a recommendation whose template is missing is
 *                    not offered);
 *   described      : from a goal, when no template fits: the author picks a format (slide pack, dashboard,
 *                    document, memo, spreadsheet, letter) and describes what it should cover; the agent
 *                    reads that into an outline the author edits, which can be saved as a template;
 *   template       : from a template in the library, with the goals it draws on.
 * The template library lives here too. Five steps: brief, template, outline, draft, review. In memory only.
 */

export type SubmissionStage = 'brief' | 'template' | 'outline' | 'draft' | 'reviewed'

export interface Section {
  id: string
  heading: string
  body: string
  from: string
  role: SectionRole
  included: boolean
}

export interface Submission {
  id: string
  title: string
  audience: string
  purpose: string
  template: string
  templateId?: string
  format: OutputFormat
  origin: 'recommendation' | 'described' | 'template'
  /** For a described output: the format chosen, the author's words and the agent's reading of them. */
  brief?: { format: OutputFormat; description: string; reading: string[] }
  goalIds: string[]
  fromGoal: { id: string; title: string } | null
  agentName?: string
  stage: SubmissionStage
  sections: Section[]
  createdBy: string
  createdAt: string
  reviewedBy?: string
  log: { at: string; who: string; what: string }[]
  /** Built by a goal run: which goal, which deliverable it agreed, the version and what it rests on. */
  journeyId?: string
  delivId?: string
  version?: number
  basis?: string
}

interface SubmissionState {
  submissions: Submission[]
  templates: Template[]
  startFromGoal: (g: Goal, s: SubmissionSuggestion, who: string) => string
  startFromTemplate: (t: Template, goals: Goal[], who: string) => string
  startDescribed: (g: Goal, description: string, outline: OutlineProposal, who: string) => string
  /** Save a described submission's outline to the library, so the next recommendation can rest on it. */
  saveOutlineAsTemplate: (id: string, name: string, who: string) => string | undefined
  addTemplate: (t: Template, who: string) => void
  update: (id: string, patch: Partial<Submission>, who?: string, what?: string) => void
  applyTemplate: (id: string, t: Template, goals: Goal[], who: string) => void
  setSections: (id: string, sections: Section[]) => void
  setStage: (id: string, stage: SubmissionStage, who: string) => void
  /** A goal run builds a deliverable straight to a draft: no set-up steps. */
  buildDeliverable: (g: Goal, s: SubmissionSuggestion, tpl: Template, who: string, meta: { journeyId: string; delivId: string; basis: string; agentName: string }) => string
  /** Rebuild it after a change upstream (another recommendation, a steer): same deliverable, next version. */
  rebuildDeliverable: (id: string, g: Goal, who: string, basis: string) => void
}

const now = () => clockNow().toISOString()
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 40)

/** What the goals have to say for each section role; several goals are stacked under their titles. */
const WORD = /(?:\d+(?:[.,]\d+)*%?|[a-zà-ÿ%$]{4,})/gi
const STOP = new Set(['with', 'from', 'that', 'this', 'what', 'against', 'four', 'their', 'into', 'each', 'about', 'which', 'where', 'when', 'have', 'been', 'over', 'under'])
/** Which finding a described section is about, by the words its heading shares with the finding; all of them when none stands out. */
const pickFindings = (g: Goal, heading?: string) => {
  if (!heading) return g.findings
  const want = new Set((heading.toLowerCase().match(WORD) ?? []).filter((w) => !STOP.has(w) && (w.length >= 4 || /\d/.test(w)) && !/^\d{1,2}$/.test(w)))
  if (!want.size) return g.findings
  const words = g.findings.map((f) => new Set(`${f.headline} ${f.detail}`.toLowerCase().match(WORD) ?? []))
  const heads = g.findings.map((f) => new Set(f.headline.toLowerCase().match(WORD) ?? []))
  /* A word that only one finding uses ("month") weighs more than one they all share ("fy2026"); a word in a finding's headline counts double. */
  const weight = (w: string) => 1 / Math.max(1, words.filter((ws) => ws.has(w)).length)
  const scored = g.findings.map((f, i) => ({ f, score: [...want].filter((w) => words[i].has(w)).reduce((acc, w) => acc + weight(w) * (heads[i].has(w) ? 2 : 1), 0) }))
  const best = Math.max(...scored.map((x) => x.score))
  return best > 0 ? scored.filter((x) => Math.abs(x.score - best) < 1e-9).map((x) => x.f) : g.findings
}

const contentFor = (goals: Goal[], role: SectionRole, s?: SubmissionSuggestion, heading?: string): { body: string; from: string } => {
  if (!goals.length) return { body: '', from: 'You' }
  const per = (g: Goal): string => {
    const pref = g.recommendations.find((r) => r.preferred) ?? g.recommendations[0]
    switch (role) {
      case 'purpose':
        return `${s ? `${s.purpose}.\n\n` : ''}Goal: ${g.goal}\nDecision asked: ${g.target.decision}\nDeadline: ${g.target.deadline}`
      case 'summary':
        return pref ? `${pref.title}.\n${pref.summary}\n${pref.figures.map((f) => `${f.label}: ${f.value}`).join('\n')}` : ''
      case 'findings':
        return pickFindings(g, heading).map((f) => `${g.findings.indexOf(f) + 1}. ${f.headline}\n${f.detail}`).join('\n\n')
      case 'options':
        return g.recommendations.map((r) => `${r.title}${r.preferred ? ' (preferred)' : ''}\n${r.summary}\n${r.figures.map((f) => `${f.label}: ${f.value}`).join(' · ')}\nTrade-off: ${r.tradeoff}`).join('\n\n')
      case 'why':
        return pref ? pref.story.filter((b) => b.kind === 'found' || b.kind === 'compared' || b.kind === 'therefore').map((b) => `• ${b.text}`).join('\n') : ''
      case 'evidence':
        return g.findings.flatMap((f) => f.evidence.map((e) => `• ${e.text} (${e.kind}: ${e.source}${e.asOf ? `, ${e.asOf}` : ''})`)).join('\n')
      case 'assumptions':
        return [...g.gaps.map((x) => `• ${x}`), ...(g.question ? [`• Open question: ${g.question}`] : [])].join('\n')
      default:
        return ''
    }
  }
  const parts = goals.map((g) => per(g)).filter(Boolean)
  if (!parts.length) return { body: '', from: 'You' }
  const from = { purpose: 'Goal', summary: 'Preferred recommendation', findings: 'Findings', options: 'Recommendations', why: 'Recommendation story', evidence: 'Evidence lines', assumptions: 'Gaps and open questions' }[role as string] ?? 'Goal'
  const body = goals.length > 1 ? goals.map((g, i) => `${g.title}\n${parts[i] ?? ''}`).join('\n\n') : parts[0]
  return { body, from: goals.length > 1 ? `${from}, ${goals.length} goals` : `${from}, ${goals[0].agent.name}` }
}

/** What the agent would put in a section, from the goals it draws on; empty when nothing in them covers it. */
export const suggestFill = (goals: Goal[], role: SectionRole, heading: string): { body: string; from: string } => {
  const c = contentFor(goals, role, undefined, heading)
  if (c.body) return c
  const g = goals[0]
  if (!g) return c
  if (role === 'next') return { body: [`• ${g.target.decision}`, `• Deadline: ${g.target.deadline}`, ...g.gaps.slice(0, 2).map((x) => `• Close: ${x}`)].join('\n'), from: `Goal and open items, ${g.agent.name}` }
  const picked = pickFindings(g, heading)
  if (picked.length && picked.length < g.findings.length) return { body: picked.map((f) => `${f.headline}\n${f.detail}`).join('\n\n'), from: `Findings, ${g.agent.name}` }
  return { body: '', from: 'You' }
}

/* A part no role fills (approvals and dates, next steps): the decision asked, the deadline, what the recommendation says about approval, and the open items. A built deliverable is complete; nothing is left for you to write. */
const fallbackFill = (goals: Goal[], heading: string, hint?: string): { body: string; from: string } => {
  const g = goals[0]
  if (!g) return { body: '', from: 'You' }
  const pref = g.recommendations.find((r) => r.preferred) ?? g.recommendations[0]
  const want = `${heading} ${hint ?? ''}`.toLowerCase()
  const lines = [
    `• Decision asked: ${g.target.decision}`,
    `• Deadline: ${g.target.deadline}`,
    ...(pref?.figures ?? []).filter((f) => /approv|committee|capacity|sign|cost/i.test(f.label)).map((f) => `• ${f.label}: ${f.value}`),
    ...g.gaps.filter((x) => (/audit|outlet|approval/.test(want) ? /approv|audit|outlet|expire/i : /approv|sign|confirm|before|identification/i).test(x)).slice(0, 3).map((x) => `• Open: ${x}`),
  ]
  return { body: lines.join('\n'), from: `Goal, recommendation and open items, ${g.agent.name}` }
}

/* A part of a structure the agent designed from words holds what its heading names, not everything of its role. */
const specificFill = (goals: Goal[], role: SectionRole, heading: string, hint?: string): { body: string; from: string } | null => {
  const g = goals[0]
  if (!g || goals.length > 1) return null
  const words = [...new Set((`${heading} ${hint ?? ''}`.toLowerCase().match(WORD) ?? []).filter((w) => !STOP.has(w) && !/^\d/.test(w)))]
  if (role === 'purpose' && /\b(decision|decide|ask)/i.test(heading)) {
    const pref = g.recommendations.find((r) => r.preferred) ?? g.recommendations[0]
    const listed = pref?.summary.match(/Decisions? asked:\s*(.+?)\.?$/i)?.[1]
    const items = listed ? listed.split(/;\s*/).map((x) => `• ${x.trim().replace(/^./, (c) => c.toUpperCase())}`) : []
    return { body: [`Decision asked: ${g.target.decision}`, ...(pref ? [`Recommended: ${pref.title}.`] : []), ...items, `Deadline: ${g.target.deadline}`].join('\n'), from: `Goal and preferred recommendation, ${g.agent.name}` }
  }
  if (role === 'assumptions' && words.length) {
    const hit = g.gaps.filter((x) => words.some((w) => x.toLowerCase().includes(w)))
    if (hit.length && hit.length < g.gaps.length) return { body: hit.map((x) => `• ${x}`).join('\n'), from: `Gaps and open questions, ${g.agent.name}` }
    const fs = pickFindings(g, heading)
    if (fs.length && fs.length < g.findings.length && words.some((w) => fs.some((f) => f.headline.toLowerCase().includes(w)))) return { body: fs.map((f) => `${g.findings.indexOf(f) + 1}. ${f.headline}\n${f.detail}`).join('\n\n'), from: `Findings, ${g.agent.name}` }
  }
  return null
}

const sectionsFromTemplate = (t: Template, goals: Goal[], s?: SubmissionSuggestion): Section[] =>
  t.sections.map((sec, i) => {
    const sp = t.id.startsWith('t-desc-') ? specificFill(goals, sec.role, sec.heading, sec.hint) : null
    if (sp) return { id: `${t.id}-${i}`, heading: sec.heading, body: sp.body, from: sp.from, role: sec.role, included: true }
    const c0 = contentFor(goals, sec.role, s, sec.role === 'findings' ? `${sec.heading} ${sec.hint ?? ''}` : undefined)
    const c1 = c0.body ? c0 : suggestFill(goals, sec.role, sec.heading)
    const c = c1.body ? c1 : fallbackFill(goals, sec.heading, sec.hint)
    return { id: `${t.id}-${i}`, heading: sec.heading, body: c.body, from: c.body ? c.from : sec.hint ? `You · ${sec.hint}` : 'You', role: sec.role, included: true }
  })

const sectionsFromOutline = (p: OutlineProposal, goals: Goal[]): Section[] =>
  p.sections.map((sec, i) => {
    const c = specificFill(goals, sec.role, sec.heading, sec.hint) ?? contentFor(goals, sec.role, undefined, `${sec.heading} ${sec.hint ?? ''}`)
    return { id: `d-${i}`, heading: sec.heading, body: c.body, from: c.body ? c.from : sec.hint ? `You · ${sec.hint}` : 'You', role: sec.role, included: true }
  })

const suggestedTemplate = (templates: Template[], templateName: string, templateId?: string): Template | undefined => {
  const byId = templateId ? templates.find((t) => t.id === templateId) : undefined
  if (byId) return byId
  const n = templateName.toLowerCase()
  return templates.find((t) => n.includes(t.name.toLowerCase().split(' ')[0]) && n.includes(t.family.toLowerCase().split(' ')[0]))
}

/** The one submission the prototype opens with: the review pack the renewal goal's agent suggested, at the outline step. */
const SEEDED: Submission[] = (() => {
  const g = GOALS.find((x) => x.id === ONCE_ID)
  const sug = g?.submissions[0]
  if (!g || !sug) return []
  const tpl = suggestedTemplate(TEMPLATES, sug.template, sug.templateId)
  const at = '2026-10-19T06:12:00Z'
  return [{
    id: 'sub-rb-schedules-2026', title: sug.label, audience: sug.audience, purpose: sug.purpose, template: sug.template, templateId: tpl?.id, format: tpl?.format ?? 'Workbook',
    origin: 'recommendation', goalIds: [g.id], fromGoal: { id: g.id, title: g.title }, agentName: g.agent.name, stage: 'outline',
    sections: tpl ? sectionsFromTemplate(tpl, [g], sug) : [], createdBy: 'Nishant Srivastav', createdAt: at,
    log: [
      { at, who: g.agent.name, what: `Recommended this submission from the goal "${g.title}" because the template "${tpl?.name ?? sug.template}" is in the library.` },
      { at: '2026-10-19T09:40:00Z', who: 'Nishant Srivastav', what: 'Confirmed the brief and the template; outline filled from the goal.' },
    ],
  }]
})()

/* The submission the earlier build opened with; kept in the source, not loaded (no seeded state). */
void SEEDED

export const useSubmissionStore = create<SubmissionState>((set, get) => {
  const patch = (id: string, fn: (s: Submission) => Submission) => set({ submissions: get().submissions.map((s) => (s.id === id ? fn(s) : s)) })
  return {
    /* Nothing is seeded: a deliverable exists only once a goal has run and built it. */
    submissions: [] as Submission[],
    templates: TEMPLATES,

    startFromGoal: (g, s, who) => {
      const id = `sub-${slug(s.label)}-${Date.now().toString(36)}`
      const t = now()
      const tpl = suggestedTemplate(get().templates, s.template, s.templateId)
      const sub: Submission = {
        id, title: s.label, audience: s.audience, purpose: s.purpose, template: s.template, templateId: tpl?.id, format: tpl?.format ?? 'Document',
        origin: 'recommendation',
        goalIds: [g.id], fromGoal: { id: g.id, title: g.title }, agentName: g.agent.name, stage: 'brief',
        sections: tpl ? sectionsFromTemplate(tpl, [g], s) : [],
        createdBy: who, createdAt: t,
        log: [{ at: t, who, what: `Started from the goal "${g.title}", as ${g.agent.name} recommended because the template "${tpl?.name ?? s.template}" is in the library.` }],
      }
      set({ submissions: [sub, ...get().submissions] })
      return id
    },

    startFromTemplate: (tpl, goals, who) => {
      const id = `sub-${slug(tpl.name)}-${Date.now().toString(36)}`
      const t = now()
      const first = goals[0]
      const sub: Submission = {
        id,
        title: first ? `${tpl.name}: ${first.title}` : tpl.name,
        audience: tpl.family === 'Contract risk' ? 'Renee Halvorsen, SVP Contract Operations' : tpl.family === 'Renewals' ? 'The Contract Operations leadership team' : tpl.family === 'Client reporting' ? 'The client' : '',
        purpose: first ? first.target.decision : '',
        template: `${tpl.family}: ${tpl.name}`,
        templateId: tpl.id,
        format: tpl.format,
        origin: 'template',
        goalIds: goals.map((g) => g.id),
        fromGoal: first ? { id: first.id, title: first.title } : null,
        agentName: first?.agent.name,
        stage: 'brief',
        sections: sectionsFromTemplate(tpl, goals),
        createdBy: who, createdAt: t,
        log: [{ at: t, who, what: `Started from the template "${tpl.name}", drawing on ${goals.length} goal${goals.length === 1 ? '' : 's'}: ${goals.map((g) => g.title).join('; ')}.` }],
      }
      set({ submissions: [sub, ...get().submissions] })
      return id
    },

    startDescribed: (g, description, outline, who) => {
      const id = `sub-${slug(outline.format)}-${slug(g.title).slice(0, 24)}-${Date.now().toString(36)}`
      const t = now()
      const label = { 'Slide pack': 'deck', Dashboard: 'dashboard', Document: 'document', Memo: 'memo', Workbook: 'workbook', Email: 'email' }[outline.format]
      const sub: Submission = {
        id,
        title: `${g.title.replace(/[?:].*$/, '').trim()}: ${label}${outline.audience ? ` for ${outline.audience.replace(/^The /, 'the ')}` : ''}`,
        audience: outline.audience ?? '',
        purpose: g.target.decision,
        template: `${outline.format}, defined from your description`,
        templateId: undefined,
        format: outline.format,
        origin: 'described',
        brief: { format: outline.format, description, reading: outline.reading },
        goalIds: [g.id], fromGoal: { id: g.id, title: g.title }, agentName: g.agent.name,
        /* A dashboard is always live: it opens on its panels at once; the other formats start at the brief. */
        stage: outline.format === 'Dashboard' ? 'draft' : 'brief',
        sections: sectionsFromOutline(outline, [g]),
        createdBy: who, createdAt: t,
        log: [
          { at: t, who, what: `Described a new ${outline.format.toLowerCase()} for the goal "${g.title}": "${description.length > 160 ? `${description.slice(0, 158)}…` : description}"` },
          { at: t, who: g.agent.name, what: `Read the description into ${outline.sections.length} ${outline.format === 'Slide pack' ? 'slides' : outline.format === 'Dashboard' ? 'panels' : outline.format === 'Workbook' ? 'sheets' : 'sections'} and filled each from the goal where the role matches. No template in the library fits; this outline can be saved as one.` },
        ],
      }
      set({ submissions: [sub, ...get().submissions] })
      return id
    },

    saveOutlineAsTemplate: (id, name, who) => {
      const s = get().submissions.find((x) => x.id === id)
      if (!s || !s.brief) return undefined
      const proposal: OutlineProposal = { format: s.brief.format, sections: s.sections.filter((x) => x.included).map((x) => ({ heading: x.heading, role: x.role })), reading: s.brief.reading, unreadPhrases: [] }
      const tpl = templateFromOutline(name, proposal, s.brief.description)
      set({ templates: [tpl, ...get().templates] })
      patch(id, (x) => ({ ...x, templateId: tpl.id, template: `Described for a goal: ${tpl.name}`, log: [...x.log, { at: now(), who, what: `Saved the outline to the library as the template "${tpl.name}" (${tpl.sections.length} sections). The agent can recommend it from now on.` }] }))
      return tpl.id
    },

    addTemplate: (t) => set({ templates: [t, ...get().templates] }),

    update: (id, p, who, what) => patch(id, (s) => ({ ...s, ...p, log: who && what ? [...s.log, { at: now(), who, what }] : s.log })),

    applyTemplate: (id, t, goals, who) =>
      patch(id, (s) => ({ ...s, templateId: t.id, template: `${t.family}: ${t.name}`, format: t.format, sections: sectionsFromTemplate(t, goals), log: [...s.log, { at: now(), who, what: `Applied the template "${t.name}": ${t.sections.length} sections.` }] })),

    setSections: (id, sections) => patch(id, (s) => ({ ...s, sections })),

    buildDeliverable: (g, sug, tpl, who, meta) => {
      const id = `sub-${slug(sug.label)}-${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`
      const t = now()
      const sub: Submission = {
        id, title: sug.label, audience: sug.audience, purpose: sug.purpose, template: `${tpl.family}: ${tpl.name}`, templateId: tpl.id, format: tpl.format,
        origin: 'recommendation', goalIds: [g.id], fromGoal: { id: g.id, title: g.title }, agentName: meta.agentName, stage: 'draft',
        sections: sectionsFromTemplate(tpl, [g], sug), createdBy: who, createdAt: t,
        journeyId: meta.journeyId, delivId: meta.delivId, version: 1, basis: meta.basis,
        log: [{ at: t, who: meta.agentName, what: `Built from the run of "${g.title}" on the template "${tpl.name}", on ${meta.basis}.` }],
      }
      set({ submissions: [sub, ...get().submissions.filter((x) => !(x.journeyId === meta.journeyId && x.delivId === meta.delivId))] })
      return id
    },

    rebuildDeliverable: (id, g, who, basis) =>
      patch(id, (s) => {
        const tpl = get().templates.find((x) => x.id === s.templateId)
        if (!tpl) return s
        const sug: SubmissionSuggestion = { id: s.delivId ?? s.id, label: s.title, audience: s.audience, purpose: s.purpose, template: s.template, templateId: tpl.id, why: '' }
        return { ...s, sections: sectionsFromTemplate(tpl, [g], sug), version: (s.version ?? 1) + 1, basis, stage: 'draft', reviewedBy: undefined, log: [...s.log, { at: now(), who, what: `Rebuilt as version ${(s.version ?? 1) + 1}, on ${basis}.` }] }
      }),

    setStage: (id, stage, who) =>
      patch(id, (s) => ({ ...s, stage, reviewedBy: stage === 'reviewed' ? who : s.reviewedBy, log: [...s.log, { at: now(), who, what: stage === 'reviewed' ? 'Marked the draft as reviewed.' : `Moved to ${stage}.` }] })),
  }
})
if (typeof window !== 'undefined') (window as unknown as { __cwSubs: unknown }).__cwSubs = useSubmissionStore
