import { installMockServer } from './install'

/*
 * Offline build: the API is served in the page (src/mock), routes live in the URL hash so the file
 * opens from disk or any static host, and the session starts signed in as Nishant Srivastav, the
 * Capital Program Analyst workspace for Northline Water Group. (The mock dataset key is unchanged.)
 */
installMockServer()
try {
  window.localStorage.setItem('contextweave.dataset', 'KEOLIS')
  if (!window.localStorage.getItem('contextweave.identity')) {
    window.localStorage.setItem(
      'contextweave.identity',
      JSON.stringify({
        state: {
          identity: {
            email: 'nishant.srivastav@vriodigital.com',
            name: 'Nishant Srivastav',
            roleId: 'business_user_exec',
            roleLabel: 'Business User -- Executive',
            accessNote: 'All contracts, all projects, all financials. The persona the executive walkthrough is written for.',
            initials: 'NS',
            signedInAt: new Date().toISOString(),
          },
        },
        version: 0,
      }),
    )
  }
} catch {
  /* Storage blocked: the app still runs, starting at the sign-in page. */
}
const ONLY = (import.meta as unknown as { env: Record<string, string | undefined> }).env?.VITE_CW_ONLY
if (!window.location.hash || window.location.hash === '#') window.location.hash = ONLY === 'submissions' ? '#/K/submissions' : ONLY === 'roles' ? '#/K/new-graph' : '#/K/goals'

