/*
 * Routes the console's API calls (`/api/backend/...`) to the in-browser server instead of the
 * network. Everything else (fonts, the framed documents) goes through untouched.
 */
import { handle } from './server'

const PREFIX = '/api/backend'

export function installMockServer() {
  const realFetch = window.fetch.bind(window)
  window.fetch = async (input, init = {}) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
    const at = url.indexOf(PREFIX)
    if (at < 0) return realFetch(input, init)
    const rest = url.slice(at + PREFIX.length)
    const qi = rest.indexOf('?')
    const path = qi >= 0 ? rest.slice(0, qi) : rest
    const query = new URLSearchParams(qi >= 0 ? rest.slice(qi + 1) : '')
    const method = (init.method || (typeof input !== 'string' && !(input instanceof URL) ? input.method : 'GET') || 'GET').toUpperCase()
    let body
    if (init.body) {
      try {
        body = JSON.parse(init.body)
      } catch {
        body = undefined
      }
    }
    /* A short, uneven delay, so loading states and spinners show as they do against the server. */
    await new Promise((r) => setTimeout(r, 60 + Math.random() * 140))
    let res
    try {
      res = await handle(method, path, query, body)
    } catch (e) {
      console.error('[offline server]', method, path, e)
      res = { status: 500, json: { error: `The offline server failed on ${method} ${path}: ${e && e.message}` } }
    }
    if (res.stream) {
      return new Response(res.stream, { status: res.status, headers: { 'content-type': res.contentType || 'text/event-stream' } })
    }
    return new Response(JSON.stringify(res.json), { status: res.status, headers: { 'content-type': 'application/json' } })
  }
}
