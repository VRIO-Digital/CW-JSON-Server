/*
 * In-browser stand-in for the ContextWeave mock server (CW-JSON-Server/backend), so the console runs
 * from a single static HTML file with no backend. It serves the Northline Water Group dataset (the
 * Veolia CAPEX demo world; the dataset key is unchanged) and the runtime state on 13 October 2026:
 * five connected sources, the committed Capital Program Analyst role with its structured, document
 * and Bridge builds, and graph version 1 published.
 *
 * Reads come from the dataset; writes change an in-memory copy of it, so connecting, building,
 * publishing and saving all work for the session and reset when the page is reloaded.
 */
import RAW_DB from './db.json'

const clone = (v) => JSON.parse(JSON.stringify(v))
const nowIso = () => new Date().toISOString()
const today = () => nowIso().slice(0, 10)
let seq = 0
const uid = (p = '') => {
  seq += 1
  const r = Math.random().toString(16).slice(2, 10)
  return `${p}${r}${seq.toString(16).padStart(4, '0')}`
}
const uuid = () =>
  'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16)
  })
const hash = (s) => {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619) >>> 0
  return h.toString(16).padStart(8, '0')
}

export const DATASET = 'KEOLIS'
const NS = 'nishant.srivastav@vriodigital.com'
const db = clone(RAW_DB)

/* ------------------------------------------------------------------ runtime state */

const MW = 'uc-capital-program-analyst-nw26a01'
const DRIVE = 'northline-capital-program'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const state = {
  startedAt: Date.now(),
  sources: [
    ...db.projects.map((p, i) => ({
      source_id: `azuresql:${p.project_id}`,
      source_name: p.display_name,
      connector: 'bigquery',
      status: 'connected',
      project_account: p.project_id,
      scope: `${p.datasets.length} dataset(s)`,
      connected_at: `2026-09-24T09:1${i}:08.514Z`,
      profiled_tables: 0,
      profiled_columns: 0,
      profiled_documents: null,
      profiled_entities: null,
      profiled_today: 0,
      profiled_today_date: '2026-09-24',
      documents_chunked: null,
      chunks_total: null,
      chunk_chars: null,
      last_chunk_at: null,
      last_chunk_count: null,
      last_chunk_since: '2026-03-24',
      datasets: p.datasets.map((d) => d.dataset_id),
      folders: [],
      labels: [],
      kind: 'bigquery',
      profilable: true,
      credential_handle: (db.credentials.find((c) => c.project_id === p.project_id) || {}).credential_handle || `cred-handle-${i}`,
      type_label: 'Azure SQL Database',
      profiled: p.datasets.flatMap((d) => d.tables.map((t) => `${d.dataset_id}.${t.table_id}`)).filter((key) => db.column_profiles[key]),
    })),
    {
      source_id: `onedrive:${DRIVE}`,
      source_name: 'Capital Program documents',
      connector: 'gdrive',
      status: 'connected',
      project_account: DRIVE,
      scope: `${db.drives[0].folders.length} folder(s)`,
      connected_at: '2026-09-24T09:18:52.710Z',
      profiled_tables: 0,
      profiled_columns: 0,
      profiled_documents: db.drives[0].folders.reduce((n, f) => n + f.documents.length, 0),
      profiled_entities: db.studio_graph.documents.entities.length,
      profiled_today: db.drives[0].folders.reduce((n, f) => n + f.documents.length, 0),
      profiled_today_date: '2026-09-24',
      documents_chunked: db.drives[0].folders.reduce((n, f) => n + f.documents.length, 0),
      chunks_total: db.drives[0].folders.reduce((n, f) => n + f.documents.reduce((m, d) => m + (d.chunk_count || 1), 0), 0),
      chunk_chars: 52000,
      last_chunk_at: '2026-09-24T09:21:38.531Z',
      last_chunk_count: 2,
      last_chunk_since: '2026-03-24',
      datasets: [],
      folders: db.drives[0].folders.map((f) => f.folder_id),
      labels: [],
      kind: 'gdrive',
      profilable: true,
      drive_id: DRIVE,
      credential_handle: 'drive-handle-ad0731d3',
      type_label: 'OneDrive',
      profiled: null,
    },
    {
      source_id: 'outlook:nishant.srivastav@vriodigital.com',
      source_name: 'Capital program mailbox',
      connector: 'gmail',
      status: 'connected',
      project_account: NS,
      scope: '1 label(s)',
      connected_at: '2026-09-24T09:19:27.812Z',
      profiled_tables: 0,
      profiled_columns: 0,
      profiled_documents: (db.mail_corpus?.documents || []).length,
      profiled_entities: 0,
      profiled_today: (db.mail_corpus?.documents || []).length,
      profiled_today_date: '2026-09-24',
      documents_chunked: (db.mail_corpus?.documents || []).length,
      chunks_total: (db.mail_corpus?.documents || []).length,
      chunk_chars: 9800,
      last_chunk_at: '2026-09-24T09:21:49.446Z',
      last_chunk_count: 1,
      last_chunk_since: '2026-03-24',
      datasets: [],
      folders: [],
      labels: ['Inbox'],
      kind: 'gmail',
      profilable: true,
      mailbox: NS,
      credential_handle: 'mail-handle-7c21d0e4',
      type_label: 'Outlook',
      profiled: null,
    },
  ],
  jobs: [],
  oauth: {},
  sgbBuilds: [],
  dgbBuilds: [],
  dgbJobs: [],
  bridgeBuilds: [],
  typeLinks: {},
  versions: [],
  playground: {},
  derivations: {},
  whatifSaved: [],
  savedReports: [],
  governanceRules: {},
  governanceReaders: {},
  governanceLog: [],
  columnNotes: {},
  documentNotes: {},
  mailNotes: {},
  storyEdits: {},
  metricEdits: {},
  personaNav: {},
  personaReports: {},
  unpublishedArtifacts: {},
}

/* The Capital Program Analyst role, built and published at 16:23-16:24 on 13 Oct. */
const SGB_STAGES = (state_ = 'complete') => [
  { stage: 'trigger_accepted', label: 'trigger_accepted', state: state_, detail: '202 accepted', steps: [{ step: 'resolve_use_case', state: state_ }, { step: 'pin_source_versions', state: state_ }] },
  { stage: 'structured_passes', label: 'structured_passes', state: state_, detail: null, steps: [{ step: 'p1_story', state: state_ }, { step: 'p2_assign_columns', state: state_ }, { step: 'p3_relate', state: state_ }] },
  { stage: 'persist_and_coverage', label: 'persist_and_coverage', state: state_, detail: null, steps: [{ step: 'materialise_nodes', state: state_ }, { step: 'materialise_edges', state: state_ }, { step: 'seal_build', state: state_ }] },
]
const BRIDGE_STAGES = (s = 'complete') => [
  { stage: 'read_lanes', label: 'Read both lanes', state: s },
  { stage: 'propose_links', label: 'Propose type links', state: s },
  { stage: 'write_links', label: 'Write links', state: s },
]
const DGB_STAGE_DEFS = [
  ['ingest', 'Read documents'],
  ['chunk', 'Chunk and embed'],
  ['extract', 'Extract entities and relations'],
  ['resolve', 'Resolve and canonicalise'],
  ['persist', 'Write the document graph'],
]

function seedMarginWatch() {
  const sg = db.studio_graph
  state.sgbBuilds.push({
    build_id: '956796a4-ecb9-4c7e-a70e-53a396aefaea',
    tenant_id: 'vrio',
    use_case_config_id: MW,
    version_id: `${MW}:v1`,
    metadata_package_version_id: null,
    status: 'complete',
    build_number: 1,
    name: 'Build v1',
    node_count: 22,
    relation_count: sg.structured.edges.length,
    table_count: sg.structured.tables.length,
    column_count: sg.structured.columns.length,
    concept_count: sg.structured.concepts.length,
    created_at: '2026-10-13T16:23:31.651Z',
    updated_at: '2026-10-13T16:23:42.857Z',
    published_at: '2026-10-13T16:24:03.312Z',
    published_by_user_id: NS,
    error_message: null,
    cursor: 8,
    step_total: 8,
    step_ms: 1400,
    stages: SGB_STAGES(),
    _startedMs: 0,
  })
  state.dgbBuilds.push({
    build_id: '6f0d2a51-5c3e-4b8a-9d7e-2b1f4c8a9e10',
    tenant_id: 'vrio',
    source_id: `onedrive:${DRIVE}`,
    document_corpus_id: MW,
    document_count: sg.documents.documents.length,
    entity_count: sg.documents.entities.length,
    relation_count: sg.documents.relations.length,
    class_count: sg.documents.classes.length,
    graph_version: 1,
    schema_version: 1,
    completed_at: '2026-10-13T16:23:36.452Z',
    publish_status: 'published',
    published_at: '2026-10-13T16:24:03.312Z',
    published_by_user_id: NS,
    superseded_at: null,
    superseded_by_graph_version: null,
    is_queryable: true,
  })
  const bb = {
    bridge_build_id: '132ca6b9-8375-4ca7-baf4-05f34c76bef3',
    use_case_config_id: MW,
    build_number: 1,
    sgb_build_id: '956796a4-ecb9-4c7e-a70e-53a396aefaea',
    document_corpus_id: MW,
    dgb_graph_version: 1,
    status: 'succeeded',
    created_at: '2026-10-13T16:23:42.858Z',
    updated_at: '2026-10-13T16:23:51.262Z',
    stage_ms: 700,
    model_calls_done: 12,
    model_calls_total: 12,
    concept_count: sg.structured.concepts.length,
    entity_type_count: sg.documents.entity_types.length,
    links_written: (sg.bridge.type_links || []).length,
    stages: BRIDGE_STAGES(),
  }
  state.bridgeBuilds.push(bb)
  state.typeLinks[bb.bridge_build_id] = (sg.bridge.type_links || []).map((t) => ({
    ...t,
    bridge_build_id: bb.bridge_build_id,
    decided_by: 'human',
    decided_by_user_id: NS,
    decided_at: '2026-10-13T16:24:01.372Z',
    created_at: '2026-10-13T16:23:51.262Z',
    updated_at: '2026-10-13T16:24:01.372Z',
  }))
  state.versions.push({
    graph_version_id: '16a97132-ee30-4b74-b3a1-a9612520229a',
    use_case_config_id: MW,
    version_number: 1,
    sgb_build_id: '956796a4-ecb9-4c7e-a70e-53a396aefaea',
    document_corpus_id: MW,
    dgb_graph_version: 1,
    bridge_build_id: '132ca6b9-8375-4ca7-baf4-05f34c76bef3',
    published_at: '2026-10-13T16:24:03.312Z',
    published_by_user_id: NS,
    created_at: '2026-10-13T16:23:52.752Z',
    created_by_user_id: null,
    _sha: '8a1422fc3b851e',
    _graph_id: 'g4ea01f8',
  })
  /* The three profiling runs that sit under Data Catalog -> Profiling jobs. */
  const src = state.sources
  state.jobs.push(
    ...src.filter((x) => x.kind === 'bigquery').map((x, i) => makeJob(x, 'table', x.profiled.map((k) => ({ parent_id: k.split('.')[0], object_id: k, label: k, units: (db.column_profiles[k] || []).length, state: 'profiled' })), { triggered_at: `2026-09-24T09:1${i}:20.114Z`, started_at: `2026-09-24T09:1${i}:21.300Z`, finished_at: `2026-09-24T09:1${i}:44.920Z`, status: 'complete' })),
    ...src.filter((x) => x.kind === 'gdrive').map((x) => makeJob(x, 'document', driveDocs(x).map(({ folder, doc }) => ({ parent_id: folder.folder_id, object_id: doc.document_id, label: doc.name, units: doc.pages, state: 'profiled' })), { triggered_at: '2026-09-24T09:21:02.700Z', started_at: '2026-09-24T09:21:03.880Z', finished_at: '2026-09-24T09:21:38.531Z', status: 'complete' })),
    ...src.filter((x) => x.kind === 'gmail').map((x) => makeJob(x, 'document', (db.mail_corpus?.documents || []).map((d) => ({ parent_id: d.label_id, object_id: d.document_id, label: d.name, units: null, state: 'profiled' })), { triggered_at: '2026-09-24T09:21:32.844Z', started_at: '2026-09-24T09:21:34.043Z', finished_at: '2026-09-24T09:21:49.446Z', status: 'complete', short_id: 'f63b5011' })),
  )
}

/* Leftovers from testing on the live demo are dropped so the file opens on the demo itself. */
db.graph_use_cases = (db.graph_use_cases || []).filter((u) => u.use_case_id === MW || (u.status === 'committed' && !/test/i.test(u.name)))

/* ------------------------------------------------------------------ helpers */

const connected = () => state.sources.filter((s) => s.status === 'connected')
const users = () => (db.settings.users || []).map((u) => ({ ...u, role_label: roleLabel(u.role_id) }))
const roleLabel = (roleId) => db.auth_roles.find((r) => r.role_id === roleId)?.label ?? roleId
const role = (roleId) => db.auth_roles.find((r) => r.role_id === roleId)
const userByEmail = (email) => users().find((u) => u.email.toLowerCase() === String(email || '').toLowerCase())
const initials = (name) => name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('')
const useCase = (id) => db.graph_use_cases.find((u) => u.use_case_id === id)
const publishedVersion = (uc) => state.versions.filter((v) => v.use_case_config_id === uc && v.published_at).sort((a, b) => b.version_number - a.version_number)[0] || null
const publishedUseCases = () => db.graph_use_cases.filter((u) => publishedVersion(u.use_case_id))
const builtUseCases = () => db.graph_use_cases.filter((u) => state.sgbBuilds.some((b) => b.use_case_config_id === u.use_case_id && b.status === 'complete') || state.dgbBuilds.some((b) => b.document_corpus_id === u.use_case_id))
const counts = () => ({
  connected_sources: connected().length,
  published_count: publishedUseCases().length,
  built_count: builtUseCases().length,
  draft_count: db.graph_use_cases.filter((u) => u.status === 'draft').length,
})
const sourceById = (id) => state.sources.find((s) => s.source_id === id)
const projectFor = (s) => db.projects.find((p) => p.project_id === s.project_account) || db.projects[0]
const driveFor = (s) => db.drives.find((d) => d.drive_id === (s.drive_id || s.project_account)) || db.drives[0]
function driveDocs(s) {
  const drive = driveFor(s)
  const out = []
  for (const folder of drive.folders) {
    if (s.folders?.length && !s.folders.includes(folder.folder_id)) continue
    for (const doc of folder.documents || []) out.push({ folder, doc })
  }
  return out
}
const mailDocs = () => db.mail_corpus?.documents || []
function tablesFor(s) {
  const project = projectFor(s)
  const out = []
  for (const ds of project.datasets) {
    if (s.datasets?.length && !s.datasets.includes(ds.dataset_id)) continue
    for (const t of ds.tables) out.push({ ds, t, key: `${ds.dataset_id}.${t.table_id}` })
  }
  return out
}
const isProfiledTable = (s, key) => (s.profiled ? s.profiled.includes(key) : !!db.column_profiles[key])

function sourceRow(s) {
  const { credential_handle, type_label, profiled, drive_id, mailbox, ...row } = s
  return row
}
function refreshSourceCounts(s) {
  if (s.kind === 'bigquery') {
    const keys = tablesFor(s).filter((x) => isProfiledTable(s, x.key)).map((x) => x.key)
    s.profiled_tables = keys.length
    s.profiled_columns = keys.reduce((n, k) => n + (db.column_profiles[k] || []).length, 0)
    s.profiled_today = s.profiled_tables
    s.scope = `${s.datasets.length} dataset(s)`
  } else if (s.kind === 'gdrive') {
    s.scope = `${s.folders.length} folder(s)`
  } else if (s.kind === 'gmail') {
    s.scope = `${s.labels.length} label(s)`
  }
}

/* Column facets, the same classes the profiler writes. */
const facetOf = (c) => {
  const cls = String(c.class || '')
  if (/identifier|_id$|key/.test(cls)) return 'ids'
  if (/amount|measure|price|cost|count|qty|quantity|rate|pct|percent|weight|currency|number/.test(cls)) return 'measures'
  if (/date|time|period|month|year/.test(cls)) return 'dates'
  if (/location|address|state|country|city|region|plant/.test(cls)) return 'location'
  if (/flag|bool|status|lifecycle|category|code/.test(cls)) return 'flags'
  return null
}

/* ------------------------------------------------------------------ views */

const viewSources = () => {
  state.sources.forEach(refreshSourceCounts)
  const rows = state.sources.map(sourceRow)
  const sum = (k) => rows.reduce((n, r) => n + (r[k] || 0), 0)
  return {
    sources: rows,
    registered_count: rows.length,
    connected_sources: connected().length,
    profiled_tables: sum('profiled_tables'),
    profiled_columns: sum('profiled_columns'),
    profiled_documents: sum('profiled_documents'),
    profiled_entities: sum('profiled_entities'),
    profiled_today: sum('profiled_today'),
    profiled_today_date: today() > '2026-10-13' ? '2026-10-13' : today(),
    documents_chunked: sum('documents_chunked'),
    chunks_total: sum('chunks_total'),
    chunk_chars: sum('chunk_chars'),
  }
}

function viewBrowse(s) {
  const project = projectFor(s)
  const datasets = project.datasets
    .filter((ds) => !s.datasets?.length || s.datasets.includes(ds.dataset_id))
    .map((ds) => ({
      dataset_id: ds.dataset_id,
      table_count: ds.tables.length,
      tables: ds.tables.map((t) => ({
        table_id: t.table_id,
        label: t.label,
        type: t.type,
        grain: t.grain,
        columns: t.columns,
        rows: t.rows ?? null,
        profiled: isProfiledTable(s, `${ds.dataset_id}.${t.table_id}`),
      })),
    }))
  return { source_id: s.source_id, datasets, dataset_count: datasets.length, object_count: datasets.reduce((n, d) => n + d.table_count, 0) }
}

function viewColumns(s) {
  const facets = { all: 0, needs_review: 0, pii: 0, ids: 0, measures: 0, dates: 0, location: 0, flags: 0 }
  const project = projectFor(s)
  const datasets = []
  for (const ds of project.datasets) {
    if (s.datasets?.length && !s.datasets.includes(ds.dataset_id)) continue
    const tables = []
    for (const t of ds.tables) {
      const key = `${ds.dataset_id}.${t.table_id}`
      if (!isProfiledTable(s, key)) continue
      const cols = (db.column_profiles[key] || []).map((c) => {
        const noteKey = `${key}.${c.column_id}`
        const description = noteKey in state.columnNotes ? state.columnNotes[noteKey] : c.description ?? null
        const facet = facetOf(c)
        const described = noteKey in state.columnNotes || (c.confidence ?? 0) >= 0.9
        const row = {
          column_id: c.column_id,
          label: c.label ?? c.column_id,
          type: c.type ?? null,
          class: c.class ?? 'unknown',
          facet,
          confidence: c.confidence ?? null,
          derivation: c.derivation ?? null,
          pii: !!c.pii,
          null_pct: c.null_pct ?? null,
          distinct: c.distinct ?? null,
          description,
          description_status: described ? 'described' : 'needs review',
        }
        facets.all += 1
        if (!described) facets.needs_review += 1
        if (row.pii) facets.pii += 1
        if (facet) facets[facet] += 1
        return row
      })
      tables.push({ table_id: t.table_id, label: t.label, type: t.type, grain: t.grain, rows: t.rows ?? null, column_count: cols.length, columns: cols })
    }
    if (tables.length) datasets.push({ dataset_id: ds.dataset_id, table_count: tables.length, column_count: tables.reduce((n, t) => n + t.column_count, 0), tables })
  }
  return { source_id: s.source_id, profiled_tables: datasets.reduce((n, d) => n + d.table_count, 0), dataset_count: datasets.length, facets, datasets }
}

function viewBrowseDocuments(s) {
  const drive = driveFor(s)
  const folders = drive.folders
    .filter((f) => !s.folders?.length || s.folders.includes(f.folder_id))
    .map((f) => ({
      folder_id: f.folder_id,
      name: f.name,
      path: f.path,
      document_count: (f.documents || []).length,
      documents: (f.documents || []).map((d) => ({
        document_id: d.document_id,
        name: d.name,
        mime_type: d.mime_type,
        doc_type: d.doc_type,
        doc_type_label: d.doc_type_label,
        linked_entity: d.linked_entity,
        pages: d.pages,
        size_mb: d.size_mb,
        entities: d.entities,
        modified: d.modified,
        chunks: s.documents_chunked ? d.chunk_count ?? null : null,
        size_chars: d.char_count ?? null,
        profiled: s.profiled_documents != null && s.profiled_documents > 0,
      })),
    }))
  return { source_id: s.source_id, folders, folder_count: folders.length, object_count: folders.reduce((n, f) => n + f.document_count, 0) }
}

const docEntities = (docId, count) => {
  const ex = db.document_extractions[docId] || []
  const rows = ex.map((e, i) => ({
    entity_id: e.extraction_id || `${docId}#${i}`,
    type: e.entity_type,
    class: String(e.entity_type || 'entity').toLowerCase(),
    confidence: e.confidence ?? 0.9,
    pii: /person|email/i.test(e.entity_type || ''),
    occurrences: e.linked_manifests ?? 1,
    coverage_pct: Math.round((e.confidence ?? 0.9) * 100),
  }))
  return rows.length ? rows : Array.from({ length: Math.min(count || 0, 6) }, (_, i) => ({ entity_id: `${docId}#e${i + 1}`, type: 'Entity', class: 'entity', confidence: 0.8, pii: false, occurrences: 1, coverage_pct: 80 }))
}

function viewDocuments(s) {
  const drive = driveFor(s)
  const typeCounts = {}
  let all = 0
  let needs = 0
  let pii = 0
  let entityTotal = 0
  const folders = []
  for (const f of drive.folders) {
    if (s.folders?.length && !s.folders.includes(f.folder_id)) continue
    let folderEntities = 0
    const documents = (f.documents || []).map((d) => {
      const ex = db.document_extractions[d.document_id] || []
      const first = ex[0]
      const ents = docEntities(d.document_id, d.entities)
      const key = `${f.folder_id}/${d.document_id}`
      const summary = key in state.documentNotes ? state.documentNotes[key] : null
      const piiCount = ents.filter((e) => e.pii).length
      all += 1
      if (!summary) needs += 1
      if (piiCount) pii += 1
      folderEntities += ents.length
      typeCounts[d.doc_type] = typeCounts[d.doc_type] || { key: d.doc_type, label: d.doc_type_label, count: 0 }
      typeCounts[d.doc_type].count += 1
      return {
        document_id: d.document_id,
        name: d.name,
        mime_type: d.mime_type,
        doc_type: d.doc_type,
        doc_type_label: d.doc_type_label,
        linked_entity: d.linked_entity,
        resolution: first
          ? { extraction_id: first.extraction_id, extracted_entity: first.extracted_entity, entity_type: first.entity_type, resolved_node: first.resolved_node, resolved_facility: first.resolved_facility, state: first.state, linked_manifests: first.linked_manifests ?? 0, confidence: first.confidence ?? 0 }
          : null,
        pages: d.pages,
        size_mb: d.size_mb,
        modified: d.modified,
        chunks: d.chunk_count ?? null,
        size_chars: d.char_count ?? null,
        snippet: d.excerpt ?? null,
        entity_count: ents.length,
        pii_count: piiCount,
        summary,
        summary_status: summary ? 'described' : 'needs review',
        entities: ents,
      }
    })
    entityTotal += folderEntities
    folders.push({ folder_id: f.folder_id, name: f.name, path: f.path, document_count: documents.length, entity_count: folderEntities, documents })
  }
  return {
    source_id: s.source_id,
    profiled_documents: all,
    folder_count: folders.length,
    entity_count: entityTotal,
    facets: { all, needs_review: needs, pii },
    type_facets: Object.values(typeCounts),
    folders,
  }
}

/* The mailbox export: ten EM-xx threads in the Inbox label. */
function mailMessages() {
  return mailDocs().map((d, i) => {
    const lines = String(d.snippet || '').split('\n')
    const subject = lines[1] || d.name.replace(/\.pdf$/, '')
    const fromName = lines[2] || 'Correspondent'
    const sent = /\d{4}-\d{2}-\d{2}T/.test(lines[3] || '') ? lines[3] : '2026-09-30T03:19:27.812Z'
    return {
      message_id: `inbox-${String(i + 1).padStart(3, '0')}`,
      thread_id: `inbox-t${String(i + 1).padStart(2, '0')}`,
      subject,
      from: `${fromName.toLowerCase().replace(/[^a-z]+/g, '.').replace(/^\.|\.$/g, '')}@correspondent.example`,
      from_name: fromName,
      to: NS,
      to_name: 'Nishant Srivastav',
      direction: 'received',
      labels: [d.label_id || 'Inbox'],
      received: sent,
      size_kb: Math.max(4, Math.round((d.size_chars || 1000) / 180)),
      document_count: 1,
      documents: [{ document_id: d.document_id, name: d.name, mime_type: d.mime_type, size_kb: Math.max(12, Math.round((d.size_chars || 1000) / 40)), entities: d.entities || 0, profiled: true }],
    }
  })
}
function viewBrowseMail(s) {
  const messages = mailMessages()
  const labels = (s.labels.length ? s.labels : ['Inbox']).map((l) => {
    const msgs = messages.filter((m) => m.labels.includes(l))
    return { label_id: l, name: l, message_count: msgs.length, document_count: msgs.reduce((n, m) => n + m.document_count, 0), messages: msgs }
  })
  return { source_id: s.source_id, labels, label_count: labels.length, message_count: messages.length, object_count: labels.reduce((n, l) => n + l.document_count, 0) }
}
function viewMailDocuments(s) {
  const msgs = mailMessages()
  let needs = 0
  let entityTotal = 0
  const labels = (s.labels.length ? s.labels : ['Inbox']).map((l) => {
    const docs = mailDocs()
      .filter((d) => (d.label_id || 'Inbox') === l)
      .map((d) => {
        const m = msgs.find((x) => x.documents[0].document_id === d.document_id)
        const key = `${l}/${d.document_id}`
        const summary = key in state.mailNotes ? state.mailNotes[key] : null
        if (!summary) needs += 1
        const ents = Array.from({ length: d.entities || 0 }, (_, i) => ({ entity_id: `${d.document_id.slice(0, 8)}#e${i + 1}`, type: ['Organization', 'Person', 'Date', 'MonetaryAmount', 'Percent', 'Product'][i % 6], class: ['organization', 'person', 'date', 'monetary_amount', 'percent', 'product_family'][i % 6], confidence: 0.86, pii: i % 6 === 1, occurrences: 1, coverage_pct: 86 }))
        entityTotal += ents.length
        return {
          document_id: d.document_id,
          name: d.name,
          mime_type: d.mime_type,
          size_kb: Math.max(12, Math.round((d.size_chars || 1000) / 40)),
          label: l,
          message_id: null,
          subject: null,
          from: null,
          from_name: null,
          to: null,
          to_name: null,
          direction: null,
          received: null,
          pages: d.pages ?? null,
          size_chars: d.size_chars ?? null,
          snippet: d.snippet ?? null,
          chunks: d.chunks ?? 1,
          entity_count: ents.length,
          pii_count: ents.filter((e) => e.pii).length,
          observation: true,
          summary,
          summary_status: summary ? 'described' : 'needs review',
          entities: ents,
          _m: m,
        }
      })
      .map(({ _m, ...d }) => d)
    return { label_id: l, name: l, document_count: docs.length, entity_count: docs.reduce((n, d) => n + d.entity_count, 0), documents: docs }
  })
  return {
    source_id: s.source_id,
    mailbox: s.mailbox || s.project_account,
    profiled_documents: labels.reduce((n, l) => n + l.document_count, 0),
    document_total: mailDocs().length,
    label_count: labels.length,
    entity_count: entityTotal,
    facets: { all: labels.reduce((n, l) => n + l.document_count, 0), needs_review: needs, pii: labels.reduce((n, l) => n + l.documents.filter((d) => d.pii_count).length, 0) },
    label_facets: labels.map((l) => ({ key: l.label_id, label: l.name, count: l.document_count })),
    labels,
  }
}

/* ------------------------------------------------------------------ profiling jobs */

const PIPELINES = {
  bigquery: ['Schema fetch', 'Column sampling', 'Classify columns', 'PII scan', 'Write catalogue'],
  gdrive: ['Reading documents', 'Extracting entities'],
  gmail: ['Reading documents', 'Extracting entities'],
}
function makeJob(s, unit, objects, extra = {}) {
  const stages = PIPELINES[s.kind] || PIPELINES.gdrive
  const id = uuid()
  return {
    job_id: id,
    short_id: id.slice(0, 8),
    source_id: s.source_id,
    kind: s.kind,
    unit,
    status: 'queued',
    stage_index: 0,
    stage_total: stages.length,
    stage_label: stages[0],
    stages,
    pipeline: stages.join(' → '),
    progress: 0,
    objects,
    object_count: objects.length,
    objects_done: 0,
    force: false,
    triggered_at: nowIso(),
    started_at: null,
    finished_at: null,
    elapsed_seconds: 0,
    triggered_by: NS,
    error: null,
    _t0: Date.now(),
    _dur: Math.max(4000, Math.min(14000, objects.length * 600)),
    ...extra,
  }
}
function tickJob(j) {
  if (j.status === 'complete' || j.status === 'cancelled' || j.status === 'failed') {
    if (j.status === 'complete') {
      j.progress = 100
      j.objects_done = j.object_count
      j.stage_index = j.stage_total - 1
      j.stage_label = j.stages[j.stage_total - 1]
      j.objects.forEach((o) => (o.state = 'profiled'))
      if (j.started_at && j.finished_at) j.elapsed_seconds = Math.round((Date.parse(j.finished_at) - Date.parse(j.started_at)) / 1000)
    }
    return j
  }
  const t = Date.now() - j._t0
  if (t < 600) return j
  j.status = 'running'
  j.started_at = j.started_at || new Date(j._t0 + 600).toISOString()
  const p = Math.min(1, (t - 600) / j._dur)
  j.progress = Math.round(p * 100)
  j.objects_done = Math.floor(p * j.object_count)
  j.objects.forEach((o, i) => (o.state = i < j.objects_done ? 'profiled' : 'pending'))
  j.stage_index = Math.min(j.stage_total - 1, Math.floor(p * j.stage_total))
  j.stage_label = j.stages[j.stage_index]
  j.elapsed_seconds = Math.round((t - 600) / 1000)
  if (p >= 1) {
    j.status = 'complete'
    j.finished_at = nowIso()
    finishJob(j)
    return tickJob(j)
  }
  return j
}
function finishJob(j) {
  const s = sourceById(j.source_id)
  if (!s) return
  if (s.kind === 'bigquery') {
    s.profiled = Array.from(new Set([...(s.profiled || []), ...j.objects.map((o) => o.object_id)]))
  } else if (s.kind === 'gdrive') {
    const docs = driveDocs(s)
    s.profiled_documents = docs.length
    s.documents_chunked = docs.length
    s.chunks_total = docs.reduce((n, x) => n + (x.doc.chunk_count || 1), 0)
    s.chunk_chars = docs.reduce((n, x) => n + (x.doc.char_count || 0), 0)
    s.profiled_entities = docs.reduce((n, x) => n + (x.doc.entities || 0), 0)
    s.profiled_today = docs.length
    s.last_chunk_at = nowIso()
    s.last_chunk_count = j.object_count
  } else if (s.kind === 'gmail') {
    s.profiled_documents = mailDocs().length
    s.documents_chunked = mailDocs().length
    s.chunks_total = mailDocs().reduce((n, d) => n + (d.chunks || 1), 0)
    s.chunk_chars = mailDocs().reduce((n, d) => n + (d.size_chars || 0), 0)
    s.profiled_today = mailDocs().length
    s.last_chunk_at = nowIso()
    s.last_chunk_count = 1
  }
}
const jobOut = (j) => {
  tickJob(j)
  const { _t0, _dur, ...rest } = j
  return clone(rest)
}
function viewJobs() {
  state.jobs.forEach(tickJob)
  const active = state.jobs.filter((j) => j.status === 'queued' || j.status === 'running').map(jobOut)
  const recent = state.jobs.filter((j) => !(j.status === 'queued' || j.status === 'running')).sort((a, b) => String(b.triggered_at).localeCompare(String(a.triggered_at))).map(jobOut)
  return {
    active,
    recent,
    active_count: active.length,
    recent_count: recent.length,
    status_line: active.length ? `${active.length} running · ${active[0].stage_label}` : 'idle — nothing running',
    pipelines: PIPELINES,
  }
}

/* ------------------------------------------------------------------ graph sources, domains, use cases */

function viewGraphSources() {
  const sources = connected().map((s) => {
    let objects = []
    let scope = []
    let scopeLabel = 'Datasets'
    let unit = 'tables'
    if (s.kind === 'bigquery') {
      objects = tablesFor(s).filter((x) => isProfiledTable(s, x.key)).map((x) => ({ object_id: x.key, parent_id: x.ds.dataset_id, label: x.key, units: (db.column_profiles[x.key] || []).length, unit_label: 'columns', pages: null, size_chars: null, snippet: null }))
      scope = s.datasets
    } else if (s.kind === 'gdrive') {
      objects = driveDocs(s).map(({ folder, doc }) => ({ object_id: doc.document_id, parent_id: folder.folder_id, label: doc.name, units: doc.pages, unit_label: 'pages', pages: doc.pages, size_chars: doc.char_count ?? null, snippet: doc.excerpt ?? null }))
      scope = s.folders.map((id) => driveFor(s).folders.find((f) => f.folder_id === id)?.name ?? id)
      scopeLabel = 'Folders'
      unit = 'documents'
    } else {
      objects = mailDocs().map((d) => ({ object_id: d.document_id, parent_id: d.label_id || 'Inbox', label: d.name, units: d.pages ?? 1, unit_label: 'pages', pages: d.pages ?? null, size_chars: d.size_chars ?? null, snippet: d.snippet ?? null }))
      scope = s.labels
      scopeLabel = 'Labels'
      unit = 'documents'
    }
    return {
      source_id: s.source_id,
      source_name: s.source_name,
      connector: s.connector,
      kind: s.kind,
      status: s.status,
      type_label: s.type_label || s.connector,
      account: s.project_account,
      scope_label: scopeLabel,
      scope,
      objects,
      object_count: objects.length,
      unit_label: unit,
      runtime: false,
    }
  })
  return { sources, source_count: sources.length, profiled_source_count: sources.filter((s) => s.object_count).length, runtime_source_count: 0 }
}

function viewDomains() {
  const objects = viewGraphSources().sources.reduce((n, s) => n + s.object_count, 0)
  const domains = db.graph_domains.map((d) => ({
    domain_id: d.domain_id,
    name: d.name,
    expected_sources: d.expected_sources,
    fit: d.fit,
    note: d.note,
    rank: d.rank,
    drafts: {
      personas: db.graph_personas.filter((p) => p.domains.includes(d.domain_id)).length,
      metrics: db.graph_metrics.filter((m) => m.domains.includes(d.domain_id)).length,
      hero_questions: db.graph_hero_questions.filter((q) => q.domains.includes(d.domain_id)).length,
    },
  }))
  return { domains, domain_count: domains.length, connected_sources: connected().length, profiled_objects: objects }
}

const STEPS = ['Role', 'Responsibilities', 'Sources', 'Personas', 'Metrics', 'Hero questions']
const ucOut = (u) => ({
  use_case_id: u.use_case_id,
  name: u.name,
  status: u.status,
  domain_id: u.domain_id ?? null,
  business_need: u.business_need ?? '',
  personas: u.personas || [],
  metrics: u.metrics || [],
  sources: u.sources || [],
  hero_questions: u.hero_questions || [],
  gap_decisions: u.gap_decisions || [],
  step: u.step ?? 1,
  step_total: STEPS.length,
  updated_at: u.updated_at ?? null,
  role: u.role ?? null,
})
const viewUseCases = () => ({
  use_cases: db.graph_use_cases.map(ucOut),
  count: db.graph_use_cases.length,
  draft_count: db.graph_use_cases.filter((u) => u.status === 'draft').length,
  committed_count: db.graph_use_cases.filter((u) => u.status === 'committed').length,
  steps: STEPS,
})

function suggestions(kind, body) {
  const domain = body?.domain_id
  const need = String(body?.business_need || '').toLowerCase()
  const fit = (x) => !domain || (x.domains || []).includes(domain)
  let rows = []
  /* Metrics and questions are drafted for the personas the role keeps: a row is offered when it matters to one of them (or when no persona is kept yet). */
  const kept = (body?.personas || []).map((p) => String(p.name || p).toLowerCase())
  const forKept = (names) => !kept.length || (names || []).some((n) => kept.includes(String(n).toLowerCase()))
  if (kind === 'personas') rows = db.graph_personas.filter(fit).map((p) => ({ id: p.persona_id, name: p.name, detail: p.focus, why: `Asks ${p.top_questions.length} of the drafted hero questions for this role.`, priority: null }))
  if (kind === 'metrics') rows = db.graph_metrics.filter(fit).filter((m) => forKept(m.personas)).map((m) => ({ id: m.metric_id, name: state.metricEdits[m.metric_id]?.name ?? m.name, detail: state.metricEdits[m.metric_id]?.definition ?? m.definition, why: `Matters to ${(m.personas || []).join(', ')}.`, priority: null }))
  if (kind === 'questions') rows = db.graph_hero_questions.filter(fit).filter((q) => forKept([q.persona])).map((q, i) => ({ id: q.question_id, name: q.text, detail: q.persona ? `Asked by the ${q.persona}.` : '', why: q.rationale, priority: q.priority || (i < 6 ? 'high' : 'normal') }))
  if (need && !kept.length) {
    const words = need.split(/\W+/).filter((w) => w.length > 3)
    rows.sort((a, b) => score(b, words) - score(a, words))
  }
  const domainName = db.graph_domains.find((d) => d.domain_id === domain)?.name
  return {
    suggestions: rows,
    count: rows.length,
    derived_from: domainName ? `the role's responsibilities and your connected sources` : 'your connected sources',
    empty_reason: rows.length ? null : 'Nothing in the connected sources supports this domain, so nothing is drafted.',
    run: { stages: ['Read the role and its responsibilities', 'Read the profiled sources', 'Draft'], cost_usd: 0.03, cost_cap_usd: 0.5 },
  }
}
const score = (r, words) => words.reduce((n, w) => n + ((r.name + ' ' + r.detail).toLowerCase().includes(w) ? 1 : 0), 0)

function coverage(body) {
  const sg = db.studio_graph.structured
  const qs = body?.hero_questions || []
  const picked = (body?.sources || []).map((p) => sourceById(p.source_id)).filter(Boolean)
  const elements = sg.concepts.map((c, i) => ({
    element_id: c.concept_ref,
    name: c.name.replace(/_/g, ' '),
    kind: 'entity',
    status: 'backed',
    confidence: Math.round((0.95 - (i % 5) * 0.03) * 100) / 100,
    evidence: `${sg.columns.filter((x) => x.concept_name === c.name).length} declared columns`,
    reason: null,
  }))
  const relEdges = sg.edges.filter((e) => e.src_kind === 'Concept' && e.dst_kind === 'Concept').slice(0, 10)
  relEdges.forEach((e, i) =>
    elements.push({ element_id: `rel:${i}`, name: `${e.src_ref.split(':').pop()} ${e.edge_type.toLowerCase().replace(/_/g, ' ')} ${e.dst_ref.split(':').pop()}`, kind: 'relationship', status: 'backed', confidence: 0.84, evidence: 'Declared on the Data Modeling tab', reason: null }),
  )
  elements.push({ element_id: 'gap:schedule', name: 'Schedules and critical path', kind: 'entity', status: 'gap', confidence: 0.2, evidence: null, reason: 'Primavera P6 is not connected; schedule and critical path questions are declined.' })
  if (picked.some((s) => s.kind === 'gmail')) elements.push({ element_id: 'runtime:mail', name: 'Project manager and contractor correspondence', kind: 'entity', status: 'runtime', confidence: 0.7, evidence: 'Read at question time from the mailbox', reason: null })
  const runtime = picked.filter((s) => s.kind === 'gmail').map((s) => ({ source_id: s.source_id, source_name: s.source_name, type_label: s.type_label || 'Mailbox', scope: s.labels.length, scope_label: 'labels' }))
  return {
    title: body?.name || 'New graph',
    entity_count: elements.filter((e) => e.kind === 'entity' && e.status !== 'gap').length,
    relationship_count: elements.filter((e) => e.kind === 'relationship').length,
    hero_question_count: qs.length,
    gap_count: elements.filter((e) => e.status === 'gap').length,
    runtime_question_count: runtime.length ? Math.min(qs.length, 2) : 0,
    object_count: viewGraphSources().sources.filter((s) => picked.some((p) => p.source_id === s.source_id)).reduce((n, s) => n + s.object_count, 0),
    elements,
    runtime_sources: runtime,
    runtime_note: runtime.length ? 'Mail is read when a question is asked, never copied into the graph.' : null,
  }
}

const DERIVATION_STAGES = ['Read the selected sources', 'Match entities to concepts', 'Walk the hero questions', 'Write the coverage']
function derivationOut(d) {
  const t = Date.now() - d.t0
  const total = 5200
  const p = Math.min(1, t / total)
  const idx = Math.min(DERIVATION_STAGES.length - 1, Math.floor(p * DERIVATION_STAGES.length))
  const names = d.coverage.elements.map((e) => e.name)
  return {
    derivation_id: d.id,
    status: p >= 1 ? 'complete' : 'running',
    stage_index: idx,
    stage_total: DERIVATION_STAGES.length,
    stage_label: DERIVATION_STAGES[idx],
    stages: DERIVATION_STAGES,
    progress: Math.round(p * 100),
    revealed: names.slice(0, Math.ceil(p * names.length)),
    entity_total: names.length,
    cost_usd: Math.round(p * 0.21 * 100) / 100,
    cost_cap_usd: 1,
    coverage: p >= 1 ? d.coverage : null,
  }
}

function questionSql(body) {
  /* A question or metric the role's pools define carries its own governed query. */
  const asked = String(body?.question || '').trim().toLowerCase()
  const authored = db.graph_hero_questions.find((x) => x.text.toLowerCase() === asked && x.sql) || db.graph_metrics.find((x) => asked.startsWith(x.name.toLowerCase()) && x.sql)
  if (authored) {
    const tables = [...new Set((authored.sql.match(/\b(?:epbcs|gl|commitments|assets|pmo|upload)\.[a-z_]+/g) || []))]
    return { sql: authored.sql, reason: null, table: tables[0] || null, columns: [], degraded: false, tables_considered: Object.keys(db.column_profiles).length }
  }
  const q = String(body?.question || '').toLowerCase()
  const words = q.split(/\W+/).filter((w) => w.length > 3)
  let best = null
  for (const [key, cols] of Object.entries(db.column_profiles)) {
    const hay = (key + ' ' + cols.map((c) => c.column_id + ' ' + (c.description || '')).join(' ')).toLowerCase()
    const sc = words.reduce((n, w) => n + (hay.includes(w) ? 1 : 0), 0)
    if (!best || sc > best.sc) best = { key, cols, sc }
  }
  if (!best || best.sc === 0) return { sql: null, reason: 'No profiled table carries the words in this question.', table: null, columns: [], degraded: false, tables_considered: Object.keys(db.column_profiles).length }
  const cols = best.cols.filter((c) => words.some((w) => (c.column_id + ' ' + (c.description || '')).toLowerCase().includes(w))).slice(0, 5)
  const use = (cols.length ? cols : best.cols.slice(0, 3)).map((c) => c.column_id)
  const [ds, t] = best.key.split('.')
  return { sql: `SELECT ${use.join(', ')}\nFROM ${ds}.${t}`, reason: null, table: best.key, columns: use, degraded: false, tables_considered: Object.keys(db.column_profiles).length }
}

/* ------------------------------------------------------------------ studio: SGB, DGB, Bridge, versions */

const studioConfig = (u) => {
  const srcs = (u.sources || []).map((p) => sourceById(p.source_id)).filter(Boolean)
  const hasStructured = srcs.some((s) => s.kind === 'bigquery')
  const hasDocs = srcs.some((s) => s.kind === 'gdrive' || s.kind === 'gmail')
  const docCount = srcs.filter((s) => s.kind === 'gdrive').reduce((n, s) => n + driveDocs(s).length, 0)
  const tableCount = srcs.filter((s) => s.kind === 'bigquery').reduce((n, s) => n + tablesFor(s).filter((x) => isProfiledTable(s, x.key)).length, 0)
  return { srcs, hasStructured, hasDocs, docCount, tableCount: Math.min(tableCount, db.studio_graph.structured.tables.length) || tableCount }
}
const viewConfigs = () => ({
  configs: db.graph_use_cases.map((u) => {
    const c = studioConfig(u)
    const v = publishedVersion(u.use_case_id)
    return {
      use_case_config_id: u.use_case_id,
      name: u.name,
      domain: u.domain_id ?? null,
      status: u.status,
      has_structured: c.hasStructured,
      has_documents: c.hasDocs,
      document_count: c.docCount,
      structured_table_count: c.tableCount,
      latest_committed_version_id: u.status === 'committed' ? `${u.use_case_id}:v1` : null,
      updated_at: u.updated_at ?? null,
      _v: v ? 1 : 0,
    }
  }).map(({ _v, ...r }) => r),
  connected_sources: connected().length,
})
const viewConfig = (u) => {
  const c = studioConfig(u)
  return {
    use_case_config_id: u.use_case_id,
    name: u.name,
    domain: u.domain_id ?? null,
    status: u.status,
    business_need: u.business_need ?? '',
    required_sources: (u.sources || []).map((s) => s.source_id),
    has_structured: c.hasStructured,
    has_documents: c.hasDocs,
    document_count: c.docCount,
    structured_table_count: c.tableCount,
  }
}

function sgbTick(b) {
  if (b.status !== 'running') return b
  const t = Date.now() - b._startedMs
  const cursor = Math.min(b.step_total, Math.floor(t / b.step_ms))
  b.cursor = cursor
  let n = 0
  b.stages.forEach((st) => {
    st.steps.forEach((sp) => {
      sp.state = n < cursor ? 'complete' : n === cursor ? 'running' : 'pending'
      n += 1
    })
    st.state = st.steps.every((s) => s.state === 'complete') ? 'complete' : st.steps.some((s) => s.state !== 'pending') ? 'running' : 'pending'
  })
  b.updated_at = nowIso()
  if (cursor >= b.step_total) {
    b.status = 'complete'
    b.stages = SGB_STAGES()
  }
  return b
}
const sgbOut = (b) => {
  sgbTick(b)
  const { _startedMs, ...r } = b
  return clone(r)
}
function startSgb(ucId, story) {
  const sg = db.studio_graph.structured
  const n = state.sgbBuilds.filter((b) => b.use_case_config_id === ucId).length + 1
  const b = {
    build_id: uuid(),
    tenant_id: 'vrio',
    use_case_config_id: ucId,
    version_id: `${ucId}:v1`,
    metadata_package_version_id: null,
    status: 'running',
    build_number: n,
    name: `Build v${n}`,
    node_count: 22,
    relation_count: sg.edges.length,
    table_count: sg.tables.length,
    column_count: sg.columns.length,
    concept_count: sg.concepts.length,
    created_at: nowIso(),
    updated_at: nowIso(),
    published_at: null,
    published_by_user_id: null,
    error_message: null,
    cursor: 0,
    step_total: 8,
    step_ms: 900,
    stages: SGB_STAGES('pending'),
    _startedMs: Date.now(),
  }
  if (story) state.storyEdits[b.build_id] = story
  state.sgbBuilds.push(b)
  return b
}

function dgbJobTick(j) {
  if (j.status === 'succeeded') return j
  const t = Date.now() - j._t0
  const per = 1300
  const idx = Math.floor(t / per)
  j.stages.forEach((s, i) => (s.state = i < idx ? 'complete' : i === idx ? 'running' : 'pending'))
  j.documents_processed = Math.min(j.document_total, Math.round((t / (per * j.stages.length)) * j.document_total))
  j.phase = idx < j.stages.length ? { stage: j.stages[idx].stage, phase: 'working', since: j._t0 + idx * per } : null
  if (idx >= j.stages.length) {
    j.status = 'succeeded'
    j.completed_at = nowIso()
    j.documents_processed = j.document_total
    j.stages.forEach((s) => (s.state = 'complete'))
    j.phase = null
    const sg = db.studio_graph.documents
    const prev = state.dgbBuilds.filter((b) => b.document_corpus_id === j.corpus)
    prev.forEach((b) => {
      if (b.publish_status === 'unpublished') b.publish_status = 'superseded'
    })
    const gv = prev.reduce((m, b) => Math.max(m, b.graph_version), 0) + 1
    state.dgbBuilds.push({
      build_id: uuid(),
      tenant_id: 'vrio',
      source_id: `onedrive:${DRIVE}`,
      document_corpus_id: j.corpus,
      document_count: j.document_total,
      entity_count: sg.entities.length,
      relation_count: sg.relations.length,
      class_count: sg.classes.length,
      graph_version: gv,
      schema_version: 1,
      completed_at: j.completed_at,
      publish_status: 'unpublished',
      published_at: null,
      published_by_user_id: null,
      superseded_at: null,
      superseded_by_graph_version: null,
      is_queryable: true,
    })
    if (j.bridgeFollows) startBridge(j.corpus)
  }
  return j
}
const dgbJobOut = (j) => {
  dgbJobTick(j)
  const { _t0, corpus, bridgeFollows, ...r } = j
  return clone(r)
}
function startDgb(ucId, bridgeFollows = false) {
  const u = useCase(ucId)
  const c = studioConfig(u)
  const j = {
    job_id: uuid(),
    status: 'running',
    documents_processed: 0,
    document_total: c.docCount || db.studio_graph.documents.documents.length,
    created_at: nowIso(),
    completed_at: null,
    stage_ms: 1300,
    stages: DGB_STAGE_DEFS.map(([stage, label]) => ({ stage, label, state: 'pending', counts: null })),
    phase: null,
    _t0: Date.now(),
    corpus: ucId,
    bridgeFollows,
  }
  state.dgbJobs.push(j)
  return j
}

function bridgeTick(b) {
  if (b.status !== 'running') return b
  const t = Date.now() - b._t0
  const idx = Math.floor(t / 1500)
  b.stages.forEach((s, i) => (s.state = i < idx ? 'complete' : i === idx ? 'running' : 'pending'))
  b.model_calls_done = Math.min(b.model_calls_total, Math.round((t / 4500) * b.model_calls_total))
  b.updated_at = nowIso()
  if (idx >= b.stages.length) {
    b.status = 'succeeded'
    b.model_calls_done = b.model_calls_total
    b.stages.forEach((s) => (s.state = 'complete'))
    b.links_written = (db.studio_graph.bridge.type_links || []).length
  }
  return b
}
const bridgeOut = (b) => {
  bridgeTick(b)
  const { _t0, ...r } = b
  return clone(r)
}
function latestSgb(ucId) {
  return state.sgbBuilds.filter((b) => b.use_case_config_id === ucId).map(sgbTick).sort((a, b) => b.build_number - a.build_number)[0] || null
}
function latestDgb(ucId) {
  state.dgbJobs.forEach(dgbJobTick)
  return state.dgbBuilds.filter((b) => b.document_corpus_id === ucId).sort((a, b) => b.graph_version - a.graph_version)[0] || null
}
function startBridge(ucId) {
  const sgb = latestSgb(ucId)
  const dgb = latestDgb(ucId)
  const n = state.bridgeBuilds.filter((b) => b.use_case_config_id === ucId).length + 1
  const sg = db.studio_graph
  const b = {
    bridge_build_id: uuid(),
    use_case_config_id: ucId,
    build_number: n,
    sgb_build_id: sgb?.build_id || '',
    document_corpus_id: ucId,
    dgb_graph_version: dgb?.graph_version || 1,
    status: 'running',
    created_at: nowIso(),
    updated_at: nowIso(),
    stage_ms: 1500,
    model_calls_done: 0,
    model_calls_total: 12,
    concept_count: sg.structured.concepts.length,
    entity_type_count: sg.documents.entity_types.length,
    links_written: 0,
    stages: BRIDGE_STAGES('pending'),
    _t0: Date.now(),
  }
  state.bridgeBuilds.push(b)
  state.typeLinks[b.bridge_build_id] = (sg.bridge.type_links || []).map((t) => ({
    ...t,
    type_link_id: uuid(),
    bridge_build_id: b.bridge_build_id,
    decided_by: 'llm',
    decided_by_user_id: null,
    decided_at: null,
    created_at: nowIso(),
    updated_at: nowIso(),
  }))
  return b
}
const unreviewed = (links) => links.filter((l) => l.decided_by !== 'human').length

const versionOut = (v) => {
  const { _sha, _graph_id, ...r } = v
  return clone(r)
}
function reconcile(ucId) {
  const sgb = latestSgb(ucId)
  const dgb = latestDgb(ucId)
  const bridge = state.bridgeBuilds.filter((b) => b.use_case_config_id === ucId).map(bridgeTick).sort((a, b) => b.build_number - a.build_number)[0]
  if (!sgb || sgb.status !== 'complete') return publishedVersion(ucId) || null
  const busy = state.dgbJobs.some((j) => j.corpus === ucId && dgbJobTick(j).status !== 'succeeded') || state.bridgeBuilds.some((b) => b.use_case_config_id === ucId && bridgeTick(b).status === 'running')
  if (busy) return state.versions.filter((v) => v.use_case_config_id === ucId).sort((a, b) => b.version_number - a.version_number)[0] || null
  const latest = state.versions.filter((v) => v.use_case_config_id === ucId).sort((a, b) => b.version_number - a.version_number)[0]
  const triple = [sgb.build_id, dgb?.graph_version ?? null, bridge && bridge.status === 'succeeded' ? bridge.bridge_build_id : null]
  if (latest && latest.sgb_build_id === triple[0] && latest.dgb_graph_version === triple[1] && latest.bridge_build_id === triple[2]) return latest
  const v = {
    graph_version_id: uuid(),
    use_case_config_id: ucId,
    version_number: (latest?.version_number || 0) + 1,
    sgb_build_id: triple[0],
    document_corpus_id: dgb ? ucId : null,
    dgb_graph_version: triple[1],
    bridge_build_id: triple[2],
    published_at: null,
    published_by_user_id: null,
    created_at: nowIso(),
    created_by_user_id: null,
    _sha: hash(triple.join('|')).slice(0, 14).padEnd(14, '0'),
    _graph_id: 'g' + hash(ucId).slice(0, 7),
  }
  state.versions.push(v)
  return v
}

function viewPlayground(ucId) {
  const u = useCase(ucId)
  const pg = state.playground[ucId]
  const base = {
    use_case_config_id: ucId,
    metrics: (u?.metrics || []).map((m) => ({ name: m.name, description: m.description, source: m.source || 'ai', origin: m.origin ?? null, sql: m.sql ?? questionSql({ question: m.name + ' ' + m.description }).sql, sql_note: null })),
    golden_queries: (u?.hero_questions || []).map((q) => ({ text: q.text, priority: q.priority || 'normal', source: q.source || 'ai', sql: q.sql ?? questionSql({ question: q.text }).sql })),
    files: [],
    query_cap: 50,
    file_cap: 10,
  }
  return pg ? { ...base, ...pg } : base
}

/* ------------------------------------------------------------------ Ask */

const graphCounts = () => {
  const sg = db.studio_graph
  return { entity_count: 22 + sg.documents.entities.length, relationship_count: sg.structured.edges.length + sg.documents.relations.length + (sg.bridge.type_links || []).filter((t) => t.decision !== 'reject').length }
}
const MAIL_QS = () => db.ask_answers.filter((a) => a.citations.some((c) => c.kind === 'correspondence')).map((a) => a.question)
const ANSWER_FORMATS = () => db.graph_answer_formats.map((f) => ({ format_id: f.format_id, name: f.name, format: f.format }))
function viewAsk() {
  const graphs = publishedUseCases().map((u) => {
    const v = publishedVersion(u.use_case_id)
    return {
      use_case_id: u.use_case_id,
      name: u.name,
      domain_id: u.domain_id ?? null,
      version: `v${v.version_number}`,
      published_at: v.created_at,
      published_by: v.published_by_user_id,
      graph_id: v._graph_id,
      sha256: v._sha,
      caveats: [],
      suggested_questions: (u.hero_questions || []).map((q) => q.text).slice(0, 3),
      ...graphCounts(),
    }
  })
  const sources = connected()
    .filter((s) => s.kind === 'gmail')
    .map((s) => ({ source_id: s.source_id, name: s.source_name, kind: s.kind, connector: s.connector, account: s.project_account, scope: s.scope, suggested_questions: MAIL_QS() }))
  return {
    graphs,
    count: graphs.length,
    sources,
    source_count: sources.length,
    built_count: builtUseCases().length,
    draft_count: counts().draft_count,
    answer_requirements: {
      citations_options: [
        { value: 'required', label: 'Every figure must cite its source' },
        { value: 'optional', label: 'Cite where a source exists' },
      ],
      default_citations: 'required',
      formats: ANSWER_FORMATS(),
      note: 'A requirement travels with the question; the graph does not change.',
    },
  }
}

const STOP = new Set('the a an and or of to in on for by with is are was were be been what which who whom how why when where does do did we our us it its this that these those from at as than then there their they them can could would should will shall may might much many any all each per vs versus between into over under about after before during if not no yes so me my you your i'.split(' '))
const stem = (w) => w.replace(/(ing|ed|es|s)$/, '')
const tokens = (s) => String(s).toLowerCase().replace(/[^a-z0-9%.$ ]+/g, ' ').split(/\s+/).filter((w) => w && !STOP.has(w)).map(stem)
let INDEX = null
function buildIndex() {
  const docs = db.ask_answers.map((a) => {
    const tf = {}
    const add = (text, w) => tokens(text).forEach((t) => (tf[t] = (tf[t] || 0) + w))
    add(a.question, 3)
    add(a.summary || '', 1)
    add(a.persona || '', 0.5)
    ;(a.blocks || []).slice(0, 2).forEach((b) => b.type === 'text' && add(b.markdown, 0.4))
    return { a, tf }
  })
  const df = {}
  docs.forEach((d) => Object.keys(d.tf).forEach((t) => (df[t] = (df[t] || 0) + 1)))
  const N = docs.length
  const idf = (t) => Math.log(1 + N / (df[t] || 0.5))
  docs.forEach((d) => {
    d.vec = {}
    let n = 0
    Object.entries(d.tf).forEach(([t, f]) => {
      d.vec[t] = f * idf(t)
      n += d.vec[t] ** 2
    })
    d.norm = Math.sqrt(n) || 1
  })
  INDEX = { docs, idf }
}
function bestAnswer(question) {
  const q = String(question).trim().toLowerCase()
  const exact = db.ask_answers.find((a) => a.question.trim().toLowerCase() === q)
  if (exact) return { a: exact, score: 1 }
  if (!INDEX) buildIndex()
  const SYN = { gap: ['drop', 'below'], ton: ['cover', 'hold', 'week'], steel: ['hrc', 'index'], cost: ['price'], recover: ['recoverable', 'refund'], refund: ['ieepa', 'recoverable'], lebanon: ['plant', 'move'], competitor: ['competitor'], forecast: ['will', 'next'] }
  const qv = {}
  tokens(question).forEach((t) => {
    qv[t] = (qv[t] || 0) + INDEX.idf(t)
    ;(SYN[t] || []).map(stem).forEach((x) => (qv[x] = (qv[x] || 0) + 0.5 * INDEX.idf(x)))
  })
  const qn = Math.sqrt(Object.values(qv).reduce((n, v) => n + v * v, 0)) || 1
  let best = null
  for (const d of INDEX.docs) {
    let dot = 0
    for (const [t, v] of Object.entries(qv)) if (d.vec[t]) dot += v * d.vec[t]
    const sc = dot / (qn * d.norm)
    if (!best || sc > best.score) best = { a: d.a, score: sc }
  }
  return best && best.score >= 0.13 ? best : null
}

const REASONING = (a, graphName, matched) => {
  const sourcesRead = Array.from(new Set(a.citations.filter((c) => c.kind !== 'graph').map((c) => c.label)))
  if (a.kind === 'decline') {
    return [
      { step: 'Understand', detail: matched ? `Read as: "${a.question}"` : 'Read the question against the published graph.' },
      { step: 'Refuse', detail: a.summary },
    ]
  }
  return [
    { step: 'Understand', detail: `Read as: "${a.question}"${a.persona ? ` (a ${a.persona} question)` : ''}.` },
    { step: 'Plan', detail: `Resolve ${a.graph_refs.slice(0, 4).join(', ')}${a.graph_refs.length > 4 ? ' and more' : ''} in ${graphName}.` },
    { step: 'Dispatch', detail: sourcesRead.length ? `Read ${sourcesRead.slice(0, 4).join(', ')}${sourcesRead.length > 4 ? ` and ${sourcesRead.length - 4} more` : ''}.` : 'Read the graph only.' },
    { step: 'Verify', detail: `${a.citations.length} citation(s) checked; confidence ${a.confidence_level || 'High'} (${a.confidence}).` },
    { step: 'Synthesize', detail: `${a.blocks.length} block(s) composed from the evidence; nothing is written back.` },
  ]
}

function composeAnswer(body) {
  const ucId = body?.use_case_id || null
  const u = ucId ? useCase(ucId) : null
  const v = ucId ? publishedVersion(ucId) : null
  const graphName = u ? `${u.name} v${v?.version_number ?? 1}` : null
  const match = bestAnswer(body?.question || '')
  const citations = body?.citations || 'required'
  const formats = ANSWER_FORMATS().filter((f) => (body?.formats || []).includes(f.format_id))
  const askedAt = nowIso()
  if (!match) {
    const reason =
      'This question is not one the published graph has been built to answer. In this offline copy, Ask is not part of the demo.'
    return {
      stages: [
        { step: 'Understand', detail: 'Read the question against the published graph.' },
        { step: 'Refuse', detail: 'No concept or measure in the graph matches the question closely enough to answer it.' },
      ],
      answer: {
        question: body?.question || '',
        use_case_id: ucId,
        graph_name: u?.name ?? null,
        version: v ? `v${v.version_number}` : null,
        source_ids: body?.source_ids || [],
        answered: false,
        reason,
        answer: null,
        confidence: null,
        entities: [],
        path: [],
        hops: 0,
        reasoning: [
          { step: 'Understand', detail: 'Read the question against the published graph.' },
          { step: 'Refuse', detail: 'No concept or measure in the graph matches the question closely enough to answer it.' },
        ],
        citations: [],
        caveats: [],
        asked_at: askedAt,
        summary: null,
        blocks: [],
        answer_id: null,
        requirements: { citations, formats, satisfied: true, note: 'Nothing was answered, so there is nothing to cite.' },
      },
    }
  }
  const a = match.a
  const answered = a.kind !== 'decline'
  const reasoning = REASONING(a, graphName || 'the graph', match.score < 1)
  const cites = a.citations.map((c) => ({ label: c.label, detail: c.detail, confidence: c.confidence ?? null, kind: c.kind ?? null, source_id: c.source_id ?? null, runtime: c.runtime ?? null, as_of: c.as_of ?? null, authoritative: c.authoritative ?? null, why_not_authoritative: c.why_not_authoritative ?? null, n: c.n ?? null }))
  const blocks = a.blocks.map((b) => (b.type === 'chart' ? { x_label: null, y_label: null, note: null, ...b } : b))
  return {
    stages: reasoning,
    answer: {
      question: body?.question || a.question,
      use_case_id: ucId,
      graph_name: u?.name ?? null,
      version: v ? `v${v.version_number}` : null,
      source_ids: body?.source_ids || [],
      answered,
      reason: answered ? `Answered from ${graphName || 'the connected sources'}.` : a.summary,
      answer: answered ? a.summary : null,
      confidence: a.confidence ?? null,
      entities: a.graph_refs || [],
      path: a.graph_refs || [],
      hops: Math.max(0, (a.graph_refs || []).length - 1),
      reasoning,
      citations: cites,
      caveats: [],
      asked_at: askedAt,
      summary: a.summary,
      blocks,
      answer_id: a.answer_id,
      requirements: {
        citations,
        formats,
        satisfied: citations === 'optional' || cites.length > 0 || !answered,
        note: citations === 'required' ? (cites.length ? `${cites.length} source(s) cited.` : 'Declined, so nothing needed citing.') : 'Citations shown where a source exists.',
      },
    },
  }
}

function askStream(body) {
  const { stages, answer } = composeAnswer(body)
  const enc = new TextEncoder()
  const frame = (event, data) => enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
  const wait = (ms) => new Promise((r) => setTimeout(r, ms))
  return new ReadableStream({
    async start(controller) {
      for (const s of stages) {
        await wait(420)
        controller.enqueue(frame('stage', s))
      }
      await wait(350)
      controller.enqueue(frame('summary', { answered: answer.answered, summary: answer.summary, reason: answer.reason, answer: answer.answer, block_count: answer.blocks.length }))
      for (let i = 0; i < answer.blocks.length; i++) {
        await wait(260)
        controller.enqueue(frame('block', { index: i, block: answer.blocks[i] }))
      }
      await wait(150)
      controller.enqueue(frame('done', answer))
      controller.close()
    },
  })
}

/* ------------------------------------------------------------------ What-if, reports, governance */

const readers = () => users().map((u) => ({ email: u.email, name: u.name, role_id: u.role_id, role_label: u.role_label, access_note: role(u.role_id)?.access_note ?? '' }))
const reportGraph = (u) => {
  const v = publishedVersion(u.use_case_id)
  return { use_case_id: u.use_case_id, name: u.name, domain_id: u.domain_id ?? null, version: `v${v.version_number}`, sha256: v._sha, built_at: v.created_at, published_by: v.published_by_user_id, ...graphCounts() }
}
function viewWhatif() {
  const w = db.whatif
  return {
    ...counts(),
    ...clone(w),
    headroom: Array.isArray(w.headroom) ? clone(w.headroom) : [],
    generators: Array.isArray(w.generators) ? clone(w.generators) : [],
    transporters: Array.isArray(w.transporters) ? clone(w.transporters) : [],
    candidate_pools: Array.isArray(w.candidate_pools) ? clone(w.candidate_pools) : [],
    readers: readers(),
    graphs: publishedUseCases().map(reportGraph),
    saved: clone(state.whatifSaved),
  }
}

function governedReports() {
  const g = db.reports.governance
  return (g.reports || []).map((r) => {
    const def = db.reports.reports.find((x) => x.report_id === r.report_id) || {}
    const status = state.unpublishedArtifacts[r.report_id] ? 'unpublished' : r.status
    const st = g.statuses.find((s) => s.key === status) || { label: status, tone: 'neutral' }
    return {
      report_id: r.report_id,
      kind: 'written',
      saved_id: null,
      report_tag: def.report_tag || r.report_id,
      title: def.title || r.report_id,
      question: def.question || '',
      lead: def.question || '',
      status,
      status_label: st.label,
      tone: st.tone,
      version: r.version ?? null,
      author: r.author ?? null,
      category: r.category,
      as_of: r.as_of ?? null,
      schedule: r.schedule,
      approval: r.approval ?? null,
      note: r.note ?? null,
      floor: def.floor ?? null,
      parameterized: false,
      row_count: def.row_count ?? 14,
      spine_total: def.spine_total ?? 14,
      private: false,
      audience_named: (r.readers || []).length,
      entitled_roles: [],
    }
  })
}
function reportsGovernance(asRole) {
  const g = db.reports.governance
  const reps = governedReports()
  const dataScope = (g.data_scope || []).map((d) => ({ role_id: d.role_id, label: d.name ?? null, scope: d.scope, predicate: d.predicate, grain: d.grain, masked: d.masked, may_author: !!d.may_author }))
  const viewerRole = asRole || null
  const publishing = clone(g.publishing)
  publishing.freshness = { label: publishing.freshness?.label || 'Keep it fresh', presets: publishing.freshness?.presets || [], days: publishing.freshness?.days || [], times: publishing.freshness?.times || [], units: publishing.freshness?.units || [], default: typeof publishing.freshness?.default === 'string' ? publishing.freshness.default : 'open', default_detail: publishing.freshness?.default_detail, no_day_error: publishing.freshness?.no_day_error || '' }
  publishing.buttons = { publish: 'Publish report', republish: 'Publish changes', cancel: 'Cancel', unpublish: 'Unpublish', manage: 'Manage publishing…', ...(publishing.buttons || {}) }
  return {
    reports: reps,
    ungoverned: [],
    restore: 'npm run seed:governance',
    publishing,
    people: users().map((u) => ({ email: u.email, name: u.name, role_id: u.role_id, role_label: u.role_label, scope: null, masked: null })),
    statuses: [{ key: 'current', label: 'All current', tone: 'neutral', count: reps.length }, ...g.statuses.map((s) => ({ ...s, count: reps.filter((r) => r.status === s.key).length }))],
    categories: Array.from(new Set(reps.map((r) => r.category))),
    viewer: { role_id: viewerRole, label: viewerRole ? roleLabel(viewerRole) : null, entitled_count: reps.length, not_entitled_count: 0, scope: null },
    author: { may_author: true, note: g.gate_notes?.author || '', authors: dataScope.filter((d) => d.may_author).map((d) => d.role_id) },
    gates: {
      note: g.gate_notes?.both || '',
      entitlement: {
        note: g.gate_notes?.entitlement || '',
        columns: reps.map((r) => ({ report_id: r.report_id, title: r.title, report_tag: r.report_tag, status: r.status })),
        roles: db.auth_roles.map((ro) => ({ role_id: ro.role_id, label: ro.label, cells: reps.map((r) => ({ report_id: r.report_id, state: 'entitled', label: 'Can open', tone: 'good' })) })),
      },
      data_scope: { note: g.gate_notes?.data_scope || '', rows: dataScope },
    },
    schedule: reps.map((r) => ({ report_id: r.report_id, title: r.title, schedule: r.schedule, as_of: r.as_of, floor: r.floor, parameterized: false, status_label: r.status_label, tone: r.tone })),
    audit: reps.map((r) => ({ report_id: r.report_id, title: r.title, act: `defined ${r.version || 'v1'}`, actor: r.author || 'Author', at: r.as_of, detail: `${r.status} · ${r.approval || 'none'}`, tone: r.tone })),
    publish_checks: reps.map((r) => ({ report_id: r.report_id, title: r.title, checks: [{ key: 'graph', label: 'Bound to a published graph', pass: true, detail: 'Margin watch v1' }, { key: 'readers', label: 'Readers named', pass: r.audience_named > 0, detail: `${r.audience_named} reader(s)` }, { key: 'scope', label: 'Data scope resolves for every reader', pass: true, detail: 'Every named reader resolves' }, { key: 'fresh', label: 'Freshness set', pass: true, detail: r.schedule }] })),
  }
}
function viewReports(asRole) {
  const pubs = publishedUseCases()
  const tiles = (def) => {
    const fig = (def.blocks || []).find((b) => b.type === 'figRow')
    return (fig?.figures || []).slice(0, 4).map((f) => ({ label: f.label, value: f.display ?? String(f.raw ?? ''), unit: f.note || '', tone: null }))
  }
  return {
    ...counts(),
    governance: reportsGovernance(asRole),
    graphs: pubs.map(reportGraph),
    graph: pubs[0] ? reportGraph(pubs[0]) : null,
    saved: clone(state.savedReports),
    authoring: { opts: clone(db.reports.opts), facets: [], defaults: { scope: db.reports.assumptions?.scope?.value || 'active', measure: db.reports.assumptions?.measure?.value || 'target', horizon: db.reports.assumptions?.horizon?.value || 'q3' } },
    documents: [],
    authoring_document: null,
    reports: (db.reports.reports || []).map((d) => ({
      report_id: d.report_id,
      report_tag: d.report_tag,
      heading: d.title,
      subtitle: d.subject || '',
      question: d.question,
      spine: d.spine,
      row_count: 14,
      spine_total: 14,
      block_kinds: Array.from(new Set((d.blocks || []).map((b) => b.type))),
      tiles: tiles(d),
    })),
  }
}

function viewGovernance() {
  const g = db.reports.governance
  const reg = db.reports.register
  const roster = db.reports.data?.[reg.roster] || []
  const bases = (reg.fields || [])
    .filter((f) => f.avail !== false)
    .map((f) => {
      const vals = {}
      roster.forEach((row) => {
        const v = row[f.key]
        if (v == null) return
        vals[v] = (vals[v] || 0) + 1
      })
      return { basis: f.key, label: f.label, identity: f.key === reg.identity, values: Object.entries(vals).map(([value, count]) => ({ value: String(value), label: String(value), count })) }
    })
  const people = users().map((u) => {
    const rule = state.governanceRules[u.role_id] ?? null
    const full = rule === 'full'
    const r = rule && rule !== 'full' ? rule : null
    let resolution = { kind: 'none', count: 0, total: roster.length, summary: 'No rule authored yet', sample: [] }
    if (full) resolution = { kind: 'full', count: roster.length, total: roster.length, summary: `All ${roster.length}`, sample: roster.slice(0, 3).map((x) => String(x[reg.identity])) }
    else if (r) {
      const rows = roster.filter((x) => r.values.includes(String(x[r.basis])))
      resolution = { kind: 'part', count: rows.length, total: roster.length, summary: `${rows.length} of ${roster.length}`, sample: rows.slice(0, 3).map((x) => String(x[reg.identity])) }
    }
    return { email: u.email, name: u.name, role_id: u.role_id, role_label: u.role_label, declared: null, masked_columns: null, full, mask: false, rule: r, resolution }
  })
  const reps = governedReports()
  const artifacts = reps.map((r) => ({
    artifact_id: r.report_id,
    kind: 'report',
    kind_label: 'Report',
    name: r.title,
    published_by: r.author,
    live: r.status === 'published',
    status_label: r.status_label,
    freshness: r.schedule,
    cases: null,
    readers: state.governanceReaders[r.report_id] || [],
    audience_note: 'Readers are named by the author at publish time.',
    can_unpublish: r.status === 'published',
  }))
  state.whatifSaved
    .filter((s) => s.published)
    .forEach((s) =>
      artifacts.push({ artifact_id: s.saved_id, kind: 'whatif', kind_label: 'What-if', name: s.name, published_by: s.saved_by || NS, live: true, status_label: 'Published', freshness: s.publication?.freshness || 'Only when it’s opened', cases: s.cases || null, readers: s.publication?.readers || [], audience_note: 'Readers named at publish time.', can_unpublish: true }),
    )
  const copy = g.audit?.copy || {}
  return {
    ...counts(),
    document: null,
    roster_total: roster.length,
    bases,
    people,
    artifacts,
    log: state.governanceLog.slice().reverse(),
    log_categories: [
      { key: 'all', label: 'All' },
      { key: 'open', label: 'Opens' },
      { key: 'publish', label: 'Publishing' },
      { key: 'readers', label: 'Readers' },
      { key: 'scope', label: 'Data access' },
      { key: 'unpublish', label: 'Unpublishing' },
    ],
    copy: {
      title: copy.title || 'Audit & Governance',
      lead: copy.lead || '',
      gates: copy.gates || [],
      not_enforced: copy.not_enforced || '',
      empty_log: copy.empty_log || 'Nothing has been logged in this session yet.',
      log_note: copy.log_note || 'Every open, every reader change and every access change lands here.',
      basis_note: copy.basis_note || 'A field qualifies as a restriction basis only if every one of its values is known on every row.',
    },
  }
}
const logEvent = (category, text, detail, actor = NS) => state.governanceLog.push({ event_id: uid('ev_'), at: nowIso(), category, actor, text, detail })

/* ------------------------------------------------------------------ settings */

function viewSettings() {
  const s = db.settings
  return {
    users: users().map((u) => ({ id: u.id, name: u.name, email: u.email, role_id: u.role_id, role_label: u.role_label })),
    personas: db.auth_roles.map((r) => ({
      role_id: r.role_id,
      label: r.label,
      access_note: r.access_note,
      nav: { ...(s.nav_permissions?.[r.role_id] || {}), ...(state.personaNav[r.role_id] || {}) },
      read_only: s.read_only?.[r.role_id] || [],
      defaults: s.defaults?.[r.role_id] || s.nav_permissions?.[r.role_id] || {},
      reports: { ...(s.report_permissions?.[r.role_id] || { open: true, edit: false, delete: false }), ...(state.personaReports[r.role_id] || {}) },
      report_defaults: s.report_defaults?.[r.role_id] || { open: true, edit: false, delete: false },
    })),
    report_actions: ['open', 'edit', 'delete'],
  }
}

/* ------------------------------------------------------------------ router */

const ok = (json, status = 200) => ({ status, json })
const err = (status, error) => ({ status, json: { error } })
const DATASETS = () => ({
  datasets: [{ dataset: DATASET, label: DATASET, primary: true, ref: 'offline copy of the Northline Water Group dataset', store: 'memory', projects: db.projects.length, drives: db.drives.length, reports: (db.reports.reports || []).length, graphs: db.graph_use_cases.length, populated: true }],
  both: { dataset: 'both', label: 'Both', read_only: true },
  selected: DATASET,
})
const sections = () => Object.entries(db).map(([key, v]) => ({ key, kind: Array.isArray(v) ? 'array' : typeof v, count: Array.isArray(v) ? v.length : v && typeof v === 'object' ? Object.keys(v).length : 0, required: true }))

let initialised = false
function init() {
  if (initialised) return
  initialised = true
  seedMarginWatch()
}

export async function handle(method, path, query, body) {
  init()
  const seg = path.split('/').filter(Boolean).map(decodeURIComponent)
  const q = query
  const M = method.toUpperCase()
  const is = (...parts) => parts.length === seg.length && parts.every((p, i) => p === '*' || p === seg[i])

  /* --- platform */
  if (M === 'GET' && is('health')) return ok({ ok: true, datasets: [DATASET], store: 'memory', port: 0, uptime_s: Math.round((Date.now() - state.startedAt) / 1000) })
  if (M === 'GET' && is('datasets')) return ok(DATASETS())
  if (M === 'GET' && is('db')) return ok({ path: 'in-memory (offline copy)', dataset: DATASET, store: 'memory', bytes: JSON.stringify(db).length, sections: sections(), required: Object.keys(db), db })
  if (M === 'PUT' && is('db')) {
    if (body?.db && typeof body.db === 'object') Object.keys(body.db).forEach((k) => (db[k] = body.db[k]))
    return ok({ saved: true, sections: sections() })
  }
  if (M === 'PUT' && is('db', '*')) {
    db[seg[1]] = body?.value
    return ok({ saved: true, section: seg[1], sections: sections() })
  }
  if (M === 'GET' && is('auth', 'roles')) return ok({ roles: db.auth_roles, count: db.auth_roles.length })
  if (M === 'POST' && is('auth', 'login')) {
    const u = userByEmail(body?.email)
    if (!u) return err(401, `${body?.email || 'That address'} is not in the user list. Sign in with an address from Settings → Add User (for example ${NS}).`)
    if (String(body?.password || '').length < 6) return err(401, 'Password must be at least 6 characters.')
    const r = role(u.role_id)
    return ok({ email: u.email, name: u.name, role_id: u.role_id, role_label: u.role_label, access_note: r?.access_note ?? '', initials: initials(u.name), signed_in_at: nowIso() })
  }
  if (M === 'GET' && is('settings')) return ok(viewSettings())
  if (M === 'PATCH' && is('settings', 'personas', '*', 'nav')) {
    state.personaNav[seg[2]] = { ...(state.personaNav[seg[2]] || {}), ...(body?.nav || {}) }
    return ok(viewSettings())
  }
  if (M === 'PATCH' && is('settings', 'personas', '*', 'reports')) {
    state.personaReports[seg[2]] = { ...(state.personaReports[seg[2]] || {}), ...(body?.reports || {}) }
    return ok(viewSettings())
  }
  if (M === 'POST' && is('settings', 'personas', '*', 'reset')) {
    delete state.personaNav[seg[2]]
    delete state.personaReports[seg[2]]
    return ok(viewSettings())
  }
  if (M === 'POST' && is('settings', 'users')) {
    const id = Math.max(0, ...db.settings.users.map((u) => u.id)) + 1
    db.settings.users.push({ id, role_id: body?.role_id, name: body?.name, email: body?.email })
    return ok(viewSettings())
  }

  /* --- connect a source */
  if (M === 'GET' && is('sources', 'oauth', 'start')) {
    const provider = q.get('provider') || 'bigquery'
    const st = uid('st_')
    state.oauth[st] = { provider }
    const scopes = { bigquery: ['https://www.googleapis.com/auth/bigquery.readonly'], drive: ['https://www.googleapis.com/auth/drive.readonly'], gmail: ['https://www.googleapis.com/auth/gmail.readonly'] }[provider] || []
    return ok({ state: st, provider, auth_url: `https://accounts.example/o/oauth2/auth?state=${st}`, scopes, accounts: users().map((u) => ({ email: u.email, name: u.name, initials: initials(u.name) })) })
  }
  if (M === 'GET' && is('sources', 'oauth', 'callback')) {
    const as = q.get('as')
    const u = userByEmail(as) || userByEmail(NS)
    const session = uid('sess_')
    state.oauth[session] = { provider: q.get('provider'), email: u.email }
    const r = role(u.role_id)
    return ok({ account: { email: u.email, name: u.name }, session, provider: q.get('provider') || 'bigquery', identity: { email: u.email, name: u.name, role_id: u.role_id, role_label: u.role_label, access_note: r?.access_note ?? '', initials: initials(u.name) } })
  }
  if (M === 'GET' && is('sources', 'oauth', 'projects')) {
    const projects = db.projects.map((p) => ({ project_id: p.project_id, display_name: p.display_name, location: p.location, dataset_count: p.datasets.length, credential_handle: db.credentials.find((c) => c.project_id === p.project_id)?.credential_handle ?? null }))
    return ok({ projects, project_count: projects.length })
  }
  if (M === 'GET' && is('sources', 'oauth', 'drives')) {
    const drives = db.drives.map((d) => ({ drive_id: d.drive_id, display_name: d.display_name, kind: d.kind, folder_count: d.folders.length, document_count: d.folders.reduce((n, f) => n + (f.documents || []).length, 0), credential_handle: db.drive_credentials.find((c) => c.drive_id === d.drive_id)?.credential_handle ?? null }))
    return ok({ drives, drive_count: drives.length })
  }
  if (is('sources', 'oauth', 'mailboxes')) {
    const email = q.get('as') || state.oauth[q.get('session')]?.email || NS
    const u = userByEmail(email) || userByEmail(NS)
    return ok({ mailboxes: [{ mailbox: u.email, display_name: `${u.name}'s mailbox`, description: 'Cost-to-price correspondence: supplier price notices, customer requests and the committee thread.', credential_handle: 'mail-handle-' + hash(u.email), label_count: 1 }], mailbox_count: 1 })
  }
  if (M === 'POST' && is('sources', 'gmail', 'preview')) {
    const u = userByEmail(body?.mailbox) || userByEmail(NS)
    return ok({ mailbox: u.email, display_name: `${u.name}'s mailbox`, description: 'Cost-to-price correspondence.', labels: ['INBOX', 'SENT', 'Inbox'], label_count: 3 })
  }
  if (M === 'POST' && is('sources', 'preview')) {
    const p = db.projects.find((x) => x.project_id === body?.project_id) || db.projects[0]
    return ok({ project_id: p.project_id, dataset_count: p.datasets.length, datasets: p.datasets.map((d) => ({ dataset_id: d.dataset_id, location: d.location, description: d.description, table_count: d.tables.length, column_count: d.tables.reduce((n, t) => n + (t.columns || 0), 0) })), registered: false })
  }
  if (M === 'POST' && is('sources', 'drive', 'preview')) {
    const d = db.drives.find((x) => x.drive_id === body?.drive_id) || db.drives[0]
    return ok({ drive_id: d.drive_id, display_name: d.display_name, kind: d.kind, folder_count: d.folders.length, document_count: d.folders.reduce((n, f) => n + (f.documents || []).length, 0), folders: d.folders.map((f) => ({ folder_id: f.folder_id, parent_id: f.parent_id ?? null, name: f.name, path: f.path, description: f.description || '', document_count: (f.documents || []).length, page_count: (f.documents || []).reduce((n, x) => n + (x.pages || 0), 0), file_types: Array.from(new Set((f.documents || []).map((x) => (x.name.split('.').pop() || '').toUpperCase()))) })), registered: false })
  }
  if (M === 'POST' && (is('sources') || is('sources', 'drive') || is('sources', 'gmail') || is('sources', 'generic'))) {
    const kind = seg[1] === 'drive' ? 'gdrive' : seg[1] === 'gmail' ? 'gmail' : seg[1] === 'generic' ? 'generic' : 'bigquery'
    const account = kind === 'bigquery' ? body?.project_id : kind === 'gdrive' ? body?.drive_id : kind === 'gmail' ? body?.mailbox : body?.account || body?.connector
    const prefix = kind === 'bigquery' ? 'azuresql' : kind === 'gdrive' ? 'onedrive' : kind === 'gmail' ? 'outlook' : body?.connector || 'generic'
    const id = `${prefix}:${account}`
    let s = sourceById(id)
    const newly = !s
    if (!s) {
      s = {
        source_id: id,
        source_name: body?.source_name || account,
        connector: kind === 'generic' ? body?.connector || 'generic' : kind,
        status: 'connected',
        project_account: account,
        scope: '',
        connected_at: nowIso(),
        profiled_tables: 0,
        profiled_columns: 0,
        profiled_documents: kind === 'bigquery' ? null : 0,
        profiled_entities: kind === 'bigquery' ? null : 0,
        profiled_today: 0,
        profiled_today_date: today(),
        documents_chunked: null,
        chunks_total: null,
        chunk_chars: null,
        last_chunk_at: null,
        last_chunk_count: null,
        last_chunk_since: '2026-04-13',
        datasets: body?.datasets || [],
        folders: body?.folders || [],
        labels: body?.labels || [],
        kind: kind === 'generic' ? body?.connector || 'generic' : kind,
        profilable: kind !== 'generic',
        credential_handle: body?.credential_handle || body?.credential_ref || uid('cred-'),
        type_label: kind === 'bigquery' ? 'Azure SQL Database' : kind === 'gdrive' ? 'OneDrive' : kind === 'gmail' ? 'Outlook' : body?.type_label || 'Source',
        profiled: kind === 'bigquery' ? [] : null,
        drive_id: kind === 'gdrive' ? account : undefined,
        mailbox: kind === 'gmail' ? account : undefined,
      }
      state.sources.push(s)
    } else {
      s.status = 'connected'
      if (body?.datasets) s.datasets = body.datasets
      if (body?.folders) s.folders = body.folders
      if (body?.labels) s.labels = body.labels
      if (body?.source_name) s.source_name = body.source_name
    }
    refreshSourceCounts(s)
    /* Registering a source starts its profiling run, as the server does. */
    if (newly && s.profilable) {
      let objs = []
      if (s.kind === 'bigquery') objs = tablesFor(s).map((x) => ({ parent_id: x.ds.dataset_id, object_id: x.key, label: x.key, units: (db.column_profiles[x.key] || []).length || null, state: 'pending' }))
      else if (s.kind === 'gdrive') objs = driveDocs(s).map(({ folder, doc }) => ({ parent_id: folder.folder_id, object_id: doc.document_id, label: doc.name, units: doc.pages, state: 'pending' }))
      else if (s.kind === 'gmail') objs = mailDocs().map((d) => ({ parent_id: d.label_id || 'Inbox', object_id: d.document_id, label: d.name, units: null, state: 'pending' }))
      if (objs.length) state.jobs.push(makeJob(s, s.kind === 'bigquery' ? 'table' : 'document', objs))
    }
    const base = { source_id: s.source_id, source_name: s.source_name, connector: s.connector, status: s.status, registered_at: s.connected_at, newly_connected: newly }
    if (kind === 'bigquery') return ok({ ...base, project_id: account, credential_handle: s.credential_handle, datasets: s.datasets, dataset_count: s.datasets.length, table_count: tablesFor(s).length })
    if (kind === 'gdrive') return ok({ ...base, drive_id: account, display_name: driveFor(s).display_name, folders: s.folders, folder_count: s.folders.length, document_count: driveDocs(s).length })
    if (kind === 'gmail') return ok({ ...base, mailbox: account, credential_handle: s.credential_handle, labels: s.labels, query: body?.query ?? null })
    return ok({ ...base, type_label: s.type_label, credential_handle: s.credential_handle, account: body?.account ?? null, scope: body?.scope ?? null, datasets: [] })
  }
  if (M === 'GET' && is('sources')) return ok(viewSources())
  if (seg[0] === 'sources' && seg.length >= 2) {
    const s = sourceById(seg[1])
    if (!s) return err(404, `No source "${seg[1]}" is registered.`)
    const sub = seg.slice(2).join('/')
    const wrong = (k) => err(400, `${s.source_id} is a ${s.kind} source; ${k} applies to another kind.`)
    if (M === 'DELETE' && sub === '') {
      state.sources = state.sources.filter((x) => x !== s)
      return ok({ deleted: s.source_id, released: { entities: 0, relationships: 0 } })
    }
    if (M === 'POST' && sub === 'disconnect') {
      s.status = 'disconnected'
      return ok(sourceRow(s))
    }
    if (M === 'POST' && sub === 'reconnect') {
      s.status = 'connected'
      return ok(sourceRow(s))
    }
    if (M === 'PUT' && sub === 'datasets') {
      s.datasets = body?.datasets || []
      refreshSourceCounts(s)
      return ok(sourceRow(s))
    }
    if (M === 'PUT' && sub === 'folders') {
      s.folders = body?.folders || []
      refreshSourceCounts(s)
      return ok(sourceRow(s))
    }
    if (M === 'GET' && sub === 'browse') return s.kind === 'bigquery' ? ok(viewBrowse(s)) : wrong('browse')
    if (M === 'GET' && sub === 'columns') return s.kind === 'bigquery' ? ok(viewColumns(s)) : wrong('columns')
    if (M === 'PATCH' && sub === 'columns') {
      const key = `${body.dataset_id}.${body.table_id}.${body.column_id}`
      state.columnNotes[key] = body.description || null
      return ok({ key, description: state.columnNotes[key] })
    }
    if (M === 'POST' && sub === 'profile') {
      const objs = (body?.objects?.length ? body.objects : tablesFor(s).map((x) => ({ dataset_id: x.ds.dataset_id, table_id: x.t.table_id }))).map((o) => {
        const key = `${o.dataset_id}.${o.table_id}`
        return { parent_id: o.dataset_id, object_id: key, label: key, units: (db.column_profiles[key] || []).length || null, state: 'pending' }
      })
      const j = makeJob(s, 'table', objs, { force: !!body?.force })
      state.jobs.push(j)
      return ok({ job: jobOut(j) })
    }
    if (M === 'POST' && sub === 'schema/preview') {
      const file = String(body?.filename || '')
      const dsId = body?.dataset_id
      const project = projectFor(s)
      const ds = project.datasets.find((d) => d.dataset_id === dsId) || project.datasets[0]
      return ok({ source_id: s.source_id, ...schemaPlan(file, ds) })
    }
    if (M === 'POST' && sub === 'schema') {
      const project = projectFor(s)
      const applied = (body?.dictionaries || []).map((d) => schemaPlan(d.filename, project.datasets.find((x) => x.dataset_id === d.dataset_id) || project.datasets[0]))
      const objs = (body?.objects || []).map((o) => ({ parent_id: o.dataset_id, object_id: `${o.dataset_id}.${o.table_id}`, label: `${o.dataset_id}.${o.table_id}`, units: (db.column_profiles[`${o.dataset_id}.${o.table_id}`] || []).length || null, state: 'pending' }))
      const j = makeJob(s, 'table', objs, { force: !!body?.force })
      state.jobs.push(j)
      return ok({ source_id: s.source_id, applied, job: jobOut(j) })
    }
    if (M === 'GET' && sub === 'browse-documents') return s.kind === 'gdrive' ? ok(viewBrowseDocuments(s)) : wrong('browse-documents')
    if (M === 'GET' && sub === 'documents') return s.kind === 'gdrive' ? ok(viewDocuments(s)) : wrong('documents')
    if (M === 'PATCH' && sub === 'documents') {
      const key = `${body.folder_id}/${body.document_id}`
      state.documentNotes[key] = body.summary || null
      return ok({ key, summary: state.documentNotes[key] })
    }
    if (M === 'POST' && sub === 'profile-documents') {
      const docs = driveDocs(s).filter(({ folder, doc }) => !body?.objects || body.objects.some((o) => o.document_id === doc.document_id))
      const j = makeJob(s, 'document', docs.map(({ folder, doc }) => ({ parent_id: folder.folder_id, object_id: doc.document_id, label: doc.name, units: doc.pages, state: 'pending' })), { force: !!body?.force })
      state.jobs.push(j)
      return ok({ job: jobOut(j) })
    }
    if (M === 'GET' && sub === 'browse-mail-documents') return s.kind === 'gmail' ? ok(viewBrowseMail(s)) : wrong('browse-mail-documents')
    if (M === 'GET' && sub === 'mail-documents') return s.kind === 'gmail' ? ok(viewMailDocuments(s)) : wrong('mail-documents')
    if (M === 'PATCH' && sub === 'mail-documents') {
      const key = `${body.label_id}/${body.document_id}`
      state.mailNotes[key] = body.summary || null
      return ok({ key, summary: state.mailNotes[key] })
    }
    if (M === 'GET' && sub === 'mail-run') {
      if (s.kind !== 'gmail') return wrong('mail-run')
      const j = state.jobs.filter((x) => x.source_id === s.source_id).slice(-1)[0]
      return ok({ source_id: s.source_id, job: j ? jobOut(j) : null })
    }
    if (M === 'POST' && sub === 'profile-mail-documents') {
      const j = makeJob(s, 'document', mailDocs().map((d) => ({ parent_id: d.label_id || 'Inbox', object_id: d.document_id, label: d.name, units: null, state: 'pending' })), { force: !!body?.force })
      state.jobs.push(j)
      return ok({ job: jobOut(j) })
    }
    return err(404, `No route ${M} /sources/${seg[1]}/${sub}`)
  }
  if (M === 'GET' && is('projects', '*', 'datasets')) {
    const p = db.projects.find((x) => x.project_id === seg[1])
    return p ? ok({ project_id: p.project_id, datasets: clone(p.datasets) }) : err(404, `No project ${seg[1]}`)
  }
  if (M === 'GET' && is('drives', '*', 'folders')) {
    const d = db.drives.find((x) => x.drive_id === seg[1])
    return d ? ok({ drive_id: d.drive_id, folders: d.folders.map((f) => ({ folder_id: f.folder_id, parent_id: f.parent_id ?? null, name: f.name, path: f.path, document_count: (f.documents || []).length })) }) : err(404, `No drive ${seg[1]}`)
  }

  /* --- catalogue */
  if (M === 'GET' && is('profiling-jobs')) return ok(viewJobs())
  if (M === 'POST' && is('profiling-jobs', '*', 'cancel')) {
    const j = state.jobs.find((x) => x.job_id === seg[1])
    if (!j) return err(404, 'No such job')
    if (j.status === 'queued' || j.status === 'running') {
      j.status = 'cancelled'
      j.finished_at = nowIso()
    }
    return ok(jobOut(j))
  }
  if (M === 'GET' && is('change-signals')) return ok({ signals: db.change_signals, count: db.change_signals.length, connected_sources: connected().length })
  if (M === 'GET' && is('data-model', 'entities')) return ok({ entities: db.data_model.entities, count: db.data_model.entities.length })
  if (M === 'POST' && is('data-model', 'entities')) {
    let e = db.data_model.entities.find((x) => (body.entity_id && x.entity_id === body.entity_id) || (body.table_key && x.table_key === body.table_key))
    if (!e) {
      e = { entity_id: body.entity_id || uuid(), confirmed_by: null, table_key: body.table_key, entity_name: body.entity_name || String(body.table_key).split('.').pop(), description: '', business_purpose: null, grain_description: null, attributes: [], relationships: [], cross_attributes: [], updated_at: nowIso() }
      db.data_model.entities.push(e)
    }
    Object.assign(e, Object.fromEntries(Object.entries(body).filter(([, v]) => v !== undefined)))
    e.cross_attributes = (e.cross_attributes || []).map((c) => ({ attribute_id: c.attribute_id || uuid(), ...c }))
    e.relationships = (e.relationships || []).map((r) => ({ confirmed_by: null, ...r }))
    e.updated_at = nowIso()
    return ok({ saved: true, entity: e })
  }
  if (M === 'DELETE' && is('data-model', 'entities', '*')) {
    db.data_model.entities = db.data_model.entities.filter((x) => x.entity_id !== seg[2])
    return ok({ deleted: seg[2] })
  }
  if (M === 'POST' && is('data-model', 'relationships', 'accept')) {
    const as = q.get('as') || NS
    let accepted = 0
    let already = 0
    const keys = body?.table_keys || []
    for (const sg of db.data_model.suggestions || []) {
      if (keys.length && !keys.includes(sg.from_table_key)) continue
      let e = db.data_model.entities.find((x) => x.table_key === sg.from_table_key)
      if (!e) {
        e = { entity_id: uuid(), confirmed_by: as, table_key: sg.from_table_key, entity_name: sg.from_table_key.split('.').pop(), description: '', business_purpose: null, grain_description: null, attributes: [], relationships: [], cross_attributes: [], updated_at: nowIso() }
        db.data_model.entities.push(e)
      }
      const exists = e.relationships.find((r) => r.target_table_key === sg.to_table_key && r.from_columns[0] === sg.from_column)
      if (exists) {
        already += 1
        continue
      }
      e.relationships.push({ target_table_key: sg.to_table_key, from_columns: [sg.from_column], to_columns: [sg.to_column], relationship_type: sg.relationship_type, cardinality_hint: sg.cardinality_hint || 'N:1', rationale: sg.rationale, confirmed_by: as })
      e.updated_at = nowIso()
      accepted += 1
    }
    return ok({ accepted, already, total: accepted + already, accepted_by: as })
  }
  if (M === 'POST' && is('data-model', 'suggestions')) {
    const s = sourceById(body?.source_id) || state.sources[0]
    const keys = new Set(tablesFor(s).map((x) => x.key))
    const rels = (db.data_model.suggestions || []).filter((r) => keys.has(r.from_table_key) || keys.has(r.to_table_key))
    const tables = tablesFor(s).filter((x) => isProfiledTable(s, x.key)).map((x) => ({ table_key: x.key, table_id: x.t.table_id, suggested_description: x.t.label, suggested_business_purpose: x.t.carries || null, suggested_grain_description: x.t.grain || null }))
    const linked = new Set(rels.flatMap((r) => [r.from_table_key, r.to_table_key]))
    return ok({
      source_id: s.source_id,
      tables,
      relationships: rels.map((r) => ({ from_table_key: r.from_table_key, from_column: r.from_column, to_table_key: r.to_table_key, to_column: r.to_column, relationship_type: r.relationship_type, relationship_type_alternatives: r.relationship_type_alternatives || [], cardinality_hint: r.cardinality_hint ?? null, rationale: r.rationale, confidence: r.confidence ?? null, evidence_kind: 'name_and_values' })),
      degraded: false,
      recorded_count: rels.length,
      derived_count: 0,
      truncated: false,
      tables_considered: tables.length,
      relationships_total: rels.length,
      orphan_tables: tables.filter((t) => !linked.has(t.table_key)).map((t) => t.table_key),
    })
  }

  /* --- New Graph */
  if (M === 'GET' && is('graph-domains')) return ok(viewDomains())
  if (M === 'GET' && is('graph-sources')) return ok(viewGraphSources())
  if (M === 'GET' && is('graph-use-cases')) return ok(viewUseCases())
  /* Drafting is model work: it takes a moment, as it does live. */
  if (M === 'POST' && is('graph-personas', 'suggest')) return (await sleep(2200), ok(suggestions('personas', body)))
  if (M === 'POST' && is('graph-metrics', 'suggest')) return (await sleep(2400), ok(suggestions('metrics', body)))
  if (M === 'POST' && is('graph-questions', 'suggest')) return (await sleep(2400), ok(suggestions('questions', body)))
  if (M === 'PATCH' && is('graph-metrics', '*')) {
    state.metricEdits[seg[1]] = { name: body?.name, definition: body?.definition }
    const m = db.graph_metrics.find((x) => x.metric_id === seg[1])
    return ok({ metric: { id: seg[1], name: body?.name ?? m?.name ?? seg[1], detail: body?.definition ?? m?.definition ?? '', why: 'Edited by you.', priority: null } })
  }
  if (M === 'POST' && is('graph-questions', 'sql')) return (await sleep(700), ok(questionSql(body)))
  if (M === 'POST' && is('graph-coverage')) return ok(coverage(body))
  if (M === 'POST' && is('graph-derivations')) {
    const d = { id: uid('drv_'), t0: Date.now(), coverage: coverage(body) }
    state.derivations[d.id] = d
    return ok(derivationOut(d))
  }
  if (M === 'GET' && is('graph-derivations', '*')) {
    const d = state.derivations[seg[1]]
    return d ? ok(derivationOut(d)) : err(404, 'No such derivation')
  }
  if (M === 'POST' && is('graph-use-cases')) {
    let u = body?.use_case_id ? useCase(body.use_case_id) : null
    if (!u) {
      const slug = String(body?.name || 'graph').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 32) || 'graph'
      u = { use_case_id: body?.use_case_id || `uc-${slug}-${Math.random().toString(36).slice(2, 11)}` }
      db.graph_use_cases.push(u)
    }
    Object.assign(u, {
      name: body?.name ?? u.name ?? 'Untitled graph',
      status: body?.status || u.status || 'draft',
      domain_id: body?.domain_id ?? u.domain_id ?? null,
      business_need: body?.business_need ?? u.business_need ?? '',
      personas: body?.personas ?? u.personas ?? [],
      metrics: body?.metrics ?? u.metrics ?? [],
      sources: body?.sources ?? u.sources ?? [],
      hero_questions: body?.hero_questions ?? u.hero_questions ?? [],
      gap_decisions: body?.gap_decisions ?? u.gap_decisions ?? [],
      step: body?.step ?? u.step ?? 1,
      role: body?.role ?? u.role ?? null,
      updated_at: nowIso(),
    })
    return ok({ use_case: ucOut(u) })
  }
  if (M === 'DELETE' && is('graph-use-cases', '*')) {
    db.graph_use_cases = db.graph_use_cases.filter((u) => u.use_case_id !== seg[1])
    return ok({ deleted: seg[1] })
  }

  /* --- Graph Studio (current studio: configs, SGB, DGB, Bridge, versions) */
  if (M === 'GET' && is('use-case-configs')) return ok(viewConfigs())
  if (M === 'GET' && is('use-case-configs', '*')) {
    const u = useCase(seg[1])
    return u ? ok(viewConfig(u)) : err(404, `No use case ${seg[1]}`)
  }
  if (M === 'GET' && is('metadata-profiler', 'sources'))
    return ok({ sources: connected().map((s) => ({ source_id: s.kind === 'bigquery' ? `bigquery:${s.project_account}` : s.source_id, source_type: s.kind === 'bigquery' ? 'structured_schema' : s.kind === 'gdrive' ? 'document_corpus' : 'mailbox', name: s.source_name, connector: s.connector })) })
  if (M === 'POST' && is('structured-graph-builder', 'story-drafts')) {
    const u = useCase(body?.use_case_config_id)
    const sg = db.studio_graph.structured
    return ok({ story: sg.story_group.story, degraded: false, degrade_reason: null, tables_considered: sg.tables.length, columns_considered: sg.columns.length, declared_relationships_considered: db.data_model.entities.reduce((n, e) => n + e.relationships.length, 0), intent_considered: !!u, hero_questions_considered: (u?.hero_questions || []).length })
  }
  if (M === 'POST' && is('structured-graph-builder', 'builds')) {
    const b = startSgb(body?.use_case_config_id, body?.story)
    return ok({ build_id: b.build_id, status: 'running' }, 202)
  }
  if (M === 'GET' && is('structured-graph-builder', 'builds')) {
    const ucId = q.get('use_case_config_id')
    return ok({ builds: state.sgbBuilds.filter((b) => !ucId || b.use_case_config_id === ucId).sort((a, b) => b.build_number - a.build_number).map(sgbOut) })
  }
  if (seg[0] === 'structured-graph-builder' && seg[1] === 'builds' && seg[2]) {
    const b = state.sgbBuilds.find((x) => x.build_id === seg[2])
    if (!b) return err(404, 'No such build')
    const sg = db.studio_graph.structured
    if (M === 'GET' && seg.length === 3) return ok(sgbOut(b))
    if (M === 'GET' && seg[3] === 'graph') {
      if (sgbTick(b).status !== 'complete') return err(409, 'The build is still running.')
      const story = state.storyEdits[b.build_id]
      return ok({ build_id: b.build_id, tables: sg.tables, columns: sg.columns, concepts: sg.concepts, edges: sg.edges, story_group: story ? { ...sg.story_group, story, edited_by_user: true } : sg.story_group })
    }
    if (M === 'GET' && seg[3] === 'story') {
      const story = state.storyEdits[b.build_id]
      return ok({ build_id: b.build_id, story_group_id: sg.story_group.story_group_id, story: story ?? sg.story_group.story, grain: { tables: sg.tables.length, stated_by: 'the use case brief' }, join_warning: null, uncertainties: sg.story_group.uncertainties || [], edited_by_user: !!story || b.build_id === '956796a4-ecb9-4c7e-a70e-53a396aefaea' })
    }
    if (M === 'PUT' && seg[3] === 'story') {
      state.storyEdits[b.build_id] = body?.story
      return ok({ status: 'saved' })
    }
  }
  if (M === 'POST' && is('document-graph-builder', 'corpora', '*', 'build')) {
    const j = startDgb(seg[2])
    return ok({ job_id: j.job_id, status: 'running' }, 202)
  }
  if (M === 'GET' && is('document-graph-builder', 'jobs', '*')) {
    const j = state.dgbJobs.find((x) => x.job_id === seg[2])
    return j ? ok(dgbJobOut(j)) : err(404, 'No such job')
  }
  if (M === 'GET' && is('document-graph-builder', 'graph', 'builds')) {
    state.dgbJobs.forEach(dgbJobTick)
    const id = q.get('document_corpus_id')
    return ok({ builds: state.dgbBuilds.filter((b) => b.document_corpus_id === id).sort((a, b) => b.graph_version - a.graph_version).map(clone) })
  }
  const hasDgb = (id) => state.dgbBuilds.some((b) => b.document_corpus_id === id)
  if (M === 'GET' && is('document-graph-builder', 'graph', 'classes')) return ok({ classes: db.studio_graph.documents.classes })
  if (M === 'GET' && is('document-graph-builder', 'graph', 'entities')) {
    const items = hasDgb(q.get('document_corpus_id')) ? db.studio_graph.documents.entities : []
    const limit = Number(q.get('limit') || 500)
    const offset = Number(q.get('offset') || 0)
    return ok({ items: items.slice(offset, offset + limit), limit, offset, has_more: offset + limit < items.length })
  }
  if (M === 'GET' && is('document-graph-builder', 'graph', 'relations')) {
    const items = hasDgb(q.get('document_corpus_id')) ? db.studio_graph.documents.relations : []
    const limit = Number(q.get('limit') || 500)
    const offset = Number(q.get('offset') || 0)
    return ok({ items: items.slice(offset, offset + limit), limit, offset, has_more: offset + limit < items.length })
  }
  if (M === 'GET' && is('document-graph-builder', 'graph', 'evidence', '*')) {
    const chunk = seg[3]
    const rel = db.studio_graph.documents.relations.find((r) => r.chunk_id === chunk)
    const docId = rel?.document_id
    let doc = null
    let folder = null
    for (const d of db.drives) for (const f of d.folders) for (const x of f.documents || []) if (x.document_id === docId || ('DOC:' + x.document_id) === docId) ((doc = x), (folder = f))
    const meta = db.studio_graph.documents.documents.find((d) => d.document_id === docId)
    const ex = doc ? db.document_extractions[doc.document_id] || [] : []
    return ok({
      chunk_id: chunk,
      document_id: docId || '',
      chunk_text: doc?.excerpt || (ex.length ? ex.map((e) => `${e.entity_type}: ${e.extracted_entity}${e.normalized_value && e.normalized_value !== e.extracted_entity ? ` (${e.normalized_value})` : ''}`).join('\n') : rel ? `${rel.relation_type.replace(/_/g, ' ')}, read from ${meta?.filename || 'the document'}` : null),
      document_name: doc?.name || meta?.filename || 'Document',
      doc_type_label: doc?.doc_type_label ?? null,
      linked_entity: doc?.linked_entity ?? null,
      page_start: 1,
      page_end: doc?.pages ?? 1,
    })
  }
  if (M === 'GET' && is('document-graph-builder', 'corpora', '*', 'documents')) {
    const u = useCase(seg[2])
    const docs = []
    for (const p of u?.sources || []) {
      const s = sourceById(p.source_id)
      if (!s || s.kind !== 'gdrive') continue
      const drive = driveFor(s)
      driveDocs(s).forEach(({ folder, doc }) => docs.push({ document_id: doc.document_id, filename: doc.name, mime_type: doc.mime_type, doc_type: doc.doc_type, doc_type_label: doc.doc_type_label, linked_entity: doc.linked_entity, pages: doc.pages, folder: folder.name, drive: drive.display_name }))
    }
    return ok({ documents: docs })
  }
  if (seg[0] === 'use-cases' && seg[1]) {
    const ucId = seg[1]
    const sub = seg.slice(2)
    const subIs = (...parts) => parts.length === sub.length && parts.every((p, i) => p === '*' || p === sub[i])
    if (M === 'GET' && subIs('playground')) return ok(viewPlayground(ucId))
    if (M === 'PATCH' && subIs('playground')) {
      state.playground[ucId] = { ...(state.playground[ucId] || {}), ...(body?.metrics ? { metrics: body.metrics } : {}), ...(body?.golden_queries ? { golden_queries: body.golden_queries } : {}), ...(body?.files ? { files: body.files } : {}) }
      return ok(viewPlayground(ucId))
    }
    if (M === 'POST' && subIs('combined-builds')) {
      const u = useCase(ucId)
      const c = studioConfig(u)
      const sgb = c.hasStructured ? startSgb(ucId, body?.story) : null
      const job = c.hasDocs ? startDgb(ucId, c.hasStructured) : null
      return ok({ use_case_config_id: ucId, sgb_build_id: sgb?.build_id ?? null, dgb_job_id: job?.job_id ?? null, bridge_follows: !!(sgb && job), status: 'running' }, 202)
    }
    if (M === 'GET' && subIs('bridge-builds')) return ok({ bridge_builds: state.bridgeBuilds.filter((b) => b.use_case_config_id === ucId).sort((a, b) => b.build_number - a.build_number).map(bridgeOut) })
    if (M === 'POST' && subIs('bridge-builds')) {
      const b = startBridge(ucId)
      return ok({ bridge_build_id: b.bridge_build_id, build_number: b.build_number, status: 'running' }, 202)
    }
    const bb = sub[0] === 'bridge-builds' && sub[1] ? state.bridgeBuilds.find((b) => b.bridge_build_id === sub[1]) : null
    if (sub[0] === 'bridge-builds' && sub[1] && !bb) return err(404, 'No such Bridge build')
    if (M === 'GET' && subIs('bridge-builds', '*')) return ok(bridgeOut(bb))
    if (M === 'GET' && subIs('bridge-builds', '*', 'type-links')) {
      bridgeTick(bb)
      const links = bb.status === 'succeeded' ? state.typeLinks[bb.bridge_build_id] || [] : []
      return ok({ type_links: clone(links), unreviewed_count: unreviewed(links) })
    }
    if (M === 'PATCH' && subIs('bridge-builds', '*', 'type-links', '*')) {
      const links = state.typeLinks[bb.bridge_build_id] || []
      const l = links.find((x) => x.type_link_id === sub[3])
      if (!l) return err(404, 'No such type link')
      l.decision = body?.decision || l.decision
      l.decided_by = 'human'
      l.decided_by_user_id = q.get('as') || NS
      l.decided_at = nowIso()
      l.updated_at = l.decided_at
      return ok(clone(l))
    }
    if (M === 'POST' && subIs('bridge-builds', '*', 'type-links', 'accept-outstanding')) {
      const links = state.typeLinks[bb.bridge_build_id] || []
      let n = 0
      links.forEach((l) => {
        if (l.decided_by !== 'human') {
          l.decided_by = 'human'
          l.decided_by_user_id = q.get('as') || NS
          l.decided_at = nowIso()
          l.updated_at = l.decided_at
          n += 1
        }
      })
      return ok({ accepted_count: n, unreviewed_count: unreviewed(links) })
    }
    if (M === 'POST' && subIs('bridge-builds', '*', 'revise')) {
      const b = startBridge(ucId)
      return ok(bridgeOut(b))
    }
    if (M === 'GET' && subIs('published-bridge')) {
      const v = publishedVersion(ucId)
      const b = v && state.bridgeBuilds.find((x) => x.bridge_build_id === v.bridge_build_id)
      return ok({ published_bridge: b ? { bridge_build_id: b.bridge_build_id, use_case_config_id: ucId, build_number: b.build_number, status: b.status } : null })
    }
    if (M === 'GET' && subIs('graph-versions')) return ok({ versions: state.versions.filter((v) => v.use_case_config_id === ucId).sort((a, b) => b.version_number - a.version_number).map(versionOut) })
    if (M === 'GET' && subIs('graph-versions', 'published')) {
      const v = publishedVersion(ucId)
      return ok({ version: v ? versionOut(v) : null })
    }
    if (M === 'POST' && subIs('graph-versions', 'reconcile')) {
      const v = reconcile(ucId)
      return ok({ version: v ? versionOut(v) : null })
    }
    if (sub[0] === 'graph-versions' && sub[1]) {
      const v = state.versions.find((x) => x.graph_version_id === sub[1])
      if (!v) return err(404, 'No such graph version')
      if (M === 'GET' && sub.length === 2) {
        const sgb = latestSgb(ucId)
        const dgb = latestDgb(ucId)
        const b = state.bridgeBuilds.find((x) => x.bridge_build_id === v.bridge_build_id)
        return ok({ version: versionOut(v), bridge_matches_named_triple: b ? b.sgb_build_id === v.sgb_build_id && b.dgb_graph_version === v.dgb_graph_version : null, bridge_status: b?.status ?? null, newer_sgb_build_id: sgb && sgb.build_id !== v.sgb_build_id && sgb.status === 'complete' ? sgb.build_id : null, newer_dgb_graph_version: dgb && v.dgb_graph_version != null && dgb.graph_version > v.dgb_graph_version ? dgb.graph_version : null })
      }
      if (M === 'POST' && sub[2] === 'publish') {
        const as = q.get('as') || NS
        state.versions.filter((x) => x.use_case_config_id === ucId && x !== v).forEach((x) => {
          if (x.published_at) x.published_at = null
        })
        v.published_at = nowIso()
        v.published_by_user_id = as
        state.sgbBuilds.filter((b) => b.build_id === v.sgb_build_id).forEach((b) => ((b.published_at = v.published_at), (b.published_by_user_id = as)))
        state.dgbBuilds.filter((b) => b.document_corpus_id === ucId).forEach((b) => {
          if (b.graph_version === v.dgb_graph_version) {
            b.publish_status = 'published'
            b.published_at = v.published_at
            b.published_by_user_id = as
          } else if (b.publish_status === 'published') b.publish_status = 'superseded'
        })
        const u = useCase(ucId)
        if (u) u.status = 'committed'
        return ok({ version: versionOut(v) })
      }
      if (M === 'POST' && sub[2] === 'unpublish') {
        v.published_at = null
        v.published_by_user_id = null
        return ok({ version: versionOut(v) })
      }
    }
    return err(404, `No route ${M} /use-cases/${ucId}/${sub.join('/')}`)
  }
  /* The earlier review-queue studio is not served for this dataset, as on the live demo. */
  if (seg[0] === 'graph-studio') return err(404, 'The review-queue studio is not served for this dataset.')

  /* --- Ask */
  if (M === 'GET' && is('ask')) return ok(viewAsk())
  if (M === 'POST' && is('ask')) return { status: 200, stream: askStream(body), contentType: 'text/event-stream' }

  /* --- What-if */
  if (M === 'GET' && is('whatif')) return ok(viewWhatif())
  if (M === 'POST' && is('whatif', 'resolve')) {
    const text = String(body?.text || body?.measure || '').toLowerCase()
    const m = (db.whatif.watched_measures || []).find((x) => text && (x.label.toLowerCase().includes(text) || text.includes(x.key)))
    return ok({ resolved: !!m, measure: m ? clone(m) : null, reason: m ? null : 'No measure in the graph resolves to that name.', copy: db.whatif.resolve_copy || null })
  }
  if (M === 'POST' && is('whatif', 'scenario')) return ok({ scenario: body || {}, note: 'Computed in the framed lens.' })
  if (M === 'POST' && is('whatif', 'saved')) {
    const s = { saved_id: body?.saved_id || uid('wis_'), saved_at: nowIso(), saved_by: NS, published: false, ...body }
    state.whatifSaved = state.whatifSaved.filter((x) => x.saved_id !== s.saved_id).concat([s])
    return ok({ saved: clone(state.whatifSaved), scenario: clone(s) })
  }
  if (seg[0] === 'whatif' && seg[1] === 'saved' && seg[2]) {
    const s = state.whatifSaved.find((x) => x.saved_id === seg[2])
    if (M === 'DELETE' && seg.length === 3) {
      state.whatifSaved = state.whatifSaved.filter((x) => x.saved_id !== seg[2])
      return ok({ saved: clone(state.whatifSaved), deleted: seg[2] })
    }
    if (!s) return err(404, 'No such scenario')
    if (M === 'POST' && seg[3] === 'publish') {
      s.published = true
      s.publication = { ...body, published_at: nowIso() }
      logEvent('publish', `Published what-if "${s.name || s.saved_id}"`, `${(body?.readers || []).length} reader(s)`)
      return ok({ saved: clone(state.whatifSaved), scenario: clone(s) })
    }
    if (M === 'DELETE' && seg[3] === 'publish') {
      s.published = false
      logEvent('unpublish', `Unpublished what-if "${s.name || s.saved_id}"`, '')
      return ok({ saved: clone(state.whatifSaved), scenario: clone(s) })
    }
  }

  /* --- reports and governance */
  if (M === 'GET' && is('reports', 'prototype')) return ok({ ref: 'offline copy', store: 'memory', dataset: clone(db.reports_prototype) })
  if (M === 'GET' && is('reports')) return ok(viewReports(q.get('as_role')))
  if (M === 'GET' && is('reports', 'saved', '*')) {
    const s = state.savedReports.find((x) => x.saved_id === seg[2])
    return s ? ok({ saved: clone(s) }) : err(404, 'No such saved report')
  }
  if (M === 'GET' && is('reports', '*')) return ok({ ...counts(), report: null })
  if (M === 'POST' && is('reports', 'saved')) {
    const s = { saved_id: uid('svr_'), saved_at: nowIso(), saved_by: NS, viewer_roles: [], filters: [], graph: publishedUseCases()[0] ? reportGraph(publishedUseCases()[0]) : null, use_case_id: MW, question: null, ...body }
    state.savedReports.push(s)
    return ok({ saved: clone(state.savedReports) })
  }
  if (M === 'DELETE' && is('reports', 'saved', '*')) {
    state.savedReports = state.savedReports.filter((x) => x.saved_id !== seg[2])
    return ok({ saved: clone(state.savedReports) })
  }
  if (M === 'POST' && is('reports', 'saved', '*', 'roles')) {
    const s = state.savedReports.find((x) => x.saved_id === seg[2])
    if (s) s.viewer_roles = (body?.role_ids || []).map((r) => ({ role_id: r, label: roleLabel(r) }))
    return ok({ saved: clone(state.savedReports) })
  }
  if (M === 'PATCH' && seg[0] === 'reports' && seg[1] === 'governance' && seg[3] === 'audience') {
    state.governanceReaders[seg[2]] = body?.readers || body?.audience || []
    return ok(viewReports(q.get('as_role')))
  }
  if (M === 'DELETE' && seg[0] === 'reports' && seg[1] === 'governance' && seg[2]) {
    state.unpublishedArtifacts[seg[2]] = true
    return ok(viewReports(q.get('as_role')))
  }
  if (M === 'GET' && is('governance')) return ok(viewGovernance())
  if (M === 'PATCH' && is('governance', 'scope', '*')) {
    const r = seg[2]
    if (body?.full) state.governanceRules[r] = 'full'
    else if (body?.rule) state.governanceRules[r] = body.rule
    else delete state.governanceRules[r]
    logEvent('scope', `Changed data access for ${roleLabel(r)}`, body?.full ? 'Full scope' : body?.rule ? `${body.rule.basis} = ${body.rule.values.join(', ')}` : 'Rule removed', q.get('as') || NS)
    return ok(viewGovernance())
  }
  if (seg[0] === 'governance' && seg[1] === 'artifacts' && seg[2]) {
    const id = seg[2]
    if (M === 'POST' && seg[3] === 'readers') {
      const list = state.governanceReaders[id] || []
      const email = body?.email || body?.reader
      if (email && !list.includes(email)) list.push(email)
      state.governanceReaders[id] = list
      logEvent('readers', `Added a reader to ${id}`, email || '', q.get('as') || NS)
      return ok(viewGovernance())
    }
    if (M === 'DELETE' && seg[3] === 'readers') {
      const email = seg[4] || body?.email
      state.governanceReaders[id] = (state.governanceReaders[id] || []).filter((x) => x !== email)
      logEvent('readers', `Removed a reader from ${id}`, email || '', q.get('as') || NS)
      return ok(viewGovernance())
    }
    if (M === 'POST' && seg[3] === 'unpublish') {
      state.unpublishedArtifacts[id] = true
      const w = state.whatifSaved.find((x) => x.saved_id === id)
      if (w) w.published = false
      logEvent('unpublish', `Unpublished ${id}`, '', q.get('as') || NS)
      return ok(viewGovernance())
    }
  }

  /* --- observability */
  if (M === 'GET' && is('audit')) return ok({ ...clone(db.audit), connected_sources: connected().length })
  if (M === 'GET' && is('traces')) return ok({ ...clone(db.traces), connected_sources: connected().length })
  if (M === 'GET' && is('evals')) return ok({ ...clone(db.evals), connected_sources: connected().length })

  return err(404, `No route for ${M} /${seg.join('/')} in this offline copy.`)
}

function schemaPlan(filename, ds) {
  const declared = Object.keys(db.column_profiles).filter((k) => k.startsWith(ds.dataset_id + '.'))
  const tables = ds.tables.map((t) => {
    const key = `${ds.dataset_id}.${t.table_id}`
    const cols = db.column_profiles[key] || []
    return { table_id: t.table_id, exists: true, profiled: declared.includes(key), label: t.label, grain: t.grain, column_count: cols.length || t.columns, previous_column_count: cols.length || t.columns, catalogued_column_count: cols.length, added: [], dropped: [], orphaned_notes: [], stranded_declarations: [] }
  })
  return { filename, format: (filename.split('.').pop() || 'csv').toLowerCase(), dataset_id: ds.dataset_id, table_count: tables.length, column_count: tables.reduce((n, t) => n + t.column_count, 0), new_table_count: 0, tables }
}
