/*
 * Analysis — the two Keolis Valmont cases the prototype opens with.
 *
 * An analysis is a goal pursued over the published graph: what the business wants, how the work was
 * started (a person, a schedule or a rule), what the analyst established, what it could not, the
 * options with their numbers, and a recommendation the accountable person can accept, change or
 * challenge. Every figure below is one that Ask already answers for this graph, so the two cases and
 * the recorded answers never disagree. Keolis Valmont, Valmont Métropole and every figure are invented.
 */

export type Trigger = 'person' | 'schedule' | 'rule'
export type AnalysisStatus = 'investigating' | 'needs-input' | 'findings-ready' | 'accepted'
export type EvidenceKind = 'table' | 'document' | 'mail' | 'assumption' | 'gap'

export interface Evidence {
  kind: EvidenceKind
  text: string
  source: string
  asOf?: string
}

export interface Finding {
  id: string
  headline: string
  detail: string
  evidence: Evidence[]
}

export interface Option {
  id: string
  label: string
  outcome: string
  figures: { label: string; value: string; tone?: 'good' | 'warn' | 'crit' }[]
  tradeoff: string
  recommended?: boolean
}

export interface LogEntry {
  at: string
  who: string
  what: string
}

export interface Analysis {
  id: string
  title: string
  goal: string
  trigger: Trigger
  triggerDetail: string
  status: AnalysisStatus
  owner: string
  ownerRole: string
  startedAt: string
  scope: string[]
  constraints: string[]
  question?: string
  findings: Finding[]
  gaps: string[]
  options: Option[]
  recommendation: string
  recommendationWhy: string[]
  submissions: { label: string; audience: string; template: string }[]
  log: LogEntry[]
  askRefs: string[]
}

export const TRIGGER_LABEL: Record<Trigger, string> = {
  person: 'Started by a person',
  schedule: 'Runs on a schedule',
  rule: 'Fired by a rule',
}

export const STATUS_LABEL: Record<AnalysisStatus, string> = {
  investigating: 'Investigating',
  'needs-input': 'Needs your input',
  'findings-ready': 'Findings ready',
  accepted: 'Recommendation accepted',
}

export const ANALYSES: Analysis[] = [
  {
    id: 'an-fy2026-programme',
    title: 'Keep the FY2026 capital programme on plan',
    goal: 'Understand why FY2026 spend is running behind the €44.5M plan, decide which projects to intervene on, and settle the figure that goes into the October forecast round.',
    trigger: 'rule',
    triggerDetail:
      'Rule "forecast vs plan deviation above 5%" fired on 15 September: the working forecast is €40.8M against €44.5M, a gap of 8.3%. The same review also runs on the first Monday of every month.',
    status: 'findings-ready',
    owner: 'Amélie Roussel',
    ownerRole: 'Investment Controller',
    startedAt: '2026-09-15T06:00:00Z',
    scope: [
      '29 funded renewal projects under DSP-VM-2021, FY2026 only',
      'Plan phasing, certified actuals January to August, working forecast September to December',
      'Supplier statements read from the mailbox at question time',
    ],
    constraints: [
      'The PPI envelope cannot change without a decision by Valmont Métropole',
      'Service dates in the contract are fixed; a slipped project is re-phased, never cancelled',
      'Figures in EUR HT; variance is forecast minus current approved budget',
    ],
    findings: [
      {
        id: 'f1',
        headline: 'Spend is €3.1M behind plan to August and the year lands €3.7M short.',
        detail:
          '€23.8M spent against €26.9M planned to the end of August. The working forecast puts the year at €40.8M against the €44.5M plan. Every month since May has spent less than its phasing.',
        evidence: [
          { kind: 'table', text: 'FY2026 plan phasing, certified actuals Jan to Aug, working forecast Sep to Dec', source: 'keolis_valmont_erp.fin', asOf: '2026-09-22' },
        ],
      },
      {
        id: 'f2',
        headline: 'This is money moving right, not money saved: 13 of 25 assessed projects are over budget.',
        detail:
          'The assessed projects forecast €2.5M net above approved budget. P-VM-005 TV-100 overhaul carries €1.78M of it, 66% of the overrun, most of that an allowance for frame replacement that is not yet approved. The under-spend against plan and the overrun against budget are both true at once.',
        evidence: [
          { kind: 'table', text: 'Latest working forecast per project against the current approved budget version', source: 'keolis_valmont_erp.fin', asOf: '2026-09-22' },
          { kind: 'document', text: 'RC-005-009 requests €2.64M and 122 days for bogie frames on 24 trams', source: 'P-VM-005_Change_Request_RC-005-009_Bogie_Frames.pdf', asOf: '2026-06-26' },
        ],
      },
      {
        id: 'f3',
        headline: 'Four projects worth €3.7M have had no forecast since 15 June, so the portfolio answer covers 25 of 29.',
        detail:
          'P-VM-046 bus washing plant, P-VM-053 bus CCTV renewal, P-VM-061 rail grinding 2026 and P-VM-064 tram stop shelters T2 have not been reforecast. Whether they spend in FY2026 is unknown, and a plan figure that assumes they do is an assumption, not evidence.',
        evidence: [
          { kind: 'table', text: 'Projects without a forecast snapshot after 2026-06-15', source: 'keolis_valmont_erp.fin', asOf: '2026-09-22' },
          { kind: 'assumption', text: 'The plan phasing still counts these four at their approved value', source: 'Working assumption, to be confirmed by the project office' },
        ],
      },
      {
        id: 'f4',
        headline: 'Three projects explain the timing: a blocked track closure and two supplier slips the schedule does not show.',
        detail:
          'P-VM-008 T1 track renewal cannot start while the closure is provisional and drawing revision C puts SIG-T1-044 inside the work limit. Arvéa now says 21 October for bus tranche 2 batch 3 while the ERP still shows 30 September. The Les Aubiers lift control unit moves from 5 to 19 October, so commissioning on 26 October will not happen.',
        evidence: [
          { kind: 'mail', text: 'Arvéa: batch 3 delivery moved to 21 October', source: 'EM-05 P-VM-014 tranche 2 batch 3 delivery', asOf: '2026-09-17' },
          { kind: 'mail', text: 'Levantis: HPU-9 control unit arrives 19 October instead of 5 October', source: 'EM-01 P-VM-021 lift HPU delivery slip', asOf: '2026-09-16' },
          { kind: 'document', text: 'Closure access provisional; drawing rev C extends the limit onto SIG-T1-044', source: 'EM-02 P-VM-008 T1 closure access and scope', asOf: '2026-09-18' },
          { kind: 'table', text: 'Schedule tasks and milestones per project, as published by the project office', source: 'keolis_valmont_ppm.ppm', asOf: '2026-09-19' },
        ],
      },
    ],
    gaps: [
      'Whether the four unassessed projects will spend anything in FY2026. The project office owns the reforecast.',
      'Per-project phasing differences for the 18 projects that are neither slipped nor over budget; the data shows the gap but not a reason, and none was invented.',
      'Whether Valmont Métropole will accept a carry-over of unspent PPI into FY2027; the contract allows a request, the answer is theirs.',
    ],
    options: [
      {
        id: 'o1',
        label: 'Re-phase: forecast €40.8M, request carry-over of €3.7M into FY2027',
        outcome: 'The October forecast round states the realistic figure and the carry-over goes to the authority with the three slips as evidence.',
        figures: [
          { label: 'FY2026 forecast', value: '€40.8M' },
          { label: 'Carry-over request', value: '€3.7M', tone: 'warn' },
          { label: 'Projects re-phased', value: '3' },
        ],
        tradeoff: 'Honest and defensible, but the authority may read a second year of under-spend as under-delivery. Needs the reforecast of the four unassessed projects first.',
        recommended: true,
      },
      {
        id: 'o2',
        label: 'Pull forward ready work to absorb part of the gap',
        outcome: 'P-VM-049 overhead contact line renewal and P-VM-045 ticket validators could start their next work packages in Q4 and spend about €1.5M earlier than phased.',
        figures: [
          { label: 'FY2026 forecast', value: '€42.3M' },
          { label: 'Gap to plan', value: '€2.2M', tone: 'warn' },
          { label: 'Approvals needed', value: '2' },
        ],
        tradeoff: 'Closes a third of the gap, but both pull-forwards need a programme change approved by the authority, and P-VM-049 is already €84k over budget.',
      },
      {
        id: 'o3',
        label: 'Hold the plan figure and report the gap at year end',
        outcome: 'No change to the forecast round; the gap surfaces in the annual assets chapter.',
        figures: [
          { label: 'FY2026 forecast', value: '€44.5M', tone: 'crit' },
          { label: 'Known gap hidden', value: '€3.7M', tone: 'crit' },
        ],
        tradeoff: 'Not defensible: the forecast would carry €3.7M the evidence says will not be spent, and three of the slips are already in writing from suppliers.',
      },
    ],
    recommendation:
      'Take the October forecast round at €40.8M and request a €3.7M carry-over into FY2027, after the project office reforecasts the four unassessed projects by 30 September. Intervene this week on T1 (service committee 1 October), bus tranche 2 (keep BUS-201 to 208 in service to late October) and the Les Aubiers lift (re-plan commissioning).',
    recommendationWhy: [
      'The gap is timing, evidenced by three supplier and access slips, not a programme that has shrunk.',
      'The €2.5M overrun against budget is a separate problem and two thirds of it sits in one decision, RC-005-009, which has its own analysis.',
      'A forecast that still carries four projects with no snapshot since June would not survive the authority’s PPI review.',
    ],
    submissions: [
      { label: 'Forecast round R3 (October) pack', audience: 'Keolis Valmont executive committee', template: 'Group capital cycle: forecast round' },
      { label: 'Portfolio intervention review', audience: 'Valmont Métropole, PPI lead', template: 'Authority reporting (DSP): intervention review' },
    ],
    log: [
      { at: '2026-09-15T06:00:00Z', who: 'Rule: forecast vs plan deviation above 5%', what: 'Fired. Working forecast €40.8M against €44.5M plan (8.3%). Analysis opened with the monthly programme review goal.' },
      { at: '2026-09-15T06:04:00Z', who: 'Context Weave analyst', what: 'Read plan phasing, actuals and the working forecast for 29 projects; 25 carry a current forecast.' },
      { at: '2026-09-15T06:09:00Z', who: 'Context Weave analyst', what: 'Read supplier statements in the mailbox: two delivery slips not yet in the ERP or the PPM.' },
      { at: '2026-09-16T08:30:00Z', who: 'Amélie Roussel', what: 'Narrowed scope: FY2026 only, exclude FY2027 tranches. Asked for the four unassessed projects to be named.' },
      { at: '2026-09-16T08:41:00Z', who: 'Context Weave analyst', what: 'Findings ready. Three options with figures; one recommended.' },
    ],
    askRefs: ['What is the FY2026 capital spend against plan?', 'Are all renewal projects within budget?', 'Which renewal projects need intervention this week, and why?'],
  },
  {
    id: 'an-tv100-rc-005-009',
    title: 'Decide RC-005-009 and stay inside the €34.5M envelope',
    goal: 'Should Keolis Valmont approve the bogie frame change request on the TV-100 mid-life overhaul, for how many trams, and does the programme stay inside the €34.5M PPI envelope either way?',
    trigger: 'person',
    triggerDetail:
      'Claire Moreau asked on 22 September, ahead of the authority meeting on 1 October: "Tell me whether to approve the frames, and whether we stay inside the envelope."',
    status: 'needs-input',
    owner: 'Pierre-Yves Collin',
    ownerRole: 'Programme Manager, TV-100 overhaul',
    startedAt: '2026-09-22T09:12:00Z',
    scope: [
      'P-VM-005 Tram TV-100 mid-life overhaul, 24 trams, Transalp Rail Services contract TRS-2024-OVH-01',
      'Approved budget €31.2M, PPI envelope €34.5M, working forecast as of 15 September',
      'Change request RC-005-009, the option study, the overhaul contract and the NDT results in correspondence',
    ],
    constraints: [
      'The €34.5M envelope is the authority’s; crossing it needs an avenant, not a forecast',
      'Fixed-price lots and the residual do not move; only the index-linked slice, the frames, labour and contingency can',
      'A tram with a cracked frame cannot return to service, whatever is decided about cost',
    ],
    question:
      'Will the NDT results for the third batch (trams 113 to 124) be available before the 1 October authority meeting? The recommendation below assumes they will not. If they will, option A or B can be decided on evidence for all 24 trams.',
    findings: [
      {
        id: 'f1',
        headline: 'The overhaul is €1.78M over budget and €1.52M under the envelope today.',
        detail:
          'Forecast total €32.98M against €31.2M approved. Against the €34.5M PPI envelope there is €1.52M of headroom. Cost to complete is €19.65M, of which €1.3M is contingency held separately.',
        evidence: [
          { kind: 'table', text: 'P-VM-005 forecast snapshots February to September 2026; cost to complete committed, uncommitted, contingency', source: 'keolis_valmont_erp.fin', asOf: '2026-09-15' },
        ],
      },
      {
        id: 'f2',
        headline: 'Most of the overrun is an allowance for frames the forecast carries although the change is not approved.',
        detail:
          '€1.32M allowance for frame replacement on 12 trams, €0.34M contract price indexation 2026 under clause 9, €0.12M for four extra months of depot support. RC-005-009 asks for €2.64M and 122 days for all 24 trams.',
        evidence: [
          { kind: 'document', text: 'Requested change €2.64M, +122 days, 24 trams', source: 'P-VM-005_Change_Request_RC-005-009_Bogie_Frames.pdf', asOf: '2026-06-26' },
          { kind: 'document', text: 'Indexation clause 9; frames outside base scope', source: 'TRS-2024-OVH-01_Overhaul_Contract_Transalp.pdf', asOf: '2024-11-04' },
        ],
      },
      {
        id: 'f3',
        headline: 'The option study’s key assumption has failed: frames need replacement, not inspection.',
        detail:
          'The selected option assumed no frame replacement and set a 10% re-appraisal trigger. Batch 1 found 31% of frames cracked; the second NDT batch found 8 of 24. The study must be re-appraised before the decision, which the contract and the study both require.',
        evidence: [
          { kind: 'document', text: 'Selected option assumed no frame replacement; 10% re-appraisal trigger', source: 'P-VM-005_Option_Study_Repair_Overhaul_Replace.pdf', asOf: '2025-10-30' },
          { kind: 'mail', text: '8 of 24 frames cracked after the second NDT batch', source: 'EM-07 P-VM-005 TV-100 frame change request', asOf: '2026-09-18' },
        ],
      },
      {
        id: 'f4',
        headline: 'The envelope holds in every position on the table, but with very different room for the price index.',
        detail:
          'With the current allowance (12 trams) the overhaul price index can rise 10% before the base case crosses €34.5M. With RC-005-009 approved as requested (24 trams, forecast €34.30M) the index can rise only 1.3%. The What-if lens computes both from the same cost decomposition.',
        evidence: [
          { kind: 'table', text: 'Headroom to the €34.5M envelope by lever: index, frames, labour, contingency', source: 'What-if lens, P-VM-005, slices locked to source', asOf: '2026-09-22' },
          { kind: 'assumption', text: 'Indexation for 2027 is taken at the 2026 rate; no 2027 index has been published', source: 'Working assumption' },
        ],
      },
    ],
    gaps: [
      'NDT results for trams 113 to 124 (batch 3) are not in the data or the mailbox. The analysis cannot say whether 12 or 24 trams need frames.',
      'A final cost for the overhaul. The forecast is €32.98M today; a prediction would be a guess and none is offered.',
      'Whether Valmont Métropole treats frame replacement as GER renewal inside the PPI or as an operator cost. The contract register has no allocation line for it.',
    ],
    options: [
      {
        id: 'a',
        label: 'A. Approve RC-005-009 as requested: 24 trams',
        outcome: 'Forecast rises to €34.30M. The envelope holds with €0.2M to spare and the price index can move only 1.3% before it does not.',
        figures: [
          { label: 'Forecast total', value: '€34.30M', tone: 'warn' },
          { label: 'Headroom to envelope', value: '€0.2M', tone: 'crit' },
          { label: 'Index headroom', value: '1.3%', tone: 'crit' },
          { label: 'Schedule', value: '+122 days', tone: 'warn' },
        ],
        tradeoff: 'Settles the scope in one decision, but commits €1.32M for 12 trams nobody has inspected yet and leaves no room for the 2027 index.',
      },
      {
        id: 'b',
        label: 'B. Approve 12 trams now on evidence, re-decide after batch 3',
        outcome: 'Forecast stays €32.98M. The index can rise 10% before the envelope is crossed. The second half of the request is decided when the NDT results exist.',
        figures: [
          { label: 'Forecast total', value: '€32.98M' },
          { label: 'Headroom to envelope', value: '€1.52M', tone: 'good' },
          { label: 'Index headroom', value: '10%', tone: 'good' },
          { label: 'Schedule', value: '+122 days', tone: 'warn' },
        ],
        tradeoff: 'Two decisions instead of one, and Transalp has asked for a single instruction. The schedule impact is the same either way because frames are on the critical path.',
        recommended: true,
      },
      {
        id: 'c',
        label: 'C. Defer the decision to the next authority meeting',
        outcome: 'No change to the forecast. Trams with cracked frames stay out of service and the 122 days start running anyway.',
        figures: [
          { label: 'Forecast total', value: '€32.98M' },
          { label: 'Trams held out of service', value: '8', tone: 'crit' },
          { label: 'Schedule', value: '+122 days and counting', tone: 'crit' },
        ],
        tradeoff: 'Costs nothing on paper and the most in service: eight trams cannot run and the overhaul contractor is idle on the frame line.',
      },
    ],
    recommendation:
      'Approve the frame replacement for the 12 trams with evidence (option B), keep the €1.3M contingency untouched, and set a trigger: if batch 3 finds 10% or more cracked, the remaining 12 are approved at the next meeting without a new study. Send the authority a decision brief under DSP-VM-2021 with the NDT evidence, so the PPI treatment of frames is settled at the same time.',
    recommendationWhy: [
      'It is the only option that keeps meaningful headroom for the 2027 price index, which nobody can set today.',
      'It commits money only where there is a cracked frame on record; the other 12 trams are a question, not a fact.',
      'The schedule cost is identical in all three options, so time is not a reason to choose A.',
    ],
    submissions: [
      { label: 'Decision brief: RC-005-009 bogie frames', audience: 'Valmont Métropole, mobility directorate', template: 'Authority reporting (DSP): change request brief' },
      { label: 'Investment committee note, TV-100 overhaul', audience: 'Keolis Valmont executive committee', template: 'Group capital cycle: committee note' },
    ],
    log: [
      { at: '2026-09-22T09:12:00Z', who: 'Claire Moreau', what: 'Started the analysis with the goal above. Deadline: authority meeting 1 October.' },
      { at: '2026-09-22T09:14:00Z', who: 'Context Weave analyst', what: 'Read P-VM-005 forecast snapshots, the change request, the option study and the overhaul contract.' },
      { at: '2026-09-22T09:19:00Z', who: 'Context Weave analyst', what: 'Ran the What-if lens for the two positions on the table; headroom computed per lever.' },
      { at: '2026-09-22T09:21:00Z', who: 'Context Weave analyst', what: 'One question for the programme manager before the recommendation is final: batch 3 NDT timing.' },
      { at: '2026-09-23T14:05:00Z', who: 'Pierre-Yves Collin', what: 'Challenged finding 3: asked whether the 31% in batch 1 counts hairline indications. Analyst answer: it counts rejections under the NDT acceptance criterion in the contract, appendix D.' },
    ],
    askRefs: ['Why has the TV-100 overhaul forecast grown?', 'What is the forecast cost to complete on the TV-100 overhaul, and does it include contingency?', 'What will the TV-100 overhaul finally cost?'],
  },
]

/** Rules and schedules that can start an analysis without a person. Shown on the list page. */
export const WATCHERS = [
  { id: 'w1', kind: 'rule' as const, label: 'Forecast vs plan deviation above 5%', detail: 'Checks the working forecast against plan after every snapshot. Last fired 15 September; opened the FY2026 programme analysis.', state: 'Fired' },
  { id: 'w2', kind: 'schedule' as const, label: 'Monthly programme review', detail: 'First Monday of the month, over the 29 funded projects. Next run 5 October.', state: 'Scheduled' },
  { id: 'w3', kind: 'rule' as const, label: 'Supplier date in correspondence differs from the schedule', detail: 'Reads delivery dates in the mailbox and compares them with the PPM. Two matches this month (bus tranche 2, Les Aubiers lift), both folded into the open analysis.', state: 'Matched' },
  { id: 'w4', kind: 'rule' as const, label: 'Project over budget by more than 5%', detail: 'Watching 25 assessed projects. P-VM-005 at 5.7% is the only match; it has its own analysis.', state: 'Matched' },
]
