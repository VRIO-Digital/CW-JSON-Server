/*
 * The streamlined Goals flow (4 Nov 2026): every human input is taken once, at the start.
 *
 * One-off goal: the agent plans, asks only what it could not find, and in the same step agrees the
 * deliverables (one or several) and the template for each (the one it recommends, one from the library,
 * one you upload, or one it designs). Then it runs to the end by itself: findings are accepted, the top
 * recommendation is chosen and the deliverables are built. You can still open the findings and the other
 * recommendations afterwards and change anything; the deliverables are rebuilt.
 *
 * Standing goal: the same at set-up, plus the actions it may take when it fires, each one either done
 * automatically or held for your OK. When it fires it runs, chooses, acts, builds and tells you.
 *
 * This file holds the deliverable and action vocabulary; the words and figures come from the package.
 */

import type { SubmissionSuggestion } from './goalCases'
import type { OutputFormat, Template } from './submissionTemplates'
import { JOURNEYS_RAW } from './journeyCases'

export type TplMode = 'recommended' | 'library' | 'upload' | 'ai'
export const TPL_MODE_LABEL: Record<TplMode, string> = { recommended: 'Recommended', library: 'From the library', upload: 'Upload your own', ai: 'Create one for me' }

/** One deliverable the run will build, and the template it is built on. */
export interface DelivSpec {
  id: string
  label: string
  audience: string
  purpose: string
  why?: string
  format: OutputFormat
  on: boolean
  mode: TplMode
  /** The template the agent recommends (from the library). */
  recId?: string
  /** The template it will be built on, for library and upload. */
  templateId?: string
  /** For "create one for me": anything it must cover, in your words. */
  describe?: string
  uploadName?: string
  /** Added by you, not one the agent proposed. */
  custom?: boolean
}

export const specFromSuggestion = (s: SubmissionSuggestion, templates: Template[], on = true): DelivSpec => {
  const t = templates.find((x) => x.id === s.templateId)
  return { id: s.id, label: s.label, audience: s.audience, purpose: s.purpose, why: s.why, format: t?.format ?? 'Document', on, mode: t ? 'recommended' : 'ai', recId: t?.id }
}

/** The template a spec resolves to, when it is already in the library (recommended, library, upload). */
export const templateOf = (d: DelivSpec, templates: Template[]): Template | undefined =>
  d.mode === 'recommended' ? templates.find((t) => t.id === d.recId) : d.mode === 'library' || d.mode === 'upload' ? templates.find((t) => t.id === d.templateId) : undefined

/** One line on what a spec will be built on. */
export const templateLine = (d: DelivSpec, templates: Template[]): string => {
  const t = templateOf(d, templates)
  if (d.mode === 'ai') return 'a structure I design for this reader'
  if (d.mode === 'upload') return t ? `your file ${d.uploadName ?? t.name}` : 'your file (not chosen yet)'
  return t ? t.name.replace(/\.(xlsx|pptx|docx)$/i, '') : 'a template (not chosen yet)'
}
export const specReady = (d: DelivSpec, templates: Template[]) => !d.on || d.mode === 'ai' || !!templateOf(d, templates)

/** More the agent can offer from the same analysis, from templates already in the library; unticked unless you want them. (journeys.json › once/watch.extraDeliverables) */
export const EXTRA_OFFERS: Record<'once' | 'watch', SubmissionSuggestion[]> = { once: JOURNEYS_RAW.once.extraDeliverables, watch: JOURNEYS_RAW.watch.extraDeliverables }

/** Generic deliverables when no recorded analysis matches the goal. (journeys.json › generic.deliverables) */
export const GENERIC_SPECS: DelivSpec[] = JOURNEYS_RAW.generic.deliverables

/* ------------------------------------------------------------------ actions a standing goal may take */

export type ActMode = 'auto' | 'ask'
export interface ActionCat { key: string; text: string; why: string; mode: ActMode; outside?: boolean; /** For a watch: what sets the rule off. */ when?: string; on?: boolean; custom?: boolean }
export interface ExecAction { cat: string; text: string; state: 'todo' | 'done' | 'waiting' | 'approved' | 'declined' }

/** Agreed when the watch is set up: what it may do when it fires. Internal requests run by themselves; anything that commits money or goes outside the company waits for your OK. (journeys.json › watch.actions) */
export const WATCH_ACTIONS: ActionCat[] = JOURNEYS_RAW.watch.actions.categories
export const SCHEDULE_ACTIONS: ActionCat[] = JOURNEYS_RAW.schedule.actions.categories
export const GENERIC_ACTIONS: ActionCat[] = JOURNEYS_RAW.generic.actions.categories

const TELL_NAMES: Record<string, string> = JOURNEYS_RAW.watch.actions.tellNames
export const tellNames = (tell?: string) => TELL_NAMES[tell ?? ''] ?? Object.values(TELL_NAMES)[Object.values(TELL_NAMES).length - 1]

/** What option N of the outlet watch does, action by action, each under the category its mode comes from. */
export const watchActionsFor = (recId: string, tell?: string): { cat: string; text: string }[] =>
  ((JOURNEYS_RAW.watch.actions.byOption[recId] ?? JOURNEYS_RAW.watch.actions.byOption.r1) as { cat: string; text: string }[]).map((a) => ({ cat: a.cat, text: a.text.replace('{to}', tellNames(tell)) }))
export const scheduleActionsFor = (): { cat: string; text: string }[] => (JOURNEYS_RAW.schedule.actions.run as { cat: string; text: string }[]).map((a) => ({ ...a }))
