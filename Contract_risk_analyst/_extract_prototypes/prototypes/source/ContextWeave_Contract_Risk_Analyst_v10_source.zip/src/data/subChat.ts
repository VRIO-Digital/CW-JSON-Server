import { create } from 'zustand'
import type { ChatMsg } from '../store/goalStore'
import type { Goal } from './goalCases'
import { roleOf } from './outputDesigner'
import type { ReadFile } from './readFile'
import type { OutputFormat, Template } from './submissionTemplates'

/*
 * The conversation on the Submissions screens, the same way a goal is worked: what is being built on
 * the left, the agent on the right, and every step can be clicked or said. One chat per submission, and
 * one for "new submission" (key "new"). Rule-based reading of what is said; the product would use a model.
 */

let seq = 0
export const smsg = (who: ChatMsg['who'], text: string, file?: ChatMsg['file']): ChatMsg => ({ id: `s${(seq += 1)}-${Date.now().toString(36)}`, at: new Date().toISOString(), who, text, file })

interface SubChatState {
  chats: Record<string, ChatMsg[]>
  typing: Record<string, boolean>
  say: (id: string, who: ChatMsg['who'], text: string, file?: ChatMsg['file']) => void
  setTyping: (id: string, on: boolean) => void
  reset: (id: string, msgs: ChatMsg[]) => void
}
export const useSubChat = create<SubChatState>((set, get) => ({
  chats: {},
  typing: {},
  say: (id, who, text, file) => set({ chats: { ...get().chats, [id]: [...(get().chats[id] ?? []), smsg(who, text, file)] } }),
  setTyping: (id, on) => set({ typing: { ...get().typing, [id]: on } }),
  reset: (id, msgs) => set({ chats: { ...get().chats, [id]: msgs } }),
}))

/* ------------------------------------------------------------------ a template from a file */

const FORMAT_OF = (name: string): OutputFormat => (/\.pptx$/i.test(name) ? 'Slide pack' : /\.xlsx$/i.test(name) ? 'Workbook' : /\.(eml|msg)$/i.test(name) ? 'Email' : 'Document')

/** Read a past deliverable or an audience's template into a library template: a pptx gives one section per
 *  slide (its title), a docx its short heading-like lines. A file the browser cannot open keeps a generic structure. */
export function templateFromRead(r: ReadFile): Template {
  const format = FORMAT_OF(r.name)
  let heads: string[] = []
  if (r.kind === 'slides') heads = r.units.map((u) => u.split('\n')[0]?.trim()).filter((h) => h && h.length < 90)
  else if (r.kind === 'document' || r.kind === 'text') heads = r.units.map((u) => u.split('\n')[0].trim()).filter((h) => h.length > 2 && h.length < 70 && !/[.;]$/.test(h) && h.split(' ').length <= 10)
  heads = heads.filter((h, i) => heads.indexOf(h) === i).slice(0, 14)
  const read = heads.length >= 2
  const sections = read
    ? heads.map((h) => ({ heading: h, role: roleOf(h) }))
    : [{ heading: 'Purpose', role: 'purpose' as const }, { heading: 'Summary', role: 'summary' as const }, { heading: 'Analysis', role: 'findings' as const }, { heading: 'Options', role: 'options' as const }, { heading: 'Evidence', role: 'evidence' as const }, { heading: 'Next steps', role: 'next' as const }]
  return {
    id: `t-file-${Date.now().toString(36)}`,
    name: r.name.replace(/\.[a-z0-9]+$/i, '').replace(/[_-]+/g, ' '),
    family: 'Your file',
    format,
    file: r.name,
    note: read ? `Structure read from ${r.name}: ${sections.length} ${format === 'Slide pack' ? 'slides' : 'sections'}.` : `Attached ${r.name}; this prototype could not read its structure, so it has a standard one you can edit.`,
    sections,
  }
}

/* ------------------------------------------------------------------ shared reading helpers */

const WORDS: Record<string, number> = { one: 1, first: 1, two: 2, second: 2, three: 3, third: 3, four: 4, fourth: 4, five: 5, fifth: 5, six: 6, sixth: 6, seven: 7, eight: 8 }
export const num = (s?: string) => (s ? (/^\d+$/.test(s) ? Number(s) : WORDS[s.toLowerCase()]) : undefined)
const N = '(\\d+|one|two|three|four|five|six|seven|eight|first|second|third|fourth|fifth|sixth)'

/** The best match for some words among labelled items, by shared words; undefined when nothing shares a word. */
export function bestMatch<T>(words: string, items: T[], label: (x: T) => string): T | undefined {
  const want = words.toLowerCase().split(/\W+/).filter((w) => w.length > 3 && !['template', 'submission', 'the', 'with', 'from', 'goal', 'that', 'this'].includes(w))
  if (!want.length) return undefined
  const scored = items.map((x) => ({ x, n: want.filter((w) => label(x).toLowerCase().includes(w)).length })).sort((a, b) => b.n - a.n)
  return scored[0]?.n ? scored[0].x : undefined
}

export const FORMAT_WORDS: [RegExp, OutputFormat][] = [
  [/\b(slide|slides|deck|presentation|pack|powerpoint)\b/i, 'Slide pack'], [/\bdashboard\b/i, 'Dashboard'], [/\b(spreadsheet|workbook|excel|sheet)\b/i, 'Workbook'],
  [/\b(email|e-mail|mail)\b/i, 'Email'], [/\bmemo\b/i, 'Memo'], [/\b(document|report|note|brief)\b/i, 'Document'],
]

/* ------------------------------------------------------------------ inside a submission */

export type SubIntent =
  | { k: 'help' } | { k: 'next' } | { k: 'back'; to?: 'brief' | 'template' | 'outline' | 'draft' }
  | { k: 'title'; v: string } | { k: 'audience'; v: string } | { k: 'purpose'; v: string }
  | { k: 'pickTemplate' } | { k: 'useTemplate'; n?: number; words?: string } | { k: 'saveTemplate'; name?: string } | { k: 'useUploaded' }
  | { k: 'remove'; n: number } | { k: 'restore'; n: number } | { k: 'add'; heading: string } | { k: 'rename'; n: number; v: string } | { k: 'write'; n: number; v: string } | { k: 'show'; n: number }
  | { k: 'review' } | { k: 'download'; as?: string } | { k: 'share' } | { k: 'lineage' } | { k: 'refresh' } | { k: 'goal' }
  | { k: 'unknown' }

export function interpretSub(raw: string, stage: string): SubIntent {
  const r = raw.trim().replace(/[!?]+$/, '')
  const t = r.toLowerCase()
  let m: RegExpMatchArray | null
  const tail = (x: string) => r.slice(r.length - x.length).trim()
  if (/^(help|what can i (say|do)( here)?)$/.test(t)) return { k: 'help' }
  if ((m = t.match(/^(?:title|call it|rename it|name it)\s*[:\-]?\s+(.+)$/))) return { k: 'title', v: tail(m[1]) }
  if ((m = t.match(/^(?:audience|for|to|reader|readers|it is for|it's for)\s*[:\-]?\s+(.{3,})$/)) && stage === 'brief') return { k: 'audience', v: tail(m[1]) }
  if ((m = t.match(/^(?:purpose|so that|the reader should|it should)\s*[:\-]?\s+(.{3,})$/))) return { k: 'purpose', v: tail(m[1]) }
  if (/\b(use (it|the uploaded|my file|that file)|apply it|yes,? use it)\b/.test(t)) return { k: 'useUploaded' }
  if (/\bsave\b.*\btemplate\b/.test(t)) { const nm = r.match(/\bas\s+["“']?(.+?)["”']?\s*$/i); return { k: 'saveTemplate', name: nm && !/template$/i.test(nm[1]) ? nm[1] : undefined } }
  if (/\b(change|another|different|pick a|choose a|library) template\b|\buse a library template\b|\bwhich templates\b/.test(t)) return { k: 'pickTemplate' }
  if ((m = t.match(new RegExp(`^(?:use|apply|switch to|take)\\s+(?:the\\s+)?(?:template\\s+${N}|(.+))$`)))) return { k: 'useTemplate', n: num(m[1]), words: m[2] }
  if ((m = t.match(new RegExp(`^template\\s+${N}$`)))) return { k: 'useTemplate', n: num(m[1]) }
  if ((m = t.match(new RegExp(`(?:remove|drop|delete|untick|leave out)\\s+(?:section\\s+|slide\\s+|panel\\s+|sheet\\s+)?${N}\\b`)))) return { k: 'remove', n: num(m[1])! }
  if ((m = t.match(new RegExp(`(?:put back|restore|bring back|tick|include)\\s+(?:section\\s+|slide\\s+|panel\\s+|sheet\\s+)?${N}\\b`)))) return { k: 'restore', n: num(m[1])! }
  if ((m = t.match(/^add (?:a |another )?(?:section|slide|panel|sheet)(?: on| about| for| called|:)?\s+(.{3,})$/))) return { k: 'add', heading: tail(m[1]) }
  if ((m = t.match(new RegExp(`^(?:rename|retitle|call)\\s+(?:section\\s+|slide\\s+|panel\\s+|sheet\\s+)?${N}\\s+(?:to|as)?\\s*(.{3,})$`)))) return { k: 'rename', n: num(m[1])!, v: tail(m[2]) }
  if ((m = t.match(new RegExp(`^(?:write|fill|text for|in)\\s+(?:section\\s+|slide\\s+|panel\\s+|sheet\\s+)?${N}\\s*[:,\\-]\\s*(.{3,})$`)))) return { k: 'write', n: num(m[1])!, v: tail(m[2]) }
  if ((m = t.match(new RegExp(`^(?:show|what is in|what's in|read)\\s+(?:section\\s+|slide\\s+|panel\\s+|sheet\\s+)?${N}$`)))) return { k: 'show', n: num(m[1])! }
  if (/\b(mark (it )?(as )?reviewed|reviewed|sign (it )?off|i('ve| have) reviewed)\b/.test(t)) return { k: 'review' }
  if ((m = t.match(/\b(download|export|save a copy)\b(?:.*\b(pptx|powerpoint|pdf|png|image|html|csv)\b)?/))) return { k: 'download', as: m[2] }
  if (/\b(share|link)\b/.test(t)) return { k: 'share' }
  if (/\b(lineage|where .* (come|comes|came) from|sources?)\b/.test(t)) return { k: 'lineage' }
  if (/\brefresh\b/.test(t)) return { k: 'refresh' }
  if (/\b(open|go to|back to) the goal\b/.test(t)) return { k: 'goal' }
  if ((m = t.match(/\b(?:back to|go to|open)\s+(?:the\s+)?(brief|template|outline|draft)\b/))) return { k: 'back', to: m[1] as 'brief' }
  if (/^(back|previous|go back)$/.test(t)) return { k: 'back' }
  if (/\b(next|continue|go on|looks good|that'?s (fine|right|good)|ok|okay|yes|build (the )?draft|keep it|carry on|move on)\b/.test(t)) return { k: 'next' }
  return { k: 'unknown' }
}

/* ------------------------------------------------------------------ new submission */

export type NewIntent =
  | { k: 'help' } | { k: 'fromGoal'; goal?: Goal } | { k: 'fromTemplate' } | { k: 'recommend' } | { k: 'startRec'; n?: number; words?: string }
  | { k: 'blank' } | { k: 'describe' } | { k: 'format'; f: OutputFormat; rest: string } | { k: 'example' } | { k: 'remove'; n: number } | { k: 'rename'; n: number; v: string }
  | { k: 'add'; heading: string } | { k: 'create' } | { k: 'template'; n?: number; words?: string } | { k: 'goals'; goals: Goal[] } | { k: 'start' }
  | { k: 'text'; v: string } | { k: 'unknown' }

export function interpretNew(raw: string, ctx: { mode: 'goal' | 'template'; path: 'recommend' | 'describe'; hasProposal: boolean; goals: Goal[] }): NewIntent {
  const r = raw.trim().replace(/[!?]+$/, '')
  const t = r.toLowerCase()
  let m: RegExpMatchArray | null
  const tail = (x: string) => r.slice(r.length - x.length).trim()
  if (/^(help|what can i (say|do)( here)?)$/.test(t)) return { k: 'help' }
  if (/\bfrom a template\b|\buse a template\b|\bstart from a template\b/.test(t)) return { k: 'fromTemplate' }
  if (/^(back to |go back to |switch to )?(from )?a goal$|\bfrom a goal\b|\bback to (the )?goals?\b/.test(t)) return { k: 'fromGoal' }
  if (ctx.hasProposal) {
    if ((m = t.match(new RegExp(`(?:remove|drop|delete)\\s+(?:slide\\s+|section\\s+|panel\\s+|sheet\\s+)?${N}\\b`)))) return { k: 'remove', n: num(m[1])! }
    if ((m = t.match(new RegExp(`^(?:rename|call)\\s+(?:slide\\s+|section\\s+|panel\\s+|sheet\\s+)?${N}\\s+(?:to|as)?\\s*(.{3,})$`)))) return { k: 'rename', n: num(m[1])!, v: tail(m[2]) }
    if ((m = t.match(/^add (?:a |another )?(?:slide|section|panel|sheet)(?: on| about| for| called|:)?\s+(.{3,})$/))) return { k: 'add', heading: tail(m[1]) }
    if (/\b(create( it)?|make it|go ahead|looks good|yes|build it|do it)\b/.test(t)) return { k: 'create' }
  }
  if (/\b(blank|from scratch|write it (myself|yourself)|by hand|manually)\b/.test(t)) return { k: 'blank' }
  if (/\bexample\b/.test(t)) return { k: 'example' }
  if (/\b(describe|new output|something else|my own|none of these|custom)\b/.test(t)) return { k: 'describe' }
  if (ctx.mode === 'template') {
    if ((m = t.match(new RegExp(`^(?:template\\s+${N}|(?:use|take|pick)\\s+(?:the\\s+)?(?:template\\s+${N}|(.+)))$`)))) return { k: 'template', n: num(m[1] ?? m[2]), words: m[3] }
    if (/\b(start|create|go|begin)\b/.test(t) && !/goal/.test(t)) return { k: 'start' }
    if (/\b(both|all)( the)? goals\b|\bboth\b/.test(t)) return { k: 'goals', goals: ctx.goals }
    const picked = ctx.goals.filter((g) => bestMatch(t, [g], (x) => x.title)) as Goal[]
    if ((m = t.match(new RegExp(`goal\\s+${N}`))) && ctx.goals[num(m[1])! - 1]) return { k: 'goals', goals: [ctx.goals[num(m[1])! - 1]] }
    if (picked.length) return { k: 'goals', goals: picked }
    if (/\btemplate\b/.test(t) || t.length > 3) return { k: 'template', words: t }
  }
  if ((m = t.match(new RegExp(`goal\\s+${N}`))) && ctx.goals[num(m[1])! - 1]) return { k: 'fromGoal', goal: ctx.goals[num(m[1])! - 1] }
  const g = /\bgoal\b|\bfor the\b|\bdunmoor|quarterly|committee|filter|c23b/.test(t) ? bestMatch(t, ctx.goals, (x) => x.title) : undefined
  if (g && !/\b(slide|deck|dashboard|memo|email|spreadsheet|document)\b/.test(t)) return { k: 'fromGoal', goal: g }
  if (/\bfrom a goal\b/.test(t)) return { k: 'fromGoal' }
  if (/\b(recommend|recommendations|suggest|suggestions|what should i send|options)\b/.test(t)) return { k: 'recommend' }
  if (ctx.path === 'recommend' && (m = t.match(new RegExp(`^(?:start|use|take|pick|go with|open)\\s+(?:the\\s+)?(?:number\\s+|#)?(?:${N}\\b)?\\s*(.*)$`)))) return { k: 'startRec', n: num(m[1]), words: m[2] }
  const f = FORMAT_WORDS.find(([re]) => re.test(t))
  if (f && (ctx.path === 'describe' || t.split(' ').length <= 4)) return { k: 'format', f: f[1], rest: r }
  if (ctx.path === 'describe' && t.length > 20) return { k: 'text', v: r }
  return { k: 'unknown' }
}
