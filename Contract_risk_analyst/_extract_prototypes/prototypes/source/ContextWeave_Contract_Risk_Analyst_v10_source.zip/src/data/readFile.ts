import JSZip from 'jszip'

/*
 * A file dropped into the chat, read in the browser. PowerPoint and Word files are opened (they are zip
 * archives of XML) and their text is read slide by slide or paragraph by paragraph; plain text, Markdown
 * and CSV are read as they are. PDF and spreadsheets are attached by name only in this prototype; the
 * product reads them server side. Nothing leaves the browser.
 */

export interface ReadFile {
  name: string
  size: number
  kind: 'slides' | 'document' | 'text' | 'other'
  /** One entry per slide or paragraph block, in order. */
  units: string[]
  /** The problem the file states, if it states one: the slide or paragraph that says "problem", else the first substantive one. */
  problem?: string
  /** Short title: the first slide's or the first line's text. */
  title?: string
}

const xmlText = (xml: string, tag: string) => {
  const out: string[] = []
  const re = new RegExp(`<${tag}(?:\\s[^>]*)?>([^<]*)</${tag}>`, 'g')
  let m: RegExpExecArray | null
  while ((m = re.exec(xml))) out.push(m[1])
  return out
}
const decode = (s: string) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#x2019;|&#8217;/g, '’')

async function readPptx(buf: ArrayBuffer): Promise<string[]> {
  const zip = await JSZip.loadAsync(buf)
  const slides = Object.keys(zip.files).filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a, b) => Number(a.match(/\d+/)![0]) - Number(b.match(/\d+/)![0]))
  const out: string[] = []
  for (const n of slides) {
    const xml = await zip.files[n].async('string')
    /* Paragraphs inside a slide: join their runs, then join paragraphs with a line break. */
    const paras = xml.split(/<\/a:p>/).map((p) => xmlText(p, 'a:t').join('')).map((t) => decode(t).trim()).filter(Boolean)
    out.push(paras.join('\n'))
  }
  return out
}

async function readDocx(buf: ArrayBuffer): Promise<string[]> {
  const zip = await JSZip.loadAsync(buf)
  const xml = await zip.file('word/document.xml')?.async('string')
  if (!xml) return []
  return xml.split(/<\/w:p>/).map((p) => decode(xmlText(p, 'w:t').join('')).trim()).filter(Boolean)
}

const PROBLEM = /\b(problem|challenge|issue|pain|why now|what we need|objective|goal|we want|we need)\b/i

export async function readUpload(file: File): Promise<ReadFile> {
  const ext = file.name.toLowerCase().split('.').pop() ?? ''
  let units: string[] = []
  let kind: ReadFile['kind'] = 'other'
  try {
    if (ext === 'pptx') { units = await readPptx(await file.arrayBuffer()); kind = 'slides' }
    else if (ext === 'docx') { units = await readDocx(await file.arrayBuffer()); kind = 'document' }
    else if (['txt', 'md', 'csv'].includes(ext)) { units = (await file.text()).split(/\n\s*\n/).map((x) => x.trim()).filter(Boolean); kind = 'text' }
  } catch {
    units = []
    kind = 'other'
  }
  const flat = units.map((u) => u.replace(/\s+/g, ' ').trim())
  const hit = flat.findIndex((u) => PROBLEM.test(u))
  let problem: string | undefined
  if (hit >= 0) {
    /* The heading that says "problem" is rarely the problem itself: take what follows it on the slide, or the next block. */
    const lines = units[hit].split('\n').map((l) => l.trim()).filter(Boolean)
    const after = lines.findIndex((l) => PROBLEM.test(l))
    const rest = lines.slice(after + 1).join(' ').trim()
    problem = rest.length > 25 ? rest : (lines.join(' ').length > 40 ? lines.join(' ') : flat[hit + 1] ?? lines.join(' '))
  } else {
    problem = flat.find((u) => u.length > 40)
  }
  if (problem && problem.length > 420) problem = `${problem.slice(0, 418).replace(/\s\S*$/, '')}…`
  const title = units[0]?.split('\n')[0]?.trim()
  return { name: file.name, size: file.size, kind, units, problem, title }
}

export const fileSize = (n: number) => (n > 1_000_000 ? `${(n / 1_000_000).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1000))} KB`)
export const describeRead = (r: ReadFile) =>
  r.kind === 'slides' ? `${r.units.length} slide${r.units.length === 1 ? '' : 's'}` : r.kind === 'document' ? `${r.units.length} paragraphs` : r.kind === 'text' ? `${r.units.length} blocks of text` : 'attached by name; this prototype reads PowerPoint, Word, text and Markdown'
