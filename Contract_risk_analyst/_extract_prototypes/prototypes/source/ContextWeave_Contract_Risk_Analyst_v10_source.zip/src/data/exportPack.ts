import { download, eur, fundedProjects, projectByCode, snapshotsFor } from './drill'
import type { Goal } from './goalCases'

/*
 * The analysis pack: one self-contained HTML file with everything on the goal page, plus the drill
 * tables the findings point at. It opens anywhere, prints to PDF, and carries the status, the
 * assumptions and the open items as stated on screen, so the saved analysis cannot look more settled
 * than the live one.
 */

const esc = (s: unknown) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c] as string)
const li = (xs: string[]) => `<ul>${xs.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`
const table = (cols: string[], rows: (string | number | null | undefined)[][]) =>
  `<table><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((v) => `<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`

export function buildPack(g: Goal, statusLabel: string, triggerLabel: string): string {
  const date = new Date().toLocaleString('en-GB', { dateStyle: 'long', timeStyle: 'short' })
  const projects = new Set<string>()
  g.findings.forEach((f) => f.drill.project && projects.add(f.drill.project))

  const portfolio = fundedProjects()
  const assessed = portfolio.filter((p) => p.assessed)
  const sum = (f: (p: (typeof portfolio)[number]) => number | null) => assessed.reduce((n, p) => n + (f(p) ?? 0), 0)

  const projectSections = [...projects]
    .map((code) => {
      const p = projectByCode(code)
      if (!p) return ''
      const snaps = snapshotsFor(code)
      return `<h3>${esc(p.code)} · ${esc(p.name)}</h3>
<p>${esc(p.category)} · ${esc(p.stage)} · PM ${esc(p.pm)}. Approved ${eur(p.budget)} (${esc(p.budget_version)}); forecast total ${eur(p.forecast)}; variance ${eur(p.variance)}. Posted actuals ${eur(p.actuals)}, valid accruals ${eur(p.accruals)}, committed ${eur(p.snapshot?.committed ?? null)}, uncommitted ${eur(p.snapshot?.uncommitted ?? null)}, contingency ${eur(p.snapshot?.contingency ?? null)}; snapshot ${esc(p.snapshot?.date)}.</p>
${table(['Snapshot', 'Actuals through', 'Committed', 'Uncommitted', 'Contingency', 'Scenario'], snaps.map((s) => [s.d, s.t, eur(s.c), eur(s.u), eur(s.g), s.s]))}`
    })
    .join('')

  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${esc(g.title)} · analysis pack</title>
<style>
body{font:14px/1.5 -apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#0f1729;max-width:980px;margin:32px auto;padding:0 24px}
h1{font-size:24px;letter-spacing:-.4px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 8px;border-bottom:1px solid #e9ecf1;padding-bottom:4px}h3{font-size:14.5px;margin:18px 0 6px}
.meta{color:#4b5a75;font-size:13px}.tag{display:inline-block;border:1px solid #e9ecf1;border-radius:4px;padding:1px 8px;font-size:12px;margin-right:6px;background:#fafbfc}
.box{border:1px solid #e9ecf1;border-radius:8px;padding:12px 16px;margin:10px 0;background:#fff}.rec{border-color:#f4562b}
table{border-collapse:collapse;width:100%;font-size:12.5px;margin:8px 0}th,td{border-bottom:1px solid #e9ecf1;padding:5px 8px;text-align:left;vertical-align:top}th{background:#fafbfc;font-weight:600}
.small{font-size:12px;color:#4b5a75}.warn{color:#b45309}dl{display:grid;grid-template-columns:180px 1fr;gap:4px 12px;margin:8px 0}dt{color:#4b5a75;font-size:12.5px}dd{margin:0}
@media print{body{margin:0}}
</style></head><body>
<h1>${esc(g.title)}</h1>
<div class="meta">Analysis pack saved ${esc(date)} · <span class="tag">${esc(statusLabel)}</span><span class="tag">${esc(triggerLabel)}</span> Accountable: ${esc(g.owner)}, ${esc(g.ownerRole)} · Agent: ${esc(g.agent.name)}</div>
<p>${esc(g.goal)}</p>
${g.question ? `<div class="box warn"><strong>Open question for the accountable person:</strong> ${esc(g.question)}</div>` : ''}

<h2>Target</h2>
<dl><dt>Measure</dt><dd>${esc(g.target.measure)}</dd><dt>Target</dt><dd>${esc(g.target.target)}</dd><dt>Where it stands</dt><dd>${esc(g.target.current)}</dd><dt>Tolerance</dt><dd>${esc(g.target.tolerance)}</dd><dt>Deadline</dt><dd>${esc(g.target.deadline)}</dd><dt>Decision asked</dt><dd>${esc(g.target.decision)}</dd></dl>
<h3>Scope</h3>${li(g.scope)}<h3>Constraints, treated as fixed</h3>${li(g.constraints.length ? g.constraints : ['None stated'])}

<h2>Approach${g.planApproved ? ` <span class="small">approved by ${esc(g.planApproved.by)} on ${esc(new Date(g.planApproved.at).toLocaleDateString('en-GB'))}</span>` : ' <span class="small">not yet approved</span>'}</h2>
${g.plan.filter((s) => s.state !== 'removed').map((s, i) => `<div class="box"><strong>${i + 1}. ${esc(s.title)}</strong>${s.editedBy ? ` <span class="small">(edited by ${esc(s.editedBy)})</span>` : ''}<br>${esc(s.how)}<br><span class="small">Sources: ${esc(s.sources.join('; '))}. Check: ${esc(s.check)}</span></div>`).join('')}

${g.recommendations.length ? `<h2>Recommendations from ${esc(g.agent.name)}</h2>${g.recommendations.map((r) => `<div class="box${r.preferred ? ' rec' : ''}"><strong>${esc(r.title)}${r.preferred ? ' · preferred' : ''}</strong><p>${esc(r.summary)}</p>${table(r.figures.map((f) => f.label), [r.figures.map((f) => f.value)])}<p class="small">Trade-off: ${esc(r.tradeoff)}</p><p class="small">How it was reached: ${r.story.map((b) => esc(b.text)).join(' ')}</p></div>`).join('')}${g.question ? '<p class="small warn">Draft until the open question is answered.</p>' : ''}` : ''}

${g.findings.length ? `<h2>Findings and evidence</h2>${g.findings.map((f, i) => `<div class="box"><strong>${i + 1}. ${esc(f.headline)}</strong><p>${esc(f.detail)}</p>${table(['Kind', 'Evidence', 'Source', 'As of'], f.evidence.map((e) => [e.kind, e.text, e.source, e.asOf ?? '']))}<p class="small">Drill: ${esc(f.drill.note)}</p></div>`).join('')}` : ''}

${g.gaps.length ? `<h2>What the analysis could not establish</h2>${li(g.gaps)}` : ''}

${g.submissions.length ? `<h2>Submissions recommended from these findings</h2>${table(['Submission', 'Audience', 'Purpose', 'Template', 'Why'], g.submissions.map((s) => [s.label, s.audience, s.purpose, s.template, s.why]))}` : ''}

<h2>Data behind the findings</h2>
<h3>Portfolio · ${portfolio.length} funded projects, ${assessed.length} assessed</h3>
<p class="small">Approved (assessed) ${eur(sum((p) => p.budget))} · forecast (assessed) ${eur(sum((p) => p.forecast))} · net variance ${eur(sum((p) => p.variance))} · over budget ${assessed.filter((p) => (p.variance ?? 0) > 0).length}. Forecast total = posted actuals + valid accruals + committed + uncommitted + contingency, latest working snapshot. EUR HT.</p>
${table(['Project', 'Name', 'Category', 'Approved', 'Forecast', 'Variance', 'Snapshot', 'Assessed'], portfolio.sort((a, b) => (b.variance ?? -1e12) - (a.variance ?? -1e12)).map((p) => [p.code, p.name, p.category, eur(p.budget), eur(p.forecast), eur(p.variance), p.snapshot?.date, p.assessed ? 'yes' : 'no']))}
${projectSections}

<h2>How it got here</h2>
${table(['When', 'Who', 'What'], g.log.map((l) => [new Date(l.at).toLocaleString('en-GB'), l.who, l.what]))}
<p class="small">Context Weave · Goals by my agents · Northline Water Group and every figure are invented. This pack is a saved copy of the goal page; the live goal may have moved on.</p>
</body></html>`
}

export const downloadPack = (g: Goal, statusLabel: string, triggerLabel: string) =>
  download(`${g.id}_analysis_pack.html`, buildPack(g, statusLabel, triggerLabel), 'text/html')
