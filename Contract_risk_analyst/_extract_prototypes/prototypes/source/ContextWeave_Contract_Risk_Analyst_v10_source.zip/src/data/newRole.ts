/*
 * What New Role's first two steps offer (Veolia CPA prototype, 19 Oct 2026).
 *
 * Step 1 picks the role from the role library, the industry it works in, and then finds the
 * utilities it covers by reading the connected data; step 2 drafts the role's responsibilities and
 * their tasks, and reads an optional job description into suggested changes. Steps 3 to 6 are the
 * New Graph wizard's own Sources, Personas, Metrics and Hero questions.
 *
 * Organisation, people and figures are fictional (Northline Water Group). English only.
 */
import { LIBRARY, OUT_REASONS, type Area, type Finding, type RoleLib } from './roleLibrary'

export { OUT_REASONS }
export type { Area, Finding, RoleLib }

export const ROLES: RoleLib[] = LIBRARY
export const roleById = (id: string | null) => LIBRARY.find((r) => r.id === id) ?? null

/** The wizard's domain for each role: what the persona, metric and question pools are drafted from. */
export const DOMAIN_OF: Record<string, string> = {
  cpa: 'capital-program',
  reg: 'rate-case-recovery',
  sca: 'contract-change',
  fa: 'capital-program',
}

export interface Industry { id: string; name: string; note: string }
export const INDUSTRIES: Industry[] = [
  { id: 'water', name: 'Water', note: 'Drinking water: treatment, storage and distribution' },
  { id: 'wastewater', name: 'Wastewater', note: 'Collection and treatment' },
  { id: 'electricity', name: 'Electricity', note: 'Generation, transmission and distribution' },
  { id: 'gas', name: 'Natural gas', note: 'Transmission and distribution' },
  { id: 'transit', name: 'Transport and transit', note: 'Bus, rail and tram networks' },
]
export const industryName = (id: string | null) => INDUSTRIES.find((i) => i.id === id)?.name ?? ''

/** One utility found in the connected data. */
export interface FoundUtility {
  code: string
  name: string
  region: string
  commission: string
  projects: number
  approvedB: number
  /** Selected when found, unless it is not a regulated utility. */
  preselect: boolean
}

/** What reading the connected data says, per industry: the steps it shows and the utilities it finds. */
export interface Discovery { steps: string[]; found: FoundUtility[]; none?: string }

const WATER: FoundUtility[] = [
  { code: 'ARD', name: 'Northline Water of Ardenia', region: 'Northvale Region', commission: 'Ardenia Public Service Commission (APSC)', projects: 1111, approvedB: 1.88, preselect: true },
  { code: 'BEL', name: 'Northline Water of Belmara', region: 'Eastmoor Region', commission: 'Belmara Public Utility Commission (BPUC)', projects: 1100, approvedB: 2.18, preselect: true },
  { code: 'COR', name: 'Northline Water of Corvale', region: 'Cascadia Region', commission: 'Corvale Utilities Commission (CUC)', projects: 1100, approvedB: 1.83, preselect: true },
  { code: 'DUN', name: 'Northline Water of Dunmoor', region: 'Lakeshore Region', commission: 'Dunmoor Public Service Commission (DPSC)', projects: 1114, approvedB: 2.32, preselect: true },
  { code: 'SSD', name: 'Shared Services Division', region: 'No region', commission: 'Not regulated', projects: 75, approvedB: 0.06, preselect: false },
]

export const DISCOVERY: Record<string, Discovery> = {
  water: {
    steps: [
      'Reading pmo.project in the PMO project master: 4,500 projects, 5 utility codes',
      'Matching utility codes to pmo.utility: 4 regulated water utilities and 1 shared services division',
      'Reading the commission and region for each one',
      'Counting approved projects and budget per utility in epbcs.plan',
    ],
    found: WATER,
  },
  wastewater: {
    steps: ['Reading pmo.project in the PMO project master: 4,500 projects', 'Looking for wastewater programs and assets'],
    found: [],
    none: 'No wastewater utilities in the connected data. pmo.project holds water projects only. Pick Water, or connect the wastewater systems first.',
  },
  electricity: {
    steps: ['Reading pmo.project in the PMO project master: 4,500 projects', 'Looking for electric utilities'],
    found: [],
    none: 'No electric utilities in the connected data. Northline Water Group runs water utilities only.',
  },
  gas: {
    steps: ['Reading pmo.project in the PMO project master: 4,500 projects', 'Looking for gas utilities'],
    found: [],
    none: 'No gas utilities in the connected data. Northline Water Group runs water utilities only.',
  },
  transit: {
    steps: ['Reading pmo.project in the PMO project master: 4,500 projects', 'Looking for transit networks and operators'],
    found: [],
    none: 'No transit networks in the connected data. Northline Water Group runs water utilities only.',
  },
}

/** How long each discovery line takes to appear: model and warehouse work, paced as it is live. */
export const DISCOVERY_STEP_MS = 850
/** How long drafting the responsibilities takes. */
export const DRAFT_MS = 2600
/** How long reading a job description takes. */
export const JD_MS = 3200

export const shortUtility = (name: string) => name.replace('Northline Water of ', '')

/** Steps a draft is in. */
export const DRAFT_STAGES = ['Read the role library', 'Read the utilities and their commissions', 'Draft responsibilities and tasks']
export const JD_STAGES = ['Read the job description', 'Compare it with the drafted responsibilities', 'Suggest changes']

/** Only the findings that change responsibilities or tasks are offered on step 2. */
export const jdFindings = (r: RoleLib): Finding[] => r.jd.findings.filter((f) => f.kind === 'confirm' || f.kind === 'task' || f.kind === 'scope')

/** The business need New Role hands the later steps and Graph Studio, written from steps 1 and 2. */
export function businessNeed(input: {
  role: RoleLib
  industry: string | null
  utilities: string[]
  reportsTo: string
  inScope: Area[]
}): string {
  const names = WATER.filter((u) => input.utilities.includes(u.code)).map((u) => shortUtility(u.name))
  const where = names.length ? ` for ${names.length > 1 ? `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}` : names[0]}` : ''
  const resp = input.inScope.map((a) => a.name.toLowerCase())
  return `${input.role.name}${where} (${industryName(input.industry).toLowerCase()}). ${input.role.blurb} Responsible for ${resp.join('; ')}.${input.reportsTo ? ` Reports to ${input.reportsTo.trim()}.` : ''}`
}
