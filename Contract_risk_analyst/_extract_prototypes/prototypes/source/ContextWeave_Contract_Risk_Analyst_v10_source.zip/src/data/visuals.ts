import { ONCE_ID, WATCH_ID, type Goal } from './goalCases'
import type { SectionRole } from './submissionTemplates'
import { DRILL } from './drill'
import { ASHBY, CONTRACTS, DESIGN, LOST, RATING_COLOR, RATING_NAME, REDMESA, REGIONS, RULE_TEXT, SCORING, SIGNALS, TODAY, decidesText, driversOf, f1, impactOn, impactRating, movers, planEffect, planFor, portfolio, priorityOf, rating, renewals, score, shortSite } from './risk'

/*
 * Visuals for submissions. A slide, a dashboard panel or a document section gets a picture when its role
 * and heading call for one, drawn live from the drill data (the same rows the worksheet shows), so a
 * dashboard reads the latest position every time it opens. Charts are small inline SVGs built here as
 * strings, so the same picture goes into the page and into the downloaded HTML, PDF and image.
 *
 * Colour: two categorical hues only (plan #1f5fa8, actual or forecast #d97706; validated for colour
 * vision and contrast), a reserved status red for a breach, grey ink for text.
 */

export type VisualKind = 'bullet' | 'hbar' | 'bars-by-month' | 'line-snapshots' | 'hbar-pairs' | 'table' | 'kpis' | 'diagram' | 'waterfall' | 'progress'

export interface Visual {
  kind: VisualKind
  title: string
  /** One sentence under the picture: what to read from it. */
  note: string
  /** The picture as SVG markup (tables render as HTML instead). */
  svg?: string
  /** For a table: header and rows. */
  table?: { columns: string[]; rows: (string | number)[][] }
  /** The series behind the picture, for the data package and the table view. */
  data: Record<string, unknown>
}

const PLAN = '#1f5fa8', ACTUAL = '#d97706', CRIT = '#b42318', INK = '#0f1729', MUTED = '#5c6b84', GRID = '#e3e6ec', SURF = '#ffffff'
const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c] as string)
const eurK = (n: number) => (Math.abs(n) >= 1e9 ? `$${(n / 1e9).toFixed(2)}B` : Math.abs(n) >= 1e6 ? `$${(n / 1e6).toFixed(2)}M` : `$${Math.round(n / 1000)}k`)
const txt = (x: number, y: number, s: string, o: { size?: number; fill?: string; anchor?: 'start' | 'middle' | 'end'; weight?: number } = {}) =>
  `<text x="${x}" y="${y}" font-size="${o.size ?? 11}" fill="${o.fill ?? MUTED}" text-anchor="${o.anchor ?? 'start'}" font-weight="${o.weight ?? 400}" font-family="-apple-system,Segoe UI,Helvetica,Arial,sans-serif">${esc(s)}</text>`
export const legend = (x: number, y: number, items: { label: string; fill: string; outline?: boolean }[]) =>
  items.map((it, i) => `<rect x="${x + i * 118}" y="${y - 9}" width="10" height="10" rx="2" fill="${it.outline ? 'none' : it.fill}" stroke="${it.fill}" stroke-width="1.5"/>${txt(x + i * 118 + 15, y, it.label, { size: 10.5 })}`).join('')
const svgOpen = (w: number, h: number) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="100%" style="display:block;max-width:${w}px;background:${SURF}" role="img">`

/* ------------------------------------------------------------------ charts */

function kpis(items: { label: string; value: string; tone?: string }[], title: string, note: string): Visual {
  return { kind: 'kpis', title, note, data: { items } }
}

/* ------------------------------------------------------------------ the two Goals stories */

const mM = (n: number) => `$${(n / 1e6).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}M`
void eurK

/** The 300 contracts by rating, as bars. */
const m0 = (n: number) => `$${(n / 1e6).toFixed(1)}M`
function ratingBars(): Visual {
  const p = portfolio(SCORING.rule, 'now')
  const rows = [1, 2, 3, 4].map((r) => ({ r, n: p.dist[r] }))
  const W = 620, rowH = 28, top = 14, H = top + rows.length * rowH + 28, labelW = 150, x0 = labelW + 10, x1 = W - 70
  const max = Math.max(...rows.map((x) => x.n)) * 1.05, sx = (v: number) => x0 + ((x1 - x0) * v) / max
  const svg = `${svgOpen(W, H)}${rows.map((x, i) => { const y = top + i * rowH; return `${txt(labelW, y + 14, `${x.r} · ${RATING_NAME[x.r]}`, { size: 10.5, anchor: 'end', fill: INK })}<rect x="${x0}" y="${y + 3}" width="${Math.max(2, sx(x.n) - x0)}" height="15" rx="4" fill="${RATING_COLOR[x.r]}"><title>${x.n} contracts rated ${x.r}</title></rect>${txt(sx(x.n) + 6, y + 15, `${x.n}`, { size: 10.5, fill: INK, weight: 600 })}` }).join('')}${txt(x0, H - 8, `${p.n} contracts · ${p.readings.toLocaleString('en-US')} readings · rating is ${RULE_TEXT[SCORING.rule]}`, { size: 10.5 })}</svg>`
  return { kind: 'hbar', title: `The ${p.n} contracts by rating`, note: `${p.dist[3] + p.dist[4]} contracts rate 3 or 4; they carry ${mM(p.highRevenue)} a year of ${mM(p.revenue)}.`, svg, data: { rows: rows.map((x) => ({ code: String(x.r), name: RATING_NAME[x.r], budget: x.n, forecast: x.n, pct: Number(((x.n / p.n) * 100).toFixed(1)) })) } }
}

/** The readings that changed at the morning check, on the scorecard as it stands. */
function changedTable(): Visual {
  const mv = movers()
  const rows = mv.flatMap((m) => [...m.sigs.map((x) => [m.c.id, m.c.site, x.s.name, x.raw, `${x.from} → ${x.to}`, `${f1(m.s0)} → ${f1(m.s1)}`, `${m.r0} → ${m.r1}`]), ...m.unscored.map((x) => [m.c.id, m.c.site, x.label, 'Seen, not scored', '', '', `${m.r1}`])])
  return { kind: 'table', title: 'Readings that changed at the 06:00 check of 20 November', note: `${mv.length} contracts changed; ${mv.filter((m) => m.r1 > m.r0).length} moved up a rating.`, table: { columns: ['Contract', 'Site', 'Signal', 'Reading', 'Signal score', 'Contract score', 'Rating'], rows }, data: { rows } }
}

function agreementTable(): Visual {
  const rows = [['Liability capped at the annual fee', '14.1', 'Present'], ['Waiver of consequential damages', '14.2 reserved', 'Missing: Non-negotiable terms rating 3, for Legal to confirm'], ['Indemnity limited to negligence', '15.1', 'Present'], ['Capital for odor control', '9.4', 'The City\'s to fund; biofilter unfunded since FY2024'], ['Joint defense', '16.3', 'Available: the letter names the City'], ['Termination for convenience', '21.1', 'The City may end on 180 days\' notice']]
  return { kind: 'table', title: 'Harlow Creek agreement: the terms that matter here', note: 'Read from the signed agreement and its three amendments.', table: { columns: ['Term', 'Section', 'Reading'], rows }, data: { rows } }
}

function watchTable(): Visual {
  const rows = movers().filter((m) => m.r1 === m.r0).map((m) => [m.c.id, m.c.site, String(m.r1), m.sigs.map((x) => `${x.s.name}: ${x.raw}`).join('; ') || m.unscored.map((x) => x.label).join('; '), m.sigs.length ? `Score ${f1(m.s0)} to ${f1(m.s1)}` : 'Not scored on your scorecard'])
  return { kind: 'table', title: 'Contracts that changed without moving a rating', note: 'Listed in the Monday digest.', table: { columns: ['Contract', 'Site', 'Rating', 'What changed', 'Effect'], rows }, data: { rows } }
}

function staffTable(): Visual {
  const rows = ['st1', 'st2', 'st3', 'st4', 'en2', 'en4'].map((id) => { const s = SIGNALS.find((x) => x.id === id)!; const b = REDMESA.v[id], a = REDMESA.night?.[id] ?? b; return [s.name, a.raw, a.r, REDMESA.night?.[id] ? `rated ${b.r} yesterday` : b.was ? `rated ${b.was} 90 days ago` : 'unchanged'] })
  return { kind: 'table', title: 'Red Mesa: the signals behind the pattern', note: 'Five of the seven sites with a notice of violation since 2024 showed open posts, overtime above 13% and repeated missed samples 8 to 12 weeks before.', table: { columns: ['Signal', 'Reading', 'Rating', 'Movement'], rows }, data: { rows } }
}

function seenTable(): Visual {
  const rows = ASHBY.seen.map((x) => [x.label, x.text, x.src.name, x.sig && DESIGN.on[x.sig] ? `Scored: ${SIGNALS.find((y) => y.id === x.sig)!.name}` : 'Not scored'])
  return { kind: 'table', title: 'Ashby Falls: what was read about the client', note: `${m0(ASHBY.revenue)} a year, ending 30 June 2027 with no option left.`, table: { columns: ['Sign', 'What was read', 'Source', 'On your scorecard'], rows }, data: { rows } }
}

/** The mitigation plan of each contract that rose: one action per signal, written for the site. */
function planByLens(): Visual {
  const ms = movers().filter((m) => m.s1 > m.s0 + 0.004)
  const rows = ms.flatMap((m) => planFor(m.c, 'after').filter((x) => !x.fixed && !x.later).map((x) => [shortSite(m.c), x.s.name, x.text, x.owner, x.due, `${Math.round(x.v)} → ${x.to}`]))
  return { kind: 'table', title: 'The plan, site by site', note: ms.map((m) => { const e = planEffect(m.c, 'after'); return `${shortSite(m.c)}: ${f1(e.from)} to ${f1(e.to)} if the plan lands` }).join(' · '), table: { columns: ['Site', 'Signal', 'Action', 'Owner', 'By', 'Signal score'], rows }, data: { rows } }
}

function regionTable(): Visual {
  const rule = SCORING.rule
  const rows = REGIONS.map((g) => { const xs = CONTRACTS.filter((c) => c.region === g.name); const hi = xs.filter((c) => rating(c, rule, 'now') >= 3); return [g.name, g.rvp, xs.length, hi.length, mM(hi.reduce((n, c) => n + c.revenue, 0))] })
  return { kind: 'table', title: 'Ratings by region', note: 'Contracts rated 3 or 4 and the revenue they carry, by Regional VP.', table: { columns: ['Region', 'Regional VP', 'Contracts', 'Rated 3 or 4', 'Revenue a year'], rows }, data: { rows } }
}

function actionsTable(): Visual {
  const rows = CONTRACTS.map((c) => ({ c, s: score(c, DESIGN.rule, 'now'), p: priorityOf(c, 'now') })).filter((x) => x.p === (impactOn() ? 'Act now' : 'Manage')).sort((a, b) => b.s - a.s).slice(0, 14).map((x) => [x.c.id, x.c.site, f1(x.s), impactOn() ? String(impactRating(x.c)) : '', m0(x.c.revenue), decidesText(x.c), driversOf(x.c, 'now', 2).map((d) => d.s.name).join('; ')])
  return { kind: 'table', title: 'The action list', note: 'High risk with a lot at stake, by score. The first fourteen are shown.', table: { columns: ['Contract', 'Site', 'Risk', 'At stake', 'A year', 'Decides', 'What drives it'], rows }, data: { rows } }
}

const nineOf = (goal: Goal) => !goal.findings.some((f) => /evergreen contracts left out/.test(f.headline))

function renewalKpis(nineIn: boolean): Visual {
  const x = renewals(SCORING.rule, nineIn)
  return kpis([{ label: 'Decide in 18 months', value: `${x.set.length} contracts` }, { label: 'Revenue at stake', value: `${mM(x.revenue)} a year` }, { label: 'Need a renewal plan', value: `${x.plan.length} contracts`, tone: 'warn' }, { label: 'Revenue on the plan list', value: `${mM(x.planRev)} a year`, tone: 'warn' }], 'The renewals that decide in the next 18 months', `${x.high.length} rate 3 or 4 on the scorecard; ${x.quiet.length} more rate 1 or 2 with a client-side sign.`)
}
function renewalRegion(nineIn: boolean): Visual {
  const x = renewals(SCORING.rule, nineIn)
  const rows = REGIONS.map((g) => { const xs = x.set.filter((c) => c.region === g.name), ps = x.plan.filter((c) => c.region === g.name); return [g.name, g.rvp, xs.length, mM(x.rev(xs)), ps.length, mM(x.rev(ps))] })
  return { kind: 'table', title: 'Revenue at stake, by region', note: 'The contracts that decide in 18 months and the ones that need a plan.', table: { columns: ['Region', 'Regional VP', 'In the set', 'Revenue', 'Need a plan', 'Revenue'], rows }, data: { rows } }
}
function planTable(nineIn: boolean): Visual {
  const x = renewals(SCORING.rule, nineIn)
  const rows = x.plan.slice(0, 12).map((c) => [c.id, c.site, c.state, c.rvp, mM(c.revenue), c.evergreen ? 'Evergreen' : `${c.monthsLeft} months`, rating(c, SCORING.rule, 'before'), c.seen.filter((z) => z.k !== 'end').map((z) => z.label).join('; ') || 'Rated 3 or 4'])
  return { kind: 'table', title: 'Contracts on the renewal plan list, largest first', note: `${x.plan.length} contracts, ${mM(x.planRev)} a year; the first twelve are shown.`, table: { columns: ['Contract', 'Site', 'State', 'Regional VP', 'Revenue', 'Left', 'Rating', 'Why it is on the list'], rows }, data: { rows } }
}
function lostTable(): Visual {
  const rows = LOST.map((l) => [`${l.site}, ${l.state}`, l.lost, l.how, mM(l.revenue), l.rated, l.moved.join('; ')])
  return { kind: 'table', title: 'The renewals lost since 2024, rated a year before', note: 'Two of the three rated 2 on the scorecard twelve months before the loss.', table: { columns: ['Lost renewal', 'Lost', 'How', 'Revenue', 'Rated a year before', 'What moved in that year'], rows }, data: { rows } }
}

/* ------------------------------------------------------------------ which visual for which section */

const has = (s: string, re: RegExp) => re.test(s)

/** The visual a section earns, from the goal it draws on, its role and its heading. Null means text only. */
export function visualFor(goal: Goal, role: SectionRole, heading: string, hint?: string): Visual | null {
  const h = `${heading} ${hint ?? ''}`.toLowerCase()
  const pref = goal.recommendations.find((r) => r.preferred) ?? goal.recommendations[0]
  /* A goal started from one of the two examples carries that example's analysis, so it draws the same pictures. */
  const key = goal.exampleOf ?? goal.id
  if (key === ONCE_ID) {
    const nineIn = nineOf(goal)
    if (role === 'summary') return renewalKpis(nineIn)
    if (role === 'findings' && has(h, /lost|lesson|back-test|year before|moved before/)) return lostTable()
    if (role === 'findings' && has(h, /region|revenue|stake|decides in your/)) return renewalRegion(nineIn)
    if (role === 'findings' && has(h, /plan|who decides|changed|client/)) return planTable(nineIn)
    if (role === 'findings') return renewalRegion(nineIn)
  }
  if (key === WATCH_ID) {
    if (role === 'summary') return ratingBars()
    if (role === 'findings' && has(h, /agreement|contract says/)) return agreementTable()
    if (role === 'findings' && has(h, /red mesa/)) return staffTable()
    if (role === 'findings' && has(h, /ashby/)) return seenTable()
    if (role === 'options' && has(h, /plan for each site|site by site/)) return planByLens()
    if (role === 'findings' && has(h, /watch|discuss/)) return watchTable()
    if (role === 'findings' && has(h, /region/)) return regionTable()
    if (role === 'findings' && has(h, /action list|overdue|tracker/)) return actionsTable()
    if (role === 'findings') return changedTable()
  }
  if (role === 'options' && goal.recommendations.length) {
    const cols = ['Option', ...pref.figures.map((f) => f.label)]
    const rows = goal.recommendations.map((r) => [`${r.title}${r.preferred ? ' (preferred)' : ''}`, ...pref.figures.map((_, i) => r.figures[i]?.value ?? 'n/a')])
    return { kind: 'table', title: 'The options side by side', note: `${goal.recommendations.length} options from ${goal.agent.name}; the preferred one first.`, table: { columns: cols, rows }, data: { rows } }
  }
  if (role === 'summary' && pref) return kpis(pref.figures, 'Headline figures', pref.title)
  return null
}

/* ------------------------------------------------------------------ diagrams for slides and dashboards */

const wrap = (s: string, n: number): string[] => {
  const out: string[] = []
  let line = ''
  for (const w of s.split(/\s+/)) { if ((line + ' ' + w).trim().length > n) { if (line) out.push(line); line = w } else line = `${line} ${w}`.trim() }
  if (line) out.push(line)
  return out
}
const BEAT_FILL: Record<string, string> = { asked: '#eef2f8', read: '#eef2f8', found: '#fff4e5', compared: '#fff4e5', therefore: '#e7f5ee' }
const BEAT_INK: Record<string, string> = { asked: PLAN, read: PLAN, found: ACTUAL, compared: ACTUAL, therefore: '#0f7b4f' }

/** The story behind the preferred recommendation as five linked boxes: asked, read, found, compared, therefore. */
function storyFlow(goal: Goal): Visual | null {
  const pref = goal.recommendations.find((r) => r.preferred) ?? goal.recommendations[0]
  if (!pref?.story.length) return null
  const beats = (['asked', 'read', 'found', 'compared', 'therefore'] as const).map((k) => pref.story.find((b) => b.kind === k)).filter(Boolean) as typeof pref.story
  const W = 620, H = 200, n = beats.length, gap = 14, bw = (W - 16 - gap * (n - 1)) / n
  const svg = `${svgOpen(W, H)}
${beats.map((b, i) => { const x = 8 + i * (bw + gap); const lines = wrap(b.text, Math.floor(bw / 6.3)).slice(0, 6); return `
<rect x="${x}" y="22" width="${bw}" height="150" rx="10" fill="${BEAT_FILL[b.kind]}"/>
${txt(x + 10, 42, b.kind.toUpperCase(), { size: 10, fill: BEAT_INK[b.kind], weight: 700 })}
${lines.map((l, j) => txt(x + 10, 62 + j * 15, l, { size: 10.5, fill: INK })).join('')}
${b.figure ? txt(x + 10, 162, b.figure.length > 22 ? `${b.figure.slice(0, 21)}…` : b.figure, { size: 10.5, fill: BEAT_INK[b.kind], weight: 700 }) : ''}
${i < n - 1 ? `<path d="M${x + bw + 2},97 l${gap - 4},0" stroke="${MUTED}" stroke-width="1.5" marker-end="url(#ar)"/>` : ''}` }).join('')}
<defs><marker id="ar" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 z" fill="${MUTED}"/></marker></defs>
${txt(8, 192, `Recommendation: ${pref.title.length > 90 ? `${pref.title.slice(0, 89)}…` : pref.title}`, { size: 10.5, fill: INK, weight: 600 })}
</svg>`
  return { kind: 'diagram', title: 'How the agent got to the recommendation', note: `${beats.length} steps, each traceable to its source; the full story plays under "Why this" on the goal.`, svg, data: { recommendation: pref.title, beats: beats.map((b) => ({ kind: b.kind, text: b.text, figure: b.figure })) } }
}

/** What the findings rest on: evidence lines by kind of source, counted from the findings themselves. */
function evidenceBySource(goal: Goal): Visual | null {
  const ev = goal.findings.flatMap((f) => f.evidence)
  if (!ev.length) return null
  const kinds = [{ k: 'table', label: 'Tables in the graph', fill: PLAN }, { k: 'document', label: 'Documents', fill: '#5b7fbf' }, { k: 'mail', label: 'Mailbox', fill: ACTUAL }, { k: 'assumption', label: 'Stated assumptions', fill: '#98a2b3' }]
  const rows = kinds.map((x) => ({ ...x, n: ev.filter((e) => e.kind === x.k).length })).filter((x) => x.n)
  const W = 620, rowH = 30, top = 18, H = top + rows.length * rowH + 30, x0 = 160, x1 = W - 60
  const max = Math.max(...rows.map((r) => r.n))
  const svg = `${svgOpen(W, H)}
${rows.map((r, i) => { const y = top + i * rowH; const w = ((x1 - x0) * r.n) / max; return `${txt(x0 - 10, y + 15, r.label, { size: 11, anchor: 'end', fill: INK })}<rect x="${x0}" y="${y + 4}" width="${w}" height="16" rx="5" fill="${r.fill}"><title>${r.label}: ${r.n}</title></rect>${txt(x0 + w + 8, y + 16, String(r.n), { size: 11.5, fill: INK, weight: 700 })}` }).join('')}
${txt(x0, H - 8, `${ev.length} evidence lines behind ${goal.findings.length} findings`, { size: 10.5 })}
</svg>`
  return { kind: 'diagram', title: 'What the findings rest on', note: `Every finding cites its rows, messages or documents; ${rows.find((r) => r.k === 'assumption')?.n ?? 0} lines are stated assumptions, not facts.`, svg, data: { rows: rows.map((r) => ({ source: r.label, lines: r.n })) } }
}

/** What is not established yet, as a checklist graphic. */
function gapsPanel(goal: Goal): Visual | null {
  const gaps = goal.gaps.slice(0, 5)
  if (!gaps.length) return null
  const lines = gaps.map((g) => wrap(g, 82).slice(0, 2))
  let y = 14
  const svg = `${svgOpen(620, 14 + lines.reduce((a, l) => a + l.length * 16 + 14, 0))}
${lines.map((l) => { const y0 = y; y += l.length * 16 + 14; return `<circle cx="18" cy="${y0 + 8}" r="9" fill="#fff4e5" stroke="${ACTUAL}" stroke-width="1.5"/>${txt(18, y0 + 12, '!', { size: 11, fill: ACTUAL, anchor: 'middle', weight: 700 })}${l.map((t, j) => txt(36, y0 + 12 + j * 16, t, { size: 11, fill: INK })).join('')}` }).join('')}
</svg>`
  return { kind: 'diagram', title: 'Not established yet', note: `${goal.gaps.length} open item${goal.gaps.length > 1 ? 's' : ''}; figures that depend on them are marked provisional.`, svg, data: { gaps: goal.gaps } }
}

/** From today to the decision: as of the data, the decision asked, the deadline. */
function nextTimeline(goal: Goal): Visual {
  const stops = [{ t: 'Data as of', d: DRILL.as_of }, { t: 'Decision asked', d: goal.target.decision }, { t: 'Deadline', d: goal.target.deadline }]
  const W = 620, H = 150, step = (W - 40) / (stops.length - 1)
  const svg = `${svgOpen(W, H)}
<line x1="20" y1="40" x2="${W - 20}" y2="40" stroke="${GRID}" stroke-width="3"/>
${stops.map((s0, i) => { const x = 20 + i * step; const anchor = i === 0 ? 'start' : i === stops.length - 1 ? 'end' : 'middle'; return `<circle cx="${x}" cy="40" r="9" fill="${i === stops.length - 1 ? CRIT : i === 0 ? PLAN : ACTUAL}" stroke="${SURF}" stroke-width="3"/>${txt(x, 70, s0.t.toUpperCase(), { size: 10, anchor, weight: 700, fill: MUTED })}${wrap(s0.d, 30).slice(0, 4).map((l, j) => txt(x, 88 + j * 14, l, { size: 11, anchor, fill: INK })).join('')}` }).join('')}
</svg>`
  return { kind: 'diagram', title: 'What happens next', note: 'The decision and its date come from the goal; the data date from the graph.', svg, data: { stops } }
}

/** The goal itself in four tiles: target, where it stands, deadline, decision. */
function targetTiles(goal: Goal): Visual {
  const short = (s: string) => (s.length > 46 ? `${s.slice(0, 44)}…` : s)
  return kpis([{ label: 'Target', value: short(goal.target.target) }, { label: 'Where it stands', value: short(goal.target.current.split(';')[0]) }, { label: 'Deadline', value: short(goal.target.deadline) }], 'The question and its target', goal.goal.length > 140 ? `${goal.goal.slice(0, 138)}…` : goal.goal)
}

/**
 * A slide or a dashboard panel always carries a picture: the section's own chart when it has one, otherwise
 * the diagram that fits its role, drawn from the goal's findings, story, gaps and target. Documents stay text-first.
 */
export function visualForFormat(goal: Goal, role: SectionRole, heading: string, format: string, hint?: string): Visual | null {
  const h = `${heading} ${hint ?? ''}`.toLowerCase()
  const visualFirst = format === 'Slide pack' || format === 'Dashboard'
  /* A slide about how the agent reached its recommendation shows that path, whatever role the section has. */
  if (visualFirst && role !== 'options' && /\b(why|story|how .*(got|came|reached).*recommend|reasoning)\b/.test(h)) { const st = storyFlow(goal); if (st) return st }
  const own = visualFor(goal, role, heading, hint)
  if (own || !visualFirst) return own
  const key = goal.exampleOf ?? goal.id
  switch (role) {
    case 'purpose': return key === ONCE_ID || key === WATCH_ID ? visualFor(goal, 'summary', 'in short') ?? targetTiles(goal) : targetTiles(goal)
    case 'findings': return evidenceBySource(goal) ?? targetTiles(goal)
    case 'why': return storyFlow(goal) ?? evidenceBySource(goal) ?? targetTiles(goal)
    case 'evidence': return evidenceBySource(goal) ?? targetTiles(goal)
    case 'assumptions': return gapsPanel(goal) ?? evidenceBySource(goal) ?? targetTiles(goal)
    case 'next': return nextTimeline(goal)
    case 'summary': case 'options': case 'free': default: return storyFlow(goal) ?? targetTiles(goal)
  }
}

/** Where each kind of picture reads its rows: the tables of the published graph behind it. */
export const LINEAGE: Record<VisualKind, { tables: string[]; asOf: string }> = {
  bullet: { tables: ['Scorecard (ratings by contract)'], asOf: TODAY },
  hbar: { tables: ['Scorecard (ratings by contract)'], asOf: TODAY },
  'bars-by-month': { tables: ['Scorecard history (ratings by month)'], asOf: TODAY },
  'line-snapshots': { tables: ['Scorecard history (ratings by month)'], asOf: TODAY },
  'hbar-pairs': { tables: ['Scorecard (internal and external scores)'], asOf: TODAY },
  table: { tables: ['Scorecard, master.contract, fin.contract_pnl, the mitigation tracker or the signed agreement, depending on the table'], asOf: TODAY },
  kpis: { tables: ['the goal’s preferred recommendation (figures computed in the analysis)'], asOf: TODAY },
  waterfall: { tables: ['Scorecard (factor scores)'], asOf: TODAY },
  progress: { tables: ['Mitigation tracker (actions by state)'], asOf: TODAY },
  diagram: { tables: ['the goal’s findings, evidence lines, recommendation story and open items (each citing its rows)'], asOf: TODAY },
}

/** The table view of a visual, for readers who want the numbers. */
export const tableOf = (v: Visual): { columns: string[]; rows: (string | number)[][] } | null => {
  if (v.table) return v.table
  switch (v.kind) {
    case 'bullet': { const d = v.data as { approved: number; forecast: number; variancePct: number }; return { columns: ['Approved', 'Forecast', 'Variance'], rows: [[eurK(d.approved), eurK(d.forecast), `${d.variancePct >= 0 ? '+' : ''}${d.variancePct}%`]] } }
    case 'hbar': { const d = v.data as { rows: { code: string; name: string; budget: number; forecast: number; pct: number }[] }; return { columns: ['Project', 'Name', 'Approved', 'Forecast', 'Variance'], rows: d.rows.map((r) => [r.code, r.name, eurK(r.budget), eurK(r.forecast), `${r.pct >= 0 ? '+' : ''}${r.pct}%`]) } }
    case 'bars-by-month': { const d = v.data as { months: { month: string; plan?: number; actual?: number | null; forecast?: number | null; amount?: number }[] }; return d.months[0]?.plan !== undefined ? { columns: ['Month', 'Plan $M', 'Actual $M', 'Forecast $M'], rows: d.months.map((m) => [m.month, m.plan!.toFixed(1), m.actual === null || m.actual === undefined ? 'n/a' : m.actual.toFixed(1), m.forecast ? m.forecast.toFixed(1) : 'n/a']) } : { columns: ['Month', 'Posted'], rows: d.months.map((m) => [m.month, eurK(m.amount ?? 0)]) } }
    case 'line-snapshots': { const d = v.data as { points: { date: string; forecast: number }[] }; return { columns: ['Forecast of', 'Forecast'], rows: d.points.map((x) => [x.date, eurK(x.forecast)]) } }
    case 'waterfall': { const d = v.data as { steps: { step: string; amount: number }[] }; return { columns: ['Step', 'Amount'], rows: d.steps.map((x) => [x.step, eurK(x.amount)]) } }
    case 'progress': { const d = v.data as { target: number; secured: number; path: number; option1: number }; return { columns: ['Figure', 'Value'], rows: [['Target', eurK(d.target)], ['Secured', eurK(d.secured)], ['Path to date', eurK(d.path)], ['Re-placing the nine lines', eurK(d.option1)]] } }
    case 'hbar-pairs': { const dc = v.data as { classes?: { cls: string; gross: number; accum: number; net: number }[] }; if (dc.classes) return { columns: ['Class', 'Gross', 'Accumulated depreciation', 'Net'], rows: dc.classes.map((c) => [c.cls, eurK(c.gross), eurK(c.accum), eurK(c.net)]) }; const d = v.data as { lines: { id: string; sup: string; t: string; o: number; r: number }[] }; return { columns: ['Contract', 'Counterparty', 'Instrument', 'Committed', 'Invoiced'], rows: d.lines.map((l) => [l.id, l.sup, l.t, eurK(l.o), eurK(l.r)]) } }
    case 'kpis': { const d = v.data as { items: { label: string; value: string }[] }; return { columns: ['Figure', 'Value'], rows: d.items.map((i) => [i.label, i.value]) } }
    case 'diagram': { const d = v.data as { rows?: { source: string; lines: number }[]; beats?: { kind: string; text: string; figure?: string }[]; gaps?: string[]; stops?: { t: string; d: string }[] }; return d.rows ? { columns: ['Source', 'Evidence lines'], rows: d.rows.map((r) => [r.source, r.lines]) } : d.beats ? { columns: ['Step', 'What', 'Figure'], rows: d.beats.map((b) => [b.kind, b.text, b.figure ?? '']) } : d.gaps ? { columns: ['Not established'], rows: d.gaps.map((x) => [x]) } : d.stops ? { columns: ['Stop', 'When / what'], rows: d.stops.map((x) => [x.t, x.d]) } : null }
    default: return null
  }
}

/** HTML for a visual, for the downloaded draft. */
export const visualHtml = (v: Visual): string => {
  const table = v.table ?? (v.kind === 'kpis' ? null : null)
  const kp = v.kind === 'kpis' ? `<div class="tiles">${(v.data as { items: { label: string; value: string }[] }).items.slice(0, 4).map((i) => `<div class="tile"><b>${esc(i.value)}</b><span>${esc(i.label)}</span></div>`).join('')}</div>` : ''
  const tb = table ? `<table class="vt"><thead><tr>${table.columns.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${table.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(String(c))}</td>`).join('')}</tr>`).join('')}</tbody></table>` : ''
  return `<figure class="vis"><figcaption>${esc(v.title)}</figcaption>${v.svg ?? ''}${kp}${tb}<div class="note">${esc(v.note)}</div></figure>`
}

export const VISUAL_CSS = `.vis{margin:10px 0 6px;padding:10px 12px;border:1px solid #e3e6ec;border-radius:8px;background:#fff}.vis figcaption{font-size:12px;color:#4b5a75;text-transform:uppercase;letter-spacing:.3px;margin-bottom:6px}.vis .note{font-size:12px;color:#4b5a75;margin-top:6px}.vt{border-collapse:collapse;width:100%;font-size:12.5px}.vt th{text-align:left;background:#f6f7fa;color:#4b5a75;font-weight:600;padding:5px 8px;border-bottom:1px solid #e3e6ec}.vt td{padding:5px 8px;border-bottom:1px solid #eef0f4}.tiles{display:flex;gap:10px;flex-wrap:wrap}.tile{flex:1 1 140px;background:#f6f7fa;border-radius:8px;padding:10px 12px}.tile b{display:block;font-size:19px;color:#0f1729}.tile span{font-size:12px;color:#4b5a75}`

/** Everything the two goals draw, for the data package. */
export const visualCatalogue = (goals: Goal[]) => {
  const out: { goalId: string; role: SectionRole; headingExample: string; visual: Omit<Visual, 'svg'> & { hasSvg: boolean } }[] = []
  const probes: Record<string, { role: SectionRole; heading: string }[]> = {
    [ONCE_ID]: [
      { role: 'summary', heading: 'The rate base at a glance' }, { role: 'findings', heading: 'Plant in service by class' }, { role: 'findings', heading: 'How the rate base moved since the 2025 order' },
      { role: 'findings', heading: 'Used and useful at 31 December' }, { role: 'findings', heading: 'Prudence of the major additions' }, { role: 'options', heading: 'Three options and the one we recommend' },
    ],
    [WATCH_ID]: [
      { role: 'summary', heading: 'Savings against the target' }, { role: 'findings', heading: 'The lines and their premium' }, { role: 'findings', heading: 'Why it happened' },
      { role: 'options', heading: 'Three options with the saving each keeps' },
    ],
  }
  for (const g of goals) for (const pr of probes[g.id] ?? []) {
    const v = visualFor(g, pr.role, pr.heading)
    if (v) { const { svg, ...rest } = v; out.push({ goalId: g.id, role: pr.role, headingExample: pr.heading, visual: { ...rest, hasSvg: !!svg } }) }
  }
  return out
}

/* For the data package export: the pictures a section earns, reachable from a script driving the prototype. */
if (typeof window !== 'undefined') (window as unknown as { __cwVisuals: unknown }).__cwVisuals = { visualForFormat, tableOf }
