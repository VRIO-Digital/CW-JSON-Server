/*
 * The Contract Risk Analyst world: Northline Contract Operations, the part of Northline Water Group that
 * runs water and wastewater plants for municipalities under operations and maintenance contracts.
 *
 * 300 contracts in five regions. Every contract is rated on the company's own risk scorecard, exactly as
 * its Phase 2 Data Driven Risk workbook writes it: seven internal factors and five external factors, each
 * with a weight; 42 signals, each ranked inside its factor and rated 1 (lowest) to 4 (highest) on fixed
 * bands. Nothing in the bands or the weights is the analyst's: where the workbook leaves something open,
 * the reading is stated (READINGS) and one point is asked (how the two halves combine).
 *
 * The portfolio is generated from a fixed seed, so every figure the journeys state is one this file
 * computes. Three contracts are written by hand because the overnight run of 20 November turns on them:
 * Harlow Creek (a demand letter and a sixth odor complaint), Red Mesa (the staffing pattern that comes
 * before a notice of violation) and Ashby Falls (a council agenda item the scorecard has no signal for).
 * Northline, its clients, people and figures are invented. The state liability ranking is the real 2026
 * edition of Rich States, Poor States.
 */

export type Group = 'internal' | 'external' | 'impact'
export type Rule = 'avg' | 'max' | 'sep'
export type SrcKind = 'table' | 'document' | 'mail' | 'web'

export interface FactorDef { id: string; group: Group; name: string; weight: number; blurb: string; added?: boolean }
export interface SignalDef {
  id: string
  f: string
  name: string
  rank: number
  /** The four bands as the workbook writes them (lightly tidied), rating 1 to 4. */
  bands: [string, string, string, string]
  /** Where the analyst reads it. */
  src: { kind: SrcKind; name: string; how: string }
  /** What the workbook's data sheet says about it: data available today, manual input, how often. */
  spec: { avail: boolean; manual: boolean; freq: string; steward: string }
  /** Fixed trait of the contract (set once), or something that moves. */
  moves: boolean
  /** Only for drinking water (dw) or wastewater (ww) contracts. */
  only?: 'dw' | 'ww'
  /** Base odds of rating 1..4 across the portfolio. */
  p: [number, number, number, number]
  /** Proposed by the analyst; not in the first framework the company drafted. */
  added?: boolean
  /** Why it is proposed, in one line. */
  why?: string
  /** Read as a number: the three thresholds between the four bands, and which way is worse. */
  num?: { cuts: number[]; dir: 'up' | 'down'; unit: string }
}

export const FACTORS: FactorDef[] = [
  { id: 'gr', group: 'internal', name: 'Non-negotiable Contract Terms', weight: 10, blurb: 'Contract terms the company should never accept, such as uncapped liability.' },
  { id: 'cr', group: 'internal', name: 'Commercial Terms', weight: 20, blurb: 'Terms and conditions that make the contract harder or costlier to run.' },
  { id: 'os', group: 'internal', name: 'Workplace Safety', weight: 15, blurb: 'How safely the site operates.' },
  { id: 'en', group: 'internal', name: 'Permit Compliance', weight: 20, blurb: 'Whether the plant meets its permits. Three-year average.' },
  { id: 'st', group: 'internal', name: 'Workforce', weight: 10, blurb: 'Whether the site has enough qualified people.' },
  { id: 'cu', group: 'internal', name: 'Client Satisfaction', weight: 10, blurb: 'How the client feels about us.' },
  { id: 'co', group: 'internal', name: 'Community Standing', weight: 15, blurb: 'How residents and local media see the operation.' },
  { id: 'sl', group: 'external', name: 'State Legal Climate', weight: 10, blurb: 'How costly the state is for lawsuits.' },
  { id: 'li', group: 'external', name: 'Legal Action', weight: 35, blurb: 'Legal action against the operation.' },
  { id: 'in', group: 'external', name: 'Asset Condition and Complexity', weight: 25, blurb: 'The condition and complexity of the assets we run.' },
  { id: 'sp', group: 'external', name: 'Neighbors', weight: 20, blurb: 'How many homes sit near the plant.' },
  { id: 'iq', group: 'external', name: 'Water Quality and Contaminants', weight: 10, blurb: 'The water coming in, and the contaminants new rules target.' },
  { id: 'fp', group: 'internal', name: 'Financial Performance', weight: 15, blurb: 'How the contract is doing commercially. Money problems tend to show before the others.', added: true },
  { id: 'cp', group: 'external', name: 'Client and Political Environment', weight: 20, blurb: 'The people and the politics on the client side, where most renewals are decided.', added: true },
  { id: 'cl', group: 'external', name: 'Competitive Landscape', weight: 10, blurb: 'Who else wants this contract.', added: true },
  { id: 'rs', group: 'external', name: 'Climate and Operational Resilience', weight: 10, blurb: 'Sudden events that no monthly figure predicts.', added: true },
  { id: 'im', group: 'impact', name: 'What is at stake', weight: 100, blurb: 'How much a loss would matter and how soon. Kept beside the risk score, not inside it.', added: true },
]

const T = (name: string, how: string) => ({ kind: 'table' as const, name, how })
const D = (name: string, how: string) => ({ kind: 'document' as const, name, how })
const M = (name: string, how: string) => ({ kind: 'mail' as const, name, how })
const W = (name: string, how: string) => ({ kind: 'web' as const, name, how })
const S = (avail: boolean, manual: boolean, freq: string, steward: string) => ({ avail, manual, freq, steward })

export const SIGNALS: SignalDef[] = [
  { id: 'gr1', f: 'gr', name: 'Legal review of the non-negotiable terms', rank: 1, bands: ['Meets every non-negotiable term', 'Meets the three core terms, misses other important ones', 'Misses one of the three core terms (liability cap, consequential damages waiver, indemnity limited to negligence)', 'Misses the core terms and other important ones'], src: D('The signed contract and its amendments', 'Read clause by clause; a draft for Legal to confirm'), spec: S(true, true, 'Once', 'Legal'), moves: false, p: [46, 34, 16, 4] },

  { id: 'cr1', f: 'cr', name: 'Prevailing wage state', rank: 1, bands: ['Not in a state with strict prevailing wage rules', '', '', 'In CA, MA, NY, IL, WA, NJ, CT or OR'], src: T('master.contract', 'State of the plant against the eight listed states'), spec: S(true, true, 'Once', 'Legal'), moves: false, p: [1, 0, 0, 0] },
  { id: 'cr2', num: { cuts: [45, 60, 90], dir: 'up', unit: 'days' }, f: 'cr', name: 'Days sales outstanding', rank: 2, bands: ['Under 45 days', '45 to 60 days', '60 to 90 days', '90 days or more'], src: T('fin.ar_aging', 'Average receivables over revenue, times the days in the period'), spec: S(true, false, 'Ongoing', 'Operations data hub'), moves: true, p: [58, 24, 13, 5] },
  { id: 'cr3', f: 'cr', name: 'Biosolids handling in scope', rank: 3, bands: ['No', '', '', 'Yes'], src: D('The signed contract, scope of services', 'Scope read from the contract and checked against the master list'), spec: S(true, false, 'Once', 'Contract master list'), moves: false, p: [1, 0, 0, 0] },
  { id: 'cr4', f: 'cr', name: 'Unionized workforce', rank: 4, bands: ['No', '', '', 'Yes'], src: T('hr.roster', 'Bargaining unit on the site roster'), spec: S(true, true, 'Once', 'Regional VP'), moves: false, p: [1, 0, 0, 0] },
  { id: 'cr5', f: 'cr', name: 'Water distribution network in scope', rank: 5, bands: ['No', 'Yes', '', ''], src: D('The signed contract, scope of services', 'Scope read from the contract and checked against the master list'), spec: S(true, false, 'Once', 'Contract master list'), moves: false, p: [1, 0, 0, 0] },
  { id: 'cr6', f: 'cr', name: 'Sewer collection network in scope', rank: 6, bands: ['No', 'Yes', '', ''], src: D('The signed contract, scope of services', 'Scope read from the contract and checked against the master list'), spec: S(true, false, 'Once', 'Contract master list'), moves: false, p: [1, 0, 0, 0] },

  { id: 'os1', num: { cuts: [0.1, 1, 2], dir: 'up', unit: 'per 200,000 hours' }, f: 'os', name: 'Lost-time injuries', rank: 1, bands: ['Zero', '0.1 to 0.99', '1 to 1.99', '2 or more'], src: T('ehs.incident · ops.hours', 'Lost time injuries per 200,000 hours, rolling twelve months'), spec: S(true, false, 'Ongoing', 'Operations data hub'), moves: true, p: [74, 14, 8, 4] },
  { id: 'os2', num: { cuts: [0.1, 1, 2], dir: 'up', unit: 'per 200,000 hours' }, f: 'os', name: 'Recordable injuries', rank: 2, bands: ['Zero', '0.1 to 0.99', '1 to 1.99', '2 or more'], src: T('ehs.incident · ops.hours', 'Recordable injuries per 200,000 hours, rolling twelve months'), spec: S(true, false, 'Ongoing', 'Operations data hub'), moves: true, p: [58, 20, 14, 8] },
  { id: 'os3', num: { cuts: [2, 1.5, 1], dir: 'down', unit: 'a year' }, f: 'os', name: 'Safety observations per employee', rank: 3, bands: ['2 or more a year', '1.5 to 2 a year', '1 to 1.5 a year', 'Under 1 a year'], src: T('ehs.observation · hr.roster', 'Near misses and safety observations submitted this year, per employee'), spec: S(true, false, 'Ongoing', 'Operations data hub'), moves: true, p: [74, 14, 8, 4] },

  { id: 'en1', num: { cuts: [100, 98, 97], dir: 'down', unit: '%' }, f: 'en', name: 'Days within permit limits', rank: 1, bands: ['100%', '98% to under 100%', '97% to under 98%', 'Under 97%'], src: T('ops.compliance_daily', 'Share of permit days met, by site, three-year average'), spec: S(true, false, 'Ongoing', 'Monthly report, compiled by hand'), moves: true, p: [48, 36, 10, 6] },
  { id: 'en2', num: { cuts: [1, 2, 3], dir: 'up', unit: 'in three years' }, f: 'en', name: 'Required samples missed', rank: 2, bands: ['0', '1', '2', '3 or more'], src: T('plantdata.sample_schedule · plantdata.results', 'Required samples with no result by the due date, this year'), spec: S(true, false, 'Ongoing', 'Compliance'), moves: true, p: [62, 22, 10, 6] },
  { id: 'en3', num: { cuts: [1, 2, 3], dir: 'up', unit: 'in three years' }, f: 'en', name: 'Notices of violation', rank: 3, bands: ['0', '1 a year', '2 a year', '3 or more a year'], src: D('Notices of violation in the compliance folder, checked against the state enforcement page', 'Each notice read; the public record catches any not filed'), spec: S(true, false, 'Ongoing', 'Monthly report, compiled by hand'), moves: true, p: [78, 14, 5, 3] },
  { id: 'en4', f: 'en', name: 'Operators using the plant data system', rank: 4, bands: ['Every day', 'Every other day', 'Weekly', 'Every two weeks or less'], src: T('plantdata.login_audit', 'Operator logins per working day, last 90 days'), spec: S(false, false, 'Ongoing', 'Not assigned'), moves: true, p: [52, 28, 14, 6] },

  { id: 'st1', f: 'st', name: 'Positions open more than 60 days', rank: 1, bands: ['None open over 60 days', '', '', 'One or more open over 60 days'], src: T('hr.requisition', 'Requisitions open longer than 60 days, by site'), spec: S(true, false, 'Ongoing', 'HR'), moves: true, p: [78, 0, 0, 22] },
  { id: 'st2', f: 'st', name: 'Licensed operators against the contract', rank: 2, bands: ['No licensed operator required', 'Required: holder and backup on the roster', 'Required: holder on the roster, no backup', 'Required: no holder and no backup'], src: D('The signed contract, staffing clause · hr.license', 'The licence level the contract requires against the licences on the roster'), spec: S(false, false, 'Once', 'HR'), moves: true, p: [8, 66, 22, 4] },
  { id: 'st3', num: { cuts: [90, 80, 75], dir: 'down', unit: '%' }, f: 'st', name: 'Staff retention', rank: 3, bands: ['Over 90%', '80% to 90%', '75% to 80%', 'Under 75%'], src: T('hr.roster', 'Staff at the start of the year still on the roster'), spec: S(false, false, 'Ongoing', 'HR'), moves: true, p: [50, 32, 11, 7] },
  { id: 'st4', num: { cuts: [6, 10, 13], dir: 'up', unit: '% overtime' }, f: 'st', name: 'Overtime share of payroll', rank: 4, bands: ['5% or below', '6% to 9%', '10% to 13%', 'Above 13%'], src: T('ops.labor_weekly', 'Overtime dollars over payroll dollars, last 13 weeks'), spec: S(true, false, 'Ongoing', 'Operations data hub'), moves: true, p: [34, 40, 18, 8] },

  { id: 'cu1', num: { cuts: [9, 7, 5], dir: 'down', unit: 'of 10' }, f: 'cu', name: 'Client survey score for the site', rank: 1, bands: ['9 to 10, would recommend us', '7 to 8, neutral', '5 to 6, unhappy', '0 to 4, very unhappy'], src: T('crm.nps_response', 'The client\'s latest answer for the site'), spec: S(true, true, 'Annual', 'Client experience'), moves: true, p: [44, 38, 13, 5] },
  { id: 'cu2', f: 'cu', name: 'Client survey score for the region', rank: 2, bands: ['Above 70', '55 to 70', '40 to 55', 'Under 40'], src: T('crm.nps_response', 'Revenue-weighted score across the region'), spec: S(true, true, 'Annual', 'Client experience'), moves: true, p: [1, 0, 0, 0] },
  { id: 'cu3', f: 'cu', name: 'Client survey trend, five years', rank: 3, bands: ['Increasing', 'Stable (scores 2.5)', '', 'Declining by more than 10%'], src: T('crm.nps_response', 'Slope of the site score over five surveys'), spec: S(true, true, 'Annual', 'Client experience'), moves: true, p: [30, 52, 0, 18] },

  { id: 'co1', num: { cuts: [1, 4, 6], dir: 'up', unit: 'in twelve months' }, f: 'co', name: 'Odor complaints', rank: 1, bands: ['0', '1 to 3 a year', '4 to 5 a year', 'More than 5 a year'], src: T('ops.complaint_log', 'Odor complaints logged this year; mail to the site is read for ones not logged'), spec: S(false, true, 'Ongoing', 'Not assigned'), moves: true, p: [52, 30, 11, 7] },
  { id: 'co2', num: { cuts: [40, 60, 80], dir: 'up', unit: '% negative' }, f: 'co', name: 'Local media coverage: % negative', rank: 2, bands: ['Under 40% negative', '40% to 59%', '60% to 79%', '80% to 100%'], src: W('Local news about the plant and the client', 'Every local media report of the last twelve months that names the plant or the operator is read and marked negative, neutral or positive. The figure is the negative reports divided by the total number of reports'), spec: S(false, false, 'Ongoing', 'Communications'), moves: true, p: [70, 18, 8, 4] },
  { id: 'co3', num: { cuts: [80, 60, 40], dir: 'down', unit: '% positive' }, f: 'co', name: 'Local media coverage: % positive', rank: 3, bands: ['80% to 100% positive', '60% to 79%', '40% to 59%', 'Under 40%'], src: W('Local news about the plant and the client', 'The same media reports. The figure is the positive reports divided by the total number of reports'), spec: S(true, false, 'Ongoing', 'Communications'), moves: true, p: [22, 36, 28, 14] },
  { id: 'co4', f: 'co', name: 'Community investment per year', rank: 4, bands: ['More than $20,000', '$10,000 to $20,000', '$1 to $10,000', '$0'], src: T('fin.community_spend', 'Sponsorships, outings and scholarships by cost centre'), spec: S(false, false, 'Annual', 'Compliance'), moves: true, p: [18, 30, 38, 14] },
  { id: 'co5', f: 'co', name: 'Community investment trend, five years', rank: 5, bands: ['Increasing', 'Stable (scores 2.5)', '', 'Declining by more than 10%'], src: T('fin.community_spend', 'Slope of the annual spend over five years'), spec: S(false, false, 'Annual', 'Compliance'), moves: true, p: [26, 54, 0, 20] },

  { id: 'sl1', f: 'sl', name: 'Lawsuit cost ranking of the state', rank: 1, bands: ['The 12 lowest-cost states', 'The next 13', 'The next 13', 'The 12 highest-cost states'], src: W('richstatespoorstates.org · State Liability System Survey', 'The 2026 edition, read from the page; checked again when a new edition is posted'), spec: S(false, true, 'Annual', 'Not assigned'), moves: false, p: [1, 0, 0, 0] },

  { id: 'li1', f: 'li', name: 'Lawsuits filed', rank: 1, bands: ['No recent, past or ongoing lawsuits', 'None active; a history of low dollar claims', 'Low dollar enforcement or tort claims active now', 'High dollar enforcement or personal injury claims, active or in the last 3 years'], src: D('Legal matter files, checked against the county court docket', 'Open and closed matters by site; public dockets catch suits not yet on the list'), spec: S(true, true, 'Quarterly', 'Legal'), moves: true, p: [70, 20, 7, 3] },
  { id: 'li2', f: 'li', name: 'Consent orders', rank: 2, bands: ['No consent order', '', '', 'Consent order'], src: D('Consent orders in the compliance folder, checked against the regulator\'s enforcement page', 'Each order read for who it binds: the client, the operator or both'), spec: S(true, true, 'Ongoing', 'Compliance'), moves: true, p: [93, 0, 0, 7] },
  { id: 'li3', f: 'li', name: 'Lawsuits threatened', rank: 3, bands: ['No threatened lawsuits, no negative campaign', 'No active campaign; a history of complaints being addressed', 'An active negative campaign about legal action', 'Demand letters or pre-suit notices received'], src: M('The legal notices mailbox and the project leaders\' mail', 'Demand letters, pre-suit notices and claim correspondence, read as they arrive'), spec: S(false, true, 'Quarterly', 'Legal'), moves: true, p: [72, 20, 5, 3] },

  { id: 'in1', f: 'in', name: 'Services covered by the contract', rank: 1, bands: ['1 to 2', '3 to 4', '5', '6 to 7'], src: D('The signed contract, scope of services', 'Counted from the scope clause: treatment, distribution, collection, biosolids, stormwater, reuse'), spec: S(false, false, 'Once', 'Not assigned'), moves: false, p: [1, 0, 0, 0] },
  { id: 'in2', f: 'in', name: 'Year of the last major upgrade', rank: 2, bands: ['5 years ago or less', '6 to 10 years', '11 to 20 years', 'More than 20 years, or none'], src: D('Capital improvement plans and annual reports to the client', 'The last major process upgrade named in the reports'), spec: S(true, false, 'Once', 'Master project list'), moves: false, p: [22, 28, 32, 18] },
  { id: 'in3', num: { cuts: [95, 90, 71], dir: 'down', unit: '%' }, f: 'in', name: 'Maintenance hours logged to work orders', rank: 3, bands: ['95% or more', '90% to 95%', '70% to 90%', '70% or less'], src: T('cmms.work_order', 'Share of maintenance labour hours booked to a work order'), spec: S(false, false, 'Ongoing', 'Operations data hub'), moves: true, p: [30, 30, 30, 10] },
  { id: 'in4', num: { cuts: [95, 90, 71], dir: 'down', unit: '%' }, f: 'in', name: 'Planned maintenance done on time', rank: 4, bands: ['95% or more', '90% to 95%', '70% to 90%', '70% or less'], src: T('cmms.work_order', 'Planned maintenance work orders closed on time, last 90 days'), spec: S(true, false, 'Ongoing', 'CMMS, compiled by hand'), moves: true, p: [34, 32, 28, 6] },
  { id: 'in5', f: 'in', name: 'Client capital plan, next five years', rank: 5, bands: ['Funded and approved', 'Partially funded', 'Planned but unfunded', 'None proposed'], src: D('The client\'s capital improvement plan and budget', 'Read from the adopted plan and the council budget'), spec: S(false, false, 'Annual', 'Master project list'), moves: true, p: [30, 28, 26, 16] },

  { id: 'sp1', num: { cuts: [2000, 4000, 10000], dir: 'up', unit: 'homes' }, f: 'sp', name: 'Homes within two miles', rank: 1, bands: ['0 to 2,000', '2,001 to 4,000', '4,001 to 10,000', 'More than 10,000'], src: T('gis.parcels_2mi', 'Residential parcels within 2 miles of the plant fence line; recounted when the county parcel file changes'), spec: S(true, true, 'Once', 'GIS map'), moves: false, p: [30, 26, 30, 14] },

  { id: 'iq1', num: { cuts: [9, 12, 15], dir: 'up', unit: 'ppb' }, f: 'iq', name: 'Lead in drinking water', rank: 1, bands: ['Under 60% of the action level', '60% to 80% of the action level', '80% to under the action level', 'At or above 15 ppb'], src: T('plantdata.results', '90th percentile of the latest tap sampling round'), spec: S(false, false, 'Ongoing', 'Compliance'), moves: true, only: 'dw', p: [74, 16, 7, 3] },
  { id: 'iq2', f: 'iq', name: 'PFAS in drinking water', rank: 2, bands: ['Below the MCL', 'Exceeds the MCL; treatment in place or will be by 2029', 'Exceeds the MCL; treatment planned, may run past 2029', 'Exceeds the MCL; no planning under way'], src: T('plantdata.results · the client\'s capital plan', 'Latest results against the federal limits, and whether treatment is planned'), spec: S(false, false, 'Ongoing', 'Compliance'), moves: true, only: 'dw', p: [70, 16, 9, 5] },
  { id: 'iq3', num: { cuts: [50, 66, 80], dir: 'up', unit: '% of the limit' }, f: 'iq', name: 'Nitrogen in effluent', rank: 3, bands: ['Under 50% of the permit limit for 12 months', 'Around 60% of the limit for 9 months', 'Around 70% of the limit for 3 months or more', 'Over 80% of the limit for 3 months or more'], src: T('plantdata.results', 'Monthly average against the permit limit'), spec: S(false, false, 'Ongoing', 'Compliance'), moves: true, only: 'ww', p: [48, 28, 16, 8] },
  { id: 'iq4', num: { cuts: [0.8, 1.05, 1.3], dir: 'up', unit: 'ppm' }, f: 'iq', name: 'Copper in drinking water', rank: 4, bands: ['Under 60% of the action level', '60% to 80% of the action level', '80% to under the action level', 'At or above 1.3 ppm'], src: T('plantdata.results', '90th percentile of the latest tap sampling round'), spec: S(false, false, 'Ongoing', 'Compliance'), moves: true, only: 'dw', p: [80, 13, 5, 2] },
  { id: 'iq5', num: { cuts: [50, 66, 80], dir: 'up', unit: '% of the limit' }, f: 'iq', name: 'Suspended solids in effluent', rank: 5, bands: ['Under 50% of the permit limit for 12 months', 'Around 60% of the limit for 9 months', 'Around 70% of the limit for 3 months or more', 'Over 80% of the limit for 3 months or more'], src: T('plantdata.results', 'Monthly average against the permit limit'), spec: S(false, false, 'Ongoing', 'Compliance'), moves: true, only: 'ww', p: [52, 28, 14, 6] },
  { id: 'iq6', num: { cuts: [50, 66, 80], dir: 'up', unit: '% of the limit' }, f: 'iq', name: 'Phosphorus in effluent', rank: 6, bands: ['Under 50% of the permit limit for 12 months', 'Around 60% of the limit for 9 months', 'Around 70% of the limit for 3 months or more', 'Over 80% of the limit for 3 months or more'], src: T('plantdata.results', 'Monthly average against the permit limit'), spec: S(false, false, 'Ongoing', 'Compliance'), moves: true, only: 'ww', p: [50, 28, 15, 7] },
  /* ---- added by the analyst: not in the first framework the company drafted */
  { id: 'cr7', f: 'cr', name: 'Fixed-price exposure on energy, chemicals and biosolids', rank: 7, added: true, why: 'Chemical cost rose 31% in 2022 on your fixed-fee contracts; 4 of them went to dispute.', bands: ['Costs passed through', 'Passed through above a threshold', 'Fixed, with a re-opener', 'Fixed for the term'], src: D('The signed contract, compensation article', 'Which costs the fee fixes and which pass through'), spec: S(false, false, 'Once', 'Contract Risk Analyst'), moves: false, p: [38, 30, 20, 12] },
  { id: 'cr8', f: 'cr', name: 'Performance guarantees and penalty clauses', rank: 8, added: true, why: 'Sets what one bad month costs. Read from the contract, clause by clause.', bands: ['None', 'Capped at 5% of the annual fee', 'Capped above 5%', 'Uncapped or per-day damages'], src: D('The signed contract, performance article', 'Guarantees, liquidated damages and their cap'), spec: S(false, false, 'Once', 'Contract Risk Analyst'), moves: false, p: [34, 36, 20, 10] },
  { id: 'cr9', f: 'cr', name: 'Price escalation clause', rank: 9, added: true, why: 'A weak escalator is where margin went on 11 of your contracts since 2021.', bands: ['Indexed to cost, yearly', 'CPI, yearly', 'CPI with a cap under 3%', 'No escalator'], src: D('The signed contract, fee adjustment article', 'The index, the cap and how often it applies'), spec: S(false, false, 'Once', 'Contract Risk Analyst'), moves: false, p: [30, 42, 20, 8] },
  { id: 'en5', f: 'en', name: 'Sewer overflows (SSO and CSO)', rank: 5, added: true, only: 'ww', why: 'The most visible failure. Two of your three consent orders began with overflows.', num: { cuts: [1, 3, 6], dir: 'up', unit: 'in twelve months' }, bands: ['None', '1 to 2', '3 to 5', '6 or more'], src: T('ops.overflow_event', 'Reported overflows, rolling twelve months'), spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [62, 24, 10, 4] },
  { id: 'en6', f: 'en', name: 'Permit renewal status', rank: 6, added: true, why: 'A renewed permit usually brings tighter limits. The dates are public.', bands: ['Renewed in the last 2 years', 'Renews in 3 to 5 years', 'Renews within 2 years', 'Expired, running on extension'], src: W('EPA ECHO and the state permit register', 'Permit number matched to the site; expiry date and draft limits'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [34, 36, 20, 10] },
  { id: 'st5', f: 'st', name: 'Site manager tenure', rank: 5, added: true, why: 'On your lost renewals the site manager had changed in the two years before, in 5 of 7.', num: { cuts: [5, 2, 1], dir: 'down', unit: 'years' }, bands: ['5 years or more', '2 to 5 years', '1 to 2 years', 'Under 1 year'], src: T('hr.roster', 'Start date of the project leader in the role'), spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [34, 38, 18, 10] },
  { id: 'st6', f: 'st', name: 'Key-person dependence', rank: 6, added: true, why: 'One licence holder leaving can put a plant out of compliance in a week.', bands: ['Three or more holders of each required licence', 'Two holders', 'One holder, backup in training', 'One holder, no backup'], src: T('hr.license · ops.labor_weekly', 'Holders of each licence the contract requires, and their hours'), spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [30, 44, 16, 10] },
  { id: 'in6', f: 'in', name: 'Corrective against preventive maintenance', rank: 6, added: true, why: 'Shows whether assets are kept up or failing first.', num: { cuts: [20, 35, 50], dir: 'up', unit: '% corrective' }, bands: ['Under 20% corrective', '20% to 35%', '35% to 50%', '50% or more'], src: T('cmms.work_order', 'Corrective hours over all maintenance hours, twelve months'), spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [36, 38, 18, 8] },
  { id: 'in7', f: 'in', name: 'Asset age', rank: 7, added: true, why: 'Older plants break more and cost more to keep compliant.', num: { cuts: [20, 35, 50], dir: 'up', unit: 'years' }, bands: ['Under 20 years', '20 to 35 years', '35 to 50 years', '50 years or more'], src: T('asset.register', 'Weighted age of the critical assets'), spec: S(false, false, 'Yearly', 'Contract Risk Analyst'), moves: false, p: [18, 38, 30, 14] },
  { id: 'iq7', f: 'iq', name: 'PFAS in biosolids and effluent', rank: 7, added: true, only: 'ww', why: 'New state rules can close a biosolids outlet overnight.', bands: ['Not detected', 'Detected, no state rule', 'Detected, state rule proposed', 'Detected, state rule in force'], src: T('lab.result · state rule register (web)', 'Lab results against the rules proposed or in force in the state'), spec: S(false, false, 'Quarterly', 'Contract Risk Analyst'), moves: true, p: [48, 30, 16, 6] },
  { id: 'iq8', f: 'iq', name: 'Rules on the way (nutrients, lead)', rank: 8, added: true, why: 'Future limits need capital the client may not fund.', bands: ['None proposed', 'Proposed, more than 3 years out', 'Final, takes effect within 3 years', 'In effect, plant not yet upgraded'], src: W('Federal Register and the state rule dockets', 'Rules that apply to the permit, with their dates'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [40, 34, 20, 6] },

  { id: 'fp1', f: 'fp', name: 'Margin against budget', rank: 1, added: true, why: 'Margin fell under budget before every one of the 7 contracts you lost or left since 2021.', num: { cuts: [0, -2, -5], dir: 'down', unit: 'points' }, bands: ['At or above budget', 'Up to 2 points under', '2 to 5 points under', 'More than 5 points under'], src: T('fin.contract_pnl', 'Actual margin less budget margin, year to date'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [46, 30, 16, 8] },
  { id: 'fp2', f: 'fp', name: 'Margin trend, 24 months', rank: 2, added: true, why: 'A steady slide is an earlier warning than one bad year.', bands: ['Rising', 'Flat', 'Falling up to 3 points', 'Falling more than 3 points'], src: T('fin.contract_pnl', 'Slope of monthly margin over 24 months'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [28, 44, 20, 8] },
  { id: 'fp3', f: 'fp', name: 'Cost overruns', rank: 3, added: true, why: 'Points to a site under strain or a contract priced too tight.', num: { cuts: [2, 5, 10], dir: 'up', unit: '% over plan' }, bands: ['Under 2% over plan', '2% to 5%', '5% to 10%', '10% or more'], src: T('fin.contract_pnl', 'Labour, chemicals, energy and repairs against plan'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [44, 30, 18, 8] },
  { id: 'fp4', f: 'fp', name: 'Unbilled or disputed change orders', rank: 4, added: true, why: 'Work done and not agreed turns into a dispute with the client.', bands: ['None', 'Under 1% of the annual fee', '1% to 3%', 'More than 3%'], src: T('fin.change_order', 'Open change orders older than 60 days, over the annual fee'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [56, 26, 12, 6] },
  { id: 'fp5', f: 'fp', name: 'Penalties and liquidated damages paid', rank: 5, added: true, why: 'A direct sign of not delivering what was promised.', bands: ['None in 3 years', 'One, minor', 'More than one', 'Above 1% of the annual fee'], src: T('fin.gl_detail', 'Penalty accounts by contract, three years'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [70, 18, 8, 4] },

  { id: 'cp1', f: 'cp', name: 'Change in key client contacts', rank: 1, added: true, why: 'A new utilities director or city manager came before 5 of your 7 losses.', bands: ['Same contacts for 3 years or more', 'Changed more than 18 months ago', 'Changed in the last 18 months', 'Changed in the last 6 months'], src: M('Project leader and client mail', 'New names and titles on the client side; introductions and hand-overs'), spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [48, 28, 16, 8] },
  { id: 'cp2', f: 'cp', name: 'Election or council turnover', rank: 2, added: true, why: 'New officials review what their predecessors signed.', bands: ['No election within 24 months', 'Election in 12 to 24 months', 'Election within 12 months', 'Majority changed in the last 12 months'], src: W('State and county election calendars', 'Seats on the ballot for the body that owns the contract'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [40, 32, 20, 8] },
  { id: 'cp3', f: 'cp', name: 'Talk of in-house operation or a re-bid', rank: 3, added: true, why: 'It was on a public agenda before both contracts you lost to in-house operation.', bands: ['None found', 'Raised once, more than a year ago', 'Raised by staff or a member this year', 'On a public agenda, or an adviser hired'], src: W('Council and board agendas and minutes', 'Agendas and minutes searched for the contract, in-house operation and procurement'), spec: S(false, false, 'Weekly', 'Contract Risk Analyst'), moves: true, p: [78, 12, 6, 4] },
  { id: 'cp4', f: 'cp', name: 'Client financial health', rank: 4, added: true, why: 'A client under budget pressure cuts scope or pushes on price.', bands: ['Rated AA or better, rates approved', 'Rated A', 'Rate increase deferred or outlook negative', 'Downgraded, or budget in deficit'], src: W('Municipal bond ratings and adopted budgets', 'Rating, outlook and whether the rate increase passed'), spec: S(false, false, 'Quarterly', 'Contract Risk Analyst'), moves: true, p: [40, 36, 18, 6] },
  { id: 'cp5', f: 'cp', name: 'The contract in public meetings', rank: 5, added: true, why: 'Shows the contract is under political attention.', num: { cuts: [1, 3, 6], dir: 'up', unit: 'mentions in twelve months' }, bands: ['Not mentioned', '1 to 2 mentions', '3 to 5 mentions', '6 or more'], src: W('Council and board agendas and minutes', 'Mentions of the operator or the plant, twelve months'), spec: S(false, false, 'Weekly', 'Contract Risk Analyst'), moves: true, p: [56, 28, 12, 4] },
  { id: 'cp6', f: 'cp', name: 'Client escalations', rank: 6, added: true, why: 'The working relationship breaking down, often before the survey shows it.', bands: ['None in twelve months', 'One, closed', 'Two or more, closed', 'One open with the client\'s director or above'], src: M('Client mail to the Regional VP and above', 'Complaints from client staff that went above the project leader'), spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [64, 22, 10, 4] },

  { id: 'cl1', f: 'cl', name: 'Competitor nearby', rank: 1, added: true, why: 'A competitor next door can pitch your client any week.', bands: ['None within 50 miles', 'One within 50 miles', 'One in the same county', 'Two or more in the same county'], src: W('State operator registers and trade press', 'Who operates the neighbouring plants'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: true, p: [46, 34, 14, 6] },
  { id: 'cl2', f: 'cl', name: 'Recent competitor wins', rank: 2, added: true, why: 'Shows who has momentum in the region and how they are winning.', bands: ['None in the region in 2 years', 'One in the region', 'One taken from us in the region', 'A competitor has presented to this client'], src: W('Procurement notices and award minutes', 'Awards in the region, and who presented to which board'), spec: S(false, false, 'Weekly', 'Contract Risk Analyst'), moves: true, p: [58, 26, 12, 4] },
  { id: 'cl3', f: 'cl', name: 'Price pressure', rank: 3, added: true, why: 'A renewal decided on price favours the cheaper bid.', bands: ['None', 'Client asked for a benchmark', 'Client asked for a price review', 'Client said in writing that we cost too much'], src: M('Client mail and meeting notes', 'Requests for benchmarks, price reviews and budget cuts'), spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [62, 22, 12, 4] },

  { id: 'rs1', f: 'rs', name: 'Flood and extreme weather exposure', rank: 1, added: true, why: 'One storm can cause overflows and a year of violations.', bands: ['Outside the 500-year flood zone', 'In the 500-year zone', 'In the 100-year zone', 'In the 100-year zone, flooded in the last 10 years'], src: W('FEMA flood maps and NOAA storm events', 'The plant address against the flood zone and the storm record'), spec: S(false, false, 'Yearly', 'Contract Risk Analyst'), moves: false, p: [52, 24, 18, 6] },
  { id: 'rs2', f: 'rs', name: 'Drought and source water', rank: 2, added: true, only: 'dw', why: 'Shortages strain operations and the client relationship.', bands: ['No drought in 5 years', 'Moderate drought in 5 years', 'Severe drought in 2 years', 'Restrictions in force'], src: W('U.S. Drought Monitor', 'The county of the source, weekly'), spec: S(false, false, 'Weekly', 'Contract Risk Analyst'), moves: true, p: [50, 30, 14, 6] },
  { id: 'rs3', f: 'rs', name: 'Cybersecurity of plant controls', rank: 3, added: true, why: 'A cyber incident can stop a plant and become a public crisis.', bands: ['Assessed this year, no open findings', 'Assessed, findings closed on plan', 'Assessed, findings overdue', 'Not assessed in 3 years'], src: D('SCADA security assessments', 'The latest assessment and its open findings'), spec: S(false, false, 'Yearly', 'Contract Risk Analyst'), moves: true, p: [34, 36, 20, 10] },
  { id: 'rs4', f: 'rs', name: 'Emergency response readiness', rank: 4, added: true, why: 'A badly handled emergency is remembered at renewal.', bands: ['Plan current, drill this year', 'Plan current, no drill this year', 'Plan older than 3 years', 'No plan on file'], src: D('Emergency response plans and drill records', 'Date of the plan and of the last drill'), spec: S(false, false, 'Yearly', 'Contract Risk Analyst'), moves: true, p: [42, 34, 18, 6] },

  { id: 'im1', f: 'im', name: 'Annual contract revenue', rank: 1, added: true, why: 'Bigger contracts deserve attention first.', num: { cuts: [2, 4, 7], dir: 'up', unit: '$M a year' }, bands: ['Under $2M', '$2M to $4M', '$4M to $7M', '$7M or more'], src: T('master.contract · fin.contract_pnl', 'Fee billed, last twelve months'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: false, p: [1, 0, 0, 0] },
  { id: 'im2', f: 'im', name: 'Margin contribution', rank: 2, added: true, why: 'A high-margin loss hurts far more than a break-even one.', num: { cuts: [150, 400, 800], dir: 'up', unit: '$k a year' }, bands: ['Under $150k', '$150k to $400k', '$400k to $800k', '$800k or more'], src: T('fin.contract_pnl', 'Margin in dollars, last twelve months'), spec: S(false, false, 'Monthly', 'Contract Risk Analyst'), moves: false, p: [1, 0, 0, 0] },
  { id: 'im3', f: 'im', name: 'Months to renewal or end', rank: 3, added: true, why: 'Sets the urgency. Risk close to a decision must be acted on now.', num: { cuts: [36, 18, 12], dir: 'down', unit: 'months' }, bands: ['More than 36 months', '18 to 36 months', '12 to 18 months', 'Under 12 months'], src: T('master.contract', 'End date of the current term'), spec: S(false, false, 'Daily', 'Contract Risk Analyst'), moves: false, p: [1, 0, 0, 0] },
  { id: 'im4', f: 'im', name: 'Options left at the end of the term', rank: 4, added: true, why: 'A term that rolls on is safer than an open re-tender.', bands: ['Renewal options left, at our choice', 'One mutual option left', '', 'No option left: goes to bid'], src: D('The signed contract, term article', 'Renewal options used and left'), spec: S(false, false, 'Once', 'Contract Risk Analyst'), moves: false, p: [40, 30, 0, 30] },
  { id: 'im5', f: 'im', name: 'Termination for convenience', rank: 5, added: true, why: 'The contract can be lost at any time, not only at renewal.', bands: ['No', '', '', 'Yes'], src: D('The signed contract, termination article', 'Whether the client can end the agreement without cause, and the notice'), spec: S(false, false, 'Once', 'Contract Risk Analyst'), moves: false, p: [1, 0, 0, 0] },
  { id: 'im6', f: 'im', name: 'Strategic and reference value', rank: 6, added: true, why: 'Losing a flagship damages other bids.', bands: ['Standard', 'Used as a reference in bids', 'Regional anchor', 'Flagship'], src: D('Bid library and reference lists', 'How often the contract is named in our own proposals'), spec: S(false, false, 'Yearly', 'Contract Risk Analyst'), moves: false, p: [70, 18, 8, 4] },
]

/** Where the workbook leaves a band or a rule open, how it is read here. Each can be changed on the plan. */
export const READINGS: { k: string; what: string; read: string }[] = [
  { k: 'rank', what: 'How a signal\'s rank becomes its weight inside a factor', read: 'Rank 1 counts most: with three signals the weights are 3, 2 and 1 parts of 6.' },
  { k: 'na', what: 'A signal that does not apply to a contract', read: 'Left out, and the other signals of the factor share its weight (lead, copper and PFAS apply to drinking water only).' },
  { k: 'state', what: 'Which end of the state ranking is high risk', read: 'The website ranks 1 as the lowest liability cost, so the 12 highest-cost states (ranks 39 to 50) rate 4.' },
  { k: 'upg', what: 'Year of most recent upgrades, ratings 2 and 3', read: 'Read in rising order: 6 to 10 years rates 2, 11 to 20 years rates 3.' },
  { k: 'cip', what: 'Capital plan investment, ratings 2 and 3', read: 'Read in rising order: partially funded rates 2, planned but unfunded rates 3.' },
  { k: 'scopes', what: 'Number of scopes, the four bands', read: 'The cells hold dates; read as 1 to 2, 3 to 4, 5, and 6 to 7 scopes.' },
  { k: 'dso', what: 'DSO, rating 4', read: 'The band says 90 days or more and the note says 120; 90 is used.' },
  { k: 'ret', what: 'Employee retention between 85% and 90%', read: 'No band covers it; 80% to 90% rates 2.' },
]

/* ------------------------------------------------------------------ the state ranking (real, 2026 edition) */

/** Rich States, Poor States, 2026 edition, State Liability System Survey: rank 1 is the lowest tort cost as a share of state GDP. */
export const STATE_RANK: Record<string, number> = { ND: 1, AK: 2, SD: 3, WY: 4, WA: 5, NH: 6, VA: 7, NC: 8, OH: 8, IA: 10, NE: 11, WI: 12, WV: 13, ME: 14, MN: 15, KS: 16, HI: 17, IN: 18, TN: 19, VT: 19, MD: 21, UT: 22, MA: 23, OK: 24, OR: 25, ID: 26, CO: 27, KY: 27, MI: 29, AZ: 30, CA: 30, TX: 32, IL: 33, AR: 34, MO: 35, NM: 36, PA: 37, AL: 38, CT: 39, MS: 40, RI: 41, NV: 42, NJ: 43, SC: 44, MT: 45, GA: 46, NY: 47, LA: 48, FL: 49, DE: 50 }
export const STATE_NAME: Record<string, string> = { AL: 'Alabama', AK: 'Alaska', AZ: 'Arizona', AR: 'Arkansas', CA: 'California', CO: 'Colorado', CT: 'Connecticut', DE: 'Delaware', FL: 'Florida', GA: 'Georgia', HI: 'Hawaii', ID: 'Idaho', IL: 'Illinois', IN: 'Indiana', IA: 'Iowa', KS: 'Kansas', KY: 'Kentucky', LA: 'Louisiana', ME: 'Maine', MD: 'Maryland', MA: 'Massachusetts', MI: 'Michigan', MN: 'Minnesota', MS: 'Mississippi', MO: 'Missouri', MT: 'Montana', NE: 'Nebraska', NV: 'Nevada', NH: 'New Hampshire', NJ: 'New Jersey', NM: 'New Mexico', NY: 'New York', NC: 'North Carolina', ND: 'North Dakota', OH: 'Ohio', OK: 'Oklahoma', OR: 'Oregon', PA: 'Pennsylvania', RI: 'Rhode Island', SC: 'South Carolina', SD: 'South Dakota', TN: 'Tennessee', TX: 'Texas', UT: 'Utah', VT: 'Vermont', VA: 'Virginia', WA: 'Washington', WV: 'West Virginia', WI: 'Wisconsin', WY: 'Wyoming' }
export const STATE_SOURCE = { site: 'richstatespoorstates.org', page: 'State Liability System Survey', edition: 'Rich States, Poor States, 2026 edition', basis: 'Tort costs as a share of state GDP, 2022 (U.S. Chamber of Commerce Institute for Legal Reform, Tort Costs in America, Third Edition, November 2024)', url: 'https://www.richstatespoorstates.org/variables/state_liability_system_survey/' }
const stateRating = (st: string) => { const r = STATE_RANK[st] ?? 25; return r <= 12 ? 1 : r <= 25 ? 2 : r <= 38 ? 3 : 4 }
const PW_STATES = new Set(['CA', 'MA', 'NY', 'IL', 'WA', 'NJ', 'CT', 'OR'])

/* ------------------------------------------------------------------ the portfolio */

export interface Reading { raw: string; r: number; was?: number; wasRaw?: string }
export interface Action { id: string; lens: 'Internal' | 'At the plant' | 'In the community' | 'With the client'; text: string; owner: string; due: string; state: 'open' | 'done' | 'overdue' | 'proposed' | 'held'; sig?: string }
export interface Seen { sig?: string; k: string; label: string; text: string; tone: 'warn' | 'crit' | 'info'; src: { kind: SrcKind; name: string; ref?: string }; night?: boolean }
export interface Contract {
  id: string
  site: string
  client: string
  state: string
  region: string
  rvp: string
  leader: string
  kind: 'Wastewater' | 'Drinking water' | 'Water and wastewater'
  scopes: string[]
  union: boolean
  staff: number
  revenue: number
  margin: number
  start: string
  end: string
  monthsLeft: number
  evergreen: boolean
  tfc: boolean
  homes: number
  /** Signal readings before the overnight changes of 20 November. */
  v: Record<string, Reading>
  /** What changed overnight, by signal. */
  night?: Record<string, Reading>
  /** Outside the scorecard: what else the analyst sees about the contract. */
  seen: Seen[]
  actions: Action[]
  /** Latent trouble, used once to draw the readings. */
  h: number
  /** The profit center the project is booked under; some profit centers hold several projects. */
  pc?: string
  /** Plants and systems under the project. */
  facilities?: number
  /** Receivables are negative for the profit center this month (credits exceed what is owed). */
  negDso?: boolean
  hero?: 'harlow' | 'redmesa' | 'ashby'
}

export const REGIONS: { name: string; rvp: string; states: string[]; nps: number }[] = [
  { name: 'Northeast', rvp: 'Daniel Okoro', states: ['MA', 'CT', 'NJ', 'NY', 'PA', 'NH', 'ME', 'RI', 'MD'], nps: 61 },
  { name: 'Southeast', rvp: 'Marisol Vega', states: ['GA', 'FL', 'SC', 'NC', 'TN', 'AL', 'MS', 'VA', 'KY'], nps: 52 },
  { name: 'Midwest', rvp: 'Tom Brandvold', states: ['OH', 'IN', 'IL', 'MI', 'WI', 'MN', 'IA', 'MO', 'KS'], nps: 72 },
  { name: 'South Central', rvp: 'Priya Raman', states: ['TX', 'OK', 'LA', 'AR', 'NM'], nps: 58 },
  { name: 'West', rvp: 'Grant Leung', states: ['CA', 'AZ', 'WA', 'OR', 'ID', 'CO', 'NV', 'UT'], nps: 66 },
]
export const PEOPLE = {
  owner: 'Renee Halvorsen', ownerRole: 'SVP, Contract Operations',
  legal: 'Elliot Marsh', legalRole: 'Associate General Counsel',
  compliance: 'Jo Whitcombe', complianceRole: 'Director, Environmental Compliance',
  hr: 'Nadia Brooks', hrRole: 'HR Business Partner, Operations',
  cx: 'Camille Roy', cxRole: 'Client Experience Lead',
  comms: 'Adrian Lowe', commsRole: 'Communications Manager',
  tp: 'Technical and Performance group',
}

/* mulberry32: the same portfolio on every load */
const rng = (seed: number) => () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296 }
const R = rng(20261120)
const R0 = R
const pick = <X,>(xs: X[]) => xs[Math.floor(R() * xs.length)]
const between = (a: number, b: number) => a + R() * (b - a)
const int = (a: number, b: number) => Math.round(between(a, b))
const gauss = () => { let s = 0; for (let i = 0; i < 6; i += 1) s += R(); return (s - 3) / 0.7071 }

const A1 = ['Harlow', 'Ashby', 'Calder', 'Wren', 'Thorn', 'Marlow', 'Kestrel', 'Brindle', 'Corwin', 'Dunmere', 'Elsin', 'Farrow', 'Garnet', 'Hollis', 'Ingram', 'Jessup', 'Keswick', 'Larkin', 'Merrow', 'Norvale', 'Orrin', 'Pell', 'Quill', 'Selby', 'Tamsin', 'Vance', 'Wexley', 'Yarrow', 'Alder', 'Drummond', 'Ember', 'Fenwick', 'Gable', 'Hadley', 'Linden', 'Mossley', 'Osric', 'Rowan', 'Sable', 'Tollan']
const A2 = ['Creek', 'Falls', 'Ridge', 'Hollow', 'Landing', 'Springs', 'Crossing', 'Bend', 'Valley', 'Grove', 'Point', 'Flats']
const FIRST = ['Aaron', 'Bianca', 'Caleb', 'Dara', 'Emeka', 'Farah', 'Gus', 'Hana', 'Ivan', 'Joy', 'Kofi', 'Lena', 'Miles', 'Nora', 'Omar', 'Paige', 'Quinn', 'Rosa', 'Sam', 'Tess', 'Uma', 'Victor', 'Wade', 'Ximena', 'Yusuf', 'Zoe']
const LAST = ['Abbott', 'Brennan', 'Castillo', 'Delgado', 'Eriksen', 'Fontaine', 'Greer', 'Haddad', 'Iverson', 'Jarrett', 'Kowalski', 'Lindqvist', 'Mbeki', 'Novak', 'Osei', 'Pruitt', 'Quintero', 'Rahimi', 'Sorensen', 'Tanaka', 'Underhill', 'Vasquez', 'Whitlock', 'Yoon', 'Zamora']
const person = () => `${pick(FIRST)} ${pick(LAST)}`
export const TODAY = '2026-11-19'
const monthsBetween = (a: string, b: string) => { const x = new Date(a), y = new Date(b); return (y.getFullYear() - x.getFullYear()) * 12 + (y.getMonth() - x.getMonth()) + (y.getDate() >= x.getDate() ? 0 : -1) }
const iso = (y: number, m: number, d: number) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`

/** A rating drawn from the base odds, pushed up by the contract's latent trouble (h). */
const draw = (p: number[], h: number, R: () => number = R0) => {
  const w = p.map((x, i) => x * Math.exp(h * (i - 1) * 0.8))
  const tot = w.reduce((a, b) => a + b, 0)
  let u = R() * tot
  for (let i = 0; i < 4; i += 1) { u -= w[i]; if (u <= 0) return i + 1 }
  return 4
}
const fmtInt = (n: number) => n.toLocaleString('en-US')

/** A raw value that sits inside the band of the rating drawn. */
const rawFor = (id: string, r: number, c: { homes: number; nps: number }): string => {
  switch (id) {
    case 'gr1': return ['Compliant', 'three core terms present; two other terms missing', 'No waiver of consequential damages', 'No liability cap, no waiver, broad indemnity'][r - 1]
    case 'cr2': return `${[int(24, 44), int(45, 59), int(61, 88), int(92, 131)][r - 1]} days`
    case 'os1': return [0, between(0.2, 0.9), between(1.05, 1.9), between(2.1, 3.4)][r - 1].toFixed(r === 1 ? 0 : 2)
    case 'os2': return [0, between(0.3, 0.95), between(1.1, 1.95), between(2.1, 4.2)][r - 1].toFixed(r === 1 ? 0 : 2)
    case 'os3': return [`${(2.1 + 4.3 * Math.pow(between(0, 1), 0.75)).toFixed(1)} per employee`, `${between(1.55, 1.95).toFixed(1)} per employee`, `${between(1.05, 1.45).toFixed(1)} per employee`, `${between(0.2, 0.9).toFixed(1)} per employee`][r - 1]
    case 'en1': return ['100%', `${between(98.2, 99.8).toFixed(1)}%`, `${between(97.1, 97.9).toFixed(1)}%`, `${between(93.5, 96.8).toFixed(1)}%`][r - 1]
    case 'en2': return String([0, 1, 2, int(3, 5)][r - 1])
    case 'en3': return String([0, 1, 2, int(3, 4)][r - 1])
    case 'en4': return [`${between(0.92, 1).toFixed(2)} logins a day`, `${between(0.45, 0.6).toFixed(2)} logins a day`, `${between(0.18, 0.28).toFixed(2)} logins a day`, `${between(0.04, 0.1).toFixed(2)} logins a day`][r - 1]
    case 'st1': return r === 1 ? 'None' : `${int(1, 3)} open over 60 days`
    case 'st2': return ['Not required', 'Holder and backup', 'Holder, no backup', 'No holder listed'][r - 1]
    case 'st3': return `${[int(91, 98), int(81, 89), int(76, 79), int(62, 74)][r - 1]}%`
    case 'st4': return `${[between(2, 5), between(6, 9), between(10, 13), between(13.4, 19)][r - 1].toFixed(1)}%`
    case 'cu1': return String([int(9, 10), int(7, 8), int(5, 6), int(2, 4)][r - 1])
    case 'cu2': return String(c.nps)
    case 'cu3': return ['Increasing', 'Stable', '', `Down ${int(11, 28)}%`][r - 1]
    case 'co1': return String([0, int(1, 3), int(4, 5), int(6, 14)][r - 1])
    case 'co2': return `${[int(0, 35), int(40, 58), int(60, 78), int(80, 100)][r - 1]}% negative`
    case 'co3': return `${[int(80, 100), int(60, 79), int(40, 59), int(10, 39)][r - 1]}% positive`
    case 'co4': return ['$' + fmtInt(int(21, 60) * 1000), '$' + fmtInt(int(10, 20) * 1000), '$' + fmtInt(int(1, 9) * 1000), '$0'][r - 1]
    case 'co5': return ['Increasing', 'Stable', '', `Down ${int(12, 40)}%`][r - 1]
    case 'li1': return ['None', 'None active; 1 small claim closed', '1 low dollar claim active', '1 high dollar claim active'][r - 1]
    case 'li2': return r === 1 ? 'None' : 'Consent order in force'
    case 'li3': return ['None', 'Complaints addressed; none active', 'Active campaign', 'Demand letter received'][r - 1]
    case 'in2': return `${[2026 - int(1, 5), 2026 - int(6, 10), 2026 - int(11, 20), 2026 - int(21, 38)][r - 1]}`
    case 'in3': return `${[int(95, 99), int(90, 94), int(71, 89), int(48, 70)][r - 1]}%`
    case 'in4': return `${[int(95, 100), int(90, 94), int(72, 89), int(55, 70)][r - 1]}%`
    case 'in5': return ['Funded and approved', 'Partially funded', 'Planned but unfunded', 'None proposed'][r - 1]
    case 'sp1': return `${fmtInt(c.homes)} homes`
    case 'iq1': return `${[between(2, 8.5), between(9.2, 11.8), between(12.2, 14.6), between(15.4, 22)][r - 1].toFixed(1)} ppb`
    case 'iq2': return ['Below the MCL', 'Above the MCL; treatment by 2029', 'Above the MCL; treatment planned past 2029', 'Above the MCL; no plan'][r - 1]
    case 'iq4': return `${[between(0.2, 0.75), between(0.8, 1.02), between(1.05, 1.28), between(1.32, 1.7)][r - 1].toFixed(2)} ppm`
    case 'iq3': case 'iq5': case 'iq6': return `${[int(28, 49), int(55, 65), int(68, 78), int(82, 97)][r - 1]}% of the limit`
    default: return ''
  }
}

const homesFor = (r: number) => [int(180, 1990), int(2010, 3990), int(4050, 9900), int(10200, 31000)][r - 1]

function makeContract(i: number, used: Set<string>): Contract {
  const region = REGIONS[i % 5 === 0 ? 0 : i % 5 === 1 ? 1 : i % 5 === 2 ? 2 : i % 5 === 3 ? 3 : 4]
  const state = pick(region.states)
  let town = ''
  do { town = `${pick(A1)} ${pick(A2)}` } while (used.has(town))
  used.add(town)
  const k = R()
  const kind: Contract['kind'] = k < 0.46 ? 'Wastewater' : k < 0.72 ? 'Drinking water' : 'Water and wastewater'
  const scopes: string[] = []
  if (kind !== 'Wastewater') { scopes.push('Water treatment'); if (R() < 0.42) scopes.push('Water distribution') }
  if (kind !== 'Drinking water') { scopes.push('Wastewater treatment'); if (R() < 0.38) scopes.push('Wastewater collection'); if (R() < 0.3) scopes.push('Biosolids') }
  if (R() < 0.08) scopes.push('Stormwater')
  if (kind !== 'Drinking water' && R() < 0.06) scopes.push('Water reuse')
  const size = Math.exp(gauss() * 0.75)
  const revenue = Math.round((0.9 + size * 1.9 + scopes.length * 0.45) * 100) / 100 * 1e6
  const h = gauss() * 1.05 + (R() < 0.07 ? 1.6 : 0) - 0.1
  const homesR = draw(SIGNALS.find((s) => s.id === 'sp1')!.p, 0)
  const homes = homesFor(homesR)
  const union = R() < (['Northeast', 'Midwest'].includes(region.name) ? 0.42 : 0.16)
  const startY = int(2009, 2023), term = pick([5, 5, 10, 10, 10, 15, 20])
  let endY = startY + term
  while (endY < 2027) endY += pick([3, 5, 5])
  const end = iso(endY, pick([3, 6, 6, 9, 12, 12]), pick([30, 30, 28]))
  const evergreen = R() < 0.07
  const c: Contract = {
    id: `NCO-${String(1001 + i).slice(1)}`, site: '', client: '', state, region: region.name, rvp: region.rvp, leader: person(), kind, scopes, union,
    staff: Math.max(3, Math.round(revenue / 1e6 * between(3.2, 4.6))), revenue, margin: Math.round(between(6, 19) * 10) / 10,
    start: iso(startY, 1, 1), end, monthsLeft: monthsBetween(TODAY, end), evergreen, tfc: R() < 0.34, homes, v: {}, seen: [], actions: [], h,
  }
  const ct = R()
  c.client = ct < 0.5 ? `City of ${town}` : ct < 0.72 ? `Town of ${town}` : ct < 0.88 ? `${town} Water Authority` : `${town} Utility District`
  c.site = `${town} ${kind === 'Wastewater' ? pick(['WWTP', 'Water Reclamation Facility', 'WWTP']) : kind === 'Drinking water' ? pick(['WTP', 'Water System']) : 'Utilities'}`
  for (const s of SIGNALS) {
    if (s.added) continue
    if (s.only === 'dw' && kind === 'Wastewater') continue
    if (s.only === 'ww' && kind === 'Drinking water') continue
    let r: number, raw: string
    if (s.id === 'cr1') { r = PW_STATES.has(state) ? 4 : 1; raw = PW_STATES.has(state) ? `${state}: listed` : `${state}: not listed` }
    else if (s.id === 'cr3') { r = scopes.includes('Biosolids') ? 4 : 1; raw = r === 4 ? 'Yes' : 'No' }
    else if (s.id === 'cr4') { r = union ? 4 : 1; raw = union ? 'Yes' : 'No' }
    else if (s.id === 'cr5') { r = scopes.includes('Water distribution') ? 2 : 1; raw = r === 2 ? 'Yes' : 'No' }
    else if (s.id === 'cr6') { r = scopes.includes('Wastewater collection') ? 2 : 1; raw = r === 2 ? 'Yes' : 'No' }
    else if (s.id === 'sl1') { r = stateRating(state); raw = `${STATE_NAME[state] ?? state}: rank ${STATE_RANK[state]} of 50` }
    else if (s.id === 'in1') { const n = scopes.length; r = n <= 2 ? 1 : n <= 4 ? 2 : n === 5 ? 3 : 4; raw = `${n} ${n === 1 ? 'scope' : 'scopes'}` }
    else if (s.id === 'sp1') { r = homesR; raw = rawFor('sp1', r, { homes, nps: region.nps }) }
    else if (s.id === 'cu2') { const n = region.nps; r = n > 70 ? 1 : n >= 55 ? 2 : n >= 40 ? 3 : 4; raw = `${n} (${region.name})` }
    else { r = draw(s.p, s.f === 'li' || s.f === 'iq' || s.f === 'in' ? h * 0.5 : h); raw = rawFor(s.id, r, { homes, nps: region.nps }) }
    const rd: Reading = { raw, r: (s.id === 'cu3' || s.id === 'co5') && r === 2 ? 2.5 : r }
    /* 90 days ago: most signals stood where they stand; a few were better or worse. */
    if (s.moves && !['cu1', 'cu2', 'cu3', 'co4', 'co5', 'iq2'].includes(s.id)) { const u = R(); if (u < 0.1 && rd.r > 1) rd.was = Math.floor(rd.r) - 1; else if (u > 0.93 && rd.r < 4) rd.was = Math.floor(rd.r) + 1 }
    c.v[s.id] = rd
  }
  return c
}

/* ------------------------------------------------------------------ scoring, as the workbook writes it */

export type When = 'now' | 'before' | 'q' | 'after'
/** 'before' is the scorecard before the overnight changes; 'after' includes them; 'now' includes them once the run has landed; 'q' is 90 days ago. */
export const NIGHT = { landed: false }
/* ------------------------------------------------------------------ the scorecard design: yours, built at set-up */
export type Size = 'beside' | 'weighted' | 'none'
export type Protect = 'balanced' | 'renewal' | 'margin' | 'harm'
export interface Design {
  /** Started from the analyst's proposal, or from a framework you uploaded. */
  source: 'proposed' | 'uploaded'
  protect: Protect
  rule: Rule
  size: Size
  on: Record<string, boolean>
  /** Factor weight inside its group (parts; shown as a share). */
  fw: Record<string, number>
  /** Signal weight inside its factor (parts). */
  sw: Record<string, number>
  /** Thresholds you changed, for signals read as a number. */
  cuts: Record<string, number[]>
  /** The score each band gives, where you changed it. */
  map: Record<string, number[]>
  /** Red flags: at 4, the contract cannot rate under 3. */
  flag: Record<string, boolean>
  /** What the dashboard shows. */
  panels: Record<string, boolean>
  /** Signals you described yourself. */
  custom: string[]
  /** Factors you added yourself. */
  customF: string[]
  /** Rule wording you changed: by signal, one entry per band, with the thresholds in force when you wrote it. */
  text: Record<string, ({ t: string; cuts?: number[] } | null)[]>
  /** The assumptions that bring every figure to one score per project. Each is confirmed or changed at the data check. */
  assume: { pc: 'inherit' | 'revenue'; negdso: 'one' | 'mid' | 'out'; nps: 'lowest' | 'latest' | 'average'; fac: 'worst' | 'sum'; hist: 'keep' | 'hist' }
  /** The signals of the template you uploaded, when there is one: only these are shown and checked. */
  tpl: string[] | null
  /** The file name of the template in use. */
  tplName: string
  /** Signals whose thresholds were taken from history. */
  histOn: string[]
  /** Which assumptions you have confirmed. */
  ok: Record<string, boolean>
  edits: number
}
export const PANELS: { k: string; name: string; what: string; rec: boolean; needs?: 'impact' }[] = [
  { k: 'kpi', name: 'Headline figures', what: 'Projects by rating, revenue at risk, what changed, sites with a plan', rec: true },
  { k: 'matrix', name: 'Risk, time left and size', what: 'Every project by risk score and months left on the contract; the bubble is annual revenue', rec: true },
  { k: 'movers', name: 'What changed', what: 'Projects whose score rose or fell since the last check and over 90 days', rec: true },
  { k: 'travel', name: 'Direction of travel', what: 'Every project as one line over twelve months: which rose, which fell and which held', rec: true },
  { k: 'ranked', name: 'The project list', what: 'Every project with one score, its direction, what drives it, revenue and end date', rec: true },
  { k: 'heat', name: 'Where the risk sits', what: 'Regions against factors: is a problem local or across the business', rec: true },
  { k: 'plans', name: 'Mitigation plans', what: 'Every site with a signal at 3 or 4, its plan and what the plan would bring the score to', rec: true },
  { k: 'grid', name: 'All projects at a glance', what: 'One square per project, by region', rec: false },
  { k: 'cover', name: 'Where every signal comes from', what: 'Each signal, its source, the level it sits at, how many projects it covers', rec: false },
  { k: 'back', name: 'Tested against contracts already lost', what: 'What this scorecard would have said a year before each loss', rec: false },
]
export const DESIGN: Design = { source: 'proposed', protect: 'balanced', rule: 'avg', size: 'beside', on: {}, fw: {}, sw: {}, cuts: {}, map: {}, flag: {}, panels: {}, custom: [], customF: [], text: {}, assume: { pc: 'inherit', negdso: 'mid', nps: 'lowest', fac: 'worst', hist: 'keep' }, tpl: null, tplName: '', histOn: [], ok: {}, edits: 0 }
/** How the internal and the external score combine into one rating. Asked at set-up. */
export const SCORING = DESIGN
const PROTECT_X: Record<Protect, Record<string, number>> = { balanced: {}, renewal: { cu: 1.5, co: 1.5, cp: 1.75, cl: 1.5 }, margin: { fp: 2, cr: 1.5, gr: 1.5 }, harm: { os: 1.5, en: 1.5, li: 1.3, rs: 1.5 } }
/** Signal weights from the order inside the factor: first counts most. Only the signals in use share the weight. */
/** Signals no connected source can feed. They stay on the sheet, switched off, until a source is connected. */
export const NOT_FOUND: Record<string, string> = { in2: 'The capital project history is not in the connected data. Connect the asset register or the capital plan archive to add it.' }
export function rankWeights() {
  for (const f of FACTORS) { const ss = SIGNALS.filter((s) => s.f === f.id && DESIGN.on[s.id]).sort((a, b) => a.rank - b.rank); ss.forEach((s, i) => { DESIGN.sw[s.id] = ss.length - i }) }
}
export function applyProtect(p: Protect) { DESIGN.protect = p; for (const f of FACTORS) DESIGN.fw[f.id] = Math.round(f.weight * (PROTECT_X[p][f.id] ?? 1)); DESIGN.edits += 1 }
/** Start again from the analyst's proposal (every signal it found a source for) or from the uploaded framework (its 42 signals; the rest offered). */
export function resetDesign(source: Design['source']) {
  for (const id of DESIGN.custom) { const i = SIGNALS.findIndex((x) => x.id === id); if (i >= 0) SIGNALS.splice(i, 1); delete DESIGN.on[id]; delete DESIGN.sw[id] }
  for (const id of DESIGN.customF ?? []) { const i = FACTORS.findIndex((x) => x.id === id); if (i >= 0) FACTORS.splice(i, 1); delete DESIGN.fw[id] }
  DESIGN.customF = []
  DESIGN.source = source; DESIGN.cuts = {}; DESIGN.map = {}; DESIGN.flag = {}; DESIGN.custom = []; DESIGN.text = {}
  for (const s of SIGNALS) DESIGN.on[s.id] = (source === 'proposed' ? true : !s.added) && !NOT_FOUND[s.id]
  DESIGN.assume = { pc: 'inherit', negdso: 'mid', nps: 'lowest', fac: 'worst', hist: 'keep' }; DESIGN.ok = {}; DESIGN.tpl = null; DESIGN.tplName = ''; DESIGN.histOn = []
  if (source === 'proposed') DESIGN.flag = { li3: true, cp3: true }
  rankWeights(); applyProtect(DESIGN.protect)
  for (const p of PANELS) DESIGN.panels[p.k] = p.rec
}
resetDesign('uploaded')
export const sigOn = (sid: string) => !!DESIGN.on[sid]
export const activeSignals = (group?: Group) => SIGNALS.filter((s) => DESIGN.on[s.id] && (!group || FACTORS.find((f) => f.id === s.f)!.group === group))
export const likelihoodSignals = () => SIGNALS.filter((s) => DESIGN.on[s.id] && s.f !== 'im')
export const activeFactors = (group?: Group) => FACTORS.filter((f) => (!group ? f.group !== 'impact' : f.group === group) && SIGNALS.some((s) => s.f === f.id && DESIGN.on[s.id]))
export const impactOn = () => DESIGN.size !== 'none' && activeSignals('impact').length > 0
export const factorShare = (fid: string) => { const f = FACTORS.find((x) => x.id === fid)!; const tot = activeFactors(f.group).reduce((n, x) => n + (DESIGN.fw[x.id] ?? 0), 0); return tot ? (DESIGN.fw[fid] ?? 0) / tot : 0 }
export const signalShare = (sid: string) => { const s = SIGNALS.find((x) => x.id === sid)!; const tot = SIGNALS.filter((x) => x.f === s.f && DESIGN.on[x.id]).reduce((n, x) => n + (DESIGN.sw[x.id] ?? 0), 0); return tot ? (DESIGN.sw[sid] ?? 0) / tot : 0 }
const numOf = (raw: string) => parseFloat(raw.replace(/[$,]/g, ''))
/** The four bands as they stand: the text you see, built from the thresholds where the signal is a number. */
const NUM_RE = /\d+(?:,\d{3})*(?:\.\d+)?/g
const numIn = (m: string) => Number(m.replace(/,/g, ''))
const numLike = (v: number, like: string) => { const r = Math.round(v * 100) / 100; return like.includes(',') || Math.abs(r) >= 10000 ? r.toLocaleString('en-US') : String(r) }
/** Which threshold a figure in a rule stands for: the threshold itself, or the figure just beside it ("59%" where the threshold is 60). */
function cutOf(v: number, cuts: number[]): { j: number; off: number; sign: number } | null {
  for (let j = 0; j < cuts.length; j += 1) if (cuts[j] === v) return { j, off: 0, sign: 1 }
  for (let j = 0; j < cuts.length; j += 1) if (cuts[j] < 0 && -cuts[j] === v) return { j, off: 0, sign: -1 }
  for (const off of [-1, -0.01, 1]) for (let j = 0; j < cuts.length; j += 1) {
    if (off === -1 && (cuts[j] < 2 || !Number.isInteger(cuts[j]))) continue
    if (off === 1 && v <= 100) continue
    if (Math.abs(cuts[j] + off - v) < 1e-9) return { j, off, sign: 1 }
  }
  return null
}
/** The same rule wording with its figures moved from one set of thresholds to another. */
const remap = (text: string, from: number[], to: number[]) => (from.every((x, i) => x === to[i]) ? text : text.replace(NUM_RE, (m) => { const k = cutOf(numIn(m), from); return k ? numLike(k.sign * to[k.j] + k.off, m) : m }))
/** The rule for 1 to 4 as it reads now: the wording you wrote where you changed it, and every figure on the thresholds in force. */
export function bandsOf(s: SignalDef): string[] {
  const ov = DESIGN.text[s.id], cur = DESIGN.cuts[s.id] ?? s.num?.cuts
  return [0, 1, 2, 3].map((i) => { const o = ov?.[i]; const base = o ? o.t : s.bands[i] ?? ''; const from = o ? o.cuts : s.num?.cuts; return s.num && from && cur ? remap(base, from, cur) : base })
}
/** You rewrite when a signal scores 1, 2, 3 or 4. Where a figure in the wording is a threshold, the threshold moves with it and the projects are sorted again. */
export function setBandText(sid: string, band: number, text: string): { changed: boolean; moved: boolean } {
  const s = SIGNALS.find((x) => x.id === sid)!, i = band - 1, shown = bandsOf(s)[i], t = text.trim()
  if (t === shown) return { changed: false, moved: false }
  const cur = (DESIGN.cuts[sid] ?? s.num?.cuts)?.slice()
  let moved = false
  if (s.num && cur) {
    const a = shown.match(NUM_RE) ?? [], b = t.match(NUM_RE) ?? []
    if (a.length === b.length) a.forEach((m, k) => { const va = numIn(m), vb = numIn(b[k]); if (va === vb) return; const c = cutOf(va, cur); if (c) { cur[c.j] = c.sign * (vb - c.off); moved = true } })
    if (moved) DESIGN.cuts[sid] = cur
  }
  const row = DESIGN.text[sid] ?? [null, null, null, null]
  row[i] = { t, cuts: cur?.slice() }
  DESIGN.text[sid] = row
  DESIGN.edits += 1
  return { changed: true, moved }
}
/** The band a reading falls in (1 to 4), on your thresholds if you changed them. */
export function bandOf(s: SignalDef, rd: Reading): number {
  const cuts = DESIGN.cuts[s.id]
  if (cuts && s.num) { const x = numOf(rd.raw); if (!Number.isNaN(x)) return 1 + cuts.filter((c) => (s.num!.dir === 'up' ? x >= c : x < c)).length }
  return rd.r
}
const SIG: Record<string, SignalDef> = {}
/** The score a contract gets on a signal: its band, then the score you gave that band. */
export function valOf(c: Contract, sid: string, when: When = 'now'): number | undefined {
  const rd = readingOf(c, sid, when); if (!rd) return undefined
  if (sid === 'cr2' && c.negDso) return DESIGN.assume.negdso === 'one' ? 1 : DESIGN.assume.negdso === 'mid' ? 2.5 : undefined
  const s = SIG[sid] ?? (SIG[sid] = SIGNALS.find((x) => x.id === sid)!)
  const b = bandOf(s, rd), m = DESIGN.map[sid]
  return m && Number.isInteger(b) ? m[b - 1] : b
}
export const flagsOf = (c: Contract, when: When = 'now') => Object.keys(DESIGN.flag).filter((sid) => DESIGN.flag[sid] && DESIGN.on[sid] && (valOf(c, sid, when) ?? 0) >= 4)
export const flagged = (c: Contract, when: When = 'now') => Object.keys(DESIGN.flag).some((sid) => DESIGN.flag[sid] && DESIGN.on[sid] && (valOf(c, sid, when) ?? 0) >= 4)
export const RULE_TEXT: Record<Rule, string> = { max: 'the higher of what we control and what we do not', avg: 'the average of what we control and what we do not', sep: 'two ratings side by side; the higher one colours the contract' }
export function applyNight() { NIGHT.landed = true }
export const readingOf = (c: Contract, sid: string, when: When = 'now'): Reading | undefined => {
  const b = c.v[sid]; if (!b) return undefined
  if (when === 'q') return b.was ? { raw: '', r: b.was } : b
  if ((when === 'after' || (when === 'now' && NIGHT.landed)) && c.night?.[sid]) return c.night[sid]
  return b
}
export function factorScore(c: Contract, fid: string, when: When = 'now'): number | null {
  let num = 0, den = 0
  for (const s of SIGNALS) { if (s.f !== fid || !DESIGN.on[s.id] || !c.v[s.id]) continue; const v = valOf(c, s.id, when); if (v === undefined) continue; const w = DESIGN.sw[s.id] ?? 1; num += w * v; den += w }
  return den ? num / den : null
}
export function groupScore(c: Contract, g: Group, when: When = 'now'): number {
  let num = 0, den = 0
  for (const f of FACTORS) { if (f.group !== g) continue; const s = factorScore(c, f.id, when); if (s === null) continue; const w = DESIGN.fw[f.id] ?? f.weight; num += w * s; den += w }
  return den ? num / den : 1
}
/** The weighted score alone, before any red flag. */
export function weighted(c: Contract, rule: Rule = DESIGN.rule, when: When = 'now'): number {
  const a = groupScore(c, 'internal', when), b = groupScore(c, 'external', when)
  let x = rule === 'avg' ? (a + b) / 2 : Math.max(a, b)
  if (DESIGN.size === 'weighted') x = 0.75 * x + 0.25 * groupScore(c, 'impact', when)
  return x
}
/** The score, with the red flags applied: a flagged contract cannot stand under 2.5, so it rates at least 3. */
export function score(c: Contract, rule: Rule = DESIGN.rule, when: When = 'now'): number { const x = weighted(c, rule, when); return x < 2.5 && flagged(c, when) ? 2.5 : x }
export const ratingOf = (x: number) => (x < 1.5 ? 1 : x < 2.5 ? 2 : x < 3.5 ? 3 : 4)
export const rating = (c: Contract, rule: Rule = DESIGN.rule, when: When = 'now') => ratingOf(score(c, rule, when))
export const RATING_NAME = ['', 'Low', 'Low to medium', 'Medium to high', 'High']
export const RATING_COLOR = ['', '#2e9e6b', '#c9b037', '#e2812a', '#c0392b']
export const RATING_SOFT = ['', '#e6f5ee', '#fbf5d9', '#fdeedd', '#fbe4e1']
export const f1 = (x: number) => x.toFixed(2)

/* ------------------------------------------------------------------ build the 300 */

const used = new Set<string>(['Harlow Creek', 'Ashby Falls', 'Red Mesa', 'Calder Valley', 'Wren Hollow', 'Thorn Landing'])
export const CONTRACTS: Contract[] = Array.from({ length: 300 }, (_, i) => makeContract(i, used))

const setV = (c: Contract, vals: Record<string, [number, string] | [number, string, number]>) => { for (const [k, x] of Object.entries(vals)) c.v[k] = { r: x[0], raw: x[1], ...(x[2] !== undefined ? { was: x[2] } : {}) } }
const dropNA = (c: Contract) => { for (const s of SIGNALS) { if ((s.only === 'dw' && c.kind === 'Wastewater') || (s.only === 'ww' && c.kind === 'Drinking water')) delete c.v[s.id] } }

/* Harlow Creek, Georgia: the closest contract to the line. Overnight a demand letter and a sixth odor complaint take it across. */
export const HARLOW = CONTRACTS[46]
Object.assign(HARLOW, { id: 'NCO-047', site: 'Harlow Creek WWTP', client: 'City of Harlow Creek', state: 'GA', region: 'Southeast', rvp: 'Marisol Vega', leader: 'Wade Pruitt', kind: 'Wastewater', scopes: ['Wastewater treatment', 'Wastewater collection', 'Biosolids'], union: false, staff: 19, revenue: 5.84e6, margin: 11.2, start: '2018-07-01', end: '2028-06-30', evergreen: false, tfc: true, homes: 11420, hero: 'harlow' } as Partial<Contract>)
HARLOW.monthsLeft = monthsBetween(TODAY, HARLOW.end)
HARLOW.v = {}
setV(HARLOW, {
  gr1: [3, 'No waiver of consequential damages (section 14.2)'],
  cr1: [1, 'GA: not listed'], cr2: [2, '52 days', 1], cr3: [4, 'Yes'], cr4: [1, 'No'], cr5: [1, 'No'], cr6: [2, 'Yes'],
  os1: [1, '0'], os2: [3, '1.24', 2], os3: [2, '1.7 per employee'],
  en1: [3, '97.6%', 2], en2: [2, '1'], en3: [2, '1'], en4: [2, '0.52 logins a day'],
  st1: [4, '1 open over 60 days', 1], st2: [3, 'Holder, no backup'], st3: [2, '84%'], st4: [3, '11.6%', 2],
  cu1: [3, '6 (surveyed March 2026)'], cu2: [3, '52 (Southeast)'], cu3: [2.5, 'Stable'],
  co1: [3, '5', 2], co2: [2, '44% negative', 1], co3: [3, '41% positive'], co4: [3, '$6,500'], co5: [4, 'Down 22%'],
  sl1: [4, 'Georgia: rank 46 of 50'],
  li1: [2, 'None active; 2 small property claims closed (2023, 2024)'], li2: [1, 'None'], li3: [2, 'Odor complaints addressed; none active'],
  in1: [2, '3 scopes'], in2: [2, '2017'], in3: [3, '84%'], in4: [2, '91%'], in5: [2, 'Partially funded'],
  sp1: [4, '11,420 homes'],
  iq3: [1, '44% of the limit'], iq5: [2, '61% of the limit'], iq6: [2, '57% of the limit'],
})
HARLOW.night = { li3: { r: 4, raw: 'Demand letter received 19 November, for 23 residents', was: 2, wasRaw: 'Odor complaints addressed; none active' }, co1: { r: 4, raw: '6', was: 3, wasRaw: '5' } }

/* Red Mesa, Arizona: still a 2, with the staffing pattern that came before most notices of violation. */
export const REDMESA = CONTRACTS[183]
Object.assign(REDMESA, { id: 'NCO-184', site: 'Red Mesa Regional Water Reclamation Facility', client: 'Red Mesa Utility District', state: 'AZ', region: 'West', rvp: 'Grant Leung', leader: 'Hana Delgado', kind: 'Wastewater', scopes: ['Wastewater treatment', 'Water reuse'], union: false, staff: 14, revenue: 4.12e6, margin: 13.5, start: '2021-01-01', end: '2031-12-31', evergreen: false, tfc: false, homes: 3140, hero: 'redmesa' } as Partial<Contract>)
REDMESA.monthsLeft = monthsBetween(TODAY, REDMESA.end)
REDMESA.v = {}
setV(REDMESA, {
  gr1: [2, 'three core terms present; insurance and force majeure terms missing'],
  cr1: [1, 'AZ: not listed'], cr2: [1, '38 days'], cr3: [1, 'No'], cr4: [1, 'No'], cr5: [1, 'No'], cr6: [1, 'No'],
  os1: [1, '0'], os2: [1, '0'], os3: [3, '1.2 per employee', 2],
  en1: [2, '99.4%'], en2: [2, '1'], en3: [1, '0'], en4: [3, '0.24 logins a day', 2],
  st1: [4, '2 open over 60 days (since 31 August and 14 September)', 1], st2: [3, 'Holder, no backup', 2], st3: [3, '78%', 2], st4: [4, '14.2%', 3],
  cu1: [1, '9'], cu2: [2, '66 (West)'], cu3: [2.5, 'Stable'],
  co1: [1, '0'], co2: [1, '10% negative'], co3: [2, '70% positive'], co4: [2, '$12,000'], co5: [2.5, 'Stable'],
  sl1: [3, 'Arizona: rank 30 of 50'],
  li1: [1, 'None'], li2: [1, 'None'], li3: [1, 'None'],
  in1: [1, '2 scopes'], in2: [1, '2022'], in3: [3, '82%', 2], in4: [3, '88%', 2], in5: [1, 'Funded and approved'],
  sp1: [2, '3,140 homes'],
  iq3: [3, '71% of the limit', 2], iq5: [2, '57% of the limit'], iq6: [2, '62% of the limit'],
})
REDMESA.night = { en2: { r: 3, raw: '2 (the second recorded 19 November)', was: 2, wasRaw: '1' } }

/* Ashby Falls, Massachusetts: nothing moves on the scorecard; the council agenda is what matters. */
export const ASHBY = CONTRACTS[110]
Object.assign(ASHBY, { id: 'NCO-111', site: 'Ashby Falls Water and Sewer', client: 'Town of Ashby Falls', state: 'MA', region: 'Northeast', rvp: 'Daniel Okoro', leader: 'Miles Fontaine', kind: 'Water and wastewater', scopes: ['Water treatment', 'Water distribution', 'Wastewater treatment', 'Wastewater collection'], union: true, staff: 27, revenue: 7.36e6, margin: 15.8, start: '2017-07-01', end: '2027-06-30', evergreen: false, tfc: false, homes: 6280, hero: 'ashby' } as Partial<Contract>)
ASHBY.monthsLeft = monthsBetween(TODAY, ASHBY.end)
ASHBY.v = {}
setV(ASHBY, {
  gr1: [1, 'Compliant'],
  cr1: [4, 'MA: listed'], cr2: [1, '36 days'], cr3: [1, 'No'], cr4: [4, 'Yes'], cr5: [2, 'Yes'], cr6: [2, 'Yes'],
  os1: [1, '0'], os2: [1, '0'], os3: [1, '2.8 per employee'],
  en1: [1, '100%'], en2: [1, '0'], en3: [1, '0'], en4: [1, '0.97 logins a day'],
  st1: [1, 'None'], st2: [2, 'Holder and backup'], st3: [1, '93%'], st4: [2, '7.1%'],
  cu1: [2, '8 (surveyed March 2026)'], cu2: [2, '61 (Northeast)'], cu3: [2.5, 'Stable'],
  co1: [2, '2'], co2: [1, '25% negative'], co3: [2, '63% positive'], co4: [2, '$14,000'], co5: [2.5, 'Stable'],
  sl1: [2, 'Massachusetts: rank 23 of 50'],
  li1: [1, 'None'], li2: [1, 'None'], li3: [1, 'None'],
  in1: [2, '4 scopes'], in2: [3, '2013'], in3: [2, '92%'], in4: [2, '93%'], in5: [3, 'Planned but unfunded'],
  sp1: [3, '6,280 homes'],
  iq1: [1, '6.1 ppb'], iq2: [2, 'Above the MCL; treatment by 2029'], iq3: [1, '41% of the limit'], iq4: [1, '0.48 ppm'], iq5: [1, '39% of the limit'], iq6: [2, '57% of the limit'],
})
ASHBY.night = { co2: { r: 1, raw: '33% negative (one new article)', was: 1, wasRaw: '25% negative' } }
for (const c of [HARLOW, REDMESA, ASHBY]) dropNA(c)

/* Harlow Creek is the contract closest to the line: no other contract rated 2 sits within 0.06 of a 3, under either way of combining the halves. */
for (const c of CONTRACTS) {
  if (c.hero) continue
  for (let k = 0; k < 12; k += 1) {
    const a = groupScore(c, 'internal', 'before'), b = groupScore(c, 'external', 'before')
    const near = (x: number) => x >= 2.44 && x < 2.5
    if (!near(Math.max(a, b)) && !near((a + b) / 2)) break
    const g: Group = a >= b ? 'internal' : 'external'
    const s = SIGNALS.filter((x) => x.moves && c.v[x.id] && c.v[x.id].r >= 2 && FACTORS.find((f) => f.id === x.f)!.group === g && !['cu2', 'cu3', 'co5', 'st1', 'li2'].includes(x.id)).sort((x, y) => c.v[y.id].r - c.v[x.id].r)[0]
    if (!s) break
    const r = Math.floor(c.v[s.id].r) - 1
    c.v[s.id] = { r, raw: rawFor(s.id, r, { homes: c.homes, nps: REGIONS.find((x) => x.name === c.region)!.nps }) }
  }
}

/* ------------------------------------------------------------------ outside the scorecard */

const COMPETITORS = ['Clearbrook Operations', 'Tidewell Services', 'Meridian Utility Partners']
for (const c of CONTRACTS) {
  if (c.hero) continue
  const u = R()
  if (c.monthsLeft <= 18 && u < 0.16) c.seen.push({ k: 'lead', label: 'New client lead', text: `A new ${pick(['utilities director', 'public works director', 'city manager'])} took office in ${pick(['June', 'August', 'September', 'October'])} 2026; the last NPS answer came from the predecessor.`, tone: 'warn', src: { kind: 'web', name: `${c.client}: council minutes` } })
  if (c.monthsLeft <= 24 && R() < 0.1) c.seen.push({ k: 'rfp', label: 'Procurement adviser hired', text: 'The client has hired an adviser to prepare the next operations procurement.', tone: 'crit', src: { kind: 'web', name: `${c.client}: council agenda` } })
  if (R() < 0.05) c.seen.push({ k: 'comp', label: 'Competitor next door', text: `${pick(COMPETITORS)} won the neighbouring ${pick(['county', 'district', 'city'])} contract in 2026.`, tone: 'info', src: { kind: 'web', name: 'Regional trade press' } })
  if (R() < 0.06) c.seen.push({ k: 'fin', label: 'Client budget pressure', text: 'The adopted budget defers the rate increase; the client has asked for a price review.', tone: 'warn', src: { kind: 'mail', name: 'Project leader mail' } })
}
HARLOW.seen = [
  { k: 'cap', label: 'Odor control is the client\'s to fund', text: 'Section 9.4 puts capital for odor control on the City; the biofilter replacement has been in the capital plan, unfunded, since 2023.', tone: 'warn', src: { kind: 'document', name: 'Harlow Creek O&M Agreement, section 9.4', ref: 'DOC:hc-contract' } },
  { k: 'tfc', label: 'Termination for convenience', text: 'The City can end the agreement on 180 days\' notice (section 21.1).', tone: 'warn', src: { kind: 'document', name: 'Harlow Creek O&M Agreement, section 21.1', ref: 'DOC:hc-contract' } },
  { k: 'elec', label: 'City election', text: 'Two of five council seats are on the ballot in May 2027; one candidate has questioned who runs the plant.', tone: 'info', src: { kind: 'web', name: 'Harlow Creek Ledger, 12 November', ref: 'WEB:hc-ledger' } },
]
REDMESA.seen = [
  { k: 'chain', night: true, label: 'The pattern before a notice of violation', text: 'Positions open over 60 days, overtime above 13% and a second missed sample in a quarter: five of the seven sites that received a notice of violation since 2024 showed all three 8 to 12 weeks before.', tone: 'crit', src: { kind: 'table', name: 'hr.requisition · ops.labor_weekly · plantdata.sample_schedule, 2024 to 2026' } },
  { k: 'key', label: 'One licence holder', text: 'The Grade 4 licence the contract requires is held by one operator, who has worked 11 of the last 13 weekends.', tone: 'warn', src: { kind: 'table', name: 'hr.license · ops.labor_weekly' } },
]
ASHBY.seen = [
  { k: 'insource', label: 'In-house operation on the council agenda', text: 'The Select Board agenda for 2 December lists "Water and sewer operations after June 2027: options including in-house operation".', tone: 'crit', night: true, src: { kind: 'web', name: 'Town of Ashby Falls: Select Board agenda, 2 December', ref: 'WEB:af-agenda' } },
  { k: 'lead', label: 'New client lead', text: 'Karen Whitlock became DPW Director on 17 August 2026. The NPS of 8 was given in March by her predecessor.', tone: 'crit', src: { kind: 'mail', name: 'Thread A1 · Introductions: new DPW Director', ref: 'A1' } },
  { k: 'end', label: 'Seven months left', text: 'The agreement ends 30 June 2027 with no renewal option left; the Town must re-bid or bring it in-house.', tone: 'crit', src: { kind: 'document', name: 'Ashby Falls O&M Agreement, section 2.2', ref: 'DOC:af-contract' } },
  { k: 'comp', label: 'Competitor active', text: 'Clearbrook Operations took the neighbouring Dunmere Ridge contract in April and presented to the Ashby Falls Finance Committee in October.', tone: 'warn', night: true, src: { kind: 'web', name: 'Ashby Falls Courier, 19 November', ref: 'WEB:af-courier' } },
]

/* ------------------------------------------------------------------ mitigation: the company's matrix, and actions that are tracked */

/** The mitigation matrix as the workbook writes it: one text per factor and lens (shortened). */
export const PLAYBOOK: Record<string, Partial<Record<Action['lens'], string>>> = {
  gr: { Internal: 'Consider new terms on renegotiation.' },
  cr: { Internal: 'Look at long term trends in receivables; build a union engagement team; consider new terms on renegotiation.', 'At the plant': 'Project team to understand what may be causing a payment delay; operational performance review with the Technical and Performance group.' },
  os: { Internal: 'Review short and long term trends in data and training records.', 'At the plant': 'Prioritize safety training for all employees who access the facilities and equipment.', 'In the community': 'If the problems are publicized, consider a communications campaign to rebuild trust.', 'With the client': 'Consider whether client investment would reduce the hazards, and agree priorities.' },
  en: { Internal: 'Internal review of leadership, staff and lab performance; review trends, investment and enforcement history; review the contract terms on compliance.', 'At the plant': 'Consider a facility audit with the EHS team; review the sampling plan; deploy LabCal.', 'In the community': 'If the problems are publicized, consider a communications campaign to rebuild trust.', 'With the client': 'Consider proactive communication with the client to limit the effect of noncompliance events.' },
  st: { Internal: 'Interview the project leader on why overtime is needed; engage the workforce development team on the pipeline.', 'At the plant': 'Train managers on performance reviews; create development, mentoring and succession plans.', 'In the community': 'Plant tours, school partnerships and local workforce programs.', 'With the client': 'Discuss workforce needs and shared funding of a local pipeline.' },
  cu: { Internal: 'Interview the project leader for the history of the relationship; find allies.', 'At the plant': 'Evaluate the communications and engagement approach with the client.', 'In the community': 'Assess whether community engagement influences client satisfaction.', 'With the client': 'Institute monthly meetings; look for ways to grow a sense of partnership.' },
  co: { Internal: 'Build a community engagement strategy; review the odor complaint response procedure.', 'At the plant': 'Identify odor sources; performance review of odor control equipment; consider fence-line air monitors.', 'In the community': 'Make sure every complainant receives a return call; consider public meetings and open houses.', 'With the client': 'Recommend additional odor controls in the asset management plan; agree how issues are communicated.' },
  sl: { Internal: 'Discuss the drivers of litigation risk in the state with Legal; consider outside counsel.' },
  li: { Internal: 'Immediately engage stakeholder affairs, Legal, strategic communications and executive leadership for "platinum level attention".', 'At the plant': 'Leadership, operators and staff meet Legal on the operational and communication changes needed.', 'In the community': 'Implement a community engagement strategy with strategic communications and Legal.', 'With the client': 'Coordinate as the contract terms and the relationship allow; consider a joint defense if the client is also a target.' },
  in: { Internal: 'Evaluate the capital improvement plan; document recommendations made to the client.', 'At the plant': 'Routine training for staff managing aging or complex infrastructure.', 'In the community': 'Assess community impacts of aging infrastructure.', 'With the client': 'Make sure the capital plan names every recommended upgrade; document the discussions on failure risk.' },
  sp: {},
  iq: { Internal: 'Work with Legal on source water protection and pretreatment options.', 'At the plant': 'Diligent attention to treatment; robust records of influent quality and system performance.', 'In the community': 'Assess awareness of water quality concerns; consider outreach.', 'With the client': 'Make sure the client understands influent quality, treatment needs and the capital or O&M required.' },
}

HARLOW.actions = [
  { id: 'hc1', lens: 'Internal', text: 'Send the demand letter to Legal and place a document hold on odor logs, complaint records and operator rounds since January 2024.', owner: 'Elliot Marsh, Legal', due: '20 Nov', state: 'proposed', sig: 'li3' },
  { id: 'hc2', lens: 'Internal', text: 'Notify the insurer under the pollution liability policy; the policy asks for notice within 30 days of a written demand.', owner: 'Elliot Marsh, Legal', due: '4 Dec', state: 'proposed', sig: 'li3' },
  { id: 'hc3', lens: 'At the plant', text: 'Odor source survey with the Technical and Performance group: headworks, the biofilter (media last changed 2017) and the biosolids load-out. H2S loggers at the east fence line.', owner: 'Wade Pruitt, Project Leader', due: '1 Dec', state: 'proposed', sig: 'co1' },
  { id: 'hc4', lens: 'At the plant', text: 'Move biosolids load-out to 06:00 to 10:00 on weekdays; five of the six complaints fall on load-out afternoons.', owner: 'Wade Pruitt, Project Leader', due: '24 Nov', state: 'proposed', sig: 'co1' },
  { id: 'hc5', lens: 'In the community', text: 'Return the two complaint calls still unanswered (3 and 19 November). Further contact with the 23 residents goes through Legal.', owner: 'Wade Pruitt, with Legal', due: '21 Nov', state: 'held', sig: 'co1' },
  { id: 'hc6', lens: 'With the client', text: 'Meet the City Manager before the 8 December council session: the letter, the survey plan, and the biofilter replacement the City has left unfunded since 2023 (section 9.4).', owner: 'Marisol Vega, Regional VP', due: '4 Dec', state: 'held', sig: 'li3' },
  { id: 'hc7', lens: 'With the client', text: 'Ask the City whether it received the same letter; section 16.3 allows a joint defense where both are named.', owner: 'Elliot Marsh, Legal', due: '24 Nov', state: 'held', sig: 'li3' },
]
REDMESA.actions = [
  { id: 'rm1', lens: 'Internal', text: 'Cover the two open operator posts from the West float pool for 90 days, starting Monday.', owner: 'Grant Leung, Regional VP', due: '23 Nov', state: 'proposed', sig: 'st1' },
  { id: 'rm2', lens: 'Internal', text: 'Re-post both requisitions at the revised grade; the offers declined in October were 9% under the Phoenix market rate.', owner: 'Nadia Brooks, HR', due: '27 Nov', state: 'proposed', sig: 'st1' },
  { id: 'rm3', lens: 'At the plant', text: 'Review the sampling plan and put the schedule in LabCal with a second owner; both missed samples fell on a weekend shift worked on overtime.', owner: 'Hana Delgado, Project Leader', due: '27 Nov', state: 'proposed', sig: 'en2' },
  { id: 'rm4', lens: 'At the plant', text: 'Name a backup for the Grade 4 licence; one operator sits the exam in January.', owner: 'Hana Delgado, Project Leader', due: '15 Jan', state: 'open', sig: 'st2' },
  { id: 'rm5', lens: 'With the client', text: 'Tell the District about the two missed samples and the cover plan before the monthly report shows them.', owner: 'Hana Delgado, Project Leader', due: '25 Nov', state: 'held', sig: 'en2' },
]
ASHBY.actions = [
  { id: 'af1', lens: 'With the client', text: 'The Regional VP meets the new DPW Director before the 2 December Select Board meeting.', owner: 'Daniel Okoro, Regional VP', due: '1 Dec', state: 'held' },
  { id: 'af2', lens: 'With the client', text: 'Send a pulse NPS to the new DPW Director; the score on file is her predecessor\'s.', owner: 'Camille Roy, Client Experience', due: '26 Nov', state: 'proposed', sig: 'cu1' },
  { id: 'af3', lens: 'Internal', text: 'Start the renewal plan: ten years of results, the cost of in-house operation for the Town, and the transition risk on four scopes.', owner: 'Daniel Okoro, Regional VP', due: '11 Dec', state: 'proposed' },
  { id: 'af4', lens: 'In the community', text: 'Offer the Courier a plant visit; the 19 November article quotes the competitor and nobody from Northline.', owner: 'Adrian Lowe, Communications', due: '5 Dec', state: 'proposed', sig: 'co2' },
]

/* ------------------------------------------------------------------ what the journeys state */

export const byId = (id: string) => CONTRACTS.find((c) => c.id === id)
export function portfolio(rule: Rule = 'max', when: When = 'now') {
  const dist = [0, 0, 0, 0, 0]
  for (const c of CONTRACTS) dist[rating(c, rule, when)] += 1
  const readings = CONTRACTS.reduce((n, c) => n + Object.keys(c.v).length, 0)
  const acts = CONTRACTS.flatMap((c) => (c.hero ? [] : c.actions))
  const cameBack = CONTRACTS.filter((c) => !c.hero && rating(c, rule, 'q') >= 3 && rating(c, rule, 'before') < 3)
  const wentUp = CONTRACTS.filter((c) => rating(c, rule, 'q') < 3 && rating(c, rule, 'before') >= 3)
  const revenue = CONTRACTS.reduce((n, c) => n + c.revenue, 0)
  const high = CONTRACTS.filter((c) => rating(c, rule, when) >= 3)
  return { n: CONTRACTS.length, dist, readings, open: acts.filter((a) => a.state === 'open').length, overdue: acts.filter((a) => a.state === 'overdue').length, done: acts.filter((a) => a.state === 'done').length, cameBack, wentUp, revenue, high, highRevenue: high.reduce((n, c) => n + c.revenue, 0) }
}
/** How many signals of the scorecard the workbook's data sheet marks as available without manual input. */
export const specCoverage = () => { const A = activeSignals(); return { total: A.length, avail: A.filter((s) => s.spec.avail).length, manual: A.filter((s) => s.spec.manual).length, auto: A.filter((s) => s.spec.avail && !s.spec.manual).length, added: A.filter((s) => s.added).length, bySrc: (['table', 'document', 'mail', 'web'] as SrcKind[]).map((k) => ({ k, n: A.filter((s) => s.src.kind === k).length })) } }

/** The renewal review: contracts that decide in the next 18 months. The nine are evergreen contracts the client can end on notice. */
export const RENEW_HORIZON = 18
export function renewals(rule: Rule = 'max', nineIn = true) {
  const ending = CONTRACTS.filter((c) => !c.evergreen && c.monthsLeft <= RENEW_HORIZON)
  const ever = CONTRACTS.filter((c) => c.evergreen && c.tfc)
  const set = nineIn ? [...ending, ...ever] : ending
  const rev = (xs: Contract[]) => xs.reduce((n, c) => n + c.revenue, 0)
  const high = set.filter((c) => rating(c, rule, 'before') >= 3)
  const newLead = set.filter((c) => c.seen.some((s) => s.k === 'lead'))
  const signs = set.filter((c) => c.seen.some((s) => ['insource', 'rfp', 'lead', 'comp'].includes(s.k)))
  const quiet = set.filter((c) => rating(c, rule, 'before') <= 2 && c.seen.some((s) => ['insource', 'rfp'].includes(s.k) || (s.k === 'lead' && c.monthsLeft <= 12)))
  const plan = [...new Set([...high, ...quiet])].sort((a, b) => b.revenue - a.revenue)
  return { ending, ever, set, rev, revenue: rev(set), high, highRev: rev(high), newLead, signs, quiet, quietRev: rev(quiet), plan, planRev: rev(plan), top: plan.slice(0, 5), topRev: rev(plan.slice(0, 5)) }
}

/** Renewals lost in the last three years, and what the scorecard would have said twelve months before. */
export const LOST = [
  { site: 'Calder Valley WWTP', state: 'OH', lost: 'December 2025', how: 'Lost at re-bid to Clearbrook Operations', revenue: 6.9e6, int: 1.84, ext: 2.11, rated: 2, moved: ['New utilities director nine months before', 'Procurement adviser hired seven months before', 'No NPS answer from the new director'], doc: 'DOC:calder-review' },
  { site: 'Wren Hollow Water System', state: 'PA', lost: 'June 2025', how: 'Taken in-house by the Township', revenue: 3.2e6, int: 1.67, ext: 1.92, rated: 2, moved: ['In-house operation on three council agendas in the year before', 'Township budget review of all service contracts'], doc: '' },
  { site: 'Thorn Landing Utilities', state: 'FL', lost: 'September 2024', how: 'Not renewed after a consent order', revenue: 4.4e6, int: 2.71, ext: 3.02, rated: 3, moved: ['Two notices of violation in the year before', 'Consent order signed four months before'], doc: '' },
]

export const m1 = (n: number) => `$${(n / 1e6).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}M`
export const m2 = (n: number) => `$${(n / 1e6).toFixed(2)}M`
export const shortSite = (c: Contract) => c.site.replace(/ (WWTP|WTP|Water System|Utilities|Water Reclamation Facility|Regional Water Reclamation Facility|Water and Sewer)$/, '')
export const scoreLine = (c: Contract, rule: Rule, when: When = 'now') => rule === 'avg' ? `${f1(score(c, rule, when))} (internal ${f1(groupScore(c, 'internal', when))}, external ${f1(groupScore(c, 'external', when))})` : `internal ${f1(groupScore(c, 'internal', when))}, external ${f1(groupScore(c, 'external', when))}`

/** What the analyst sees about a contract that your scorecard does not score. */
export const seenOf = (c: Contract) => c.seen.filter((x) => (NIGHT.landed || !x.night) && !(x.sig && DESIGN.on[x.sig]))

/* ================================================================== version 2: the added signals, impact, direction, plans */
const R2 = rng(20261121)
const b2 = (a: number, b: number) => a + R2() * (b - a)
const hasSeen = (c: Contract, k: string) => c.seen.some((x) => x.k === k)
/** A value inside the band drawn, for a signal read as a number. */
const rawNum = (s: SignalDef, r: number): string => {
  const [a, b, c] = s.num!.cuts, up = s.num!.dir === 'up'
  const step = Math.abs(b - a) || 1
  const lo = up ? [Math.max(0, a - step), a, b, c][r - 1] : [a, b, c, c - step][r - 1]
  const hi = up ? [a, b, c, c + step * 1.4][r - 1] : [a + step, a, b, c][r - 1]
  const x = b2(lo + (hi - lo) * 0.08, hi - (hi - lo) * 0.08)
  const dec = step < 4 ? 1 : 0
  const t = up && r === 1 && a <= 1 ? '0' : x.toFixed(dec)
  return `${s.id === 'fp1' && x > 0 ? '+' : ''}${t} ${s.num!.unit}`
}
function addReadings(c: Contract) {
  for (const s of SIGNALS) {
    if (!s.added || c.v[s.id]) continue
    if ((s.only === 'dw' && c.kind === 'Wastewater') || (s.only === 'ww' && c.kind === 'Drinking water')) continue
    let r = 1, raw = ''
    const mrev = c.revenue / 1e6, mk = c.revenue * c.margin / 100 / 1e3
    if (s.id === 'im1') { r = mrev < 2 ? 1 : mrev < 4 ? 2 : mrev < 7 ? 3 : 4; raw = `${mrev.toFixed(2)} $M a year` }
    else if (s.id === 'im2') { r = mk < 150 ? 1 : mk < 400 ? 2 : mk < 800 ? 3 : 4; raw = `${Math.round(mk)} $k a year` }
    else if (s.id === 'im3') { r = c.evergreen ? 3 : c.monthsLeft > 36 ? 1 : c.monthsLeft >= 18 ? 2 : c.monthsLeft >= 12 ? 3 : 4; raw = c.evergreen ? 'Evergreen: rolls on, can end on notice' : `${c.monthsLeft} months` }
    else if (s.id === 'im4') r = c.evergreen ? 1 : draw(s.p, 0, R2)
    else if (s.id === 'im5') r = c.tfc ? 4 : 1
    else if (s.id === 'cp1') r = hasSeen(c, 'lead') ? 4 : draw([60, 30, 10, 0], 0, R2)
    else if (s.id === 'cp3') r = hasSeen(c, 'rfp') ? 4 : draw([88, 9, 3, 0], c.h * 0.3, R2)
    else if (s.id === 'cp4') r = hasSeen(c, 'fin') ? 3 : draw([46, 42, 8, 4], 0, R2)
    else if (s.id === 'cl1') r = hasSeen(c, 'comp') ? 3 : draw([54, 38, 6, 2], 0, R2)
    else r = draw(s.p, ['fp', 'st', 'en'].includes(s.f) ? c.h : c.h * 0.4, R2)
    if (!raw) raw = s.num ? rawNum(s, r) : s.bands[r - 1] || s.bands[0]
    const rd: Reading = { raw, r }
    if (s.moves) { const u = R2(); if (u < 0.1 && r > 1) rd.was = r - 1; else if (u > 0.94 && r < 4) rd.was = r + 1 }
    c.v[s.id] = rd
  }
}
for (const c of CONTRACTS) addReadings(c)
/* The three contracts written by hand: their added readings, and what the morning of 20 November changes in them. */
setV(HARLOW, {
  cr7: [3, 'Fixed, with a re-opener at 15%'], cr8: [2, 'Capped at 5% of the annual fee'], cr9: [2, 'CPI, yearly'], en5: [1, '0 in twelve months'], en6: [2, 'Renews in 2029'], st5: [2, '3.4 years'], st6: [2, 'Two holders'],
  in6: [2, '31 % corrective'], in7: [3, '41 years'], iq7: [2, 'Detected, no state rule'], iq8: [2, 'Proposed, more than 3 years out'],
  fp1: [2, '-1.1 points'], fp2: [2, 'Flat'], fp3: [3, '6.2 % over plan (odor chemicals)', 2], fp4: [1, 'None'], fp5: [1, 'None in 3 years'],
  cp1: [1, 'Same contacts for 3 years or more'], cp2: [3, 'Two of five council seats on the ballot in May 2027'], cp3: [1, 'None found'], cp4: [2, 'Rated A'], cp5: [2, '2 mentions in twelve months'], cp6: [2, 'One, closed'],
  cl1: [2, 'One within 50 miles'], cl2: [1, 'None in the region in 2 years'], cl3: [1, 'None'], rs1: [2, 'In the 500-year zone'], rs3: [2, 'Assessed, findings closed on plan'], rs4: [2, 'Plan current, no drill this year'], im4: [2, 'One mutual option left'], im6: [2, 'Used as a reference in bids'],
})
setV(REDMESA, {
  st5: [3, '1.3 years'], st6: [4, 'One holder, no backup (11 of the last 13 weekends worked)'], fp1: [2, '-1.8 points'], fp3: [3, '7.4 % over plan (overtime)', 2], cp1: [1, 'Same contacts for 3 years or more'], cp3: [1, 'None found'], cl2: [1, 'None in the region in 2 years'],
})
setV(ASHBY, {
  cr7: [2, 'Passed through above a threshold'], cr8: [2, 'Capped at 5% of the annual fee'], cr9: [2, 'CPI, yearly'], en5: [1, '0 in twelve months'], en6: [2, 'Renews in 2030'], st5: [1, '8.2 years'], st6: [2, 'Two holders'], in6: [2, '24 % corrective'], in7: [3, '44 years'], iq7: [1, 'Not detected'], iq8: [2, 'Proposed, more than 3 years out'],
  fp1: [1, '+0.6 points'], fp2: [2, 'Flat'], fp3: [1, '0.8 % over plan'], fp4: [1, 'None'], fp5: [1, 'None in 3 years'],
  cp1: [4, 'DPW Director changed 17 August 2026', 1], cp2: [2, 'Election in 12 to 24 months'], cp3: [1, 'None found'], cp4: [2, 'Rated A'], cp5: [2, '1 mentions in twelve months'], cp6: [1, 'None in twelve months'],
  cl1: [3, 'One in the same county (Dunmere Ridge)'], cl2: [2, 'One in the region: Dunmere Ridge, April'], cl3: [2, 'Client asked for a benchmark'], rs1: [2, 'In the 500-year zone'], rs2: [1, 'No drought in 5 years'], rs3: [2, 'Assessed, findings closed on plan'], rs4: [1, 'Plan current, drill this year'], im4: [4, 'No option left: goes to bid'], im6: [3, 'Regional anchor'],
})
ASHBY.night = {
  ...ASHBY.night,
  cp3: { r: 4, raw: 'On the Select Board agenda for 2 December: "options including in-house operation"', was: 1, wasRaw: 'None found' },
  cp5: { r: 3, raw: '3 mentions in twelve months', was: 2, wasRaw: '1 mention' },
  cl2: { r: 4, raw: 'Clearbrook Operations presented to the Finance Committee in October (minutes published 19 November)', was: 2, wasRaw: 'One in the region: Dunmere Ridge, April' },
}
for (const c of [HARLOW, REDMESA, ASHBY]) dropNA(c)
/* What used to sit beside the scorecard now has a signal. Where you leave that signal out, it is still shown, unscored. */
const SEEN_SIG: Record<string, string> = { lead: 'cp1', rfp: 'cp3', comp: 'cl1', fin: 'cp4', insource: 'cp3', tfc: 'im5', elec: 'cp2', key: 'st6', end: 'im3' }
for (const c of CONTRACTS) for (const x of c.seen) x.sig = c === ASHBY && x.k === 'comp' ? 'cl2' : SEEN_SIG[x.k]
resetDesign('proposed')

/* ------------------------------------------------------------------ impact, priority, direction */
export const impactScore = (c: Contract) => groupScore(c, 'impact', 'before')
export const impactRating = (c: Contract) => ratingOf(impactScore(c))
export type Priority = 'Act now' | 'Manage' | 'Watch' | 'Routine'
export const PRIORITY_COLOR: Record<Priority, string> = { 'Act now': '#c0392b', Manage: '#e2812a', Watch: '#c9b037', Routine: '#8a94a6' }
export const PRIORITY_WHAT: Record<Priority, string> = { 'Act now': 'High risk and a lot at stake', Manage: 'High risk, less at stake', Watch: 'A lot at stake and close to the line', Routine: 'Nothing to do today' }
export function priorityOf(c: Contract, when: When = 'now'): Priority {
  const s = score(c, DESIGN.rule, when), L = ratingOf(s), I = impactOn() ? impactRating(c) : 0
  if (!impactOn()) return L >= 3 ? 'Manage' : s >= 2.25 ? 'Watch' : 'Routine'
  return L >= 3 && I >= 3 ? 'Act now' : L >= 3 ? 'Manage' : I >= 3 && s >= 2.2 ? 'Watch' : 'Routine'
}
const hash = (t: string) => { let h = 2166136261; for (let i = 0; i < t.length; i += 1) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) } return (h >>> 0) / 4294967296 }
/** Twelve monthly scores ending today. The score of 90 days ago is computed; the months before it are the stored history. */
export function trendOf(c: Contract, when: When = 'now'): number[] {
  const now = score(c, DESIGN.rule, when), q = score(c, DESIGN.rule, 'q'), drift = (hash(c.id) - 0.5) * 0.3
  /* After a morning check the last point is this morning: what moved overnight shows as a step at the end, not as a slope over three months. */
  const upTo = when === 'after' ? score(c, DESIGN.rule, 'before') : now
  return Array.from({ length: 12 }, (_, i) => (i <= 8 ? q - drift * (8 - i) / 8 + (hash(c.id + i) - 0.5) * 0.07 : i === 11 ? now : q + (upTo - q) * (i - 8) / 3))
}
export const deltaOf = (c: Contract, when: When = 'now') => score(c, DESIGN.rule, when) - score(c, DESIGN.rule, 'q')
export const dirOf = (c: Contract, when: When = 'now'): 'up' | 'down' | 'flat' => { const d = deltaOf(c, when); return d > 0.08 ? 'up' : d < -0.08 ? 'down' : 'flat' }
export interface Driver { s: SignalDef; f: FactorDef; v: number; pts: number; raw: string; was?: number }
/** The signals that lift a contract's score most: band 3 or 4, by how many points of the group score they add. */
export function driversOf(c: Contract, when: When = 'now', n = 99): Driver[] {
  const out: Driver[] = []
  for (const s of likelihoodSignals()) {
    const v = valOf(c, s.id, when); if (v === undefined || v < 3) continue
    const f = FACTORS.find((x) => x.id === s.f)!
    const rd = readingOf(c, s.id, when)!
    out.push({ s, f, v, pts: factorShare(f.id) * signalShare(s.id) * (v - 1), raw: rd.raw, was: rd.was })
  }
  return out.sort((a, b) => b.pts - a.pts).slice(0, n)
}

/* ------------------------------------------------------------------ the mitigation plan, written for the site */
const OWNER: Record<string, (c: Contract) => string> = {
  gr: () => `${PEOPLE.legal}, Legal`, cr: (c) => `${c.rvp}, Regional VP`, os: (c) => `${c.leader}, Project Leader`, en: () => `${PEOPLE.compliance}, Compliance`, st: () => `${PEOPLE.hr}, HR`,
  cu: (c) => `${c.rvp}, Regional VP`, co: () => `${PEOPLE.comms}, Communications`, li: () => `${PEOPLE.legal}, Legal`, in: (c) => `${c.leader}, Project Leader`, iq: () => `${PEOPLE.compliance}, Compliance`,
  fp: (c) => `${c.leader}, Project Leader`, cp: (c) => `${c.rvp}, Regional VP`, cl: (c) => `${c.rvp}, Regional VP`, rs: (c) => `${c.leader}, Project Leader`,
}
const ACT: Record<string, string> = {
  gr1: 'Table the missing terms at the next amendment of the {client} agreement: {raw}. Legal drafts the wording before the renewal talks open.',
  cr2: 'Receivables stand at {raw}. {leader} walks the open invoices with the client\'s finance officer this month and agrees a payment date for each.',
  os1: 'Lost time rate {raw}. Stand-down at {site} this week; the Regional safety lead reviews the last three incidents with the crew and reports the common cause.',
  os2: 'Recordable rate {raw}. Review the last twelve months of incidents at {site} by task; retrain on the two tasks that recur.',
  os3: 'Safety observations: {raw}. Set one observation per shift at {site} and review them at the Monday meeting for eight weeks.',
  en1: 'Permit compliance {raw}. Compliance audits the lab and the process at {site}; a corrective plan with dates goes to the client before the next monthly report.',
  en2: 'Missed samples: {raw}. Put the sampling schedule at {site} in the calendar with a second owner; Compliance checks each week for a quarter.',
  en3: 'Notices of violation: {raw}. Root cause report for each, shared with the regulator and {client} before they ask.',
  en4: 'Compliance system use is low ({raw}). Name a compliance owner at {site} and log in daily; Compliance reviews use at month end.',
  en5: 'Overflows: {raw}. Walk the collection system hot spots with the client and agree a cleaning and CCTV schedule for the six worst lines.',
  en6: 'Permit: {raw}. Start the renewal file for {site} now and cost the likely new limits with the client.',
  st1: 'Open positions: {raw}. Cover from the {region} float pool for 90 days and re-post at the local market rate.',
  st2: 'Required licence: {raw}. Name a backup at {site} and book the exam; cover from a neighbouring site until then.',
  st3: 'Retention {raw}. Stay interviews with every operator at {site} this month; HR reports the three most common reasons.',
  st4: 'Overtime {raw}. Re-cut the shift pattern at {site} and fill the open post; overtime back under 10% in 60 days.',
  st5: 'The site manager has been in post {raw}. Pair with a senior project leader for six months and bring the Regional VP to every client meeting this quarter.',
  st6: 'Licences: {raw}. Sponsor a second operator for the licence and write a cover agreement with the nearest site.',
  cu1: 'Client score {raw}. {rvp} meets the client lead this month to hear it first hand and agrees three things to fix by name.',
  cu3: 'Client meetings: {raw}. Put a monthly review with {client} back in the calendar; the Regional VP attends the first two.',
  co1: 'Odor complaints: {raw}. Odor source survey at {site} with fence-line loggers; return every complaint call within one day.',
  co2: 'Local coverage: {raw}. Communications briefs the local paper with the plant\'s results and offers a visit.',
  co3: 'Local coverage: {raw}. One community event at {site} this quarter and a plant open day.',
  co4: 'Community spend: {raw}. Agree a small community program with {client} for next year.',
  li1: 'Litigation: {raw}. Legal reviews the reserve and briefs the Regional VP on what {site} must and must not say.',
  li3: 'Threatened litigation: {raw}. Legal takes the file; preserve the records; one voice to residents.',
  in3: 'Preventive maintenance on critical assets {raw}. Clear the backlog at {site} in 60 days with regional maintenance support.',
  in4: 'Preventive maintenance {raw}. Re-plan the PM schedule at {site}; weekly completion report to the Regional VP until it passes 90%.',
  in5: 'Capital plan: {raw}. Put the unfunded items in writing to {client} with the risk of each, so the record shows who decided.',
  in6: 'Maintenance is {raw}. Reliability review of the five assets that fail most at {site}.',
  iq1: 'Lead {raw}. Review corrosion control at {site} with the Technical group; step up sampling.',
  iq2: 'PFAS: {raw}. Cost the treatment options with {client} and agree who funds them.',
  iq7: 'PFAS in biosolids: {raw}. Line up a second outlet for the biosolids from {site} before the rule bites.',
  iq8: 'New rules: {raw}. Cost the upgrade for {site} and put it to {client} in writing this quarter.',
  fp1: 'Margin is {raw} against budget. {leader} and Finance go through the cost lines of {site} this month; a recovery plan to the Regional VP.',
  fp2: 'Margin trend: {raw}. Find the two cost lines behind the slide at {site} and price a change order or a fee adjustment.',
  fp3: 'Costs are {raw}. Review chemical dosing and overtime at {site}; claim the pass-through the contract allows.',
  fp4: 'Change orders: {raw}. {rvp} takes the open change orders to {client} this month; no new out-of-scope work without a signed order.',
  fp5: 'Penalties: {raw}. Root cause for each penalty at {site}, and a fix with a date.',
  cp1: 'Client contacts: {raw}. {rvp} meets the new lead within 30 days and re-runs the client survey; the score on file is the predecessor\'s.',
  cp2: 'Elections: {raw}. Brief every candidate\'s office with the plant\'s record; no one should hear about {site} first from a rival.',
  cp3: 'In-house operation or a re-bid: {raw}. Start the renewal plan for {site} now: results over the term, the cost of in-house operation, the transition risk.',
  cp4: 'Client finances: {raw}. Prepare two scope options for {client} that hold our margin if the budget is cut.',
  cp5: 'Public meetings: {raw}. Attend the next meeting of {client} and offer the board a results briefing.',
  cp6: 'Escalations: {raw}. {rvp} calls the client director this week and closes each escalation in writing.',
  cl1: 'Competitors: {raw}. Refresh the price benchmark for {site} and the list of what we do that a rival would not.',
  cl2: 'Competitor activity: {raw}. Win-back brief for {client}: what the rival offered next door and how it turned out.',
  cl3: 'Price pressure: {raw}. Offer {client} a value review before they ask for a re-bid.',
  rs2: 'Source water: {raw}. Review the drought plan with {client} and test the backup source.',
  rs3: 'Plant controls: {raw}. Close the overdue findings at {site} with IT security; assess this quarter if never assessed.',
  rs4: 'Emergency plan: {raw}. Update the plan for {site} and run a drill with {client} this quarter.',
}
const fmtDue = (days: number) => { const d = new Date(`${TODAY}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + 1 + days); return `${d.getUTCDate()} ${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getUTCMonth()]}` }
export const PLAN_MAX = 5
export interface PlanItem { id: string; s: SignalDef; f: FactorDef; v: number; raw: string; text: string; owner: string; due: string; to: number; basis?: { kind: SrcKind; text: string }[]; fixed?: boolean; /** At 3 or 4, but not in this plan yet. */ later?: boolean }
/** One action for every signal that scores 3 or 4 on this contract and can be moved. Signals that are facts of the site are listed as such. */
export function planFor(c: Contract, when: When = 'now'): PlanItem[] {
  const out: PlanItem[] = []
  /* What changed this morning comes first, then by weight. A plan has at most seven actions: the rest wait their turn. */
  const ds = driversOf(c, when).sort((x, y) => Number(!!c.night?.[y.s.id]) - Number(!!c.night?.[x.s.id]))
  let n = 0
  for (const d of ds) {
    const { s, f, v } = d
    if (s.moves && n >= PLAN_MAX && !c.actions.some((a) => a.sig === s.id && c.night?.[s.id])) { out.push({ id: `${c.id}-${s.id}`, s, f, v, raw: d.raw, text: '', owner: '', due: '', to: v, later: true }); continue }
    if (s.moves) n += 1
    const fill = (t: string) => t.replace(/\{raw\}/g, d.raw.replace(/^(.)/, (m) => m.toLowerCase())).replace(/\{site\}/g, shortSite(c)).replace(/\{leader\}/g, c.leader).replace(/\{rvp\}/g, c.rvp).replace(/\{client\}/g, c.client.replace(/^(City|Town) of /, 'the $1 of ')).replace(/\{region\}/g, c.region)
    if (!s.moves) { out.push({ id: `${c.id}-${s.id}`, s, f, v, raw: d.raw, text: 'A fact of the site or the contract. Nothing to do today; it is priced and argued at renewal.', owner: '', due: '', to: v, fixed: true }); continue }
    const hand = c.actions.filter((a) => a.sig === s.id)
    if (hand.length) { hand.forEach((a, i) => out.push({ id: a.id, s, f, v, raw: d.raw, text: a.text, owner: a.owner, due: a.due, to: Math.max(2, v - 1), basis: i === 0 ? basisOf(c, s, d.raw) : undefined })); continue }
    out.push({ id: `${c.id}-${s.id}`, s, f, v, raw: d.raw, text: `${fill(ACT[s.id] ?? `${s.name}: {raw}. {leader} reviews it with the Regional VP and sets a fix with a date.`)} ${c.hero ? '' : contextOf(c, s)}`.trim(), owner: (OWNER[f.id] ?? OWNER.in)(c), due: fmtDue(v >= 4 ? 14 : 30), to: Math.max(2, v - 1), basis: basisOf(c, s, d.raw) })
  }
  return out
}
/** Where the score would stand if every action of the plan landed. */
export function planEffect(c: Contract, when: When = 'now') {
  const v: Record<string, Reading> = when === 'after' || (when === 'now' && NIGHT.landed) ? { ...c.v, ...(c.night ?? {}) } : { ...c.v }
  for (const p of planFor(c, when)) if (!p.fixed && !p.later) v[p.s.id] = { raw: '', r: p.to }
  const after = score({ ...c, v, night: undefined }, DESIGN.rule, 'before'), from = score(c, DESIGN.rule, when)
  return { from, to: Math.min(from, after), rFrom: ratingOf(from), rTo: ratingOf(Math.min(from, after)) }
}

/* ------------------------------------------------------------------ what the morning check of 20 November finds, on your scorecard */
export interface Move { c: Contract; s0: number; s1: number; r0: number; r1: number; p0: Priority; p1: Priority; sigs: { s: SignalDef; from: number; to: number; raw: string }[]; unscored: Seen[] }
export function movers(): Move[] {
  const out: Move[] = []
  for (const c of CONTRACTS) {
    if (!c.night && !c.seen.some((x) => x.night)) continue
    const sigs = Object.keys(c.night ?? {}).filter((sid) => DESIGN.on[sid]).map((sid) => ({ s: SIGNALS.find((x) => x.id === sid)!, from: valOf(c, sid, 'before') ?? 1, to: valOf(c, sid, 'after') ?? 1, raw: c.night![sid].raw })).filter((x) => x.from !== x.to)
    const unscored = c.seen.filter((x) => x.night && !(x.sig && DESIGN.on[x.sig]))
    const s0 = score(c, DESIGN.rule, 'before'), s1 = score(c, DESIGN.rule, 'after')
    if (!sigs.length && !unscored.length) continue
    out.push({ c, s0, s1, r0: ratingOf(s0), r1: ratingOf(s1), p0: priorityOf(c, 'before'), p1: priorityOf(c, 'after'), sigs, unscored })
  }
  return out.sort((a, b) => (b.r1 - b.r0) - (a.r1 - a.r0) || (b.s1 - b.s0) - (a.s1 - a.s0))
}
export const moveLine = (m: Move) => m.r1 > m.r0 ? `${shortSite(m.c)} moved from ${m.r0} to ${m.r1}` : m.s1 > m.s0 + 0.004 ? `${shortSite(m.c)} rose from ${f1(m.s0)} to ${f1(m.s1)}, still rated ${m.r1}` : `${shortSite(m.c)}: a sign your scorecard does not score`

/* ------------------------------------------------------------------ the back-test: the renewals already lost, on your design */
const LOST_PLUS: Record<string, Record<string, number>> = {
  'Calder Valley WWTP': { cp1: 4, cp3: 4, cp5: 3, cl1: 3, cl2: 3, cl3: 3, fp1: 3, fp2: 3 },
  'Wren Hollow Water System': { cp3: 4, cp5: 4, cp4: 3, cp1: 2, cp2: 4, fp1: 2 },
  'Thorn Landing Utilities': { cp6: 4, cp5: 3, fp5: 4, fp1: 3, cl2: 2 },
}
export function lostOn(l: (typeof LOST)[number]) {
  const plus = LOST_PLUS[l.site] ?? {}
  const half = (g: Group, base: number) => {
    let num = 0, den = 0
    for (const f of activeFactors(g)) {
      const w = DESIGN.fw[f.id] ?? f.weight
      if (!f.added) { num += w * base; den += w; continue }
      let n2 = 0, d2 = 0
      for (const s of SIGNALS) { if (s.f !== f.id || !DESIGN.on[s.id]) continue; const sw = DESIGN.sw[s.id] ?? 1; n2 += sw * (plus[s.id] ?? 1); d2 += sw }
      if (d2) { num += w * (n2 / d2); den += w }
    }
    return den ? num / den : base
  }
  const int = half('internal', l.int), ext = half('external', l.ext)
  const w = DESIGN.rule === 'avg' ? (int + ext) / 2 : Math.max(int, ext)
  const flags = Object.keys(DESIGN.flag).filter((sid) => DESIGN.flag[sid] && DESIGN.on[sid] && (plus[sid] ?? 0) >= 4)
  const s = w < 2.5 && flags.length ? 2.5 : w
  return { int, ext, s, rated: ratingOf(s), flags }
}
export const lostCaught = () => LOST.filter((l) => lostOn(l).rated >= 3).length

/* ------------------------------------------------------------------ coverage, and a signal you describe yourself */
export const coverOf = (sid: string) => { const s = SIGNALS.find((x) => x.id === sid)!; const app = CONTRACTS.filter((c) => !((s.only === 'dw' && c.kind === 'Wastewater') || (s.only === 'ww' && c.kind === 'Drinking water'))); return { n: app.filter((c) => c.v[sid]).length, of: app.length } }
export const bandCount = (sid: string) => { const out = [0, 0, 0, 0]; const s = SIGNALS.find((x) => x.id === sid)!; for (const c of CONTRACTS) { const rd = c.v[sid]; if (rd) out[Math.min(4, Math.max(1, Math.round(bandOf(s, rd)))) - 1] += 1 } return out }
/** You describe a signal in a sentence; the analyst finds where it can be read, proposes four bands and reads it for every contract. */
export function addCustomSignal(text: string, into?: string, bands?: string[]): SignalDef {
  const t = text.toLowerCase()
  const DEF = /notice|complaint|excursion|incident|event|outage|break|spill|failure|claim|fine|violation|alarm|shutdown/.test(t) ? ['None in twelve months', 'One in twelve months', 'Two or three in twelve months', 'More than three in twelve months'] : ['Not seen', 'Seen once in twelve months', 'Seen more than once', 'Seen and getting worse']
  const only: SignalDef['only'] = /boil water|drinking water|tap water|\blead\b|copper|water main|distribution/.test(t) ? 'dw' : /effluent|sewer|overflow|biosolid|sludge|influent/.test(t) ? 'ww' : undefined
  const bb = [0, 1, 2, 3].map((i) => (bands?.[i] ?? '').trim() || DEF[i]) as [string, string, string, string]
  const f = into ?? (/overtime|operator|staff|vacan|licen|training|turnover/.test(t) ? 'st' : /margin|cost|invoice|budget|price|penalt|profit/.test(t) ? 'fp' : /storm|flood|cyber|weather|drought|power/.test(t) ? 'rs' : /competitor|rival|bid/.test(t) ? 'cl' : /injur|safety|osha/.test(t) ? 'os' : /permit|violation|sample|effluent|spill/.test(t) ? 'en' : /resident|odor|news|press|community/.test(t) ? 'co' : 'cp')
  const src = /mail|email|letter|wrote|complain/.test(t) ? M('Client and project mail', 'Messages that match the description, read and counted by contract') : /news|council|agenda|public|web|rating|election/.test(t) ? W('Public web pages for the client', 'Pages that match the description, read at each check') : /contract|clause|agreement|report|plan/.test(t) ? D('Contracts and site documents', 'Documents that match the description, read by contract') : T('Operations data hub', 'The closest fields found for the description; shown for you to confirm')
  const id = `u${DESIGN.custom.length + 1}`
  const name = text.trim().replace(/\.$/, '').replace(/^(.)/, (m) => m.toUpperCase())
  const s: SignalDef = { id, f, name, rank: 99, added: true, why: 'You asked for it.', bands: bb, src, spec: S(false, false, 'Ongoing', 'Contract Risk Analyst'), moves: true, p: [70, 18, 8, 4], ...(only ? { only } : {}) }
  SIGNALS.push(s); DESIGN.custom.push(id); DESIGN.on[id] = true; DESIGN.sw[id] = 1
  delete SIG[id]
  for (const c of CONTRACTS) { if ((only === 'dw' && c.kind === 'Wastewater') || (only === 'ww' && c.kind === 'Drinking water')) { delete c.v[id]; continue } const u = hash(c.id + id), r = u < 0.7 ? 1 : u < 0.88 ? 2 : u < 0.96 ? 3 : 4; c.v[id] = { raw: s.bands[r - 1], r } }
  DESIGN.edits += 1
  return s
}
/** The scoring as it stands, to come back to: the design, and the signals and factors the person added. */
export interface SavedDesign { d: string; sig: SignalDef[]; fac: FactorDef[] }
export function saveDesign(): SavedDesign {
  return { d: JSON.stringify(DESIGN), sig: SIGNALS.filter((s) => DESIGN.custom.includes(s.id)).map((s) => ({ ...s })), fac: FACTORS.filter((f) => (DESIGN.customF ?? []).includes(f.id)).map((f) => ({ ...f })) }
}
export function restoreDesign(x: SavedDesign) {
  const d = JSON.parse(x.d) as Design
  for (const id of [...DESIGN.custom]) if (!d.custom.includes(id)) { const i = SIGNALS.findIndex((s) => s.id === id); if (i >= 0) SIGNALS.splice(i, 1) }
  for (const id of [...(DESIGN.customF ?? [])]) if (!(d.customF ?? []).includes(id)) { const i = FACTORS.findIndex((f) => f.id === id); if (i >= 0) FACTORS.splice(i, 1) }
  for (const f of x.fac) if (!FACTORS.some((y) => y.id === f.id)) FACTORS.push({ ...f })
  for (const sg of x.sig) { const i = SIGNALS.findIndex((y) => y.id === sg.id); if (i >= 0) SIGNALS[i] = { ...sg }; else SIGNALS.push({ ...sg }) }
  for (const k of Object.keys(DESIGN)) delete (DESIGN as unknown as Record<string, unknown>)[k]
  Object.assign(DESIGN, d)
  for (const k of Object.keys(SIG)) delete SIG[k]
}
export const decidesText = (c: Contract) => (c.evergreen ? 'Evergreen' : `${c.monthsLeft} months`)

/* ================================================================== version 3: sections A to F, where the data sits, the data check */
export type Section = 'A' | 'B' | 'C' | 'D' | 'E' | 'F'
export const SECTIONS: { k: Section; name: string; what: string; where: string }[] = [
  { k: 'A', name: 'What is at stake', what: 'How much a loss would matter and how soon: revenue, margin, months to renewal, how the contract can end. It sits beside the risk score as a second reading; it is not averaged into it.', where: 'A new reading beside the score' },
  { k: 'B', name: 'Financial Performance', what: 'How the contract is doing commercially. Money problems tend to show before the others.', where: 'A new factor in what we control' },
  { k: 'C', name: 'Client and Political Environment', what: 'The people and the politics on the client side, where most renewals are decided.', where: 'A new factor in what we do not control' },
  { k: 'D', name: 'Competitive Landscape', what: 'Who else wants this contract.', where: 'A new factor in what we do not control' },
  { k: 'E', name: 'Climate and Operational Resilience', what: 'Sudden events that no monthly figure predicts.', where: 'A new factor in what we do not control' },
  { k: 'F', name: 'Extra signals for factors you already have', what: 'Contract terms beyond the non-negotiable terms, site leadership, overflows, permits, asset condition, rules on the way.', where: 'Added inside existing factors' },
]
export const sectionOf = (s: SignalDef): Section | null => (!s.added || DESIGN.custom.includes(s.id) || DESIGN.customF.includes(s.f) ? null : s.f === 'im' ? 'A' : s.f === 'fp' ? 'B' : s.f === 'cp' ? 'C' : s.f === 'cl' ? 'D' : s.f === 'rs' ? 'E' : 'F')
export const sectionSignals = (k: Section) => SIGNALS.filter((s) => sectionOf(s) === k)
export const sectionOn = (k: Section) => sectionSignals(k).some((s) => DESIGN.on[s.id])

export type Level = 'project' | 'pc' | 'facility' | 'account' | 'region' | 'state' | 'contract'
export const LEVEL_NAME: Record<Level, string> = { project: 'Project', pc: 'Profit center', facility: 'Facility', account: 'Client account', region: 'Region', state: 'State', contract: 'Signed contract' }
const PC_SIGS = new Set(['cr2', 'st4', 'co4', 'co5', 'fp1', 'fp2', 'fp3', 'fp4', 'fp5', 'im1', 'im2'])
const FAC_SIGS = new Set(['en1', 'en2', 'en3', 'en4', 'en5', 'en6', 'in3', 'in4', 'in6', 'in7', 'iq1', 'iq2', 'iq3', 'iq4', 'iq5', 'iq6', 'iq7', 'co1', 'rs1', 'rs3', 'rs4', 'os1', 'os2', 'os3'])
export const levelOf = (s: SignalDef): Level => (PC_SIGS.has(s.id) ? 'pc' : FAC_SIGS.has(s.id) ? 'facility' : s.id === 'cu1' || s.id === 'cu3' ? 'account' : s.id === 'cu2' ? 'region' : s.id === 'sl1' || s.id === 'cr1' || s.id === 'iq8' ? 'state' : s.src.kind === 'document' ? 'contract' : 'project')
/** How a figure that does not sit at project level is brought to the project, in words, on the assumptions as they stand. */
export function toProject(s: SignalDef): string {
  const l = levelOf(s)
  if (l === 'pc') return DESIGN.assume.pc === 'inherit' ? 'Each project takes the figure of its profit center' : 'The profit center figure is split across its projects by revenue'
  if (l === 'facility') return DESIGN.assume.fac === 'worst' ? 'The project takes its worst facility' : 'The facilities of the project are added up'
  if (l === 'account') return `Matched to the project by client name; where a client answered more than once, the ${DESIGN.assume.nps} answer counts`
  if (l === 'region') return 'Every project in the region takes the regional figure'
  if (l === 'state') return 'Every project in the state takes the state figure'
  if (l === 'contract') return 'One signed contract per project'
  return 'Already at project level'
}
/* Profit centers and facilities, as the books and the plants have them. Fixed, not random at each load. */
{
  const byRegion: Record<string, string[]> = {}
  CONTRACTS.forEach((c, i) => {
    const u = hash(`pc${c.id}`), list = byRegion[c.region] ?? (byRegion[c.region] = [])
    c.pc = !c.hero && list.length && u < 0.36 ? list[Math.floor(hash(`pp${c.id}`) * list.length)] : `PC-${4100 + i}`
    if (!list.includes(c.pc)) list.push(c.pc)
    c.facilities = c.hero ? (c === ASHBY ? 2 : 1) : c.scopes.length >= 4 ? 3 : (c.scopes.length === 3 && hash(`f${c.id}`) < 0.55) || hash(`g${c.id}`) < 0.07 ? 2 : 1
  })
  const pickN = (salt: string, n: number) => CONTRACTS.filter((c) => !c.hero).sort((a, b) => hash(salt + a.id) - hash(salt + b.id)).slice(0, n)
  for (const c of pickN('negative-dso', 11)) { c.negDso = true; c.v.cr2 = { raw: `-${4 + Math.floor(hash(`n2${c.id}`) * 22)} days (credits exceed receivables)`, r: 2.5 } }
  /* The survey system holds answers by client account; 32 accounts could not be matched to a project by name. */
  for (const c of pickN('nps-unmatched', 32)) delete c.v.cu1
}
export function bookShape() {
  const pcs: Record<string, number> = {}
  for (const c of CONTRACTS) pcs[c.pc!] = (pcs[c.pc!] ?? 0) + 1
  const shared = Object.values(pcs).filter((n) => n > 1)
  return { pcs: Object.keys(pcs).length, sharedPcs: shared.length, inShared: shared.reduce((a, b) => a + b, 0), multiFac: CONTRACTS.filter((c) => (c.facilities ?? 1) > 1).length, facilities: CONTRACTS.reduce((n, c) => n + (c.facilities ?? 1), 0), negDso: CONTRACTS.filter((c) => c.negDso).length, npsMatched: CONTRACTS.filter((c) => c.v.cu1).length }
}
export type CheckStatus = 'ready' | 'assume' | 'partly' | 'missing'
export interface CheckRow { s: SignalDef; level: Level; how: string; n: number; of: number; status: CheckStatus; note: string }
/** The data check: every signal on the sheet against the connected data. */
export function dataCheck(): CheckRow[] {
  const B = bookShape()
  return SIGNALS.filter((s) => (DESIGN.on[s.id] || (!!NOT_FOUND[s.id] && !s.added)) && inTemplate(s)).map((s) => {
    const level = levelOf(s), cv = coverOf(s.id)
    let status: CheckStatus = 'ready', note = ''
    if (NOT_FOUND[s.id]) { status = 'missing'; note = NOT_FOUND[s.id] }
    else if (s.id === 'cu1') { status = 'partly'; note = `${B.npsMatched} of ${CONTRACTS.length} projects matched to a survey answer by client name. The rest have no score and the factor's other signals carry the weight.` }
    else if (s.id === 'co5') { status = 'partly'; note = 'Two years of community spend are loaded, not five. Scored on the two-year trend until the earlier years are connected.' }
    else if (s.id === 'cr2') { status = 'assume'; note = `Booked by profit center and month. ${B.negDso} projects sit in a profit center with negative DSO this month.` }
    else if (level === 'pc') { status = 'assume'; note = `Booked by profit center. ${B.sharedPcs} profit centers hold more than one project (${B.inShared} projects).` }
    else if (level === 'facility' && s.moves) { status = 'assume'; note = `Recorded by facility. ${B.multiFac} projects have more than one facility.` }
    else if (level === 'account') { status = 'assume'; note = 'Recorded by client account, not by project.' }
    return { s, level, how: toProject(s), n: status === 'missing' ? 0 : cv.n, of: cv.of, status, note }
  })
}
export const checkCounts = () => { const r = dataCheck(); return { all: r.length, ready: r.filter((x) => x.status === 'ready').length, assume: r.filter((x) => x.status === 'assume').length, partly: r.filter((x) => x.status === 'partly').length, missing: r.filter((x) => x.status === 'missing').length } }
/** The share of the final score a factor carries: its weight inside its half, and the halves count equally (or the higher one counts, if you chose that). */
export const finalShare = (fid: string) => factorShare(fid) * (DESIGN.rule === 'avg' ? 0.5 : 1)

/* ------------------------------------------------------------------ what a mitigation rests on: the site's own records */
const DAY = (seed: string, back = 40) => { const d = new Date(`${TODAY}T00:00:00Z`); d.setUTCDate(d.getUTCDate() - 2 - Math.floor(hash(seed) * back)); return `${d.getUTCDate()} ${['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][d.getUTCMonth()]}` }
const CROSS: Record<string, (c: Contract, k: string) => { kind: SrcKind; text: string }> = {
  gr: (c, k) => ({ kind: 'document', text: `${shortSite(c)} agreement, article ${11 + Math.floor(hash(k) * 6)}: the clause as signed in ${c.start.slice(0, 4)}` }),
  cr: (c, k) => ({ kind: 'mail', text: `${c.leader} to the client's finance officer, ${DAY(k)}: ${1 + Math.floor(hash(k + 'i') * 4)} invoices queried` }),
  os: (_c, k) => ({ kind: 'document', text: `Incident review of ${DAY(k, 90)}: the same task named in ${2 + Math.floor(hash(k + 't') * 2)} reports` }),
  en: (c, k) => ({ kind: 'mail', text: `${c.leader} to Compliance, ${DAY(k)}: the cause as the site sees it` }),
  st: (c, k) => ({ kind: 'mail', text: `${c.leader} to HR, ${DAY(k)}: ${hash(k + 'o') < 0.5 ? 'two offers declined on pay' : 'cover from the neighbouring site asked for'}` }),
  cu: (c, k) => ({ kind: 'mail', text: `Client mail to ${c.rvp}, ${DAY(k, 70)}: what they said was missing` }),
  co: (_c, k) => ({ kind: 'web', text: `Local news on the plant, ${DAY(k, 60)}, and the complaint log for the same weeks` }),
  li: (c, _k) => ({ kind: 'document', text: `${shortSite(c)} agreement: the liability and indemnity articles, and the claims procedure` }),
  in: (c, _k) => ({ kind: 'document', text: `Capital plan sent to ${c.client.replace(/^(City|Town) of /, 'the $1 of ')} in ${c.start.slice(0, 4) < '2020' ? '2024' : '2025'}: what was recommended and what was funded` }),
  iq: (c, _k) => ({ kind: 'web', text: `State rule register and the permit for ${shortSite(c)}: the limit and its date` }),
  fp: (c, _k) => ({ kind: 'document', text: `${shortSite(c)} agreement, fee adjustment and pass-through articles: what can be recovered` }),
  cp: (c, k) => ({ kind: 'web', text: `${c.client} agendas and minutes, last twelve months: ${1 + Math.floor(hash(k + 'm') * 4)} items that name the operator` }),
  cl: (c, _k) => ({ kind: 'web', text: `Award notices in ${STATE_NAME[c.state] ?? c.state}, last two years, and who presented to which board` }),
  rs: (c, _k) => ({ kind: 'document', text: `The emergency response plan and the last assessment on file for ${shortSite(c)}` }),
}
/** The records a mitigation for this signal at this site rests on: where the reading came from, and what else was read about it. */
export function basisOf(c: Contract, s: SignalDef, raw: string): { kind: SrcKind; text: string }[] {
  const k = `${c.id}${s.id}`
  return [{ kind: s.src.kind, text: `${s.src.name}: ${raw.replace(/^(.)/, (m) => m.toLowerCase())}` }, (CROSS[s.f] ?? CROSS.cr)(c, k)]
}
/** The average of each factor across the portfolio, for the web chart of a site. */
export const factorAverages = (when: When = 'now') => activeFactors().map((f) => { const xs = CONTRACTS.map((c) => factorScore(c, f.id, when)).filter((v): v is number => v !== null); return { f, avg: xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 1 } })
/** What a version of the dashboard showed, kept so that an older version can be opened later. */
export interface DashSnapshot { dist: number[]; n34: number; act: number; signals: number; factors: number; revenue34: number; top: { id: string; site: string; s: number; r: number }[] }
export function snapshotNow(when: When): DashSnapshot {
  const rows = CONTRACTS.map((c) => { const s = score(c, DESIGN.rule, when); return { c, s, r: ratingOf(s) } })
  const dist = [0, 0, 0, 0, 0]; rows.forEach((x) => { dist[x.r] += 1 })
  return { dist, n34: dist[3] + dist[4], act: CONTRACTS.filter((c) => priorityOf(c, when) === 'Act now').length, signals: likelihoodSignals().length, factors: activeFactors().length, revenue34: rows.filter((x) => x.r >= 3).reduce((n, x) => n + x.c.revenue, 0), top: rows.sort((a, b) => b.s - a.s).slice(0, 10).map((x) => ({ id: x.c.id, site: x.c.site, s: x.s, r: x.r })) }
}

export const TEMPLATE_FILE = 'Contract_Risk_Scorecard_Template.xlsx'
/** The assumptions the data check asks you to confirm. */
export const ASSUME_KEYS = (_d: Design) => ['score', 'pc', 'negdso', 'nps', 'fac', 'hist']

/* What the site's own records add to an action: one sentence, different from site to site, from the mail, the contract and what is public. */
const CTX: Record<string, string[]> = {
  gr: ['The clause was accepted in the {y} renewal to match a rival bid; the renewal file says so.', 'Legal flagged the same clause on {d}; the client has not replied.', 'The next amendment is due with the fee review, so the wording can be tabled then.'],
  cr: ['The client changed finance officer in {m}; the unpaid invoices date from the hand-over.', 'Two of the invoices are held over a disputed scope item raised on {d}.', '{leader} wrote on {d} that the purchase order for this year was issued late.'],
  os: ['Both incidents were on the night shift, which has run one operator short since {m}.', 'The task named in the reports is confined-space entry at the headworks.', 'The last site safety walk on file is from {m}.'],
  en: ['The exceedances follow wet weather; the equalisation basin has been out of service since {m}.', 'The lab changed on {d}; the gaps start that week.', '{leader} told Compliance on {d} that the cause is a failing blower, with a quote already in hand.'],
  st: ['The pay offered is under the rate the neighbouring county posted in {m}.', 'One of the open posts is the licence holder the contract requires.', 'Exit notes from {m} name weekend cover as the reason for leaving.'],
  cu: ['The client lead wrote on {d} that monthly reports arrive late and without the cost page.', 'Their mail of {d} asks for one named contact instead of three.', 'The last review meeting on file was in {m}.'],
  co: ['The complaints cluster on days the sludge trucks load.', 'A residents group raised it at the council meeting of {d}.', 'The local paper ran the story on {d} without a comment from us.'],
  li: ['The claim concerns a sewer backup in {m}; the agreement caps our liability at the annual fee.', 'Outside counsel was appointed on {d}; the insurer has been notified.', 'The same claimant settled a smaller claim in {y}.'],
  in: ['The client deferred the same capital item in its {y} budget.', 'Three of the overdue work orders are on the one standby pump.', 'The asset list handed over at the start did not include this equipment.'],
  iq: ['The state published the draft limit on {d}.', 'The upstream industrial discharger renewed its permit in {m} with a higher limit.', 'Sampling shows the rise began in {m}.'],
  fp: ['Chemical prices rose after the supplier contract lapsed in {m}; the agreement allows a pass-through above 10%.', 'Overtime to cover two open posts explains most of the overrun.', 'The fee has not been indexed since {y}; the clause allows it yearly.'],
  cp: ['The new lead comes from a utility that runs its own plants.', 'The item was put on the agenda by a member elected in {m}.', 'The client hired a procurement adviser on {d}.'],
  cl: ['The rival took the neighbouring contract in {m} at a lower fee.', 'Their bid there included a capital contribution; ours did not.', 'The client asked for a price benchmark on {d}.'],
  rs: ['The plant flooded in {y}; the generator pad is still at grade.', 'The last drill on file is from {m}.', 'The control system runs on an operating system out of support since {y}.'],
}
const MON = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October']
export function contextOf(c: Contract, s: SignalDef): string {
  const k = `${c.id}${s.id}`, list = CTX[s.f]; if (!list) return ''
  return list[Math.floor(hash(`x${k}`) * list.length)].replace('{d}', DAY(k)).replace('{m}', MON[Math.floor(hash(`m${k}`) * MON.length)]).replace('{y}', String(2021 + Math.floor(hash(`y${k}`) * 4))).replace('{leader}', c.leader)
}

/** A factor you add yourself. It counts once it has a signal. */
export function addCustomFactor(group: Group, name: string): FactorDef {
  const id = `uf${DESIGN.customF.length + 1}`
  const f: FactorDef = { id, group, name: name.trim().replace(/\.$/, '').replace(/^(.)/, (m) => m.toUpperCase()), weight: 10, blurb: 'Added by you.', added: true }
  FACTORS.push(f); DESIGN.customF.push(id); DESIGN.fw[id] = 10; DESIGN.edits += 1
  return f
}

/* ================================================================== version 8: your own template, and rules checked against your history */
/** With a template uploaded, only its signals (and the ones you add) are part of the scorecard. */
export const inTemplate = (s: SignalDef) => !DESIGN.tpl || DESIGN.tpl.includes(s.id) || DESIGN.custom.includes(s.id)

/** How your projects are spread on a figure, and what that says about the rule for 1 to 4. */
/** Rules that follow a regulatory or permit limit. History does not move them. */
export const REG_RULE = new Set(['iq1', 'iq2', 'iq3', 'iq4', 'iq5', 'iq6', 'iq7'])
export interface Hist { reg: boolean; n: number; bins: { x0: number; x1: number; n: number; band: number }[]; shares: number[]; cur: number[]; rec: number[]; flagged: boolean; top: number; median: number; lo: number; hi: number; unit: string; up: boolean }
const niceStep = (span: number) => (span > 4000 ? 500 : span > 400 ? 50 : span > 60 ? 5 : span > 12 ? 1 : span > 3 ? 0.5 : 0.1)
export function histOf(s: SignalDef, written = false): Hist | null {
  if (!s.num) return null
  const vals = CONTRACTS.map((c) => c.v[s.id]).filter(Boolean).map((rd) => numOf(rd.raw)).filter((x) => Number.isFinite(x)).sort((a, b) => a - b)
  if (vals.length < 30) return null
  const up = s.num.dir === 'up', cur = (written ? s.num.cuts : DESIGN.cuts[s.id] ?? s.num.cuts).slice()
  const bandAt = (x: number, cuts: number[]) => 1 + cuts.filter((c) => (up ? x >= c : x < c)).length
  const lo = vals[0], hi = vals[vals.length - 1], span = hi - lo || 1, st = vals.every((x) => Number.isInteger(x)) ? Math.max(1, niceStep(span)) : niceStep(span)
  const q = (p: number) => vals[Math.min(vals.length - 1, Math.max(0, Math.round(p * (vals.length - 1))))]
  const rnd = (x: number) => Math.round(Math.round(x / st) * st * 100) / 100
  /* from the history: the better half scores 1, the next 30% score 2, the next 15% score 3, the worst 5% score 4 */
  let rec = (up ? [q(0.5), q(0.8), q(0.95)] : [q(0.5), q(0.2), q(0.05)]).map(rnd)
  /* where the better half sits on the floor (most projects at zero), the first cut stays as written */
  if (up ? rec[0] <= lo : rec[0] >= hi) rec[0] = cur[0]
  if (up) { for (let i = 1; i < 3; i += 1) if (rec[i] <= rec[i - 1]) rec[i] = rnd(rec[i - 1] + st) }
  else { if (rec[2] <= lo) rec[2] = rnd(lo + st); if (rec[1] <= rec[2]) rec[1] = rnd(rec[2] + st); if (rec[0] <= rec[1]) rec[0] = rnd(rec[1] + st) }
  if (rec.some((x) => !Number.isFinite(x))) rec = cur.slice()
  const counts = [0, 0, 0, 0]; for (const x of vals) counts[bandAt(x, cur) - 1] += 1
  const shares = counts.map((n) => n / vals.length), top = Math.max(...shares)
  const N = 18, w = span / N, bins = Array.from({ length: N }, (_, i) => ({ x0: lo + i * w, x1: lo + (i + 1) * w, n: 0, band: bandAt(lo + (i + 0.5) * w, cur) }))
  for (const x of vals) bins[Math.min(N - 1, Math.floor((x - lo) / w))].n += 1
  const med = q(0.5), reg = REG_RULE.has(s.id)
  return { reg, n: vals.length, bins, shares, cur, rec, flagged: !reg && top >= 0.6 && (up ? med > lo : med < hi) && rec.some((x, i) => x !== cur[i]), top, median: med, lo, hi, unit: s.num.unit, up }
}
/** The figures whose written rule puts most projects in one score, so it separates little. Judged on the rule as written. */
export const histFlagged = () => SIGNALS.filter((s) => s.num && DESIGN.on[s.id] && inTemplate(s) && s.f !== 'im' && !DESIGN.text[s.id] && (DESIGN.histOn.includes(s.id) || (!DESIGN.cuts[s.id] && histOf(s, true)?.flagged)))
export const numericSignals = () => SIGNALS.filter((s) => s.num && DESIGN.on[s.id] && inTemplate(s))
/** Take the thresholds from history for the flagged figures, or go back to the rule as written. */
export function applyHist(on: boolean) {
  const list = histFlagged()
  for (const s of list) { if (on) { DESIGN.cuts[s.id] = histOf(s, true)!.rec } else delete DESIGN.cuts[s.id] }
  DESIGN.histOn = on ? list.map((s) => s.id) : []
  DESIGN.assume.hist = on ? 'hist' : 'keep'; DESIGN.edits += 1
}
/** One figure's thresholds from its history. */
export function useHist(sid: string) { const s = SIGNALS.find((x) => x.id === sid)!, h = histOf(s, true); if (!h) return; DESIGN.cuts[sid] = h.rec.slice(); if (!DESIGN.histOn.includes(sid)) DESIGN.histOn.push(sid); DESIGN.edits += 1 }

/** One line of a scoring template: a signal in its factor, with weights and the rule for 1 to 4. */
export interface TplRow { group: string; factor: string; fw: number | null; signal: string; sw: number | null; b: string[]; how: string; flag: boolean }
export const GROUP_NAME: Record<Group, string> = { internal: 'What we control', external: 'What we do not control', impact: 'What is at stake' }
/** The whole framework as a template: every factor and signal, weights as percentages, the rule for 1 to 4 written out. */
export function templateRows(): TplRow[] {
  const out: TplRow[] = []
  for (const g of ['internal', 'external', 'impact'] as Group[]) {
    const fs = FACTORS.filter((f) => f.group === g && !DESIGN.customF.includes(f.id)), tot = fs.reduce((n, f) => n + f.weight, 0)
    for (const f of fs) {
      const ss = SIGNALS.filter((x) => x.f === f.id && !DESIGN.custom.includes(x.id)).sort((a, b) => a.rank - b.rank), live = ss.filter((x) => !NOT_FOUND[x.id]), sum = (live.length * (live.length + 1)) / 2
      ss.forEach((x) => { const i = live.indexOf(x); out.push({ group: GROUP_NAME[g], factor: f.name, fw: g === 'impact' ? null : Math.round((f.weight / tot) * 1000) / 10, signal: x.name, sw: i < 0 ? 0 : Math.round(((live.length - i) / sum) * 1000) / 10, b: x.bands.slice(), how: x.src.how, flag: x.id === 'li3' || x.id === 'cp3' }) })
    }
  }
  return out
}
const nrm = (x: string) => x.toLowerCase().replace(/[^a-z0-9% ]+/g, ' ').replace(/\s+/g, ' ').trim()
export interface TplResult { factors: number; signals: number; noSource: string[]; fresh: string[]; freshF: string[]; rules: number; flags: number }
/** Use an uploaded template exactly as written: its factors, its signals, its weights, its rules. Nothing is added to it. */
export function applyTemplate(rows: TplRow[]): TplResult {
  resetDesign('proposed'); DESIGN.source = 'uploaded'; DESIGN.flag = {}
  const seen: string[] = [], fresh: string[] = [], freshF: string[] = [], fwSet: Record<string, number> = {}, swSet: Record<string, number> = {}
  let rules = 0, flags = 0
  const grp = (t: string): Group => (/stake|impact/i.test(t) ? 'impact' : /not|external|outside/i.test(t) ? 'external' : 'internal')
  for (const r of rows) {
    if (!r.signal.trim() || !r.factor.trim()) continue
    let f = FACTORS.find((x) => nrm(x.name) === nrm(r.factor)) ?? FACTORS.find((x) => nrm(x.name).includes(nrm(r.factor)) || nrm(r.factor).includes(nrm(x.name)))
    if (!f) { const g = grp(r.group); f = addCustomFactor(g === 'impact' ? 'external' : g, r.factor); freshF.push(f.name) }
    if (r.fw !== null && fwSet[f.id] === undefined) fwSet[f.id] = r.fw
    const sig = SIGNALS.find((x) => x.f === f!.id && nrm(x.name) === nrm(r.signal)) ?? SIGNALS.find((x) => nrm(x.name) === nrm(r.signal))
    if (!sig) { const n = addCustomSignal(r.signal, f.id, r.b); fresh.push(n.name); if (r.sw !== null) swSet[n.id] = r.sw; if (r.flag) { DESIGN.flag[n.id] = true; flags += 1 } continue }
    seen.push(sig.id)
    /* a case is an edit only where it differs from the rule I know; the other cases follow a moved threshold by themselves */
    const orig = bandsOf(sig)
    r.b.forEach((t, i) => { if (t.trim() && nrm(t) !== nrm(orig[i] ?? '')) { setBandText(sig.id, i + 1, t); rules += 1 } })
    if (r.sw !== null) swSet[sig.id] = r.sw
    if (r.flag) { DESIGN.flag[sig.id] = true; flags += 1 }
  }
  for (const x of SIGNALS) if (!DESIGN.custom.includes(x.id)) DESIGN.on[x.id] = seen.includes(x.id) && !NOT_FOUND[x.id]
  rankWeights()
  for (const [fid, w] of Object.entries(fwSet)) if (w > 0) DESIGN.fw[fid] = w
  for (const f of FACTORS) { const ss = SIGNALS.filter((x) => x.f === f.id && DESIGN.on[x.id]); if (!ss.length || !ss.some((x) => swSet[x.id] !== undefined)) continue; const sum = (ss.length * (ss.length + 1)) / 2, tot = ss.reduce((n, x) => n + (swSet[x.id] ?? 0), 0) || 1; for (const x of ss) DESIGN.sw[x.id] = Math.max(0.25, Math.round(((swSet[x.id] ?? 0) / tot) * sum * 100) / 100) }
  DESIGN.tpl = seen; DESIGN.size = seen.some((id) => SIGNALS.find((x) => x.id === id)!.f === 'im') ? 'beside' : 'none'
  DESIGN.edits = 0
  return { factors: activeFactors().length, signals: seen.length + fresh.length, noSource: seen.filter((id) => NOT_FOUND[id]).map((id) => SIGNALS.find((x) => x.id === id)!.name), fresh, freshF, rules, flags }
}

/** Back to the rule as written: thresholds and wording. */
export function ruleAsWritten(sid: string) { delete DESIGN.cuts[sid]; delete DESIGN.text[sid]; DESIGN.histOn = DESIGN.histOn.filter((x) => x !== sid); DESIGN.edits += 1 }
