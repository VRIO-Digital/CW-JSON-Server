/*
 * How fast the agents appear to work. The demo paces each step like an agent at work (about ten seconds
 * for a step that reads and reasons, about a second for each part of a deliverable being built), so a run
 * reads as work being done, not as text appearing at once. Add ?pace=0.05 before the # to the file's
 * address to run everything twenty times faster (the click tests do).
 */
export const PACE: number = (() => {
  try {
    const q = new URLSearchParams(window.location.search).get('pace')
    const n = q ? Number(q) : NaN
    return Number.isFinite(n) && n > 0 ? n : 1
  } catch { return 1 }
})()
/** A demo delay in milliseconds, scaled by the pace. */
export const P = (ms: number) => Math.max(1, Math.round(ms * PACE))

/*
 * The clock the prototype shows. Normally the real one. With ?clock=2026-11-03T14:00:00Z it starts there and runs at the
 * demo's pace, so a recording made at ?pace=0.05 carries the times a real-speed demo would show (the data package is
 * recorded this way).
 */
const CLOCK0: number | null = (() => {
  try {
    const q = new URLSearchParams(window.location.search).get('clock')
    const t = q ? Date.parse(q) : NaN
    return Number.isFinite(t) ? t : null
  } catch { return null }
})()
const REAL0 = Date.now()
export const now = (): Date => (CLOCK0 === null ? new Date() : new Date(CLOCK0 + (Date.now() - REAL0) / PACE))
