/*
 * Turn a piece of the page into a PNG without any library: clone the node, copy the computed styles that
 * matter onto each element, wrap the clone in an SVG foreignObject, draw it on a canvas and save it.
 * Works in Chromium and Firefox for same-origin content; inline SVG charts come along as they are.
 */
const PROPS = ['display', 'position', 'flex', 'flex-direction', 'flex-wrap', 'justify-content', 'align-items', 'gap', 'grid-template-columns', 'box-sizing', 'width', 'min-width', 'max-width',
  'margin', 'padding', 'border', 'border-radius', 'background', 'background-color', 'color', 'font', 'font-size', 'font-weight', 'font-family', 'line-height', 'letter-spacing', 'text-transform', 'text-align',
  'white-space', 'word-break', 'overflow', 'opacity', 'box-shadow', 'vertical-align', 'list-style', 'border-collapse', 'border-spacing', 'text-decoration']

const inlineStyles = (src: Element, dst: Element) => {
  const cs = window.getComputedStyle(src)
  const style = (dst as HTMLElement).style
  if (style) for (const p of PROPS) style.setProperty(p, cs.getPropertyValue(p))
  const sc = src.children, dc = dst.children
  for (let i = 0; i < sc.length && i < dc.length; i++) inlineStyles(sc[i], dc[i])
}

export async function nodeToPng(node: HTMLElement, fileName: string, scale = 2): Promise<void> {
  const rect = node.getBoundingClientRect()
  const w = Math.ceil(rect.width), h = Math.ceil(node.scrollHeight)
  const clone = node.cloneNode(true) as HTMLElement
  inlineStyles(node, clone)
  clone.style.width = `${w}px`
  clone.style.height = 'auto'
  clone.style.margin = '0'
  clone.querySelectorAll('button, .no-print').forEach((el) => el.remove())
  const xhtml = new XMLSerializer().serializeToString(clone).replace(/<br>/g, '<br/>')
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml" style="background:#fff">${xhtml}</div></foreignObject></svg>`
  /* A data URL, not a blob URL: from a file opened on disk a blob image counts as another origin and taints the canvas. */
  const url = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`
  try {
    const img = new Image()
    await new Promise<void>((res, rej) => { img.onload = () => res(); img.onerror = () => rej(new Error('render')); img.src = url })
    const canvas = document.createElement('canvas')
    canvas.width = w * scale; canvas.height = h * scale
    const ctx = canvas.getContext('2d')!
    ctx.scale(scale, scale)
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, w, h)
    ctx.drawImage(img, 0, 0)
    const blob: Blob | null = await new Promise((res) => canvas.toBlob(res, 'image/png'))
    if (!blob) throw new Error('blob')
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob); a.download = fileName; a.click()
    setTimeout(() => URL.revokeObjectURL(a.href), 2000)
  } finally {
    /* nothing to revoke for a data URL */
  }
}

/** Print only the given node; the browser's print dialog saves it as PDF. */
export function printNode(node: HTMLElement): void {
  node.classList.add('sb-print-target')
  document.body.classList.add('sb-printing')
  const done = () => { node.classList.remove('sb-print-target'); document.body.classList.remove('sb-printing'); window.removeEventListener('afterprint', done) }
  window.addEventListener('afterprint', done)
  window.setTimeout(() => { window.print(); window.setTimeout(done, 500) }, 50)
  window.setTimeout(done, 60000)
}
