/*
 * Goals: the two Northline Contract Operations cases the prototype opens with (Contract Risk Analyst):
 * a standing goal that watches the risk of all 300 operations and maintenance contracts on the
 * company's own scorecard, and a one-off review of the renewals that decide in the next 18 months.
 *
 * A goal is what the business wants to know or achieve. A named agent pursues it: it proposes an
 * approach for the analyst to review, runs it over the published graph and the connected data, shows
 * its actions as it goes, and brings back findings that drill to the row and three recommendations,
 * each with the story of how it was reached. Every figure here is one `risk.ts` computes or
 * `riskDocs.ts` holds. Northline, its clients and every figure are invented; the state liability
 * ranking is the public 2026 edition.
 */
import { ASHBY, HARLOW, LOST, PEOPLE, REDMESA, f1, groupScore, m1, renewals } from './risk'

export type Trigger = 'person' | 'schedule' | 'rule'
export type GoalStatus = 'plan-review' | 'armed' | 'fired' | 'analysing' | 'needs-input' | 'findings-ready' | 'accepted'
export type EvidenceKind = 'table' | 'document' | 'mail' | 'web' | 'assumption'

export interface Target {
  measure: string
  target: string
  current: string
  tolerance: string
  deadline: string
  decision: string
}

export interface PlanStep {
  id: string
  title: string
  how: string
  sources: string[]
  check: string
  state: 'done' | 'running' | 'pending' | 'removed'
  editedBy?: string
  /** What the agent does inside the step, as tool calls: "tool target → result". Shown in the agent log. */
  actions?: string[]
  /** The actions shown so far (filled while the step runs). */
  trace?: string[]
}

export interface Drill {
  view: 'portfolio' | 'project' | 'monthly' | 'changes' | 'ledger' | 'snapshots' | 'orders' | 'documents' | 'mail' | 'ratebase' | 'additions' | 'procure' | 'scorecard' | 'contract' | 'actions' | 'renewals' | 'web' | 'signals'
  project?: string
  /** A contract of the risk portfolio, by id. */
  contract?: string
  doc?: string
  thread?: string
  note: string
}

export interface Evidence {
  kind: EvidenceKind
  text: string
  source: string
  asOf?: string
  ref?: { doc?: string; thread?: string; sheet?: Drill['view']; project?: string; contract?: string }
}

export interface Finding {
  id: string
  headline: string
  detail: string
  evidence: Evidence[]
  drill: Drill
}

/** One beat of the story behind a recommendation: what was asked, what was read, what was found, what follows. */
export interface Beat {
  kind: 'asked' | 'read' | 'found' | 'compared' | 'therefore'
  text: string
  figure?: string
  ref?: Evidence['ref']
}

export interface Recommendation {
  id: string
  title: string
  summary: string
  figures: { label: string; value: string; tone?: 'good' | 'warn' | 'crit' }[]
  tradeoff: string
  preferred?: boolean
  story: Beat[]
}

export interface LogEntry {
  at: string
  who: string
  what: string
}

/** A submission the agent recommends from a goal. It always rests on a template that exists in the library
 *  (`templateId`); a recommendation whose template is not in the library is not shown. */
export interface SubmissionSuggestion {
  id: string
  label: string
  audience: string
  purpose: string
  template: string
  templateId: string
  why: string
}

export interface Agent {
  name: string
  icon: string
  colour: string
}

/** The agents a goal can be given, in order of assignment. Named like colleagues, not like versions. */
export const AGENT_POOL: Agent[] = [
  { name: 'Agent Ledger', icon: 'radar', colour: '#9e3819' },
  { name: 'Agent Compass', icon: 'compass', colour: '#0f5c7b' },
  { name: 'Agent Beacon', icon: 'bulb', colour: '#8a5a00' },
  { name: 'Agent Keel', icon: 'rocket', colour: '#6b3fa0' },
  { name: 'Agent Sentinel', icon: 'experiment', colour: '#3b6e22' },
  { name: 'Agent Harbour', icon: 'thunder', colour: '#1f4e9c' },
]

export interface Goal {
  id: string
  title: string
  agent: Agent
  goal: string
  target: Target
  trigger: Trigger
  triggerDetail: string
  status: GoalStatus
  owner: string
  ownerRole: string
  startedAt: string
  scope: string[]
  constraints: string[]
  plan: PlanStep[]
  planApproved?: { by: string; at: string }
  question?: string
  findings: Finding[]
  gaps: string[]
  recommendations: Recommendation[]
  submissions: SubmissionSuggestion[]
  log: LogEntry[]
  askRefs: string[]
  approachName?: string
  /** Findings the analyst has accepted, by id. */
  acceptedFindings?: string[]
  /** Files the analyst gave the goal in the chat (read in the browser). */
  files?: { name: string; size: number; read: string; problem?: string }[]
  exampleOf?: string
}

export const TRIGGER_LABEL: Record<Trigger, string> = {
  person: 'Started by a person',
  schedule: 'Runs on a schedule',
  rule: 'Fired by a rule',
}

export const STATUS_LABEL: Record<GoalStatus, string> = {
  'plan-review': 'Approach for your review',
  armed: 'Armed, waiting for the trigger',
  fired: 'Rule fired · draft',
  analysing: 'Analysing',
  'needs-input': 'Needs your input',
  'findings-ready': 'Findings ready',
  accepted: 'Recommendation accepted',
}

/* ------------------------------------------------------------------ the two example goals */

export const ONCE_ID = 'g-renewal-review'
export const WATCH_ID = 'g-contract-risk-watch'

const hi = f1(groupScore(HARLOW, 'internal', 'before')), hi2 = f1(groupScore(HARLOW, 'internal', 'after'))
const he = f1(groupScore(HARLOW, 'external', 'before')), he2 = f1(groupScore(HARLOW, 'external', 'after'))
const ri = f1(groupScore(REDMESA, 'internal', 'before')), ri2 = f1(groupScore(REDMESA, 'internal', 'after'))

/* ------------------------------------------------------------------ approaches */

export const PROC_PLAN: PlanStep[] = [
  { id: 's1', title: 'Re-score what changed since the last check', how: 'Every signal of every contract read again from its source; the bands of the scorecard applied; the contracts whose readings changed listed with the old and the new rating.', sources: ['Operations data hub', 'Contracts and client documents', 'Legal notices and operations mail', 'Public web'], check: 'Every rating recomputes from its signals, bands, ranks and factor weights.', state: 'done', actions: ['read 11,973 readings across 300 contracts → 4 readings changed on 3 contracts.', `recompute NCO-047 Harlow Creek → internal ${hi} to ${hi2}, external ${he} to ${he2}: rating 2 to 3.`, 'check → each rating recomputes. Passed.'] },
  { id: 's2', title: 'Read the evidence behind each change', how: 'The message, document, row or page that changed each reading, and what the contract says about it.', sources: ['Legal notices mailbox', 'Complaint log', 'The signed contract', 'Local news'], check: 'Every change points at a dated source.', state: 'done', actions: ['read_mail legal-notices thread H1 → demand letter of 19 November for 23 residents.', 'read_document Harlow_Creek_OM_Agreement_2018.pdf → sections 9.4, 14, 16.3, 21.1.', 'check → every change has a dated source. Passed.'] },
  { id: 's3', title: 'Look for what comes before a rating moves', how: 'Combinations of signals that came before a notice of violation or a lost renewal in the last three years, and signs the scorecard has no signal for.', sources: ['hr.requisition', 'ops.labor_weekly', 'plantdata.sample_schedule', 'Council agendas'], check: 'A pattern is named only with the history that supports it.', state: 'done', actions: ['match staffing pattern → NCO-184 Red Mesa shows all three signals; 5 of 7 sites with a notice since 2024 did.', 'read_web Ashby Falls Select Board agenda → in-house operation listed for 2 December.'] },
  { id: 's4', title: 'Say what to do about each contract, including nothing', how: 'A plan written for the site: the action, the owner, the date, and what must wait for Legal or for your OK.', sources: ['Steps 1 to 3', 'Mitigation matrix', 'Claims notice and legal hold procedure'], check: 'Every action has an owner and a date, and names the signal it answers.', state: 'done', actions: ['compose → act on all three; act on Harlow Creek only; hold for the 2 December review.'] },
  { id: 's5', title: 'Build the deliverables, act and tell you', how: 'The scorecard refreshed, a deck for each contract that moved up, the actions opened in the tracker, and a note to the people who own the contract.', sources: ['Steps 1 to 4', 'Template: contract risk brief'], check: 'Every figure links back to its step.', state: 'done', actions: ['compose brief → 6 sections.', 'send → the Regional VP, the project leader and Legal.'] },
]

export const RB_PLAN: PlanStep[] = [
  { id: 's1', title: 'Rate the contracts that decide in the next 18 months', how: 'Contracts whose term ends in the next 18 months, and evergreen contracts the client can end on notice; each with its rating on the scorecard.', sources: ['master.contract', 'The signed contracts', 'Scorecard'], check: 'Every contract in the set has an end date read from its agreement.', state: 'done', actions: ['read_table master.contract → end dates and renewal options for 300 contracts.'] },
  { id: 's2', title: 'Read the client side of each one', how: 'Who decides and what has changed: a new client lead, a procurement adviser, in-house operation on an agenda, a competitor presenting, a price review.', sources: ['Council agendas and minutes', 'Operations mail', 'crm.nps_response', 'Local news'], check: 'Every sign points at a dated source.', state: 'done', actions: ['read_web council agendas for the set → signs on the client side listed by contract.'] },
  { id: 's3', title: 'Size what is at stake', how: 'Annual revenue and margin of each contract, by region and by rating.', sources: ['fin.contract_pnl', 'master.contract'], check: 'Revenue sums to the contract ledger.', state: 'done', actions: ['sum fin.contract_pnl for the set → revenue and margin by contract.'] },
  { id: 's4', title: 'Test the scorecard against the renewals we lost', how: 'The three renewals lost since 2024, rated as the scorecard would have rated them twelve months before, and what moved in that year.', sources: ['Calder Valley loss review', 'Scorecard history', 'Council agendas'], check: 'Each loss has its rating a year before and the dated changes.', state: 'done', actions: ['recompute the three lost contracts twelve months before → two rated 2, one rated 3.'] },
  { id: 's5', title: 'Recommend which to act on, and how', how: 'Which contracts go on a renewal plan now, which are watched, and what each plan starts with.', sources: ['Steps 1 to 4'], check: 'The recommendation names its caveats and the alternatives it rejected.', state: 'done', actions: ['select → renewal plans for the contracts rated 3 or 4 and for the quiet ones with client-side signs.'] },
  { id: 's6', title: 'Build the deliverables you chose', how: 'The review pack on last year\'s structure, a renewal plan for the contract most at risk, and a brief per region.', sources: ['Steps 1 to 5', 'Template: renewal review, December 2025'], check: 'Every figure links back to its step.', state: 'done', actions: ['compose pack from the 2025 structure → 5 sections.'] },
]

/* ------------------------------------------------------------------ goals */

const rn = renewals('max', true)
const lost2 = LOST.filter((l) => l.rated <= 2)

export const GOALS: Goal[] = [
  {
    id: WATCH_ID,
    title: 'Morning check, 20 November: Harlow Creek moves from 2 to 3, two more to watch',
    agent: AGENT_POOL[0],
    goal: 'Monitor the risk of every contract in the portfolio on a scorecard built with you: what to measure, how to score it and how much each thing counts. Read every source each morning, and when the risk of a contract goes up say why, with the evidence, and what to do at that site.',
    target: {
      measure: 'Risk rating of every contract on the scorecard you agreed',
      target: 'No contract moves to 3 or 4 without its owner knowing the same morning, with a plan',
      current: 'Harlow Creek WWTP moved from 2 to 3 overnight; Red Mesa and Ashby Falls changed without moving a rating',
      tolerance: 'Fires when a contract changes rating, a factor moves a full point, or a sign appears that the scorecard has no signal for',
      deadline: 'The demand letter asks for a response within 30 days, by 19 December',
      decision: 'What to do about each contract that changed, and who does it',
    },
    trigger: 'rule',
    triggerDetail: 'Rule "A contract\'s risk changes", checked every morning at 06:00 across the operations data, the drive, the mailboxes and the public web. On 20 November it found three contracts changed since the check of 19 November.',
    status: 'armed',
    owner: PEOPLE.owner,
    ownerRole: PEOPLE.ownerRole,
    startedAt: '2026-11-20T06:00:00Z',
    scope: [
      'All 300 contracts in five regions: 11,973 signal readings',
      'The scorecard agreed at set-up: factors, signals, bands, weights and red flags',
      'Operations data, contracts and client documents, the legal notices and operations mailboxes, local news, council agendas and the state liability ranking',
    ],
    constraints: [
      'The scorecard is yours; nothing in it changes unless you change it',
      'A rating read from a contract clause is a draft until Legal confirms it',
      'After a written demand, contact with claimants about the matter goes through Legal',
      'Nothing goes outside the company without your OK',
    ],
    plan: PROC_PLAN,
    planApproved: { by: PEOPLE.owner, at: '2026-11-12T15:10:00Z' },
    findings: [
      {
        id: 'f1',
        headline: 'Overnight, 3 of the 300 contracts changed and one moved a rating: Harlow Creek WWTP in Georgia, from 2 to 3.',
        detail: `All 11,973 readings were read again at 06:00. Four changed, on three contracts. Harlow Creek was the contract closest to the line: its internal score went from ${hi} to ${hi2} and its external score from ${he} to ${he2}, so it now rates 3, medium to high. Red Mesa in Arizona and Ashby Falls in Massachusetts changed without moving a rating. The other 297 contracts stand where they stood.`,
        evidence: [
          { kind: 'table', text: 'The scorecard before and after the 06:00 check: 300 contracts, 4 readings changed', source: 'Scorecard · all contracts', asOf: '2026-11-20', ref: { sheet: 'scorecard' } },
          { kind: 'table', text: 'The bands and weights applied are those agreed on the plan', source: 'Scorecard design', asOf: '2026-11-19', ref: { sheet: 'signals' } },
        ],
        drill: { view: 'scorecard', note: 'The three contracts that changed are at the top.' },
      },
      {
        id: 'f2',
        headline: 'Harlow Creek: a demand letter for 23 residents arrived at 16:42 and a sixth odor complaint was logged the same evening.',
        detail: 'Threatened litigation goes from 2 to 4 (a demand letter is the top band) and Odor complaints from 3 to 4 (more than five in a year). The letter asks for abatement, the odor records since January 2024 and talks on compensation within 30 days, and names the City too. Five of the six complaints fall on biosolids load-out afternoons and two were never called back. The setting makes it worse: Georgia rates 4 on the state ranking (rank 46 of 50) and 11,420 homes sit within 2 miles. The contract caps liability at the annual fee but has no waiver of consequential damages.',
        evidence: [
          { kind: 'mail', text: 'Baines & Ortega LLP, 19 November 16:42: notice of claim and demand, copied to the City Attorney', source: 'Thread H1, legal notices mailbox', asOf: '2026-11-19', ref: { thread: 'H1' } },
          { kind: 'document', text: 'Complaint log: six this year, five on load-out afternoons, two not called back', source: 'Harlow_Creek_Odor_Complaint_Log_2026.xlsx', asOf: '2026-11-19', ref: { doc: 'DOC:hc-complaints' } },
          { kind: 'document', text: 'Agreement: liability capped at the annual fee (14.1); no waiver of consequential damages; odor control capital is the City\'s (9.4)', source: 'Harlow_Creek_OM_Agreement_2018.pdf', asOf: '2018-06-12', ref: { doc: 'DOC:hc-contract' } },
          { kind: 'web', text: 'Georgia ranks 46 of 50 on liability cost, 2026 edition', source: 'richstatespoorstates.org', asOf: '2026-11-20', ref: { doc: 'WEB:state-rank' } },
        ],
        drill: { view: 'contract', contract: 'NCO-047', note: 'Harlow Creek signal by signal; the two that moved are marked.' },
      },
      {
        id: 'f3',
        headline: 'Red Mesa still rates 2, but it now shows the pattern that came before five of the last seven notices of violation.',
        detail: `A second missed sample this quarter was recorded on 19 November, so Missed samples goes from 2 to 3 and the internal score from ${ri} to ${ri2}. On its own that moves nothing. Together with two operator posts open more than 60 days and overtime at 14.2% of payroll it is the combination five of the seven sites with a notice of violation since 2024 showed 8 to 12 weeks before. Both missed samples fell on weekend shifts covered on overtime by the one operator who holds the licence the contract requires.`,
        evidence: [
          { kind: 'document', text: 'Sampling exceptions: 12 September and 15 November, both on a weekend overtime shift', source: 'Red_Mesa_Sampling_Plan_and_Exceptions_2026.pdf', asOf: '2026-11-19', ref: { doc: 'DOC:rm-sampling' } },
          { kind: 'mail', text: 'Project leader, 19 November: second missed sample; both posts still open; two offers declined', source: 'Thread R1, Missed TSS composite', asOf: '2026-11-19', ref: { thread: 'R1' } },
          { kind: 'table', text: 'Open requisitions, overtime share and missed samples for every site since 2024, against notices of violation', source: 'hr.requisition · ops.labor_weekly · plantdata.sample_schedule', asOf: '2026-11-20', ref: { sheet: 'contract', contract: 'NCO-184' } },
        ],
        drill: { view: 'contract', contract: 'NCO-184', note: 'Red Mesa signal by signal; the staffing factor and the missed sample are marked.' },
      },
      {
        id: 'f4',
        headline: 'Ashby Falls does not move on the scorecard, and it is the contract most likely to be lost: $7.4M a year, ending in seven months.',
        detail: 'The Select Board agenda posted on 19 November lists "Water and sewer operations after June 2027: options including in-house operation" for 2 December, with a vote to hire a procurement adviser. The DPW Director changed in August; the NPS of 8 on file was given by her predecessor. The agreement ends 30 June 2027 with no renewal option left, and a competitor presented to the Finance Committee in October. None of this is a signal on the scorecard, so the rating stays 2. It is the same sequence as Calder Valley in 2025.',
        evidence: [
          { kind: 'web', text: 'Select Board agenda for 2 December, item 6a and 6b, posted 19 November', source: 'Town of Ashby Falls', asOf: '2026-11-19', ref: { doc: 'WEB:af-agenda' } },
          { kind: 'mail', text: 'Project leader, 19 August: new DPW Director, from a district that runs its own plants', source: 'Thread A1, Introductions', asOf: '2026-08-19', ref: { thread: 'A1' } },
          { kind: 'document', text: 'Agreement section 2.2: the one renewal option was used in 2022; ends 30 June 2027', source: 'Ashby_Falls_OM_Agreement_2017.pdf', asOf: '2017-05-30', ref: { doc: 'DOC:af-contract' } },
          { kind: 'document', text: 'Calder Valley: new client lead, adviser hired, stale NPS, competitor presenting, then lost at re-bid', source: 'Calder_Valley_Loss_Review_2026-03.pdf', asOf: '2026-03-12', ref: { doc: 'DOC:calder-review' } },
        ],
        drill: { view: 'contract', contract: 'NCO-111', note: 'Ashby Falls: the scorecard, and beside it what the scorecard has no signal for.' },
      },
    ],
    gaps: [
      'Whether the City of Harlow Creek received the same letter and how it will respond; the City Attorney was copied.',
      'Legal has not yet confirmed the non-negotiable terms reading of the Harlow Creek agreement (no waiver of consequential damages).',
      'The NPS of the new Ashby Falls DPW Director is not known; the score on file is her predecessor\'s.',
    ],
    recommendations: [
      {
        id: 'r1',
        title: 'Run the full plan at every contract that rose: an odor plan at Harlow Creek, a renewal plan at Ashby Falls, cover at Red Mesa',
        summary: 'Harlow Creek: an odor source survey, load-out moved to mornings, the complaint calls returned and the Regional VP in front of the City Manager before the 8 December council. Ashby Falls: the Regional VP meets the new DPW Director before 2 December and the renewal plan starts now. Red Mesa: both posts covered from the West float pool on Monday and the sampling schedule given a second owner.',
        figures: [
          { label: 'Contracts acted on', value: '3 of 300' },
          { label: 'Revenue they carry', value: m1(HARLOW.revenue + REDMESA.revenue + ASHBY.revenue) + ' a year', tone: 'warn' },
          { label: 'Plans written', value: '3, one per site', tone: 'good' },
          { label: 'Written for', value: 'each site, by signal', tone: 'good' },
        ],
        tradeoff: 'Three regions get work this week, one of them for a contract that still rates 2.',
        preferred: true,
        story: [
          { kind: 'asked', text: 'The watch fired: three contracts changed overnight. What should be done about each?' },
          { kind: 'read', text: 'Read the demand letter and the complaint log for Harlow Creek.', figure: '23 residents · 6 complaints', ref: { thread: 'H1' } },
          { kind: 'read', text: 'Read the agreement: liability is capped, consequential damages are not waived, odor capital is the City\'s.', ref: { doc: 'DOC:hc-contract' } },
          { kind: 'found', text: 'Harlow Creek crosses from 2 to 3 on your scorecard.', figure: `${he} to ${he2}`, ref: { sheet: 'contract', contract: 'NCO-047' } },
          { kind: 'compared', text: 'Red Mesa shows the pattern that came before five of seven notices of violation.', figure: '5 of 7', ref: { sheet: 'contract', contract: 'NCO-184' } },
          { kind: 'read', text: 'Ashby Falls puts in-house operation on its 2 December agenda, seven months before the contract ends.', ref: { doc: 'WEB:af-agenda' } },
          { kind: 'therefore', text: 'Act on all three now: one because it moved, two because the record says what comes next.' },
        ],
      },
      {
        id: 'r2',
        title: 'Plans only where a rating moved; list the rest in the Monday digest',
        summary: 'Follow the ratings strictly: a contract that moved up gets the full plan today. A contract that rose inside its rating goes into the Monday digest.',
        figures: [
          { label: 'Contracts acted on', value: '1 of 300' },
          { label: 'Actions opened', value: '7', tone: 'good' },
          { label: 'Red Mesa', value: 'pattern left to run', tone: 'crit' },
          { label: 'Ashby Falls', value: 'council meets first', tone: 'crit' },
        ],
        tradeoff: 'Simple to explain, since it follows the ratings. But the Ashby Falls board meets on 2 December, the same day as the review, and Red Mesa goes on with one licence holder working weekends.',
        story: [
          { kind: 'asked', text: 'What if only a rating change triggers work?' },
          { kind: 'found', text: 'One contract changed rating.', figure: '1 of 3', ref: { sheet: 'scorecard' } },
          { kind: 'compared', text: 'The Ashby Falls board discusses in-house operation on the day of the portfolio review.', figure: '2 December', ref: { doc: 'WEB:af-agenda' } },
          { kind: 'therefore', text: 'Faithful to the scorecard, and late for the two it does not yet see.' },
        ],
      },
      {
        id: 'r3',
        title: 'Tell the owners now and decide the rest at the 2 December review',
        summary: 'Tell the people who own each contract this morning. Take the contracts to the leadership team on 2 December and decide the plans there.',
        figures: [
          { label: 'Done today', value: 'Owners told', tone: 'good' },
          { label: 'Days used of the 30', value: '13', tone: 'crit' },
          { label: 'Odor survey', value: 'not started', tone: 'crit' },
          { label: 'Disruption this week', value: 'none', tone: 'good' },
        ],
        tradeoff: 'The least work now. It uses 13 of the 30 days the letter gives, and the Ashby Falls board meets on the same day as the review.',
        story: [
          { kind: 'asked', text: 'What if the decisions wait for the leadership team?' },
          { kind: 'read', text: 'The claims procedure asks for Legal within one working day and the insurer within 30.', ref: { doc: 'DOC:claims-proc' } },
          { kind: 'compared', text: 'The review is 12 days away; the letter gives 30.', figure: '13 of 30 days' },
          { kind: 'therefore', text: 'Allowed by the procedure, costly for the odor plan and for Ashby Falls.' },
        ],
      },
    ],
    submissions: [
      { id: 'sub-risk-scorecard', label: 'Contract risk dashboard: all contracts', audience: `${PEOPLE.owner}, ${PEOPLE.ownerRole}, and the five Regional VPs`, purpose: 'The dashboard you designed, refreshed, with what changed overnight', template: 'Contract risk: dashboard', templateId: 't-risk-scorecard', why: 'Rebuilt after every check, so nobody has to collate it.' },
      { id: 'sub-risk-brief', label: 'Why it moved: the contracts whose risk went up', audience: 'The Regional VP and the project leader of each contract', purpose: 'What moved, the evidence, what is at stake and the plan for the site', template: 'Contract risk: why it moved', templateId: 't-risk-brief', why: 'Your rule: a deck for every contract that moves up a rating.' },
      { id: 'sub-risk-plan', label: 'Mitigation plan: site by site', audience: 'The project leader and the Regional VP of each contract', purpose: 'One action for every signal at 3 or 4 that can be moved, with an owner, a date and the score it would bring', template: 'Contract risk: site mitigation plan', templateId: 't-risk-plan', why: 'Your rule: a plan for the site when a signal reaches 3 or 4.' },
    ],
    log: [
      { at: '2026-11-12T15:10:00Z', who: PEOPLE.owner, what: 'Approved the approach for the rule "A contract\'s risk changes". The agent checks every morning at 06:00.' },
    ],
    askRefs: ['Which contracts changed rating this week, and why?'],
    approachName: 'Contract risk: what changed, why, what to do',
  },
  {
    id: ONCE_ID,
    title: 'Renewal risk review: the contracts that decide in the next 18 months',
    agent: AGENT_POOL[1],
    goal: 'Of the contracts that decide in the next 18 months, work out which Northline is most likely to lose, what they are worth and what to do about each; and test whether the scorecard would have warned of the renewals already lost.',
    target: {
      measure: 'Annual revenue of the contracts that decide in the next 18 months, by likelihood of loss',
      target: 'A renewal plan for every contract at risk before the 2 December portfolio review',
      current: `${rn.set.length} contracts decide in 18 months, ${m1(rn.revenue)} a year; ${rn.plan.length} need a plan, ${m1(rn.planRev)} a year`,
      tolerance: 'A contract counts as at risk if it rates 3 or 4, or shows a client-side sign with twelve months or less to run',
      deadline: `Pack to ${PEOPLE.owner} by Friday 27 November · portfolio review on Wednesday 2 December`,
      decision: 'Which contracts go on a renewal plan now, and who leads each',
    },
    trigger: 'person',
    triggerDetail: `Started by you on Thursday 19 November, from ${PEOPLE.owner}'s request for the renewal risk review (thread P1).`,
    status: 'findings-ready',
    owner: PEOPLE.owner,
    ownerRole: PEOPLE.ownerRole,
    startedAt: '2026-11-19T09:00:00Z',
    scope: [
      `The ${rn.ending.length} contracts whose term ends in the next 18 months and the ${rn.ever.length} evergreen contracts the client can end on notice`,
      'Their rating on the scorecard, their agreements, client mail, council agendas and local news',
      'The three renewals lost since 2024 and the Calder Valley loss review',
    ],
    constraints: [
      'The scorecard rating is used as written; client-side signs are shown beside it, not mixed into it',
      'An NPS answer given by a predecessor is marked as such',
      'The pack follows the structure of the December 2025 renewal review',
    ],
    plan: RB_PLAN,
    planApproved: { by: 'Nishant Srivastav', at: '2026-11-19T09:05:00Z' },
    findings: [
      {
        id: 'f1',
        headline: `${rn.set.length} contracts decide in the next 18 months, ${m1(rn.revenue)} a year; on the scorecard ${rn.high.length} of them rate 3 or 4.`,
        detail: `${rn.ending.length} end by May 2028 and ${rn.ever.length} are evergreen contracts the client can end on notice. The ${rn.high.length} rated 3 or 4 carry ${m1(rn.highRev)} a year. The other ${rn.set.length - rn.high.length} rate 1 or 2, which is where the scorecard would stop looking.`,
        evidence: [
          { kind: 'table', text: 'End date, renewal options and termination rights for every contract', source: 'master.contract · the signed contracts', asOf: '2026-11-19', ref: { sheet: 'renewals' } },
          { kind: 'table', text: 'The scorecard rating of each contract in the set', source: 'Scorecard · all contracts', asOf: '2026-11-19', ref: { sheet: 'scorecard' } },
        ],
        drill: { view: 'renewals', note: 'The contracts that decide in 18 months, with rating, revenue and months left.' },
      },
      {
        id: 'f2',
        headline: `${rn.quiet.length} contracts rated 1 or 2 show a client-side sign the scorecard has no signal for: ${m1(rn.quietRev)} a year.`,
        detail: `A procurement adviser hired, in-house operation on an agenda, or a new client lead with a year or less to run. ${rn.newLead.length} contracts in the set have a new client lead since their last NPS answer, so the score on file was given by someone who no longer decides. Ashby Falls is the clearest case: $7.4M a year, seven months left, a new DPW Director and in-house operation on the 2 December agenda.`,
        evidence: [
          { kind: 'web', text: 'Council agendas and minutes of the clients in the set, last twelve months', source: 'Client council pages', asOf: '2026-11-19', ref: { sheet: 'renewals' } },
          { kind: 'mail', text: 'Ashby Falls: new DPW Director since 17 August', source: 'Thread A1, Introductions', asOf: '2026-08-19', ref: { thread: 'A1' } },
          { kind: 'table', text: 'Date of the last NPS answer against the date the client lead changed', source: 'crm.nps_response', asOf: '2026-11-19', ref: { sheet: 'renewals' } },
        ],
        drill: { view: 'renewals', note: 'Client-side signs by contract.' },
      },
      {
        id: 'f3',
        headline: `${rn.plan.length} contracts need a renewal plan: ${m1(rn.planRev)} a year, ${Math.round(rn.planRev / rn.revenue * 100)}% of the revenue that decides in 18 months.`,
        detail: `The ${rn.high.length} rated 3 or 4 plus the ${rn.quiet.length} quiet ones with a client-side sign. The five largest carry ${m1(rn.topRev)} a year: ${rn.top.map((c) => c.site).join(', ')}.`,
        evidence: [
          { kind: 'table', text: 'Annual revenue and margin by contract', source: 'fin.contract_pnl', asOf: '2026-10-31', ref: { sheet: 'renewals' } },
        ],
        drill: { view: 'renewals', note: 'The contracts on the plan list, largest first.' },
      },
      {
        id: 'f4',
        headline: `The scorecard would have rated ${lost2.length} of the 3 renewals lost since 2024 a 2 a year before they were lost.`,
        detail: `Calder Valley (lost at re-bid, December 2025) and Wren Hollow (taken in-house, June 2025) both rated 2 twelve months before: plants that ran well. What moved was on the client side: a new utilities director, a procurement adviser, in-house operation on council agendas, an NPS answer that never came. Thorn Landing rated 3 after two notices of violation and a consent order, so the scorecard would have seen that one. It sees trouble at the plant; it does not see a client deciding.`,
        evidence: [
          { kind: 'document', text: 'Calder Valley loss review: what changed in the year before', source: 'Calder_Valley_Loss_Review_2026-03.pdf', asOf: '2026-03-12', ref: { doc: 'DOC:calder-review' } },
          { kind: 'table', text: 'The three lost contracts scored on your bands twelve months before the loss', source: 'Scorecard history', asOf: '2026-11-19', ref: { sheet: 'renewals' } },
          { kind: 'assumption', text: 'That signal values a year before the loss are as the monthly reports of the time recorded them', source: 'Agent Compass' },
        ],
        drill: { view: 'renewals', note: 'The three lost renewals, at the bottom of the sheet.' },
      },
    ],
    gaps: [
      'Client-side signs are read from public agendas, news and mail; a client that decides in private leaves none.',
      'Margin by contract is the October ledger; allocated overhead is not split by contract.',
      `${rn.newLead.length} contracts have no NPS answer from the person who now decides.`,
    ],
    recommendations: [],
    submissions: [
      { id: 'sub-rn-pack', label: 'Renewal review pack: 2 December', audience: `${PEOPLE.owner} and the Contract Operations leadership team`, purpose: 'What decides in 18 months, what is at risk, and the decisions asked of the leadership team', template: 'Your prior deliverables: renewal review, December 2025', templateId: 't-prior-renewal-2025', why: 'Renee asked for last year\'s structure.' },
      { id: 'sub-rn-plan', label: 'Renewal plan: Ashby Falls Water and Sewer', audience: 'Daniel Okoro, Regional VP Northeast', purpose: 'The contract most likely to be lost: who decides, what they will weigh, and what to do before 2 December and before June', template: 'Contract risk: renewal plan', templateId: 't-renewal-plan', why: 'The Select Board discusses in-house operation on 2 December.' },
      { id: 'sub-rn-brief', label: 'Regional brief: renewals at risk, by region', audience: 'The five Regional VPs', purpose: 'One page per region: the contracts on the plan list, what is at stake and who leads', template: 'Contract risk: regional brief', templateId: 't-region-brief', why: 'Each Regional VP owns the plans in the region.' },
    ],
    log: [
      { at: '2026-11-19T09:00:00Z', who: 'Nishant Srivastav', what: `Started the goal from ${PEOPLE.owner}'s request (thread P1).` },
      { at: '2026-11-19T09:05:00Z', who: 'Agent Compass', what: 'Plan agreed; running the six steps.' },
      { at: '2026-11-19T09:24:00Z', who: 'Agent Compass', what: 'Findings ready: four findings, three recommendations, one preferred.' },
    ],
    askRefs: ['Which contracts end in the next 18 months?', 'Which renewals are we most likely to lose?'],
    approachName: 'Renewals: likelihood, client side, what is at stake',
  },
]

/** The renewal recommendations, with the evergreen contracts counted or left out. */
export function onceRecsFor(nineIn = true): Recommendation[] {
  const x = renewals('max', nineIn)
  return [
    {
      id: 'r1',
      title: `Put ${x.plan.length} contracts on a renewal plan now: ${m1(x.planRev)} a year`,
      summary: `Every contract rated 3 or 4 and every quiet one with a client-side sign gets a named lead and a plan before the 2 December review${nineIn ? ', evergreen contracts included' : '; the evergreen contracts are left out at your call'}. Each plan starts with the Regional VP meeting the person who decides, and a fresh NPS where the answer on file is a predecessor's.`,
      figures: [
        { label: 'On a plan', value: `${x.plan.length} contracts` },
        { label: 'Revenue covered', value: `${m1(x.planRev)} a year`, tone: 'good' },
        { label: 'Rated 1 or 2 among them', value: `${x.quiet.length}`, tone: 'warn' },
        { label: 'Start with', value: 'Ashby Falls · $7.4M' },
      ],
      tradeoff: `${x.plan.length} plans are work for five Regional VPs in December, and ${x.quiet.length} of them are for contracts the scorecard rates 1 or 2.`,
      preferred: true,
      story: [
        { kind: 'asked', text: 'Which renewals are we most likely to lose, and what should we do about each?' },
        { kind: 'read', text: 'Read the end date and renewal options of every agreement.', figure: `${x.set.length} decide in 18 months`, ref: { sheet: 'renewals' } },
        { kind: 'found', text: 'On the scorecard, a minority rate 3 or 4.', figure: `${x.high.length} · ${m1(x.highRev)}`, ref: { sheet: 'scorecard' } },
        { kind: 'read', text: 'Read the council agendas, client mail and local news for the rest.', figure: `${x.quiet.length} quiet ones with a sign`, ref: { sheet: 'renewals' } },
        { kind: 'compared', text: 'Two of the three renewals lost since 2024 rated 2 a year before.', figure: '2 of 3', ref: { doc: 'DOC:calder-review' } },
        { kind: 'therefore', text: 'Plan for the rated ones and for the quiet ones with a sign; the rating alone would miss what was lost before.' },
      ],
    },
    {
      id: 'r2',
      title: `Plan only the ${x.high.length} rated 3 or 4: ${m1(x.highRev)} a year`,
      summary: 'Follow the scorecard: a renewal plan for each contract in the set that rates 3 or 4. The others stay under the standing watch.',
      figures: [
        { label: 'On a plan', value: `${x.high.length} contracts` },
        { label: 'Revenue covered', value: `${m1(x.highRev)} a year` },
        { label: 'Left out', value: `${x.quiet.length} with a client-side sign`, tone: 'crit' },
        { label: 'Ashby Falls', value: 'not on the list', tone: 'crit' },
      ],
      tradeoff: `Less work, and easy to defend from the ratings. It leaves out ${m1(x.quietRev)} a year where the client is already weighing its options, Ashby Falls among them.`,
      story: [
        { kind: 'asked', text: 'What if the rating decides who gets a plan?' },
        { kind: 'found', text: 'The rated contracts are covered.', figure: `${x.high.length}`, ref: { sheet: 'scorecard' } },
        { kind: 'compared', text: 'Calder Valley and Wren Hollow rated 2 the year before they were lost.', ref: { doc: 'DOC:calder-review' } },
        { kind: 'therefore', text: 'Consistent with the scorecard, and blind where the last two losses came from.' },
      ],
    },
    {
      id: 'r3',
      title: 'Plan the five largest now and decide the rest after the spring NPS survey',
      summary: `Start with the five largest contracts on the list (${m1(x.topRev)} a year) and wait for fresh NPS answers in March before adding more.`,
      figures: [
        { label: 'On a plan', value: '5 contracts' },
        { label: 'Revenue covered', value: `${m1(x.topRev)} a year` },
        { label: 'Decide before March', value: `${x.set.filter((c) => c.monthsLeft <= 7).length} contracts`, tone: 'crit' },
        { label: 'Work in December', value: 'lightest', tone: 'good' },
      ],
      tradeoff: 'The lightest month for the regions. But several contracts end in June, and their clients will have decided before the survey reports.',
      story: [
        { kind: 'asked', text: 'What if we start small and wait for better data?' },
        { kind: 'compared', text: 'The survey reports in March; several agreements end in June.', figure: 'too late for some' },
        { kind: 'therefore', text: 'Sensible for the long-dated contracts, late for the ones that end next summer.' },
      ],
    },
  ]
}
GOALS[1].recommendations = onceRecsFor(true)

/** Rules and schedules that can start a goal without a person. Shown on the list page. */
export interface Watcher {
  id: string
  kind: 'rule' | 'schedule'
  label: string
  condition: string
  last: string
  state: 'Watching' | 'Fired' | 'Scheduled' | 'Matched'
  goalId?: string
  /** Where the condition is checked: in our own data (the graph), or outside, on the internet (rankings, council agendas, local news). */
  source?: 'data' | 'external'
}

export const WATCHERS: Watcher[] = [
  { id: 'w1', kind: 'schedule', label: 'Quarterly renewal review', condition: 'Each quarter, for every contract that decides in the next 18 months', last: 'Next on 1 February', state: 'Scheduled', goalId: ONCE_ID },
  { id: 'w2', kind: 'rule', source: 'external', label: 'In-house operation on a client council agenda', condition: 'Council agendas of every client, read as they are posted', last: '1 match · Ashby Falls', state: 'Matched' },
  { id: 'w4', kind: 'rule', source: 'data', label: 'A contract\'s risk changes', condition: 'Every signal of every contract against the bands of the company scorecard, each morning at 06:00', last: 'Checked 19 Nov · watching', state: 'Watching', goalId: WATCH_ID },
]

/** The approach the agent proposes for a goal it has not seen before. The analyst edits it before anything runs. */
export const GENERIC_PLAN = (goal: string): PlanStep[] => [
  { id: 'n1', title: 'Ground the goal in the role graph', how: `Resolve "${goal.slice(0, 80)}${goal.length > 80 ? '…' : ''}" to the signals, contracts and documents the graph holds; name anything it does not.`, sources: ['Contract Risk Analyst graph v1'], check: 'Every term in the goal maps to a signal or an entity, or is listed as unresolved.', state: 'pending', actions: ['resolve → the goal\'s terms against the signals of the scorecard and the entity types in the graph.', 'check → every term mapped or listed as unresolved. Passed, with one unresolved.'] },
  { id: 'n2', title: 'State the current position with its components', how: 'The rating of everything in scope, by factor and signal, from the latest check.', sources: ['Scorecard', 'Operations data hub'], check: 'Every rating recomputes from its signals.', state: 'pending', actions: ['read scorecard → ratings for everything in scope.', 'check → ratings recompute. Passed.'] },
  { id: 'n3', title: 'Read what the documents and the mailbox say that the tables do not', how: 'Client, regulator and internal statements with dates that differ from the data.', sources: ['Outlook mailboxes', 'OneDrive documents', 'Public web'], check: 'Nothing is attributed without a dated reference.', state: 'pending', actions: ['read_mail → threads linked to the contracts in scope.', 'read_document → documents linked to the contracts in scope.', 'check → nothing without a dated reference. Passed.'] },
  { id: 'n4', title: 'Set out the ways forward and test them against the constraints', how: 'At least two courses of action and "do nothing", each with what it changes and who must agree.', sources: ['Steps 1 to 3', 'Mitigation matrix'], check: 'No course of action breaks a stated constraint.', state: 'pending', actions: ['compose → two courses of action and "do nothing".', 'check → no course of action breaks a stated constraint. Passed.'] },
]
