import pptxgen from 'pptxgenjs'
import type { Goal } from './goalCases'
import { visualForFormat } from './visuals'
import type { Section, Submission } from '../store/submissionStore'

/* A slide pack downloads as PowerPoint: one slide per section, text left, the section's picture right (rendered to PNG). */

const svgToPng = (svg: string, w = 1240): Promise<string> =>
  new Promise((res, rej) => {
    const img = new Image()
    img.onload = () => {
      const ratio = img.naturalHeight / img.naturalWidth || 0.4
      const c = document.createElement('canvas'); c.width = w; c.height = Math.round(w * ratio)
      const ctx = c.getContext('2d')!; ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height)
      res(c.toDataURL('image/png'))
    }
    img.onerror = () => rej(new Error('svg'))
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`
  })

/* A slide carries its point, not its paragraph: up to three short bullets. */
const bullets = (body: string) => body.split(/\n+/).flatMap((l) => l.split(/(?<=[.!?])\s+(?=[A-Z$"(0-9])/)).map((x) => x.replace(/^[•\-\d.\s]+/, '').trim()).filter((x) => x.length > 3).slice(0, 3).map((x) => (x.length > 140 ? `${x.slice(0, x.lastIndexOf(' ', 138))}…` : x))
const asBullets = (body: string) => bullets(body).map((t) => ({ text: t, options: { bullet: { code: '25CF' }, paraSpaceAfter: 8 } }))

export async function downloadPptx(s: Submission, goal: Goal | null, sections: Section[]): Promise<void> {
  const pptx = new pptxgen()
  pptx.layout = 'LAYOUT_16x9'
  pptx.author = s.createdBy; pptx.title = s.title
  const INK = '0F1729', MUTED = '5C6B84', BRAND = 'E8562A'
  const title = pptx.addSlide(); title.background = { color: '1E2A3A' }
  title.addText('Northline Water Group · Context Weave', { x: 0.5, y: 1.3, w: 9, h: 0.4, fontSize: 14, color: 'A7D7CF', fontFace: 'Arial' })
  title.addText(s.title, { x: 0.5, y: 1.8, w: 9, h: 1.3, fontSize: 28, bold: true, color: 'FFFFFF', fontFace: 'Arial', valign: 'top' })
  title.addText(`To ${s.audience || 'the reader'} · ${new Date().toLocaleDateString('en-GB', { dateStyle: 'long' })} · prepared by ${s.createdBy}${s.agentName ? ` with ${s.agentName}` : ''}`, { x: 0.5, y: 3.3, w: 9, h: 0.4, fontSize: 12, color: 'D3D6DB', fontFace: 'Arial' })
  title.addText('DRAFT, not approved. Figures reproducible from the goal’s data; assumptions and open items stated inside.', { x: 0.5, y: 4.9, w: 9, h: 0.3, fontSize: 9, color: '8A9099', fontFace: 'Arial' })
  for (let i = 0; i < sections.length; i++) {
    const x = sections[i]
    const sl = pptx.addSlide()
    sl.addText(x.heading, { x: 0.5, y: 0.3, w: 8.4, h: 0.7, fontSize: 22, bold: true, color: INK, fontFace: 'Arial', valign: 'middle' })
    sl.addText(`${i + 1} / ${sections.length}`, { x: 8.9, y: 0.4, w: 0.6, h: 0.3, fontSize: 9, color: '8A9099', align: 'right', fontFace: 'Arial' })
    const v = goal ? visualForFormat(goal, x.role, x.heading, 'Slide pack') : null
    const body = (x.body || '(to be written)').trim()
    let png: string | null = null
    if (v?.svg) { try { png = await svgToPng(v.svg) } catch { png = null } }
    if (png) {
      sl.addText(x.body.trim() ? asBullets(body) : body, { x: 0.5, y: 1.1, w: 4.1, h: 3.7, fontSize: 13, color: INK, fontFace: 'Arial', valign: 'top' })
      sl.addText(v!.title, { x: 4.8, y: 1.1, w: 4.7, h: 0.3, fontSize: 9, color: MUTED, fontFace: 'Arial' })
      sl.addImage({ data: png, x: 4.8, y: 1.4, w: 4.7, sizing: { type: 'contain', w: 4.7, h: 2.9 } })
      sl.addText(v!.note, { x: 4.8, y: 4.35, w: 4.7, h: 0.5, fontSize: 9, color: MUTED, fontFace: 'Arial', valign: 'top' })
    } else if (v?.kind === 'kpis') {
      const items = (v.data as { items: { label: string; value: string }[] }).items.slice(0, 4)
      sl.addText(x.body.trim() ? asBullets(body) : body, { x: 0.5, y: 1.1, w: 4.1, h: 3.7, fontSize: 13, color: INK, fontFace: 'Arial', valign: 'top' })
      items.forEach((it, k) => {
        const yy = 1.15 + k * 0.95
        sl.addShape('roundRect', { x: 4.8, y: yy, w: 4.7, h: 0.82, fill: { color: 'F4F6F9' }, line: { color: 'E3E6EC' }, rectRadius: 0.08 })
        sl.addText(it.value, { x: 5.0, y: yy + 0.06, w: 4.3, h: 0.45, fontSize: 18, bold: true, color: INK, fontFace: 'Arial' })
        sl.addText(it.label, { x: 5.0, y: yy + 0.48, w: 4.3, h: 0.28, fontSize: 9.5, color: MUTED, fontFace: 'Arial' })
      })
      sl.addText(v.title, { x: 4.8, y: 0.85, w: 4.7, h: 0.3, fontSize: 9, color: MUTED, fontFace: 'Arial' })
    } else if (v?.table) {
      const t = v.table
      sl.addText(x.body.trim() ? asBullets(body) : body, { x: 0.5, y: 1.1, w: 3.6, h: 3.7, fontSize: 12, color: INK, fontFace: 'Arial', valign: 'top' })
      const head = t.columns.map((c) => ({ text: c, options: { bold: true, color: 'FFFFFF', fill: { color: '1E2A3A' }, fontSize: 9 } }))
      const rows = t.rows.slice(0, 8).map((r) => r.map((c) => ({ text: String(c).length > 60 ? `${String(c).slice(0, 58)}…` : String(c), options: { fontSize: 9, color: INK } })))
      sl.addTable([head, ...rows], { x: 4.3, y: 1.1, w: 5.2, fontFace: 'Arial', border: { type: 'solid', pt: 0.5, color: 'D3D6DB' }, colW: Array(t.columns.length).fill(5.2 / t.columns.length), rowH: 0.3 })
      sl.addText(v.note, { x: 4.3, y: 4.5, w: 5.2, h: 0.4, fontSize: 9, color: MUTED, fontFace: 'Arial' })
    } else {
      sl.addText(body.length > 1400 ? `${body.slice(0, body.lastIndexOf(' ', 1400))}…` : body, { x: 0.5, y: 1.1, w: 9, h: 3.7, fontSize: 12, color: INK, fontFace: 'Arial', valign: 'top', paraSpaceAfter: 4 })
    }
    sl.addText(`Source: ${x.from}`, { x: 0.5, y: 5.0, w: 6.5, h: 0.3, fontSize: 8, color: '8A9099', fontFace: 'Arial' })
    sl.addText('Draft · Context Weave', { x: 7.5, y: 5.0, w: 2, h: 0.3, fontSize: 8, color: BRAND, align: 'right', fontFace: 'Arial' })
  }
  await pptx.writeFile({ fileName: `${s.id}.pptx` })
}
