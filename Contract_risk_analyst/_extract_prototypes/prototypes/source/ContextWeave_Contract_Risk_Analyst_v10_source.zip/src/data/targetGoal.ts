/*
 * The target goal (11 November 2026): a standing goal with a number and a date.
 *
 * "Take 2.5% off procurement spend by 30 June 2027" is more than a rule to check. The analyst owns
 * the number: it fixes the baseline, breaks the target into the levers the savings register already
 * uses, sizes each lever from the data, watches every load for three kinds of signal (leakage,
 * openings, headwinds), forecasts where the program lands and says what would close the gap.
 * It recommends; it changes nothing in a source system.
 *
 * Every figure here is derived from the Northline procurement story (data/veoliaStories.json):
 * the register (41 entries, $8.7M secured, five levers), the four frameworks, six months of order
 * lines by category and the 20 October order load. Planned and pipeline amounts per lever are the
 * program's own split, stated here because the package does not carry them.
 */
import type { Drill } from './goalCases'
import { PROC } from './drill'

export const m1t = (n: number) => `$${(n / 1e6).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}M`
export const m2t = (n: number) => `$${(n / 1e6).toFixed(2)}M`
export const pct1 = (n: number) => `${(n * 100).toFixed(1)}%`
const dr = (view: Drill['view'], extra: Partial<Drill> = {}): Drill => ({ view, note: '', ...extra })

export type LeverKey = 'reneg' | 'rebid' | 'fw' | 'spec' | 'vol'
export interface Lever {
  key: LeverKey
  /** The name the savings register uses. */
  name: string
  what: string
  watch: string[]
  plan: number
  secured: number
  entries: number
  /** Named in the tracker's pipeline, not yet in an order or a signed contract. */
  pipeline: number
  invoiced: number
  evidence: { n: string; m: string; drill: Drill }
}

const reg = (lever: string) => { const xs = PROC.register.filter((r) => r.lever === lever); return { secured: xs.reduce((n, r) => n + r.amount, 0), entries: xs.length } }

export const LEVERS: Lever[] = [
  { key: 'reneg', name: 'Renegotiation', what: 'A lower price on a contract that is already running.', watch: ['The same item bought at different prices across regions', 'Contract prices above the category benchmark', 'Volume rebates earned and not claimed'], plan: 8.4e6, pipeline: 2.6e6, invoiced: 2.0e6, ...reg('Renegotiation'), evidence: { n: 'Savings_tracker_2026-10.xlsx', m: 'Register, lever Renegotiation', drill: dr('documents', { doc: 'DOC:sav-tracker' }) } },
  { key: 'rebid', name: 'Re-bid', what: 'A contract put back to the market before it renews.', watch: ['Frameworks and contracts that end within nine months', 'Items with one supplier and a price above benchmark', 'Renewals that roll over without a bid'], plan: 6.2e6, pipeline: 2.3e6, invoiced: 1.1e6, ...reg('Re-bid'), evidence: { n: 'Procurement_Savings_Program_2026-27.pdf', m: 'The re-bid calendar', drill: dr('documents', { doc: 'DOC:sav-program' }) } },
  { key: 'fw', name: 'Framework compliance', what: 'Orders placed on the framework that covers the item, at its price.', watch: ['Order lines off a framework that covers the item', 'Lines above the category benchmark where no framework applies', 'Catalogue defaults that send orders to spot suppliers'], plan: 4.6e6, pipeline: 0.4e6, invoiced: 1.3e6, ...reg('Framework compliance'), evidence: { n: 'psoft.po_line · framework price schedules', m: 'Every order line against its framework price', drill: dr('procure') } },
  { key: 'spec', name: 'Specification change', what: 'The same job done with a cheaper item or a simpler specification.', watch: ['Items ordered above the class the design standard asks for', 'Two items that do the same job at different prices', 'One-off specifications where a standard item exists'], plan: 2.6e6, pipeline: 1.1e6, invoiced: 0.3e6, ...reg('Specification change'), evidence: { n: 'Savings_tracker_2026-10.xlsx', m: 'Register, lever Specification change', drill: dr('documents', { doc: 'DOC:sav-tracker' }) } },
  { key: 'vol', name: 'Volume consolidation', what: 'Several small orders of the same item placed as one.', watch: ['The same item ordered by several projects in one month', 'Categories with spend and no framework', 'A long tail of small suppliers in one category'], plan: 2.4e6, pipeline: 1.1e6, invoiced: 0.2e6, ...reg('Volume consolidation'), evidence: { n: 'psoft.po_line', m: 'Order lines by item and month', drill: dr('procure') } },
]

/** Days left in the program from the day of the demo story (the 20 October load). */
const TODAY = new Date('2026-10-20T00:00:00Z')
const END = new Date(`${PROC.end}T00:00:00Z`)
const START = new Date(`${PROC.start}T00:00:00Z`)
export const MONTHS_LEFT = Math.round(((END.getTime() - TODAY.getTime()) / 86400000 / 30.4) * 10) / 10
const MONTHS_GONE = (TODAY.getTime() - START.getTime()) / 86400000 / 30.4

export interface TargetState { fired: boolean; handled: boolean; catalogueRaised: boolean }

/** Where the program stands and where it lands, with every assumption the forecast rests on. */
export function targetFigures(s: TargetState) {
  const target = PROC.target
  const nine = PROC.unconfirmed_premium
  const secured = PROC.secured + (s.handled ? nine : 0)
  const pipeline = LEVERS.reduce((n, l) => n + l.pipeline, 0) + (s.fired && !s.handled ? nine : 0)
  const invoiced = LEVERS.reduce((n, l) => n + l.invoiced, 0)
  const conv = 0.62
  const pace = PROC.secured / MONTHS_GONE
  const newFinds = Math.round((pace / 2) * MONTHS_LEFT / 1e5) * 1e5
  const leakYear = PROC.run_rate_year
  const leak = s.catalogueRaised ? 0 : Math.round((leakYear * MONTHS_LEFT) / 12 / 1e5) * 1e5
  const converted = Math.round(LEVERS.reduce((n, l) => n + l.pipeline, 0) * conv / 1e5) * 1e5
  const forecast = secured + converted + newFinds - leak
  return { target, baseline: PROC.baseline, secured, pipeline, invoiced, conv, pace, newFinds, leak, leakYear, converted, forecast, gap: Math.max(0, target - forecast), path: PROC.path_today, nine }
}

export type SignalKind = 'leak' | 'open' | 'head'
export interface Signal { id: string; kind: SignalKind; lever: LeverKey; title: string; amount: string; body: string; src: { n: string; drill: Drill }[]; when: 'always' | 'fired'; run?: boolean }

const mtr = PROC.frameworks.find((f) => f.no === 'FA-2024-MTR-01')!
const cat = (name: string) => PROC.cats.find((c) => c.cat === name)!

export const SIGNALS: Signal[] = [
  { id: 'sg-load', kind: 'leak', lever: 'fw', when: 'fired', run: true, title: `${PROC.load.off} of the ${PROC.load.lines} new order lines are off-framework`, amount: `${m2t(PROC.batch_premium)} above framework prices`, body: `Nine are not yet confirmed by the supplier, so they can still be cancelled at no cost and re-ordered on the frameworks: ${m2t(PROC.unconfirmed_premium)} kept.`, src: [{ n: 'psoft.po_line · load of 20 October 02:00', drill: dr('procure') }, { n: 'FA-2025-PIPE-01 · Schedule A', drill: dr('documents', { doc: 'DOC:fa-pipe' }) }] },
  { id: 'sg-cat', kind: 'leak', lever: 'fw', when: 'always', title: 'The ordering catalogue still defaults to the spot suppliers for pipe and valves', amount: `about ${m1t(PROC.run_rate_year)} a year`, body: `Since April $${PROC.off_6m}M went off-framework or above benchmark, $${PROC.prem_6m}M over the framework and benchmark prices. The tracker does not net this against the savings.`, src: [{ n: 'Thread S2 · Ductile iron orders still going to Northgate', drill: dr('mail', { thread: 'S2' }) }, { n: 'Savings_tracker_2026-10.xlsx', drill: dr('documents', { doc: 'DOC:sav-tracker' }) }] },
  { id: 'sg-mtr', kind: 'open', lever: 'rebid', when: 'always', title: `The meters framework ${mtr.no} ends on 30 June 2027`, amount: 'about $1.1M if re-bid and signed before it ends', body: `Meters run at $${cat('Meters').spend}M in six months with ${mtr.sup}. A re-bid has to start by January to be signed in time, and it is not in the tracker’s pipeline. The estimate is 5% of a year’s spend, the average of the eight re-bids so far.`, src: [{ n: 'Procurement_Savings_Program_2026-27.pdf', drill: dr('documents', { doc: 'DOC:sav-program' }) }, { n: 'psoft.po_line · meters since April', drill: dr('procure') }] },
  { id: 'sg-pmp', kind: 'open', lever: 'vol', when: 'always', title: 'Pumps and motors have spend and no framework', amount: 'about $0.5M under one agreement', body: `$${cat('Pumps and motors').spend}M in six months across several suppliers, $${cat('Pumps and motors').off}M of it above the category benchmark. One agreement at the benchmark would hold the price for every project.`, src: [{ n: 'psoft.po_line · pumps and motors since April', drill: dr('procure') }, { n: 'Capital_Procurement_Policy_2025.pdf', drill: dr('documents', { doc: 'DOC:proc-policy' }) }] },
  { id: 'sg-lead', kind: 'head', lever: 'fw', when: 'always', title: 'Framework lead times decide whether orders stay on the frameworks', amount: 'two blankets need pipe within four weeks', body: 'Harbor Pipe reached 11 weeks in the spring and orders moved to spot suppliers. It has been back to 4 weeks since 29 September. If it slips again, the same thing happens.', src: [{ n: 'Thread S1 · Harbor Pipe lead times back to 4 weeks', drill: dr('mail', { thread: 'S1' }) }] },
  { id: 'sg-pace', kind: 'head', lever: 'reneg', when: 'always', title: 'The easy contracts are done', amount: '20 of the 41 savings so far', body: 'Twenty of the 41 entries in the register are renegotiations and re-bids, and a contract can only be reopened once. I forecast new savings at half the pace so far for that reason.', src: [{ n: 'Savings_tracker_2026-10.xlsx · register', drill: dr('documents', { doc: 'DOC:sav-tracker' }) }] },
]

export const KIND_LABEL: Record<SignalKind, string> = { leak: 'Leakage', open: 'Openings', head: 'Headwinds' }
export const KIND_SUB: Record<SignalKind, string> = { leak: 'Savings being lost now', open: 'New ways to save that nobody has on the list', head: 'Things pushing spend up' }

export interface Move { id: string; title: string; amount: number; lever: LeverKey; who: string; by: string; done?: (s: TargetState) => boolean; doneText?: string }
export const MOVES: Move[] = [
  { id: 'mv-cat', title: 'Change the catalogue default to the framework suppliers', amount: Math.round((PROC.run_rate_year * MONTHS_LEFT) / 12 / 1e5) * 1e5, lever: 'fw', who: 'Tolu Adeyemi, Head of Capital Procurement, with Procurement systems', by: 'now', done: (s) => s.catalogueRaised, doneText: 'Change request raised on the 20 October run; counted once IT makes the change' },
  { id: 'mv-mtr', title: 'Start the meters re-bid in January', amount: 1.1e6, lever: 'rebid', who: 'Tolu Adeyemi', by: 'January 2027' },
  { id: 'mv-pmp', title: 'Put pumps and motors under one agreement', amount: 0.5e6, lever: 'vol', who: 'Capital Procurement', by: 'March 2027' },
]

/* ------------------------------------------------------------------ called at the step, from the procurement system */

export interface ReqLine { item: string; desc: string; q: number; unit: string; price: number }
export interface Requisition {
  id: string; project: string; by: string; supplier: string; line: ReqLine
  verdict: 'flag' | 'clear' | 'note'
  head: string; reason: string
  better?: { supplier: string; price: number; framework: string; lead: string; label: string }
  evidence: { n: string; drill: Drill }[]
  lever: LeverKey
}

const b0 = PROC.batch.find((b) => b.item === 'GV-12-RW') ?? PROC.batch[0]
const pipe = PROC.frameworks[0].items[0]

export const REQUISITIONS: Requisition[] = [
  {
    id: 'REQ-0071842', project: `${b0.p} ${b0.name}`, by: b0.pm, supplier: b0.sup, lever: 'fw',
    line: { item: b0.item, desc: b0.desc, q: b0.q, unit: b0.unit, price: b0.up },
    verdict: 'flag', head: 'Off-framework: this item is on a framework at a lower price',
    reason: `${b0.fw} covers ${b0.desc.toLowerCase()} at a fixed price. Above $25,000 a line the policy asks for the framework, or a Procurement exception on the order. The framework supplier has been back to a 3-week lead time since September.`,
    better: { supplier: 'Kestrel Flow Controls, Inc.', price: b0.fp, framework: b0.fw, lead: '3 weeks', label: `Switch to Kestrel on ${b0.fw}` },
    evidence: [{ n: `${b0.fw} · Schedule A`, drill: dr('documents', { doc: 'DOC:fa-vlv' }) }, { n: 'Capital_Procurement_Policy_2025.pdf · item 3', drill: dr('documents', { doc: 'DOC:proc-policy' }) }],
  },
  {
    id: 'REQ-0071855', project: 'CZZF50291_612 Main Replacement Blanket, Eastmoor', by: 'Priya Raman', supplier: PROC.frameworks[0].sup, lever: 'fw',
    line: { item: pipe.item, desc: pipe.desc, q: 2400, unit: pipe.unit, price: pipe.price },
    verdict: 'clear', head: 'On framework, at the framework price',
    reason: `${PROC.frameworks[0].no} covers this item and the price matches Schedule A. Nothing to change.`,
    evidence: [{ n: `${PROC.frameworks[0].no} · Schedule A`, drill: dr('documents', { doc: 'DOC:fa-pipe' }) }],
  },
  {
    id: 'REQ-0071861', project: 'CZZF50402_233 Booster Station Renewal, Lakeshore', by: 'Hollis Callaghan', supplier: 'Meridian Pump & Motor', lever: 'vol',
    line: { item: 'VT-075-PMP', desc: 'Vertical turbine pump, 75 hp', q: 1, unit: 'each', price: 48900 },
    verdict: 'note', head: 'No framework covers this item; two other projects are buying the same pump this month',
    reason: 'The price is 7.7% above the category benchmark of $45,400. Two requisitions for the same pump are open in Eastmoor and Lakeshore. One order of three reaches the supplier’s volume price.',
    better: { supplier: 'Meridian Pump & Motor', price: 45400, framework: 'one order of three', lead: 'same', label: 'Ask Procurement to bundle the three' },
    evidence: [{ n: 'psoft.po_line · pumps and motors since April', drill: dr('procure') }, { n: 'Capital_Procurement_Policy_2025.pdf · item 5', drill: dr('documents', { doc: 'DOC:proc-policy' }) }],
  },
]

export const money0 = (n: number) => `$${Math.round(n).toLocaleString('en-US')}`
export const money2 = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
export const reqSaving = (r: Requisition) => (r.better ? (r.line.price - r.better.price) * r.line.q : 0)

/** What the calling system sends and what the analyst answers: shown so the client's team can see the contract. */
export function callSample(r: Requisition, analyst: string) {
  const request = { analyst, goal: 'Take 2.5% off procurement spend', event: 'requisition.submitted', system: 'PeopleSoft eProcurement', requisition: { id: r.id, project: r.project.split(' ')[0], requested_by: r.by, supplier: r.supplier, lines: [{ item: r.line.item, quantity: r.line.q, unit: r.line.unit, unit_price: r.line.price }] } }
  const response = { verdict: r.verdict === 'flag' ? 'review' : r.verdict === 'note' ? 'advice' : 'clear', headline: r.head, saving_identified: Math.round(reqSaving(r) * 100) / 100, lever: LEVERS.find((l) => l.key === r.lever)!.name, alternative: r.better ? { supplier: r.better.supplier, unit_price: r.better.price, basis: r.better.framework, lead_time: r.better.lead } : null, evidence: r.evidence.map((e) => e.n), writes_to_source_system: false }
  return { request: JSON.stringify(request, null, 2), response: JSON.stringify(response, null, 2) }
}
