/**
 * Where a dataset's rendered report documents actually live, as URLs the browser can load.
 *
 * The server lists a document by **filename** — `R1_variance_report.html` — because that is what the
 * ingest read off disk and because the server has no idea how the client bundles its assets. This module
 * is the other half: it turns that filename into a URL.
 *
 * **`import.meta.glob` with `?url`, so there is exactly one copy of each file.** The obvious alternative
 * is to copy them into `public/`, which serves them at a stable path with no bundler involvement — and
 * that is how `/login/data` frames its document. It was rejected here for one reason: a copy in `public/`
 * beside the original in `src/Capex/Report/` is two answers to what the report says, and the one nobody
 * edits goes stale silently. These files are 2.5 MB each and are re-exported as a whole; a stale copy
 * would be a whole report out of date, not a detail. So the files stay where they were authored and Vite
 * emits them as assets.
 *
 * **The glob is written per-dataset-folder rather than naming CAPEX**, so a second dataset that ships
 * rendered reports is a folder drop and an ingest run rather than an edit here. `eager` because the map
 * is a lookup table of URLs, not the documents themselves — nothing 2.5 MB is pulled into the bundle
 * graph by asking for its address.
 *
 * **A rendered What-if lens resolves through here too, and through the same map.** A dataset can ship its
 * What-if as a finished page rather than a traversal to compute — CAPEX does — and that page needs exactly
 * what a report needs: a filename turned into a URL, from one copy, with a missing file named rather than
 * guessed. Two modules would be two copies of that machinery and two places for the duplicate-basename
 * throw below to live. **A second glob rather than a widened one**, because the folder is what says which
 * kind of document a file is: `Report/` holds reports and `what-if-lens/` holds a lens, and a pattern
 * loose enough to catch both would also catch the next folder somebody drops beside them.
 *
 * **And a third, for a dataset whose Audit & Governance screen is a rendered page.** Same reasoning
 * again, and the folder name is again what classifies the file: `audit-governance/` holds that screen.
 *
 * **A fourth glob resolves the specification behind a rendered report**, and **a fifth resolves a
 * page that is not a dataset's at all** — see their own declarations below for why each earns a
 * separate pattern rather than a widened one. Five globs feeding one lookup is five lines; one loose
 * pattern is a rule nobody can read off the tree, and the duplicate-basename throw below has to see
 * every candidate whichever way they arrive.
 */

/*
 * Vite rewrites this at build time into a map of module path -> emitted asset URL. Typed explicitly
 * because `?url` on `.html` is not one of the extensions `vite/client` declares.
 */
/*
 * Offline build: only the KEOLIS documents are bundled, as text, and each frame is given its
 * document through `srcdoc` (see `frameSource`). A `srcdoc` frame shares this page's origin even when
 * the file is opened from disk, so the stylesheet injection below and the documents' own downloads
 * keep working.
 */
import keolisWhatIf from '../Keolis/what-if-lens/whatif_keolis_demo.html?raw'
import keolisAiSubmissions from '../Keolis/ai-submissions/ai_submissions_keolis_demo.html?raw'

const INLINE: Record<string, string> = {
  'whatif_keolis_demo.html': keolisWhatIf,
  'ai_submissions_keolis_demo.html': keolisAiSubmissions,
}
const byName = new Map<string, string>(Object.keys(INLINE).map((name) => [name, `inline:${name}`]))

/** The iframe attribute that carries a bundled document. */
export const frameSource = (url: string): { src?: string; srcDoc?: string } =>
  url.startsWith('inline:') ? { srcDoc: INLINE[url.slice(7)] } : { src: url }

export const reportDocumentUrl = (file: string): string | null => byName.get(file) ?? null

/** Every document filename the bundle carries, for the "which files are here" half of a diagnosis. */
export const reportDocumentFiles = (): string[] => [...byName.keys()].sort()
