/*
 * Ask, for contract risk. The questions a leader asks about the portfolio, each answered from the same
 * scorecard the dashboard shows: the projects, their scores, their readings, their plans. Nothing here is
 * a stored answer; every figure is worked out when the question is asked, so it follows a change to the
 * scoring or a morning check.
 *
 * A question is matched in this order: two project names (compare), one project name (status, plan or
 * stake), then the list of intents below. What it cannot answer, it says so.
 */
import {
  CONTRACTS, DESIGN, FACTORS, LOST, NOT_FOUND, RATING_NAME, REGIONS, SIGNALS, activeFactors, deltaOf, driversOf, f1, factorAverages, factorScore,
  flagsOf, impactOn, likelihoodSignals, lostCaught, lostOn, m1, movers, planEffect, planFor, priorityOf, ratingOf, readingOf, score, shortSite, trendOf, valOf,
  type Contract, type SrcKind, type When,
} from './risk'

export interface AskTable { cols: string[]; rows: string[][]; ids?: (string | null)[]; num?: number[] }
export interface AskAnswer { key: string; head: string; points?: string[]; table?: AskTable; bars?: { label: string; value: number; text: string }[]; sources: { kind: SrcKind; name: string }[]; follow: string[] }

const S = (c: Contract, w: When) => score(c, DESIGN.rule, w)
const R = (c: Contract, w: When) => ratingOf(S(c, w))
const rev = (cs: Contract[]) => cs.reduce((n, c) => n + c.revenue, 0)
const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`
const hsh = (t: string) => { let h = 2166136261; for (let i = 0; i < t.length; i += 1) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) } return ((h >>> 0) % 100000) / 100000 }
const SCORECARD = { kind: 'table' as SrcKind, name: 'The contract risk scorecard' }
const MASTER = { kind: 'table' as SrcKind, name: 'master.contract' }
const srcOf = (sids: string[]) => { const out: { kind: SrcKind; name: string }[] = []; for (const id of sids) { const s = SIGNALS.find((x) => x.id === id); if (s && !out.some((o) => o.name === s.src.name)) out.push({ kind: s.src.kind, name: s.src.name }) } return out }
const high = (w: When) => CONTRACTS.filter((c) => R(c, w) >= 3)
const term = (c: Contract) => (c.evergreen ? 'evergreen, ends on notice' : `${c.monthsLeft} months left`)
const band = (c: Contract, sid: string, w: When) => { const v = valOf(c, sid, w); if (v !== undefined) return Math.round(v); const rd = readingOf(c, sid, w); return rd ? rd.r : 0 }
const raw = (c: Contract, sid: string, w: When) => readingOf(c, sid, w)?.raw ?? ''
const asOf = (w: When) => (w === 'after' ? new Date(Date.UTC(2026, 10, 20)) : new Date(Date.UTC(2026, 10, 19)))
const day = (d: Date) => d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: 'UTC' })

/* ------------------------------------------------------------------ building blocks */
const projTable = (cs: Contract[], w: When, extra?: { col: string; of: (c: Contract) => string; num?: boolean }[]): AskTable => ({
  cols: ['Project', 'Region', ...(extra ?? []).map((e) => e.col), 'Risk score', 'Rating', 'Revenue a year'],
  rows: cs.map((c) => [shortSite(c), c.region, ...(extra ?? []).map((e) => e.of(c)), f1(S(c, w)), `${R(c, w)} · ${RATING_NAME[R(c, w)].toLowerCase()}`, m1(c.revenue)]),
  ids: cs.map((c) => c.id), num: [2 + (extra?.length ?? 0), 4 + (extra?.length ?? 0), ...(extra ?? []).map((e, i) => (e.num ? 2 + i : -1)).filter((i) => i >= 0)],
})
/** Projects that score at least `min` on one signal. */
function sigList(sid: string, min: number, w: When, phrase: string, follow: string[]): AskAnswer {
  const s = SIGNALS.find((x) => x.id === sid)!, f = FACTORS.find((x) => x.id === s.f)!
  const cs = CONTRACTS.filter((c) => readingOf(c, sid, w) && band(c, sid, w) >= min).sort((a, b) => band(b, sid, w) - band(a, sid, w) || S(b, w) - S(a, w))
  const hi = cs.filter((c) => R(c, w) >= 3)
  const off = !DESIGN.on[sid]
  return {
    key: `sig:${sid}`,
    head: cs.length ? `**${plural(cs.length, 'project')}** ${phrase}. Together they bill ${m1(rev(cs))} a year, and ${hi.length ? `${hi.length} of them already rate 3 or 4` : 'none of them rates 3 or 4'}.` : `No project ${phrase.replace(/^have /, 'has ').replace(/^are /, 'is ')} today.`,
    points: [`On the scorecard this is the signal “${s.name}” in ${f.name}${off ? '. It is not in use on your scorecard right now, so it does not count in the score; I still read it' : ''}.`, `Measured as: ${s.src.how.replace(/\.$/, '')}.`],
    table: cs.length ? projTable(cs, w, [{ col: s.name, of: (c) => raw(c, sid, w) }, { col: 'Scores', of: (c) => String(band(c, sid, w)), num: true }]) : undefined,
    sources: [{ kind: s.src.kind, name: s.src.name }, SCORECARD], follow,
  }
}
/** Projects where one factor is weakest. */
function facList(fid: string, w: When, follow: string[]): AskAnswer {
  const f = FACTORS.find((x) => x.id === fid)!
  const xs = CONTRACTS.map((c) => ({ c, v: factorScore(c, fid, w) })).filter((x): x is { c: Contract; v: number } => x.v !== null).sort((a, b) => b.v - a.v)
  const bad = xs.filter((x) => x.v >= 2.5), top = xs.slice(0, 12), avg = xs.reduce((n, x) => n + x.v, 0) / (xs.length || 1)
  const sigs = SIGNALS.filter((s) => s.f === fid && DESIGN.on[s.id])
  const worst = (c: Contract) => { const d = sigs.map((s) => ({ s, b: band(c, s.id, w) })).sort((a, b) => b.b - a.b)[0]; return d && d.b >= 3 ? `${d.s.name}: ${raw(c, d.s.id, w)}` : 'No signal at 3 or 4' }
  return {
    key: `fac:${fid}`,
    head: `On ${f.name} the portfolio averages **${f1(avg)}**. **${plural(bad.length, 'project')}** score 2.5 or more on it; the weakest is ${shortSite(top[0].c)} at ${f1(top[0].v)}.`,
    points: [`${f.name} is made of ${plural(sigs.length, 'signal')}: ${sigs.map((s) => s.name.toLowerCase()).join('; ')}.`],
    table: projTable(top.map((x) => x.c), w, [{ col: f.name, of: (c) => f1(factorScore(c, fid, w) ?? 0), num: true }, { col: 'Worst signal', of: worst }]),
    sources: [...srcOf(sigs.map((s) => s.id)).slice(0, 3), SCORECARD], follow,
  }
}
/** The signals that score worse now than 90 days ago. */
const roseOn = (c: Contract, w: When) => likelihoodSignals().map((s) => ({ s, rd: readingOf(c, s.id, w) })).filter((x) => x.rd && x.rd.was !== undefined && x.rd.was < x.rd.r).map((x) => ({ s: x.s, from: x.rd!.was!, to: x.rd!.r, raw: x.rd!.raw, wasRaw: x.rd!.wasRaw }))
const reasonOf = (c: Contract, w: When) => {
  const mv = w === 'after' ? movers().find((m) => m.c.id === c.id) : undefined
  if (mv && mv.sigs.length) return mv.sigs.slice(0, 2).map((x) => `${x.s.name}: ${x.raw}`).join('; ')
  const up = deltaOf(c, w) > 0.08 ? roseOn(c, w) : []
  if (up.length) return up.slice(0, 2).map((x) => `${x.s.name}: ${x.raw} (was ${x.from}, now ${x.to})`).join('; ')
  const d = driversOf(c, w, 2)
  return d.length ? d.map((x) => `${x.s.name}: ${x.raw}`).join('; ') : 'No signal at 3 or 4'
}
const NAMES = [...new Set(CONTRACTS.map((c) => shortSite(c).toLowerCase()))].sort((a, b) => b.length - a.length)
const sitesIn = (t: string) => {
  const out: Contract[] = []; let rest = ` ${t.toLowerCase()} `
  for (const n of NAMES) {
    if (!rest.includes(n)) continue
    const cs = CONTRACTS.filter((c) => shortSite(c).toLowerCase() === n)
    const pick = cs.find((c) => rest.includes(c.site.toLowerCase())) ?? (/wastewater treatment|wwtp/.test(rest) ? cs.find((c) => / WWTP$/.test(c.site)) : undefined) ?? (/water system|drinking/.test(rest) ? cs.find((c) => / (Water System|WTP)$/.test(c.site)) : undefined) ?? [...cs].sort((a, b) => score(b, DESIGN.rule, 'before') - score(a, DESIGN.rule, 'before'))[0]
    out.push(pick); rest = rest.split(n).join(' ')
  }
  return out
}

/* ------------------------------------------------------------------ one project */
function siteStatus(c: Contract, w: When): AskAnswer {
  const s = S(c, w), r = R(c, w), d = deltaOf(c, w), dr = driversOf(c, w), mv = w === 'after' ? movers().find((m) => m.c.id === c.id) : undefined
  const eff = planEffect(c, w), plan = planFor(c, w).filter((p) => !p.fixed && !p.later), flags = flagsOf(c, w)
  const moved = d > 0.08 ? `It rose by ${d.toFixed(2)} over the last 90 days` : d < -0.08 ? `It fell by ${Math.abs(d).toFixed(2)} over the last 90 days` : 'It has held steady over the last 90 days'
  const n = shortSite(c)
  return {
    key: `site:${c.id}`,
    head: `**${n} rates ${r} (${RATING_NAME[r].toLowerCase()}) with a risk score of ${f1(s)}.** ${moved}${mv && mv.r1 > mv.r0 ? `, and it moved from ${mv.r0} to ${mv.r1} at this morning's check` : ''}. Priority: ${priorityOf(c, w).toLowerCase()}.`,
    points: [
      `The contract: ${c.kind.toLowerCase()} for ${c.client}, ${c.state}. ${m1(c.revenue)} a year at ${c.margin.toFixed(1)}% margin, ${term(c)}. Regional VP ${c.rvp}, project leader ${c.leader}.`,
      ...(mv && mv.sigs.length ? [`What changed this morning: ${mv.sigs.map((x) => `${x.s.name.toLowerCase()} went from ${x.from} to ${x.to} (${x.raw})`).join('; ')}.`] : []),
      ...(flags.length ? [`Red flag: ${flags.map((id) => SIGNALS.find((x) => x.id === id)!.name.toLowerCase()).join('; ')}. A red flag at its worst rates the project at least 3, whatever the weights say.`] : []),
      ...(d > 0.08 && roseOn(c, w).length && !(mv && mv.sigs.length) ? [`Why it went up in the last 90 days: ${roseOn(c, w).slice(0, 3).map((x) => `${x.s.name.toLowerCase()} went from ${x.from} to ${x.to} (${x.raw}${x.wasRaw ? `, was ${x.wasRaw}` : ''})`).join('; ')}.`] : []),
      dr.length ? `Why it scores ${f1(s)}: ${plural(dr.length, 'signal')} at 3 or 4. The ones that carry most are in the table.` : 'No signal stands at 3 or 4.',
      plan.length ? `What to do: ${plural(plan.length, 'action')} in the plan, first “${plan[0].text.replace(/\.$/, '')}” (${plan[0].owner}, by ${plan[0].due}). If the plan lands the score goes from ${f1(eff.from)} to ${f1(eff.to)}.` : 'There is no open action for this site.',
    ],
    table: dr.length ? { cols: ['Signal', 'Reading', 'Scores', 'Factor'], rows: dr.slice(0, 8).map((x) => [x.s.name, x.raw, String(Math.round(x.v)), x.f.name]), num: [2] } : undefined,
    sources: [...srcOf(dr.slice(0, 4).map((x) => x.s.id)), MASTER, SCORECARD],
    follow: [`What is the mitigation plan for ${n}?`, `What is at stake at ${n}?`, 'For which projects did the risk increase in the last 90 days, and why?'],
  }
}
function sitePlan(c: Contract, w: When): AskAnswer {
  const all = planFor(c, w), plan = all.filter((p) => !p.fixed && !p.later), eff = planEffect(c, w), n = shortSite(c)
  return {
    key: `plan:${c.id}`,
    head: plan.length ? `**${n} has ${plural(plan.length, 'action')} in its mitigation plan.** If they land, the score goes from ${f1(eff.from)} to ${f1(eff.to)}${eff.rTo < eff.rFrom ? ` and the rating from ${eff.rFrom} to ${eff.rTo}` : ''}.` : `${n} has no signal at 3 or 4 that an action can move, so there is no plan to run.`,
    points: [`Each action is written for this site from its own records, and it stands whether or not the score changed.`, ...(all.some((p) => p.fixed) ? [`${plural(all.filter((p) => p.fixed).length, 'signal')} at 3 or 4 are facts of the site or the contract (the state, the scope) and no action moves them.`] : []), `Owner of the plan: ${c.rvp}, Regional VP, with ${c.leader}, project leader.`],
    table: plan.length ? { cols: ['For the signal', 'Action', 'Owner', 'By', 'Moves it'], rows: plan.map((p) => [p.s.name, p.text, p.owner, p.due, `${Math.round(p.v)} to ${p.to}`]) } : undefined,
    sources: [...srcOf(plan.slice(0, 3).map((p) => p.s.id)), { kind: 'mail', name: 'Project and client mail' }, SCORECARD],
    follow: [`What is the status of ${n} and why?`, 'Which actions are due first?', 'How many sites have a mitigation plan, and what happens to the risk if the plans land?'],
  }
}
function siteStake(c: Contract, w: When): AskAnswer {
  const n = shortSite(c), mg = (c.revenue * c.margin) / 100
  return {
    key: `stake:${c.id}`,
    head: `**${n} bills ${m1(c.revenue)} a year at ${c.margin.toFixed(1)}% margin, about ${m1(mg)} of margin a year.** The contract is ${c.evergreen ? 'evergreen: the client can end it on notice' : `in force until ${c.end}, ${c.monthsLeft} months from now`}. It rates ${R(c, w)} on risk, so its priority is “${priorityOf(c, w).toLowerCase()}”.`,
    points: [`Termination for convenience: ${c.tfc ? 'yes, the client can end without cause' : 'no'}.`, `Scope: ${c.scopes.join(', ').toLowerCase()}. ${c.staff} staff${c.union ? ', unionized' : ''}.`, `${c.homes.toLocaleString('en-US')} homes within two miles of the plant.`],
    sources: [MASTER, { kind: 'document', name: 'The signed contract and its amendments' }, { kind: 'table', name: 'fin.contract_pnl' }],
    follow: [`What is the status of ${n} and why?`, 'Which contracts come up for renewal in the next 18 months, and which of those are high risk?', `What is the mitigation plan for ${n}?`],
  }
}
function compare(a: Contract, b: Contract, w: When): AskAnswer {
  const fs = activeFactors(), A = shortSite(a), B = shortSite(b)
  const rows = fs.map((f) => ({ f, x: factorScore(a, f.id, w) ?? 1, y: factorScore(b, f.id, w) ?? 1 })).sort((p, q) => Math.abs(q.x - q.y) - Math.abs(p.x - p.y))
  return {
    key: 'compare',
    head: `**${A} scores ${f1(S(a, w))} (rating ${R(a, w)}) and ${B} scores ${f1(S(b, w))} (rating ${R(b, w)}).** They differ most on ${rows[0].f.name.toLowerCase()}: ${f1(rows[0].x)} against ${f1(rows[0].y)}.`,
    points: [`${A}: ${m1(a.revenue)} a year, ${term(a)}, ${a.region}. Main reason: ${reasonOf(a, w)}.`, `${B}: ${m1(b.revenue)} a year, ${term(b)}, ${b.region}. Main reason: ${reasonOf(b, w)}.`],
    table: { cols: ['Factor', A, B, 'Gap'], rows: rows.map((r) => [r.f.name, f1(r.x), f1(r.y), (r.x - r.y >= 0 ? '+' : '−') + Math.abs(r.x - r.y).toFixed(2)]), num: [1, 2, 3] },
    sources: [SCORECARD, MASTER], follow: [`What is the status of ${A} and why?`, `What is the status of ${B} and why?`, 'Which ten projects carry the most risk?'],
  }
}

/* ------------------------------------------------------------------ the portfolio */
type Run = (w: When, t: string) => AskAnswer
const INTENTS: { re: RegExp; run: Run }[] = []
const on = (re: RegExp, run: Run) => INTENTS.push({ re, run })

on(/safety observation|near miss|leading indicator/i, (w) => {
  const cs = CONTRACTS.map((c) => { const r = band(c, 'os3', w), u = hsh(`obs${c.id}`); const days = r >= 4 ? 16 + Math.floor(u * 58) : r === 3 ? (u < 0.4 ? 15 + Math.floor(u * 60) : 2 + Math.floor(u * 11)) : u < 0.03 ? 15 + Math.floor(u * 200) : Math.floor(u * 12); return { c, days } }).filter((x) => x.days > 14).sort((a, b) => b.days - a.days)
  const d0 = asOf(w)
  return {
    key: 'obs',
    head: `**${plural(cs.length, 'project')} have not recorded a safety observation in the last two weeks.** The longest gap is ${shortSite(cs[0].c)}: ${cs[0].days} days. ${cs.filter((x) => R(x.c, w) >= 3).length} of them already rate 3 or 4.`,
    points: ['A site that stops recording observations has usually stopped looking, not stopped having them. On your lost-time injuries of the last three years, the site had gone quiet for three weeks or more before most of them.', 'On the scorecard this feeds the signal “Safety observations per employee” in Workplace Safety.'],
    table: projTable(cs.map((x) => x.c), w, [{ col: 'Last observation', of: (c) => { const x = cs.find((y) => y.c.id === c.id)!; return `${day(new Date(d0.getTime() - x.days * 864e5))} · ${x.days} days ago` } }, { col: 'This year, per employee', of: (c) => raw(c, 'os3', w).replace(' per employee', '') }]),
    sources: [{ kind: 'table', name: 'ehs.observation' }, { kind: 'table', name: 'hr.roster' }, SCORECARD],
    follow: ['Which sites have the highest lost-time injury rate?', 'Where is workplace safety the weakest?', `What is the status of ${shortSite(cs[0].c)} and why?`],
  }
})
on(/how (is|does).*(score|rating).*(made|work|calculated)|how do you score/i, () => ({
  key: 'how',
  head: `**Every project gets one risk score from 1 (good) to 4 (bad), made from ${likelihoodSignals().length} signals in ${activeFactors().length} factors.**`,
  points: ['Each signal scores 1 to 4 on a written rule. A factor is the weighted average of its signals.', `The factors are weighted into two halves, what we control and what we do not, and the project score is the ${DESIGN.rule === 'max' ? 'higher' : 'average'} of the two.`, 'Under 1.5 rates 1, under 2.5 rates 2, under 3.5 rates 3, the rest 4.', `Red flags: ${SIGNALS.filter((s) => DESIGN.flag[s.id] && DESIGN.on[s.id]).map((s) => s.name.toLowerCase()).join('; ') || 'none set'}. One of these at its worst rates a project at least 3.`, ...(impactOn() ? ['What is at stake (revenue, margin, months left) is read beside the score. It sets which high-risk projects come first.'] : []), `The scoring is ${DESIGN.source === 'uploaded' ? `from your template${DESIGN.tplName ? ` (${DESIGN.tplName})` : ''}, used as written` : 'the one you agreed on the goal'}. You can change it on the goal's Plan tab.`],
  table: { cols: ['Factor', 'Group', 'Signals', 'Portfolio average'], rows: factorAverages('before').map((x) => [x.f.name, x.f.group === 'internal' ? 'What we control' : 'What we do not control', String(SIGNALS.filter((s) => s.f === x.f.id && DESIGN.on[s.id]).length), f1(x.avg)]), num: [2, 3] },
  sources: [SCORECARD], follow: ['Which factor drives the most risk across the portfolio?', 'Which red flags are raised today?', 'What data is missing from the scorecard?'],
}))
on(/red flag/i, (w) => {
  const fl = SIGNALS.filter((s) => DESIGN.flag[s.id] && DESIGN.on[s.id]), cs = CONTRACTS.filter((c) => flagsOf(c, w).length)
  return { key: 'flags', head: cs.length ? `**${plural(cs.length, 'project')} have a red flag raised today**, worth ${m1(rev(cs))} a year. A red flag at its worst rates the project at least 3, whatever the weights say.` : 'No red flag is raised today.', points: [`Red flags on your scorecard: ${fl.map((s) => s.name.toLowerCase()).join('; ') || 'none'}.`], table: cs.length ? projTable(cs.sort((a, b) => S(b, w) - S(a, w)), w, [{ col: 'Red flag', of: (c) => flagsOf(c, w).map((id) => `${SIGNALS.find((x) => x.id === id)!.name}: ${raw(c, id, w)}`).join('; ') }]) : undefined, sources: [...srcOf(fl.map((s) => s.id)), SCORECARD], follow: ['Where are lawsuits threatened or filed?', 'Where is the client talking about in-house operation or a re-bid?', 'Which projects need action now?'] }
})
on(/data.*(missing|gap)|missing.*data|not (found|connected)|data coverage|no (data|source)|without (data|a source)|lack(s|ing)? data/i, () => {
  const miss = SIGNALS.filter((s) => NOT_FOUND[s.id]), part = [['Client survey score for the site', '268 of 300 projects matched to a survey answer by client name'], ['Community investment trend, five years', 'Two years are loaded, not five']]
  return { key: 'gaps', head: `**${plural(miss.length, 'signal')} ${miss.length === 1 ? 'has' : 'have'} no source in the connected data, and two more are only partly covered.** Everything else is read at every check.`, points: ['A signal with no source stays out of the score until its source is connected. A signal that is partly covered is scored where it can be; the other signals of its factor carry the weight elsewhere.'], table: { cols: ['Signal', 'What is missing'], rows: [...miss.map((s) => [s.name, NOT_FOUND[s.id]]), ...part] }, sources: [SCORECARD], follow: ['How is the risk score made?', 'Which clients gave us a low survey score?', 'Which factor drives the most risk across the portfolio?'] }
})
on(/(caught|predict|foreseen|seen).*(lost|loss)|lost.*(caught|scor|contract)|back.?test/i, () => ({
  key: 'lost', head: `**The scorecard as it stands would have rated ${lostCaught()} of the ${LOST.length} contracts lost at renewal at 3 or more a year before the loss.**`,
  points: LOST.map((l) => `${l.site}, ${l.state}, lost ${l.lost} (${l.how.toLowerCase()}): would have rated ${lostOn(l).rated}. What came first: ${l.moved.slice(0, 2).join('; ').toLowerCase()}.`),
  table: { cols: ['Contract', 'Lost', 'How', 'Revenue a year', 'Would have rated'], rows: LOST.map((l) => [l.site, l.lost, l.how, m1(l.revenue), String(lostOn(l).rated)]), num: [3, 4] },
  sources: [{ kind: 'document', name: 'The three loss reviews' }, SCORECARD], follow: ['Where is the client talking about in-house operation or a re-bid?', 'Where did the key client contact change?', 'Where are competitors active?'],
}))
on(/factor.*(drive|most|worst|biggest)|what drives|where does the risk come from/i, (w) => {
  const xs = factorAverages(w).sort((a, b) => b.avg - a.avg)
  return { key: 'factors', head: `**${xs[0].f.name} is the weakest factor across the portfolio, at ${f1(xs[0].avg)} on average**, followed by ${xs[1].f.name.toLowerCase()} (${f1(xs[1].avg)}) and ${xs[2].f.name.toLowerCase()} (${f1(xs[2].avg)}).`, points: ['A factor that is weak everywhere is a problem of the business, not of a site. A factor that is weak in a few places is a problem of those sites.'], bars: xs.map((x) => ({ label: x.f.name, value: x.avg, text: `${f1(x.avg)} · ${CONTRACTS.filter((c) => (factorScore(c, x.f.id, w) ?? 0) >= 2.5).length} projects at 2.5 or more` })), sources: [SCORECARD], follow: [`Where is ${xs[0].f.name.toLowerCase()} the weakest?`, 'Which region carries the most risk?', 'How is the risk score made?'] }
})
on(/mitigation plan.*(land|how many)|how many.*plan|if the plans? land|(need|have|with) a (mitigation )?plan|which.*mitigation plans?/i, (w) => {
  const withPlan = CONTRACTS.filter((c) => planFor(c, w).some((p) => !p.fixed && !p.later)), h0 = high(w), after = h0.filter((c) => planEffect(c, w).rTo >= 3)
  return { key: 'plans', head: `**${plural(withPlan.length, 'site')} have a mitigation plan: every site with a signal at 3 or 4 that an action can move.** If the plans of the ${h0.length} high-risk projects land, ${h0.length - after.length} of them come down to a rating of 2 and ${after.length} stay at 3 or more.`, points: ['A plan stands whether or not the score moved. Each action is written for the site from its own records.', `The projects that stay high are held there by facts no action moves: the state, the scope, a consent order already signed.`], table: projTable(h0.sort((a, b) => planEffect(b, w).from - planEffect(b, w).to - (planEffect(a, w).from - planEffect(a, w).to)).slice(0, 12), w, [{ col: 'Actions', of: (c) => String(planFor(c, w).filter((p) => !p.fixed && !p.later).length), num: true }, { col: 'If the plan lands', of: (c) => f1(planEffect(c, w).to), num: true }]), sources: [SCORECARD, { kind: 'mail', name: 'Project and client mail' }], follow: ['Which actions are due first?', 'Who owns the most mitigation actions?', 'Which projects need action now?'] }
})
on(/actions?.*(due|first|this week|next)|what.*do first/i, (w) => {
  const acts = high(w).filter((c) => priorityOf(c, w) === 'Act now').flatMap((c) => planFor(c, w).filter((p) => !p.fixed && !p.later).slice(0, 2).map((p) => ({ c, p }))).sort((a, b) => Date.parse(`${a.p.due} 2026`) - Date.parse(`${b.p.due} 2026`) || S(b.c, w) - S(a.c, w)).slice(0, 14)
  return { key: 'due', head: `**These are the ${acts.length} actions that come first: the top two of each project that needs action now, by date.**`, points: ['Each one names its owner. Nothing is sent to an owner until the plan is assigned on the project.'], table: { cols: ['Project', 'Action', 'Owner', 'By', 'For the signal'], rows: acts.map((x) => [shortSite(x.c), x.p.text, x.p.owner, x.p.due, x.p.s.name]), ids: acts.map((x) => x.c.id) }, sources: [SCORECARD, { kind: 'mail', name: 'Project and client mail' }], follow: ['Who owns the most mitigation actions?', 'Which projects need action now?', 'How many sites have a mitigation plan, and what happens to the risk if the plans land?'] }
})
on(/who owns.*(most|action)|owner.*most/i, (w) => {
  const m = new Map<string, { n: number; sites: Set<string> }>()
  for (const c of high(w)) for (const p of planFor(c, w).filter((x) => !x.fixed && !x.later)) { const k = p.owner; const e = m.get(k) ?? { n: 0, sites: new Set<string>() }; e.n += 1; e.sites.add(c.id); m.set(k, e) }
  const xs = [...m.entries()].sort((a, b) => b[1].n - a[1].n).slice(0, 10)
  return { key: 'owners', head: `**${xs[0][0]} owns the most mitigation actions on high-risk projects: ${xs[0][1].n} actions across ${plural(xs[0][1].sites.size, 'site')}.**`, points: ['Counted on the projects that rate 3 or 4 today.'], table: { cols: ['Owner', 'Actions', 'Sites'], rows: xs.map(([k, v]) => [k, String(v.n), String(v.sites.size)]), num: [1, 2] }, sources: [SCORECARD], follow: ['Which actions are due first?', 'Which Regional VP has the most high-risk contracts?', 'Which projects need action now?'] }
})
/* questions about one signal: the wording a leader uses, the signal behind it, and from which score it counts */
const SIG: [RegExp, string, number, string, string[]][] = [
  [/lost.?time|injur/i, 'os1', 3, 'have a lost-time injury rate of 1 or more per 200,000 hours over the last twelve months', ['Which projects have not recorded a safety observation in the last two weeks?', 'Where is workplace safety the weakest?']],
  [/miss.*sampl|sampl.*miss/i, 'en2', 2, 'missed a required sample in the last three years', ['Which projects received a notice of violation?', 'Which sites are under a consent order?']],
  [/notice.*violation|\bnov\b|violation/i, 'en3', 2, 'received a notice of violation in the last three years', ['Which sites are under a consent order?', 'Which projects missed required samples?']],
  [/consent order/i, 'li2', 4, 'are under a consent order', ['Where are lawsuits threatened or filed?', 'Which projects received a notice of violation?']],
  [/permit.*renew|tighter limit|draft limit/i, 'en6', 3, 'have a permit up for renewal with tighter limits', ['Which projects received a notice of violation?', 'Which plants are over the PFAS limits?']],
  [/pfas/i, 'iq2', 3, 'are at or over the PFAS limits in drinking water', ['Which permits are up for renewal with tighter limits?', 'What data is missing from the scorecard?']],
  [/open.*(position|vacanc)|vacanc|positions? open|60 days/i, 'st1', 4, 'have a position open for more than 60 days', ['Where is overtime above 13% of payroll?', 'Which sites lack a licensed operator or a backup?']],
  [/overtime/i, 'st4', 4, 'run overtime above 13% of payroll', ['Which sites have positions open for more than 60 days?', 'Where is staff retention under 75%?']],
  [/licen[cs]ed|certified|operator.*backup|backup/i, 'st2', 3, 'lack a licensed operator or a backup the contract requires', ['Which sites depend on one key person?', 'Which sites have positions open for more than 60 days?']],
  [/site manager|new manager|manager tenure/i, 'st5', 3, 'have a site manager in the role for under two years', ['Which sites depend on one key person?', 'Where is staff retention under 75%?']],
  [/retention|(?<!council )turnover|attrition|staff.*leav|people leaving/i, 'st3', 4, 'kept under 75% of their staff over the year', ['Where is overtime above 13% of payroll?', 'Which sites have a new site manager?']],
  [/key.?person|depend.*one/i, 'st6', 3, 'depend on one person for a licence the contract requires', ['Which sites lack a licensed operator or a backup?', 'Which sites have a new site manager?']],
  [/planned maintenance|maintenance.*(behind|late|time)|\bpm\b/i, 'in4', 3, 'close under 90% of planned maintenance on time', ['Where is the plant oldest?', 'Which factor drives the most risk across the portfolio?']],
  [/asset age|oldest|old plant/i, 'in7', 3, 'run critical assets older than 35 years on average', ['Which sites are behind on planned maintenance?', 'What data is missing from the scorecard?']],
  [/receivable|\bdso\b|days sales|paid late|pay(s|ing)? (us )?late|not paid|unpaid|owes? us|collect/i, 'cr2', 4, 'have receivables older than 90 days', ['Where are change orders unbilled or in dispute?', 'Which contracts run under their budget margin?']],
  [/under.*budget|budget margin|margin against/i, 'fp1', 3, 'run 2 points or more under their budget margin', ['Which high-risk contracts are also losing margin?', 'Where are change orders unbilled or in dispute?']],
  [/change order/i, 'fp4', 3, 'have change orders unbilled or in dispute above 1% of the annual fee', ['Which contracts paid penalties in the last three years?', 'Which projects have receivables older than 90 days?']],
  [/penalt|liquidated/i, 'fp5', 2, 'paid a penalty or liquidated damages in the last three years', ['Which contracts carry fixed-price exposure on energy and chemicals?', 'Which contracts run under their budget margin?']],
  [/fixed.?price|energy.*chemical|pass.?through/i, 'cr7', 3, 'carry fixed-price exposure on energy, chemicals or biosolids', ['Which contracts paid penalties in the last three years?', 'Which contracts run under their budget margin?']],
  [/in.?house|re.?bid|rebid/i, 'cp3', 3, 'have talk of in-house operation or a re-bid on the client side', ['Where did the key client contact change?', 'Where are competitors active?']],
  [/client contact|contact.*chang|new (director|client lead|city manager)/i, 'cp1', 3, 'had a key client contact change in the last 18 months', ['Which clients have an election or council turnover coming?', 'Which clients gave us a low survey score?']],
  [/election|council turnover|ballot/i, 'cp2', 3, 'have an election or council turnover coming for the body that owns the contract', ['Where did the key client contact change?', 'Where is the client talking about in-house operation or a re-bid?']],
  [/competitor|rival|competition/i, 'cl2', 3, 'have a competitor active with the client or winning nearby', ['Where is the client talking about in-house operation or a re-bid?', 'Which contracts come up for renewal in the next 18 months, and which of those are high risk?']],
  [/media|press|news coverage/i, 'co2', 3, 'have mostly negative local media coverage', ['Which sites get the most odor complaints?', 'Where are lawsuits threatened or filed?']],
  [/odor|odour|smell/i, 'co1', 3, 'had four or more odor complaints in twelve months', ['Where is local media coverage mostly negative?', 'Where are lawsuits threatened or filed?']],
  [/survey|nps|satisf|unhappy/i, 'cu1', 3, 'got a client survey score of 6 or lower', ['Where did the key client contact change?', 'Which clients have an election or council turnover coming?']],
  [/escalat/i, 'cp6', 3, 'had client escalations above the project leader', ['Which clients gave us a low survey score?', 'Where did the key client contact change?']],
  [/flood|storm/i, 'rs1', 3, 'sit in a flood zone or have a record of storm damage', ['What data is missing from the scorecard?', 'Which factor drives the most risk across the portfolio?']],
  [/cyber/i, 'rs3', 3, 'have open findings on the cybersecurity of plant controls', ['Which sites are behind on planned maintenance?', 'Which factor drives the most risk across the portfolio?']],
  [/overflow|sso|cso/i, 'en5', 3, 'reported three or more sewer overflows in twelve months', ['Which projects received a notice of violation?', 'Which sites are under a consent order?']],
]
for (const [re, sid, min, phrase, follow] of SIG) on(re, (w) => sigList(sid, min, w, `${/^(are|have|had|got|sit|run|kept|paid|lack|carry|close|depend|missed|received|reported)/.test(phrase) ? '' : ''}${phrase}`, [...follow, 'Which projects need action now?']))
on(/lawsuit|litigation|sued|legal action|demand letter/i, (w) => { const cs = CONTRACTS.filter((c) => band(c, 'li3', w) >= 3 || band(c, 'li1', w) >= 3).sort((a, b) => S(b, w) - S(a, w)); return { key: 'legal', head: `**${plural(cs.length, 'project')} have a lawsuit filed or threatened**, worth ${m1(rev(cs))} a year. ${cs.filter((c) => band(c, 'li3', w) >= 4).length} have a demand letter or a pre-suit notice in hand.`, points: ['A demand letter is a red flag on your scorecard: it rates the project at least 3 by itself.'], table: projTable(cs, w, [{ col: 'Lawsuits filed', of: (c) => raw(c, 'li1', w) }, { col: 'Lawsuits threatened', of: (c) => raw(c, 'li3', w) }]), sources: [...srcOf(['li1', 'li3']), SCORECARD], follow: ['Which sites are under a consent order?', 'Where is local media coverage mostly negative?', 'Which red flags are raised today?'] } })
on(/(risk|score).*(increase|rose|rise|went up|gone up|up)|rising|\brose\b|\brisen\b|went up|gone up|going up|moved up|climb|worsen|g[eo]t(ting)? worse|(got|gotten|became|become) riskier|deteriorat|increase.*risk|rise in risk|largest rise/i, (w, t) => {
  if (/region/i.test(t)) return regionTrend(w)
  const up = CONTRACTS.filter((c) => deltaOf(c, w) > 0.08).sort((a, b) => deltaOf(b, w) - deltaOf(a, w))
  if (/largest|biggest|most/i.test(t) && up.length) { const c = up[0]; const a = siteStatus(c, w); return { ...a, key: 'top-riser', head: `**The largest rise is ${shortSite(c)}: up ${deltaOf(c, w).toFixed(2)} in 90 days, to ${f1(S(c, w))}.** ${a.head.replace(/\*\*/g, '')}` } }
  const onlyHigh = /high.?risk.*(still|worse)|still getting worse/i.test(t), list = onlyHigh ? up.filter((c) => R(c, w) >= 3) : up
  return { key: onlyHigh ? 'high-rising' : 'risers', head: `**${plural(list.length, 'project')}${onlyHigh ? ' that already rate 3 or 4' : ''} rose in the last 90 days**${onlyHigh ? '' : `; ${list.filter((c) => R(c, w) >= 3).length} of them now rate 3 or 4`}. ${list.length ? `The largest rise is ${shortSite(list[0])} (+${deltaOf(list[0], w).toFixed(2)}).` : ''}`, points: list.slice(0, 3).map((c) => `${shortSite(c)}, ${c.region}: ${f1(S(c, w) - deltaOf(c, w))} to ${f1(S(c, w))}. ${reasonOf(c, w)}.`), table: projTable(list, w, [{ col: '90 days ago', of: (c) => f1(S(c, w) - deltaOf(c, w)), num: true }, { col: 'Change', of: (c) => `+${deltaOf(c, w).toFixed(2)}`, num: true }, { col: 'Main reason', of: (c) => reasonOf(c, w) }]), sources: [SCORECARD, ...srcOf(list.slice(0, 3).flatMap((c) => driversOf(c, w, 1).map((d) => d.s.id)))], follow: [...(list.length ? [`What is the status of ${shortSite(list[0])} and why?`] : []), 'Which projects improved in the last 90 days?', 'Which projects moved into high risk?'] }
})
on(/improv|fell|came down|got better|getting better|risk.*(decrease|down)|safer.*project/i, (w) => {
  const dn = CONTRACTS.filter((c) => deltaOf(c, w) < -0.08).sort((a, b) => deltaOf(a, w) - deltaOf(b, w))
  return { key: 'fallers', head: `**${plural(dn.length, 'project')} improved in the last 90 days.** The largest fall is ${shortSite(dn[0])} (−${Math.abs(deltaOf(dn[0], w)).toFixed(2)}, now ${f1(S(dn[0], w))}).`, points: ['A fall is a reading that got better: a position filled, a complaint closed, a quarter in compliance.'], table: projTable(dn, w, [{ col: '90 days ago', of: (c) => f1(S(c, w) - deltaOf(c, w)), num: true }, { col: 'Change', of: (c) => `−${Math.abs(deltaOf(c, w)).toFixed(2)}`, num: true }]), sources: [SCORECARD], follow: ['For which projects did the risk increase in the last 90 days, and why?', 'Is the portfolio getting riskier or safer?', 'Which projects need action now?'] }
})
on(/since yesterday|this morning|last check|morning check|check (find|found|show)|last night|overnight|today.*chang|what changed|what moved/i, (w) => {
  const mv = w === 'after' ? movers() : []
  if (!mv.length) return { key: 'morning', head: '**No rating moved at the last check, on 19 November.** Every signal was read for all 300 projects and no project crossed a rating line.', points: ['The next check is tomorrow at 06:00. If a score rises I follow your rules and tell you.'], sources: [SCORECARD], follow: ['For which projects did the risk increase in the last 90 days, and why?', 'Which projects need action now?', 'What should I worry about this week?'] }
  return { key: 'morning', head: `**${plural(mv.length, 'project')} changed at this morning's check; ${mv.filter((m) => m.r1 > m.r0).length} moved up a rating.**`, points: mv.map((m) => `${shortSite(m.c)}: ${f1(m.s0)} to ${f1(m.s1)}${m.r1 > m.r0 ? `, rating ${m.r0} to ${m.r1}` : ', rating held'}. ${m.sigs.map((x) => `${x.s.name}: ${x.raw}`).join('; ')}.`), table: projTable(mv.map((m) => m.c), w, [{ col: 'Yesterday', of: (c) => f1(S(c, 'before')), num: true }, { col: 'What changed', of: (c) => reasonOf(c, w) }]), sources: [SCORECARD, ...srcOf(mv.flatMap((m) => m.sigs.map((x) => x.s.id)))], follow: mv.slice(0, 2).map((m) => `What is the status of ${shortSite(m.c)} and why?`).concat('Which actions are due first?') }
})
on(/moved into high|crossed|became high|newly high/i, (w) => {
  const cs = CONTRACTS.filter((c) => R(c, w) >= 3 && ratingOf(S(c, w) - deltaOf(c, w)) < 3).sort((a, b) => deltaOf(b, w) - deltaOf(a, w))
  return { key: 'crossed', head: cs.length ? `**${plural(cs.length, 'project')} moved into high risk in the last 90 days**: they rated 2 then and rate 3 now. Together ${m1(rev(cs))} a year.` : 'No project moved into high risk in the last 90 days.', points: cs.slice(0, 3).map((c) => `${shortSite(c)}: ${reasonOf(c, w)}.`), table: cs.length ? projTable(cs, w, [{ col: '90 days ago', of: (c) => f1(S(c, w) - deltaOf(c, w)), num: true }, { col: 'Main reason', of: (c) => reasonOf(c, w) }]) : undefined, sources: [SCORECARD], follow: ['Which projects need action now?', 'For which projects did the risk increase in the last 90 days, and why?', 'Which actions are due first?'] }
})
on(/riskier or safer|portfolio.*(trend|getting|direction)|overall trend/i, (w) => {
  const t = Array.from({ length: 12 }, (_, i) => CONTRACTS.reduce((n, c) => n + trendOf(c, w)[i], 0) / CONTRACTS.length), up = CONTRACTS.filter((c) => deltaOf(c, w) > 0.08).length, dn = CONTRACTS.filter((c) => deltaOf(c, w) < -0.08).length
  const d = t[11] - t[8]
  return { key: 'trend', head: `**The portfolio is ${Math.abs(d) < 0.005 ? 'holding steady' : d > 0 ? 'getting slightly riskier' : 'getting slightly safer'}: the average score went from ${t[8].toFixed(3)} to ${t[11].toFixed(3)} in 90 days.** ${up} projects rose, ${dn} fell and ${CONTRACTS.length - up - dn} held.`, points: ['The average hides the movers. A few projects carry the change; the dashboard shows each as a line under “Direction of travel”.'], bars: ['Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'].map((m, i) => ({ label: m, value: t[i], text: t[i].toFixed(3) })), sources: [SCORECARD], follow: ['For which projects did the risk increase in the last 90 days, and why?', 'Which region got worse over the last 90 days?', 'Which projects improved in the last 90 days?'] }
})
const regionTrend = (w: When): AskAnswer => {
  const xs = REGIONS.map((r) => { const cs = CONTRACTS.filter((c) => c.region === r.name); return { r, d: cs.reduce((n, c) => n + deltaOf(c, w), 0) / cs.length, up: cs.filter((c) => deltaOf(c, w) > 0.08).length, n: cs.length } }).sort((a, b) => b.d - a.d)
  return { key: 'region-trend', head: `**${xs[0].r.name} got worse the most over the last 90 days: its average score moved by ${xs[0].d >= 0 ? '+' : '−'}${Math.abs(xs[0].d).toFixed(3)}, with ${plural(xs[0].up, 'project')} rising.**`, points: [`Regional VP: ${xs[0].r.rvp}.`], table: { cols: ['Region', 'Regional VP', 'Projects', 'Rose', 'Average change'], rows: xs.map((x) => [x.r.name, x.r.rvp, String(x.n), String(x.up), `${x.d >= 0 ? '+' : '−'}${Math.abs(x.d).toFixed(3)}`]), num: [2, 3, 4] }, sources: [SCORECARD], follow: ['Which region carries the most risk?', 'For which projects did the risk increase in the last 90 days, and why?', 'Which Regional VP has the most high-risk contracts?'] }
}
on(new RegExp(`\\b(${REGIONS.map((r) => r.name).join('|')})\\b`, 'i'), (w, t) => {
  const r = REGIONS.find((x) => new RegExp(`\\b${x.name}\\b`, 'i').test(t))!, cs = CONTRACTS.filter((c) => c.region === r.name).sort((a, b) => S(b, w) - S(a, w)), h = cs.filter((c) => R(c, w) >= 3), up = cs.filter((c) => deltaOf(c, w) > 0.08)
  return { key: `region:${r.name}`, head: `**${r.name} has ${plural(cs.length, 'project')}; ${h.length} of them rate 3 or 4, worth ${m1(rev(h))} a year.** ${plural(up.length, 'project')} rose in the last 90 days. Regional VP: ${r.rvp}.`, points: h.slice(0, 3).map((c) => `${shortSite(c)}: ${reasonOf(c, w)}.`), table: projTable(cs, w), sources: [SCORECARD, MASTER], follow: ['Which region carries the most risk?', 'Which region got worse over the last 90 days?', `What is the status of ${shortSite(cs[0])} and why?`] }
})
on(/regional vp|\bvp\b|which leader/i, (w) => {
  const xs = REGIONS.map((r) => { const cs = CONTRACTS.filter((c) => c.rvp === r.rvp), h = cs.filter((c) => R(c, w) >= 3); return { r, n: cs.length, h, act: cs.filter((c) => priorityOf(c, w) === 'Act now').length } }).sort((a, b) => b.h.length - a.h.length)
  return { key: 'vps', head: `**${xs[0].r.rvp}, ${xs[0].r.name}, has the most high-risk contracts: ${xs[0].h.length} of ${xs[0].n}, worth ${m1(rev(xs[0].h))} a year.** ${xs[0].act} of them need action now.`, table: { cols: ['Regional VP', 'Region', 'Contracts', 'Rated 3 or 4', 'Act now', 'Revenue at risk'], rows: xs.map((x) => [x.r.rvp, x.r.name, String(x.n), String(x.h.length), String(x.act), m1(rev(x.h))]), num: [2, 3, 4, 5] }, sources: [SCORECARD, MASTER], follow: ['Which region carries the most risk?', 'Who owns the most mitigation actions?', 'Which projects need action now?'] }
})
on(/\bregions?\b.*(most|worst|carr|highest)|which region\b|by region\b/i, (w, t) => {
  if (/worse|90 days|trend/i.test(t)) return regionTrend(w)
  const xs = REGIONS.map((r) => { const cs = CONTRACTS.filter((c) => c.region === r.name), h = cs.filter((c) => R(c, w) >= 3); return { r, n: cs.length, h, share: rev(h) / rev(cs) } }).sort((a, b) => rev(b.h) - rev(a.h))
  return { key: 'regions', head: `**${xs[0].r.name} carries the most risk: ${plural(xs[0].h.length, 'project')} at 3 or 4, worth ${m1(rev(xs[0].h))} a year, ${Math.round(xs[0].share * 100)}% of the region's revenue.**`, points: [`Regional VP: ${xs[0].r.rvp}.`], bars: xs.map((x) => ({ label: x.r.name, value: rev(x.h) / 1e6, text: `${m1(rev(x.h))} · ${x.h.length} of ${x.n} projects` })), table: { cols: ['Region', 'Regional VP', 'Projects', 'Rated 3 or 4', 'Revenue at risk', 'Share of the region'], rows: xs.map((x) => [x.r.name, x.r.rvp, String(x.n), String(x.h.length), m1(rev(x.h)), `${Math.round(x.share * 100)}%`]), num: [2, 3, 4, 5] }, sources: [SCORECARD, MASTER], follow: ['Which Regional VP has the most high-risk contracts?', 'Which region got worse over the last 90 days?', 'Which ten projects carry the most risk?'] }
})
on(/renew|up for|expir|come up|ending|18 months/i, (w) => {
  const cs = CONTRACTS.filter((c) => !c.evergreen && c.monthsLeft <= 18).sort((a, b) => a.monthsLeft - b.monthsLeft), h = cs.filter((c) => R(c, w) >= 3)
  return { key: 'renew', head: `**${plural(cs.length, 'contract')} come up in the next 18 months, worth ${m1(rev(cs))} a year. ${h.length} of them rate 3 or 4: ${m1(rev(h))} a year that is both at risk and up for decision.**`, points: ['These are the ones that need a renewal plan now, not at the re-bid. The high-risk ones are listed first.', `Evergreen contracts are not in this count: ${CONTRACTS.filter((c) => c.evergreen).length} contracts can be ended on notice at any time.`], table: projTable([...h, ...cs.filter((c) => R(c, w) < 3)].slice(0, 20), w, [{ col: 'Ends', of: (c) => c.end }, { col: 'Months left', of: (c) => String(c.monthsLeft), num: true }]), sources: [MASTER, { kind: 'document', name: 'The signed contracts' }, SCORECARD], follow: ['Where is the client talking about in-house operation or a re-bid?', 'Where are competitors active?', 'Where did the key client contact change?'] }
})
on(/(ten|10) largest|largest contracts|biggest contracts/i, (w) => { const cs = [...CONTRACTS].sort((a, b) => b.revenue - a.revenue).slice(0, 10), h = cs.filter((c) => R(c, w) >= 3); return { key: 'largest', head: `**Of the ten largest contracts (${m1(rev(cs))} a year together), ${h.length ? `${h.length} rate 3 or 4: ${h.map(shortSite).join(', ')}` : 'none rates 3 or 4'}.**`, table: projTable(cs, w, [{ col: 'Term', of: term }, { col: '90 days', of: (c) => { const d = deltaOf(c, w); return d > 0.08 ? `+${d.toFixed(2)}` : d < -0.08 ? `−${Math.abs(d).toFixed(2)}` : 'held' }, num: true }]), sources: [MASTER, SCORECARD], follow: ['How much of our revenue sits in high-risk contracts?', 'Which projects need action now?', 'Which contracts come up for renewal in the next 18 months, and which of those are high risk?'] } })
on(/margin.*at risk|how much margin/i, (w) => { const h = high(w), mg = h.reduce((n, c) => n + (c.revenue * c.margin) / 100, 0), all = CONTRACTS.reduce((n, c) => n + (c.revenue * c.margin) / 100, 0); return { key: 'margin', head: `**The ${h.length} high-risk contracts carry ${m1(mg)} of margin a year, ${Math.round((mg / all) * 100)}% of the margin of the portfolio.**`, points: [`Their revenue is ${m1(rev(h))} a year. The average margin of a high-risk contract is ${(h.reduce((n, c) => n + c.margin, 0) / (h.length || 1)).toFixed(1)}%, against ${(CONTRACTS.reduce((n, c) => n + c.margin, 0) / CONTRACTS.length).toFixed(1)}% for the portfolio.`], table: projTable([...h].sort((a, b) => b.revenue * b.margin - a.revenue * a.margin).slice(0, 12), w, [{ col: 'Margin', of: (c) => `${c.margin.toFixed(1)}%`, num: true }, { col: 'Margin a year', of: (c) => m1((c.revenue * c.margin) / 100), num: true }]), sources: [{ kind: 'table', name: 'fin.contract_pnl' }, SCORECARD], follow: ['Which high-risk contracts are also losing margin?', 'How much of our revenue sits in high-risk contracts?', 'Which contracts run under their budget margin?'] } })
on(/high.?risk.*(losing|margin|budget)|also losing margin/i, (w) => { const cs = high(w).filter((c) => band(c, 'fp1', w) >= 3).sort((a, b) => S(b, w) - S(a, w)); return { key: 'high-margin', head: `**${plural(cs.length, 'high-risk contract')} also run under their budget margin**, worth ${m1(rev(cs))} a year. These are at risk twice: of being lost, and of not being worth keeping on today's terms.`, table: cs.length ? projTable(cs, w, [{ col: 'Margin against budget', of: (c) => raw(c, 'fp1', w) }, { col: 'Margin', of: (c) => `${c.margin.toFixed(1)}%`, num: true }]) : undefined, sources: [{ kind: 'table', name: 'fin.contract_pnl' }, SCORECARD], follow: ['Which contracts run under their budget margin?', 'Where are change orders unbilled or in dispute?', 'How much margin is at risk in the high-risk contracts?'] } })
on(/revenue.*(risk|high)|how much.*(at risk|revenue)|expos/i, (w) => { const h = high(w), tot = rev(CONTRACTS), act = CONTRACTS.filter((c) => priorityOf(c, w) === 'Act now'); return { key: 'revenue', head: `**${m1(rev(h))} a year sits in contracts that rate 3 or 4: ${h.length} of ${CONTRACTS.length} projects, ${Math.round((rev(h) / tot) * 100)}% of revenue.** ${act.length} of them need action now, worth ${m1(rev(act))}.`, points: [`The portfolio bills ${m1(tot)} a year.`], bars: [1, 2, 3, 4].map((r) => { const cs = CONTRACTS.filter((c) => R(c, w) === r); return { label: `${r} · ${RATING_NAME[r]}`, value: rev(cs) / 1e6, text: `${m1(rev(cs))} · ${cs.length} projects` } }), sources: [SCORECARD, MASTER], follow: ['Which ten projects carry the most risk?', 'Which region carries the most risk?', 'How much margin is at risk in the high-risk contracts?'] } })
on(/how many.*(rate|rated|high|3 or 4)|distribution|by rating|summary|overview|how are we doing|state of the (portfolio|book)/i, (w) => { const d = [1, 2, 3, 4].map((r) => CONTRACTS.filter((c) => R(c, w) === r)); return { key: 'count', head: `**${d[2].length + d[3].length} of ${CONTRACTS.length} projects rate 3 or 4 today.** ${d[0].length} rate 1, ${d[1].length} rate 2, ${d[2].length} rate 3 and ${d[3].length} rate 4.`, bars: d.map((cs, i) => ({ label: `${i + 1} · ${RATING_NAME[i + 1]}`, value: cs.length, text: `${cs.length} projects · ${m1(rev(cs))}` })), sources: [SCORECARD], follow: ['Which ten projects carry the most risk?', 'How much of our revenue sits in high-risk contracts?', 'Which projects need action now?'] } })
on(/act(ion)? now|need.*action|priorit|urgent/i, (w) => { const cs = CONTRACTS.filter((c) => priorityOf(c, w) === 'Act now').sort((a, b) => S(b, w) - S(a, w)); return { key: 'act', head: `**${plural(cs.length, 'project')} need action now: high risk and a lot at stake.** Together ${m1(rev(cs))} a year.`, points: ['“Act now” is a rating of 3 or 4 on a contract that is large, profitable or close to its end.'], table: projTable(cs.slice(0, 20), w, [{ col: 'Term', of: term }, { col: 'Main reason', of: (c) => reasonOf(c, w) }]), sources: [SCORECARD, MASTER], follow: ['Which actions are due first?', `What is the status of ${shortSite(cs[0])} and why?`, 'Which Regional VP has the most high-risk contracts?'] } })
on(/worry|keep me up|this week|top of mind|attention|on fire/i, (w) => { const mv = w === 'after' ? movers().filter((m) => m.r1 > m.r0).map((m) => m.c) : [], cs = [...mv, ...CONTRACTS.filter((c) => priorityOf(c, w) === 'Act now' && deltaOf(c, w) > 0.08 && !mv.includes(c)).sort((a, b) => deltaOf(b, w) - deltaOf(a, w))].slice(0, 6); const list = [...cs, ...CONTRACTS.filter((c) => priorityOf(c, w) === 'Act now' && !cs.includes(c)).sort((a, b) => S(b, w) - S(a, w))].slice(0, 5); return { key: 'worry', head: `**Five projects deserve your attention this week: high risk and a lot at stake${cs.length ? `, and ${cs.length === 1 ? 'one is' : `${cs.length} are`} still getting worse` : ''}.**`, points: list.map((c) => `${shortSite(c)} (${m1(c.revenue)}, ${term(c)}): ${reasonOf(c, w)}.`), table: projTable(list, w, [{ col: '90 days', of: (c) => `${deltaOf(c, w) >= 0 ? '+' : '−'}${Math.abs(deltaOf(c, w)).toFixed(2)}`, num: true }]), sources: [SCORECARD], follow: [`What is the status of ${shortSite(list[0])} and why?`, 'Which actions are due first?', 'What changed since yesterday’s check?'] } })
on(/(ten|10|top|most).*(risk|riskiest)|riskiest|highest (risk|score)|likely to lose|could we lose|might (we )?lose|risk of losing|worst (projects|contracts|sites)/i, (w) => { const cs = [...CONTRACTS].sort((a, b) => S(b, w) - S(a, w)).slice(0, 10); return { key: 'top10', head: `**The ten highest scores run from ${f1(S(cs[0], w))} (${shortSite(cs[0])}) to ${f1(S(cs[9], w))}.** Together these ten bill ${m1(rev(cs))} a year.`, table: projTable(cs, w, [{ col: 'Priority', of: (c) => priorityOf(c, w) }, { col: 'Main reason', of: (c) => reasonOf(c, w) }]), sources: [SCORECARD], follow: [`What is the status of ${shortSite(cs[0])} and why?`, 'Which projects need action now?', 'How many sites have a mitigation plan, and what happens to the risk if the plans land?'] } })

/* questions about one factor */
const FAC: [RegExp, string][] = [[/safety/i, 'os'], [/permit|compliance|environment/i, 'en'], [/workforce|staffing|people/i, 'st'], [/client satisfaction|client relationship/i, 'cu'], [/community/i, 'co'], [/financ/i, 'fp'], [/politic|client side/i, 'cp'], [/asset|infrastructure/i, 'in'], [/resilien|climate/i, 'rs'], [/commercial|contract terms|(bad|poor|weak|tough) terms/i, 'cr'], [/water quality|contaminant/i, 'iq']]
for (const [re, fid] of FAC) on(re, (w) => facList(fid, w, ['Which factor drives the most risk across the portfolio?', 'Which region carries the most risk?', 'Which projects need action now?']))

/* ------------------------------------------------------------------ the library and the entry point */
export const ASK_LIBRARY: { theme: string; qs: string[] }[] = [
  { theme: 'The portfolio', qs: ['How much of our revenue sits in high-risk contracts?', 'How many projects rate 3 or 4 today?', 'Which ten projects carry the most risk?', 'Which projects need action now?', 'Which region carries the most risk?', 'Which Regional VP has the most high-risk contracts?', 'How are our ten largest contracts rated?', 'What should I worry about this week?'] },
  { theme: 'What moved', qs: ['For which projects did the risk increase in the last 90 days, and why?', 'Which projects improved in the last 90 days?', 'What changed since yesterday’s check?', 'Which projects moved into high risk?', 'Which region got worse over the last 90 days?', 'Which project had the largest rise in risk?', 'Is the portfolio getting riskier or safer?', 'Which high-risk projects are still getting worse?'] },
  { theme: 'One project', qs: ['What is the status of Sable Creek WWTP and why did the risk go up?', 'Why did Harlow Creek move to a rating of 3?', 'What is the mitigation plan for Harlow Creek?', 'What is at stake at Ashby Falls?', 'What is happening at Red Mesa?', 'Compare Harlow Creek and Sable Creek', 'Who owns Ashby Falls and what should they do first?'] },
  { theme: 'Safety and compliance', qs: ['Which projects have not recorded a safety observation in the last two weeks?', 'Which sites have the highest lost-time injury rate?', 'Where is workplace safety the weakest?', 'Which projects missed required samples?', 'Which projects received a notice of violation?', 'Which sites are under a consent order?', 'Which permits are up for renewal with tighter limits?', 'Which plants are over the PFAS limits?'] },
  { theme: 'People and operations', qs: ['Which sites have positions open for more than 60 days?', 'Where is overtime above 13% of payroll?', 'Which sites lack a licensed operator or a backup?', 'Which sites have a new site manager?', 'Where is staff retention under 75%?', 'Which sites are behind on planned maintenance?', 'Which sites depend on one key person?'] },
  { theme: 'Money', qs: ['Which projects have receivables older than 90 days?', 'Which contracts run under their budget margin?', 'Which high-risk contracts are also losing margin?', 'Where are change orders unbilled or in dispute?', 'Which contracts paid penalties in the last three years?', 'Which contracts carry fixed-price exposure on energy and chemicals?', 'How much margin is at risk in the high-risk contracts?'] },
  { theme: 'Client, community and competition', qs: ['Which contracts come up for renewal in the next 18 months, and which of those are high risk?', 'Where is the client talking about in-house operation or a re-bid?', 'Where did the key client contact change?', 'Which clients have an election or council turnover coming?', 'Where are competitors active?', 'Where is local media coverage mostly negative?', 'Which sites get the most odor complaints?', 'Which clients gave us a low survey score?', 'Where are lawsuits threatened or filed?'] },
  { theme: 'Plans and the scorecard', qs: ['How many sites have a mitigation plan, and what happens to the risk if the plans land?', 'Which actions are due first?', 'Who owns the most mitigation actions?', 'Which factor drives the most risk across the portfolio?', 'Which red flags are raised today?', 'How is the risk score made?', 'What data is missing from the scorecard?', 'Would the scorecard have caught the contracts we lost?'] },
]
export const ASK_COUNT = ASK_LIBRARY.reduce((n, t) => n + t.qs.length, 0)

/** Answer a question as it is typed. `w` says whether this morning's check has run. */
export function askRisk(text: string, w: When): AskAnswer {
  const t = text.trim(), sites = sitesIn(t)
  if (sites.length >= 2 && /compare|against|versus|\bvs\b| and /i.test(t)) return compare(sites[0], sites[1], w)
  if (sites.length) { const c = sites[0]; if (/\bplans?\b|mitigat|do (first|about)|\bactions?\b|should they/i.test(t)) return sitePlan(c, w); if (/at stake|worth|\brevenue\b|\bmargin\b|\brenew|\bends?\b|\bterm\b/i.test(t)) return siteStake(c, w); return siteStatus(c, w) }
  for (const i of INTENTS) if (i.re.test(t)) { try { return i.run(w, t) } catch { /* fall through to the honest answer */ } }
  return { key: 'none', head: 'I cannot answer that from the contract risk scorecard yet.', points: ['I answer questions about the portfolio, a region, a project by name, a signal such as overtime or missed samples, what moved and why, renewals, mitigation plans and how the score is made.'], sources: [], follow: ['What should I worry about this week?', 'For which projects did the risk increase in the last 90 days, and why?', 'Which projects have not recorded a safety observation in the last two weeks?'] }
}
