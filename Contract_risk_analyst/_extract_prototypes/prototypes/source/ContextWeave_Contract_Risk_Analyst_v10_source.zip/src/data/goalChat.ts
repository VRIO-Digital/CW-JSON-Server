import type { Goal, PlanStep } from './goalCases'

/*
 * The conversation that drives a goal. The analyst talks to the agent instead of pressing buttons:
 * "approve", "remove step 3", "add a step to read the supplier mail", "show finding 2", "why option 1",
 * "choose option 1", "start the change request". `interpret` turns a message into an intent; the goal
 * workspace carries it out and the left pane follows. Rule-based here; the product would use a model.
 * A message it cannot place gets an honest "I did not catch that" with what it can do now.
 */

export type Tab = 'target' | 'approach' | 'findings' | 'data' | 'decision' | 'submissions' | 'log'

export type Intent =
  | { k: 'help' }
  | { k: 'approve' }
  | { k: 'remove'; n: number }
  | { k: 'restore'; n: number }
  | { k: 'move'; n: number; to: number }
  | { k: 'add'; text: string; after?: number }
  | { k: 'change'; n: number; text: string }
  | { k: 'extend'; n: number; text: string }
  | { k: 'explain'; n: number }
  | { k: 'save'; name?: string }
  | { k: 'revise' }
  | { k: 'fire' }
  | { k: 'status' }
  | { k: 'summary' }
  | { k: 'finding'; n: number }
  | { k: 'drill'; n?: number }
  | { k: 'accept'; ns: number[] | 'all' }
  | { k: 'challenge'; n: number; text: string }
  | { k: 'recs' }
  | { k: 'why'; n?: number }
  | { k: 'choose'; n?: number }
  | { k: 'subs' }
  | { k: 'startSub'; n?: number; words?: string }
  | { k: 'describe' }
  | { k: 'pack' }
  | { k: 'info'; text: string }
  | { k: 'tab'; tab: Tab }
  | { k: 'unknown' }

const WORDS: Record<string, number> = { one: 1, first: 1, two: 2, second: 2, three: 3, third: 3, four: 4, fourth: 4, five: 5, fifth: 5, six: 6, sixth: 6, last: -1 }
const NUM = '(\\d+|one|two|three|four|five|six|first|second|third|fourth|fifth|sixth|last)'
const toN = (s: string | undefined, last = 0): number | undefined => {
  if (!s) return undefined
  const v = /^\d+$/.test(s) ? Number(s) : WORDS[s]
  return v === -1 ? last : v
}

const TAB_WORDS: [RegExp, Tab][] = [
  [/\b(goal|target)\b/, 'target'], [/\b(approach|plan|steps)\b/, 'approach'], [/\bfindings?\b/, 'findings'], [/\b(data|worksheet|tables?)\b/, 'data'],
  [/\b(decision|recommendations?|options)\b/, 'decision'], [/\bsubmissions?\b/, 'submissions'], [/\b(log|history)\b/, 'log'],
]

/** The short form of a finding: what comes before its first colon. */
export const shortHeadline = (h: string) => {
  const i = h.indexOf(':')
  return (i > 12 && i < 90 ? h.slice(0, i) : h.length > 90 ? `${h.slice(0, 88)}…` : h).replace(/\.$/, '')
}

const COUNT = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven']
export const count = (n: number) => COUNT[n] ?? String(n)
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)

/** What the agent says when findings land. */
export const findingsSummary = (g: Pick<Goal, 'findings' | 'recommendations'>) => {
  const pref = g.recommendations.findIndex((r) => r.preferred)
  return [
    `Done. ${cap(count(g.findings.length))} findings:`,
    ...g.findings.map((f, i) => `${i + 1}. ${shortHeadline(f.headline)}`),
    '',
    g.recommendations.length ? `I see ${count(g.recommendations.length)} ways forward and prefer option ${pref + 1}. Say a number to open a finding, or ask what I recommend.` : 'Say a number to open a finding.',
  ].join('\n')
}

/* ------------------------------------------------------------------ a step from plain words */

const SOURCE_HINTS: [RegExp, string][] = [
  [/\b(mail|email|e-mail|thread|inbox|mailbox|correspondence)\b/, 'Outlook mailbox'],
  [/\b(document|report|contract|deck|minutes|letter|pdf|file)s?\b/, 'OneDrive documents'],
  [/\b(order|po|purchase|supplier|vendor|delivery|deliveries)s?\b/, 'erp.proc po_line'],
  [/\b(ledger|cost|actuals?|spend|invoice|posted)s?\b/, 'erp.fin cost_transaction'],
  [/\b(accruals?|accrued)\b/, 'erp.fin accrual_line'],
  [/\b(budget|forecast|snapshot)s?\b/, 'erp.fin forecast_snapshot'],
  [/\b(risk|change request|register|cr)s?\b/, 'ppm.risk_change_register'],
  [/\b(schedule|milestone|date|programme)s?\b/, 'ppm schedule'],
  [/\b(tariff|index|indices|news|internet|market|price)s?\b/, 'Internet: news, tariffs and price indices'],
]

export const inferSources = (text: string) => {
  const t = text.toLowerCase()
  const s = SOURCE_HINTS.filter(([re]) => re.test(t)).map(([, v]) => v)
  return s.length ? [...new Set(s)] : ['Contract Risk Analyst graph v1']
}

const checkFor = (text: string) => {
  const t = text.toLowerCase()
  if (/\b(mail|email|thread|document|letter)\b/.test(t)) return 'Every statement it uses has a dated message or document.'
  if (/\b(sum|total|cost|budget|forecast|ledger|spend)\b/.test(t)) return 'Its figures reconcile to the ledger.'
  return 'Everything it adds has a dated source.'
}

const clean = (s: string) => cap(s.trim().replace(/^(to|that|which)\s+/i, '').replace(/[.\s]+$/, ''))

/** Turn "read the supplier mail for promised dates" into a full step: title, how, sources, check. */
export const draftStep = (text: string, who: string): PlanStep => {
  const title = clean(text)
  const sources = inferSources(text)
  return { id: `u${Date.now().toString(36)}`, title, how: `${title}, from ${sources.join(', ')}.`, sources, check: checkFor(text), state: 'pending', editedBy: who }
}

export const rewordStep = (s: PlanStep, text: string, who: string): PlanStep => {
  const d = draftStep(text, who)
  return { ...s, title: d.title, how: d.how, sources: d.sources, check: d.check, editedBy: who }
}

export const extendStep = (s: PlanStep, text: string, who: string): PlanStep => {
  const extra = clean(text)
  return { ...s, how: `${s.how.replace(/\.?$/, '.')} Also: ${extra.charAt(0).toLowerCase()}${extra.slice(1)}.`, sources: [...new Set([...s.sources, ...inferSources(text).filter((x) => !x.startsWith('Capital Project'))])], editedBy: who }
}

/* ------------------------------------------------------------------ interpret */

export function interpret(raw: string, g: Goal, tab: Tab): Intent {
  const r = raw.trim().replace(/[!?]+$/, '').replace(/\s+/g, ' ')
  const t = r.toLowerCase()
  const live = g.plan.filter((s) => s.state !== 'removed').length
  const planOpen = g.status === 'plan-review'
  const hasFindings = g.findings.length > 0
  const n1 = (re: RegExp, last = live) => { const m = t.match(re); return m ? toN(m[1], last) : undefined }
  let m: RegExpMatchArray | null

  if (/^(help|what can (i|you) (say|do)( here)?|commands|options here)$/.test(t)) return { k: 'help' }

  /* --- the approach, while it is open --- */
  if (g.plan.length) {
    if ((m = t.match(new RegExp(`(?:remove|drop|delete|skip|take out|cut)\\s+(?:the\\s+)?step\\s+${NUM}`)))) return { k: 'remove', n: toN(m[1], live)! }
    if ((m = t.match(new RegExp(`(?:restore|put back|bring back|undo removing|keep)\\s+(?:the\\s+)?step\\s+${NUM}`)))) return { k: 'restore', n: toN(m[1], g.plan.length)! }
    if ((m = t.match(new RegExp(`move\\s+step\\s+${NUM}\\s+(up|down|first|to the top|last|to the end|(?:to|before)\\s+(?:step\\s+)?${NUM}|after\\s+(?:step\\s+)?${NUM})`)))) {
      const n = toN(m[1], live)!
      const how = m[2]
      const to = how === 'up' ? n - 1 : how === 'down' ? n + 1 : /first|top/.test(how) ? 1 : /last|end/.test(how) ? live : how.startsWith('after') ? toN(m[4], live)! + (toN(m[4], live)! < n ? 1 : 0) : toN(m[3], live)!
      return { k: 'move', n, to }
    }
    if ((m = t.match(new RegExp(`(?:change|reword|rename|rewrite|replace)\\s+step\\s+${NUM}\\s*(?:to|:|as|with|into|so it)?\\s+(.{4,})`)))) return { k: 'change', n: toN(m[1], live)!, text: r.slice(r.length - m[2].length) }
    if ((m = t.match(new RegExp(`(?:in\\s+)?step\\s+${NUM}[,:]?\\s+(?:should\\s+|could\\s+|must\\s+)?(?:also|and)\\s+(.{4,})`)))) return { k: 'extend', n: toN(m[1], live)!, text: r.slice(r.length - m[2].length) }
    if ((m = t.match(new RegExp(`^(?:add|insert|include|plus)\\b(?:\\s+(?:a|another|one more|new))?\\s+step(?:\\s+after\\s+(?:step\\s+)?${NUM})?\\s*(?:that|to|which|:|,|-)?\\s*(.{4,})`)))) {
      let text = r.slice(r.length - m[2].length)
      let after = toN(m[1], live)
      const pos = text.match(new RegExp(`[,\\s]+(after|before)\\s+(?:step\\s+)?${NUM}\\s*$`, 'i'))
      if (pos) { const k = toN(pos[2].toLowerCase(), live)!; after = pos[1].toLowerCase() === 'after' ? k : k - 1; text = text.slice(0, pos.index) }
      return { k: 'add', text, after }
    }
    if (planOpen && (m = t.match(/^(?:also|and also|you should also|please also)\s+(.{4,})/))) return { k: 'add', text: r.slice(r.length - m[1].length) }
    if ((m = t.match(new RegExp(`(?:what|explain|tell me about|why|how)\\b.*\\bstep\\s+${NUM}|^step\\s+${NUM}$`)))) return { k: 'explain', n: toN(m[1] ?? m[2], live)! }
    if (planOpen && /\b(approve|approved|lgtm)\b/.test(t)) return { k: 'approve' }
    if (/\bsave\b|\bkeep (it|this) for\b|\breuse\b/.test(t)) {
      const nm = raw.match(/\bas\s+["“']?(.+?)["”']?\s*$/i)
      return { k: 'save', name: nm?.[1] }
    }
    if (/\b(revise|reopen|rework|edit|change|update)\s+(the\s+)?(approach|plan)\b/.test(t) && !planOpen) return { k: 'revise' }
  }

  if (planOpen && g.plan.length && /\b(approve|approved|looks good|look good|lgtm|go ahead|go for it|sounds good|that'?s (right|fine|good)|confirm|yes|yep|ok|okay|fine|start|run it|do it|save and arm|arm it)\b/.test(t)) return { k: 'approve' }

  if (g.status === 'armed' && /\b(simulate|fire|fires|trigger|run (it )?now|run now|run it)\b/.test(t)) return { k: 'fire' }

  if (/\b(where are you|status|progress|how far|what are you doing|where does it stand|how is it going)\b/.test(t)) return { k: 'status' }

  /* --- findings, recommendations, submissions --- */
  if (hasFindings) {
    if ((m = t.match(new RegExp(`(?:challenge|dispute|disagree with|question|i doubt|not sure about)\\s+(?:finding\\s+)?${NUM}[:,.]?\\s*(.*)`)))) return { k: 'challenge', n: toN(m[1], g.findings.length)!, text: m[2] ? r.slice(r.length - m[2].length) : '' }
    if (/\b(accept|agree|approve|confirm|sign off)\b/.test(t) && (/\ball\b|\bthe findings\b|\bfindings\b|\bfinding\s/.test(t) || (tab !== 'decision' && /\d/.test(t))) && !/option|recommendation|preferred/.test(t)) {
      if (/\ball\b|\bthe findings\b/.test(t) && !/finding\s+\d/.test(t)) return { k: 'accept', ns: 'all' }
      const ns = [...t.matchAll(new RegExp(`${NUM}`, 'g'))].map((x) => toN(x[1], g.findings.length)!).filter((x) => x >= 1 && x <= g.findings.length)
      return ns.length ? { k: 'accept', ns } : { k: 'accept', ns: 'all' }
    }
    if (/\bwhy\b/.test(t)) return { k: 'why', n: n1(new RegExp(`(?:option|recommendation|number|#)?\\s*${NUM}\\b`), g.recommendations.length) }
    if ((m = t.match(new RegExp(`\\b(?:choose|pick|go with|select|take|accept|we'?ll do|let'?s do)\\b(?:\\s+(?:option|recommendation|number|#))?\\s*${NUM}?`))) && (/option|recommendation|preferred|go with|choose|pick|let'?s do|we'?ll do/.test(t) || tab === 'decision')) {
      return { k: 'choose', n: m[1] ? toN(m[1], g.recommendations.length) : undefined }
    }
    if (/\b(describe|new output|something else|my own output|custom output)\b/.test(t)) return { k: 'describe' }
    if (g.submissions.length && (m = t.match(new RegExp(`\\b(?:start|open|draft|write|prepare|create|begin|do)\\b\\s+(?:the\\s+)?(?:submission\\s+|number\\s+)?(?:${NUM}\\b)?\\s*(.*)`))) && (m[1] || /submission|brief|note|deck|pack|request|report/.test(t))) {
      return { k: 'startSub', n: m[1] ? toN(m[1], g.submissions.length) : undefined, words: m[2] }
    }
    if (/\b(download|export|analysis pack|pdf)\b/.test(t)) return { k: 'pack' }
    if (/\b(what should i send|what do i send|submissions?|deliverables?|outputs?|who (do|should) i tell)\b/.test(t)) return { k: 'subs' }
    if (/\b(recommend|recommendations|options|ways forward|what should (i|we) do|what now|decision|next step)\b/.test(t)) return { k: 'recs' }
    if ((m = t.match(new RegExp(`\\b(?:data|drill|rows|numbers|source|sources|evidence|ledger|orders|figures)\\b.*?(?:finding\\s+|for\\s+|behind\\s+)?${NUM}?$`)))) return { k: 'drill', n: m[1] ? toN(m[1], g.findings.length) : undefined }
    if (/^(summary|summari[sz]e|recap|in short|what did you find|findings|the findings|show (me )?the findings|tell me)$/.test(t) || /\b(summary|summari[sz]e|recap)\b/.test(t)) return { k: 'summary' }
    if ((m = t.match(new RegExp(`^(?:show|open|see|read|explain|tell me about|go to|and)?\\s*(?:me\\s+)?(?:the\\s+)?(?:finding|option|recommendation|number|#|no\\.?)?\\s*${NUM}$`)))) {
      const n = toN(m[1], g.findings.length)!
      if (/option|recommendation/.test(t) || tab === 'decision') return { k: 'why', n }
      if (tab === 'submissions') return { k: 'startSub', n }
      return { k: 'finding', n }
    }
  }

  if ((m = raw.match(/^(?:add (?:information|info|a note|this)|note|fyi|for your information)[:,\s]+(.{3,})/i))) return { k: 'info', text: m[1] }
  if ((m = t.match(/^(?:show|open|go to|see|back to|take me to)\s+(?:me\s+)?(?:the\s+)?(.+)$/))) {
    const hit = TAB_WORDS.find(([re]) => re.test(m![1]))
    if (hit) return { k: 'tab', tab: hit[1] }
  }
  return { k: 'unknown' }
}

/** What the analyst can say next, as one-tap suggestions. They follow where the analyst is: the tab, and
 *  the step or finding in focus on the screen. */
export function suggestions(g: Goal, tab: Tab, agentShort: string, focus: { step?: number; finding?: number } = {}): string[] {
  const live = g.plan.filter((s) => s.state !== 'removed').length
  const pref = Math.max(0, g.recommendations.findIndex((r) => r.preferred)) + 1
  const fn = focus.finding
  const accepted = new Set(g.acceptedFindings ?? [])
  switch (g.status) {
    case 'plan-review': {
      if (!g.plan.length) return []
      const approve = g.trigger === 'rule' ? 'Approve and save the approach' : 'Approve the approach'
      if (focus.step) return [approve, `Remove step ${focus.step}`, focus.step > 1 ? `Move step ${focus.step} up` : `Move step ${focus.step} down`, `In step ${focus.step} also read the controller mail`]
      return [approve, `What does step ${Math.min(2, live)} do?`, 'Add a step to read the supplier mail for promised dates', live > 2 ? `Move step ${live} up` : 'Remove step 1', 'Save it for reuse']
    }
    case 'armed':
      return g.trigger === 'rule' ? ['Change the approach', 'Save it for reuse', 'Where does it stand?'] : ['Simulate: run now', 'Change the approach', 'Save it for reuse']
    case 'fired':
    case 'analysing':
      return ['Where are you?', 'Show the approach']
    case 'needs-input':
      if (!g.findings.length) return ['Drop it from the goal', 'State it as a range from recorded positions']
      return ['Summary', 'Show finding 1']
    default: {
      if (g.status === 'accepted' && (tab === 'decision' || tab === 'findings')) return ['What should I send?', 'Start 1', 'Download the analysis pack']
      if (g.trigger === 'schedule' && tab === 'approach') return ['Summary', 'Simulate: run now', 'Change the approach']
      if (tab === 'decision') return [`Why option ${pref}?`, `Choose option ${pref}`, 'What should I send?']
      if (tab === 'submissions') return g.submissions.length ? ['Start 1', 'Describe a new output', 'Download the analysis pack'] : ['Describe a new output', 'Download the analysis pack']
      if (tab === 'data') return ['Summary', 'What do you recommend?']
      if (tab === 'approach') return ['Summary', 'What does step 3 do?', 'Change the approach']
      if (g.status === 'accepted') return ['What should I send?', 'Start 1', 'Download the analysis pack']
      if (tab === 'findings' && g.findings.length && g.findings.every((f) => accepted.has(f.id))) return ['What do you recommend?', 'Open the data', 'Go to the decision']
      if (fn) {
        const next = fn < g.findings.length ? `Show finding ${fn + 1}` : 'What do you recommend?'
        return [`Show the data for finding ${fn}`, accepted.has(g.findings[fn - 1]?.id) ? next : `Accept ${fn}`, `Challenge ${fn}`, next, 'Accept all findings'].filter((x, i, all) => all.indexOf(x) === i)
      }
      return ['Summary', 'Show finding 1', 'Accept all findings', `What do you recommend, ${agentShort}?`]
    }
  }
}

export function helpText(g: Goal): string {
  if (g.status === 'plan-review') return 'While the approach is open you can say:\n"approve" · "remove step 3" · "move step 4 up" · "add a step to read the supplier mail" · "change step 2 to …" · "in step 2 also check the accruals" · "what does step 1 do?" · "save it as …"'
  if (g.status === 'armed') return g.trigger === 'rule' ? 'I am waiting for the rule. It is under "Watching for you" on the right, where you can simulate it; or say "simulate the rule". Here you can say "change the approach" or "save it for reuse".' : 'I am waiting for the schedule. You can say "simulate: run now", "change the approach" or "save it for reuse".'
  if (g.status === 'analysing') return 'I am running. Ask "where are you?" or say "show the approach".'
  return 'You can say:\n"summary" · "show finding 2" · "show the data for finding 3" · "accept all findings" · "challenge 2: …" · "what do you recommend?" · "why option 1?" · "choose option 1" · "what should I send?" · "start 1" · "describe a new output" · "download the analysis pack" · "add information: …"'
}
