import type { Goal } from './goalCases'
import type { OutputFormat, SectionRole, Template } from './submissionTemplates'

/*
 * Describing a new output from a goal. When no template in the library fits, the author picks a format
 * (slide pack, dashboard, document, memo, spreadsheet, email) and says in plain words what the output
 * should cover for the goal. The agent reads the description into an outline: one section per thing the
 * author asked for, each with the role that tells the filler where the goal's content goes, plus the
 * parts the format always needs. The outline is the author's to edit before anything is drafted, and can
 * be saved to the library as a template so the next recommendation can rest on it.
 *
 * The reading is rule-based here: phrases in the description map to roles; the product would read with a
 * model. Every phrase that was read is reported back ("I read … as …") so the author can correct it.
 */

export interface OutputFormatInfo {
  key: OutputFormat
  label: string
  icon: 'slides' | 'dashboard' | 'document' | 'memo' | 'sheet' | 'email'
  goodFor: string
  unit: string
  /** The sections the format always has, in order, before and after what the author describes. */
  skeleton: { heading: string; role: SectionRole; hint?: string; position: 'start' | 'end' }[]
}

export const OUTPUT_FORMATS: OutputFormatInfo[] = [
  {
    key: 'Slide pack', label: 'Slide pack', icon: 'slides', unit: 'slide',
    goodFor: 'A committee or a review: one idea per slide, figures large, the decision on its own slide.',
    skeleton: [
      { heading: 'Title and position in one line', role: 'summary', position: 'start' },
      { heading: 'Decisions asked', role: 'purpose', position: 'end' },
      { heading: 'Sources and as-of dates', role: 'evidence', position: 'end' },
    ],
  },
  {
    key: 'Dashboard', label: 'Dashboard', icon: 'dashboard', unit: 'panel',
    goodFor: 'Something people come back to: figures as tiles, one chart per question, exceptions as a list, every tile drilling to its rows.',
    skeleton: [
      { heading: 'Headline tiles', role: 'summary', hint: 'The three or four figures that say where things stand; each tile opens its rows.', position: 'start' },
      { heading: 'Open decisions', role: 'purpose', position: 'end' },
      { heading: 'Data behind the panels', role: 'evidence', position: 'end' },
    ],
  },
  {
    key: 'Document', label: 'Document', icon: 'document', unit: 'section',
    goodFor: 'A report someone reads end to end: context, findings, options, recommendation, evidence.',
    skeleton: [
      { heading: 'Purpose and decision asked', role: 'purpose', position: 'start' },
      { heading: 'Summary', role: 'summary', position: 'start' },
      { heading: 'Evidence', role: 'evidence', position: 'end' },
      { heading: 'Assumptions and open items', role: 'assumptions', position: 'end' },
    ],
  },
  {
    key: 'Memo', label: 'Memo', icon: 'memo', unit: 'paragraph',
    goodFor: 'One page to one reader: the ask first, the reasons, what happens next.',
    skeleton: [
      { heading: 'The ask', role: 'purpose', position: 'start' },
      { heading: 'In short', role: 'summary', position: 'start' },
      { heading: 'Next steps', role: 'next', position: 'end' },
    ],
  },
  {
    key: 'Workbook', label: 'Spreadsheet', icon: 'sheet', unit: 'sheet',
    goodFor: 'Figures people will sort, filter and reconcile: one sheet per table, a cover that says what is in it.',
    skeleton: [
      { heading: 'Cover: what this workbook holds and as of when', role: 'purpose', position: 'start' },
      { heading: 'Sources per line', role: 'evidence', position: 'end' },
    ],
  },
  {
    key: 'Email', label: 'Email', icon: 'email', unit: 'paragraph',
    goodFor: 'A message one person reads on a phone: the ask in the first line, three short paragraphs, the figures attached.',
    skeleton: [
      { heading: 'Subject and the ask in one line', role: 'purpose', position: 'start' },
      { heading: 'Attachments and where the figures come from', role: 'evidence', position: 'end' },
    ],
  },
]

export const formatInfo = (f: OutputFormat): OutputFormatInfo => OUTPUT_FORMATS.find((x) => x.key === f) ?? OUTPUT_FORMATS[2]

/* What a phrase in the description means. First match wins; the order puts the specific before the general. */
const ROLE_RULES: { role: SectionRole; test: RegExp; reads: string }[] = [
  { role: 'options', test: /\b(option|alternative|scenario|choice|course|ways? forward|trade.?off)/i, reads: 'the options with their figures and trade-offs' },
  { role: 'summary', test: /\b(summary|headline|kpi|tile|at a glance|position|overall|total|recommend|bottom line|one line)/i, reads: 'the headline position and recommendation' },
  { role: 'purpose', test: /\b(decision|decide|approval|approve|ask|request|sign.?off|agree|authori[sz])/i, reads: 'a decision the reader takes' },
  { role: 'assumptions', test: /\b(assum|risk|open (item|question|point)|question|caveat|provisional|not (yet )?(established|confirmed)|uncertain|gap)/i, reads: 'what is not established' },
  { role: 'why', test: /\b(why|reason|rationale|because|how (we|the agent|it) got|story|logic)/i, reads: 'why the recommendation is what it is' },
  { role: 'evidence', test: /\b(evidence|source|citation|reference|where .* came from|audit|drill|row.?level|transaction|attach)/i, reads: 'the evidence lines' },
  { role: 'next', test: /\b(next step|what happens next|action|owner|who does what|timeline|by when|follow.?up)/i, reads: 'next steps with owners' },
  { role: 'findings', test: /\b(finding|analysis|variance|forecast|budget|actual|trend|month|chart|graph|table|breakdown|by (project|month|category|supplier|lot|plant|site|business|stream|unit|facility|generator|outlet)|exception|over|behind|detail|movement|cause|what (happened|changed|moved)|ledger|order|snapshot|accrual|register|line|how .* got|costs?|bids?|cover|volumes?|spend|prices?|stock|shortfall|short|transfers?|expedites?|buy|streams?|routes?|routing|capacity|margin|acceptance|positions?|shipments?|re-?routes?|holds?|outlets?|booked|network|headroom|changes? since|breach|plant|ratings?|rated|scorecard|signals?|contracts?|renewals?|regions?|at stake|revenue|lost|losses|lessons?|back.?test|client.side|signs?|moved|plan list|pattern|agreement|clauses?|complaints?|tracker|overdue|categor(?:y|ies)|confirmations?)/i, reads: 'findings and figures from the analysis' },
]

/** What a phrase asks for that no connected source holds: the agent says so instead of filling the part with something else. */
const NOT_CONNECTED: { test: RegExp; source: string }[] = [
  { test: /\bcompetitor('s)?\s+(pric|price|rate)|\bmarket (price|rate)s?\b|\b(market|commodity)\s+(price\s+)?ind(ex|ices)\b/i, source: 'competitor pricing' },
  { test: /\b(carrier|in transit|truck tracking|shipment tracking|tracking number)/i, source: 'carrier tracking' },
  { test: /\b(client('s)? (budget|internal) (papers|memos)|private (board|council) (papers|session))/i, source: 'the client’s internal papers' },
]

/** The role a heading plays, by the same rules the agent reads descriptions with. */
export const roleOf = (heading: string): SectionRole => ROLE_RULES.find((r) => r.test.test(heading))?.role ?? 'free'

export interface OutlineSection {
  heading: string
  role: SectionRole
  hint?: string
  /** What the agent read in the description to propose this section; empty for a format's own part. */
  because?: string
}

export interface OutlineProposal {
  format: OutputFormat
  /** Who the output is for, when the description says ("a memo to the chair", "a dashboard for the committee"). */
  audience?: string
  sections: OutlineSection[]
  /** The agent's account of its reading, one line per part. */
  reading: string[]
  unreadPhrases: string[]
}

const clean = (s: string) => s.replace(/^[\s,;:.\-–•]+|[\s,;:.\-–•]+$/g, '').replace(/^(and|then|also|plus)\s+/i, '').trim()
const cap = (s: string) => (s ? s[0].toUpperCase() + s.slice(1) : s)
const headingFrom = (phrase: string): string => {
  const h = cap(clean(phrase)
    .replace(/^(?:(?:one|a|an|the|first|last|final|closing)\s+)?(?:slide|panel|sheet|section|page|tile|paragraph)s?\s+(?:with|on|about|for|showing|of|that shows|covering)\s+/i, '')
    .replace(/^(?:close|open|finish|end|start)\s+with\s+/i, '')
    .replace(/^(a|an|the|some|one|with|show|showing|include|including|cover|covering|add|put|give|list|listing|then)\s+/i, ''))
  return h.length > 84 ? `${h.slice(0, h.lastIndexOf(' ', 82)).replace(/[\s,;:]+$/, '')}…` : h
}

/** "A memo to the chair", "a dashboard for the executive committee": the framing sentence names the audience, not a section. */
const FRAMING = /^(?:a|an|the|one)?\s*(?:(?:short|brief|quick|one.?page|two.?page)\s+)*(?:dashboard|memo|deck|slide ?pack|slides|document|report|spreadsheet|workbook|letter|e-?mail|message|note|pack|brief|summary)\b[^,]*?\b(?:to|for)\s+(.+)$/i

const DET = '(?:the|a|an|one|two|three|four|five|all|every|each|which|what|why|how|where|who|our|its|their|next|FY\\d)'
const FORMAT_WORD = /\b(?:dashboard|memo|deck|slide ?pack|slides|document|report|spreadsheet|workbook|letter|e-?mail|message|note|pack|brief|summary)\b/i
const CLAUSE = new RegExp(`,\\s+(?=(?:and\\s+)?${DET}\\b)`, 'i')
/** Split a description into the things the author asked for: sentences first; a framing sentence ("a memo to the chair:
 *  …") is kept whole and what follows its colon is read on its own; then list items that start with a determiner
 *  ("…, the order lines…, and the sources…"). A plain list of figures ("approved, forecast, variance") stays together. */
export const splitDescription = (text: string): string[] =>
  text
    .split(/[\n;.]+(?!\d)|\s+(?:and then|then)\s+/i)
    .flatMap((sentence) => {
      const parts: string[] = []
      let rest = sentence
      const m = sentence.match(/^([^:]*)(?::\s*)(.*)$/)
      if (m && FORMAT_WORD.test(m[1])) { parts.push(m[1]); rest = m[2] }
      if (FRAMING.test(clean(rest))) return [...parts, rest]
      return [...parts, ...rest.split(CLAUSE)]
    })
    .map(clean)
    .filter((p) => p.length > 3)


/** Read a description into an outline for the format. Deterministic, so the same words give the same outline. */
export function designOutline(format: OutputFormat, description: string, g?: Goal): OutlineProposal {
  const info = formatInfo(format)
  const phrases = splitDescription(description)
  const unit = info.unit
  const described: OutlineSection[] = []
  const reading: string[] = []
  const unread: string[] = []
  let audience: string | undefined
  const work = [...phrases]
  for (let pi = 0; pi < work.length; pi += 1) {
    const p = work[pi]
    const fr = p.match(FRAMING)
    if (fr && !audience) {
      /* "a dashboard of the routing and the margin for Dana", "a slide pack for Dana on the routing and the margin":
         the reader is the audience; what it is of, or on, is read as the parts it asks for. */
      let aud = clean(fr[1]).replace(/\s+(before|ahead of|after|on \d+|by \d+|in \w+ \d+)\b.*$/i, '')
      let topic = ''
      const after = aud.match(/^(.*?)\s+(?:on|about|of|covering)\s+(.+)$/i)
      if (after) { aud = after[1]; topic = after[2] }
      const before = p.slice(0, p.length - fr[1].length).match(/\b(?:of|on|about|covering|showing)\s+(.+?)\s+(?:to|for)\s*$/i)
      if (before) topic = topic ? `${before[1]} and ${topic}` : before[1]
      audience = cap(aud.replace(/^the\s+/i, ''))
      const topics = topic ? topic.split(/\s*,\s*|\s+and\s+/i).map(clean).filter((x) => x.length > 2) : []
      reading.push(`"${p}" → who it is for: ${audience}${topics.length ? `; what it covers: ${topics.join(', ')}` : ''}.`)
      work.splice(pi + 1, 0, ...topics)
      continue
    }
    const nc = NOT_CONNECTED.find((x) => x.test.test(p))
    if (nc) { unread.push(p); reading.push(`"${p}" → needs ${nc.source}, which is not a connected source; nothing in the graph can fill this ${unit}.`); continue }
    const rule = ROLE_RULES.find((r) => r.test.test(p))
    if (!rule) { unread.push(p); continue }
    /* "Headline tiles: approved, forecast, variance" → the heading is the part before the colon, the list is the hint. */
    const [head, ...tail] = p.split(/:\s*/)
    const heading = headingFrom(head)
    const hint = tail.length ? cap(clean(tail.join(': '))) : p.length > 84 ? p : undefined
    if (described.some((d) => d.heading.toLowerCase() === heading.toLowerCase())) continue
    described.push({ heading, role: rule.role, hint, because: p })
    reading.push(`"${p}" → one ${unit}: ${rule.reads}.`)
  }
  /* The format's own parts come first and last, unless the author already asked for that role. */
  const have = new Set(described.map((d) => d.role))
  const start = info.skeleton.filter((k) => k.position === 'start' && !have.has(k.role)).map(({ heading, role, hint }) => ({ heading, role, hint }))
  const end = info.skeleton.filter((k) => k.position === 'end' && !have.has(k.role)).map(({ heading, role, hint }) => ({ heading, role, hint }))
  if (!described.length) reading.push(`Nothing in the description names a part I can fill, so this is the ${info.label.toLowerCase()} as it usually reads for a goal like this.`)
  if (start.length || end.length) reading.push(`Added what a ${info.label.toLowerCase()} always needs: ${[...start, ...end].map((k) => k.heading.toLowerCase()).join(', ')}.`)
  if (unread.length) reading.push(`Could not place: ${unread.map((u) => `"${u}"`).join(', ')}. Add a section for it below if it matters.`)
  if (g) reading.push(`Content comes from "${g.title}" (${g.agent.name}): ${g.findings.length} findings, ${g.recommendations.length} recommendations.`)
  return { format, audience, sections: [...start, ...described, ...end], reading, unreadPhrases: unread }
}

/** A library template built from a described outline, so the next recommendation can rest on it. */
export const templateFromOutline = (name: string, p: OutlineProposal, description: string): Template => ({
  id: `t-desc-${Date.now().toString(36)}`,
  name,
  family: 'Described for a goal',
  format: p.format,
  note: description.length > 140 ? `${description.slice(0, 138)}…` : description,
  sections: p.sections.map(({ heading, role, hint }) => ({ heading, role, hint })),
})

/** Example descriptions per goal, so the journey can be walked with one click. */
export const EXAMPLE_BRIEFS: Record<string, { format: OutputFormat; text: string }[]> = {
  'g-renewal-review': [
    { format: 'Slide pack', text: 'A slide pack for the portfolio review on 2 December. One slide with the contracts that decide in the next 18 months and the revenue at stake. One slide on revenue at stake by region. One slide on the contracts that need a renewal plan. One slide on the lessons from the renewals we lost. Close with the decisions asked and the sources.' },
    { format: 'Dashboard', text: 'A dashboard for renewals. Headline tiles: contracts that decide in 18 months, revenue at stake, contracts on a plan. Revenue at stake by region. The contracts on the renewal plan list. The renewals we lost, rated a year before.' },
    { format: 'Memo', text: 'A one-page memo to Renee before the review: the contracts on a renewal plan, what is at stake, why the quiet ones are on the list, the lessons from the renewals we lost, and the next steps with dates.' },
  ],
  'g-contract-risk-watch': [
    { format: 'Slide pack', text: 'A short slide pack for the leadership team: where the 300 contracts stand, what changed at the 20 November check, why Harlow Creek moved, the contracts to watch, the three options, how the agent got to its recommendation, and what happens next.' },
    { format: 'Email', text: 'An email to Marisol Vega and Wade Pruitt: why Harlow Creek moved from 2 to 3, what the agreement says, the actions we ask of each of them with dates, and what waits for Legal.' },
    { format: 'Workbook', text: 'A spreadsheet for the Regional VPs: the actions open and overdue with contract, lens, owner and due date, the ratings by region, and the sources for each line.' },
  ],
}

/* For the data package export: the outline reader, reachable from a script driving the prototype. */
if (typeof window !== 'undefined') (window as unknown as { __cwDesigner: unknown }).__cwDesigner = { designOutline, EXAMPLE_BRIEFS, OUTPUT_FORMATS }
