/*
 * Goals: the two Northline Contract Operations journeys (Contract Risk Analyst) in the shape of a plan document.
 *
 * A goal is briefed in one message. The agent reads what it was given and what is connected, and the
 * plan on the right fills in row by row, each row saying where it came from (you, inferred, needs you,
 * from your files). It asks only what the reads could not find, one card at a time. Then the plan is
 * agreed and runs as a workflow of steps to the end; findings land as steps finish; the top
 * recommendation is chosen; the deliverables are built.
 *
 * Two kinds of goal: "Answer once" (the renewal risk review for the 2 December portfolio review: which
 * contracts that decide in the next 18 months are likely to be lost, what they are worth, what to do)
 * and "Keep watching" (the risk of all 300 contracts on the company scorecard, checked every morning;
 * it fires on the check of 20 November, when a demand letter, a missed sample and a council agenda
 * change three contracts). Every figure here is one `risk.ts` computes or `riskDocs.ts` holds.
 *
 * Structural ids are kept from the earlier builds so the store and the page need no new wiring: the
 * once question keys are `four` (the evergreen contracts: june = count them, standin = leave them
 * out) and `t3` (NPS answers given by a predecessor: out = treat as stale, expected = keep and list
 * separately, approved = keep as surveyed).
 */

import type { Drill, Finding, Recommendation, SubmissionSuggestion } from './goalCases'
import { GOALS, ONCE_ID, WATCH_ID, onceRecsFor } from './goalCases'
import { ASHBY, CONTRACTS, DESIGN, HARLOW, bookShape, LOST, PEOPLE, REDMESA, REGIONS, RULE_TEXT, SCORING, deltaOf, f1, flagsOf, groupScore, impactOn, impactRating, likelihoodSignals, m1 as mm1, m2 as mm2, moveLine, movers, planEffect, planFor, portfolio, rating, renewals, shortSite, specCoverage } from './risk'
import DF from './northline/deliver_flow.json'


export type Mode = 'once' | 'watch'
export type Tag = 'you' | 'inf' | 'need' | 'ok'
export type NodeType = 'gather' | 'compute' | 'model' | 'checkpoint' | 'scenario' | 'synthesize' | 'deliver'

/** One line of the reading feed: the tool call, what it returned, and which plan rows it reveals. */
export interface Read { tool: string; res: string; warn?: boolean; rv: string[] }

export interface RowVal { v: string; tag: Tag; label?: string; sub?: string; soft?: boolean }

export interface Node {
  id: string
  col: number
  row: number
  type: NodeType
  title: string
  purpose: string
  how: string
  draws: string[]
  check: string
  fork?: boolean
  caveat?: string
}

export interface Receipt { n: string; m: string; mono?: boolean; drill?: Drill }
export interface Caveat { k: string; t: string; p: string; assume?: boolean; acts?: string[] }
export interface NodeContent {
  dur: string
  conf: 'high' | 'medium' | 'low'
  summary: string[]
  table?: { cols: string[]; num?: number[]; rows: string[][]; tot?: string[]; warn?: number }
  receipts: Receipt[]
  subs?: [string, string][]
  checks: string[]
  caveats: Caveat[]
  trace: string[]
  traceN: number
  live: [string, string]
}

export interface JFinding { id: string; h: string; d: string; from: string; cav: string[]; drill: Drill; base?: Finding }

export interface Tile { v: string; t: string; s: string; rec?: boolean }
export interface Question { key: string; title: string; text: string; tiles: Tile[]; free?: string }

export interface LibFile { id: string; n: string; ext: string; from: 'onedrive' | 'outlook'; icon: 'doc' | 'sheet' | 'folder' | 'mail'; drill?: Drill }


/* ------------------------------------------------------------------ helpers over the data */

export const m1 = mm1
export const m2 = mm2
const d = (view: Drill['view'], extra: Partial<Drill> = {}, note = ''): Drill => ({ view, note, ...extra })
const NUM = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty']
const word = (n: number) => NUM[n] ?? String(n)
const Word = (n: number) => { const w = word(n); return w[0].toUpperCase() + w.slice(1) }

/** Kept for callers from the earlier build. */
export const FOUR: string[] = []
export const DUNMOOR = HARLOW.id

/** The renewal review as the analyst has it: the evergreen contracts counted (nineIn) or left out. */
export function rbFigures(nineIn = true) {
  const x = renewals(SCORING.rule, nineIn)
  return { ...x, nineIn, n: x.set.length, rate: x.planRev, everRev: x.rev(x.ever) }
}
export const portfolioFigures = () => rbFigures(true)
/** The overnight change, in figures. */
export function procFigures() {
  const before = portfolio(SCORING.rule, 'before'), after = portfolio(SCORING.rule, 'after')
  const g = (c: typeof HARLOW, k: 'internal' | 'external', w: 'before' | 'after') => f1(groupScore(c, k, w))
  return { before, after, hi: g(HARLOW, 'internal', 'before'), hi2: g(HARLOW, 'internal', 'after'), he: g(HARLOW, 'external', 'before'), he2: g(HARLOW, 'external', 'after'), ri: g(REDMESA, 'internal', 'before'), ri2: g(REDMESA, 'internal', 'after'), ai: g(ASHBY, 'internal', 'after'), ae: g(ASHBY, 'external', 'after'), three: HARLOW.revenue + REDMESA.revenue + ASHBY.revenue }
}

/* ------------------------------------------------------------------ the one-off goal: the renewal risk review */

export const ONCE_PROMPT = `${PEOPLE.owner.split(' ')[0]} needs the renewal risk review for the portfolio review on 2 December. Of the contracts that decide in the next 18 months, which are we most likely to lose, what are they worth, and what should we do about each? Check whether our scorecard would have warned us about the renewals we already lost. Draft the review pack in last year's structure, a renewal plan for the contract most at risk, and a one-page brief per region. Attached: last year's renewal review and the Calder Valley loss review.`
export const ONCE_FILES = [
  { id: 'seed', n: 'Renewal_Review_2025-12.pptx', s: '1.8 MB' },
  { id: 'seed', n: 'Calder_Valley_Loss_Review_2026-03.pdf', s: '240 KB' },
]

const R0 = renewals('max', true)
export const ONCE_READS: Read[] = [
  { tool: 'read Renewal_Review_2025-12.pptx', res: 'Five sections: what ends in 18 months, revenue at stake by region, contracts on a plan, lessons, decisions asked. The structure for this year', rv: ['doc:q2', 'deliver'] },
  { tool: 'read Calder_Valley_Loss_Review_2026-03.pdf', res: 'Lost at re-bid in December 2025 after eleven years with no violation · a new client lead, an adviser hired and a stale NPS in the year before', rv: ['doc:deck', 'scope'] },
  { tool: 'scan master.contract · the signed contracts', res: `300 agreements read for end date, renewal options and termination rights · ${R0.ending.length} end in the next 18 months`, rv: ['src:fin', 'scope', 'decision'] },
  { tool: 'read the scorecard', res: `Every contract rated on the scorecard you agreed · ${R0.high.length} of the set rate 3 or 4`, rv: ['src:ppm'] },
  { tool: 'scan the agreements for evergreen terms', res: `${Word(R0.ever.length)} contracts renew automatically but the client can end them on notice. Do they count as up for renewal?`, warn: true, rv: ['as:four', 'src:ins', 'miss:four'] },
  { tool: 'read Outlook: Contract Operations leadership · operations mail', res: `${PEOPLE.owner.split(' ')[0]}: pack by 27 November, last year's structure · Tom Brandvold: count the evergreen contracts`, rv: ['src:mail'] },
  { tool: 'search role memory', res: 'A rating read from a contract is a draft until Legal confirms it · client-side signs are shown beside the scorecard, not mixed into it', rv: ['memory', 'success', 'fixed'] },
  { tool: 'compare crm.nps_response to changes of client lead', res: `${Word(R0.newLead.length)} contracts in the set have a new client lead since their last NPS answer; the score on file is a predecessor's`, warn: true, rv: ['as:t3', 'miss:t3'] },
]
export const ONCE_READ_WEB: Read = { tool: 'search the web · council agendas and local news of the clients in the set', res: `Agendas and articles of the last twelve months read for every client · ${R0.quiet.length} contracts rated 1 or 2 show a client-side sign`, rv: ['as:t3', 'miss:t3', 'web'] }

export const ONCE_QUESTIONS: Question[] = [
  {
    key: 'four',
    title: `${Word(R0.ever.length)} evergreen contracts (${m1(R0.rev(R0.ever))} a year): do they count as up for renewal?`,
    text: 'They have no end date in the next 18 months: they renew by themselves each year. But each agreement lets the client end it on notice, so the client can decide at any time.',
    tiles: [
      { v: 'june', t: 'Count them: the client can leave on notice', s: 'What the Calder Valley review recommends', rec: true },
      { v: 'standin', t: 'Leave them out: no end date in the window', s: `${m1(R0.rev(R0.ever))} a year fewer in the review` },
    ],
  },
  {
    key: 't3',
    title: `${Word(R0.newLead.length)} contracts have a new client lead since their NPS answer: how do I treat the score?`,
    text: 'The Client Satisfaction factor reads the NPS on file. For these contracts it was given by someone who no longer decides. The scorecard has no rule for it.',
    tiles: [
      { v: 'out', t: 'Keep the scorecard you agreed, and flag the score as a predecessor\'s', s: 'The rating does not change; the review says so', rec: true },
      { v: 'expected', t: 'Keep the score and list the contracts separately', s: 'A list for the client experience team' },
      { v: 'approved', t: 'Keep the score as surveyed, no flag', s: 'As the scorecard does today' },
    ],
  },
]

export const ONCE_NODES: Node[] = [
  { id: 'n1', col: 0, row: 1, type: 'compute', title: 'Rate the contracts that decide in the next 18 months', purpose: 'Which contracts are in the window, and what the scorecard says about each.', how: 'End date, renewal options and termination rights read from each agreement; the scorecard rating of each contract, internal and external.', draws: ['master.contract', 'The signed contracts', 'Scorecard'], check: 'Every contract in the set has an end date read from its agreement.' },
  { id: 'n2', col: 1, row: 0, type: 'gather', title: 'Read the client side of each one', purpose: 'Who decides, and what has changed around them.', how: 'For every client in the set: changes of client lead, procurement advisers, in-house operation on agendas, competitors presenting, price reviews. From council agendas, local news, client mail and the NPS record.', draws: ['Council agendas and minutes', 'Local news', 'Outlook: operations mail (A1, A2)', 'crm.nps_response'], check: 'Every sign points at a dated source.' },
  { id: 'n3', col: 1, row: 2, type: 'compute', title: 'Size what is at stake', purpose: 'What each contract is worth, by region and by rating.', how: 'Annual revenue and margin by contract from the contract ledger, summed for the set, for the rated ones and for the quiet ones.', draws: ['fin.contract_pnl', 'master.contract'], check: 'Revenue sums to the contract ledger.' },
  { id: 'n4', col: 2, row: 1, type: 'gather', title: 'Test the scorecard against the renewals we lost', purpose: 'Whether the scorecard would have warned of the three lost since 2024.', how: 'Each lost contract rated on your bands as it stood twelve months before the loss, and what changed in that year.', draws: ['Calder_Valley_Loss_Review_2026-03.pdf', 'Scorecard history', 'Council agendas'], check: 'Each loss has its rating a year before and the dated changes.' },
  { id: 'n5', col: 3, row: 1, type: 'synthesize', title: 'Which to act on, and how', purpose: 'One list of contracts to put on a renewal plan, with what it trades off.', how: 'Weigh planning for every contract at risk against planning only for the rated ones, or starting with the five largest; state the trade-off and every caveat that reached it.', draws: ['Steps 1 to 4', 'Your answers while planning'], check: 'The recommendation names its remaining caveats and the alternatives it rejected.' },
  { id: 'n6', col: 4, row: 1, type: 'deliver', title: 'Build the deliverables you chose', purpose: `What you agreed while planning, built on the recommendation chosen: for ${PEOPLE.owner.split(' ')[0]} by 27 November.`, how: 'The review pack on the 2025 structure; a renewal plan for the contract most at risk; a brief per region. Every figure linked to the step that produced it.', draws: ['Steps 1 to 5', 'Template: renewal review, December 2025'], check: 'Every figure links back to its step.' },
]
export const ONCE_EDGES: [string, string][] = [['n1', 'n2'], ['n1', 'n3'], ['n2', 'n4'], ['n3', 'n4'], ['n4', 'n5'], ['n5', 'n6']]
export const ONCE_FORKS: Record<string, Node> = {
  rc: { id: 'f1', col: 3, row: 2, type: 'scenario', title: 'What-if: the window is 24 months', purpose: 'The review if contracts that decide in the next 24 months are included.', how: 'Widens the window from 18 to 24 months and re-reads the set; shares steps 1 to 3.', draws: ['Steps 1 to 3', 'master.contract'], check: 'Same checks as step 3.', fork: true },
  t3: { id: 'f1', col: 3, row: 2, type: 'scenario', title: 'What-if: the predecessors\' NPS answers are set aside', purpose: 'The ratings if an NPS given by a predecessor counted as no answer.', how: 'Re-rates Customer Relationship for those contracts as a detractor band and re-reads the set; shares steps 1 to 3.', draws: ['Steps 1 to 3', 'crm.nps_response'], check: 'Same checks as step 3.', fork: true },
  four: { id: 'f1', col: 3, row: 2, type: 'scenario', title: 'What-if: the evergreen contracts are left out', purpose: 'The review without the contracts that renew by themselves.', how: 'Takes the evergreen contracts out of the set and re-reads the figures; shares steps 1 to 3.', draws: ['Steps 1 to 3', 'The signed contracts'], check: 'Same checks as step 3.', fork: true },
}

const nineIsIn = (a?: Record<string, string>) => a?.four !== 'standin'
const pctOf = (a: number, b: number) => `${Math.round((a / b) * 100)}%`

export function onceContent(answers?: Record<string, string>): Record<string, NodeContent> {
  const nineIn = nineIsIn(answers)
  const x = rbFigures(nineIn), y = rbFigures(!nineIn)
  const t3 = answers?.t3
  const npsTreat = t3 === 'approved' ? 'Kept as surveyed, no flag (your call)' : t3 === 'expected' ? 'Kept; the contracts listed separately' : 'Kept as written; flagged as a predecessor\'s answer'
  const byRating = [4, 3, 2, 1].map((r) => { const xs = x.set.filter((c) => rating(c, SCORING.rule, 'before') === r); return [`${r}`, String(xs.length), m1(x.rev(xs))] })
  const byRegion = REGIONS.map((g) => { const xs = x.set.filter((c) => c.region === g.name), ps = x.plan.filter((c) => c.region === g.name); return [g.name, g.rvp, String(xs.length), m1(x.rev(xs)), String(ps.length), m1(x.rev(ps))] })
  const signRows = [['A new client lead since the last NPS answer', 'lead'], ['A procurement adviser hired', 'rfp'], ['In-house operation on a council agenda', 'insource'], ['A competitor presenting or newly next door', 'comp'], ['A price review asked for', 'fin']].map(([label, k]) => { const xs = x.set.filter((c) => c.seen.some((s) => s.k === k)); return [label, String(xs.length), m1(x.rev(xs))] })
  return {
    n1: {
      dur: '52 s', conf: 'high', live: ['read 300 agreements', `${x.ending.length} end in 18 months`],
      summary: [`Read the end date, renewal options and termination rights of all 300 agreements. <b>${x.ending.length} end in the next 18 months${nineIn ? `, and ${x.ever.length} more are evergreen contracts the client can end on notice: ${x.n} contracts, ${m1(x.revenue)} a year` : `: ${m1(x.revenue)} a year`}.</b>`, `On the scorecard you agreed, <b>${x.high.length} of them rate 3 or 4</b> (${m1(x.highRev)} a year). The other ${x.n - x.high.length} rate 1 or 2.`],
      table: { cols: ['Scorecard rating', 'Contracts', 'Revenue a year'], num: [1, 2], rows: byRating, tot: ['Decide in 18 months', String(x.n), m1(x.revenue)] },
      receipts: [{ n: 'master.contract', mono: true, m: 'End dates and options, checked against each agreement', drill: d('renewals') }, { n: 'Scorecard · all contracts', m: 'Rating of each contract in the set', drill: d('scorecard') }, { n: 'Ashby_Falls_OM_Agreement_2017.pdf', m: 'Section 2.2: ends 30 June 2027, no option left', drill: d('documents', { doc: 'DOC:af-contract' }) }],
      checks: ['Every end date is read from the agreement, not only from the master list.', 'The ratings are those of the last morning check.'],
      caveats: [],
      trace: ['read_document 300 agreements: term, renewal, termination  → 300 read', `filter end date within 18 months  → ${x.ending.length}`, `filter evergreen and client may end on notice  → ${x.ever.length}`], traceN: 6,
    },
    n2: {
      dur: '1 min 18 s', conf: 'medium', live: ['read council agendas, local news and client mail', `${x.n} clients`],
      summary: [`<b>${Word(x.quiet.length)} contracts that rate 1 or 2 show a client-side sign: ${m1(x.quietRev)} a year.</b> A procurement adviser hired, in-house operation on an agenda, or a new client lead with a year or less to run. The clearest case is Ashby Falls: a new DPW Director since August, seven months left, and in-house operation on the 2 December Select Board agenda.`, `<b>${Word(x.newLead.length)} contracts have a new client lead since their NPS answer.</b> ${nineIn ? `The ${word(x.ever.length)} evergreen contracts are counted, since each client can leave on notice.` : `The ${word(y.ever.length)} evergreen contracts are left out at your call.`}`],
      table: { cols: ['Sign on the client side', 'Contracts', 'Revenue a year'], num: [1, 2], rows: signRows },
      receipts: [{ n: 'Council agendas and minutes', m: 'Read for every client in the set, last twelve months', drill: d('web') }, { n: 'Thread A1 · Introductions: new DPW Director', m: 'Ashby Falls: the client lead changed on 17 August', drill: d('mail', { thread: 'A1' }) }, { n: 'Thread A2 · Request: cost by scope for the Board', m: 'The client is costing the alternatives', drill: d('mail', { thread: 'A2' }) }, { n: 'crm.nps_response', mono: true, m: `NPS on file for the ${word(x.newLead.length)}: ${npsTreat.toLowerCase()}`, drill: d('renewals') }],
      checks: ['Every sign points at a dated agenda, article or message.', 'A sign is never inferred from a rating.'],
      caveats: [nineIn ? { k: 'Assumption', t: `The ${word(x.ever.length)} evergreen contracts are counted as deciding in the window, because each client can end on notice.`, p: 'Set · Revenue at stake · Pack', assume: true, acts: ['Leave the evergreen contracts out'] } : { k: 'Judgement · your call', t: `The ${word(y.ever.length)} evergreen contracts are left out; the review covers ${m1(y.everRev)} a year less for that reason only.`, p: 'Set · Revenue at stake · Pack' }],
      trace: ['read_web council agendas of the clients in the set  → signs by contract', 'read_mail threads A1, A2  → Ashby Falls', 'join crm.nps_response to changes of client lead  → predecessors\' answers'], traceN: 7,
    },
    n2b: {
      dur: '38 s · re-run', conf: 'medium', live: ['remove the evergreen contracts', `${y.ever.length} contracts`],
      summary: [`Re-run after your steer: the ${word(y.ever.length)} evergreen contracts are <b>left out of the review</b>. The set goes from ${y.n} to ${x.n} contracts and from ${m1(y.revenue)} to <b>${m1(x.revenue)}</b> a year; the plan list from ${y.plan.length} to ${x.plan.length}.`, 'That is a judgement, not a reading: each of them can be ended by the client on notice, which is how the next loss could come.'],
      table: { cols: ['Evergreen contracts', 'In the set', 'Revenue a year', 'On the plan list'], num: [1, 2, 3], rows: [['Counted', String(y.n), m1(y.revenue), String(y.plan.length)], ['Left out (your steer)', String(x.n), m1(x.revenue), String(x.plan.length)]] },
      receipts: [{ n: 'The signed contracts', m: 'Evergreen terms and termination on notice', drill: d('renewals') }, { n: 'Your steer', m: '“Leave the evergreen contracts out”' }],
      checks: ['The set recomputes without the evergreen contracts.', 'The contracts with an end date are unchanged.'],
      caveats: [{ k: 'Judgement · from your steer', t: 'Contracts the client can end on notice are left out of the review.', p: 'Set · Revenue at stake · Pack' }],
      trace: [`remove ${y.ever.length} evergreen contracts  → ${x.n} in the set`, `recompute revenue at stake  → ${m1(x.revenue)}`], traceN: 4,
    },
    n3: {
      dur: '47 s', conf: 'high', live: ['sum fin.contract_pnl for the set', `${m1(x.revenue)} a year`],
      summary: [`<b>${m1(x.revenue)} a year decides in the next 18 months; ${x.plan.length} contracts need a renewal plan, ${m1(x.planRev)} a year (${pctOf(x.planRev, x.revenue)}).</b> That is the ${x.high.length} rated 3 or 4 plus the ${x.quiet.length} quiet ones with a client-side sign.`, `The five largest carry ${m1(x.topRev)}: ${x.top.map((c) => `${c.site} (${m1(c.revenue)})`).join(', ')}.`],
      table: { cols: ['Region', 'Regional VP', 'In the set', 'Revenue', 'Need a plan', 'Revenue'], num: [2, 3, 4, 5], rows: byRegion, tot: ['All regions', '', String(x.n), m1(x.revenue), String(x.plan.length), m1(x.planRev)] },
      receipts: [{ n: 'fin.contract_pnl', mono: true, m: 'Revenue and margin by contract, October ledger', drill: d('renewals') }, { n: 'Renewal_Review_2025-12.pptx', m: 'Section 2: revenue at stake by region', drill: d('documents', { doc: 'DOC:renewal-2025' }) }],
      checks: ['Revenue sums to the contract ledger.', 'No contract is counted twice.'],
      caveats: [],
      trace: [`sum fin.contract_pnl where contract in set  → ${m1(x.revenue)}`, `sum plan list  → ${m1(x.planRev)}`], traceN: 5,
    },
    n4: {
      dur: '1 min 06 s', conf: 'medium', live: ['re-rate three lost contracts a year before', '2024 to 2025'],
      summary: [`<b>The scorecard would have rated ${LOST.filter((l) => l.rated <= 2).length} of the 3 lost renewals a 2 a year before the loss.</b> Calder Valley and Wren Hollow were well-run plants; what moved in their last year was on the client side. Thorn Landing rated 3 after two notices of violation and a consent order: the scorecard would have seen that one.`, 'So the scorecard is a fair reading of trouble at the plant and in the setting. It has no signal for a client who is deciding, and that is where two of the three were lost.'],
      table: { cols: ['Lost renewal', 'Lost', 'How', 'Revenue', 'Rated a year before', 'What moved in that year'], num: [3], rows: LOST.map((l) => [`${l.site}, ${l.state}`, l.lost, l.how, m1(l.revenue), `${l.rated} (internal ${f1(l.int)}, external ${f1(l.ext)})`, l.moved.join('; ')]), warn: 0 },
      receipts: [{ n: 'Calder_Valley_Loss_Review_2026-03.pdf', m: 'What changed in the year before', drill: d('documents', { doc: 'DOC:calder-review' }) }, { n: 'Scorecard history', m: 'The three contracts on your bands, twelve months before', drill: d('renewals') }],
      checks: ['Each loss is rated on the same bands and weights as today.', 'Every change in the last year is dated.'],
      caveats: [{ k: 'Assumption', t: 'That the signal values a year before each loss are as the monthly reports of the time recorded them.', p: 'Recommendation · Pack', assume: true }],
      trace: ['recompute Calder Valley at 2024-12  → internal 1.84, external 2.11: rating 2', 'recompute Wren Hollow at 2024-06  → rating 2', 'recompute Thorn Landing at 2023-09  → rating 3'], traceN: 6,
    },
    n5: {
      dur: '34 s', conf: 'medium', live: ['compare three ways to act', 'all at risk · rated only · five largest'],
      summary: [`<b>Put ${x.plan.length} contracts on a renewal plan now: ${m1(x.planRev)} a year.</b> Every contract rated 3 or 4 and every quiet one with a client-side sign gets a named lead before 2 December, starting with the Regional VP meeting the person who decides.`, `The alternatives: plan only the ${x.high.length} rated 3 or 4 (${m1(x.highRev)}; leaves out Ashby Falls), or start with the five largest and wait for the spring NPS survey (several contracts end in June).`],
      receipts: [{ n: 'From steps 1 to 4', m: 'The set, the client side, what is at stake, the back-test' }, { n: 'Your answers while planning', m: 'The evergreen contracts and the predecessors\' NPS' }],
      checks: ['The recommendation names its remaining caveats.', 'Each alternative states what it leaves out.'],
      caveats: [{ k: 'Inherited · 2', t: `${nineIn ? 'The evergreen contracts counted' : 'The evergreen contracts left out'}; the signal values of the back-test taken from the monthly reports.`, p: 'Pack · Plan · Brief', assume: true }],
      trace: ['rank ways to act by: revenue covered, lost-renewal pattern covered, work in December', 'select plan for all at risk'], traceN: 3,
    },
    n6: {
      dur: '49 s', conf: 'medium', live: ['compose from template renewal review, December 2025', 'section 4 of 5'],
      summary: ['Built the deliverables agreed while planning, on the recommendation chosen: the review pack on the 2025 structure, a renewal plan for Ashby Falls, and a brief per region. Every figure is linked to the step that produced it, and the back-test sits where the leadership team will read it.', 'They are on the Deliverables tab, built part by part. Change anything in the chat (another option, the evergreen contracts left out) and they are rebuilt as the next version.'],
      receipts: [{ n: 'From steps 1 to 5', m: 'Figures and the recommendation' }, { n: 'Template: renewal review, December 2025', m: 'Five sections · last year\'s structure' }],
      checks: ['Every figure links back to its step.'],
      caveats: [],
      trace: ['compose pack from template t-prior-renewal-2025  → 5 sections', 'compose plan from t-renewal-plan  → 6 sections', 'compose brief from t-region-brief  → 5 regions'], traceN: 4,
    },
    f1: forkOf('rc', nineIn),
  }
}

function forkOf(kind: 'rc' | 't3' | 'four', nineIn: boolean): NodeContent {
  const x = rbFigures(nineIn), y = rbFigures(!nineIn)
  if (kind === 'rc') {
    const wide = CONTRACTS.filter((c) => !c.evergreen && c.monthsLeft > 18 && c.monthsLeft <= 24)
    const rev = wide.reduce((n, c) => n + c.revenue, 0)
    return { dur: '36 s', conf: 'medium', live: ['widen the window to 24 months', `${wide.length} more contracts`], summary: [`<b>At 24 months</b> the set grows by ${wide.length} contracts and ${m1(rev)} a year, to ${x.n + wide.length} contracts and ${m1(x.revenue + rev)}. ${wide.filter((c) => rating(c, SCORING.rule, 'before') >= 3).length} of the added ones rate 3 or 4. None ends before June 2028, so they can wait for the next quarterly review.`], receipts: [{ n: 'From steps 1 to 3', m: 'Shared with the main run' }, { n: 'master.contract', mono: true, m: 'End dates 18 to 24 months out', drill: d('renewals') }], checks: ['Same checks as step 3.'], caveats: [{ k: 'Inherited', t: 'Same caveats as the main run.', p: 'Pack', assume: true }], trace: ['filter end date within 24 months', 'recompute revenue at stake'], traceN: 3 }
  }
  if (kind === 't3') {
    return { dur: '33 s', conf: 'medium', live: ['set the predecessors\' answers aside', `${x.newLead.length} contracts`], summary: [`<b>If an NPS given by a predecessor counted as no answer</b>, Customer Relationship for those ${word(x.newLead.length)} contracts would be rated on the trend and the regional score only. None of them changes rating on the scorecard: the NPS is one signal in a factor that weighs 10%. That is why a stale score is flagged in the review and not left to the rating.`], receipts: [{ n: 'From steps 1 to 3', m: 'Shared with the main run' }, { n: 'crm.nps_response', mono: true, m: 'Answers dated before the client lead changed', drill: d('renewals') }], checks: ['Same checks as step 3.'], caveats: [{ k: 'Inherited', t: 'Same caveats as the main run.', p: 'Pack', assume: true }], trace: ['drop NPS site score where answer predates the client lead', 'recompute ratings  → none changes'], traceN: 3 }
  }
  return { dur: '31 s', conf: 'medium', live: [nineIn ? 'leave the evergreen contracts out' : 'count the evergreen contracts', `${(nineIn ? x : y).ever.length} contracts`], summary: [nineIn ? `<b>Without the evergreen contracts</b> the set is ${y.n} contracts and ${m1(y.revenue)} a year, and the plan list ${y.plan.length}. They have no end date, but each client can leave on notice.` : `<b>With the evergreen contracts counted</b> the set is ${y.n} contracts and ${m1(y.revenue)} a year, and the plan list ${y.plan.length}.`], receipts: [{ n: 'From steps 1 to 3', m: 'Shared with the main run' }, { n: 'The signed contracts', m: 'Evergreen terms', drill: d('renewals') }], checks: ['Same checks as step 3.'], caveats: [{ k: 'Inherited', t: 'Same caveats as the main run.', p: 'Pack', assume: true }], trace: ['move the evergreen contracts in or out of the set', 'recompute revenue at stake'], traceN: 3 }
}

/** The fork's content depends on which what-if was chosen. */
export function forkContent(kind: 'rc' | 't3' | 'four', answers?: Record<string, string>): NodeContent { return forkOf(kind, nineIsIn(answers)) }

const ONCE_GOAL = GOALS.find((g) => g.id === ONCE_ID)!
const WATCH_GOAL = GOALS.find((g) => g.id === WATCH_ID)!

export function onceFindings(answers?: Record<string, string>): Record<string, JFinding> {
  const nineIn = nineIsIn(answers)
  const x = rbFigures(nineIn)
  const [b1, b2, b3, b4] = ONCE_GOAL.findings
  const h1 = `${x.n} contracts decide in the next 18 months, ${m1(x.revenue)} a year; on the scorecard ${x.high.length} of them rate 3 or 4.`
  const d1 = `${x.ending.length} end by May 2028${nineIn ? ` and ${x.ever.length} are evergreen contracts the client can end on notice` : `; the ${renewals(SCORING.rule, true).ever.length} evergreen contracts are left out at your call`}. The ${x.high.length} rated 3 or 4 carry ${m1(x.highRev)} a year. The other ${x.n - x.high.length} rate 1 or 2, which is where the scorecard would stop looking.`
  const h2 = `${Word(x.quiet.length)} contracts rated 1 or 2 show a client-side sign the scorecard has no signal for: ${m1(x.quietRev)} a year.`
  const h3 = `${x.plan.length} contracts need a renewal plan: ${m1(x.planRev)} a year, ${pctOf(x.planRev, x.revenue)} of the revenue that decides in 18 months.`
  const d3 = `The ${x.high.length} rated 3 or 4 plus the ${x.quiet.length} quiet ones with a client-side sign. The five largest carry ${m1(x.topRev)} a year: ${x.top.map((c) => c.site).join(', ')}.`
  return {
    F1: { id: 'F1', h: h1, d: d1, from: 'n1', cav: [], drill: b1.drill, base: { ...b1, headline: h1, detail: d1 } },
    F2: { id: 'F2', h: h2, d: b2.detail, from: 'n2', cav: ['The evergreen contracts are counted as deciding in the window'], drill: b2.drill, base: { ...b2, headline: h2 } },
    F2b: { id: 'F2b', h: `With the evergreen contracts left out, ${word(x.quiet.length)} quiet contracts show a client-side sign: ${m1(x.quietRev)} a year.`, d: 'Changed after your steer. The evergreen contracts renew by themselves, so they are outside the window; each client can still end on notice, which the review now does not cover.', from: 'n2', cav: ['Contracts the client can end on notice left out · your call'], drill: d('renewals', {}, 'The evergreen contracts are marked as left out.'), base: { ...b2, headline: `With the evergreen contracts left out, ${word(x.quiet.length)} quiet contracts show a client-side sign.` } },
    F3: { id: 'F3', h: h3, d: d3, from: 'n3', cav: [], drill: b3.drill, base: { ...b3, headline: h3, detail: d3 } },
    F4: { id: 'F4', h: b4.headline, d: b4.detail, from: 'n4', cav: ['Signal values a year before each loss are from the monthly reports'], drill: b4.drill, base: b4 },
  }
}

/** The recommendations, with the review as the analyst has it. */
export function onceRecs(answers?: Record<string, string>): Recommendation[] { return onceRecsFor(nineIsIn(answers)) }
export const ONCE_RECS: Recommendation[] = ONCE_GOAL.recommendations
export const ONCE_OUTPUTS: SubmissionSuggestion[] = ONCE_GOAL.submissions
export const ONCE_GAPS = ONCE_GOAL.gaps
export const ONCE_BASE = ONCE_GOAL

/* ------------------------------------------------------------------ the standing goal: the risk of all 300 contracts */

export const WATCH_PROMPT = 'I need to monitor the risk of all the contracts in our portfolio. Work out what the important risk factors and signals are from everything we have connected, and help me build the scorecard: what to measure, how to score it and how much each thing counts. Then watch every contract, and tell me when the risk of one goes up, why, and what we should do about it at that site.'

const srcWord = (k: string) => (k === 'table' ? 'operations data' : k === 'document' ? 'contracts and documents' : k === 'mail' ? 'mail' : 'the public web')
export const WATCH_READS: Read[] = [
  { tool: 'look at what is connected', res: 'Operations data hub (214 tables), the contract repository (2,460 documents), three shared mailboxes and the public web', rv: ['watch', 'src:fin', 'src:proc', 'src:mail', 'src:web'] },
  { tool: 'find the projects · master.contract', res: `${CONTRACTS.length} active operations and maintenance projects in five regions, ${m1(CONTRACTS.reduce((n, c) => n + c.revenue, 0))} a year, booked under ${bookShape().pcs} profit centers and running ${bookShape().facilities} facilities. I give each project one score`, rv: ['against', 'where'] },
  { tool: 'look for a scoring template you already use', res: 'None is connected. I found your Contracting Policy (the non-negotiable terms), three loss reviews and the monthly KPI pack, but nothing that says what to score and how. Upload yours, or I propose one', warn: true, rv: ['miss:frame', 'memory'] },
  { tool: 'read the contracts you lost or left since 2021', res: '7 contracts: 3 lost at renewal, 2 taken in-house, 2 ended early. What came first in each: a new client lead (5 of 7), margin under budget (7 of 7), in-house operation on a public agenda (both in-house losses)', rv: ['prior'] },
  { tool: 'fetch public sources', res: 'richstatespoorstates.org (state liability ranking, 2026 edition) · EPA ECHO (permits) · FEMA flood maps · council and board agendas · municipal bond ratings', rv: ['src:web', 'fixed'] },
  { tool: 'check where each figure sits', res: 'Not everything is recorded by project. Finance figures are booked by profit center, compliance and maintenance by facility, the client survey by client account. I say how each one is brought to the project and ask you to confirm', rv: ['until', 'steps', 'miss:design', 'miss:check'] },
]

export const WATCH_QUESTIONS: Question[] = [
  {
    key: 'frame',
    title: 'Do you have a scoring template?',
    text: 'A file with your factors and their weights, the signals in each factor, and how each signal scores 1 to 4. If you have one I use it exactly as written. If not, I propose a scorecard. Either way it appears on the right once you answer.',
    tiles: [
      { v: 'upload', t: 'Yes, I will upload it', s: 'Use our factors, weights and rules as written' },
      { v: 'none', t: 'No. Propose one', s: 'From what is connected and the contracts already lost' },
    ],
  },
  {
    key: 'design',
    title: 'This is how every project will be scored',
    text: 'The scorecard is on the Plan tab: every factor with its share of the final score, every signal with its weight and its rule for 1 to 4. Drop a signal, add one to a factor, add a factor, or change a weight or a rule, there or here in the chat. The preview shows what each change does to your projects.',
    tiles: [
      { v: 'ok', t: 'Score on it as it stands now', s: 'You can change it at any time, also after the goal is live', rec: true },
    ],
  },
  {
    key: 'check',
    title: 'The data check: a few assumptions need your call',
    text: 'I tested every signal against the connected data. Most are ready. Some figures do not sit at project level (profit center, facility, client account), and one signal has no source. The data check on the plan lists each signal, how it is measured, and the assumptions I would make to get one figure per project.',
    tiles: [
      { v: 'ok', t: 'Confirm the assumptions as they stand', s: 'Or change any of them on the plan first', rec: true },
    ],
  },
]

export const SCHEDULE_QUESTIONS: Question[] = [
  { key: 'tell', title: 'Who is told when it has run?', text: 'The contract master names a Regional VP and a project leader for every contract.', tiles: [{ v: 'me', t: 'Just me', s: 'I decide who hears' }, { v: 'pm', t: 'Me and the Regional VPs', s: 'The owners of the relationships', rec: true }, { v: 'controller', t: 'Me, the Regional VPs and the project leaders', s: 'Everyone who has to act' }] },
]

export const WATCH_NODES: Node[] = [
  { id: 'w1', col: 0, row: 1, type: 'gather', title: 'Read every signal again and re-score', purpose: 'Which contracts changed, and by how much.', how: 'Every signal of every contract read again from its source and scored on your bands; factor scores from your weights; the contracts whose readings changed, with the old and the new score.', draws: ['Operations data hub', 'Contracts and documents', 'Mailboxes', 'Public web'], check: 'Each score recomputes from its signals, bands and weights.' },
  { id: 'w2', col: 1, row: 0, type: 'gather', title: 'Read the evidence behind each change', purpose: 'Why it changed, and what the contract says about it.', how: 'The message, document, row or page behind each changed reading; then the agreement: liability, who pays for the fix, how the client can leave.', draws: ['Mail: legal notices and operations', 'The signed agreements', 'Council agendas and local news'], check: 'Every change points at a dated message, row or page.' },
  { id: 'w3', col: 1, row: 2, type: 'compute', title: 'Weigh what is at stake and where it is heading', purpose: 'Which of the contracts that rose come first.', how: 'Annual revenue, margin, months to a decision and how the contract can end, beside the risk; the twelve-month direction of each score; anything I read that your scorecard does not score.', draws: ['master.contract · fin.contract_pnl', 'Twelve months of scores'], check: 'What is at stake never changes the risk score unless you asked for it.' },
  { id: 'w4', col: 2, row: 1, type: 'synthesize', title: 'Write the mitigation plan for each site', purpose: 'One action for every signal at 3 or 4 that can be moved, for that site.', how: 'For each site: the action, written from the reading, the mail about it, the contract clause and what is public; the owner from the contract master, a date, and the score the plan would bring the project to. Facts of the site are listed, not actioned.', draws: ['Steps 1 to 3', 'The contract master: who owns each contract'], check: 'Every action names the signal it answers, an owner and a date.' },
  { id: 'w5', col: 3, row: 1, type: 'deliver', title: 'Do what you told me to do when risk goes up', purpose: 'Your rules from set-up, applied to what changed this morning.', how: 'The dashboard refreshed; then each rule that applies: tell the people named, build the deck on why it moved, write the plan. A rule set to "ask me first" waits for your OK.', draws: ['Steps 1 to 4', 'Your rules on the Plan tab'], check: 'Only your rules run. Nothing is sent outside the company.' },
]
export const WATCH_EDGES: [string, string][] = [['w1', 'w2'], ['w1', 'w3'], ['w2', 'w4'], ['w3', 'w4'], ['w4', 'w5']]

/** What the morning check of 20 November found, in words, on the scorecard as it stands. */
export function watchStory() {
  const mv = movers(), up = mv.filter((m) => m.r1 > m.r0), rose = mv.filter((m) => m.r1 === m.r0 && m.s1 > m.s0 + 0.004), un = mv.filter((m) => m.unscored.length && m.s1 <= m.s0 + 0.004)
  const names = (xs: typeof mv) => xs.map((m) => shortSite(m.c)).join(' and ')
  const head = up.length ? `${names(up)} moved up a rating` : rose.length ? `${names(rose)} rose, no rating moved` : 'No score rose'
  const short = up.length ? up.map((m) => `${shortSite(m.c)} ${m.r0} to ${m.r1}`).join(', ') : rose.length ? `${names(rose)} rose` : 'nothing rose'
  const nRead = mv.reduce((n, m) => n + m.sigs.length, 0)
  const line = `**${mv.length} of the ${CONTRACTS.length} contracts changed overnight${up.length ? ` and ${up.length === 1 ? 'one' : up.length} moved up a rating: ${up.map((m) => `${m.c.site}, from ${m.r0} to ${m.r1}`).join('; ')}` : ''}.**${rose.length ? ` ${names(rose)} rose inside ${rose.length === 1 ? 'its' : 'their'} rating.` : ''}${un.length ? ` ${names(un)} shows a sign your scorecard does not score.` : ''}`
  return { mv, up, rose, un, head, short, line, nRead }
}
export function watchContent(): Record<string, NodeContent> {
  const S = watchStory(), nAll = CONTRACTS.reduce((n, c) => n + likelihoodSignals().filter((x) => c.v[x.id]).length, 0)
  const cov = specCoverage()
  const ashbyOn = DESIGN.on.cp3, plans = S.mv.filter((m) => m.s1 > m.s0 + 0.004 || m.r1 >= 3).map((m) => ({ m, plan: planFor(m.c, 'after').filter((x) => !x.fixed && !x.later), eff: planEffect(m.c, 'after') }))
  return {
    w1: {
      dur: '24 s', conf: 'high', live: [`re-read ${nAll.toLocaleString('en-US')} readings`, `${S.nRead} changed · ${S.mv.length} contracts`],
      summary: [`At the 06:00 check of 20 November I read all ${nAll.toLocaleString('en-US')} readings again: ${cov.bySrc.map((x) => `${x.n} signals from ${srcWord(x.k)}`).join(', ')}. ${S.line.replace(/\*\*/g, '')}`, `One rating is ${RULE_TEXT[DESIGN.rule]}.`],
      table: { cols: ['Contract', 'Signal', 'Reading', 'Score'], rows: S.mv.flatMap((m) => [...m.sigs.map((x) => [m.c.site, x.s.name, x.raw, `${x.from} → ${x.to}`]), ...m.unscored.map((x) => [m.c.site, x.label, 'Not on your scorecard', ''])]), tot: ['Contract score', '', S.mv.map((m) => `${shortSite(m.c)} ${f1(m.s0)} → ${f1(m.s1)}`).join(' · '), ''], warn: 0 },
      receipts: [{ n: 'Scorecard · all contracts', m: `${CONTRACTS.length} contracts before and after the 06:00 check`, drill: d('scorecard') }, ...S.mv.map((m) => ({ n: `${m.c.id} ${m.c.site}`, m: 'Signal by signal, with what changed marked', drill: d('contract', { contract: m.c.id }) }))],
      checks: ['Each score recomputes from its signals, your bands and your weights.', `The other ${CONTRACTS.length - S.mv.length} contracts have no changed reading.`],
      caveats: [{ k: 'Draft for Legal', t: 'Scores read from contract clauses are drafts until Legal confirms them.', p: 'Dashboard · Deck', assume: true }],
      trace: [`rule contract_risk_rises  → ${CONTRACTS.length} contracts read, ${S.mv.length} changed`, ...S.mv.map((m) => `recompute ${m.c.id}  → ${f1(m.s0)} to ${f1(m.s1)}: rating ${m.r1}`)], traceN: 6,
    },
    w2: {
      dur: '41 s', conf: 'high', live: ['read the demand letter, the agenda and the agreements', `${S.mv.length} contracts`],
      summary: ['<b>Harlow Creek: a demand letter for 23 residents reached the legal notices mailbox at 16:42 on 19 November, and a sixth odor complaint was logged that evening.</b> The letter asks for abatement, the odor records since January 2024 and talks on compensation within 30 days. Five of the six complaints fall on biosolids load-out afternoons. The agreement caps liability at the annual fee and puts odor control capital on the City, which has left the biofilter unfunded since 2023.', '<b>Ashby Falls: the Select Board agenda posted on 19 November lists "options including in-house operation" for 2 December</b>, with a vote to hire a procurement adviser. A competitor presented to the Finance Committee in October. The agreement ends on 30 June 2027 with no renewal option left.', 'Red Mesa: a second missed sample this quarter, on a weekend shift worked on overtime by the one operator who holds the licence the contract requires.'],
      table: { cols: ['Contract', 'What the agreement says', 'What it means here'], rows: [['Harlow Creek', 'Liability capped at the annual fee (14.1); no waiver of consequential damages', `Exposure near ${m2(HARLOW.revenue)} a year, and one of the three terms your policy asks for is missing`], ['Harlow Creek', 'Odor control capital is the City\'s (9.4)', 'The fix that matters is not ours to fund'], ['Ashby Falls', 'One renewal option, used in 2022 (2.2)', 'The Town must re-bid or bring it in-house by June 2027'], ['Red Mesa', 'A Grade 4 licence holder on site (6.3)', 'One holder, no backup']] },
      receipts: [{ n: 'Thread H1 · Notice of claim and demand', m: 'Baines & Ortega LLP, 19 November 16:42', drill: d('mail', { thread: 'H1' }) }, { n: 'Harlow_Creek_Odor_Complaint_Log_2026.xlsx', m: 'Six complaints; five on load-out afternoons', drill: d('documents', { doc: 'DOC:hc-complaints' }) }, { n: 'Harlow_Creek_OM_Agreement_2018.pdf', m: 'Sections 9.4, 14.1, 21.1', drill: d('documents', { doc: 'DOC:hc-contract' }) }, { n: 'Town of Ashby Falls · Select Board agenda, 2 December', m: 'Items 6a and 6b, posted 19 November', drill: d('web', { doc: 'WEB:af-agenda' }) }, { n: 'Red_Mesa_Sampling_Plan_and_Exceptions_2026.pdf', m: 'Both missed samples on weekend overtime shifts', drill: d('documents', { doc: 'DOC:rm-sampling' }) }],
      checks: ['Every change points at a dated message, row or page.', 'Clause readings quote the section.'],
      caveats: [],
      trace: ['read_mail legal-notices thread H1  → demand letter, 23 residents, 30 days', 'read_web ashbyfalls-ma.example agenda 2026-12-02  → items 6a, 6b', 'read_document Harlow_Creek_OM_Agreement_2018.pdf  → 9.4, 14.1, 21.1'], traceN: 7,
    },
    w3: {
      dur: '36 s', conf: 'medium', live: ['weigh what is at stake', `${S.mv.length} contracts`],
      summary: [impactOn() ? `<b>${S.mv.filter((m) => m.p1 === 'Act now').map((m) => shortSite(m.c)).join(' and ') || 'None of them'} ${S.mv.filter((m) => m.p1 === 'Act now').length === 1 ? 'is' : 'are'} now high risk with a lot at stake.</b> Ashby Falls carries ${m1(ASHBY.revenue)} a year and decides in ${ASHBY.monthsLeft} months; Harlow Creek carries ${m1(HARLOW.revenue)} a year and the City can end the agreement on notice.` : 'You left what is at stake out of the scorecard, so I rank the contracts that rose by score alone.', ashbyOn ? 'In-house operation on a public agenda is one of your red flags: on its own it rates Ashby Falls 3. It came before both contracts you lost to in-house operation.' : '<b>Ashby Falls does not move on your scorecard, because it has no signal for the client\'s politics.</b> I show it under "Seen, not scored" and you can add the signal from there. It came before both contracts you lost to in-house operation.'],
      table: { cols: ['Contract', 'Risk', 'At stake', 'Priority', 'Direction, 90 days'], rows: S.mv.map((m) => [m.c.site, `${m.r1} (${f1(m.s1)})`, impactOn() ? `${impactRating(m.c)} · ${m1(m.c.revenue)} a year` : 'left out', m.p1, deltaOf(m.c, 'after') > 0.08 ? 'Rising' : 'Level']) },
      receipts: [{ n: 'master.contract · fin.contract_pnl', m: 'Revenue, margin, end dates and termination rights' }, { n: 'Calder_Valley_Loss_Review_2026-03.pdf', m: 'New client lead, adviser hired, competitor presenting, then lost', drill: d('documents', { doc: 'DOC:calder-review' }) }],
      checks: ['What is at stake is shown beside the risk.', 'Anything unscored is named as unscored.'],
      caveats: [{ k: 'Assumption', t: 'The client survey score on file for Ashby Falls was given by the previous DPW Director.', p: 'Deck', assume: true }],
      trace: ['impact NCO-111  → revenue, margin, 7 months, no option left', 'impact NCO-047  → revenue, termination on notice', 'trend 12 months  → 3 contracts'], traceN: 5,
    },
    w4: {
      dur: '29 s', conf: 'medium', live: ['write the plan for each site', `${plans.reduce((n, x) => n + x.plan.length, 0)} actions`],
      summary: [`A mitigation plan for each contract that rose: <b>${plans.map((x) => `${x.plan.length} actions at ${shortSite(x.m.c)}`).join(', ')}</b>, one for every signal at 3 or 4 that can be moved, each with an owner from the contract master and a date.`, plans.map((x) => `${shortSite(x.m.c)}: if the plan lands the score goes from ${f1(x.eff.from)} to ${f1(x.eff.to)}.`).join(' '), 'Three ways to run it are under Findings. I chose the first: run the full plan at every contract that rose.'],
      table: { cols: ['Contract', 'Actions', 'Score today', 'If the plan lands'], num: [1, 2, 3], rows: plans.map((x) => [x.m.c.site, String(x.plan.length), f1(x.eff.from), f1(x.eff.to)]) },
      receipts: [{ n: 'From steps 1 to 3', m: 'What changed, why, and what is at stake' }, ...plans.map((x) => ({ n: `${x.m.c.id} ${x.m.c.site}`, m: 'The plan, action by action', drill: d('contract', { contract: x.m.c.id }) }))],
      checks: ['Every action names the signal it answers, an owner and a date.', 'Facts of the site are listed, not actioned.'],
      caveats: [{ k: 'Assumption', t: 'Owners come from the contract master; an owner can hand an action on.', p: 'Plan', assume: true }],
      trace: plans.map((x) => `compose plan ${x.m.c.id}  → ${x.plan.length} actions, ${f1(x.eff.from)} to ${f1(x.eff.to)}`), traceN: 4,
    },
    w5: {
      dur: '27 s', conf: 'medium', live: ['apply your rules', 'building'],
      summary: ['Your rules from the Plan tab, applied to what changed this morning. The dashboard is refreshed. For each contract that moved up a rating the people you named are told, and the deck on why it moved and the site plan are built.', 'A rule set to "ask me first" waits for your OK. Nothing goes outside the company.'],
      receipts: [{ n: 'From steps 1 to 4', m: 'Changes, evidence, what is at stake, plans' }, { n: 'Your rules', m: 'Plan tab, the rules' }],
      checks: ['Every figure in the deck links back to its step.'],
      caveats: [],
      trace: ['refresh dashboard  → done', 'apply rules  → see the action list', 'compose deck and plan  → built'], traceN: 3,
    },
  }
}

export function watchFindings(): Record<string, JFinding> {
  const [b1, b2, b3, b4] = WATCH_GOAL.findings
  const S = watchStory()
  const h1 = `${S.mv.length} of the ${CONTRACTS.length} contracts changed overnight: ${S.mv.map(moveLine).join('; ')}.`
  const d1 = `Every reading was read again at 06:00 and scored on your scorecard. ${S.mv.map((m) => `${m.c.site}: ${m.sigs.length ? m.sigs.map((x) => `${x.s.name.toLowerCase()} from ${x.from} to ${x.to}`).join(', ') : 'no scored reading changed'}${flagsOf(m.c, 'after').length && m.r1 > m.r0 ? ' (a red flag)' : ''}.`).join(' ')} One rating is ${RULE_TEXT[DESIGN.rule]}.`
  const ash = S.mv.find((m) => m.c.id === 'NCO-111'), red = S.mv.find((m) => m.c.id === 'NCO-184')
  const h4 = ash && ash.r1 > ash.r0 ? `Ashby Falls moves to ${ash.r1}: in-house operation is on the 2 December agenda, seven months before a ${m1(ASHBY.revenue)} contract ends.` : `Ashby Falls does not move on your scorecard, and it is the contract most likely to be lost: ${m1(ASHBY.revenue)} a year, ending in seven months.`
  const h3 = red && red.s1 > red.s0 + 0.004 ? `Red Mesa rose to ${f1(red.s1)} and still rates ${red.r1}: a second missed sample, with one licence holder covering weekends.` : b3.headline
  const mk = (b: typeof b1, h: string, dd: string) => ({ ...b, headline: h, detail: dd })
  return {
    W1: { id: 'W1', h: h1, d: d1, from: 'w1', cav: ['Clause readings are drafts for Legal'], drill: b1.drill, base: mk(b1, h1, d1) },
    W2: { id: 'W2', h: b2.headline, d: b2.detail, from: 'w2', cav: [], drill: b2.drill, base: b2 },
    W3: { id: 'W3', h: h3, d: b3.detail, from: 'w3', cav: ['Still inside its rating'], drill: b3.drill, base: mk(b3, h3, b3.detail) },
    W4: { id: 'W4', h: h4, d: b4.detail, from: 'w3', cav: [DESIGN.on.cp3 ? 'A red flag on your scorecard' : 'Not scored on your scorecard'], drill: b4.drill, base: mk(b4, h4, b4.detail) },
  }
}
export const WATCH_RECS: Recommendation[] = WATCH_GOAL.recommendations
export const WATCH_OUTPUTS: SubmissionSuggestion[] = WATCH_GOAL.submissions
export const WATCH_GAPS = WATCH_GOAL.gaps
export const WATCH_BASE = WATCH_GOAL

/** What the agent does once a standing goal's recommendation is chosen, by option. Shown as a confirm card, then run. */
export const WATCH_EXECUTE: Record<string, { title: string; steps: string[]; done: string }> = {
  r1: { title: 'Run the full plan at every contract that rose', steps: ['Refresh the dashboard', 'Tell the owners of each contract that moved up', 'Build the deck on why it moved', 'Write the plan for each site'], done: 'The dashboard is refreshed, the owners are told, and the deck and the site plans are built.' },
  r2: { title: 'Plans only where a rating moved', steps: ['Refresh the dashboard', 'Tell the owners of each contract that moved up', 'Build the deck and the plan for those contracts', 'List the rest in the Monday digest'], done: 'The owners are told and the deck and plans are built for the contracts that moved a rating.' },
  r3: { title: 'Tell the owners and take it to the 2 December review', steps: ['Refresh the dashboard', 'Tell the owners of each contract that moved up', 'Add the contracts to the agenda of the 2 December review'], done: 'The owners are told; the contracts are on the 2 December agenda.' },
}

/* ------------------------------------------------------------------ the generic goal: honest about what it cannot do */

export const GENERIC_READS = (goal: string): Read[] => [
  { tool: 'resolve the goal against the role graph', res: `“${goal.slice(0, 70)}${goal.length > 70 ? '…' : ''}” → the signals of the scorecard, 300 contracts, documents and mail`, rv: ['scope', 'decision'] },
  { tool: 'read the scorecard', res: `300 contracts · ${portfolio('max', 'before').readings.toLocaleString('en-US')} readings at the last morning check`, rv: ['src:fin'] },
  { tool: 'scan master.contract · the signed contracts', res: '300 agreements with scope, term and termination rights', rv: ['src:ppm'] },
  { tool: 'read Outlook · OneDrive', res: 'Operations and legal notices mail, and the documents linked to the contracts', rv: ['src:mail'] },
  { tool: 'search role memory', res: 'The scorecard is used as written · clause readings are drafts for Legal · client-side signs sit beside the rating', rv: ['memory', 'success', 'fixed'] },
  { tool: 'match the goal to a recorded analysis', res: 'No recorded analysis in this copy matches it; I can run the steps and show what the graph holds, but the findings will be thin', warn: true, rv: ['miss:generic'] },
]
export const GENERIC_NODES: Node[] = [
  { id: 'g1', col: 0, row: 1, type: 'gather', title: 'Ground the goal in the role graph', purpose: 'Which signals, contracts and documents the goal names.', how: 'Resolve every term in the goal to a signal, a contract or a document; list anything that does not resolve.', draws: ['Contract Risk Analyst graph v1'], check: 'Every term maps to something the graph holds, or is listed as unresolved.' },
  { id: 'g2', col: 1, row: 1, type: 'compute', title: 'State the current position with its components', purpose: 'Ratings, factors and signals for everything in scope.', how: 'From the latest morning check.', draws: ['Scorecard', 'Operations data hub'], check: 'Ratings recompute from their signals.' },
  { id: 'g3', col: 2, row: 1, type: 'gather', title: 'Read what the documents and the mailbox say that the tables do not', purpose: 'Dated statements that differ from the data.', how: 'Client, regulator and internal statements with dates.', draws: ['Outlook mailboxes', 'OneDrive documents', 'Public web'], check: 'Nothing is attributed without a dated reference.' },
  { id: 'g4', col: 3, row: 1, type: 'synthesize', title: 'Set out the ways forward and test them against the constraints', purpose: 'At least two courses of action and "do nothing".', how: 'Each with what it changes and who must agree.', draws: ['Steps 1 to 3'], check: 'No course of action breaks a stated constraint.' },
]
export const GENERIC_EDGES: [string, string][] = [['g1', 'g2'], ['g2', 'g3'], ['g3', 'g4']]
export function genericContent(): Record<string, NodeContent> {
  const p = portfolio(SCORING.rule, 'now')
  const c = (title: string, live: [string, string], summary: string[], trace: string[]): NodeContent => ({ dur: '30 s', conf: 'low', live, summary, receipts: [{ n: 'Contract Risk Analyst graph v1', m: title }], checks: ['Passed, with unresolved terms listed.'], caveats: [{ k: 'No recorded analysis', t: 'This copy carries recorded analyses for the renewal review and the contract risk watch only. The figures here are the graph\'s position, not an answer to the goal.', p: 'Findings' }], trace, traceN: trace.length })
  return {
    g1: c('resolve', ['resolve terms', 'the scorecard'], ['Resolved the goal\'s terms against the signals of the scorecard and the entity types in the graph. One or more terms do not resolve to anything the graph computes.'], ['resolve  → matched signals and contracts; unresolved terms listed']),
    g2: c('position', ['read the scorecard', '300 contracts'], [`The portfolio stands at ${p.dist[1]} contracts rated low, ${p.dist[2]} low to medium, ${p.dist[3]} medium to high and ${p.dist[4]} high.`], ['read scorecard  → 300 contracts']),
    g3: c('read', ['read_mail outlook', 'threads and documents'], ['Read the mail threads and documents linked to the contracts in scope; dated statements that differ from the data are listed with their reference.'], ['read_mail  → threads', 'read_document  → documents']),
    g4: c('compose', ['compose options', '2 + do nothing'], ['No recorded analysis in this copy matches the goal, so I can only set out the position. The two example goals carry full findings and recommendations.'], ['compose  → 2 courses of action and do nothing']),
  }
}

/* ------------------------------------------------------------------ files reachable from the connectors */

export const LIB: Record<string, LibFile> = {
  deck: { id: 'deck', n: 'Renewal_Review_2025-12.pptx', ext: 'PowerPoint · 1.8 MB', from: 'onedrive', icon: 'sheet', drill: d('documents', { doc: 'DOC:renewal-2025' }) },
  q2min: { id: 'q2min', n: 'Calder_Valley_Loss_Review_2026-03.pdf', ext: 'PDF · 240 KB', from: 'onedrive', icon: 'doc', drill: d('documents', { doc: 'DOC:calder-review' }) },
  fcwork: { id: 'fcwork', n: 'Renewal_review_working_notes_2026-11.xlsx', ext: 'Excel · 38 KB', from: 'onedrive', icon: 'sheet', drill: d('documents', { doc: 'DOC:my-notes' }) },
  rc: { id: 'rc', n: 'Contract_Risk_Framework_draft.xlsx', ext: 'Excel · 96 KB', from: 'onedrive', icon: 'sheet', drill: d('documents', { doc: 'DOC:risk-spec' }) },
  p5: { id: 'p5', n: 'Re: Renewal risk review for 2 December', ext: 'Thread P2 · Tom Brandvold · 17 Nov', from: 'outlook', icon: 'mail', drill: d('mail', { thread: 'P2' }) },
  c3: { id: 'c3', n: 'Introductions: new DPW Director', ext: 'Thread A1 · Ashby Falls · 19 Aug', from: 'outlook', icon: 'mail', drill: d('mail', { thread: 'A1' }) },
  p2: { id: 'p2', n: 'Renewal risk review for 2 December', ext: 'Thread P1 · Renee Halvorsen · 16 Nov', from: 'outlook', icon: 'mail', drill: d('mail', { thread: 'P1' }) },
}

/** The analysis, run on a schedule instead of once (a one-off goal made standing). */
export const SCHEDULE_READS: Read[] = [
  { tool: 'read the review calendar', res: 'The portfolio review meets on the first Wednesday of each quarter; the next after 2 December is 3 February 2027', rv: ['where', 'src:cal'] },
  { tool: 'reuse the agreed plan', res: 'Six steps, no checkpoint, from the goal you just ran', rv: ['watch', 'steps'] },
  { tool: 'scan master.contract · the scorecard', res: 'End dates, options and ratings, read fresh each run; agendas and mail are read at run time', rv: ['against', 'src:fin'] },
  { tool: 'search for a distribution list', res: 'No leadership list is connected; I need to know who to tell', warn: true, rv: ['miss:tell'] },
]

export const shortProject = (code: string) => { const c = CONTRACTS.find((x) => x.id === code); return c ? `${c.id} ${c.site}` : code }

/* 4 Nov 2026: the deliverables each goal offers and the actions a standing goal may take, as the package writes them. */
export const JOURNEYS_RAW = DF as unknown as J4
type J4 = { once: { extraDeliverables: SubmissionSuggestion[] }; watch: { extraDeliverables: SubmissionSuggestion[]; actions: { categories: never[]; tellNames: Record<string, string>; byOption: Record<string, { cat: string; text: string }[]> } }; schedule: { actions: { categories: never[]; run: { cat: string; text: string }[] } }; generic: { deliverables: never[]; actions: { categories: never[] } } }
