/*
 * The scoring template as a spreadsheet file: read one you upload, or write one to fill in.
 * One row per signal: the group, the factor and its weight, the signal and its weight, when it scores 1, 2, 3
 * and 4, how it is measured, and whether it is a red flag. The file is read as written; nothing is added to it.
 */
import * as XLSX from 'xlsx'
import { TEMPLATE_FILE, templateRows, type TplRow } from './risk'

export const TEMPLATE_COLUMNS = ['Group', 'Factor', 'Factor weight (%)', 'Signal', 'Signal weight (%)', 'Scores 1 when (good)', 'Scores 2 when', 'Scores 3 when', 'Scores 4 when (bad)', 'How it is measured', 'Red flag']
const num = (x: unknown): number | null => { if (x === null || x === undefined || x === '') return null; const n = typeof x === 'number' ? x : parseFloat(String(x).replace(/[%,\s]/g, '')); return Number.isFinite(n) ? (n > 0 && n <= 1 && typeof x === 'number' ? n * 100 : n) : null }
const txt = (x: unknown) => (x === null || x === undefined ? '' : String(x).trim())

/** Read the rows of a template from the bytes of an .xlsx, .xls or .csv file. Empty when no table with Factor and Signal is found. */
export function readTemplate(buf: ArrayBuffer): TplRow[] {
  let wb: XLSX.WorkBook
  try { wb = XLSX.read(buf, { type: 'array' }) } catch { return [] }
  for (const name of wb.SheetNames) {
    const grid = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[name], { header: 1, defval: '', blankrows: false })
    const h = grid.findIndex((r) => { const t = r.map((c) => txt(c).toLowerCase()); return t.some((c) => c === 'signal' || c.startsWith('signal')) && t.some((c) => c === 'factor' || c.startsWith('factor')) })
    if (h < 0) continue
    const head = grid[h].map((c) => txt(c).toLowerCase())
    const col = (test: (c: string) => boolean) => head.findIndex(test)
    const C = {
      group: col((c) => c.startsWith('group') || c.startsWith('area')),
      factor: col((c) => c.startsWith('factor') && !c.includes('weight')), fw: col((c) => c.startsWith('factor') && c.includes('weight')),
      signal: col((c) => c.startsWith('signal') && !c.includes('weight')), sw: col((c) => c.startsWith('signal') && c.includes('weight')),
      b: [1, 2, 3, 4].map((n) => col((c) => new RegExp(`^(scores?|rating|risk)?\\s*${n}\\b`).test(c))),
      how: col((c) => c.includes('measured') || c.includes('definition')), flag: col((c) => c.includes('red flag') || c === 'flag'),
    }
    if (C.signal < 0 || C.factor < 0) continue
    const out: TplRow[] = []
    let group = '', factor = '', fw: number | null = null
    for (const r of grid.slice(h + 1)) {
      const g = C.group >= 0 ? txt(r[C.group]) : '', f = txt(r[C.factor]), sig = txt(r[C.signal])
      if (g) group = g
      if (f && f !== factor) { factor = f; fw = C.fw >= 0 ? num(r[C.fw]) : null } else if (C.fw >= 0 && num(r[C.fw]) !== null) fw = num(r[C.fw])
      if (!sig || !factor) continue
      out.push({ group, factor, fw, signal: sig, sw: C.sw >= 0 ? num(r[C.sw]) : null, b: C.b.map((i) => (i >= 0 ? txt(r[i]) : '')), how: C.how >= 0 ? txt(r[C.how]) : '', flag: C.flag >= 0 && /^(y|yes|true|x|1)$/i.test(txt(r[C.flag])) })
    }
    if (out.length) return out
  }
  return []
}

/** The template as a workbook, filled with the whole framework, ready to edit and upload. */
export function templateWorkbook(): XLSX.WorkBook {
  const rows = templateRows()
  const aoa: (string | number)[][] = [TEMPLATE_COLUMNS, ...rows.map((r) => [r.group, r.factor, r.fw ?? '', r.signal, r.sw ?? '', r.b[0] ?? '', r.b[1] ?? '', r.b[2] ?? '', r.b[3] ?? '', r.how, r.flag ? 'Yes' : ''])]
  const ws = XLSX.utils.aoa_to_sheet(aoa)
  ws['!cols'] = [22, 30, 12, 40, 12, 34, 30, 30, 34, 60, 9].map((wch) => ({ wch }))
  const how = XLSX.utils.aoa_to_sheet([['How to use this template'], ['One row per signal. Change a weight, rewrite a rule, delete a row, or add a row for a signal or a factor of your own.'], ['Factor weights are shares inside their group. Signal weights are shares inside their factor. They do not have to add up to 100; shares are worked out from what you write.'], ['1 is good, 4 is bad. Leave a score empty if the signal does not use it.'], ['Red flag: write Yes and the signal alone rates a project 3 when it scores 4.'], ['"What is at stake" is read beside the risk score. It has no factor weight.']])
  how['!cols'] = [{ wch: 130 }]
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Scorecard'); XLSX.utils.book_append_sheet(wb, how, 'How to use')
  return wb
}
export function downloadTemplate() { XLSX.writeFile(templateWorkbook(), TEMPLATE_FILE) }
