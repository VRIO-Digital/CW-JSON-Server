/*
 * Templates a submission can follow. Three families come from what Northline Contract Operations
 * produces about its contracts: contract risk (briefs, the scorecard dashboard, the monthly review, the
 * mitigation tracker), renewals (plans and regional briefs) and client reporting (the version that can
 * leave the company); the fourth is the author's own prior deliverables, recognised by file name. A
 * template is a section list; each section names the role it plays, so content from a goal lands in
 * the right place.
 */

export type SectionRole = 'purpose' | 'summary' | 'findings' | 'options' | 'why' | 'evidence' | 'assumptions' | 'next' | 'free'

export type OutputFormat = 'Document' | 'Memo' | 'Slide pack' | 'Dashboard' | 'Workbook' | 'Email'
export type TemplateFamily = 'Contract risk' | 'Renewals' | 'Client reporting' | 'Your prior deliverables' | 'Your file' | 'Described for a goal'

export interface Template {
  id: string
  name: string
  family: TemplateFamily
  format: OutputFormat
  note: string
  /** The template document in the demo data package (prototypes/goals_submissions/templates/). */
  file?: string
  sections: { heading: string; role: SectionRole; hint?: string }[]
}

export const TEMPLATES: Template[] = [
  {
    id: 't-prior-renewal-2025',
    name: 'Renewal review, December 2025 (as presented).pptx',
    family: 'Your prior deliverables',
    format: 'Slide pack',
    note: 'Your pack to the leadership team last December, structure read from the file: five sections.',
    file: 'Renewal_Review_2025-12.pptx',
    sections: [
      { heading: 'Contracts that decide in the next 18 months', role: 'summary' },
      { heading: 'Revenue at stake, by region', role: 'findings', hint: 'The set by region with revenue, and the contracts that need a plan.' },
      { heading: 'Contracts on a renewal plan', role: 'findings', hint: 'Rated 3 or 4, and the quiet ones with a client-side sign.' },
      { heading: 'Lessons from the renewals we lost', role: 'findings', hint: 'The back-test: how the scorecard rated each a year before.' },
      { heading: 'Decisions asked of the leadership team', role: 'options' },
      { heading: 'What we do not know', role: 'assumptions' },
      { heading: 'Sources', role: 'evidence' },
    ],
  },
  {
    id: 't-renewal-plan',
    name: 'Renewal plan',
    family: 'Renewals',
    format: 'Memo',
    note: 'For one contract: who decides, what they will weigh, and what to do before each date.',
    file: 'Renewal_plan_template.docx',
    sections: [
      { heading: 'The contract and what is at stake', role: 'purpose' },
      { heading: 'Who decides, and what has changed', role: 'findings', hint: 'The client lead, the agenda, the competitor.' },
      { heading: 'What the record shows', role: 'findings', hint: 'The scorecard rating and the results delivered.' },
      { heading: 'What we do, by when', role: 'options' },
      { heading: 'Why this plan', role: 'why' },
      { heading: 'Open points', role: 'assumptions' },
      { heading: 'Evidence', role: 'evidence' },
    ],
  },
  {
    id: 't-region-brief',
    name: 'Regional brief',
    family: 'Renewals',
    format: 'Document',
    note: 'One page per region for the Regional VP: the contracts on the plan list and who leads each.',
    file: 'Regional_brief_template.docx',
    sections: [
      { heading: 'What decides in your region', role: 'summary' },
      { heading: 'Contracts that need a plan', role: 'findings', hint: 'By region, largest first.' },
      { heading: 'What we ask of you', role: 'options' },
      { heading: 'Next dates', role: 'next' },
      { heading: 'Sources', role: 'evidence' },
    ],
  },
  {
    id: 't-client-review',
    name: 'Client partnership review',
    family: 'Client reporting',
    format: 'Document',
    note: 'A version for the client: results delivered and what is proposed. Internal ratings and plans are left out.',
    file: 'Client_partnership_review_template.docx',
    sections: [
      { heading: 'What this review covers', role: 'purpose' },
      { heading: 'Results delivered for the Town', role: 'findings', hint: 'Compliance, safety, response and investment recommended.' },
      { heading: 'What the next term could look like', role: 'options' },
      { heading: 'Next steps', role: 'next' },
    ],
  },
  {
    id: 't-backtest-note',
    name: 'Back-test note',
    family: 'Contract risk',
    format: 'Memo',
    note: 'Whether the scorecard would have warned of events that already happened.',
    file: 'Backtest_note_template.docx',
    sections: [
      { heading: 'What was tested', role: 'purpose' },
      { heading: 'The renewals we lost, rated a year before', role: 'findings', hint: 'The three lost renewals on your bands.' },
      { heading: 'What moved before each loss', role: 'findings', hint: 'Client-side signs.' },
      { heading: 'What to add beside the scorecard', role: 'options' },
      { heading: 'Limits of the test', role: 'assumptions' },
      { heading: 'Evidence', role: 'evidence' },
    ],
  },
  {
    id: 't-risk-brief',
    name: 'Why it moved',
    family: 'Contract risk',
    format: 'Slide pack',
    note: 'A short deck for the people who own a contract whose risk went up: what moved, the evidence, what is at stake and the plan for the site.',
    file: 'Why_it_moved_deck_template.pptx',
    sections: [
      { heading: 'What moved this morning', role: 'purpose' },
      { heading: 'Why the score went up', role: 'findings', hint: 'The signals that changed, with the old and the new score.' },
      { heading: 'Harlow Creek: the demand letter, and what the contract says', role: 'findings', hint: 'Liability, who funds the fix, how the client can leave.' },
      { heading: 'Red Mesa: rising inside its rating', role: 'findings', hint: 'Still rated 2.' },
      { heading: 'Ashby Falls: in-house operation on the agenda', role: 'findings', hint: 'Seven months before the contract ends.' },
      { heading: 'The plan for each site', role: 'options', hint: 'One action per signal, with an owner and a date.' },
      { heading: 'Why this plan', role: 'why' },
      { heading: 'Open points', role: 'assumptions' },
      { heading: 'Evidence', role: 'evidence' },
    ],
  },
  {
    id: 't-risk-plan',
    name: 'Site mitigation plan',
    family: 'Contract risk',
    format: 'Document',
    note: 'For the project leader and the Regional VP: one action for every signal at 3 or 4 that can be moved, written for the site, and the score the plan would bring it to.',
    file: 'Site_mitigation_plan_template.docx',
    sections: [
      { heading: 'What this plan is for', role: 'purpose' },
      { heading: 'Why the score went up', role: 'findings', hint: 'The signals that changed.' },
      { heading: 'The plan for each site', role: 'options', hint: 'One action per signal, with an owner and a date.' },
      { heading: 'What the plan would do to the score', role: 'why' },
      { heading: 'Facts of the site, and open points', role: 'assumptions' },
    ],
  },
  {
    id: 't-risk-scorecard',
    name: 'Contract risk dashboard',
    family: 'Contract risk',
    format: 'Dashboard',
    note: 'The dashboard you designed, for all contracts, rebuilt after every check.',
    file: 'Contract_risk_dashboard_template.html',
    sections: [
      { heading: 'Where the portfolio stands', role: 'summary' },
      { heading: 'What changed since the last check', role: 'findings', hint: 'Contracts whose readings changed.' },
      { heading: 'Ratings by region', role: 'findings' },
      { heading: 'The action list: high risk with a lot at stake', role: 'findings' },
      { heading: 'What needs a decision', role: 'options' },
      { heading: 'Sources', role: 'evidence' },
    ],
  },
  {
    id: 't-risk-review-pack',
    name: 'Monthly portfolio review',
    family: 'Contract risk',
    format: 'Slide pack',
    note: 'For the leadership team each month: where the portfolio stands, what moved, and what to discuss.',
    file: 'Monthly_portfolio_review_template.pptx',
    sections: [
      { heading: 'The portfolio this month', role: 'summary' },
      { heading: 'What moved, and why', role: 'findings' },
      { heading: 'Ratings by region', role: 'findings' },
      { heading: 'Actions open and overdue', role: 'findings' },
      { heading: 'Contracts to discuss', role: 'options' },
      { heading: 'Open points', role: 'assumptions' },
      { heading: 'Sources', role: 'evidence' },
    ],
  },
  {
    id: 't-risk-tracker',
    name: 'Mitigation tracker',
    family: 'Contract risk',
    format: 'Workbook',
    note: 'Every open action with its contract, signal, owner, date and state.',
    file: 'Mitigation_tracker_template.xlsx',
    sections: [
      { heading: 'Summary', role: 'summary' },
      { heading: 'Actions open and overdue', role: 'findings', hint: 'By contract, owner and due date.' },
      { heading: 'What needs a decision', role: 'options' },
      { heading: 'Sources', role: 'evidence' },
    ],
  },
]

/** A template made from a file the author names; the structure is generic because only the name is read here. */
export const templateFromFile = (fileName: string): Template => ({
  id: `t-file-${Date.now().toString(36)}`,
  name: fileName,
  family: 'Your file',
  format: /\.pptx$/i.test(fileName) ? 'Slide pack' : /\.xlsx$/i.test(fileName) ? 'Workbook' : 'Document',
  note: 'Structure read from the file name only in this prototype; the product would read the file.',
  sections: [
    { heading: 'Purpose', role: 'purpose' },
    { heading: 'Summary', role: 'summary' },
    { heading: 'Analysis', role: 'findings' },
    { heading: 'Options', role: 'options' },
    { heading: 'Evidence', role: 'evidence' },
    { heading: 'Assumptions', role: 'assumptions' },
    { heading: 'Next steps', role: 'next' },
  ],
})
