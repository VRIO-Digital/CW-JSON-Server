import AskRiskPage from './pages/AskRisk'
import type { RouteObject } from 'react-router-dom'
import App from './App'
import DatasetPathGate from './components/shell/DatasetPathGate'
import DatasetRedirect from './components/shell/DatasetRedirect'
import RequireAuth from './components/shell/RequireAuth'
import { LANDING } from './nav'
import DoctorPage from './pages/DoctorPage'
import StaticDocPage from './pages/StaticDocPage'
import GoalsPage from './pages/GoalsPage'
import SubmissionsPage from './pages/SubmissionsPage'
import LoginPage from './pages/LoginPage'
import NotFoundPage from './pages/NotFoundPage'
import NewRolePage from './pages/NewRolePage'
import GraphStudioPage from './pages/GraphStudioPage'
import GraphCanvasFullPage from './pages/GraphCanvasFullPage'
import BlankPage from './pages/BlankPage'

/* A build that carries one journey only (VITE_CW_ONLY=goals|submissions) shows New Role and Graph Studio as blank pages; the combined and the roles build carry them. */
const ONLY = (import.meta as unknown as { env: Record<string, string | undefined> }).env?.VITE_CW_ONLY
const ROLES_ON = !ONLY || ONLY === 'roles'

/*
 * Element routes only — no loaders, actions, or SSR. See the ALLOWLIST note in
 * scripts/audit-gate.mjs for why that matters to the audit gate.
 *
 * Kept separate from the history binding in main.tsx so the table can be
 * mounted on a memory router in tests.
 */
export const routes: RouteObject[] = [
  // Outside RequireAuth on purpose: this is the one page reachable while
  // signed out, and the only one with no sidebar to render.
  { path: '/login', element: <LoginPage /> },

  /*
   * The settings/users/connectors description, at a path somebody can type.
   *
   * The document lives in `public/` and Vite already serves it under its own long filename; this is the
   * short address for it. **Reachable signed out**, like `/login` and for the same reason — it is a
   * document to be read, and behind the gate a typed URL would bounce to the login and never show it.
   * Nothing on it is tenant data.
   *
   * A sibling of `/login`, not a child: react-router matches these paths exactly, so `/login` does not
   * swallow `/login/data` and the declaration order does not matter here. That is worth stating because
   * the opposite is true elsewhere in this table — `graph-studio/:useCaseId` *does* match its child's
   * parent segment, which is why the canvas route below has to come first.
   */
  {
    path: '/login/data',
    element: (
      <StaticDocPage
        file="context-weave-settings-users-connectors-use-description.html"
        title="Context Weave — settings, users and connectors"
      />
    ),
  },

  /*
   * The diagnostics page — the frontend's `GET /health`.
   *
   * **Outside `RequireAuth`, and that is the whole point.** It reports which API this bundle calls,
   * whether that API answers, which store answered, whether the dataset header arrives, and which
   * preconditions are unmet — and an unreachable API breaks the sign-in first, so a page behind the
   * sign-in could not report it. A diagnostics screen that needs the app to be working is a
   * diagnostics screen for a state nobody needs diagnosed.
   *
   * **Outside `/:ds` too**, so `DatasetPathGate` does not rewrite its address: the page reports the
   * selected dataset as a *fact*, and being redirected on the way in is precisely the behaviour it may
   * have to explain. It signs nobody in and changes nothing, so it exposes no tenant data beyond the
   * counts it prints — and it is URL-only, with no `NAV_ITEMS` entry, by the same rule as `/db`.
   */
  { path: '/doctor', element: <DoctorPage /> },

  {
    element: <RequireAuth />,

    children: [
      /*
       * ---------------- the dataset is the first segment of every in-app URL ----------------
       *
       * `/E/sources`, `/C/reports` — the selected dataset's first letter, so the address says which
       * dataset the page is showing. `DatasetPathGate` renders at `/:ds` and corrects a URL whose letter
       * is wrong or missing; the selection is the authority and the URL is its rendering, because
       * adopting a typed letter would change dataset without the confirmation and sign-out that make
       * the switch safe.
       *
       * `/` has no segment to match, so it redirects on its own — through a component rather than a
       * `<Navigate>` built here, since the table is constructed once at module load and would freeze
       * the dataset selected at that moment.
       */
      { path: '/', element: <DatasetRedirect to={LANDING} /> },

      /*
       * The canvas with the whole window, opened in a new tab by the **Full view**
       * button on the studio's Canvas tab.
       *
       * Deliberately a sibling of the `App` tree rather than a child of it: `App`
       * renders the sidebar, and 189 nodes want those 240px. It is the only page
       * besides `/login` outside that shell, and for the opposite reason — `/login`
       * has nothing to navigate to, and this has nothing to spare. Still inside
       * `RequireAuth`, so an unauthenticated URL redirects like everything else, and
       * still URL-only with no `NAV_ITEMS` entry, by the same rule as `/db`.
       *
       * It must sit **before** the `App` route: `graph-studio/:useCaseId` would
       * otherwise match `graph-studio/x/canvas`'s parent segment and the studio page
       * would win.
       */
      {
        path: '/:ds',
        element: <DatasetPathGate />,

        children: [
          ...(ROLES_ON ? [{ path: 'graph-studio/:useCaseId/canvas', element: <GraphCanvasFullPage /> }] : []),

          {
            /*
             * Pathless, so its children's paths are relative to `/:ds` and the shell is one level of
             * nesting rather than a second path to keep in step. The same layout-route shape
             * `RequireAuth` uses above.
             */
            element: <App />,

            children: [
          /* The same landing page the login falls back to — Ask, what the console is for. `LANDING` is
             declared once here and imported by `LoginPage`; two answers to "where does no particular page
             go" would send a fresh sign-in and a bare `/` to different places. */
          { index: true, element: <DatasetRedirect to={LANDING} /> },
          { path: 'goals', element: <GoalsPage /> },
          { path: 'goals/:goalId', element: <GoalsPage /> },
          { path: 'submissions', element: <SubmissionsPage /> },
          { path: 'submissions/:submissionId', element: <SubmissionsPage /> },
          { path: 'aisubmission', element: <SubmissionsPage /> },
          /* The rest of the product stays in the sidebar for orientation; this prototype does not redesign it. */
          { path: 'ask', element: <AskRiskPage /> },
          { path: 'what-if', element: <BlankPage /> },
          { path: 'reports', element: <BlankPage /> },
          { path: 'new-graph', element: ROLES_ON ? <NewRolePage /> : <BlankPage /> },
          { path: 'sources', element: <BlankPage /> },
          { path: 'catalog', element: <BlankPage /> },
          { path: 'graph-studio', element: ROLES_ON ? <GraphStudioPage /> : <BlankPage /> },
          { path: 'graph-studio/:useCaseId', element: ROLES_ON ? <GraphStudioPage /> : <BlankPage /> },
          { path: 'audit', element: <BlankPage /> },
          { path: 'settings', element: <BlankPage /> },
          { path: '*', element: <NotFoundPage /> },
            ],
          },
        ],
      },
    ],
  },
]
