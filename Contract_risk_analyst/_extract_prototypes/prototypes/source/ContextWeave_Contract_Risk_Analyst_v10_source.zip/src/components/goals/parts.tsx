import {
  BellOutlined,
  BulbOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  CompassOutlined,
  ExperimentOutlined,
  FileSearchOutlined,
  MailOutlined,
  QuestionCircleOutlined,
  RadarChartOutlined,
  RocketOutlined,
  TableOutlined,
  ThunderboltOutlined,
  UserOutlined, GlobalOutlined } from '@ant-design/icons'
import { App, Badge, Button, Drawer, Flex, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { appPath } from '../../api/dataset'
import { STATUS_LABEL, TRIGGER_LABEL, type Agent, type Drill, type Evidence, type GoalStatus, type Trigger } from '../../data/goalCases'
import { useGoalStore, type Notice } from '../../store/goalStore'
import { BRAND_INK, SP, STATUS } from '../../theme'

const { Text } = Typography

export const TRIGGER_ICON: Record<Trigger, React.ReactNode> = { person: <UserOutlined />, schedule: <ClockCircleOutlined />, rule: <BellOutlined /> }
export const TRIGGER_SHORT: Record<Trigger, string> = { person: 'Person', schedule: 'Schedule', rule: 'Rule' }
const STATUS_COLOR: Record<GoalStatus, string> = { 'plan-review': 'purple', armed: 'blue', fired: 'volcano', analysing: 'processing', 'needs-input': 'warning', 'findings-ready': 'success', accepted: 'default' }
const EVIDENCE_ICON: Record<Evidence['kind'], React.ReactNode> = { table: <TableOutlined />, document: <FileSearchOutlined />, mail: <MailOutlined />, web: <GlobalOutlined />, assumption: <QuestionCircleOutlined /> }
export const AGENT_ICONS: Record<string, React.ReactNode> = { radar: <RadarChartOutlined />, compass: <CompassOutlined />, experiment: <ExperimentOutlined />, rocket: <RocketOutlined />, bulb: <BulbOutlined />, thunder: <ThunderboltOutlined /> }

export const fmtDate = (iso: string) => new Date(iso).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })

/** The agent on a goal: its icon in its colour, and its name. */
export function AgentBadge({ agent, size = 'small', bare }: { agent: Agent; size?: 'small' | 'large'; bare?: boolean }) {
  const big = size === 'large'
  return (
    <span className="g-agent" style={{ fontSize: big ? 13 : 12 }}>
      <span className="g-agent-icon" style={{ background: `${agent.colour}18`, color: agent.colour, width: big ? 28 : 22, height: big ? 28 : 22, fontSize: big ? 15 : 12 }}>{AGENT_ICONS[agent.icon]}</span>
      {bare ? null : <span style={{ color: agent.colour, fontWeight: 500 }}>{agent.name}</span>}
    </span>
  )
}

export const TriggerTag = ({ trigger, long }: { trigger: Trigger; long?: boolean }) => <Tag icon={TRIGGER_ICON[trigger]} style={{ marginInlineEnd: 0 }}>{long ? TRIGGER_LABEL[trigger] : TRIGGER_SHORT[trigger]}</Tag>
export const StatusTag = ({ status }: { status: GoalStatus }) => <Tag color={STATUS_COLOR[status]} style={{ marginInlineEnd: 0 }}>{STATUS_LABEL[status]}</Tag>

/** Where a goal is in its life, as six dots. */
const STAGE_OF: Record<GoalStatus, number> = { 'plan-review': 2, armed: 2, fired: 2, analysing: 3, 'needs-input': 3, 'findings-ready': 5, accepted: 6 }
export function StageDots({ status }: { status: GoalStatus }) {
  const n = STAGE_OF[status]
  const labels = ['Goal', 'Approach', 'Findings', 'Data', 'Decision', 'Submissions']
  return (
    <Flex gap={4} align="center" className="g-dots">
      {labels.map((l, i) => (
        <Tooltip key={l} title={l}>
          <span className={`g-dot${i < n ? ' is-done' : ''}${i === n - 1 ? ' is-now' : ''}`} />
        </Tooltip>
      ))}
    </Flex>
  )
}

export function Figure({ label, value, tone }: { label: string; value: string; tone?: 'good' | 'warn' | 'crit' }) {
  const color = tone === 'good' ? STATUS.good : tone === 'warn' ? STATUS.warn : tone === 'crit' ? STATUS.crit : undefined
  return (
    <div style={{ minWidth: 96 }}>
      <Text type="secondary" style={{ fontSize: 10.5, textTransform: 'uppercase', letterSpacing: 0.3, display: 'block' }}>{label}</Text>
      <Text style={{ fontSize: 14.5, fontWeight: 500, color, letterSpacing: -0.2 }}>{value}</Text>
    </div>
  )
}

export const drillFromRef = (ref: Evidence['ref']): Drill | null => {
  if (!ref) return null
  if (ref.doc) return { view: 'documents', doc: ref.doc, project: ref.project, note: '' }
  if (ref.thread) return { view: 'mail', thread: ref.thread, note: '' }
  if (ref.sheet) return { view: ref.sheet, project: ref.project, contract: ref.contract, note: '' }
  return null
}
export const drillFromEvidence = (e: Evidence, fallback: Drill): Drill | null => (!e.ref ? (e.kind === 'assumption' ? null : fallback) : drillFromRef(e.ref) ?? fallback)

export function EvidenceLine({ e, onOpen }: { e: Evidence; onOpen?: () => void }) {
  const clickable = !!onOpen
  return (
    <Flex gap={SP.sm} align="flex-start" className={`g-ev${clickable ? ' is-link' : ''}`} onClick={onOpen}>
      <span style={{ color: e.kind === 'assumption' ? STATUS.warn : BRAND_INK, marginTop: 2 }}>{EVIDENCE_ICON[e.kind]}</span>
      <div style={{ minWidth: 0 }}>
        <Text style={{ fontSize: 12.5 }}>{e.text}</Text>
        <Text type="secondary" style={{ display: 'block', fontSize: 11.5 }}>{e.source}{e.asOf ? ` · ${e.asOf}` : ''}</Text>
      </div>
    </Flex>
  )
}

/* ------------------------------------------------------------------ notifications */

const NOTICE_ICON: Record<Notice['kind'], React.ReactNode> = { fired: <BellOutlined />, ran: <ClockCircleOutlined />, findings: <CheckCircleOutlined />, 'needs-input': <QuestionCircleOutlined />, executed: <ThunderboltOutlined /> }
const NOTICE_COLOR: Record<Notice['kind'], string> = { fired: STATUS.crit, ran: BRAND_INK, findings: STATUS.good, 'needs-input': STATUS.warn, executed: STATUS.good }
/** What a notice says: the line, and for a standing goal that fired, what it found and what it recommends. */
const NoticeBody = ({ n }: { n: Notice }) => (
  <div className="g-notice-body">
    <Text style={{ display: 'block', fontSize: 12.5 }}>{n.text}</Text>
    {n.found ? <div className="g-notice-kv"><span>{n.kind === 'executed' ? 'Done' : 'Found'}</span><span>{n.found}</span></div> : null}
    {n.rec ? <div className="g-notice-kv is-rec"><span>Recommends</span><span>{n.rec}</span></div> : null}
  </div>
)

/** The bell: unread count, a drawer with every notice, and a toast when something lands while the app is open. */
export function NotificationBell() {
  const { notices, markRead, markAllRead, goals, setView } = useGoalStore()
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const { notification } = App.useApp()
  const [open, setOpen] = useState(false)
  const unread = notices.filter((n) => !n.read).length
  const seen = useRef<Set<string>>(new Set(notices.map((n) => n.id)))
  const shown = useRef<Map<string, string>>(new Map())

  const openNotice = (n: Notice) => {
    markRead(n.id)
    setOpen(false)
    notification.destroy(n.id)
    const jt = String(n.tab)
    if (jt !== 'runs' && jt !== 'deliverables') setView(n.goalId, { tab: n.tab as Parameters<typeof setView>[1]['tab'] })
    navigate(appPath(`/goals/${n.goalId}`))
    if (jt === 'runs' || jt === 'deliverables') window.setTimeout(() => window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id: n.goalId, tab: jt } })), 80)
  }

  useEffect(() => {
    for (const n of notices) {
      if (seen.current.has(n.id)) continue
      seen.current.add(n.id)
      if (n.read) continue
      /* Already looking at that goal: the chat says it, so only a standing goal's own news still pops (it fired, it found something, it executed). */
      const loud = n.kind === 'fired' || n.kind === 'executed' || !!n.found
      if (pathname.endsWith(`/goals/${n.goalId}`) && !loud) { markRead(n.id); continue }
      /* One toast per goal at a time: the newer news replaces the older. */
      const prev = shown.current.get(n.goalId); if (prev) notification.destroy(prev)
      shown.current.set(n.goalId, n.id)
      notification.open({
        key: n.id,
        message: n.title,
        description: <NoticeBody n={n} />,
        icon: <span style={{ color: NOTICE_COLOR[n.kind] }}>{NOTICE_ICON[n.kind]}</span>,
        placement: 'topRight',
        duration: n.found ? 0 : n.kind === 'fired' ? 8 : 6,
        className: `g-toast is-${n.kind}`,
        style: { width: 400 },
        btn: <Button size="small" type="primary" onClick={() => openNotice(n)}>{n.cta ?? 'Open the goal'}</Button>,
      })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notices])

  return (
    <>
      <Tooltip title="Notifications">
        <Badge count={unread} size="small" offset={[-2, 2]}>
          <Button type="text" icon={<BellOutlined />} onClick={() => setOpen(true)} aria-label="Notifications" />
        </Badge>
      </Tooltip>
      <Drawer
        title={<Flex justify="space-between" align="center"><span>Notifications</span>{unread ? <Button size="small" type="link" onClick={markAllRead}>Mark all read</Button> : null}</Flex>}
        open={open} onClose={() => setOpen(false)} width={420} styles={{ body: { padding: SP.sm } }}
      >
        {notices.length === 0 ? <Text type="secondary" style={{ display: 'block', padding: SP.base }}>Nothing yet. Standing goals that fire, what they find, and what was executed appear here.</Text> : null}
        {notices.map((n) => {
          const g = goals.find((x) => x.id === n.goalId)
          return (
            <div key={n.id} className={`g-notice${n.read ? '' : ' is-unread'}`} onClick={() => openNotice(n)} role="button">
              <span className="g-notice-icon" style={{ color: NOTICE_COLOR[n.kind] }}>{NOTICE_ICON[n.kind]}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Text style={{ display: 'block', fontSize: 13, fontWeight: n.read ? 400 : 500 }}>{n.title}</Text>
                <NoticeBody n={n} />
                <Text type="secondary" style={{ display: 'block', fontSize: 11.5, marginTop: 2 }}>{fmtDate(n.at)}{g ? ` · ${g.agent.name}` : ''}</Text>
              </div>
              {!n.read ? <span className="g-notice-dot" /> : null}
            </div>
          )
        })}
      </Drawer>
    </>
  )
}
