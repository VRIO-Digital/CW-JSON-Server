import { ArrowDownOutlined, ArrowUpOutlined, CheckCircleFilled, DeleteOutlined, EditOutlined, LoadingOutlined, PlusOutlined, UndoOutlined } from '@ant-design/icons'
import { Button, Card, Flex, Form, Input, Modal, Space, Tag, Typography } from 'antd'
import { useState } from 'react'
import type { PlanStep } from '../../data/goalCases'
import { BRAND, SP, STATUS } from '../../theme'
import './ApproachEditor.css'

const { Text } = Typography

/*
 * The approach the agent proposes, as the analyst sees and changes it: every step says what will be
 * done, how, from which sources, and what check must pass. While the approach is open for review the
 * analyst can reword, reorder, remove and add steps; once approved the same list shows progress.
 */

/** The agent's actions inside a step, as a log the analyst can open; closed by default, with the latest line as its header. */
export function AgentLog({ step, defaultOpen }: { step: PlanStep; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(!!defaultOpen)
  const lines = step.trace ?? []
  const last = lines[lines.length - 1]
  const running = step.state === 'running'
  return (
    <div className={`ap-log${open ? ' is-open' : ''}`}>
      <button type="button" className="ap-log-head" onClick={() => setOpen((o) => !o)}>
        <span className={`ap-dot${running ? ' is-live' : ''}`} />
        <span className="ap-log-title">Agent log · {lines.length} action{lines.length === 1 ? '' : 's'}{running ? ', running' : ''}</span>
        {!open && last ? <span className="ap-log-last">{running ? 'working' : last.split(' → ')[0]}{running ? '…' : ''}</span> : null}
        <span className="ap-log-chev">{open ? '▾' : '▸'}</span>
      </button>
      {open ? (
        <div className="ap-feed">
          {lines.map((a, i) => {
            const [tool, ...rest] = a.split(' → ')
            return (
              <div key={i} className="ap-line">
                <span className="ap-tool">{tool}</span>
                <span className="ap-result">{rest.join(' → ')}</span>
              </div>
            )
          })}
          {running ? <div className="ap-line is-live"><span className="ap-tool">…</span><span className="ap-result">working</span></div> : null}
        </div>
      ) : null}
    </div>
  )
}

export default function ApproachEditor({
  plan,
  editable,
  who,
  onChange,
}: {
  plan: PlanStep[]
  editable: boolean
  who: string
  onChange: (plan: PlanStep[]) => void
}) {
  const [editing, setEditing] = useState<PlanStep | null>(null)
  const [adding, setAdding] = useState(false)
  const [form] = Form.useForm<{ title: string; how: string; sources: string; check: string }>()

  const live = plan.filter((s) => s.state !== 'removed')
  const move = (id: string, dir: -1 | 1) => {
    const idx = plan.findIndex((s) => s.id === id)
    let j = idx + dir
    while (j >= 0 && j < plan.length && plan[j].state === 'removed') j += dir
    if (j < 0 || j >= plan.length) return
    const next = [...plan]
    ;[next[idx], next[j]] = [next[j], next[idx]]
    onChange(next)
  }
  const remove = (id: string) => onChange(plan.map((s) => (s.id === id ? { ...s, state: 'removed', editedBy: who } : s)))
  const restore = (id: string) => onChange(plan.map((s) => (s.id === id ? { ...s, state: 'pending', editedBy: who } : s)))

  const openEdit = (s: PlanStep) => {
    setEditing(s)
    form.setFieldsValue({ title: s.title, how: s.how, sources: s.sources.join('\n'), check: s.check })
  }
  const openAdd = () => {
    setAdding(true)
    form.resetFields()
  }
  const submit = () => {
    form.validateFields().then((v) => {
      const sources = v.sources.split('\n').map((x) => x.trim()).filter(Boolean)
      if (editing) {
        onChange(plan.map((s) => (s.id === editing.id ? { ...s, title: v.title, how: v.how, sources, check: v.check, editedBy: who } : s)))
      } else {
        onChange([...plan, { id: `u${Date.now().toString(36)}`, title: v.title, how: v.how, sources, check: v.check, state: 'pending', editedBy: who }])
      }
      setEditing(null)
      setAdding(false)
    })
  }

  if (!plan.length) {
    return (
      <Card size="small">
        <Space>
          <LoadingOutlined style={{ color: BRAND }} />
          <Text>The agent is reading the goal and drafting its approach. It will not run anything until you approve it.</Text>
        </Space>
      </Card>
    )
  }

  return (
    <>
      <Flex vertical gap={SP.sm}>
        {plan.map((s) => {
          const n = live.findIndex((x) => x.id === s.id) + 1
          const removed = s.state === 'removed'
          return (
            <Card
              key={s.id}
              size="small"
              style={{ opacity: removed ? 0.55 : 1, borderStyle: removed ? 'dashed' : 'solid', borderColor: s.state === 'running' ? BRAND : undefined }}
              styles={{ body: { padding: `${SP.md}px ${SP.base}px` } }}
            >
              <Flex justify="space-between" align="flex-start" gap={SP.sm}>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <Space size={SP.xs} wrap>
                    {s.state === 'done' ? <CheckCircleFilled style={{ color: STATUS.good }} /> : s.state === 'running' ? <LoadingOutlined style={{ color: BRAND }} /> : null}
                    <Text delete={removed} style={{ fontWeight: 500, fontSize: 13.5 }}>
                      {removed ? 'Removed: ' : `${n}. `}
                      {s.title}
                    </Text>
                    {s.editedBy ? <Tag style={{ marginInlineEnd: 0 }}>changed by {s.editedBy}</Tag> : null}
                    {s.state === 'running' ? <Tag color="processing" style={{ marginInlineEnd: 0 }}>running</Tag> : null}
                  </Space>
                  <Text style={{ display: 'block', fontSize: 13, marginTop: SP.xs }}>{s.how}</Text>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: SP.xs }}>
                    Sources: {s.sources.join('; ')}
                  </Text>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>
                    Check: {s.check}
                  </Text>
                  {s.trace?.length || s.state === 'running' ? <AgentLog step={s} /> : null}
                </div>
                {editable ? (
                  <Space size={0}>
                    {removed ? (
                      <Button type="text" size="small" icon={<UndoOutlined />} onClick={() => restore(s.id)} title="Put the step back" />
                    ) : (
                      <>
                        <Button type="text" size="small" icon={<ArrowUpOutlined />} onClick={() => move(s.id, -1)} title="Move up" />
                        <Button type="text" size="small" icon={<ArrowDownOutlined />} onClick={() => move(s.id, 1)} title="Move down" />
                        <Button type="text" size="small" icon={<EditOutlined />} onClick={() => openEdit(s)} title="Change the step" />
                        <Button type="text" size="small" danger icon={<DeleteOutlined />} onClick={() => remove(s.id)} title="Remove the step" />
                      </>
                    )}
                  </Space>
                ) : null}
              </Flex>
            </Card>
          )
        })}
        {editable ? (
          <div>
            <Button icon={<PlusOutlined />} onClick={openAdd}>
              Add a step
            </Button>
          </div>
        ) : null}
      </Flex>

      <Modal
        open={!!editing || adding}
        title={editing ? 'Change this step' : 'Add a step'}
        okText={editing ? 'Save' : 'Add'}
        onOk={submit}
        onCancel={() => {
          setEditing(null)
          setAdding(false)
        }}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" style={{ marginTop: SP.base }}>
          <Form.Item name="title" label="What the step does" rules={[{ required: true, message: 'Say what the step does.' }]}>
            <Input placeholder="e.g. Compare supplier promised dates with the schedule" />
          </Form.Item>
          <Form.Item name="how" label="How" rules={[{ required: true, message: 'Say how.' }]}>
            <Input.TextArea rows={3} placeholder="The method in plain words: what is read, what is compared, what is counted." />
          </Form.Item>
          <Form.Item name="sources" label="Sources, one per line" rules={[{ required: true, message: 'Name at least one source.' }]}>
            <Input.TextArea rows={2} placeholder={'erp.proc po_line\nOutlook mailbox (supplier threads)'} />
          </Form.Item>
          <Form.Item name="check" label="Check that must pass before the step counts as done" rules={[{ required: true, message: 'Name the check.' }]}>
            <Input placeholder="e.g. Every slip cited has a message or document reference with a date." />
          </Form.Item>
        </Form>
      </Modal>
    </>
  )
}
