/*
 * The Scorecard tab of the contract risk watch (16 November 2026).
 *
 * The company's own scorecard, kept by the analyst: all 300 contracts on one screen, each rated on the
 * factors, weights and bands of the Phase 2 workbook, every signal read from its source. A contract opens
 * to its factors and signals, with the evidence behind each reading, what the analyst sees beside the
 * scorecard (never mixed into the rating), and the actions with their owners and dates. Below: where
 * every signal comes from, the actions that are tracked, the test against renewals already lost, and
 * where else the analyst can be reached (at the step, when a contract is drafted or bid).
 * The analyst recommends; nothing here writes to a source system.
 */
import { ApiOutlined, ArrowDownOutlined, ArrowRightOutlined, ArrowUpOutlined, CheckOutlined, DownOutlined, FileTextOutlined, GlobalOutlined, MailOutlined, RightOutlined, TableOutlined, ThunderboltOutlined } from '@ant-design/icons'
import { Button, Input, Modal } from 'antd'
import { useMemo, useState } from 'react'
import { create } from 'zustand'
import type { Drill } from '../../data/goalCases'
import type { Journey } from '../../store/journeyStore'
import { ASHBY, CONTRACTS, FACTORS, HARLOW, LOST, PLAYBOOK, RATING_COLOR, RATING_NAME, RATING_SOFT, READINGS, REDMESA, REGIONS, RULE_TEXT, SCORING, SIGNALS, STATE_NAME, f1, factorScore, groupScore, m1, portfolio, rating, ratingOf, readingOf, score, specCoverage, likelihoodSignals, movers, shortSite, type Action, type Contract, type Group, type SrcKind, type When } from '../../data/risk'
import { useDesignV } from '../../store/designStore'
import './TargetBoard.css'
import './ScoreBoard.css'

/** Is this standing goal the scorecard watch. */
export const isTargetGoal = (j: Journey | null) => !!j && j.mode === 'watch' && j.case === 'watch'
export const firedOf = (j: Journey) => j.runs.length > 0
const whenOf = (j: Journey): When => (firedOf(j) ? 'after' : 'before')

export const SRC_ICON: Record<SrcKind, React.ReactNode> = { table: <TableOutlined />, document: <FileTextOutlined />, mail: <MailOutlined />, web: <GlobalOutlined /> }
const SRC_LABEL: Record<SrcKind, string> = { table: 'Operations data', document: 'Contracts and documents', mail: 'Mail', web: 'Public web' }
const LENSES: Action['lens'][] = ['Internal', 'At the plant', 'In the community', 'With the client']

/** The evidence behind a reading: the document, thread or page for the three contracts told in depth, the contract's sheet otherwise. */
const EVID: Record<string, Record<string, Drill>> = {
  'NCO-047': { li3: { view: 'mail', thread: 'H1', note: '' }, co1: { view: 'documents', doc: 'DOC:hc-complaints', note: '' }, gr1: { view: 'documents', doc: 'DOC:hc-contract', note: '' }, in5: { view: 'documents', doc: 'DOC:hc-cip', note: '' }, co2: { view: 'web', doc: 'WEB:hc-ledger', note: '' }, co3: { view: 'web', doc: 'WEB:hc-ledger', note: '' }, cr3: { view: 'documents', doc: 'DOC:hc-contract', note: '' }, cr6: { view: 'documents', doc: 'DOC:hc-contract', note: '' }, in1: { view: 'documents', doc: 'DOC:hc-contract', note: '' } },
  'NCO-184': { st6: { view: 'mail', thread: 'R2', note: '' }, en2: { view: 'documents', doc: 'DOC:rm-sampling', note: '' }, st1: { view: 'mail', thread: 'R2', note: '' } },
  'NCO-111': { cp3: { view: 'web', doc: 'WEB:af-agenda', note: '' }, cp5: { view: 'web', doc: 'WEB:af-agenda', note: '' }, cl2: { view: 'web', doc: 'WEB:af-courier', note: '' }, cp1: { view: 'mail', thread: 'A1', note: '' }, gr1: { view: 'documents', doc: 'DOC:af-contract', note: '' }, in1: { view: 'documents', doc: 'DOC:af-contract', note: '' }, co2: { view: 'web', doc: 'WEB:af-courier', note: '' }, cu1: { view: 'mail', thread: 'A1', note: '' } },
}
export const drillFor = (c: Contract, sid: string, fired: boolean): Drill => {
  if (sid === 'sl1') return { view: 'web', doc: 'WEB:state-rank', note: '' }
  const d = EVID[c.id]?.[sid]
  if (d && (fired || !(d.doc === 'WEB:af-courier' || d.doc === 'WEB:af-agenda' || d.thread === 'H1'))) return d
  return { view: 'contract', contract: c.id, note: '' }
}
export const seenDrill = (ref?: string): Drill | null => (!ref ? null : ref.startsWith('WEB:') ? { view: 'web', doc: ref, note: '' } : ref.startsWith('DOC:') ? { view: 'documents', doc: ref, note: '' } : { view: 'mail', thread: ref, note: '' })

/* What other systems asked the analyst, kept for the visit so the board can show it. */
export interface StepCall { id: string; at: string; item: string; outcome: string }
interface CallStore { calls: Record<string, StepCall[]>; add: (id: string, c: StepCall) => void }
export const useStepCalls = create<CallStore>((set) => ({ calls: {}, add: (id, c) => set((s) => ({ calls: { ...s.calls, [id]: [...(s.calls[id] ?? []).filter((x) => x.item !== c.item), c] } })) }))
const hhmm = () => new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
const NO_CALLS: StepCall[] = []

/** One line under the panel title, so the scorecard is in view on every tab. */
export function TargetStrip({ j, onOpen }: { j: Journey; onOpen: () => void }) {
  useDesignV()
  const w = whenOf(j), p = portfolio(SCORING.rule, w), mv = firedOf(j) ? movers() : [], up = mv.filter((m) => m.r1 > m.r0)
  return (
    <button type="button" className="tg-strip" data-testid="target-strip" onClick={onOpen}>
      <span><b>Dashboard</b> {CONTRACTS.length} contracts · {likelihoodSignals().length} signals</span>
      <span>Rated 3 or 4 <b>{p.dist[3] + p.dist[4]}</b></span>
      <span className={firedOf(j) ? 'is-short' : 'is-ok'}>{firedOf(j) ? <>{up.length ? <>{up.map((m) => shortSite(m.c)).join(', ')} <b>up a rating</b></> : <>{mv.length} changed · <b>no rating moved</b></>}</> : <>Last check <b>19 November</b> · no rating moved</>}</span>
      <ArrowRightOutlined />
    </button>
  )
}

type Filter = 'all' | 'high' | 'changed' | 'worse' | 'renew'
const FILTERS: { k: Filter; label: string }[] = [{ k: 'all', label: 'All 300' }, { k: 'high', label: 'Rated 3 or 4' }, { k: 'changed', label: 'Changed overnight' }, { k: 'worse', label: 'Worse than 90 days ago' }, { k: 'renew', label: 'Decide in 18 months' }]

export default function ScoreBoard({ j, onOpen, onTab }: { j: Journey; onOpen: (d: Drill) => void; onTab: (t: 'findings' | 'deliverables' | 'plan') => void }) {
  const rule = SCORING.rule
  const fired = firedOf(j), w = whenOf(j)
  const handled = fired && j.status === 'executed'
  const [sel, setSel] = useState<string>(HARLOW.id)
  const [filter, setFilter] = useState<Filter>('all')
  const [view, setView] = useState<'grid' | 'stake'>('grid')
  const [openF, setOpenF] = useState<string | null>(null)
  const [cov, setCov] = useState(false)
  const [lost, setLost] = useState(false)
  const [step, setStep] = useState(false)
  const calls = useStepCalls((s) => s.calls[j.id] ?? NO_CALLS)

  const rows = useMemo(() => CONTRACTS.map((c) => ({ c, s: score(c, rule, w), r: rating(c, rule, w), q: score(c, rule, 'q'), b: rating(c, rule, 'before') })), [rule, w])
  const p = useMemo(() => portfolio(rule, w), [rule, w])
  const pb = useMemo(() => portfolio(rule, 'before'), [rule])
  const isChanged = (c: Contract) => fired && !!c.night
  const match = (x: (typeof rows)[number]) => filter === 'all' || (filter === 'high' && x.r >= 3) || (filter === 'changed' && isChanged(x.c)) || (filter === 'worse' && x.s - x.q > 0.12) || (filter === 'renew' && (x.c.monthsLeft <= 18 || (x.c.evergreen && x.c.tfc)))
  const nMatch = rows.filter(match).length
  const c = CONTRACTS.find((x) => x.id === sel) ?? HARLOW
  const cov0 = specCoverage()
  const near = useMemo(() => rows.filter((x) => x.r === 2).sort((a, b) => b.s - a.s).slice(0, 3), [rows])
  const pick = (id: string) => { setSel(id); setOpenF(null); window.setTimeout(() => document.querySelector('[data-testid="sb-detail"]')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 40) }

  return (
    <div className="tg sb" data-testid="target-board">
      <div className="tg-head">
        <div>
          <h3>Contract risk scorecard</h3>
          <p>300 contracts · 7 internal and 5 external factors · 42 signals rated 1 to 4, on the bands of your Phase 2 workbook. One rating is {RULE_TEXT[rule]}.</p>
        </div>
        <span className={`pill ${fired ? 'is-amber' : 'is-green'}`}><i />{fired ? 'As of the 20 November check · 1 rating moved' : 'As of the 19 November check'}</span>
      </div>

      {/* where the portfolio stands */}
      <section>
        <div className="sb-dist" data-testid="sb-dist">
          {[1, 2, 3, 4].map((r) => (
            <button type="button" key={r} className="sb-tile" data-rating={r} onClick={() => setFilter(r >= 3 ? 'high' : 'all')} style={{ borderTopColor: RATING_COLOR[r] }}>
              <small>{r} · {RATING_NAME[r]}</small>
              <b data-testid={`sb-n${r}`}>{p.dist[r]}</b>
              <span>{p.dist[r] !== pb.dist[r] && fired ? `${p.dist[r] > pb.dist[r] ? '+' : '−'}${Math.abs(p.dist[r] - pb.dist[r])} since yesterday` : `${p.dist[r] && p.dist[r] / p.n < 0.01 ? 'under 1' : Math.round((p.dist[r] / p.n) * 100)}% of contracts`}</span>
            </button>
          ))}
        </div>
        <div className="sb-bar" aria-hidden>{[1, 2, 3, 4].map((r) => <i key={r} style={{ width: `${(p.dist[r] / p.n) * 100}%`, background: RATING_COLOR[r] }} />)}</div>
        <p className="tg-note">{p.readings.toLocaleString('en-US')} readings, all read from their source at the 06:00 check. The {p.dist[3] + p.dist[4]} contracts rated 3 or 4 carry {m1(p.highRevenue)} a year of {m1(p.revenue)}.</p>
      </section>

      {/* what changed, or what is closest to changing */}
      <section>
        <div className="tg-h"><b>{fired ? 'What changed at the 20 November check' : 'Closest to the line today'}</b><span>{fired ? 'Three sources, three contracts. One moved a rating; two changed in ways the rating does not show.' : 'The contracts rated 2 with the highest score. A single reading can take them to 3.'}</span></div>
        <div className="sb-chg" data-testid="sb-changed">
          {fired ? (
            <>
              <button type="button" className="sb-card is-crit" data-c={HARLOW.id} onClick={() => pick(HARLOW.id)}><span className="sb-via"><MailOutlined /> Mail · legal notices</span><b>Harlow Creek WWTP, Georgia</b><em>2 → 3</em><p>A demand letter for 23 residents and a sixth odor complaint. Threatened litigation 2 to 4, Odor complaints 3 to 4.</p></button>
              <button type="button" className="sb-card is-warn" data-c={REDMESA.id} onClick={() => pick(REDMESA.id)}><span className="sb-via"><TableOutlined /> Lab and HR data</span><b>Red Mesa, Arizona</b><em>stays 2</em><p>A second missed sample, with two posts open over 60 days and overtime at 14.2%: the pattern before five of the last seven notices of violation.</p></button>
              <button type="button" className="sb-card is-warn" data-c={ASHBY.id} onClick={() => pick(ASHBY.id)}><span className="sb-via"><GlobalOutlined /> Web · council agenda</span><b>Ashby Falls, Massachusetts</b><em>stays 2</em><p>In-house operation on the 2 December agenda, seven months before the contract ends. The scorecard has no signal for it.</p></button>
            </>
          ) : near.map((x) => (
            <button type="button" key={x.c.id} className="sb-card" data-c={x.c.id} onClick={() => pick(x.c.id)}><span className="sb-via">{x.c.id} · {x.c.region}</span><b>{x.c.site}, {STATE_NAME[x.c.state] ?? x.c.state}</b><em>{f1(x.s)}</em><p>Internal {f1(groupScore(x.c, 'internal', w))}, external {f1(groupScore(x.c, 'external', w))}. Rates 2; 3 starts at 2.50.</p></button>
          ))}
        </div>
      </section>

      {/* all 300 */}
      <section>
        <div className="sb-toolbar">
          <div className="tg-h"><b>All 300 contracts</b><span>{view === 'grid' ? 'One square per contract, by region, highest score first. Pick one to open it.' : 'Each contract by its rating and the months left on its agreement; the size is annual revenue. From the contract master, beside the scorecard.'}</span></div>
          <div className="sb-seg" role="tablist"><button type="button" role="tab" aria-selected={view === 'grid'} className={view === 'grid' ? 'is-on' : ''} onClick={() => setView('grid')}>By region</button><button type="button" role="tab" aria-selected={view === 'stake'} className={view === 'stake' ? 'is-on' : ''} data-testid="sb-stake" onClick={() => setView('stake')}>By what is at stake</button></div>
        </div>
        <div className="sb-filters">{FILTERS.filter((f) => f.k !== 'changed' || fired).map((f) => <button type="button" key={f.k} className={`sb-chip${filter === f.k ? ' is-on' : ''}`} data-filter={f.k} onClick={() => setFilter(f.k)}>{f.label}</button>)}<span className="sb-count" data-testid="sb-count">{nMatch} shown</span></div>
        {view === 'grid' ? (
          <div className="sb-grid" data-testid="sb-grid">
            {REGIONS.map((g) => {
              const xs = rows.filter((x) => x.c.region === g.name).sort((a, b) => b.s - a.s)
              return (
                <div className="sb-reg" key={g.name}>
                  <div className="sb-reg-h"><b>{g.name}</b><span>{g.rvp} · {xs.filter((x) => x.r >= 3).length} of {xs.length} rated 3 or 4</span></div>
                  <div className="sb-cells">
                    {xs.map((x) => <button type="button" key={x.c.id} className={`sb-cell${sel === x.c.id ? ' is-sel' : ''}${match(x) ? '' : ' is-dim'}${isChanged(x.c) ? ' is-chg' : ''}`} data-c={x.c.id} data-r={x.r} title={`${x.c.id} ${x.c.site}, ${x.c.state} · rating ${x.r} (${f1(x.s)})`} aria-label={`${x.c.site}, rating ${x.r}`} style={{ background: RATING_COLOR[x.r], opacity: match(x) ? 0.55 + Math.min(0.45, Math.max(0, (x.s - (x.r - 0.5)) * 0.45)) : undefined }} onClick={() => pick(x.c.id)} />)}
                  </div>
                </div>
              )
            })}
            <div className="sb-legend">{[1, 2, 3, 4].map((r) => <span key={r}><i style={{ background: RATING_COLOR[r] }} />{r} {RATING_NAME[r]}</span>)}{fired ? <span><i className="lg-chg" />changed overnight</span> : null}</div>
          </div>
        ) : <Stake rows={rows.filter(match)} sel={sel} onPick={pick} changed={isChanged} />}
      </section>

      {/* one contract */}
      <ContractCard c={c} w={w} fired={fired} handled={handled} openF={openF} setOpenF={setOpenF} onOpen={onOpen} onTab={onTab} j={j} />

      {/* where every signal comes from */}
      <section>
        <div className="tg-h"><b>Where every signal comes from</b><span>Your data sheet marks {cov0.avail} of the 42 signals as available today and {cov0.manual} as manual inputs. Here all 42 are read from a source at every check: {cov0.bySrc.map((b) => `${b.n} from ${SRC_LABEL[b.k].toLowerCase()}`).join(', ')}.</span></div>
        <div className="sb-src" data-testid="sb-sources">{cov0.bySrc.map((b) => <div key={b.k} className="sb-srcT"><span className="sb-ic">{SRC_ICON[b.k]}</span><b>{b.n}</b><small>{SRC_LABEL[b.k]}</small></div>)}</div>
        <button type="button" className="tg-fold" aria-expanded={cov} data-testid="sb-cov-fold" onClick={() => setCov(!cov)}>{cov ? <DownOutlined /> : <RightOutlined />} The 42 signals, one by one</button>
        {cov ? (
          <div className="sb-tblw"><table className="sb-tbl" data-testid="sb-cov">
            <thead><tr><th>Signal</th><th>In your workbook</th><th>Read here from</th></tr></thead>
            <tbody>{FACTORS.map((f) => [<tr key={f.id} className="sb-grp"><td colSpan={3}>{f.group === 'internal' ? 'Internal' : 'External'} · {f.name} · {f.weight}%</td></tr>, ...SIGNALS.filter((s) => s.f === f.id).map((s) => <tr key={s.id}><td>{s.name}<small>rank {s.rank}</small></td><td>{s.spec.avail ? 'Available' : 'Not available yet'}{s.spec.manual ? ' · manual input' : ''}<small>{s.spec.freq} · {s.spec.steward}</small></td><td><span className="sb-ic">{SRC_ICON[s.src.kind]}</span> {s.src.name}<small>{s.src.how}</small></td></tr>)])}</tbody>
          </table></div>
        ) : null}
        <p className="tg-note">Where a band or a rule in the workbook is unclear I read it one way and say so: {READINGS.length} readings, listed on the <a onClick={() => onTab('plan')}>Plan</a> under what I take as given. A rating read from a contract clause is a draft until Legal confirms it.</p>
      </section>

      {/* actions that are tracked */}
      <section>
        <div className="tg-h"><b>Actions I keep track of</b><span>Every action has a contract, a signal, an owner and a date. At each check I read whether it was done, and whether the rating came back.</span></div>
        <div className="tg-kpis sb-acts" data-testid="sb-actions">
          <div><small>Open</small><b>{p.open + (handled ? 16 : 0)}</b><span>{handled ? '16 opened this morning' : 'across the portfolio'}</span></div>
          <div><small>Overdue</small><b className="is-warn">{p.overdue}</b><span>past their date, owner reminded</span></div>
          <div><small>Closed, last 90 days</small><b>{p.done}</b><span>read as done from mail and data</span></div>
          <div><small>Came back to 2</small><b className="is-good">{p.cameBack.length}</b><span>{p.cameBack.slice(0, 2).map((x) => x.site.split(' ').slice(0, 2).join(' ')).join(', ') || 'none yet'}</span></div>
        </div>
        <a className="tg-src" data-testid="sb-open-actions" onClick={() => onOpen({ view: 'actions', note: '' })}><TableOutlined /> Open the tracker <span>every action, with owner, date and state</span></a>
      </section>

      {/* tested against what already happened */}
      <section>
        <div className="tg-h"><b>Tested against the renewals already lost</b><span>The scorecard, run back over the three renewals lost since 2024, as each stood twelve months before.</span></div>
        <button type="button" className="tg-fold" aria-expanded={lost} data-testid="sb-lost-fold" onClick={() => setLost(!lost)}>{lost ? <DownOutlined /> : <RightOutlined />} {LOST.filter((l) => l.rated <= 2).length} of the 3 rated 2 a year before the loss</button>
        {lost ? (
          <div className="sb-tblw"><table className="sb-tbl" data-testid="sb-lost">
            <thead><tr><th>Lost renewal</th><th>Rated a year before</th><th>What moved in that year</th></tr></thead>
            <tbody>{LOST.map((l) => <tr key={l.site}><td>{l.site}, {l.state}<small>{l.how} · {l.lost} · {m1(l.revenue)} a year</small></td><td><span className="sb-rt" style={{ background: RATING_SOFT[l.rated], color: RATING_COLOR[l.rated] }}>{l.rated}</span> internal {f1(l.int)}, external {f1(l.ext)}</td><td>{l.moved.join('; ')}{l.doc ? <small><a onClick={() => onOpen({ view: 'documents', doc: l.doc, note: '' })}>Open the loss review</a></small> : null}</td></tr>)}</tbody>
          </table></div>
        ) : null}
        <p className="tg-note">The scorecard sees trouble at the plant and in its setting. What came before two of the three losses was on the client side, so I read council agendas, client mail and local news for every contract and show what I find beside the rating, never inside it.</p>
      </section>

      {/* where the analyst is reached */}
      <section>
        <div className="tg-h"><b>Where I show up</b><span>The same scorecard, reached two ways. In both I inform and recommend; the people and the systems act.</span></div>
        <div className="tg-where">
          <div className="wh">
            <span className="wh-ic"><ThunderboltOutlined /></span>
            <div><b>By myself, every morning</b><span>{j.stage === 'armed' ? `Next: ${j.nextCheck ?? 'tomorrow at 06:00'}. I read every source, rate all 300 contracts and tell the people you chose only when something moves.` : 'From the moment the watch is armed: every source, every morning at 06:00.'}</span></div>
            <span className="tag ok">{j.stage === 'armed' ? 'On' : 'On when armed'}</span>
          </div>
          <div className="wh">
            <span className="wh-ic"><ApiOutlined /></span>
            <div><b>At the step, when a contract is drafted or bid</b><span>The contract desk asks before a renewal, an amendment or a bid goes for approval. I check the draft against the non-negotiable terms and rate the contract as it would enter the scorecard, before it is signed.</span>
              <div className="wh-acts"><Button size="small" type="primary" data-testid="open-step" onClick={() => setStep(true)}>See it at the step</Button></div>
            </div>
            <span className="tag ok">On</span>
          </div>
        </div>
        {calls.length ? (
          <div className="tg-calls" data-testid="step-calls">
            <div className="tg-calls-h"><b>Asked at the step today</b><span>{calls.length} of 3 drafts</span></div>
            <ul>{calls.map((x) => <li key={x.id}><time>{x.at}</time><span>{x.item}</span><span>{x.outcome}</span></li>)}</ul>
          </div>
        ) : null}
      </section>
      <StepModal open={step} onClose={() => setStep(false)} j={j} onOpen={onOpen} />
    </div>
  )
}

/* ------------------------------------------------------------------ rating against what is at stake */

function Stake({ rows, sel, onPick, changed }: { rows: { c: Contract; s: number; r: number }[]; sel: string; onPick: (id: string) => void; changed: (c: Contract) => boolean }) {
  const W = 640, H = 300, L = 44, R = 12, T = 12, B = 34
  const maxM = 60
  const sx = (m: number) => L + ((W - L - R) * Math.min(maxM, Math.max(0, m))) / maxM
  const sy = (s: number) => T + (H - T - B) * (1 - (s - 1) / 3)
  const rad = (rev: number) => 2.5 + Math.sqrt(rev / 1e6) * 1.9
  const pts = rows.map((x) => ({ ...x, m: x.c.evergreen ? 3 : x.c.monthsLeft })).sort((a, b) => b.c.revenue - a.c.revenue)
  const hot = pts.filter((x) => x.m <= 18 && x.r >= 3)
  return (
    <div className="sb-stake" data-testid="sb-stake-chart">
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Contracts by score and months left">
        <rect x={L} y={T} width={sx(18) - L} height={sy(2.5) - T} fill="#fdeedd" opacity="0.55" />
        {[1, 2, 3, 4].map((v) => <g key={v}><line x1={L} x2={W - R} y1={sy(v)} y2={sy(v)} stroke="#eff1f5" /><text x={L - 8} y={sy(v) + 4} textAnchor="end" fontSize="11" fill="#6b778a">{v}</text></g>)}
        <line x1={L} x2={W - R} y1={sy(2.5)} y2={sy(2.5)} stroke="#e2812a" strokeDasharray="4 4" />
        {[0, 12, 18, 24, 36, 48, 60].map((m) => <g key={m}><line x1={sx(m)} x2={sx(m)} y1={T} y2={H - B} stroke={m === 18 ? '#e2812a' : '#eff1f5'} strokeDasharray={m === 18 ? '4 4' : undefined} /><text x={sx(m)} y={H - B + 15} textAnchor="middle" fontSize="11" fill="#6b778a">{m === 60 ? '60+' : m}</text></g>)}
        <text x={(L + W - R) / 2} y={H - 3} textAnchor="middle" fontSize="11" fill="#6b778a">Months left on the agreement (evergreen contracts at 3: the client can end on notice)</text>
        <text x={12} y={(T + H - B) / 2} textAnchor="middle" fontSize="11" fill="#6b778a" transform={`rotate(-90 12 ${(T + H - B) / 2})`}>Score</text>
        <text x={L + 6} y={T + 14} fontSize="11" fontWeight="600" fill="#b4530a">Rated 3 or 4 and deciding within 18 months: {hot.length} contracts, {m1(hot.reduce((n, x) => n + x.c.revenue, 0))} a year</text>
        {pts.map((x) => <circle key={x.c.id} data-c={x.c.id} cx={sx(x.m)} cy={sy(x.s)} r={rad(x.c.revenue)} fill={RATING_COLOR[x.r]} fillOpacity={sel === x.c.id ? 1 : 0.55} stroke={sel === x.c.id ? '#18212f' : changed(x.c) ? '#18212f' : '#fff'} strokeWidth={sel === x.c.id ? 2 : changed(x.c) ? 1.5 : 0.6} strokeDasharray={changed(x.c) && sel !== x.c.id ? '2 2' : undefined} style={{ cursor: 'pointer' }} onClick={() => onPick(x.c.id)}><title>{`${x.c.site}, ${x.c.state} · rating ${x.r} (${f1(x.s)}) · ${x.c.evergreen ? 'evergreen' : `${x.c.monthsLeft} months left`} · ${m1(x.c.revenue)} a year`}</title></circle>)}
      </svg>
    </div>
  )
}

/* ------------------------------------------------------------------ one contract, opened */

function ContractCard({ c, w, fired, handled, openF, setOpenF, onOpen, onTab, j }: { c: Contract; w: When; fired: boolean; handled: boolean; openF: string | null; setOpenF: (f: string | null) => void; onOpen: (d: Drill) => void; onTab: (t: 'findings' | 'deliverables' | 'plan') => void; j: Journey }) {
  const rule = SCORING.rule
  const s = score(c, rule, w), r = ratingOf(s), rb = rating(c, rule, 'before'), sq = score(c, rule, 'q')
  const moved = fired && !!c.night
  const changedSig = (sid: string) => moved && !!c.night?.[sid]
  const seen = c.seen.filter((x) => fired || !x.night)
  const acts = c.hero ? (fired ? c.actions : []) : c.actions
  const stateOf = (a: Action): { t: string; cls: string } => {
    if (a.state === 'done') return { t: 'Done', cls: 'ok' }
    if (a.state === 'overdue') return { t: 'Overdue', cls: 'crit' }
    if (a.state === 'open') return { t: 'Open', cls: 'inf' }
    if (!handled) return { t: 'Proposed', cls: 'inf' }
    if (a.state === 'held') { /* each one is released by its own action of the run: the calls to residents, or the approach to the client */ const g = j.execActs.find((x) => x.cat === (a.id === 'hc5' ? 'claimant' : 'client')); return !g || g.state === 'done' || g.state === 'approved' ? { t: 'Open', cls: 'inf' } : g.state === 'declined' ? { t: 'Left', cls: 'inf' } : { t: 'Waits for your OK', cls: 'need' } }
    return { t: 'Open', cls: 'inf' }
  }
  const worst = FACTORS.map((f) => ({ f, v: factorScore(c, f.id, w) ?? 0 })).filter((x) => x.v >= 3 && Object.keys(PLAYBOOK[x.f.id] ?? {}).length).sort((a, b) => b.v - a.v).slice(0, 3)
  const grp = (g: Group) => (
    <div className="sb-fcol">
      <div className="sb-fcol-h"><b>{g === 'internal' ? 'Internal factors' : 'External factors'}</b><em data-testid={`sb-${g}`}>{f1(groupScore(c, g, w))}</em>{moved && f1(groupScore(c, g, 'before')) !== f1(groupScore(c, g, w)) ? <span className="sb-was">was {f1(groupScore(c, g, 'before'))}</span> : null}</div>
      {FACTORS.filter((f) => f.group === g).map((f) => {
        const v = factorScore(c, f.id, w); if (v === null) return null
        const vb = factorScore(c, f.id, 'before') ?? v
        const sigs = SIGNALS.filter((x) => x.f === f.id && c.v[x.id])
        const open = openF === f.id || sigs.some((x) => changedSig(x.id))
        return (
          <div className={`sb-f${open ? ' is-open' : ''}`} key={f.id} data-factor={f.id}>
            <button type="button" className="sb-f-row" aria-expanded={open} onClick={() => setOpenF(openF === f.id ? null : f.id)}>
              <span className="sb-f-n">{open ? <DownOutlined /> : <RightOutlined />}<b>{f.name}</b><small>{f.weight}%</small></span>
              <span className="sb-f-bar"><i style={{ width: `${((v - 1) / 3) * 100}%`, background: RATING_COLOR[ratingOf(v)] }} /></span>
              <span className="sb-f-v">{f1(v)}{moved && f1(vb) !== f1(v) ? <ArrowUpOutlined className="up" /> : null}</span>
            </button>
            {open ? (
              <div className="sb-sigs">
                {sigs.map((x) => { const rd = readingOf(c, x.id, w)!; const ch = changedSig(x.id); const ri = Math.min(4, Math.max(1, Math.floor(rd.r))); return (
                  <div className={`sb-sig${ch ? ' is-chg' : ''}`} key={x.id} data-signal={x.id}>
                    <span className="sb-rt" style={{ background: RATING_SOFT[ri], color: RATING_COLOR[ri] }}>{rd.r}</span>
                    <div><b>{x.name}</b><span>{rd.raw}{ch ? <em> · was {rd.wasRaw} (rating {rd.was})</em> : rd.was && !ch ? <em> · rated {rd.was} 90 days ago</em> : null}</span><small>Band {ri}: {x.bands[ri - 1] || x.bands[0]}</small>
                      <a className="sb-ev" onClick={() => onOpen(drillFor(c, x.id, fired))}>{SRC_ICON[x.src.kind]} {x.src.name}</a>
                    </div>
                  </div>
                ) })}
              </div>
            ) : null}
          </div>
        )
      })}
    </div>
  )
  return (
    <section className="sb-detail" data-testid="sb-detail" data-c={c.id}>
      <div className="sb-d-head">
        <div className="sb-d-rt" style={{ background: RATING_SOFT[r], color: RATING_COLOR[r] }} data-testid="sb-rating"><b>{r}</b><span>{RATING_NAME[r]}</span></div>
        <div className="sb-d-t">
          <b>{c.site}</b>
          <span>{c.id} · {c.client}, {STATE_NAME[c.state] ?? c.state} · {c.region}, {c.rvp} · project leader {c.leader}</span>
          <span>{c.scopes.join(', ')} · {m1(c.revenue)} a year · {c.evergreen ? 'evergreen' : `ends ${new Date(c.end).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })} (${c.monthsLeft} months)`}</span>
        </div>
        <div className="sb-d-mv">{moved && rb !== r ? <span className="sb-move is-up" data-testid="sb-moved"><ArrowUpOutlined /> from {rb} to {r} overnight</span> : s - sq > 0.12 ? <span className="sb-move is-up"><ArrowUpOutlined /> worse than 90 days ago ({f1(sq)})</span> : sq - s > 0.12 ? <span className="sb-move is-down"><ArrowDownOutlined /> better than 90 days ago ({f1(sq)})</span> : <span className="sb-move">steady over 90 days</span>}</div>
      </div>
      <div className="sb-fgrid">{grp('internal')}{grp('external')}</div>
      <p className="tg-note">Open a factor to see its signals: the reading, the band of your workbook it falls in, and the source. A factor with a signal that changed overnight is open already.</p>

      {seen.length ? (
        <div className="sb-seen" data-testid="sb-seen">
          <div className="tg-h"><b>Beside the scorecard</b><span>What I see about this contract that is not a signal of your workbook. It never changes the rating.</span></div>
          {seen.map((x) => { const d = seenDrill(x.src.ref); return <div className={`sb-s is-${x.tone}`} key={x.k}><b>{x.label}</b><p>{x.text}</p><a className="sb-ev" onClick={() => onOpen(d ?? { view: 'contract', contract: c.id, note: '' })}>{SRC_ICON[x.src.kind]} {x.src.name}</a></div> })}
        </div>
      ) : null}

      <div className="sb-do" data-testid="sb-do">
        <div className="tg-h"><b>What to do about it</b><span>{acts.length ? (c.hero ? 'Your mitigation matrix, made specific to this contract: the action, the owner, the date. I check at every morning check whether each was done.' : 'The open actions on this contract, from your mitigation matrix.') : worst.length ? 'Your mitigation matrix for the factors that rate 3 or more here. Nothing specific is open yet.' : 'Nothing rates 3 or more on this contract. No action is open.'}</span></div>
        {acts.length ? LENSES.map((l) => { const xs = acts.filter((a) => a.lens === l); if (!xs.length) return null; return (
          <div className="sb-lens" key={l} data-lens={l}><div className="sb-lens-h">{l}</div>
            {xs.map((a) => { const st = stateOf(a); return <div className="sb-act" key={a.id} data-act={a.id}><p>{a.text}</p><span>{a.owner} · by {a.due}</span><span className={`tag ${st.cls}`}>{st.t}</span></div> })}
          </div>
        ) }) : worst.map(({ f }) => (
          <div className="sb-lens" key={f.id}><div className="sb-lens-h">{f.name} · from your matrix</div>
            {LENSES.filter((l) => PLAYBOOK[f.id]?.[l]).map((l) => <div className="sb-act is-book" key={l}><p>{PLAYBOOK[f.id]![l]}</p><span>{l}</span></div>)}
          </div>
        ))}
        {c.hero && fired ? <div className="sb-do-foot">{handled ? <a onClick={() => onTab('deliverables')}>Open the risk brief</a> : <span>The run is building the brief now.</span>}<a onClick={() => onTab('findings')}>Open the findings and options</a></div> : null}
      </div>
    </section>
  )
}

/* ------------------------------------------------------------------ at the step: the contract desk asks before a draft goes for approval */

interface Draft { id: string; kind: string; title: string; sub: string; lines: [string, string][]; verdict: 'flag' | 'clear' | 'note'; head: string; text: string; better?: { from: string; to: string; note: string }; ev: { n: string; d?: Drill }[]; acts: { k: string; label: string; primary?: boolean; outcome: string }[] }
const DRAFTS: Draft[] = [
  { id: 'd1', kind: 'Renewal', title: 'Tamsin Harbor WWTP: five-year renewal', sub: 'Client redline received 18 November', lines: [['Client', 'Tamsin Harbor Utility District, Texas'], ['Term', '1 July 2027 to 30 June 2032'], ['Annual fee', '$4.6M'], ['Clause 14.1', 'Liability cap: deleted in the client redline'], ['Clause 14.2', 'Waiver of consequential damages: kept']], verdict: 'flag', head: 'This draft breaks a non-negotiable term: the liability cap is gone', text: 'The client redline deletes clause 14.1. Without a cap the contract lacks one of the three core terms and would rate 3 on Non-negotiable Contract Terms; today it rates 1. Texas ranks 32 of 50 on liability cost and 7,900 homes sit within 2 miles, so an uncapped claim is not remote.', better: { from: 'No cap (client redline)', to: 'Cap at the annual fee, with the insurance limit raised to $10M', note: 'What two other Texas clients accepted in 2025 when they asked for the same change.' }, ev: [{ n: 'Tamsin_Harbor_Renewal_Redline_2026-11-18.docx · clause 14.1' }, { n: 'Scorecard · Non-negotiable terms bands', d: { view: 'documents', doc: 'DOC:risk-spec', note: '' } }, { n: 'richstatespoorstates.org · Texas, rank 32', d: { view: 'web', doc: 'WEB:state-rank', note: '' } }], acts: [{ k: 'back', label: 'Send it back with the cap restored', primary: true, outcome: 'Sent back to the drafter with the cap restored' }, { k: 'keep', label: 'Keep it, and ask Legal for an exception', outcome: 'Kept; exception request raised with Legal' }] },
  { id: 'd2', kind: 'Amendment', title: 'Ember Mesa: add stormwater to the scope', sub: 'Amendment 4, drafted 19 November', lines: [['Client', 'City of Ember Mesa, Ohio'], ['Change', 'Stormwater system added from 1 January 2027'], ['Fee', '+$310,000 a year'], ['Liability terms', 'Unchanged']], verdict: 'clear', head: 'Nothing to flag', text: 'The three core terms are untouched. The contract goes from 2 scopes to 3, so Number of scopes moves from 1 to 2 and the external score from 1.52 to 1.60. The rating stays 2.', ev: [{ n: 'Ember_Mesa_Amendment_4_draft.docx' }, { n: 'Scorecard · Number of scopes bands', d: { view: 'documents', doc: 'DOC:risk-spec', note: '' } }], acts: [] },
  { id: 'd3', kind: 'New bid', title: 'City of Sable Harbor, Florida: WWTP, collection and biosolids', sub: 'Request for proposals due 11 December', lines: [['Scope', 'Wastewater treatment, collection, biosolids'], ['Term', '10 years from 1 July 2027'], ['Estimated fee', '$8.2M a year'], ['Draft agreement', 'Client form: liability capped, no waiver of consequential damages']], verdict: 'note', head: 'This contract would enter the scorecard at 3 on its first day', text: 'Before anyone runs the plant: Florida ranks 49 of 50 on liability cost (rating 4), 14,800 homes sit within 2 miles (rating 4), the scope includes biosolids (rating 4), the plant is under a consent order signed in 2024, and the client form has no waiver of consequential damages. External score 3.12. It is the profile of Harlow Creek with a consent order added.', better: { from: 'Bid on the client form', to: 'Bid with the waiver added, odor control capital named as the City\'s, and the consent order milestones priced', note: 'Three terms that take the first-day rating from 3 to 2.' }, ev: [{ n: 'Sable_Harbor_RFP_2026-11.pdf · draft agreement, article 12' }, { n: 'richstatespoorstates.org · Florida, rank 49', d: { view: 'web', doc: 'WEB:state-rank', note: '' } }, { n: 'County parcel file · 14,800 residential parcels within 2 miles' }, { n: 'State enforcement page · consent order, 2024' }], acts: [{ k: 'terms', label: 'Send the three terms to the bid team', primary: true, outcome: 'Three terms sent to the bid team' }, { k: 'asis', label: 'Bid as it is, with a reason', outcome: 'Bid on the client form; reason recorded' }] },
]

export function StepModal({ open, onClose, j, onOpen }: { open: boolean; onClose: () => void; j: Journey; onOpen: (d: Drill) => void }) {
  const [id, setId] = useState('d1')
  const [asked, setAsked] = useState<Record<string, boolean>>({})
  const [done, setDone] = useState<Record<string, string>>({})
  const [reason, setReason] = useState('')
  const [keep, setKeep] = useState<string | null>(null)
  const [how, setHow] = useState(false)
  const add = useStepCalls((s) => s.add)
  const dr = DRAFTS.find((x) => x.id === id)!
  const ask = () => { setAsked((a) => ({ ...a, [id]: true })); if (!dr.acts.length) { setDone((x) => ({ ...x, [id]: 'Nothing to flag' })); add(j.id, { id: `${id}-${Date.now()}`, at: hhmm(), item: dr.title, outcome: 'Nothing to flag' }) } }
  const settle = (outcome: string) => { setDone((x) => ({ ...x, [id]: outcome })); add(j.id, { id: `${id}-${Date.now()}`, at: hhmm(), item: dr.title, outcome }); setKeep(null); setReason('') }
  const sample = { request: { asked_by: 'contract-desk', step: 'before_approval', draft: dr.id, kind: dr.kind, title: dr.title }, answer: { verdict: dr.verdict === 'flag' ? 'breaks_a_core_term' : dr.verdict === 'clear' ? 'nothing_to_flag' : 'advice', headline: dr.head, evidence: dr.ev.map((e) => e.n), better_option: dr.better?.to ?? null, writes_to_source_system: false } }
  return (
    <Modal open={open} onCancel={onClose} footer={null} width="min(1040px, 94vw)" destroyOnHidden title={<span className="stp-title">At the step · {j.agent.name} called from the contract desk</span>} className="stp-modal" data-testid="step-modal">
      <div className="stp-tabs"><button type="button" className={how ? '' : 'is-on'} onClick={() => setHow(false)}>In the contract desk</button><button type="button" className={how ? 'is-on' : ''} data-testid="stp-how" onClick={() => setHow(true)}>How it is called</button></div>
      {how ? (
        <div className="stp-contract" data-testid="stp-contract">
          <p className="tg-note">Another system asks before a draft goes for approval, and shows my answer in its own screen. I answer with a verdict, the reason, the evidence and a better option. I never write to the contract desk.</p>
          <pre className="sb-json">{JSON.stringify(sample, null, 2)}</pre>
          <p className="tg-note">Three doors: a person asks me directly, the contract desk raises an event when a draft is saved, or another engine uses me as a step in its own workflow.</p>
        </div>
      ) : (
        <div className="stp">
          <div className="stp-pick">{DRAFTS.map((x) => <button type="button" key={x.id} className={x.id === id ? 'is-on' : ''} data-draft={x.id} onClick={() => { setId(x.id); setKeep(null) }}><b>{x.kind}{done[x.id] ? ' · answered' : ''}</b><span>{x.title}</span></button>)}</div>
          <div className="erp">
            <div className="erp-bar"><b>Contract desk</b><span>Northline Contract Operations · drafts for approval</span></div>
            <div className="sb-erp-body">
              <div className="sb-erp-h"><b>{dr.title}</b><span>{dr.sub}</span></div>
              <table className="sb-erp-t"><tbody>{dr.lines.map(([k, v]) => <tr key={k}><td>{k}</td><td>{v}</td></tr>)}</tbody></table>
              {asked[id] ? null : <Button type="primary" size="small" data-testid="stp-ask" onClick={ask}>Check before approval</Button>}
            </div>
          </div>
          {asked[id] ? (
            <div className={`stp-msg is-${dr.verdict === 'flag' ? 'flag' : dr.verdict === 'clear' ? 'clear' : 'note'}`} data-testid="stp-answer">
              <div className="stp-msg-h"><span className="stp-who">{j.agent.name} · Contract Risk Analyst</span><span className={`tag ${dr.verdict === 'clear' ? 'ok' : 'need'}`}>{dr.verdict === 'flag' ? 'Breaks a non-negotiable term' : dr.verdict === 'clear' ? 'Clear' : 'Advice'}</span></div>
              <b>{dr.head}</b>
              <p>{dr.text}</p>
              {dr.better ? <div className="stp-better"><div><small>As drafted</small><b>{dr.better.from}</b></div><ArrowRightOutlined /><div><small>Better</small><b>{dr.better.to}</b><span>{dr.better.note}</span></div></div> : null}
              <div className="stp-ev">{dr.ev.map((e) => (e.d ? <a key={e.n} onClick={() => { onClose(); onOpen(e.d!) }}>{e.n}</a> : <a key={e.n} className="is-plain">{e.n}</a>))}</div>
              {done[id] ? <div className="stp-acts"><span className="stp-done"><CheckOutlined /> {done[id]}</span></div>
                : keep ? <div className="stp-keep"><Input size="small" autoFocus value={reason} onChange={(e) => setReason(e.target.value)} placeholder="The reason, for the record" onPressEnter={() => reason.trim() && settle(`${keep}: “${reason.trim()}”`)} /><Button size="small" type="primary" disabled={!reason.trim()} data-testid="stp-keep-ok" onClick={() => settle(`${keep}: “${reason.trim()}”`)}>Record it</Button></div>
                : dr.acts.length ? <div className="stp-acts">{dr.acts.map((a) => <Button key={a.k} size="small" type={a.primary ? 'primary' : 'default'} data-act={a.k} onClick={() => (a.primary ? settle(a.outcome) : setKeep(a.outcome))}>{a.label}</Button>)}<span>These buttons are the drafter's, in their own system. I change nothing there.</span></div> : null}
            </div>
          ) : <div className="stp-msg is-wait">The contract desk has not asked yet. Press “Check before approval” as the drafter would.</div>}
        </div>
      )}
    </Modal>
  )
}
