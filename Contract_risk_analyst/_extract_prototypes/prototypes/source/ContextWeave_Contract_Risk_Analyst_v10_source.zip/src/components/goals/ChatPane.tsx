import { ArrowUpOutlined, PaperClipOutlined } from '@ant-design/icons'
import { Input, Typography } from 'antd'
import { Fragment, useEffect, useRef, useState } from 'react'
import type { Agent } from '../../data/goalCases'
import type { ChatMsg } from '../../store/goalStore'
import { fileSize } from '../../data/readFile'
import { AgentBadge } from './parts'
import { PaneControls } from './TwoPane'
import './ChatPane.css'

const { Text } = Typography

/*
 * The conversation with the agent: the right half of a goal. Agent messages on the left with the
 * agent's mark, the analyst's on the right, quiet event lines in the middle (a rule fired, a step done).
 * Suggestions above the box are things you could say; tapping one sends it as your message.
 */

/** **bold** and line breaks, nothing more. */
function Rich({ text }: { text: string }) {
  return (
    <>
      {text.split('\n').map((line, i, all) => (
        <Fragment key={i}>
          {line.split(/(\*\*[^*]+\*\*)/g).map((part, j) => (part.startsWith('**') && part.endsWith('**') ? <strong key={j}>{part.slice(2, -2)}</strong> : <Fragment key={j}>{part}</Fragment>))}
          {i < all.length - 1 ? <br /> : null}
        </Fragment>
      ))}
    </>
  )
}

export default function ChatPane({
  agent,
  messages,
  typing,
  chips,
  onSend,
  placeholder,
  title,
  onUpload,
  accept,
  controls = true,
  scope,
  onClearScope,
}: {
  agent: Agent
  messages: ChatMsg[]
  typing: boolean
  chips: string[]
  onSend: (text: string) => void
  placeholder?: string
  title?: string
  /** When set, a paperclip in the box lets the analyst drop a file into the conversation. */
  onUpload?: (file: File) => void
  accept?: string
  /** Show the split controls (only where the chat sits in a TwoPane). */
  controls?: boolean
  /** What the next message is about (a selected slide or section), shown above the box. */
  scope?: string
  onClearScope?: () => void
}) {
  const fileInput = useRef<HTMLInputElement>(null)
  const [text, setText] = useState('')
  const end = useRef<HTMLDivElement>(null)
  useEffect(() => {
    end.current?.scrollIntoView({ block: 'end', behavior: 'smooth' })
  }, [messages.length, typing])

  const send = (t: string) => {
    const v = t.trim()
    if (!v) return
    onSend(v)
    setText('')
  }

  return (
    <aside className="gc" aria-label={`Chat with ${agent.name}`}>
      <div className="gc-head">
        <AgentBadge agent={agent} size="large" />
        <span className="gc-head-right"><Text type="secondary" style={{ fontSize: 12 }}>{title ?? 'talk to me or click on the left'}</Text>{controls ? <PaneControls /> : null}</span>
      </div>
      <div className="gc-feed">
        {messages.map((m) =>
          m.who === 'event' ? (
            <div key={m.id} className="gc-event">{m.text}</div>
          ) : m.who === 'agent' ? (
            <div key={m.id} className="gc-row is-agent">
              <AgentBadge agent={agent} bare />
              <div className="gc-bubble is-agent" style={{ ['--agent' as string]: agent.colour }}><Rich text={m.text} /></div>
            </div>
          ) : (
            <div key={m.id} className="gc-row is-me">
              <div className="gc-bubble is-me">{m.file ? <span className="gc-file"><PaperClipOutlined /> {m.file.name} <span className="gc-file-size">{fileSize(m.file.size)}</span></span> : null}{m.text}</div>
            </div>
          ),
        )}
        {typing ? (
          <div className="gc-row is-agent">
            <AgentBadge agent={agent} bare />
            <div className="gc-bubble is-agent gc-typing"><span /><span /><span /></div>
          </div>
        ) : null}
        <div ref={end} />
      </div>
      {chips.length ? (
        <div className="gc-chips">
          {chips.map((c) => (
            <span key={c} role="button" tabIndex={0} className="gc-chip" onClick={() => send(c)} onKeyDown={(e) => { if (e.key === 'Enter') send(c) }}>{c}</span>
          ))}
        </div>
      ) : null}
      {scope ? <div className="gc-scope">About: <b>{scope}</b>{onClearScope ? <span role="button" tabIndex={0} aria-label="Clear" onClick={onClearScope}>×</span> : null}</div> : null}
      <div className="gc-box">
        {onUpload ? (
          <>
            <span role="button" aria-label="Attach a file" title="Attach a file" tabIndex={0} className="gc-clip" onClick={() => fileInput.current?.click()}><PaperClipOutlined /></span>
            <input ref={fileInput} type="file" accept={accept ?? '.pptx,.docx,.pdf,.txt,.md,.csv,.xlsx'} style={{ display: 'none' }} onChange={(e) => { const f = e.target.files?.[0]; if (f) onUpload(f); e.target.value = '' }} data-testid="chat-upload" />
          </>
        ) : null}
        <Input.TextArea
          value={text}
          onChange={(e) => setText(e.target.value)}
          autoSize={{ minRows: 1, maxRows: 5 }}
          placeholder={placeholder ?? `Message ${agent.name}`}
          onPressEnter={(e) => { if (!e.shiftKey) { e.preventDefault(); send(text) } }}
          variant="borderless"
          aria-label="Message"
        />
        <span role="button" aria-label="Send" tabIndex={0} className={`gc-send${text.trim() ? ' is-on' : ''}`} onClick={() => send(text)}><ArrowUpOutlined /></span>
      </div>
    </aside>
  )
}
