import { DownloadOutlined, FileTextOutlined, GlobalOutlined, MailOutlined } from '@ant-design/icons'
import { Button, Flex, Input, Select, Table, Tag, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { download, toCsv, type Doc, type Mail } from '../../data/drill'
import type { Drill } from '../../data/goalCases'
import { CONTRACTS, FACTORS, LOST, NIGHT, RATING_COLOR, RATING_NAME, RATING_SOFT, SCORING, SIGNALS, STATE_NAME, TODAY, byId, f1, factorScore, groupScore, m1, rating, readingOf, renewals, score, type Contract } from '../../data/risk'
import { DESIGN, activeSignals, planFor } from '../../data/risk'
import { usePlans } from './RiskBoard'
import { docById, docsFor, mailFor, threadMessages } from '../../data/riskDocs'
import { BRAND_INK, BRAND_SOFT, SP, STATUS } from '../../theme'
import './DataExplorer.css'

const { Text } = Typography

/*
 * The worksheet behind a goal. One workbook, eight sheets, the way an analyst expects to check a number:
 * a contract filter and a search on top, a status bar with the count of what is on screen, the grid with
 * row numbers, and sheet tabs along the bottom. Scorecard, Signals, Sources, Actions and Renewals come
 * from the scorecard and the warehouse; Documents, Mail and Web are the unstructured half of the same
 * world, with a reader beside the grid. Every sheet downloads as CSV.
 */

export type Sheet = 'scorecard' | 'contract' | 'signals' | 'actions' | 'renewals' | 'documents' | 'mail' | 'web'

const SHEETS: { key: Sheet; label: string; needsContract?: boolean }[] = [
  { key: 'scorecard', label: 'Scorecard' },
  { key: 'contract', label: 'Signals', needsContract: true },
  { key: 'signals', label: 'Sources' },
  { key: 'actions', label: 'Actions' },
  { key: 'renewals', label: 'Renewals' },
  { key: 'documents', label: 'Documents' },
  { key: 'mail', label: 'Mail' },
  { key: 'web', label: 'Web' },
]

const sheetFromDrill = (d: Drill): Sheet =>
  d.doc?.startsWith('WEB:') ? 'web' : d.view === 'contract' || d.view === 'signals' || d.view === 'actions' || d.view === 'renewals' || d.view === 'documents' || d.view === 'mail' || d.view === 'web' ? d.view : 'scorecard'

const rt = (r: number) => { const i = Math.min(4, Math.max(1, Math.floor(r))); return <span className="ws-num" style={{ display: 'inline-block', minWidth: 22, textAlign: 'center', borderRadius: 5, padding: '0 4px', fontWeight: 700, background: RATING_SOFT[i], color: RATING_COLOR[i] }}>{r}</span> }

export default function DataExplorer({ start, height = 460 }: { start: Drill; height?: number }) {
  const [sheet, setSheet] = useState<Sheet>(sheetFromDrill(start))
  const [contract, setContract] = useState<string | undefined>(start.contract)
  const [q, setQ] = useState('')
  const [doc, setDoc] = useState<string | undefined>(start.doc)
  const [thread, setThread] = useState<string | undefined>(start.thread)

  useEffect(() => {
    setSheet(sheetFromDrill(start))
    setContract(start.contract)
    setDoc(start.doc)
    setThread(start.thread)
    setQ('')
  }, [start])

  const needsContract = SHEETS.find((s) => s.key === sheet)?.needsContract && !contract
  const gridHeight = height - 150
  const scoped = sheet === 'documents' || sheet === 'mail' || sheet === 'web' || sheet === 'actions' ? contract : undefined

  return (
    <div className="ws">
      <Flex className="ws-bar" align="center" gap={SP.sm} wrap>
        <Select size="small" allowClear placeholder="All contracts" value={contract} onChange={(v) => setContract(v)} style={{ width: 300 }} showSearch optionFilterProp="label"
          options={CONTRACTS.map((c) => ({ value: c.id, label: `${c.id} · ${c.site}, ${c.state}` }))} />
        <Input.Search size="small" allowClear placeholder="Find in this sheet" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: 240 }} />
        <Text type="secondary" style={{ fontSize: 12, marginLeft: 'auto' }}>As of the {NIGHT.landed ? '20' : '19'} November check · US dollars</Text>
      </Flex>

      <div className="ws-body" style={{ height: gridHeight + 56 }}>
        {needsContract ? <PickContract onPick={(c) => setContract(c)} />
          : sheet === 'scorecard' ? <ScorecardSheet q={q} height={gridHeight} onOpen={(c) => { setContract(c); setSheet('contract') }} />
          : sheet === 'contract' ? <ContractSheet c={byId(contract!)!} q={q} height={gridHeight} />
          : sheet === 'signals' ? <SourcesSheet q={q} height={gridHeight} />
          : sheet === 'actions' ? <ActionsSheet contract={scoped} q={q} height={gridHeight} onOpen={(c) => { setContract(c); setSheet('contract') }} />
          : sheet === 'renewals' ? <RenewalsSheet q={q} height={gridHeight} onOpen={(c) => { setContract(c); setSheet('contract') }} />
          : sheet === 'documents' ? <DocumentsSheet contract={scoped} q={q} height={gridHeight} selected={doc} onSelect={setDoc} />
          : sheet === 'web' ? <DocumentsSheet web contract={scoped} q={q} height={gridHeight} selected={doc} onSelect={setDoc} />
          : <MailSheet contract={scoped} q={q} height={gridHeight} thread={thread} onSelect={setThread} />}
      </div>

      <div className="ws-tabs">
        {SHEETS.map((s) => (
          <button key={s.key} type="button" className={`ws-tab${sheet === s.key ? ' is-active' : ''}`} data-sheet={s.key} onClick={() => setSheet(s.key)}>
            {s.key === 'documents' ? <FileTextOutlined /> : s.key === 'mail' ? <MailOutlined /> : s.key === 'web' ? <GlobalOutlined /> : null} {s.label}
          </button>
        ))}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ pieces */

function StatusBar({ items, csv }: { items: { label: string; value: string; tone?: 'good' | 'warn' | 'crit' }[]; csv?: { name: string; rows: Record<string, unknown>[] } }) {
  return (
    <Flex className="ws-status" align="center" gap={SP.lg} wrap>
      {items.map((i) => (
        <span key={i.label} className="ws-stat">
          <span className="ws-stat-label">{i.label}</span>
          <span className="ws-stat-value" style={{ color: i.tone === 'crit' ? STATUS.crit : i.tone === 'good' ? STATUS.good : i.tone === 'warn' ? STATUS.warn : undefined }}>{i.value}</span>
        </span>
      ))}
      {csv ? <Button size="small" type="text" icon={<DownloadOutlined />} style={{ marginLeft: 'auto' }} onClick={() => download(csv.name, toCsv(csv.rows), 'text/csv')}>CSV</Button> : null}
    </Flex>
  )
}

const rowNo = { title: '', key: '_n', width: 44, className: 'ws-rowno', render: (_: unknown, __: unknown, i: number) => i + 1 }
const match = (q: string, ...vals: (string | number | null | undefined)[]) => !q.trim() || vals.some((v) => String(v ?? '').toLowerCase().includes(q.trim().toLowerCase()))

function PickContract({ onPick }: { onPick: (c: string) => void }) {
  const top = useMemo(() => CONTRACTS.slice().sort((a, b) => score(b, SCORING.rule) - score(a, SCORING.rule)).slice(0, 8), [])
  return (
    <div style={{ padding: SP.lg }}>
      <Text style={{ display: 'block', marginBottom: SP.sm }}>This sheet shows one contract signal by signal. Pick a contract above, or one of these:</Text>
      <Flex gap={SP.xs} wrap>{top.map((c) => <Button key={c.id} size="small" onClick={() => onPick(c.id)}>{c.id} · {c.site}</Button>)}</Flex>
    </div>
  )
}

interface Row { c: Contract; i: number; e: number; s: number; r: number; was: number; chg: boolean }
function ScorecardSheet({ q, height, onOpen }: { q: string; height: number; onOpen: (c: string) => void }) {
  const rule = SCORING.rule
  const rows: Row[] = useMemo(() => CONTRACTS.map((c) => ({ c, i: groupScore(c, 'internal'), e: groupScore(c, 'external'), s: score(c, rule), r: rating(c, rule), was: rating(c, rule, 'before'), chg: NIGHT.landed && !!c.night })).filter((x) => match(q, x.c.id, x.c.site, x.c.client, x.c.state, x.c.region, x.c.rvp)).sort((a, b) => Number(b.chg) - Number(a.chg) || b.s - a.s), [q, rule])
  const fcol = (fid: string, short: string) => ({ title: short, key: fid, width: 58, align: 'right' as const, render: (_: unknown, x: Row) => { const v = factorScore(x.c, fid); return v === null ? <span className="ws-num">n/a</span> : <span className="ws-num" style={{ color: v >= 3 ? STATUS.crit : undefined }}>{f1(v)}</span> } })
  return (
    <>
      <StatusBar items={[{ label: 'Contracts', value: `${rows.length}` }, { label: 'Rated 3 or 4', value: `${rows.filter((x) => x.r >= 3).length}`, tone: 'warn' }, { label: 'Changed at this check', value: `${rows.filter((x) => x.chg).length}` }, { label: 'Revenue', value: m1(rows.reduce((n, x) => n + x.c.revenue, 0)) }]}
        csv={{ name: 'scorecard.csv', rows: rows.map((x) => ({ contract: x.c.id, site: x.c.site, client: x.c.client, state: x.c.state, region: x.c.region, regional_vp: x.c.rvp, internal: f1(x.i), external: f1(x.e), rating: x.r, ...Object.fromEntries(FACTORS.map((f) => [f.name, factorScore(x.c, f.id) === null ? '' : f1(factorScore(x.c, f.id)!)])), revenue: x.c.revenue, ends: x.c.evergreen ? 'evergreen' : x.c.end })) }} />
      <Table<Row> className="ws-grid" size="small" bordered rowKey={(x) => x.c.id} dataSource={rows} pagination={false} virtual scroll={{ y: height - 84, x: 1500 }}
        rowClassName={(x) => (x.chg ? 'is-selected' : '')}
        onRow={(x) => ({ onClick: () => onOpen(x.c.id), style: { cursor: 'pointer' } })}
        columns={[rowNo, { title: 'Contract', key: 'id', width: 84, fixed: 'left', render: (_, x) => x.c.id }, { title: 'Site', key: 'site', width: 186, fixed: 'left', ellipsis: true, render: (_, x) => <span>{x.c.site}{x.chg ? <Tag color={x.r !== x.was ? 'error' : 'warning'} style={{ marginLeft: 6, marginInlineEnd: 0 }}>{x.r !== x.was ? `${x.was} → ${x.r}` : 'changed'}</Tag> : null}</span> },
          { title: 'Rating', key: 'r', width: 66, align: 'center', render: (_, x) => rt(x.r) }, { title: 'Internal', key: 'i', width: 88, align: 'right', render: (_, x) => <span className="ws-num">{f1(x.i)}</span> }, { title: 'External', key: 'e', width: 88, align: 'right', render: (_, x) => <span className="ws-num">{f1(x.e)}</span> }, { title: 'State', key: 'st', width: 60, render: (_, x) => x.c.state }, { title: 'Region', key: 'rg', width: 110, render: (_, x) => x.c.region },
          fcol('gr', 'Golden'), fcol('cr', 'Contract'), fcol('os', 'OSHA'), fcol('en', 'Environ.'), fcol('st', 'Staffing'), fcol('cu', 'Customer'), fcol('co', 'Commun.'), fcol('sl', 'State'), fcol('li', 'Litigat.'), fcol('in', 'Infra.'), fcol('sp', 'Proxim.'), fcol('iq', 'Influent'),
          { title: 'Revenue', key: 'rev', width: 90, align: 'right', render: (_, x) => <span className="ws-num">{m1(x.c.revenue)}</span> }]} />
    </>
  )
}

interface SigRow { id: string; factor: string; group: string; weight: number; name: string; rank: number; raw: string; r: number; was?: number; band: string; src: string; chg: boolean }
function ContractSheet({ c, q, height }: { c: Contract; q: string; height: number }) {
  const rows: SigRow[] = useMemo(() => SIGNALS.filter((s) => c.v[s.id] && DESIGN.on[s.id]).map((s) => { const f = FACTORS.find((x) => x.id === s.f)!; const rd = readingOf(c, s.id)!; const i = Math.min(4, Math.max(1, Math.floor(rd.r))); return { id: s.id, factor: f.name, group: f.group === 'internal' ? 'What we control' : f.group === 'external' ? 'What we do not' : 'At stake', weight: f.weight, name: s.name, rank: s.rank, raw: rd.raw, r: rd.r, was: rd.was, band: s.bands[i - 1] || s.bands[0], src: s.src.name, chg: NIGHT.landed && !!c.night?.[s.id] } }).filter((x) => match(q, x.factor, x.name, x.raw, x.src)), [c, q])
  const r = rating(c, SCORING.rule)
  return (
    <>
      <StatusBar items={[{ label: 'Contract', value: `${c.id} ${c.site}, ${STATE_NAME[c.state] ?? c.state}` }, { label: 'Rating', value: `${r} · ${RATING_NAME[r]}`, tone: r >= 3 ? 'crit' : undefined }, { label: 'Internal', value: f1(groupScore(c, 'internal')) }, { label: 'External', value: f1(groupScore(c, 'external')) }, { label: 'Signals', value: `${rows.length}` }]}
        csv={{ name: `signals_${c.id}.csv`, rows: rows.map((x) => ({ group: x.group, factor: x.factor, factor_weight: x.weight, signal: x.name, rank: x.rank, reading: x.raw, rating: x.r, rating_90_days_ago: x.was ?? x.r, band: x.band, source: x.src })) }} />
      <Table<SigRow> className="ws-grid" size="small" bordered rowKey="id" dataSource={rows} pagination={false} scroll={{ y: height - 84 }}
        rowClassName={(x) => (x.chg ? 'is-selected' : '')}
        columns={[rowNo, { title: 'Factor', dataIndex: 'factor', width: 190, ellipsis: true, render: (v: string, x) => `${v} · ${x.weight}%` }, { title: 'Signal', dataIndex: 'name', width: 230, ellipsis: true }, { title: 'Rank', dataIndex: 'rank', width: 56, align: 'center' }, { title: 'Reading', dataIndex: 'raw', width: 240, ellipsis: true }, { title: 'Rating', dataIndex: 'r', width: 70, align: 'center', render: (v: number, x) => <span>{rt(v)}{x.chg ? <Tag color="error" style={{ marginLeft: 4, marginInlineEnd: 0 }}>was {x.was}</Tag> : null}</span> }, { title: 'Band of the scorecard', dataIndex: 'band', ellipsis: true }, { title: 'Read from', dataIndex: 'src', width: 240, ellipsis: true }]} />
    </>
  )
}

function SourcesSheet({ q, height }: { q: string; height: number }) {
  const rows = useMemo(() => activeSignals().map((s) => ({ ...s, factor: FACTORS.find((x) => x.id === s.f)!.name })).filter((s) => match(q, s.name, s.factor, s.src.name, s.src.how, s.spec.steward)), [q])
  return (
    <>
      <StatusBar items={[{ label: 'Signals', value: `${rows.length}` }, { label: 'From data', value: `${rows.filter((x) => x.src.kind === 'table').length}` }, { label: 'From documents', value: `${rows.filter((x) => x.src.kind === 'document').length}` }, { label: 'From mail', value: `${rows.filter((x) => x.src.kind === 'mail').length}` }, { label: 'From the web', value: `${rows.filter((x) => x.src.kind === 'web').length}`, tone: 'good' }]}
        csv={{ name: 'signal_sources.csv', rows: rows.map((s) => ({ factor: s.factor, signal: s.name, rank: s.rank, band_1: s.bands[0], band_2: s.bands[1], band_3: s.bands[2], band_4: s.bands[3], workbook_available: s.spec.avail ? 'Y' : '', workbook_manual: s.spec.manual ? 'Y' : '', workbook_frequency: s.spec.freq, workbook_steward: s.spec.steward, read_from: s.src.name, how: s.src.how })) }} />
      <Table className="ws-grid" size="small" bordered rowKey="id" dataSource={rows} pagination={false} scroll={{ y: height - 84 }}
        columns={[rowNo, { title: 'Factor', dataIndex: 'factor', width: 190, ellipsis: true }, { title: 'Signal', dataIndex: 'name', width: 230, ellipsis: true }, { title: 'Rank', dataIndex: 'rank', width: 56, align: 'center' as const }, { title: 'In the scorecard', key: 'spec', width: 210, render: (_: unknown, s) => `${s.spec.avail ? 'Available' : 'Not available yet'}${s.spec.manual ? ' · manual' : ''} · ${s.spec.freq}` }, { title: 'Read here from', key: 'src', width: 280, ellipsis: true, render: (_: unknown, s) => s.src.name }, { title: 'How', key: 'how', ellipsis: true, render: (_: unknown, s) => s.src.how }]} />
    </>
  )
}

interface ActRow { key: string; c: Contract; lens: string; text: string; owner: string; due: string; state: string; signal: string }
function ActionsSheet({ contract, q, height, onOpen }: { contract?: string; q: string; height: number; onOpen: (c: string) => void }) {
  const assigned = usePlans((x) => x.assigned)
  const rows: ActRow[] = CONTRACTS.filter((c) => (!contract || c.id === contract) && rating(c, SCORING.rule) >= 3).flatMap((c) => planFor(c).filter((p) => !p.fixed && !p.later).map((p) => ({ key: p.id, c, lens: p.f.name, text: p.text, owner: p.owner, due: p.due, state: assigned[c.id] ? 'Open' : 'Proposed', signal: p.s.name }))).filter((x) => match(q, x.c.id, x.c.site, x.text, x.owner, x.lens, x.state, x.signal))
  return (
    <>
      <StatusBar items={[{ label: 'Actions', value: `${rows.length}` }, { label: 'Contracts rated 3 or 4', value: `${new Set(rows.map((x) => x.c.id)).size}` }, { label: 'Proposed', value: `${rows.filter((x) => x.state === 'Proposed').length}` }, { label: 'Assigned', value: `${rows.filter((x) => x.state === 'Open').length}`, tone: 'good' }]}
        csv={{ name: 'mitigation_plans.csv', rows: rows.map((x) => ({ contract: x.c.id, site: x.c.site, region: x.c.region, factor: x.lens, action: x.text, signal: x.signal, owner: x.owner, due: x.due, state: x.state })) }} />
      <Table<ActRow> className="ws-grid" size="small" bordered rowKey="key" dataSource={rows} pagination={false} virtual scroll={{ y: height - 84, x: 1200 }}
        onRow={(x) => ({ onClick: () => onOpen(x.c.id), style: { cursor: 'pointer' } })}
        columns={[rowNo, { title: 'Contract', key: 'c', width: 210, ellipsis: true, render: (_, x) => `${x.c.id} · ${x.c.site}` }, { title: 'Factor', dataIndex: 'lens', width: 150, ellipsis: true }, { title: 'Action', dataIndex: 'text', ellipsis: true }, { title: 'Signal', dataIndex: 'signal', width: 170, ellipsis: true }, { title: 'Owner', dataIndex: 'owner', width: 200, ellipsis: true }, { title: 'Due', dataIndex: 'due', width: 76 }, { title: 'State', dataIndex: 'state', width: 110, render: (v: string) => <Tag color={v === 'Open' ? 'success' : 'processing'} style={{ marginInlineEnd: 0 }}>{v}</Tag> }]} />
    </>
  )
}

interface RenRow { key: string; site: string; state: string; region: string; rvp: string; revenue: number; left: string; r: number; signs: string; plan: boolean; c?: Contract }
function RenewalsSheet({ q, height, onOpen }: { q: string; height: number; onOpen: (c: string) => void }) {
  const x = useMemo(() => renewals(SCORING.rule, true), [])
  const rows: RenRow[] = useMemo(() => [
    ...x.set.slice().sort((a, b) => Number(x.plan.includes(b)) - Number(x.plan.includes(a)) || b.revenue - a.revenue).map((c) => ({ key: c.id, site: `${c.id} · ${c.site}`, state: c.state, region: c.region, rvp: c.rvp, revenue: c.revenue, left: c.evergreen ? 'Evergreen · client may end on notice' : `${c.monthsLeft} months · ends ${c.end}`, r: rating(c, SCORING.rule, 'before'), signs: c.seen.filter((s) => (NIGHT.landed || !s.night) && ['lead', 'rfp', 'insource', 'comp', 'fin', 'end'].includes(s.k)).map((s) => s.label).join('; '), plan: x.plan.includes(c), c })),
    ...LOST.map((l) => ({ key: `lost-${l.site}`, site: `Lost · ${l.site}`, state: l.state, region: '', rvp: '', revenue: l.revenue, left: `${l.how}, ${l.lost}`, r: l.rated, signs: `A year before: ${l.moved.join('; ')}`, plan: false })),
  ].filter((r) => match(q, r.site, r.state, r.region, r.rvp, r.signs, r.left)), [q, x])
  return (
    <>
      <StatusBar items={[{ label: 'Decide in 18 months', value: `${x.set.length}` }, { label: 'Revenue a year', value: m1(x.revenue) }, { label: 'Need a renewal plan', value: `${x.plan.length} · ${m1(x.planRev)}`, tone: 'warn' }, { label: 'Lost since 2024', value: `${LOST.length}` }, { label: 'Today', value: TODAY }]}
        csv={{ name: 'renewals.csv', rows: rows.map((r) => ({ contract: r.site, state: r.state, region: r.region, regional_vp: r.rvp, revenue: r.revenue, left: r.left, scorecard_rating: r.r, client_side_signs: r.signs, on_plan_list: r.plan ? 'Y' : '' })) }} />
      <Table<RenRow> className="ws-grid" size="small" bordered rowKey="key" dataSource={rows} pagination={false} scroll={{ y: height - 84, x: 1200 }}
        rowClassName={(r) => (r.plan ? 'is-selected' : '')}
        onRow={(r) => ({ onClick: () => r.c && onOpen(r.c.id), style: { cursor: r.c ? 'pointer' : 'default' } })}
        columns={[rowNo, { title: 'Contract', dataIndex: 'site', width: 260, ellipsis: true, render: (v: string, r) => <span>{v}{r.plan ? <Tag color="warning" style={{ marginLeft: 6, marginInlineEnd: 0 }}>plan</Tag> : null}</span> }, { title: 'State', dataIndex: 'state', width: 60 }, { title: 'Regional VP', dataIndex: 'rvp', width: 130, ellipsis: true }, { title: 'Revenue', dataIndex: 'revenue', width: 90, align: 'right', render: (v: number) => <span className="ws-num">{m1(v)}</span> }, { title: 'Left', dataIndex: 'left', width: 250, ellipsis: true }, { title: 'Rating', dataIndex: 'r', width: 70, align: 'center', render: (v: number) => rt(v) }, { title: 'Beside the scorecard: client-side signs', dataIndex: 'signs', ellipsis: true }]} />
    </>
  )
}

function DocumentsSheet({ contract, q, height, selected, onSelect, web }: { contract?: string; q: string; height: number; selected?: string; onSelect: (id?: string) => void; web?: boolean }) {
  const rows = useMemo(() => docsFor(contract, !!web).filter((d) => match(q, d.name, d.type, d.folder, d.org, d.evidence_for, d.project)), [contract, q, web])
  const sel = selected ? docById(selected) : null
  const shown = sel && (sel.folder === 'Web') === !!web ? sel : null
  return (
    <>
      <StatusBar items={web ? [{ label: 'Pages', value: `${rows.length}` }, { label: 'Read at', value: 'every check, and cited where used' }] : [{ label: 'Documents', value: `${rows.length}` }, { label: 'Scope', value: contract ?? 'all contracts' }]}
        csv={{ name: web ? 'web_pages.csv' : 'documents.csv', rows: rows.map((d) => ({ id: d.id, name: d.name, folder: d.folder, type: d.type, contract: d.project, date: d.date, organisation: d.org, read_for: d.evidence_for })) }} />
      <div className="ws-split" style={{ height: height - 44 }}>
        <Table<Doc> className="ws-grid" size="small" bordered rowKey="id" dataSource={rows} pagination={false} scroll={{ y: height - 84 }}
          rowClassName={(d) => (d.id === selected ? 'is-selected' : '')}
          onRow={(d) => ({ onClick: () => onSelect(d.id), style: { cursor: 'pointer' } })}
          columns={[rowNo, { title: web ? 'Page' : 'Document', dataIndex: 'name', ellipsis: true, render: (v: string) => <span>{web ? <GlobalOutlined style={{ color: BRAND_INK, marginRight: 6 }} /> : <FileTextOutlined style={{ color: BRAND_INK, marginRight: 6 }} />}{v}</span> }, { title: web ? 'Site' : 'Type', dataIndex: web ? 'org' : 'type', width: 170, ellipsis: true }, { title: 'Contract', dataIndex: 'project', width: 90 }, { title: 'Date', dataIndex: 'date', width: 105 }]} />
        <div className="ws-reader">
          {shown ? <DocReader d={shown} /> : <Text type="secondary" style={{ fontSize: 13 }}>{web ? 'Pick a page to read what was taken from it.' : 'Pick a document to read it here.'}</Text>}
        </div>
      </div>
    </>
  )
}

function DocReader({ d }: { d: Doc }) {
  return (
    <>
      <Text strong style={{ display: 'block' }}>{d.name}</Text>
      <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>{d.folder} · {d.type} · {d.org}{d.author ? ` · ${d.author}` : ''} · {d.date}{d.folder === 'Web' ? '' : ` · ${d.pages.length} page${d.pages.length === 1 ? '' : 's'}`}</Text>
      {d.evidence_for ? <Text style={{ display: 'block', fontSize: 12.5, margin: `${SP.sm}px 0`, padding: `${SP.xs}px ${SP.sm}px`, background: BRAND_SOFT, borderRadius: 6 }}>What the agent read it for: {d.evidence_for}</Text> : null}
      {d.pages.map((p, i) => <pre key={i} className="ws-page">{p}</pre>)}
    </>
  )
}

function MailSheet({ contract, q, height, thread, onSelect }: { contract?: string; q: string; height: number; thread?: string; onSelect: (t?: string) => void }) {
  const rows = useMemo(() => mailFor(contract).filter((m) => match(q, m.subject, m.sender, m.project, m.thread, m.text)), [contract, q])
  const msgs = thread ? threadMessages(thread) : []
  return (
    <>
      <StatusBar items={[{ label: 'Messages', value: `${rows.length}` }, { label: 'Threads', value: `${new Set(rows.map((m) => m.thread)).size}` }, { label: 'Scope', value: contract ?? 'all contracts' }]}
        csv={{ name: 'mail.csv', rows: rows.map((m) => ({ thread: m.thread, n: m.n, sent: m.at, from: m.sender, subject: m.subject, contract: m.project, mailbox: m.mailboxes.join(';'), attachments: m.attachments.join(';') })) }} />
      <div className="ws-split" style={{ height: height - 44 }}>
        <Table<Mail> className="ws-grid" size="small" bordered rowKey="id" dataSource={rows} pagination={false} scroll={{ y: height - 84 }}
          rowClassName={(m) => (m.thread === thread ? 'is-selected' : '')}
          onRow={(m) => ({ onClick: () => onSelect(m.thread), style: { cursor: 'pointer' } })}
          columns={[rowNo, { title: 'Sent', dataIndex: 'at', width: 130, render: (v: string) => v.slice(0, 16).replace('T', ' ') }, { title: 'From', dataIndex: 'sender', width: 170, ellipsis: true }, { title: 'Subject', dataIndex: 'subject', ellipsis: true, render: (v: string, m) => <span>{v}{m.attachments.length ? <Tag style={{ marginLeft: 6, marginInlineEnd: 0 }}>{m.attachments.length} att.</Tag> : null}</span> }, { title: 'Contract', dataIndex: 'project', width: 90 }, { title: 'Thread', dataIndex: 'thread', width: 70 }]} />
        <div className="ws-reader">
          {thread && msgs.length ? (
            <>
              <Text strong style={{ display: 'block' }}>{msgs[0]?.subject.replace(/^(Re|Fwd): /i, '')}</Text>
              <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>Thread {thread} · {msgs.length} message{msgs.length === 1 ? '' : 's'} · mailbox {msgs[0]?.mailboxes.join(', ')}{msgs[0]?.project ? ` · ${msgs[0].project}` : ''}</Text>
              {msgs[0]?.evidence_for ? <Text style={{ display: 'block', fontSize: 12.5, margin: `${SP.sm}px 0`, padding: `${SP.xs}px ${SP.sm}px`, background: BRAND_SOFT, borderRadius: 6 }}>What the agent read it for: {msgs[0].evidence_for}</Text> : null}
              {msgs.map((m) => (
                <div key={m.id} className="ws-msg">
                  <Text style={{ fontSize: 12.5 }}><strong>{m.sender}</strong> · {m.at.slice(0, 16).replace('T', ' ')}{m.attachments.length ? ` · attachments: ${m.attachments.join(', ')}` : ''}</Text>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>{m.subject}</Text>
                  <pre className="ws-page">{m.text}</pre>
                </div>
              ))}
            </>
          ) : <Text type="secondary" style={{ fontSize: 13 }}>Pick a message to read its thread here.</Text>}
        </div>
      </div>
    </>
  )
}
