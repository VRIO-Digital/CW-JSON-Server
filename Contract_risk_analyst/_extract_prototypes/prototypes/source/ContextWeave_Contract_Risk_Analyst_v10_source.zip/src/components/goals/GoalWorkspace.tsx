import { BulbOutlined, CheckCircleFilled, CheckCircleOutlined, CheckOutlined, FileSearchOutlined, PaperClipOutlined, LoadingOutlined, PlayCircleOutlined, PlusOutlined, QuestionCircleOutlined, SaveOutlined, SwapOutlined, TableOutlined, ThunderboltOutlined, WarningOutlined } from '@ant-design/icons'
import { Button, Drawer, Flex, Space, Tabs, Tag, Timeline, Typography } from 'antd'
import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { appPath } from '../../api/dataset'
import { downloadPack } from '../../data/exportPack'
import { STATUS_LABEL, TRIGGER_LABEL, type Beat, type Drill, type Goal, type PlanStep, type Recommendation } from '../../data/goalCases'
import { count, draftStep, extendStep, findingsSummary, helpText, interpret, rewordStep, shortHeadline, suggestions, type Intent, type Tab } from '../../data/goalChat'
import { useAuthStore } from '../../store/authStore'
import { describeRead, readUpload } from '../../data/readFile'
import { useGoalStore, type GoalView } from '../../store/goalStore'
import { useSubmissionStore } from '../../store/submissionStore'
import { SP, STATUS } from '../../theme'
import { AgentLog } from './ApproachEditor'
import ChatPane from './ChatPane'
import TwoPane from './TwoPane'
import DataExplorer from './DataExplorer'
import { AgentBadge, drillFromEvidence, drillFromRef, EvidenceLine, Figure, fmtDate, StatusTag, TriggerTag } from './parts'

const { Text } = Typography

/*
 * One goal, in two panes. Left: what is being run and its details (goal, approach, findings, data,
 * decision, submissions, log); it changes on its own as the work moves and as you talk. Right: the
 * conversation with the agent. There are no action buttons: approving the approach, changing a step,
 * opening a finding, accepting it, choosing a recommendation and starting a submission are all said.
 */

const shortRec = (r: Recommendation) => (r.title.split(/[;:,]\s/)[0] ?? r.title)

/* ------------------------------------------------------------------ left pane */

export function GoalTab({ g }: { g: Goal }) {
  return (
    <Flex vertical gap={SP.base}>
      <div className="gw-kv">
        <span>Goal</span><span>{g.goal}</span>
        <span>Measure</span><span>{g.target.measure}</span>
        <span>Target</span><span style={{ fontWeight: 500 }}>{g.target.target}</span>
        <span>Where it stands</span><span>{g.target.current}</span>
        <span>Deadline</span><span>{g.target.deadline}</span>
        <span>Starts</span><span>{g.triggerDetail}</span>
        <span>Scope</span><span>{g.scope.join(' · ')}</span>
        <span>Fixed</span><span>{g.constraints.length ? g.constraints.join(' · ') : 'Nothing stated'}</span>
        {g.files?.length ? <><span>Files</span><span>{g.files.map((f) => <span key={f.name} style={{ display: 'block' }}><PaperClipOutlined /> {f.name} <Text type="secondary" style={{ fontSize: 12 }}>· {f.read}</Text>{f.problem ? <Text type="secondary" style={{ display: 'block', fontSize: 12, fontStyle: 'italic' }}>"{f.problem}"</Text> : null}</span>)}</span></> : null}
      </div>
    </Flex>
  )
}

/** Say something to the agent from the screen: a button is a shortcut for a sentence in the chat. */
type Say = (text: string) => void

/** Numbers in a sentence (€ amounts, percentages, counts) as links that open the data behind them. */
export function Linked({ text, onOpen }: { text: string; onOpen: () => void }) {
  const parts = text.split(/((?<![\w\-/.,])(?:[€$]\s?)?\d(?:[\d,.]*\d)?(?:\s?(?:%|M|k|million))?(?!\s?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\b)(?![\w/-])(?:\s(?:funded projects|projects|snapshots|lines|order lines|items|posted lines|forecasts|decisions))?)/g)
  return (
    <>
      {parts.map((p, i) => (i % 2 === 1 && /\d/.test(p) && !/^\d{4}$/.test(p.trim()) ? <a key={i} className="gw-num-link" onClick={(e) => { e.stopPropagation(); onOpen() }}>{p}</a> : <span key={i}>{p}</span>))}
    </>
  )
}

function StepCard({ s, n, focus, colour, onFocus }: { s: PlanStep; n: number; focus: boolean; colour: string; onFocus: () => void }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => { if (focus) ref.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }) }, [focus])
  const removed = s.state === 'removed'
  return (
    <div ref={ref} onClick={onFocus} className={`gw-step gw-click${s.state === 'running' ? ' is-running' : ''}${removed ? ' is-removed' : ''}${focus ? ' gw-focus' : ''}`} style={{ ['--agent' as string]: colour }}>
      <Flex gap={SP.sm} align="flex-start">
        {s.state === 'done' ? <CheckCircleFilled style={{ color: STATUS.good, fontSize: 18, marginTop: 1 }} /> : s.state === 'running' ? <LoadingOutlined style={{ color: colour, fontSize: 18, marginTop: 1 }} /> : <span className={`gw-num${focus ? ' is-on' : ''}`}>{removed ? '–' : n}</span>}
        <div style={{ minWidth: 0, flex: 1 }}>
          <Text delete={removed} style={{ fontWeight: 500, fontSize: 13.5 }}>{s.title}</Text>
          {s.editedBy ? <Tag style={{ marginLeft: 6, fontSize: 11 }}>changed by {s.editedBy.split(' ')[0]}</Tag> : null}
          {focus && !removed ? <Text style={{ display: 'block', fontSize: 12.5, marginTop: 2 }}>{s.how}</Text> : null}
          <Text type="secondary" style={{ display: 'block', fontSize: 11.5, marginTop: 2 }}>{s.sources.join(' · ')}</Text>
          {focus && !removed ? <Text type="secondary" style={{ display: 'block', fontSize: 11.5 }}>Done when: {s.check}</Text> : null}
          {s.trace?.length || s.state === 'running' ? <div onClick={(e) => e.stopPropagation()}><AgentLog key={`${s.id}-${s.state}`} step={s} defaultOpen={s.state === 'running'} /></div> : null}
        </div>
      </Flex>
    </div>
  )
}

export function ApproachTab({ g, v, onFocus, say }: { g: Goal; v: GoalView; onFocus: (id: string) => void; say: Say }) {
  if (!g.plan.length) return <div className="gw-empty"><LoadingOutlined /> {g.agent.name} is reading the goal and drafting its approach.</div>
  let n = 0
  const line = g.status === 'plan-review' ? 'Proposed. Click a step to see it; change it in the conversation.'
    : g.status === 'armed' ? (g.trigger === 'rule' ? 'Approved and saved with the rule. Runs by itself when the rule fires.' : 'Approved. Runs by itself on the schedule.')
    : g.status === 'analysing' ? 'Running.'
    : g.planApproved ? `Approved by ${g.planApproved.by}, ${fmtDate(g.planApproved.at)}.` : ''
  const live = g.plan.some((s) => s.state !== 'removed')
  return (
    <Flex vertical gap={SP.sm}>
      <Flex justify="space-between" align="center" gap={SP.sm} wrap>
        <Text type="secondary" style={{ fontSize: 12.5 }}>{line}</Text>
        <Space size={SP.xs}>
          {g.status === 'plan-review' ? <Button size="small" type="primary" disabled={!live} onClick={() => say(g.trigger === 'rule' ? 'Approve and save the approach' : 'Approve the approach')}>{g.trigger === 'rule' ? 'Approve and save' : 'Approve'}</Button> : null}
          {g.status === 'armed' && g.trigger === 'schedule' ? <Button size="small" type="primary" icon={<ThunderboltOutlined />} onClick={() => say('Simulate: run now')}>Simulate: run now</Button> : null}
          {g.status === 'armed' || g.status === 'findings-ready' || g.status === 'accepted' ? <Button size="small" onClick={() => say('Change the approach')}>Change</Button> : null}
          {g.status !== 'analysing' ? <Button size="small" icon={<SaveOutlined />} onClick={() => say('Save it for reuse')}>Save for reuse</Button> : null}
        </Space>
      </Flex>
      {g.plan.map((s) => {
        if (s.state !== 'removed') n += 1
        return <StepCard key={s.id} s={s} n={n} focus={v.step === s.id} colour={g.agent.colour} onFocus={() => onFocus(s.id)} />
      })}
    </Flex>
  )
}

export function FindingsTab({ g, v, onFocus, onDrill, say }: { g: Goal; v: GoalView; onFocus: (id: string) => void; onDrill: (d: Drill) => void; say: Say }) {
  const focusRef = useRef<HTMLDivElement>(null)
  useEffect(() => { focusRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }) }, [v.finding])
  if (!g.findings.length) {
    return <div className="gw-empty">{g.status === 'analysing' ? 'Being written while the approach runs.' : g.status === 'needs-input' ? 'Written once you answer the question in the chat.' : g.status === 'armed' ? 'Land here when the trigger runs the approach.' : 'Land here once the approach has run.'}</div>
  }
  const accepted = new Set(g.acceptedFindings ?? [])
  const allIn = g.findings.every((f) => accepted.has(f.id))
  return (
    <Flex vertical gap={SP.sm}>
      <Flex justify="space-between" align="center">
        <Text type="secondary" style={{ fontSize: 12.5 }}>Click a finding to open it. Numbers and evidence open the data.</Text>
        {allIn ? <Tag color="success" icon={<CheckCircleOutlined />} style={{ marginInlineEnd: 0 }}>All accepted</Tag> : <Button size="small" onClick={() => say('Accept all findings')}>Accept all</Button>}
      </Flex>
      {g.findings.map((f, i) => {
        const on = v.finding === f.id
        return (
          <div key={f.id} ref={on ? focusRef : undefined} className={`gw-card${on ? ' gw-focus' : ''}`} style={{ ['--agent' as string]: g.agent.colour }} onClick={() => onFocus(f.id)}>
            <Flex gap={SP.sm} align="flex-start">
              <span className={`gw-num${on ? ' is-on' : ''}`}>{i + 1}</span>
              <div style={{ minWidth: 0, flex: 1 }}>
                <Flex justify="space-between" gap={SP.sm}>
                  <Text style={{ fontSize: 13.5, fontWeight: 500 }}>{shortHeadline(f.headline)}</Text>
                  {accepted.has(f.id) ? <Tag color="success" icon={<CheckCircleOutlined />} style={{ marginInlineEnd: 0 }}>Accepted</Tag> : null}
                </Flex>
                {on ? (
                  <>
                    <Text style={{ display: 'block', fontSize: 12.5, marginTop: 4 }}><Linked text={f.headline.slice(shortHeadline(f.headline).length).replace(/^[:.]\s*/, '')} onOpen={() => onDrill(f.drill)} /></Text>
                    <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: 4 }}><Linked text={f.detail} onOpen={() => onDrill(f.drill)} /></Text>
                    <div style={{ marginTop: SP.sm, borderTop: '1px solid #e9ecf1' }}>
                      {f.evidence.map((e, j) => {
                        const d = drillFromEvidence(e, f.drill)
                        return <div key={j} onClick={(ev) => ev.stopPropagation()}><EvidenceLine e={e} onOpen={d ? () => onDrill(d) : undefined} /></div>
                      })}
                    </div>
                    <Space size={SP.xs} style={{ marginTop: SP.sm }} onClick={(e) => e.stopPropagation()}>
                      <Button size="small" type="primary" ghost icon={<TableOutlined />} onClick={() => onDrill(f.drill)}>Open the data</Button>
                      {!accepted.has(f.id) ? <Button size="small" icon={<CheckOutlined />} onClick={() => say(`Accept ${i + 1}`)}>Accept</Button> : null}
                      <Button size="small" onClick={() => say(`Challenge ${i + 1}`)}>Challenge</Button>
                    </Space>
                  </>
                ) : null}
              </div>
            </Flex>
          </div>
        )
      })}
      {g.gaps.length ? (
        <div style={{ padding: '8px 2px' }}>
          <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.3 }}><WarningOutlined style={{ color: STATUS.warn }} /> Not established</Text>
          <ul className="g-ul" style={{ marginTop: 4, fontSize: 12.5 }}>{g.gaps.map((x) => <li key={x}>{x}</li>)}</ul>
        </div>
      ) : null}
    </Flex>
  )
}

const BEAT_ICON: Record<Beat['kind'], React.ReactNode> = { asked: <QuestionCircleOutlined />, read: <FileSearchOutlined />, found: <BulbOutlined />, compared: <SwapOutlined />, therefore: <CheckCircleOutlined /> }
const BEAT_LABEL: Record<Beat['kind'], string> = { asked: 'Asked', read: 'Read', found: 'Found', compared: 'Compared', therefore: 'Therefore' }

/** The story behind a recommendation, told one beat at a time. */
export function StoryPlayer({ g, r, onDrill }: { g: Goal; r: Recommendation; onDrill: (d: Drill) => void }) {
  const [shown, setShown] = useState(0)
  const [run, setRun] = useState(0)
  const timer = useRef(0)
  /* Plays one beat at a time; "Show all" stops the player, so it cannot step back over what is shown. */
  useEffect(() => {
    setShown(0)
    let i = 0
    const tick = () => { i += 1; setShown(i); if (i < r.story.length) timer.current = window.setTimeout(tick, i === 1 ? 700 : 1300) }
    timer.current = window.setTimeout(tick, 300)
    return () => window.clearTimeout(timer.current)
  }, [r, run])
  const showAll = () => { window.clearTimeout(timer.current); setShown(r.story.length) }
  const done = shown >= r.story.length
  return (
    <div className="st" style={{ marginTop: SP.sm }}>
      <Flex justify="flex-end" style={{ marginBottom: 6 }}>
        {done ? <Button size="small" type="text" icon={<PlayCircleOutlined />} onClick={() => setRun((x) => x + 1)}>Replay</Button> : <Button size="small" type="text" onClick={showAll}>Show all</Button>}
      </Flex>
      <div className="st-bar"><div className="st-bar-fill" style={{ width: `${(Math.min(shown, r.story.length) / r.story.length) * 100}%` }} /></div>
      <div className="st-beats">
        {r.story.slice(0, shown).map((b, i) => {
          const d = drillFromRef(b.ref)
          return (
            <div key={i} className={`st-beat is-${b.kind}`} style={{ ['--agent' as string]: g.agent.colour }}>
              <div className="st-icon">{BEAT_ICON[b.kind]}</div>
              <div className="st-body">
                <Text type="secondary" style={{ fontSize: 10.5, textTransform: 'uppercase', letterSpacing: 0.4 }}>{BEAT_LABEL[b.kind]}</Text>
                <Text style={{ display: 'block', fontSize: b.kind === 'therefore' ? 14 : 13, fontWeight: b.kind === 'therefore' ? 500 : 400 }}>{b.text}</Text>
                <Space size={SP.sm} style={{ marginTop: 4 }}>
                  {b.figure ? <span className="st-figure">{b.figure}</span> : null}
                  {d ? <a style={{ fontSize: 12 }} onClick={() => onDrill(d)}>open the source</a> : null}
                </Space>
              </div>
            </div>
          )
        })}
        {!done ? <div className="st-beat is-pending"><div className="st-icon"><span className="st-pulse" /></div><div className="st-body" /></div> : null}
      </div>
    </div>
  )
}

export function DecisionTab({ g, v, onDrill, say }: { g: Goal; v: GoalView; onDrill: (d: Drill) => void; say: Say }) {
  if (!g.recommendations.length) return <div className="gw-empty">Appears with the findings.</div>
  return (
    <>
      {g.question ? <Text style={{ display: 'block', fontSize: 12.5, color: STATUS.warn, marginBottom: SP.sm }}><WarningOutlined /> Draft until you answer the question in the chat.</Text> : null}
      <Flex vertical gap={SP.sm}>
        {g.recommendations.map((r, i) => {
          const chosen = g.status === 'accepted' && !!r.preferred
          const on = v.story === r.id
          return (
            <div key={r.id} className={`gw-card${on ? ' gw-focus' : ''}`} style={{ ['--agent' as string]: g.agent.colour, cursor: 'default', background: r.preferred ? `${g.agent.colour}08` : undefined, borderColor: r.preferred ? `${g.agent.colour}66` : undefined }}>
              <Flex gap={SP.sm} align="flex-start">
                <span className={`gw-num${on ? ' is-on' : ''}`}>{i + 1}</span>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <Flex justify="space-between" gap={SP.sm}>
                    <Text style={{ fontSize: 13.5, fontWeight: 500 }}>{r.title}</Text>
                    {chosen ? <Tag color="green" style={{ marginInlineEnd: 0 }}>Chosen</Tag> : r.preferred ? <Tag style={{ marginInlineEnd: 0, color: g.agent.colour, borderColor: `${g.agent.colour}55`, background: `${g.agent.colour}12` }}>Preferred</Tag> : null}
                  </Flex>
                  <Flex gap={SP.lg} wrap style={{ marginTop: SP.sm }}>{r.figures.map((f) => <Figure key={f.label} {...f} />)}</Flex>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: SP.sm }}>Trade-off: {r.tradeoff}</Text>
                  <Space size={SP.xs} style={{ marginTop: SP.sm }}>
                    <Button size="small" type="primary" ghost icon={<PlayCircleOutlined />} onClick={() => say(`Why option ${i + 1}?`)}>Why this</Button>
                    <Button size="small" type={r.preferred && !chosen ? 'primary' : 'default'} disabled={chosen} onClick={() => say(`Choose option ${i + 1}`)}>{chosen ? 'Chosen' : 'Choose'}</Button>
                  </Space>
                  {on ? <StoryPlayer g={g} r={r} onDrill={onDrill} /> : null}
                </div>
              </Flex>
            </div>
          )
        })}
      </Flex>
    </>
  )
}

export function SubmissionsTab({ g, say }: { g: Goal; say: Say }) {
  const navigate = useNavigate()
  const templates = useSubmissionStore((s) => s.templates)
  if (!g.findings.length) return <div className="gw-empty">Recommended once the findings are in.</div>
  const offered = g.submissions.filter((s) => templates.some((t) => t.id === s.templateId))
  const notOffered = g.submissions.filter((s) => !templates.some((t) => t.id === s.templateId))
  return (
    <Flex vertical gap={SP.sm}>
      <Flex justify="space-between" align="center">
        <Text type="secondary" style={{ fontSize: 12.5 }}>Based on the templates in your library</Text>
        <Space size={SP.xs}>
          <Button size="small" icon={<PlusOutlined />} onClick={() => say('Describe a new output')}>Describe a new output</Button>
          <Button size="small" type="link" onClick={() => navigate(appPath('/submissions'))}>Submissions page →</Button>
        </Space>
      </Flex>
      {offered.map((s, i) => (
        <div key={s.id} className="gw-card" style={{ cursor: 'default' }}>
          <Flex gap={SP.sm} align="flex-start">
            <span className="gw-num">{i + 1}</span>
            <div style={{ minWidth: 0, flex: 1 }}>
              <Text style={{ fontSize: 13.5, fontWeight: 500 }}>{s.label}</Text>
              <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>To {s.audience}</Text>
              <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>Template: {templates.find((t) => t.id === s.templateId)?.name}</Text>
            </div>
            <Button size="small" type="primary" onClick={() => say(`Start ${i + 1}`)}>Start</Button>
          </Flex>
        </div>
      ))}
      {!offered.length ? <Text type="secondary" style={{ fontSize: 13 }}>None of the templates in your library fits this goal.</Text> : null}
      {notOffered.length ? <Text type="secondary" style={{ fontSize: 12 }}>Not offered, template not in the library: {notOffered.map((s) => s.label).join('; ')}.</Text> : null}
    </Flex>
  )
}


function useAgentChat(g: Goal) {
  const navigate = useNavigate()
  const me = useAuthStore((s) => s.identity?.name) ?? 'You'
  const startSubmission = useSubmissionStore((s) => s.startFromGoal)
  const pending = useRef<null | { k: 'challenge'; n: number }>(null)

  const act = (text: string) => {
    const st = useGoalStore.getState()
    const g0 = st.goals.find((x) => x.id === g.id)
    if (!g0) return
    const v = st.views[g.id] ?? { tab: 'approach' as Tab }
    const say = (t: string) => st.say(g.id, 'agent', t)
    const setView = (x: GoalView) => st.setView(g.id, x)
    const live = g0.plan.filter((s) => s.state !== 'removed')
    const removed = g0.plan.filter((s) => s.state === 'removed')
    const planOpen = g0.status === 'plan-review'
    const findingNo = (id?: string) => g0.findings.findIndex((f) => f.id === id) + 1
    const pref = Math.max(0, g0.recommendations.findIndex((r) => r.preferred)) + 1
    const templates = useSubmissionStore.getState().templates
    const offered = g0.submissions.filter((s) => templates.some((t) => t.id === s.templateId))

    if (pending.current?.k === 'challenge') {
      const n = pending.current.n
      pending.current = null
      st.addLog(g.id, me, `Challenged finding ${n}: ${text}`)
      say(`Noted against finding ${n}. I recheck it on the next run; it stays open until you accept it.`)
      return
    }

    const intent: Intent = interpret(text, g0, v.tab)
    const lockedEdit = () => say(g0.status === 'analysing' ? 'I am running the approach now. Changes wait until the findings land.' : 'The approach is approved and locked. Say "change the approach" to reopen it.')
    const commit = (plan: PlanStep[], focus?: string) => { st.setPlan(g.id, plan, me); setView({ tab: 'approach', step: focus }) }

    switch (intent.k) {
      case 'help': say(helpText(g0)); return
      case 'approve':
        if (!live.length) { say('Every step is removed. Put one back first.'); return }
        st.approvePlan(g.id, me)
        if (g0.trigger === 'rule') window.setTimeout(() => navigate(appPath('/goals'), { state: { justArmed: g.id } }), 2200)
        return
      case 'remove': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}. The approach has ${count(live.length)}.`); return }
        commit(g0.plan.map((x) => (x.id === s.id ? { ...x, state: 'removed', editedBy: me } : x)), s.id)
        say(`Removed: ${s.title}. Say "put back step ${intent.n}" if you change your mind.`)
        return
      }
      case 'restore': {
        if (!planOpen) return lockedEdit()
        const cand = g0.plan[intent.n - 1]?.state === 'removed' ? g0.plan[intent.n - 1] : removed[removed.length - 1]
        if (!cand) { say('Nothing is removed.'); return }
        commit(g0.plan.map((x) => (x.id === cand.id ? { ...x, state: 'pending', editedBy: me } : x)), cand.id)
        say(`Put back: ${cand.title}.`)
        return
      }
      case 'move': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        const to = Math.max(1, Math.min(live.length, intent.to))
        if (!s) { say(`There is no step ${intent.n}.`); return }
        const order = live.filter((x) => x.id !== s.id)
        order.splice(to - 1, 0, s)
        commit([...order, ...removed], s.id)
        say(`Moved. "${s.title}" is now step ${to}.`)
        return
      }
      case 'add': {
        if (!planOpen) return lockedEdit()
        const step = draftStep(intent.text, me)
        const at = intent.after ? Math.min(live.length, intent.after) : live.length
        const order = [...live]
        order.splice(at, 0, step)
        commit([...order, ...removed], step.id)
        say(`Added as step ${at + 1}: **${step.title}**\nReads ${step.sources.join(', ')}. Done when: ${step.check.charAt(0).toLowerCase()}${step.check.slice(1)}${at + 1 < order.length ? '' : `\n\nWant it earlier? Say "move step ${at + 1} up".`}`)
        return
      }
      case 'change': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}.`); return }
        const next = rewordStep(s, intent.text, me)
        commit(g0.plan.map((x) => (x.id === s.id ? next : x)), s.id)
        say(`Step ${intent.n} now reads: **${next.title}**\nReads ${next.sources.join(', ')}.`)
        return
      }
      case 'extend': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}.`); return }
        const next = extendStep(s, intent.text, me)
        commit(g0.plan.map((x) => (x.id === s.id ? next : x)), s.id)
        say(`Step ${intent.n} now covers that too. Sources: ${next.sources.join(', ')}.`)
        return
      }
      case 'explain': {
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}.`); return }
        setView({ tab: 'approach', step: s.id })
        say(`Step ${intent.n} is open on the left. In short: ${s.how.split('. ')[0].replace(/\.$/, '')}.`)
        return
      }
      case 'save': {
        if (!g0.plan.length) { say('Nothing to save yet.'); return }
        const name = intent.name?.trim() || g0.approachName || (g0.title.length > 48 ? `${g0.title.slice(0, 46)}…` : g0.title)
        st.saveApproach(g.id, name, me)
        say(`Saved to your approaches as "${name}". A new goal can start from it.`)
        return
      }
      case 'revise':
        if (g0.status === 'analysing') { say('I am running it now. Wait for the findings, then reopen it.'); return }
        st.revisePlan(g.id, me)
        return
      case 'fire':
        if (g0.trigger === 'rule') {
          say('A rule runs when its condition is met. To simulate it, use "Watching for you" on the Goals page. Taking you there.')
          window.setTimeout(() => navigate(appPath('/goals'), { state: { justArmed: g.id } }), 1600)
          return
        }
        st.fire(g.id, 'Agent')
        return
      case 'status': {
        if (g0.status === 'analysing') {
          const i = g0.plan.filter((s) => s.state !== 'removed').findIndex((s) => s.state === 'running')
          const s = live[i]
          const last = s?.trace?.[s.trace.length - 1]
          setView({ tab: 'approach', step: s?.id })
          say(s ? `Step ${i + 1} of ${live.length}: ${s.title}.${last ? `\nLast: ${last.split(' → ')[0]}.` : ''}` : 'Finishing up.')
          return
        }
        say(g0.status === 'plan-review' ? 'Waiting for your go on the approach.' : g0.status === 'armed' ? `Armed. ${g0.trigger === 'rule' ? 'Waiting for the rule to fire.' : 'Waiting for the next scheduled run.'}` : `${STATUS_LABEL[g0.status]}. ${g0.target.current}.`)
        return
      }
      case 'summary':
        if (!g0.findings.length) { say('No findings yet.'); return }
        setView({ tab: 'findings', finding: v.finding })
        say(findingsSummary(g0))
        return
      case 'finding': {
        const f = g0.findings[intent.n - 1]
        if (!f) { say(`There are ${count(g0.findings.length)} findings.`); return }
        setView({ tab: 'findings', finding: f.id })
        say(`Finding ${intent.n} is open on the left, with ${count(f.evidence.length)} pieces of evidence. Say "show the data" for the rows behind it, or "accept ${intent.n}".`)
        return
      }
      case 'drill': {
        const n = intent.n ?? (findingNo(v.finding) || 1)
        const f = g0.findings[n - 1]
        if (!f) { setView({ tab: 'data' }); say('The worksheet is on the left.'); return }
        setView({ tab: 'data', drill: f.drill, finding: f.id })
        say(`The data behind finding ${n} is on the left. ${f.drill.note}`)
        return
      }
      case 'accept': {
        const ids = intent.ns === 'all' ? g0.findings.map((f) => f.id) : intent.ns.map((n) => g0.findings[n - 1]?.id).filter(Boolean) as string[]
        if (!ids.length) { say('Which finding? Say "accept 2" or "accept all".'); return }
        st.acceptFindings(g.id, ids, me)
        setView({ tab: 'findings', finding: v.finding })
        const all = new Set([...(g0.acceptedFindings ?? []), ...ids]).size === g0.findings.length
        const nextOpen = g0.findings.findIndex((f) => !new Set([...(g0.acceptedFindings ?? []), ...ids]).has(f.id)) + 1
        say(all
          ? `${intent.ns === 'all' ? 'All findings' : `Finding${ids.length > 1 ? 's' : ''} ${ids.map(findingNo).join(' and ')}`} accepted${intent.ns !== 'all' ? '; that is all of them' : ''}.\n\nWhere next? I can open the data behind them, or take you to the decision: ${count(g0.recommendations.length)} ways forward, and I prefer option ${pref}.`
          : `Finding${ids.length > 1 ? 's' : ''} ${ids.map(findingNo).join(' and ')} accepted. Next: finding ${nextOpen}, or accept the rest.`)
        return
      }
      case 'challenge':
        if (!g0.findings[intent.n - 1]) { say(`There is no finding ${intent.n}.`); return }
        setView({ tab: 'findings', finding: g0.findings[intent.n - 1].id })
        if (!intent.text.trim()) { pending.current = { k: 'challenge', n: intent.n }; say(`What is wrong with finding ${intent.n}? One sentence is enough.`); return }
        st.addLog(g.id, me, `Challenged finding ${intent.n}: ${intent.text}`)
        say(`Noted against finding ${intent.n}. I recheck it on the next run; it stays open until you accept it.`)
        return
      case 'recs':
        if (!g0.recommendations.length) { say('No recommendations yet.'); return }
        setView({ tab: 'decision' })
        say(`${count(g0.recommendations.length).replace(/^./, (c) => c.toUpperCase())} ways forward, on the left:\n${g0.recommendations.map((r, i) => `${i + 1}. ${shortRec(r)}`).join('\n')}\n\nI prefer option ${pref}. Ask "why option ${pref}?" or say "choose option ${pref}".`)
        return
      case 'why': {
        const n = intent.n && g0.recommendations[intent.n - 1] ? intent.n : pref
        const r = g0.recommendations[n - 1]
        if (!r) { say('No recommendations yet.'); return }
        setView({ tab: 'decision', story: r.id })
        say(`Playing how I got to option ${n} on the left: what I asked, read, found and compared.`)
        return
      }
      case 'choose': {
        if (g0.question) { say(`Answer my question first: ${g0.question}`); return }
        const n = intent.n && g0.recommendations[intent.n - 1] ? intent.n : pref
        const r = g0.recommendations[n - 1]
        if (!r) { say('No recommendations yet.'); return }
        st.choose(g.id, r.id, me)
        setView({ tab: 'decision', story: v.story })
        say(`Recorded: option ${n}. ${offered.length ? `I can draft ${count(offered.length)} submission${offered.length === 1 ? '' : 's'} from your templates. Ask "what should I send?"` : ''}`.trim())
        return
      }
      case 'subs':
        if (!g0.findings.length) { say('Submissions come once the findings are in.'); return }
        setView({ tab: 'submissions' })
        say(offered.length ? `Based on the templates in your library:\n${offered.map((s, i) => `${i + 1}. ${s.label}`).join('\n')}\n\nSay "start 1", or "describe a new output" if none fits.` : 'None of your templates fits this goal. Say "describe a new output" and I will propose a structure.')
        return
      case 'startSub': {
        if (!offered.length) { say('No template in your library fits. Say "describe a new output".'); return }
        const words = (intent.words ?? '').toLowerCase().split(/\W+/).filter((w) => w.length > 3)
        const byWords = words.length ? offered.map((s) => ({ s, score: words.filter((w) => s.label.toLowerCase().includes(w)).length })).sort((a, b) => b.score - a.score)[0] : undefined
        const s = intent.n ? offered[intent.n - 1] : byWords?.score ? byWords.s : offered[0]
        if (!s) { say(`There ${offered.length === 1 ? 'is one' : `are ${count(offered.length)}`} to choose from.`); return }
        const t = templates.find((x) => x.id === s.templateId)
        const id = startSubmission(g0, s, me)
        st.addLog(g.id, me, `Started the submission "${s.label}" from ${g0.agent.name}'s recommendation (template "${t?.name}").`)
        say(`Opening "${s.label}" in Submissions, with this goal attached.`)
        window.setTimeout(() => navigate(appPath(`/submissions/${id}`)), 700)
        return
      }
      case 'describe':
        say('Opening Submissions to describe a new output for this goal.')
        window.setTimeout(() => navigate(appPath('/submissions/new'), { state: { newFromGoal: g0.id, describe: true } }), 700)
        return
      case 'pack':
        downloadPack(g0, STATUS_LABEL[g0.status], TRIGGER_LABEL[g0.trigger])
        st.addLog(g.id, me, 'Downloaded the analysis pack.')
        say('Downloaded the analysis pack: one HTML file with the findings, the evidence and the tables behind them.')
        return
      case 'info':
        st.addLog(g.id, me, `Added information: ${intent.text}`)
        say('Added to the goal. I use it on the next run.')
        return
      case 'tab':
        setView({ tab: intent.tab })
        say('On the left.')
        return
      default:
        if (g0.question) {
          st.answer(g.id, me, text)
          say(g0.findings.length ? 'Thanks. The recommendation stands with your answer taken into account.' : 'Thanks, noted. This goal has no recorded analysis behind it in this copy, so there are no findings to write. The two example goals carry full ones.')
          return
        }
        if (g0.status === 'analysing') { say('I am running the approach. Ask "where are you?", or wait for the findings.'); return }
        say(`I did not catch that. ${helpText(g0)}`)
    }
  }

  const send = (text: string) => {
    const st = useGoalStore.getState()
    st.say(g.id, 'me', text)
    st.setTyping(g.id, true)
    window.setTimeout(() => {
      useGoalStore.getState().setTyping(g.id, false)
      act(text)
    }, 450 + Math.random() * 450)
  }
  return send
}

/* ------------------------------------------------------------------ the workspace */

export default function GoalWorkspace({ g }: { g: Goal }) {
  const navigate = useNavigate()
  const chat = useGoalStore((s) => s.chats[g.id]) ?? []
  const typing = useGoalStore((s) => !!s.typing[g.id])
  const v = useGoalStore((s) => s.views[g.id]) ?? { tab: 'approach' as Tab }
  const setView = useGoalStore((s) => s.setView)
  const send = useAgentChat(g)
  const [drawer, setDrawer] = useState<Drill | null>(null)
  const me = useAuthStore((st) => st.identity?.name) ?? 'You'
  /* A file dropped into the goal's chat: read it, keep it on the goal, and say what it holds. */
  const upload = async (file: File) => {
    const st = useGoalStore.getState()
    st.say(g.id, 'me', 'Here is a file for this goal.', { name: file.name, size: file.size })
    st.setTyping(g.id, true)
    const r = await readUpload(file)
    window.setTimeout(() => {
      const s2 = useGoalStore.getState()
      s2.setTyping(g.id, false)
      s2.attach(g.id, { name: r.name, size: r.size, read: describeRead(r), problem: r.problem }, me)
      s2.setView(g.id, { tab: 'target' })
      s2.say(g.id, 'agent', `Read ${r.name}: ${describeRead(r)}.${r.problem ? `\n\nWhat it says: "${r.problem}"` : ''}\n\nIt is on the Goal tab and I read it on every run from now on. Anything in it I should treat as fixed?`)
    }, 900)
  }
  const live = g.plan.filter((s) => s.state !== 'removed')
  const focus = { step: v.step ? live.findIndex((s) => s.id === v.step) + 1 || undefined : undefined, finding: v.finding ? g.findings.findIndex((f) => f.id === v.finding) + 1 || undefined : undefined }
  const chips = suggestions(g, v.tab, g.agent.name.replace(/^Agent /, ''), { step: v.tab === 'approach' ? focus.step : undefined, finding: v.tab === 'findings' ? focus.finding : undefined })
  /* Data opened from the screen slides in from the right, over the chat, as it did before. */
  const openData = (d: Drill) => setDrawer(d)

  const items: { key: Tab; label: string; children: React.ReactNode }[] = [
    { key: 'target', label: 'Goal', children: <GoalTab g={g} /> },
    { key: 'approach', label: 'Approach', children: <ApproachTab g={g} v={v} say={send} onFocus={(id) => setView(g.id, { tab: 'approach', step: v.step === id ? undefined : id })} /> },
    { key: 'findings', label: `Findings${g.findings.length ? ` · ${g.findings.length}` : ''}`, children: <FindingsTab g={g} v={v} say={send} onFocus={(id) => setView(g.id, { tab: 'findings', finding: id })} onDrill={openData} /> },
    { key: 'data', label: 'Data', children: <DataExplorer key={JSON.stringify(v.drill ?? null)} start={v.drill ?? { view: g.findings[0]?.drill.project ? 'snapshots' : 'portfolio', project: g.findings[0]?.drill.project, note: '' }} height={Math.max(420, window.innerHeight - 250)} /> },
    { key: 'decision', label: 'Decision', children: <DecisionTab g={g} v={v} say={send} onDrill={openData} /> },
    { key: 'submissions', label: 'Submissions', children: <SubmissionsTab g={g} say={send} /> },
    { key: 'log', label: 'Log', children: <Timeline style={{ paddingTop: 6 }} items={[...g.log].reverse().map((l) => ({ color: l.who === g.agent.name ? g.agent.colour : /^(Rule|Schedule)/.test(l.who) ? STATUS.warn : 'gray', children: <div><Text type="secondary" style={{ fontSize: 11.5 }}>{fmtDate(l.at)} · {l.who}</Text><Text style={{ display: 'block', fontSize: 12.5 }}>{l.what}</Text></div> }))} /> },
  ]

  return (
    <>
    <TwoPane left={(
      <div className="gw-work">
        <div className="gw-head">
          <span className="gw-back" role="link" onClick={() => navigate(appPath('/goals'))}>← Goals</span>
          <div className="gw-title">{g.title}</div>
          <Flex gap={SP.sm} align="center" wrap>
            <AgentBadge agent={g.agent} />
            <StatusTag status={g.status} />
            <TriggerTag trigger={g.trigger} />
            <Text type="secondary" style={{ fontSize: 12 }}>{g.owner}</Text>
          </Flex>
          <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: 4 }}>Target: {g.target.target}</Text>
        </div>
        <Tabs className="gw-tabs" activeKey={v.tab} onChange={(k) => setView(g.id, { tab: k as Tab, finding: v.finding, drill: v.drill, story: v.story, step: v.step })} items={items} size="small" />
      </div>
    )} right={(
        <ChatPane agent={g.agent} messages={chat} typing={typing} chips={chips} onSend={send} onUpload={upload} />
    )} />
      <Drawer open={!!drawer} onClose={() => setDrawer(null)} width="min(1280px, 94vw)" title="The data behind it" destroyOnHidden styles={{ body: { padding: SP.base } }}>
        {drawer ? <DataExplorer start={drawer} height={Math.max(360, window.innerHeight - 150)} /> : null}
      </Drawer>
    </>
  )
}
