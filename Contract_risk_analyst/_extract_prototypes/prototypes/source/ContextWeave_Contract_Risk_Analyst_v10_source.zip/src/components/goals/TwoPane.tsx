import { ColumnWidthOutlined, CompressOutlined, ExpandOutlined } from '@ant-design/icons'
import { Tooltip } from 'antd'
import { useEffect, useRef, type ReactNode } from 'react'
import { create } from 'zustand'

/*
 * The working pane on the left and the chat on the right, with the split under the analyst's control:
 * drag the bar between them, or use the buttons in the chat header to widen the chat, give it the whole
 * width, or put it back. The split is remembered while the page is open and shared by goals and submissions.
 */

type Mode = 'normal' | 'wide' | 'full'
const usePane = create<{ width: number; mode: Mode; set: (p: Partial<{ width: number; mode: Mode }>) => void }>((set) => ({ width: 400, mode: 'normal', set: (p) => set(p) }))

export function PaneControls() {
  const { mode, set } = usePane()
  return (
    <span className="tp-ctl">
      {mode !== 'wide' ? <Tooltip title="Widen the chat"><span role="button" tabIndex={0} aria-label="Widen the chat" onClick={() => set({ mode: 'wide' })}><ColumnWidthOutlined /></span></Tooltip> : null}
      {mode !== 'full' ? <Tooltip title="Chat only: hide the working pane"><span role="button" tabIndex={0} aria-label="Chat only" onClick={() => set({ mode: 'full' })}><ExpandOutlined /></span></Tooltip> : null}
      {mode !== 'normal' ? <Tooltip title="Back to the normal split"><span role="button" tabIndex={0} aria-label="Normal split" onClick={() => set({ mode: 'normal', width: 400 })}><CompressOutlined /></span></Tooltip> : null}
    </span>
  )
}

export default function TwoPane({ left, right }: { left: ReactNode; right: ReactNode }) {
  const { width, mode, set } = usePane()
  const box = useRef<HTMLDivElement>(null)
  const drag = useRef<{ x: number; w: number } | null>(null)
  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (!drag.current || !box.current) return
      const total = box.current.getBoundingClientRect().width
      const w = Math.min(total - 280, Math.max(320, drag.current.w + (drag.current.x - e.clientX)))
      set({ width: w, mode: 'normal' })
    }
    const up = () => { drag.current = null; document.body.classList.remove('tp-dragging') }
    window.addEventListener('mousemove', move)
    window.addEventListener('mouseup', up)
    return () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up) }
  }, [set])
  const cols = mode === 'full' ? '0px 0px minmax(0, 1fr)' : mode === 'wide' ? 'minmax(280px, 0.8fr) 10px minmax(0, 1.2fr)' : `minmax(280px, 1fr) 10px ${width}px`
  return (
    <div ref={box} className={`gw tp is-${mode}`} style={{ gridTemplateColumns: cols }}>
      <div className="tp-left">{left}</div>
      <div className="tp-bar" role="separator" aria-orientation="vertical" title="Drag to resize" onMouseDown={(e) => { drag.current = { x: e.clientX, w: box.current ? (box.current.lastElementChild as HTMLElement).getBoundingClientRect().width : width }; document.body.classList.add('tp-dragging'); e.preventDefault() }} />
      {right}
    </div>
  )
}
