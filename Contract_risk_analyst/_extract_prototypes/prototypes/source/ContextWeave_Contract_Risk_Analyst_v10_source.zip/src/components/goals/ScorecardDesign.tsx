/*
 * The plan of the contract risk watch (version 4, 17 November 2026).
 *
 * It appears only after the template question is answered, and after the analyst has drafted it.
 * No template: ONE scorecard. What we control, what we do not control and what is at stake, every factor with
 *   its share of the final score, every signal with its weight and the rule for 1, 2, 3 and 4.
 * A template: the template played back as written, then what it does not have, each area added with one switch.
 * Either way you can drop a signal, add one to a factor with its own rule, or add a factor.
 * Then the data check (where each figure sits, how it is measured, the assumptions to confirm), the views of
 * the dashboard, and mitigation and rules. The goal stays editable after it is live: a change is published as
 * a new version of the dashboard.
 */
import { CheckOutlined, DownOutlined, EditOutlined, FileTextOutlined, FlagFilled, FlagOutlined, FundProjectionScreenOutlined, GlobalOutlined, MailOutlined, PlusOutlined, RightOutlined, TableOutlined } from '@ant-design/icons'
import { Button, Input, Switch } from 'antd'
import { useEffect, useState } from 'react'
import type { ActionCat } from '../../data/deliverFlow'
import type { Drill } from '../../data/goalCases'
import { ASSUME_KEYS, CONTRACTS, DESIGN, FACTORS, LEVEL_NAME, REG_RULE, histFlagged, histOf, inTemplate, numericSignals, LOST, NOT_FOUND, PANELS, RATING_COLOR, RATING_NAME,  SIGNALS, activeFactors, bandCount, bandsOf, bookShape, checkCounts, coverOf, dataCheck, finalShare, impactOn, likelihoodSignals, lostCaught, priorityOf, rating, score, signalShare, type CheckStatus, type Group, type SignalDef, type SrcKind } from '../../data/risk'
import { design, movedByYou, unpublished, useDesign, useDesignV } from '../../store/designStore'
import { useJourney, type Journey } from '../../store/journeyStore'
import './ScorecardDesign.css'

const SRC_ICON: Record<SrcKind, JSX.Element> = { table: <TableOutlined />, document: <FileTextOutlined />, mail: <MailOutlined />, web: <GlobalOutlined /> }
const SRC_WORD: Record<SrcKind, string> = { table: 'Data', document: 'Document', mail: 'Mail', web: 'Web' }
const pct = (x: number) => `${Math.round(x * 100)}%`
export const WHEN_OPTIONS = ['A score goes up', 'A rating goes up', 'A signal reaches 3 or 4', 'A contract becomes "Act now"', 'A plan action is 7 days late', 'Every Monday', 'After every check']
const STATUS: Record<CheckStatus, { t: string; c: string }> = { ready: { t: 'Ready', c: 'ok' }, assume: { t: 'Ready, on an assumption', c: 'as' }, partly: { t: 'Partly', c: 'pt' }, missing: { t: 'Not found', c: 'no' } }

/** The preview: what the scorecard, as it stands now, says about the portfolio. */
export function DesignPreview() {
  useDesignV()
  const dist = [0, 0, 0, 0, 0]
  let act = 0
  for (const c of CONTRACTS) { dist[rating(c, DESIGN.rule, 'before')] += 1; if (priorityOf(c, 'before') === 'Act now') act += 1 }
  const mv = movedByYou(), caught = lostCaught()
  return (
    <div className="sdz-prev" data-testid="sdz-preview">
      <div className="sdz-prev-h"><b>Your {CONTRACTS.length} projects on this {DESIGN.source === 'uploaded' ? 'template' : 'scorecard'}, one score each</b><span data-testid="sdz-counts">{activeFactors().length} factors · {likelihoodSignals().length} signals</span></div>
      <div className="sdz-bar" role="img" aria-label="Projects by rating">{[1, 2, 3, 4].map((r) => dist[r] ? <span key={r} style={{ flex: dist[r], background: RATING_COLOR[r] }} /> : null)}</div>
      <div className="sdz-dist">{[1, 2, 3, 4].map((r) => <span key={r}><i style={{ background: RATING_COLOR[r] }} /><b data-testid={`sdz-n${r}`}>{dist[r]}</b> {RATING_NAME[r].toLowerCase()}</span>)}</div>
      <div className="sdz-facts">
        {impactOn() ? <span><b data-testid="sdz-act">{act}</b> high risk with a lot at stake</span> : null}
        <span className={caught === LOST.length ? 'is-good' : 'is-warn'}><b data-testid="sdz-caught">{caught} of {LOST.length}</b> contracts already lost would have rated 3 or more a year before</span>
        {mv.up + mv.down ? <span data-testid="sdz-moved">Your changes move <b>{mv.up + mv.down}</b> projects: {mv.up} up, {mv.down} down</span> : null}
      </div>
    </div>
  )
}

function Stepper({ label, value, onDown, onUp, off, id }: { label: string; value: string; onDown: () => void; onUp: () => void; off?: boolean; id?: string }) {
  return <span className="sdz-step" aria-label={label} data-testid={id}><button type="button" aria-label={`${label}: less`} disabled={off} onClick={(e) => { e.stopPropagation(); onDown() }}>−</button><b>{value}</b><button type="button" aria-label={`${label}: more`} disabled={off} onClick={(e) => { e.stopPropagation(); onUp() }}>+</button></span>
}

const fig = (x: number) => (Math.abs(x) >= 1000 ? Math.round(x).toLocaleString('en-US') : String(Math.round(x * 100) / 100))
/*
 * What three years of your own figures say about a rule: how the projects are spread (one bar per range, in the
 * colour of the score it gets today), where the thresholds sit (solid) and where history would put them (dashed).
 */
function History({ s, canEdit }: { s: SignalDef; canEdit: boolean }) {
  const h = histOf(s), w0 = histOf(s, true)
  if (!h || !w0) return null
  const W = 520, H = 118, L = 8, R = 8, T = 16, B = 20, max = Math.max(...h.bins.map((b) => b.n)), map = DESIGN.map[s.id] ?? [1, 2, 3, 4]
  const X = (v: number) => L + ((v - h.lo) / (h.hi - h.lo || 1)) * (W - L - R), bw = (W - L - R) / h.bins.length
  const same = h.rec.every((x, i) => x === h.cur[i]), top = Math.round(w0.top * 100), pc = h.shares.map((x) => Math.round(x * 100))
  const inside = (v: number) => v >= h.lo && v <= h.hi
  return (
    <div className="sdz-hist" data-testid={`sdz-hist-${s.id}`}>
      <div className="sdz-hist-h"><b>Your history</b><span>{h.n} projects, last three years. Half of them are at {fig(h.median)} {h.unit} or {h.up ? 'lower' : 'higher'}.</span></div>
      <svg viewBox={`0 0 ${W} ${H}`} className="sdz-hist-svg" role="img" aria-label={`How ${h.n} projects are spread on ${s.name}. ${pc[0]}% score 1, ${pc[1]}% score 2, ${pc[2]}% score 3, ${pc[3]}% score 4.`}>
        {h.bins.map((b, i) => { const hh = max ? (b.n / max) * (H - T - B) : 0; return <rect key={i} x={L + i * bw + 1} y={H - B - hh} width={Math.max(1, bw - 2)} height={hh} rx="2" fill={RATING_COLOR[map[b.band - 1]]} opacity="0.8"><title>{`${fig(b.x0)} to ${fig(b.x1)} ${h.unit}: ${b.n} projects, score ${map[b.band - 1]} today`}</title></rect> })}
        <line x1={L} x2={W - R} y1={H - B} y2={H - B} stroke="#cfd6e2" />
        <text x={L} y={H - 6} className="sdz-hist-t">{fig(h.lo)}</text><text x={W - R} y={H - 6} textAnchor="end" className="sdz-hist-t">{fig(h.hi)} {h.unit}</text>
        {h.cur.filter(inside).map((c, i) => <g key={`c${i}`}><line x1={X(c)} x2={X(c)} y1={T - 3} y2={H - B} stroke="#18212f" strokeWidth="1.5" /><text x={X(c)} y={T - 6} textAnchor="middle" className="sdz-hist-c">{fig(c)}</text></g>)}
        {!same && !h.reg ? h.rec.filter(inside).map((c, i) => <g key={`r${i}`}><line x1={X(c)} x2={X(c)} y1={T + 8} y2={H - B} stroke="#1f5fbf" strokeWidth="1.5" strokeDasharray="4 3" /><text x={X(c)} y={H - 6} textAnchor="middle" className="sdz-hist-r">{fig(c)}</text></g>) : null}
      </svg>
      <div className="sdz-hist-key"><span><i className="is-cur" /> Thresholds now</span>{!same && !h.reg ? <span><i className="is-rec" /> From history</span> : null}<span>On the rule now: {pc[0]}% score 1, {pc[1]}% score 2, {pc[2]}% score 3, {pc[3]}% score 4</span></div>
      <p className="sdz-hist-say">
        {h.reg ? 'This rule follows a regulatory or permit limit, so history does not move it. I leave it as written.'
          : same ? <>These thresholds are the ones your history gives: the better half of the projects scores 1 and the worst 5% score 4. {DESIGN.cuts[s.id] && canEdit ? <a data-testid={`sdz-hist-back-${s.id}`} onClick={() => design.written(s.id)}>Go back to the rule as written</a> : null}</>
          : w0.flagged && !DESIGN.cuts[s.id] ? <><b>The rule as written puts {top}% of the projects in one score, so it tells sites apart poorly.</b> From the history I would cut at {h.rec.map(fig).join(', ')}: the better half scores 1, the next 30% score 2, the next 15% score 3 and the worst 5% score 4.</>
          : <>The rule spreads your projects well enough. From the history alone the cuts would be {h.rec.map(fig).join(', ')}.</>}
      </p>
      {!h.reg && !same && canEdit ? <Button size="small" type={w0.flagged && !DESIGN.cuts[s.id] ? 'primary' : 'default'} data-testid={`sdz-hist-use-${s.id}`} onClick={() => design.hist(s.id)}>Use the thresholds from history</Button> : null}
    </div>
  )
}

/** One case of the rule, as a line you can rewrite. Saved when you leave the field or press Enter. */
function BandText({ s, b, text, canEdit, onSaved }: { s: SignalDef; b: number; text: string; canEdit: boolean; onSaved: (moved: boolean) => void }) {
  const [v, setV] = useState(text)
  useEffect(() => setV(text), [text])
  const commit = () => { const t = v.trim(); if (t === text) return; if (!t && text) { setV(text); return } const r = design.text(s.id, b, t); if (r.changed) onSaved(r.moved) }
  return <input className="sdz-band-t" value={v} disabled={!canEdit} placeholder="Not used. Write when it scores this to use it" aria-label={`When ${s.name} scores ${b}`} data-testid={`sdz-bt-${s.id}-${b}`} onChange={(e) => setV(e.target.value)} onBlur={commit} onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') setV(text) }} />
}

/** The rule for 1 to 4 of one signal, every part editable: the wording of each case, the score it gives, and the thresholds. */
function Bands({ s, canEdit }: { s: SignalDef; canEdit: boolean }) {
  const texts = bandsOf(s), n = bandCount(s.id), cuts = DESIGN.cuts[s.id] ?? s.num?.cuts, map = DESIGN.map[s.id] ?? [1, 2, 3, 4]
  const [saved, setSaved] = useState('')
  return (
    <div className="sdz-bands" data-testid={`sdz-bands-${s.id}`}>
      <div className="sdz-bands-h"><span>Scores</span><span>When (click the wording to change it)</span><span>Projects today</span></div>
      {[1, 2, 3, 4].map((b) => (
        <div key={b} className={`sdz-band${texts[b - 1] ? '' : ' is-empty'}`}>
          <select aria-label={`Score for case ${b}`} value={map[b - 1]} disabled={!canEdit} onChange={(e) => design.map(s.id, b, Number(e.target.value))} style={{ color: RATING_COLOR[map[b - 1]] }}>{[1, 2, 3, 4].map((x) => <option key={x} value={x}>{x}</option>)}</select>
          <BandText s={s} b={b} text={texts[b - 1] ?? ''} canEdit={canEdit} onSaved={(moved) => setSaved(moved ? 'Saved. The threshold moved with your wording, and the projects are sorted again.' : s.num ? 'Saved.' : 'Saved. From the next check every project is read against the new wording.')} />
          <b>{n[b - 1]}</b>
        </div>
      ))}
      {saved ? <small className="sdz-note is-saved" data-testid={`sdz-bt-saved-${s.id}`}>{saved}</small> : null}
      {s.num ? <History s={s} canEdit={canEdit} /> : null}
      {s.num && cuts ? <div className="sdz-cuts"><span>Thresholds ({s.num.unit})</span>{cuts.map((c, i) => <input key={i} type="number" aria-label={`Threshold ${i + 1}`} data-testid={`sdz-cut-${s.id}-${i}`} value={c} disabled={!canEdit} step={Math.abs(cuts[1] - cuts[0]) < 3 ? 0.1 : 1} onChange={(e) => { const v = Number(e.target.value); if (!Number.isNaN(v)) design.cuts(s.id, i, v) }} />)}<small>{s.num.dir === 'up' ? 'Higher is worse.' : 'Lower is worse.'} Change a figure here or in the wording above. The projects are sorted again.</small></div> : <small className="sdz-note">Rewrite any case above, or change the score it gives on the left.</small>}
    </div>
  )
}

const BAND_PH = ['Scores 1 when… (good)', 'Scores 2 when…', 'Scores 3 when…', 'Scores 4 when… (bad)']

/** One line of the scorecard: the signal, the rule for 1 to 4 written out, its weight in the factor, and Drop. */
function SheetRow({ s, canEdit, onOpen }: { s: SignalDef; canEdit: boolean; onOpen: (d: Drill) => void }) {
  const [open, setOpen] = useState(false)
  const on = !!DESIGN.on[s.id], flag = !!DESIGN.flag[s.id], miss = NOT_FOUND[s.id], texts = bandsOf(s), map = DESIGN.map[s.id] ?? [1, 2, 3, 4]
  return (
    <div className={`sdz-sig${on ? '' : ' is-off'}${open ? ' is-open' : ''}`} data-signal={s.id}>
      <div className="sdz-sig-row">
        <button type="button" className="sdz-sig-name" onClick={() => setOpen(!open)} aria-expanded={open}>
          <span><b>{s.name}</b>{DESIGN.custom.includes(s.id) ? <em className="is-yours">Yours</em> : null}{miss ? <em className="is-miss">No source found</em> : !on ? <em className="is-drop">Dropped</em> : null}</span>
          <span className="sdz-rule4">{[1, 2, 3, 4].map((b) => texts[b - 1] ? <i key={b}><u style={{ background: RATING_COLOR[map[b - 1]] }}>{map[b - 1]}</u>{texts[b - 1]}</i> : null)}</span>
        </button>
        <button type="button" className={`sdz-flag${flag ? ' is-on' : ''}`} disabled={!canEdit || !on} title={flag ? 'Red flag: at its worst band, the project rates at least 3' : 'Make it a red flag'} aria-label={`Red flag: ${s.name}`} aria-pressed={flag} onClick={() => design.flag(s.id)}>{flag ? <FlagFilled /> : <FlagOutlined />}</button>
        <Stepper label={`Weight of ${s.name}`} id={`sdz-sw-${s.id}`} value={on ? pct(signalShare(s.id)) : 'off'} off={!canEdit || !on} onDown={() => design.signalWeight(s.id, -1)} onUp={() => design.signalWeight(s.id, 1)} />
        <button type="button" className={`sdz-drop${on ? '' : ' is-back'}`} data-testid={`sdz-drop-${s.id}`} disabled={!canEdit || !!miss} aria-label={`${on ? 'Drop' : 'Put back'} ${s.name}`} onClick={() => design.on(s.id, !on)}>{on ? 'Drop' : 'Put back'}</button>
        <button type="button" className={`sdz-more sdz-edit${open ? ' is-open' : ''}`} data-testid={`sdz-edit-${s.id}`} aria-label={`${open ? 'Close' : 'Edit the rule of'} ${s.name}`} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? 'Close' : <><EditOutlined /> Edit</>}</button>
      </div>
      {open ? (
        <div className="sdz-sig-body">
          <Bands s={s} canEdit={canEdit && on} />
          {miss ? <p className="sdz-why"><b>No source:</b> {miss}</p> : null}
          {s.why ? <p className="sdz-why"><b>Why:</b> {s.why}</p> : null}
          <p className="sdz-src"><b>Measured as:</b> {s.src.how}.</p>
          <p className="sdz-src"><b>Read from ({SRC_WORD[s.src.kind].toLowerCase()}):</b> {SRC_ICON[s.src.kind]} {s.src.name}. <a onClick={() => onOpen({ view: 'signals', note: '' })}>Open the sources</a></p>
        </div>
      ) : null}
    </div>
  )
}

/** A signal you add to one factor: what to measure, and when it scores 1, 2, 3 and 4. */
function AddSignal({ fid, startOpen }: { fid: string; startOpen?: boolean }) {
  const f = FACTORS.find((x) => x.id === fid)!
  const [open, setOpen] = useState(!!startOpen)
  const [name, setName] = useState('')
  const [b, setB] = useState(['', '', '', ''])
  const [said, setSaid] = useState('')
  const add = () => {
    const t = name.trim(); if (t.length < 4) return
    const own = b.some((x) => x.trim())
    const sig = design.custom(t, fid, b)
    setSaid(`Added to ${f.name}. I read it from the ${sig.src.name.toLowerCase()} for all ${CONTRACTS.length} projects. ${own ? 'It scores on the rule you wrote.' : 'You wrote no rule, so I proposed one. Open the signal to change it.'}`)
    setName(''); setB(['', '', '', '']); setOpen(false)
  }
  return (
    <div className="sdz-new" data-newsig={fid}>
      {open ? (
        <div className="sdz-new-form">
          <b>New signal in {f.name}</b>
          <Input size="small" value={name} onChange={(e) => setName(e.target.value)} placeholder="What to measure, e.g. invoices the client pays late" aria-label={`New signal in ${f.name}`} data-testid={`sdz-newsig-name-${fid}`} />
          <div className="sdz-new-b">{[1, 2, 3, 4].map((i) => <label key={i}><u style={{ background: RATING_COLOR[i] }}>{i}</u><input value={b[i - 1]} placeholder={BAND_PH[i - 1]} aria-label={`Rule for ${i}`} data-testid={`sdz-newsig-b${i}-${fid}`} onChange={(e) => setB(b.map((x, k) => (k === i - 1 ? e.target.value : x)))} /></label>)}</div>
          <div className="sdz-new-a"><Button size="small" type="primary" disabled={name.trim().length < 4} onClick={add} data-testid={`sdz-newsig-add-${fid}`}>Add the signal</Button><Button size="small" onClick={() => setOpen(false)}>Cancel</Button><small>Leave the rule empty and I propose one.</small></div>
        </div>
      ) : <button type="button" className="sdz-new-btn" data-testid={`sdz-addsig-${fid}`} onClick={() => { setOpen(true); setSaid('') }}><PlusOutlined /> Add a signal to this factor</button>}
      {said ? <p className="sdz-said" data-testid={`sdz-newsig-said-${fid}`}>{said}</p> : null}
    </div>
  )
}

/** A factor you add to one half of the scorecard. It counts once it has a signal. */
function AddFactor({ g }: { g: 'internal' | 'external' }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const add = () => { const t = name.trim(); if (t.length < 3) return; design.factor(g, t); setName(''); setOpen(false) }
  return open ? (
    <div className="sdz-new-form is-fac" data-newfac={g}>
      <b>New factor in {g === 'internal' ? 'what we control' : 'what we do not control'}</b>
      <div className="sdz-new-row"><Input size="small" value={name} onChange={(e) => setName(e.target.value)} onPressEnter={add} placeholder="Name of the factor, e.g. Energy cost" aria-label="Name of the new factor" data-testid={`sdz-newfac-name-${g}`} /><Button size="small" type="primary" disabled={name.trim().length < 3} onClick={add} data-testid={`sdz-newfac-add-${g}`}>Add the factor</Button><Button size="small" onClick={() => setOpen(false)}>Cancel</Button></div>
      <small>It starts at a weight of 10 and counts once it has a signal. Add its signals next.</small>
    </div>
  ) : <button type="button" className="sdz-new-btn is-fac" data-testid={`sdz-addfac-${g}`} onClick={() => setOpen(true)}><PlusOutlined /> Add a factor</button>
}

function FactorSheet({ fid, canEdit, onOpen, only, startOpen }: { fid: string; canEdit: boolean; onOpen: (d: Drill) => void; only?: (s: SignalDef) => boolean; startOpen?: boolean }) {
  const f = FACTORS.find((x) => x.id === fid)!
  const yours = DESIGN.customF.includes(fid)
  const [open, setOpen] = useState(!!startOpen || yours)
  const ss = SIGNALS.filter((s) => s.f === fid && (!only || only(s))).sort((a, b) => Number(!!DESIGN.on[b.id]) - Number(!!DESIGN.on[a.id]) || a.rank - b.rank), nOn = ss.filter((s) => DESIGN.on[s.id]).length
  if (!ss.length && !yours) return null
  return (
    <div className={`sdz-f${open ? ' is-open' : ''}${nOn ? '' : ' is-off'}`} data-factor={fid}>
      <div className="sdz-f-row" role="button" tabIndex={0} aria-expanded={open} onClick={() => setOpen(!open)} onKeyDown={(e) => { if (e.key === 'Enter') setOpen(!open) }}>
        {open ? <DownOutlined /> : <RightOutlined />}
        <span className="sdz-f-name"><b>{f.name}</b>{yours ? <em className="is-yours">Yours</em> : null}<small>{f.blurb} {ss.length ? `${nOn} of ${ss.length} signals in use.` : 'No signal yet.'}</small></span>
        {f.group === 'impact' ? <span className="sdz-step is-none" /> : <Stepper label={`Weight of ${f.name}`} id={`sdz-fw-${fid}`} value={nOn ? pct(finalShare(fid)) : 'off'} off={!canEdit || !nOn} onDown={() => design.factorWeight(fid, -5)} onUp={() => design.factorWeight(fid, 5)} />}
      </div>
      {open ? (
        <div className="sdz-sigs">
          {ss.length ? <div className="sdz-sigs-h"><span>Signal, and how it scores 1 to 4</span><span>Weight in the factor</span></div> : <p className="sdz-empty">This factor has no signal yet, so it does not count. Add the first one below.</p>}
          {ss.map((s) => <SheetRow key={s.id} s={s} canEdit={canEdit} onOpen={onOpen} />)}
          {canEdit ? <AddSignal fid={fid} startOpen={yours && !ss.length} /> : null}
        </div>
      ) : null}
    </div>
  )
}

function Assume({ k, title, text, options, value, onPick }: { k: string; title: string; text: string; options?: [string, string, string?][]; value?: string; onPick?: (v: string) => void }) {
  const ok = !!DESIGN.ok[k]
  return (
    <div className={`sdz-as${ok ? ' is-ok' : ''}`} data-assume={k}>
      <div className="sdz-as-h"><b>{title}</b><span className={`tag ${ok ? 'ok' : 'need'}`}>{ok ? <><CheckOutlined /> Confirmed</> : 'To confirm'}</span></div>
      <p>{text}</p>
      {options ? <div className="sdz-as-opts" role="radiogroup" aria-label={title}>{options.map(([v, t, note]) => <button key={v} type="button" role="radio" aria-checked={value === v} className={value === v ? 'is-on' : ''} onClick={() => onPick?.(v)}>{t}{note ? <small>{note}</small> : null}</button>)}</div> : null}
      {!ok ? <button type="button" className="sdz-as-ok" data-testid={`sdz-ok-${k}`} onClick={() => design.confirm(k)}>Confirm as it stands</button> : null}
    </div>
  )
}


export default function ScorecardDesign({ j, onOpen, canEdit }: { j: Journey; onOpen: (d: Drill) => void; canEdit: boolean }) {
  useDesignV()
  const st = useJourney()
  const versions = useDesign((s) => s.versions)
  const [text, setText] = useState('')
  const [said, setSaid] = useState('')
  const [rule, setRule] = useState('')
  const [flt, setFlt] = useState<CheckStatus | 'all'>('all')
  const [allOpen, setAllOpen] = useState(true)
  const [fold, setFold] = useState(0)
  const up = DESIGN.source === 'uploaded', B = bookShape(), cc = checkCounts(), rows = dataCheck()
  const flags = SIGNALS.filter((s) => DESIGN.flag[s.id] && DESIGN.on[s.id])
  const keys = ASSUME_KEYS(DESIGN), left = keys.filter((k) => !DESIGN.ok[k]).length
  const live = j.stage === 'armed'
  const neg = CONTRACTS.filter((c) => c.negDso), negAvg = neg.length ? (neg.reduce((n, c) => n + score(c, DESIGN.rule, 'before'), 0) / neg.length).toFixed(3) : 'n/a'
  const addSignal = () => { const t = text.trim(); if (t.length < 4) return; const sig = design.custom(t); const f = FACTORS.find((x) => x.id === sig.f)!; setSaid(`Added to ${f.name}. I read it from the ${sig.src.name.toLowerCase()} for all ${CONTRACTS.length} projects. I proposed its rule for 1 to 4; open the signal to change it.`); setText('') }
  const setActs = (acts: ActionCat[]) => st.setActs(j.id, acts)
  const addRule = () => { const t = rule.trim(); if (t.length < 4) return; setActs([...j.acts, { key: `x${j.acts.length + 1}`, when: /monday|week/i.test(t) ? 'Every Monday' : /signal|reach/i.test(t) ? 'A signal reaches 3 or 4' : /late|overdue/i.test(t) ? 'A plan action is 7 days late' : 'A score goes up', text: t.replace(/^(.)/, (m) => m.toUpperCase()).replace(/\.$/, ''), why: 'Your rule', mode: 'ask', on: true, custom: true }]); setRule('') }
  const word = up ? 'template' : 'scorecard'
  /* No template: one scorecard, every factor in its group. A template: its own factors, plus any factor you add. */
  const groups = (['internal', 'external', 'impact'] as Group[]).filter((g) => g !== 'impact' || SIGNALS.some((x) => x.f === 'im' && inTemplate(x)))
  const facs = (g: Group) => FACTORS.filter((f) => f.group === g && (DESIGN.customF.includes(f.id) || SIGNALS.some((x) => x.f === f.id && inTemplate(x))))
  const GRP: Record<Group, [string, string]> = {
    internal: ['What we control', 'How the contract is written, how the site is run and how the contract performs.'],
    external: ['What we do not control', 'The client and its politics, competitors, the community, the plant we inherited and the world outside.'],
    impact: ['What is at stake', 'How much a loss would matter and how soon. Read beside the risk score: it sets which high-risk projects come first.'],
  }
  let no = 0
  return (
    <div className="sdz" data-testid="sdz" data-source={DESIGN.source}>
      {live ? <div className={`sdz-live${unpublished() ? ' is-dirty' : ''}`} data-testid="sdz-live"><span>{unpublished() ? <><b>You changed the scoring.</b> The dashboard still shows version {versions.length}. Publish to score every project again on the {word} as it stands.</> : <><b>This goal is live and can be edited.</b> Change the scoring, the data check, the dashboard or the rules here. A change to the scoring is published as a new version of the dashboard.</>}</span>{unpublished() ? <span className="sdz-live-acts"><Button size="small" data-testid="sdz-discard" onClick={() => st.discardChange(j.id)}>Discard</Button><Button type="primary" size="small" data-testid="sdz-publish" onClick={() => st.republish(j.id)}>Publish version {versions.length + 1}</Button></span> : null}</div> : null}

      <section className="sdz-sec" data-part="sheet">
        <div className="sdz-sec-h"><span className="sdz-no">{no += 1}</span><div><h3>{up ? 'Your template, as written' : 'The scorecard'}</h3><p>{up ? <>Read from <b>{DESIGN.tplName}</b> and used as written: your factors with their share of the final score, your signals with their weight and your rule for 1 to 4. I added nothing and left nothing out. You can still rewrite a rule, drop a signal, add one to a factor, or add a factor.</> : <>My proposal, built from your Contracting Policy, your KPI pack, the contracts already lost and what the connected data can feed. It is one framework: what we control, what we do not control, and what is at stake. Every factor has its share of the final score; every signal has its weight and its rule for 1 to 4. Drop a signal, add one to a factor, add a factor, or change a weight or a rule.</>} 1 is good, 4 is bad.</p></div></div>
        <DesignPreview />
        <p className="sdz-formula" data-testid="sdz-formula"><b>How one score is made.</b> Each signal scores 1 to 4. A factor is the weighted average of its signals. {DESIGN.rule === 'avg' ? 'The factors are weighted into two halves, what we control and what we do not, and the project score is the average of the two.' : 'The factors are weighted into two halves, what we control and what we do not, and the project score is the higher of the two.'} Under 1.5 rates 1, under 2.5 rates 2, under 3.5 rates 3, the rest 4.{impactOn() ? ' What is at stake is not averaged in: it is read beside the score.' : ''}</p>
        <div className="sdz-fold"><span>Every factor with its signals. <b>Edit</b> opens the rule for 1 to 4 so you can rewrite it. <b>Drop</b> takes a signal out.</span><button type="button" data-testid="sdz-fold" onClick={() => { setAllOpen(!allOpen); setFold(fold + 1) }}>{allOpen ? 'Collapse all' : 'Expand all'}</button></div>
        {groups.map((g) => (
          <div key={g} className="sdz-grp" data-group={g}>
            <div className="sdz-grp-h"><b>{GRP[g][0]}</b><span>{GRP[g][1]}</span><i>{g === 'impact' ? 'beside the score' : DESIGN.rule === 'avg' ? 'share of the score' : 'share of its half'}</i></div>
            {facs(g).map((f) => <FactorSheet key={`${f.id}-${fold}`} fid={f.id} canEdit={canEdit} onOpen={onOpen} only={up ? inTemplate : undefined} startOpen={allOpen} />)}
            {canEdit && g !== 'impact' ? <AddFactor g={g} /> : null}
          </div>
        ))}
        <div className="sdz-flags"><FlagFilled /> <span><b>Red flags.</b> {flags.length ? <>One of these at its worst band rates a project 3 whatever the weights say: {flags.map((x) => x.name.toLowerCase()).join('; ')}. Take the flag off a signal to remove it.</> : `None${up ? ' in your template' : ''}. Mark a signal with the flag and its worst case alone rates the project 3.`}</span></div>
        {<p className="sdz-g" data-testid="sdz-travel"><b>Direction of travel.</b> Not a factor: for every project and every signal I keep twelve months of scores, so the dashboard shows whether a site is sliding, steady or recovering.</p>}
        <div className="sdz-add">
          <Input value={text} disabled={!canEdit} onChange={(e) => setText(e.target.value)} onPressEnter={addSignal} placeholder="Or describe a signal in your own words and I place it, e.g. operators working more than two weekends in a row" aria-label="Add a signal" data-testid="sdz-add-input" />
          <Button icon={<PlusOutlined />} disabled={!canEdit || text.trim().length < 4} onClick={addSignal} data-testid="sdz-add-btn">Add</Button>
        </div>
        {said ? <p className="sdz-said" data-testid="sdz-said">{said}</p> : null}
        <p className="sdz-tip">You can also say it in the chat: “drop odor complaints”, “add a factor Energy cost”, “add a signal late invoices to Financial Performance”.</p>
      </section>

      <section className="sdz-sec" data-part="check">
        <div className="sdz-sec-h"><span className="sdz-no">{no += 1}</span><div><h3>The data check</h3><p>I tested every signal against the connected data: is there a source, how is it measured, at what level does the data sit, and how does it become one figure per project. {B.pcs} profit centers hold the {CONTRACTS.length} projects, and the projects run {B.facilities} facilities, so several figures have to be brought to project level.</p></div></div>
        <div className="sdz-cc" data-testid="sdz-cc">{([['all', `${cc.all} signals`], ['ready', `${cc.ready} ready`], ['assume', `${cc.assume} ready on an assumption`], ['partly', `${cc.partly} partly`], ['missing', `${cc.missing} not found`]] as [CheckStatus | 'all', string][]).map(([k, t]) => <button key={k} type="button" data-filter={k} className={`sdz-chip is-${k}${flt === k ? ' is-on' : ''}`} onClick={() => setFlt(k)}>{t}</button>)}</div>
        <div className="sdz-as-h2"><b>Assumptions to confirm</b><span>{left ? `${left} of ${keys.length} still to confirm` : `All ${keys.length} confirmed`}</span>{left ? <Button size="small" data-testid="sdz-ok-all" onClick={() => design.confirmAll(keys)}>Confirm all as they stand</Button> : null}</div>
        <div className="sdz-ass">
          <Assume k="score" title="One score per project" text={`${up ? 'Your template weights' : 'The scorecard weights'} what we control to 100% and what we do not to 100%. To give every project one score, the two halves need one rule.`} value={DESIGN.rule === 'max' ? 'max' : 'avg'} onPick={(v) => design.rule(v as 'avg' | 'max')} options={[['avg', 'Average of the two halves', 'Each factor then has one share of the final score'], ['max', 'The higher of the two halves', 'A project can be lost on either side']]} />
          <Assume k="pc" title="Figures booked by profit center" text={`DSO, overtime against payroll, community spend and the financial signals are booked by profit center and month, not by project. ${B.sharedPcs} profit centers hold more than one project (${B.inShared} projects in all).`} value={DESIGN.assume.pc} onPick={(v) => design.assume('pc', v)} options={[['inherit', 'Each project takes its profit center\'s figure', 'Simple, and how the finance reports read'], ['revenue', 'Split the profit center across its projects by revenue', 'Closer, where the general ledger carries a project code']]} />
          <Assume k="negdso" title="Negative DSO" text={`${B.negDso} projects sit in a profit center where credits exceed receivables this month, so DSO is negative. ${up ? 'Your template has' : 'The DSO rule has'} no band for it. On the choice below those projects score ${negAvg} on average.`} value={DESIGN.assume.negdso} onPick={(v) => design.assume('negdso', v)} options={[['mid', 'Score it 2.5 for now', 'A middle score until you decide'], ['one', 'Score it 1', 'Nothing is owed, so no collection risk'], ['out', 'Leave DSO out for those projects', 'Treat it as a data exception']]} />
          <Assume k="nps" title="Survey answers sit by client account" text={`The client survey is stored by client account name, not by project. I matched ${B.npsMatched} of ${CONTRACTS.length} projects by name; the others have no site score. Some clients answered more than once.`} value={DESIGN.assume.nps} onPick={(v) => design.assume('nps', v)} options={[['lowest', 'The lowest answer counts'], ['latest', 'The latest answer counts'], ['average', 'The average of the answers']]} />
          <Assume k="fac" title="Figures recorded by facility" text={`Compliance, samples, violations, maintenance and safety are recorded by facility. ${B.multiFac} projects have more than one facility.`} value={DESIGN.assume.fac} onPick={(v) => design.assume('fac', v)} options={[['worst', 'The project takes its worst facility', 'One bad plant is a problem for the contract'], ['sum', 'Add the facilities up', 'Counts and rates over the whole project']]} />
          {(() => { const nums = numericSignals().filter((x) => x.f !== 'im'), fl = histFlagged(), reg = nums.filter((x) => REG_RULE.has(x.id)).length; return <Assume k="hist" title="Rules checked against your history" text={`${nums.length} signals are scored on a figure. I looked at how your projects were spread on each one over the last three years. ${reg} follow a regulatory or permit limit and stay as written. ${fl.length ? `${fl.length} put most projects in one score, so ${fl.length === 1 ? 'it tells' : 'they tell'} sites apart poorly: ${fl.map((x) => `${x.name.toLowerCase()} (${Math.round(histOf(x, true)!.top * 100)}% in one score)`).join('; ')}. Open ${fl.length === 1 ? 'it' : 'one'} with Edit on the scorecard to see the curve.` : 'All of them spread your projects well.'}`} value={DESIGN.assume.hist} onPick={(v) => design.assume('hist', v)} options={fl.length ? [['keep', 'Keep the rules as written', up ? 'As in your template' : 'As proposed'], ['hist', `Take the thresholds from history for ${fl.length === 1 ? 'it' : `these ${fl.length}`}`, 'The better half scores 1, the worst 5% score 4']] : undefined} /> })()}
        </div>
        <div className="sdz-tbl-wrap"><table className="sdz-tbl" data-testid="sdz-check">
          <thead><tr><th>Signal, how it is measured and how it scores</th><th>Read from, and where the data sits</th><th className="n">Projects</th><th>Result</th></tr></thead>
          <tbody>{rows.filter((r) => flt === 'all' || r.status === flt).map((r) => (
            <tr key={r.s.id} data-signal={r.s.id} className={`is-${r.status}`}>
              <td><b>{r.s.name}</b><small className="sdz-meas">{r.s.src.how}.</small><span className="sdz-rule4">{[1, 2, 3, 4].map((b) => bandsOf(r.s)[b - 1] ? <i key={b}><u style={{ background: RATING_COLOR[(DESIGN.map[r.s.id] ?? [1, 2, 3, 4])[b - 1]] }}>{(DESIGN.map[r.s.id] ?? [1, 2, 3, 4])[b - 1]}</u>{bandsOf(r.s)[b - 1]}</i> : null)}</span>{r.note ? <small>{r.note}</small> : null}</td>
              <td><span className="sdz-from">{SRC_ICON[r.s.src.kind]} {r.s.src.name}</span><span className={`sdz-lvl is-${r.level}`}>{LEVEL_NAME[r.level]}</span>{r.level !== 'project' && r.level !== 'contract' ? <small>{r.how}</small> : null}</td>
              <td className="n">{r.status === 'missing' ? 'none' : `${coverOf(r.s.id).n} of ${r.of}`}</td>
              <td><span className={`sdz-st is-${STATUS[r.status].c}`}>{STATUS[r.status].t}</span></td>
            </tr>))}</tbody>
        </table></div>
      </section>

      <section className="sdz-sec" data-part="dashboard">
        <div className="sdz-sec-h"><span className="sdz-no">{no += 1}</span><div><h3>The dashboard: what you want to see</h3><p>I propose the views a portfolio owner asks for. Tick what you want.</p></div></div>
        <div className="sdz-where" data-testid="sdz-where"><FundProjectionScreenOutlined /><span><b>Where you open it, every time.</b> <b>Submissions</b> in the left menu, under “Contract risk dashboard”. It is also on this goal’s <b>Deliverables</b> tab. Both show the same dashboard. I refresh it every morning after the 06:00 check. It gets a new version number only when you change the scoring, and every older version stays open.</span></div>
        <div className="sdz-panels">{PANELS.map((p) => { const dis = !canEdit || (p.needs === 'impact' && !impactOn()); return (
          <label key={p.k} className={`sdz-panel${DESIGN.panels[p.k] ? ' is-on' : ''}${dis ? ' is-dis' : ''}`} data-panel={p.k}>
            <input type="checkbox" checked={!!DESIGN.panels[p.k]} disabled={dis} onChange={(e) => design.panel(p.k, e.target.checked)} />
            <span><b>{p.name}</b>{p.rec ? <em>Recommended</em> : null}<small>{p.needs === 'impact' && !impactOn() ? 'Needs “What is at stake”, which is not in use.' : p.what}</small></span>
          </label>) })}</div>
      </section>

      <section className="sdz-sec" data-part="rules">
        <div className="sdz-sec-h"><span className="sdz-no">{no += 1}</span><div><h3>Mitigation, and what I do when a score rises</h3><p><b>Every site with a signal at 3 or 4 gets a mitigation plan, whether or not its score moved.</b> Each action is written for that site from its own records: the reading, the mail about it, the contract clause, and what is public. The rules below are what else I do, and when.</p></div></div>
        <div className="sdz-rules">{j.acts.map((a) => { const on = a.on !== false; return (
          <div key={a.key} className={`sdz-rule${on ? '' : ' is-off'}`} data-rule={a.key}>
            <Switch size="small" checked={on} disabled={!canEdit} aria-label={`Use the rule: ${a.text}`} onChange={(v) => setActs(j.acts.map((x) => (x.key === a.key ? { ...x, on: v } : x)))} />
            <div className="sdz-rule-t">
              <select aria-label="When" value={a.when ?? WHEN_OPTIONS[0]} disabled={!canEdit || !on} onChange={(e) => setActs(j.acts.map((x) => (x.key === a.key ? { ...x, when: e.target.value } : x)))}>{WHEN_OPTIONS.map((w) => <option key={w}>{w}</option>)}</select>
              <b>{a.text}</b>{a.custom ? <em>Yours</em> : null}
            </div>
            <div className="dv-seg" role="radiogroup" aria-label={a.text}><button type="button" role="radio" aria-checked={a.mode === 'auto'} disabled={!canEdit || !on} className={a.mode === 'auto' ? 'is-on' : ''} onClick={() => st.setActMode(j.id, a.key, 'auto')}>By itself</button><button type="button" role="radio" aria-checked={a.mode === 'ask'} disabled={!canEdit || !on} className={a.mode === 'ask' ? 'is-on is-ask' : ''} onClick={() => st.setActMode(j.id, a.key, 'ask')}>Ask me first</button></div>
          </div>) })}</div>
        <div className="sdz-add">
          <Input value={rule} disabled={!canEdit} onChange={(e) => setRule(e.target.value)} onPressEnter={addRule} placeholder="Add a rule in your own words, e.g. put it on the agenda of the monthly review" aria-label="Add a rule" data-testid="sdz-rule-input" />
          <Button icon={<PlusOutlined />} disabled={!canEdit || rule.trim().length < 4} onClick={addRule} data-testid="sdz-rule-btn">Add</Button>
        </div>
      </section>
    </div>
  )
}
