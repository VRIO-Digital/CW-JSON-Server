import { Typography } from 'antd'
import { useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { appPath } from '../../api/dataset'
import { AGENT_POOL, GOALS, type Trigger } from '../../data/goalCases'
import { useAuthStore } from '../../store/authStore'
import { exampleInput, useGoalStore, type ChatMsg } from '../../store/goalStore'
import ChatPane from './ChatPane'
import { describeRead, readUpload } from '../../data/readFile'
import TwoPane from './TwoPane'

const { Text } = Typography

/*
 * A new goal, briefed in conversation. The agent asks only what it still needs: the goal in plain
 * words, how it starts (now, on a schedule, when a rule fires), the deadline, schedule or condition
 * (and for a rule, whether it is checked in our data or on the internet), and what to hold it against.
 * The left pane fills in as it learns. "Create it" makes the goal; the agent then proposes its approach.
 */

interface Draft {
  goal?: string
  trigger?: Trigger
  when?: string
  conditionSource?: 'data' | 'external'
  measure?: string
  target?: string
  agentName?: string
  approachId?: string
  exampleOf?: string
  scope?: string
  constraints?: string
  files?: { name: string; size: number; read: string; problem?: string }[]
}
type Stage = 'goal' | 'trigger' | 'when' | 'measure' | 'confirm'

let n = 0
const m = (who: ChatMsg['who'], text: string): ChatMsg => ({ id: `ng${(n += 1)}-${Date.now().toString(36)}`, at: new Date().toISOString(), who, text })

const EX_RULE = 'Example: over-budget project (rule)'
const EX_SCHED = 'Example: quarterly committee pack (schedule)'
const STARTS: Record<Trigger, string> = { person: 'Now, by you', schedule: 'On a schedule', rule: 'When a rule fires' }

export default function NewGoalChat() {
  const navigate = useNavigate()
  const location = useLocation()
  const me = useAuthStore((s) => s.identity?.name) ?? 'You'
  const { goals, approaches, start } = useGoalStore()
  const fromApproach = approaches.find((a) => a.id === (location.state as { approachId?: string } | null)?.approachId)
  const nextAgent = useMemo(() => AGENT_POOL.find((a) => !goals.some((g) => g.agent.name === a.name)) ?? AGENT_POOL[goals.length % AGENT_POOL.length], [goals])

  const [draft, setDraft] = useState<Draft>(fromApproach ? { approachId: fromApproach.id, scope: fromApproach.scope.join('\n'), constraints: fromApproach.constraints.join('\n') } : {})
  const [stage, setStage] = useState<Stage>('goal')
  const [typing, setTyping] = useState(false)
  const [msgs, setMsgs] = useState<ChatMsg[]>(() => [
    m('agent', fromApproach
      ? `Starting from your saved approach "${fromApproach.name}". What is the goal? Say it in plain words.`
      : 'What do you want to know or achieve? Say it in plain words, the way you would brief an analyst. If you have a deck or a note with the problem statement, attach it with the clip below and I will read it.'),
  ])
  const lastField = useRef<string>('')

  const agent = { ...nextAgent, name: draft.agentName ? (/^agent\b/i.test(draft.agentName) ? draft.agentName : `Agent ${draft.agentName}`) : nextAgent.name }

  const whenQuestion = (t: Trigger) =>
    t === 'rule' ? 'What is the condition, and where do I check it: in our data at every snapshot, or on the internet every morning?'
      : t === 'schedule' ? 'When should it run?' : 'Is there a deadline?'

  const summary = (d: Draft) => [
    'Here is the goal, on the left.',
    `I am ${agent.name}. ${d.trigger === 'rule' ? 'Once it is created I propose my approach; you approve and save it, and it runs by itself when the rule fires.' : d.trigger === 'schedule' ? 'Once it is created I propose my approach; after you approve it, it runs by itself on the schedule.' : 'Once it is created I propose my approach and start when you approve it.'}`,
    '',
    `If it looks right, say "create it".`,
    `You can still change it first. To give me another name, say "call you Atlas". To change how it starts, say "make it a ${d.trigger === 'schedule' ? 'rule' : 'schedule'}".${d.trigger === 'person' ? ' To set a date, say "deadline 30 October".' : ''}`,
  ].join('\n')

  const create = (d: Draft, history: ChatMsg[]) => {
    const id = start({
      goal: d.goal!, measure: d.measure ?? 'Read from the goal', target: d.target ?? 'Set out in the findings', scope: d.scope ?? '', constraints: d.constraints ?? '',
      trigger: d.trigger ?? 'person', when: d.when ?? '', owner: me, approachId: d.approachId, exampleOf: d.exampleOf, agentName: d.agentName, conditionSource: d.conditionSource, files: d.files,
      chat: [...history, m('agent', 'Created. Drafting my approach now.')],
    })
    navigate(appPath(`/goals/${id}`), { replace: true })
  }

  /** Once the goal is known: guess how it starts from its wording, and ask the next thing. */
  const afterGoal = (next: Draft, t: string): { st: Stage; out: string } => {
    const rule = /\b(whenever|as soon as|every time|if any|when any|when a|when an|alert me)\b/.test(t)
    const sched = /\b(each|every (week|month|quarter|monday|tuesday|wednesday|thursday|friday|day|morning)|weekly|monthly|quarterly)\b/.test(t)
    if (rule || sched) {
      next.trigger = rule ? 'rule' : 'schedule'
      return { st: 'when', out: `Sounds like ${rule ? 'a rule: it starts when something happens' : 'a schedule: it runs by itself'}. ${whenQuestion(next.trigger)}` }
    }
    return { st: 'trigger', out: 'How should it start: now, by you; on a schedule; or when a rule fires?' }
  }

  /** The question for the step the brief is on, asked again after a file arrives. */
  const askAgain = (st: Stage, d: Draft) =>
    st === 'goal' ? 'What do you want to know or achieve?' : st === 'trigger' ? 'How should it start: now, by you; on a schedule; or when a rule fires?' : st === 'when' ? whenQuestion(d.trigger ?? 'person') : st === 'measure' ? 'What do I hold it against? A measure and a target, or say "you decide".' : 'Say "create it" when ready.'

  /* A file dropped into the brief, typically a deck with the problem statement: read it, take the problem
     as the goal if none is stated yet, keep the file with the goal, and carry on with the next question. */
  const upload = async (file: File) => {
    const history = [...msgs, { ...m('me', 'Here is the problem statement.'), file: { name: file.name, size: file.size } }]
    setMsgs(history)
    setTyping(true)
    const r = await readUpload(file)
    window.setTimeout(() => {
      setTyping(false)
      const next: Draft = { ...draft, files: [...(draft.files ?? []).filter((f) => f.name !== r.name), { name: r.name, size: r.size, read: describeRead(r), problem: r.problem }] }
      let st = stage
      let out = `Read ${r.name}: ${describeRead(r)}.`
      if (!draft.goal && r.problem) {
        next.goal = r.problem
        lastField.current = 'goal'
        const a = afterGoal(next, r.problem.toLowerCase())
        st = a.st
        out += `\n\nThe problem it states: "${r.problem}"\n\nI have taken that as the goal, on the left. If it is not quite right, say it in your own words.\n\n${a.out}`
      } else if (!draft.goal) {
        out += `\n\nI could not find a problem statement in it, so I keep it as background. ${askAgain('goal', next)}`
      } else {
        lastField.current = 'files'
        out += `${r.problem ? `\n\nIt says: "${r.problem}"` : ''}\n\nI keep it with the goal as background and read it on every run. ${askAgain(stage, next)}`
      }
      setDraft(next)
      setStage(st)
      setMsgs((x) => [...x, m('agent', out)])
    }, 900)
  }

  const reply = (text: string, d: Draft, s: Stage, history: ChatMsg[]) => {
    const t = text.toLowerCase().trim()
    let next = { ...d }
    let st = s
    let out = ''
    let mm: RegExpMatchArray | null

    /* Things that can be said at any point. */
    if (text === EX_RULE || text === EX_SCHED || /^example\b/.test(t)) {
      const ex = GOALS.find((g) => g.trigger === (text === EX_RULE || /rule|budget/.test(t) ? 'rule' : 'schedule'))!
      const v = exampleInput(ex, me)
      next = { ...next, goal: v.goal, measure: v.measure, target: v.target, scope: v.scope, constraints: v.constraints, trigger: v.trigger, when: v.when, conditionSource: v.conditionSource, exampleOf: ex.id, approachId: undefined }
      lastField.current = 'all'
      st = 'confirm'
      out = summary(next)
    } else if ((mm = text.match(/(?:call|name|rename)\s+(?:the agent|it|you|yourself|agent)\s+(?:agent\s+)?(.+)$/i))) {
      next.agentName = mm[1].trim().replace(/[.!]$/, '')
      lastField.current = 'agent'
      out = `${/^agent\b/i.test(next.agentName) ? next.agentName : `Agent ${next.agentName}`} it is.${st === 'confirm' ? ' Say "create it" when ready.' : ''}`
    } else if (d.goal && (mm = t.match(/make it (?:a |an )?(rule|schedule|scheduled|now|one-off|manual)/))) {
      next.trigger = /rule/.test(mm[1]) ? 'rule' : /sched/.test(mm[1]) ? 'schedule' : 'person'
      next.when = undefined
      lastField.current = 'trigger'
      st = 'when'
      out = whenQuestion(next.trigger)
    } else if (st === 'confirm' && (mm = text.match(/^deadline\s+(.+)$/i))) {
      next.when = mm[1]
      lastField.current = 'when'
      out = 'Deadline set. Say "create it" when ready.'
    } else if (st === 'confirm' && /\b(create|yes|go|looks good|do it|ok|okay|confirm|make it)\b/.test(t)) {
      create(next, history)
      return null
    } else if (st === 'goal') {
      next.goal = text.trim()
      lastField.current = 'goal'
      const r = afterGoal(next, t)
      st = r.st
      out = r.out
    } else if (st === 'trigger') {
      const tr: Trigger | undefined = /\b(rule|condition|fires|when|whenever|alert)\b/.test(t) ? 'rule' : /\b(schedule|scheduled|each|every|weekly|monthly|quarterly|regular)\b/.test(t) ? 'schedule' : /\b(now|me|by you|by me|once|manual|today)\b/.test(t) ? 'person' : undefined
      if (!tr) { out = 'Now, on a schedule, or when a rule fires?' } else {
        next.trigger = tr
        lastField.current = 'trigger'
        st = 'when'
        out = whenQuestion(tr)
      }
    } else if (st === 'when') {
      if (next.trigger === 'rule') {
        const ext = /^on the internet\b|\b(internet|tariff|news|index|indices|market price|announces?)\b/.test(t)
        next.conditionSource = ext ? 'external' : 'data'
        const cond = text.replace(/^(in our data|on the internet)\s*[:,-]?\s*/i, '').trim()
        if (cond.length < 6) { lastField.current = 'source'; out = `I check it ${ext ? 'on the internet, every morning' : 'in our data, at every snapshot'}. What is the condition?` }
        else { next.when = cond.charAt(0).toUpperCase() + cond.slice(1); lastField.current = 'when'; st = 'measure' }
      } else if (next.trigger === 'person') {
        next.when = /^(no|none|no deadline|not really|nope)\b/.test(t) ? '' : text.replace(/^yes,?\s*/i, '')
        lastField.current = 'when'
        st = 'measure'
      } else {
        next.when = text
        lastField.current = 'when'
        st = 'measure'
      }
      if (st === 'measure') {
        out = next.approachId
          ? 'Last thing: what do I hold it against? A measure and a target, or say "you decide".'
          : 'Last thing: what do I hold it against? A measure and a target, e.g. "forecast against approved budget, within 10%". Or say "you decide".'
      }
    } else if (st === 'measure') {
      if (/\b(you decide|up to you|no idea|not sure|skip)\b/.test(t)) {
        next.measure = 'Read from the goal'
        next.target = 'Set out in the findings'
      } else {
        const parts = text.split(/,\s*|\s+(?=within\b|under\b|below\b|at or under\b)/i)
        next.measure = parts[0].trim().replace(/^./, (c) => c.toUpperCase())
        next.target = parts.slice(1).join(' ').trim() || 'As stated'
      }
      lastField.current = 'measure'
      st = 'confirm'
      out = summary(next)
    } else {
      out = 'Say "create it", or tell me what to change.'
    }
    setDraft(next)
    setStage(st)
    return out
  }

  const send = (text: string) => {
    const history = [...msgs, m('me', text)]
    setMsgs(history)
    setTyping(true)
    window.setTimeout(() => {
      setTyping(false)
      const out = reply(text, draft, stage, history)
      if (out) setMsgs((x) => [...x, m('agent', out)])
    }, 450 + Math.random() * 400)
  }

  const chips = stage === 'goal' ? [EX_RULE, EX_SCHED]
    : stage === 'trigger' ? ['Now, by me', 'On a schedule', 'When a rule fires']
    : stage === 'when' ? (draft.trigger === 'rule' ? ['In our data: a project in delivery more than 10% off its budget', 'On the internet: tariffs on steel raised by 20%'] : draft.trigger === 'schedule' ? ['Every Monday at 06:00', 'Each quarter, two weeks before the committee'] : ['No deadline', 'Before the committee on 8 October'])
    : stage === 'measure' ? ['You decide', 'Forecast against approved budget, within 10%']
    : ['Create it', 'Call you Atlas']

  const rows: [string, string, string | undefined][] = [
    ['goal', 'Goal', draft.goal],
    ['trigger', 'Starts', draft.trigger ? STARTS[draft.trigger] : undefined],
    ['when', draft.trigger === 'rule' ? 'Condition' : draft.trigger === 'schedule' ? 'Schedule' : 'Deadline', draft.trigger && draft.when !== undefined ? draft.when || 'None' : undefined],
    ...(draft.trigger === 'rule' ? [['source', 'Checked', draft.conditionSource === 'external' ? 'On the internet, every morning' : draft.conditionSource ? 'In our data, at every snapshot' : undefined] as [string, string, string | undefined]] : []),
    ['measure', 'Measure', draft.measure],
    ['measure', 'Target', draft.target],
    ['agent', 'Agent', agent.name],
    ...(draft.files?.length ? [['files', 'Files', draft.files.map((f) => `${f.name} (${f.read})`).join(' · ')] as [string, string, string | undefined]] : []),
    ...(draft.approachId ? [['approach', 'Approach', `Saved: ${approaches.find((a) => a.id === draft.approachId)?.name}`] as [string, string, string | undefined]] : []),
  ]

  return (
    <TwoPane left={(
      <div className="gw-work">
        <div className="gw-head">
          <span className="gw-back" role="link" onClick={() => navigate(appPath('/goals'))}>← Goals</span>
          <div className="gw-title">New goal</div>
          <Text type="secondary" style={{ fontSize: 12.5 }}>Brief {agent.name} in the chat. This fills in as it learns.</Text>
        </div>
        <div className="gw-kv" style={{ marginTop: 16, background: '#fff', border: '1px solid #e9ecf1', borderRadius: 8, padding: '14px 16px' }}>
          {rows.map(([k, label, val]) => (
            <FragmentRow key={`${label}-${lastField.current === k || lastField.current === 'all' ? msgs.length : 0}`} label={label} value={val} flash={lastField.current === k || lastField.current === 'all'} />
          ))}
        </div>
      </div>
    )} right={(
        <ChatPane agent={agent} messages={msgs} typing={typing} chips={chips} onSend={send} title="new goal" placeholder="Say what you want to know or achieve, or attach a deck" onUpload={upload} />
    )} />
  )
}

function FragmentRow({ label, value, flash }: { label: string; value?: string; flash: boolean }) {
  return (
    <>
      <span>{label}</span>
      <span className={flash && value ? 'gw-draft-field' : undefined} style={{ color: value ? undefined : '#b6bdc9' }}>{value ?? 'not yet'}</span>
    </>
  )
}

