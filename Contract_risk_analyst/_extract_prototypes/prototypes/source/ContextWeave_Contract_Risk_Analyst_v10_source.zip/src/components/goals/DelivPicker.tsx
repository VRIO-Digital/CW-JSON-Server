import { CheckOutlined, PlusOutlined, UploadOutlined } from '@ant-design/icons'
import { Button, Checkbox, Input, Select } from 'antd'
import { useRef, useState } from 'react'
import { TPL_MODE_LABEL, specReady, templateOf, type ActMode, type ActionCat, type DelivSpec, type TplMode } from '../../data/deliverFlow'
import { readUpload, describeRead } from '../../data/readFile'
import { templateFromRead } from '../../data/subChat'
import type { OutputFormat, Template } from '../../data/submissionTemplates'
import { useSubmissionStore } from '../../store/submissionStore'

/*
 * What the run hands over, agreed while the plan is being made: tick one deliverable or several, and for
 * each one choose the template: the one the agent recommends, one from the library, your own file, or a
 * structure the agent designs. For a standing goal, also what it may do when it fires, each kind of action
 * either done by itself or held for your OK. The same card starts a deliverable in Submissions.
 */

const FORMATS: { key: OutputFormat; label: string }[] = [{ key: 'Document', label: 'Document' }, { key: 'Memo', label: 'Memo' }, { key: 'Slide pack', label: 'Slide pack' }, { key: 'Dashboard', label: 'Dashboard' }, { key: 'Workbook', label: 'Spreadsheet' }, { key: 'Email', label: 'Email' }]
const FMT_LABEL: Record<OutputFormat, string> = { Document: 'Document', Memo: 'Memo', 'Slide pack': 'Slide pack', Dashboard: 'Dashboard', Workbook: 'Spreadsheet', Email: 'Email' }
const MODES: TplMode[] = ['recommended', 'library', 'upload', 'ai']
const clean = (n: string) => n.replace(/\.(xlsx|pptx|docx)$/i, '')

export interface DelivPickerProps {
  specs: DelivSpec[]
  onSpecs: (s: DelivSpec[]) => void
  acts?: ActionCat[]
  onAct?: (key: string, mode: ActMode) => void
  onConfirm: () => void
  confirmLabel: string
  /** Deliverables already made from this analysis (Submissions): shown as made, not offered again. */
  made?: Record<string, string>
  intro?: string
  /** A default audience for something you add. */
  audience?: string
}

export default function DelivPicker({ specs, onSpecs, acts, onAct, onConfirm, confirmLabel, made, intro, audience }: DelivPickerProps) {
  const templates = useSubmissionStore((s) => s.templates)
  const addTemplate = useSubmissionStore((s) => s.addTemplate)
  const fileRef = useRef<HTMLInputElement>(null)
  const uploadFor = useRef<string | null>(null)
  const [open, setOpen] = useState<string | null>(null)
  const [adding, setAdding] = useState(false)
  const [newFmt, setNewFmt] = useState<OutputFormat>('Slide pack')
  const [newText, setNewText] = useState('')
  const [reading, setReading] = useState<string | null>(null)

  const upd = (id: string, p: Partial<DelivSpec>) => onSpecs(specs.map((d) => (d.id === id ? { ...d, ...p } : d)))
  const on = specs.filter((d) => d.on && !made?.[d.id])
  const ready = on.length > 0 && on.every((d) => specReady(d, templates))
  const pickFile = (id: string) => { uploadFor.current = id; fileRef.current?.click() }
  const onFile = async (f: File) => {
    const id = uploadFor.current
    if (!id) return
    setReading(id)
    const r = await readUpload(f)
    const t = templateFromRead(r)
    addTemplate(t, 'You')
    setReading(null)
    upd(id, { mode: 'upload', templateId: t.id, uploadName: `${r.name} (${describeRead(r)})` })
  }
  const add = () => {
    const words = newText.trim()
    const label = words ? words.replace(/^./, (c) => c.toUpperCase()).replace(/\.$/, '') : `${FMT_LABEL[newFmt]} from this analysis`
    const aud = words.match(/\bfor (the )?([A-Z][\w,.'-]*(?:\s+(?!on\b|about\b|with\b|of\b|to\b)[\w,.'-]+){0,6})/)?.[2]?.trim()
    onSpecs([...specs, { id: `custom-${Date.now().toString(36)}`, label: label.length > 90 ? `${label.slice(0, label.lastIndexOf(' ', 88)).replace(/[\s,;:]+$/, '')}…` : label, audience: aud ?? audience ?? 'As you described', purpose: words || label, format: newFmt, on: true, mode: 'ai', describe: words || undefined, custom: true }])
    setAdding(false); setNewText('')
  }
  const sorted = (fmt: OutputFormat) => [...templates].sort((a, b) => Number(b.format === fmt) - Number(a.format === fmt))
  const tplSections = (t: Template) => <ol className="dv-secs">{t.sections.map((x) => <li key={x.heading}>{x.heading}</li>)}</ol>

  return (
    <div className="dv" data-testid="deliv-picker">
      <input ref={fileRef} type="file" accept=".pptx,.docx,.pdf,.txt,.md,.xlsx" style={{ display: 'none' }} data-testid="tpl-upload" onChange={(e) => { const f = e.target.files?.[0]; if (f) void onFile(f); e.target.value = '' }} />
      {intro ? <p className="hc-text">{intro}</p> : null}
      <div className="dv-list">
        {specs.map((d) => {
          const isMade = !!made?.[d.id]
          const t = templateOf(d, templates)
          const rec = templates.find((x) => x.id === d.recId)
          return (
            <div key={d.id} className={`dv-row${d.on && !isMade ? ' is-on' : ''}${isMade ? ' is-made' : ''}`} data-deliv={d.id}>
              <div className="dv-top">
                {isMade ? <span className="dv-made"><CheckOutlined /></span> : <Checkbox checked={d.on} onChange={(e) => upd(d.id, { on: e.target.checked })} aria-label={`Build ${d.label}`} />}
                <div className="dv-name">
                  <b>{d.label}</b>
                  <small>For {d.audience}{d.custom ? ' · added by you' : ''}</small>
                </div>
                <span className="dv-fmt">{FMT_LABEL[d.format]}</span>
              </div>
              {isMade ? <div className="dv-madeline">Already made from this analysis</div> : null}
              {d.on && !isMade ? (
                <div className="dv-tpl">
                  <div className="dv-modes" role="radiogroup" aria-label={`Template for ${d.label}`}>
                    {MODES.filter((m) => m !== 'recommended' || rec).map((m) => (
                      <button key={m} type="button" role="radio" aria-checked={d.mode === m} className={`dv-mode${d.mode === m ? ' is-on' : ''}`} onClick={() => (m === 'upload' ? (d.mode === 'upload' && d.templateId ? upd(d.id, { mode: 'upload' }) : pickFile(d.id)) : upd(d.id, { mode: m, ...(m === 'library' && !d.templateId ? { templateId: d.recId } : {}) }))}>
                        {m === 'upload' ? <UploadOutlined /> : null}{TPL_MODE_LABEL[m]}
                      </button>
                    ))}
                  </div>
                  {d.mode === 'recommended' && rec ? (
                    <div className="dv-detail"><span className="dv-tname">{clean(rec.name)}</span><span className="dv-why">{d.why ?? rec.note}</span><a onClick={() => setOpen(open === d.id ? null : d.id)}>{open === d.id ? 'hide its parts' : `its ${rec.sections.length} parts`}</a>{open === d.id ? tplSections(rec) : null}</div>
                  ) : null}
                  {d.mode === 'library' ? (
                    <div className="dv-detail">
                      <Select size="small" style={{ width: '100%' }} value={d.templateId} placeholder="Pick a template" onChange={(v) => upd(d.id, { templateId: v, format: templates.find((x) => x.id === v)?.format ?? d.format })}
                        options={sorted(d.format).map((x) => ({ value: x.id, label: `${clean(x.name)} · ${FMT_LABEL[x.format]} · ${x.family}` }))} />
                      {t ? <><span className="dv-why">{t.note}</span><a onClick={() => setOpen(open === d.id ? null : d.id)}>{open === d.id ? 'hide its parts' : `its ${t.sections.length} parts`}</a>{open === d.id ? tplSections(t) : null}</> : null}
                    </div>
                  ) : null}
                  {d.mode === 'upload' ? (
                    <div className="dv-detail">{reading === d.id ? <span className="dv-why">Reading the file…</span> : t ? <><span className="dv-tname">{d.uploadName ?? t.name}</span><span className="dv-why">In your library now; built on its {t.sections.length} parts.</span><a onClick={() => pickFile(d.id)}>another file</a></> : <span className="dv-why">Choose a file: PowerPoint, Word, PDF or text.</span>}</div>
                  ) : null}
                  {d.mode === 'ai' ? (
                    <div className="dv-detail"><span className="dv-why">I design the structure for this reader from the findings and the recommendation, and keep it in your library.</span>
                      <Input size="small" value={d.describe ?? ''} onChange={(e) => upd(d.id, { describe: e.target.value })} placeholder="Anything it must cover? (optional)" />
                    </div>
                  ) : null}
                </div>
              ) : null}
            </div>
          )
        })}
      </div>
      {adding ? (
        <div className="dv-add">
          <div className="dv-modes">{FORMATS.map((f) => <button key={f.key} type="button" className={`dv-mode${newFmt === f.key ? ' is-on' : ''}`} onClick={() => setNewFmt(f.key)}>{f.label}</button>)}</div>
          <Input.TextArea size="small" autoSize={{ minRows: 1, maxRows: 3 }} value={newText} onChange={(e) => setNewText(e.target.value)} placeholder="What is it and who reads it? e.g. a one-page note for the insurer on the Harlow Creek claim" />
          <div className="dv-add-acts"><Button size="small" type="primary" onClick={add}>Add</Button><Button size="small" type="text" onClick={() => setAdding(false)}>Cancel</Button></div>
        </div>
      ) : <a className="dv-addlink" onClick={() => setAdding(true)}><PlusOutlined /> Add another deliverable</a>}
      {acts?.length ? (
        <div className="dv-acts">
          <div className="hc-label">When it fires, it may</div>
          {acts.map((a) => (
            <div key={a.key} className="dv-act" data-act={a.key}>
              <div className="dv-act-t"><b>{a.text}</b><small>{a.why}</small></div>
              <div className="dv-seg" role="radiogroup" aria-label={a.text}>
                <button type="button" role="radio" aria-checked={a.mode === 'auto'} className={a.mode === 'auto' ? 'is-on' : ''} onClick={() => onAct?.(a.key, 'auto')}>By itself</button>
                <button type="button" role="radio" aria-checked={a.mode === 'ask'} className={a.mode === 'ask' ? 'is-on is-ask' : ''} onClick={() => onAct?.(a.key, 'ask')}>Ask me first</button>
              </div>
            </div>
          ))}
        </div>
      ) : null}
      <div className="dv-foot">
        <span>{on.length ? `${on.length} to build${on.some((d) => !specReady(d, templates)) ? ' · pick a template for each' : ''}` : 'Tick at least one'}</span>
        <Button type="primary" size="small" disabled={!ready} onClick={onConfirm} data-testid="deliv-confirm">{confirmLabel}</Button>
      </div>
    </div>
  )
}
