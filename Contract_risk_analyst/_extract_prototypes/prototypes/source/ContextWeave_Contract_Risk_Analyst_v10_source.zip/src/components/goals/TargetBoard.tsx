/*
 * The Target tab of a standing goal that has a number and a date (11 November 2026).
 *
 * It answers four questions an owner of the number asks every morning: where do we stand, where will
 * we land, what moved since yesterday, and what would close the gap. Below that it shows where the
 * analyst can be reached: by itself after every load, and at the step, when another system calls it.
 * The analyst recommends; nothing here writes to a source system.
 */
import { ApiOutlined, ArrowRightOutlined, CheckOutlined, CopyOutlined, DownOutlined, FileSearchOutlined, RightOutlined, ThunderboltOutlined } from '@ant-design/icons'
import { Button, Input, Modal } from 'antd'
import { useState } from 'react'
import { create } from 'zustand'
import type { Drill } from '../../data/goalCases'
import type { Journey } from '../../store/journeyStore'
import { KIND_LABEL, KIND_SUB, LEVERS, MONTHS_LEFT, MOVES, REQUISITIONS, SIGNALS, callSample, m1t, money0, money2, pct1, reqSaving, targetFigures, type LeverKey, type Requisition, type SignalKind, type TargetState } from '../../data/targetGoal'
import './TargetBoard.css'

/** Is this standing goal a target: a number to reach by a date. Today the procurement watch is. */
export const isTargetGoal = (j: Journey | null) => !!j && j.mode === 'watch' && j.case === 'watch'

export const targetStateOf = (j: Journey): TargetState => {
  const fired = j.runs.length > 0
  const handled = fired && j.status === 'executed'
  const catalogueRaised = handled && j.execActs.some((a) => /catalogue/i.test(a.text) && (a.state === 'done' || a.state === 'approved'))
  return { fired, handled, catalogueRaised }
}

/* What other systems asked the analyst, kept for the visit so the board can show it. */
export interface StepCall { id: string; at: string; req: string; verdict: Requisition['verdict']; saving: number; outcome: 'open' | 'switched' | 'kept' | 'bundled' | 'cleared'; reason?: string }
interface CallStore { on: Record<string, boolean>; calls: Record<string, StepCall[]>; setOn: (id: string, v: boolean) => void; add: (id: string, c: StepCall) => void; settle: (id: string, callId: string, outcome: StepCall['outcome'], reason?: string) => void }
export const useStepCalls = create<CallStore>((set) => ({
  on: {}, calls: {},
  setOn: (id, v) => set((s) => ({ on: { ...s.on, [id]: v } })),
  add: (id, c) => set((s) => ({ calls: { ...s.calls, [id]: [...(s.calls[id] ?? []).filter((x) => x.req !== c.req), c] } })),
  settle: (id, callId, outcome, reason) => set((s) => ({ calls: { ...s.calls, [id]: (s.calls[id] ?? []).map((x) => (x.id === callId ? { ...x, outcome, reason } : x)) } })),
}))
const hhmm = () => new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
const OUTCOME: Record<StepCall['outcome'], string> = { open: 'Shown to the requester', switched: 'Requester switched to the framework', kept: 'Requester kept it, with a reason', bundled: 'Sent to Procurement to bundle', cleared: 'Nothing to flag' }

/** One line under the panel title, so the number is in view on every tab. */
export function TargetStrip({ j, onOpen }: { j: Journey; onOpen: () => void }) {
  const f = targetFigures(targetStateOf(j))
  return (
    <button type="button" className="tg-strip" data-testid="target-strip" onClick={onOpen}>
      <span><b>Target</b> {m1t(f.target)} by 30 June 2027</span>
      <span>Secured <b>{m1t(f.secured)}</b> · {pct1(f.secured / f.target)}</span>
      <span className={f.gap ? 'is-short' : 'is-ok'}>Forecast <b>{m1t(f.forecast)}</b>{f.gap ? ` · ${m1t(f.gap)} short` : ' · on target'}</span>
      <ArrowRightOutlined />
    </button>
  )
}

export default function TargetBoard({ j, onOpen, onTab }: { j: Journey; onOpen: (d: Drill) => void; onTab: (t: 'findings' | 'deliverables' | 'plan') => void }) {
  const st = targetStateOf(j)
  const f = targetFigures(st)
  const [open, setOpen] = useState<LeverKey | null>(null)
  const [how, setHow] = useState(false)
  const [step, setStep] = useState(false)
  const stepOn = useStepCalls((s) => s.on[j.id] ?? true)
  const setOn = useStepCalls((s) => s.setOn)
  const calls = useStepCalls((s) => s.calls[j.id]) ?? []
  const armed = j.stage === 'armed'
  const w = (n: number) => `${Math.max(0, Math.min(100, (n / f.target) * 100))}%`
  const signals = SIGNALS.filter((s) => s.when === 'always' || st.fired)
  const kinds: SignalKind[] = ['leak', 'open', 'head']
  const moves = MOVES.map((m) => ({ ...m, isDone: !!m.done?.(st) }))
  const left = moves.filter((m) => !m.isDone).reduce((n, m) => n + m.amount, 0)
  const stepSaved = calls.filter((c) => c.outcome === 'switched' || c.outcome === 'bundled').reduce((n, c) => n + c.saving, 0)

  return (
    <div className="tg" data-testid="target-board">
      <div className="tg-head">
        <div>
          <h3>Take 2.5% off procurement spend</h3>
          <p>{m1t(f.target)} of {m1t(f.baseline)} addressable capital spend, by 30 June 2027 · {MONTHS_LEFT} months left · a saving counts once it is in an order or a signed contract</p>
        </div>
        <span className={`pill ${f.gap ? 'is-amber' : 'is-green'}`} data-testid="target-verdict"><i />{f.gap ? `Forecast ${m1t(f.gap)} short` : 'Forecast on target'}</span>
      </div>

      {/* where we stand, where we land */}
      <div className="tg-score">
        <div className="tg-bar" role="img" aria-label={`Secured ${m1t(f.secured)}, forecast ${m1t(f.forecast)}, target ${m1t(f.target)}`}>
          <i className="b-sec" style={{ width: w(f.secured) }} />
          <i className="b-fc" style={{ left: w(f.secured), width: w(Math.max(0, f.forecast - f.secured)) }} />
          <em className="t-path" style={{ left: w(f.path) }} title={`Straight-line path to date ${m1t(f.path)}`} />
        </div>
        <div className="tg-scale"><span>$0</span><span style={{ left: w(f.path) }} className="at">path to date {m1t(f.path)}</span><span className="end">target {m1t(f.target)}</span></div>
        <div className="tg-kpis">
          <div><small>Invoiced</small><b>{m1t(f.invoiced)}</b><span>paid at the lower price</span></div>
          <div className="k-sec"><small>Secured</small><b data-testid="tg-secured">{m1t(f.secured)}</b><span>{pct1(f.secured / f.target)} of target{st.handled ? ' · nine lines pending the re-orders' : ''}</span></div>
          <div><small>Named, not secured</small><b>{m1t(f.pipeline)}</b><span>in the tracker’s pipeline{st.fired && !st.handled ? ' and tonight’s load' : ''}</span></div>
          <div className="k-fc"><small>Forecast at 30 June</small><b data-testid="tg-forecast">{m1t(f.forecast)}</b><span>{pct1(f.forecast / f.baseline)} of spend{f.gap ? ` · ${m1t(f.gap)} short` : ''}</span></div>
        </div>
        <button type="button" className="tg-fold" aria-expanded={how} onClick={() => setHow(!how)}>{how ? <DownOutlined /> : <RightOutlined />} How I forecast it</button>
        {how ? (
          <table className="tg-how" data-testid="tg-how"><tbody>
            <tr><td>Secured so far</td><td className="n">{m1t(f.secured)}</td><td>The savings register, 41 entries{st.handled ? ', plus the nine lines re-placed on 20 October' : ''}.</td></tr>
            <tr><td>Named pipeline that converts</td><td className="n">+{m1t(f.converted)}</td><td>{pct1(f.conv).replace('.0', '')} of what was named has reached an order so far. <span className="tag inf">Assumption</span></td></tr>
            <tr><td>New savings still to be found</td><td className="n">+{m1t(f.newFinds)}</td><td>Half the pace so far ({m1t(f.pace)} a month), over {MONTHS_LEFT} months: the easy contracts are done. <span className="tag inf">Assumption</span></td></tr>
            <tr><td>Off-framework leakage</td><td className="n">{f.leak ? `−${m1t(f.leak)}` : '$0.0M'}</td><td>{f.leak ? `About ${m1t(f.leakYear)} a year while the catalogue defaults to the spot suppliers. The tracker does not net it; I do.` : 'Stopped by the catalogue change, once IT makes it. Requested on the 20 October run.'}</td></tr>
            <tr className="tot"><td>Forecast at 30 June 2027</td><td className="n">{m1t(f.forecast)}</td><td>{f.gap ? `${m1t(f.gap)} short of ${m1t(f.target)}.` : 'At or above the target.'} The tracker alone reads {pct1(f.secured / f.target)}, ahead of the path.</td></tr>
          </tbody></table>
        ) : null}
      </div>

      {/* the levers */}
      <section>
        <div className="tg-h"><b>How the 2.5% breaks down</b><span>Five levers, named as the savings register names them. Open one to see what I watch for it.</span></div>
        <div className="tg-levers" role="table">
          <div className="lv-row lv-top" role="row"><span>Lever</span><span className="n">Plan</span><span className="n">Secured</span><span className="n">Named</span><span>Against plan</span></div>
          {LEVERS.map((l) => {
            const sec = l.secured + (st.handled && l.key === 'fw' ? f.nine : 0)
            const named = l.pipeline + (st.fired && !st.handled && l.key === 'fw' ? f.nine : 0)
            const isOpen = open === l.key
            const sig = signals.filter((s) => s.lever === l.key)
            return (
              <div key={l.key} className={`lv${isOpen ? ' is-open' : ''}`} data-lever={l.key}>
                <button type="button" className="lv-row" role="row" aria-expanded={isOpen} onClick={() => setOpen(isOpen ? null : l.key)}>
                  <span className="lv-n">{isOpen ? <DownOutlined /> : <RightOutlined />}<b>{l.name}</b>{sig.length ? <i className="lv-dot" title={`${sig.length} signal${sig.length === 1 ? '' : 's'} today`}>{sig.length}</i> : null}</span>
                  <span className="n">{m1t(l.plan)}</span>
                  <span className="n">{m1t(sec)}</span>
                  <span className="n">{m1t(named)}</span>
                  <span className="lv-bar"><i style={{ width: `${Math.min(100, (sec / l.plan) * 100)}%` }} /><i className="nm" style={{ left: `${Math.min(100, (sec / l.plan) * 100)}%`, width: `${Math.min(100 - Math.min(100, (sec / l.plan) * 100), (named / l.plan) * 100)}%` }} /><em>{pct1(sec / l.plan).replace(/\.\d/, '')}</em></span>
                </button>
                {isOpen ? (
                  <div className="lv-body">
                    <p>{l.what} {l.entries} entries in the register so far.</p>
                    <div className="lv-cols">
                      <div><small>What I watch for</small><ul>{l.watch.map((x) => <li key={x}>{x}</li>)}</ul></div>
                      <div><small>Today</small>{sig.length ? <ul>{sig.map((s) => <li key={s.id}><b>{KIND_LABEL[s.kind]}:</b> {s.title}</li>)}</ul> : <p className="none">No signal on this lever today.</p>}</div>
                    </div>
                    <a className="tg-src" onClick={() => onOpen(l.evidence.drill)}><FileSearchOutlined /> {l.evidence.n} <span>{l.evidence.m}</span></a>
                  </div>
                ) : null}
              </div>
            )
          })}
          <div className="lv-row lv-tot" role="row"><span>All levers</span><span className="n">{m1t(f.target)}</span><span className="n">{m1t(f.secured)}</span><span className="n">{m1t(f.pipeline)}</span><span /></div>
        </div>
      </section>

      {/* what moved */}
      <section>
        <div className="tg-h"><b>{st.fired ? 'What I saw at the 20 October load' : 'What I see today'}</b><span>{armed ? 'Read after every nightly order load, with the documents and the mailbox.' : 'Read from the register, six months of order lines, the frameworks and the mailbox while drafting the plan.'}</span></div>
        <div className="tg-sigs">
          {kinds.map((k) => {
            const xs = signals.filter((s) => s.kind === k)
            return (
              <div key={k} className={`sg-col is-${k}`} data-kind={k}>
                <div className="sg-h"><b>{KIND_LABEL[k]}</b><span>{KIND_SUB[k]}</span></div>
                {xs.map((s) => (
                  <div key={s.id} className="sg" data-signal={s.id}>
                    <b>{s.title}</b>
                    <span className="sg-amt">{s.amount}</span>
                    <p>{s.body}</p>
                    <div className="sg-src">{s.src.map((x) => <a key={x.n} onClick={() => onOpen(x.drill)}><FileSearchOutlined /> {x.n}</a>)}</div>
                    {s.run ? <Button size="small" onClick={() => onTab('findings')}>Open the run and its options</Button> : null}
                  </div>
                ))}
              </div>
            )
          })}
        </div>
      </section>

      {/* what would close the gap */}
      <section>
        <div className="tg-h"><b>{f.gap ? 'What would close the gap' : 'What keeps it on target'}</b><span>My recommendations. Each one is a decision for the person named; I change nothing in PeopleSoft or the catalogue.</span></div>
        <ol className="tg-moves">
          {moves.map((m) => (
            <li key={m.id} className={m.isDone ? 'is-done' : ''} data-move={m.id}>
              <span className="mv-n">{m.isDone ? <CheckOutlined /> : null}</span>
              <div><b>{m.title}</b><span>{m.isDone ? m.doneText : `Decides: ${m.who} · by ${m.by} · lever: ${LEVERS.find((l) => l.key === m.lever)!.name}`}</span></div>
              <em>{m.isDone ? 'in the forecast' : `+${m1t(m.amount)}`}</em>
            </li>
          ))}
        </ol>
        <p className="tg-note">{f.gap ? (left >= f.gap ? `The ${moves.filter((m) => !m.isDone).length} open ones add ${m1t(left)}, which covers the ${m1t(f.gap)}.` : `The ${moves.filter((m) => !m.isDone).length} open ones add ${m1t(left)} of the ${m1t(f.gap)}. The rest has to come from converting more of the named pipeline than the ${pct1(f.conv).replace('.0', '')} so far.`) : 'Nothing further is needed at today’s forecast.'}</p>
      </section>

      {/* where the analyst shows up */}
      <section>
        <div className="tg-h"><b>Where I show up</b><span>The same goal, reached two ways. In both I inform and recommend; the people and the systems act.</span></div>
        <div className="tg-where">
          <div className="wh">
            <span className="wh-ic"><ThunderboltOutlined /></span>
            <div><b>By myself, after every order load</b><span>{armed ? `Next: ${j.nextCheck ?? 'the next nightly load'}. I read the day’s lines, score each lever, update the forecast and tell the people you chose.` : 'From the moment the watch is armed: every nightly load, the documents and the mailbox.'}</span></div>
            <span className="tag ok">{armed ? 'On' : 'On when armed'}</span>
          </div>
          <div className="wh">
            <span className="wh-ic"><ApiOutlined /></span>
            <div><b>At the step, when another system calls me</b><span>The procurement system asks before a requisition goes for approval. I answer with a verdict, the reason, the evidence and a better option, shown to the requester in their own screen.</span>
              <div className="wh-acts"><Button size="small" type="primary" disabled={!stepOn} data-testid="open-step" onClick={() => setStep(true)}>See it at the step</Button>{stepOn ? null : <span className="none">Turned off: calls from other systems get no answer.</span>}</div>
            </div>
            <button type="button" role="switch" aria-checked={stepOn} aria-label="Answer calls from other systems" data-testid="step-switch" className={`sw${stepOn ? ' is-on' : ''}`} onClick={() => setOn(j.id, !stepOn)}><i /></button>
          </div>
        </div>
        {calls.length ? (
          <div className="tg-calls" data-testid="step-calls">
            <div className="tg-calls-h"><b>Calls from the procurement system this visit</b><span>{calls.length} answered{stepSaved ? ` · ${money0(stepSaved)} identified at the step, secured once ordered` : ''}</span></div>
            <ul>{calls.map((c) => <li key={c.id}><time>{c.at}</time><span><b>{c.req}</b> · {c.verdict === 'clear' ? 'clear' : `${money0(c.saving)} identified`}</span><span className={`tag ${c.outcome === 'switched' || c.outcome === 'bundled' || c.outcome === 'cleared' ? 'ok' : c.outcome === 'kept' ? 'need' : 'inf'}`}>{OUTCOME[c.outcome]}</span></li>)}</ul>
          </div>
        ) : null}
      </section>

      <StepWindow j={j} open={step} onClose={() => setStep(false)} onOpen={onOpen} />
    </div>
  )
}

/* ------------------------------------------------------------------ the checkpoint, seen from the calling system */

function StepWindow({ j, open, onClose, onOpen }: { j: Journey; open: boolean; onClose: () => void; onOpen: (d: Drill) => void }) {
  const [rid, setRid] = useState(REQUISITIONS[0].id)
  const [view, setView] = useState<'screen' | 'contract'>('screen')
  const [phase, setPhase] = useState<Record<string, 'idle' | 'asking' | 'answered'>>({})
  const [switched, setSwitched] = useState<Record<string, boolean>>({})
  const [keeping, setKeeping] = useState<string | null>(null)
  const [reason, setReason] = useState('')
  const [copied, setCopied] = useState<string | null>(null)
  const add = useStepCalls((s) => s.add)
  const settle = useStepCalls((s) => s.settle)
  const calls = useStepCalls((s) => s.calls[j.id]) ?? []
  const r = REQUISITIONS.find((x) => x.id === rid)!
  const ph = phase[rid] ?? 'idle'
  const call = calls.find((c) => c.req === rid)
  const isSw = !!switched[rid]
  const price = isSw && r.better ? r.better.price : r.line.price
  const supplier = isSw && r.better ? r.better.supplier : r.supplier
  const sample = callSample(r, j.agent.name)

  const ask = () => {
    setPhase((p) => ({ ...p, [rid]: 'asking' }))
    window.setTimeout(() => {
      setPhase((p) => ({ ...p, [rid]: 'answered' }))
      add(j.id, { id: `sc-${rid}`, at: hhmm(), req: rid, verdict: r.verdict, saving: reqSaving(r), outcome: r.verdict === 'clear' ? 'cleared' : 'open' })
    }, 900)
  }
  const doSwitch = () => { setSwitched((s) => ({ ...s, [rid]: true })); setKeeping(null); settle(j.id, `sc-${rid}`, r.verdict === 'note' ? 'bundled' : 'switched') }
  const doKeep = () => { if (!reason.trim()) return; settle(j.id, `sc-${rid}`, 'kept', reason.trim()); setKeeping(null); setReason('') }
  const copy = (k: string, t: string) => { const done = () => { setCopied(k); window.setTimeout(() => setCopied(null), 1400) }; try { void navigator.clipboard.writeText(t).then(done, done) } catch { done() } }

  return (
    <Modal open={open} onCancel={onClose} footer={null} width="min(1040px, 94vw)" destroyOnHidden title={<span className="stp-title">At the step · {j.agent.name} called from the procurement system</span>} className="stp-modal">
      <div className="stp-tabs" role="tablist">
        <button type="button" role="tab" aria-selected={view === 'screen'} className={view === 'screen' ? 'is-on' : ''} onClick={() => setView('screen')}>What the requester sees</button>
        <button type="button" role="tab" aria-selected={view === 'contract'} className={view === 'contract' ? 'is-on' : ''} data-testid="stp-contract-tab" onClick={() => setView('contract')}>How it is called</button>
      </div>
      {view === 'screen' ? (
        <div className="stp" data-testid="step-window">
          <div className="stp-pick" role="tablist" aria-label="Requisition">{REQUISITIONS.map((x) => <button key={x.id} type="button" role="tab" aria-selected={x.id === rid} data-req={x.id} className={x.id === rid ? 'is-on' : ''} onClick={() => { setRid(x.id); setKeeping(null); setReason('') }}><b>{x.id}</b><span>{x.line.desc}</span></button>)}</div>
          <div className="erp" data-testid="erp">
            <div className="erp-bar"><b>PeopleSoft eProcurement</b><span>Northline Water Group · a mock of the calling system</span></div>
            <div className="erp-body">
              <div className="erp-h"><b>Requisition {r.id}</b><span className={`erp-st${ph === 'answered' && r.verdict !== 'clear' && !isSw && call?.outcome === 'open' ? ' is-hold' : ''}`}>{isSw ? 'Changed · ready to submit' : call?.outcome === 'kept' ? 'Exception requested' : ph === 'answered' && r.verdict === 'clear' ? 'Ready to submit' : ph === 'answered' ? 'Review before submit' : 'Draft'}</span></div>
              <dl className="erp-meta"><div><dt>Project</dt><dd>{r.project}</dd></div><div><dt>Requested by</dt><dd>{r.by}</dd></div><div><dt>Supplier</dt><dd data-testid="erp-supplier">{supplier}</dd></div></dl>
              <table className="erp-t"><thead><tr><th>Item</th><th>Description</th><th className="n">Quantity</th><th className="n">Unit price</th><th className="n">Line total</th></tr></thead>
                <tbody><tr><td>{r.line.item}</td><td>{r.line.desc}</td><td className="n">{r.line.q.toLocaleString('en-US')} {r.line.unit}</td><td className="n" data-testid="erp-price">{money2(price)}</td><td className="n">{money2(price * r.line.q)}</td></tr></tbody></table>
              {call?.outcome === 'kept' ? <p className="erp-note">Reason recorded on the requisition: “{call.reason}”. Sent to Procurement as an exception request.</p> : null}
              <div className="erp-acts">
                <button type="button" className="erp-btn is-primary" data-testid="erp-check" disabled={ph !== 'idle'} onClick={ask}>{ph === 'idle' ? 'Check and submit for approval' : ph === 'asking' ? 'Checking…' : 'Checked'}</button>
                <span>On this button the procurement system calls {j.agent.name} before the requisition goes for approval.</span>
              </div>
            </div>
          </div>

          {ph === 'asking' ? <div className="stp-msg is-wait"><span className="bld-spin" /> {j.agent.name} is reading the requisition against the frameworks, the benchmarks and this month’s orders…</div> : null}
          {ph === 'answered' ? (
            <div className={`stp-msg is-${r.verdict}`} data-testid="step-answer" role="status">
              <div className="stp-msg-h"><span className="stp-who">{j.agent.name} · Capital Program Analyst</span><span className={`tag ${r.verdict === 'clear' ? 'ok' : 'need'}`}>{r.verdict === 'clear' ? 'Clear' : r.verdict === 'flag' ? 'Review' : 'Advice'}</span></div>
              <b>{r.head}</b>
              <p>{r.reason}</p>
              {r.better ? (
                <div className="stp-better">
                  <div><small>Now</small><b>{money2(r.line.price)}</b><span>{r.supplier}</span></div>
                  <ArrowRightOutlined />
                  <div><small>Better option</small><b>{money2(r.better.price)}</b><span>{r.better.supplier} · {r.better.framework} · lead time {r.better.lead}</span></div>
                  <div className="sv"><small>On this line</small><b>{money0(reqSaving(r))}</b><span>counts as secured once ordered</span></div>
                </div>
              ) : null}
              <div className="stp-ev">{r.evidence.map((e) => <a key={e.n} onClick={() => onOpen(e.drill)}><FileSearchOutlined /> {e.n}</a>)}</div>
              {r.better && call?.outcome === 'open' ? (
                <div className="stp-acts">
                  <Button type="primary" size="small" data-testid="stp-switch" onClick={doSwitch}>{r.better.label}</Button>
                  <Button size="small" data-testid="stp-keep" onClick={() => setKeeping(rid)}>Keep it as it is, with a reason</Button>
                  <span>These are the requester’s buttons, in the procurement system. {j.agent.name} does not change the requisition.</span>
                </div>
              ) : null}
              {keeping === rid && call?.outcome === 'open' ? (
                <div className="stp-keep"><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Why this supplier, for example: needed on site within two weeks" aria-label="Reason" onPressEnter={doKeep} /><Button size="small" type="primary" disabled={!reason.trim()} data-testid="stp-keep-send" onClick={doKeep}>Record the reason</Button></div>
              ) : null}
              {call && call.outcome !== 'open' ? <p className="stp-done"><CheckOutlined /> {OUTCOME[call.outcome]}{call.outcome === 'switched' || call.outcome === 'bundled' ? `. ${money0(call.saving)} goes on the Target tab as identified at the step.` : call.outcome === 'kept' ? '. It goes to Procurement as an exception, and stays on my list of leakage.' : '.'}</p> : null}
            </div>
          ) : null}
        </div>
      ) : (
        <div className="stp-contract" data-testid="step-contract">
          <div className="door-row">
            <div className="door"><b>Ask it directly</b><span>Another application sends a requisition, an order or an invoice and gets the answer back in the same call.</span></div>
            <div className="door"><b>Tell it something happened</b><span>The source system raises an event when a step runs. The analyst reads it and answers to the people you chose.</span></div>
            <div className="door"><b>Use it as a step</b><span>A workflow engine or another agent calls {j.agent.name} as one step of its own process and carries on with the answer.</span></div>
          </div>
          <p className="tg-note">Every analyst is created with a name and one address. This one is <b>{j.agent.name}</b>, Capital Program Analyst for Northline. The call below is the one behind {r.id}; pick another requisition on the first tab to see its call.</p>
          <div className="code-row">
            <div className="code"><div className="code-h"><b>What the procurement system sends</b><button type="button" onClick={() => copy('req', sample.request)}>{copied === 'req' ? <><CheckOutlined /> Copied</> : <><CopyOutlined /> Copy</>}</button></div><pre>{sample.request}</pre></div>
            <div className="code"><div className="code-h"><b>What {j.agent.name} answers</b><button type="button" onClick={() => copy('res', sample.response)}>{copied === 'res' ? <><CheckOutlined /> Copied</> : <><CopyOutlined /> Copy</>}</button></div><pre>{sample.response}</pre></div>
          </div>
          <p className="tg-note">The answer never writes to the source system. Showing it inside the requester’s screen needs a small extension on the procurement system’s side; until that exists the same answer goes out by mail or chat with a link.</p>
        </div>
      )}
    </Modal>
  )
}

