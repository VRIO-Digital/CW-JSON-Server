/*
 * The dashboard of the contract risk watch (version 3, 17 November 2026).
 *
 * Built from the scorecard the person designed on the Plan tab, and showing the views they ticked there.
 * It answers a portfolio owner's questions in order: how much is at risk, which contracts first (risk
 * against what is at stake), what moved and why, where the risk sits across regions and factors, and what
 * decides soon. A contract opens to why it scores what it scores, signal by signal with the evidence, what
 * the analyst sees that the scorecard does not score, and a mitigation plan written for that site, with
 * the score the plan would bring it to. Nothing here writes to a source system.
 */
import { ArrowDownOutlined, ArrowLeftOutlined, ArrowUpOutlined, CheckOutlined, FlagFilled, MinusOutlined, PlusOutlined } from '@ant-design/icons'
import { Button } from 'antd'
import { useRef, useState } from 'react'
import { create } from 'zustand'
import type { Drill } from '../../data/goalCases'
import { CONTRACTS, DESIGN, FACTORS, LOST, PRIORITY_COLOR, PRIORITY_WHAT, RATING_COLOR, RATING_NAME, RATING_SOFT, REGIONS, SIGNALS, activeFactors, activeSignals, coverOf, deltaOf, driversOf, f1, factorAverages, factorScore, factorShare, finalShare, flagsOf, groupScore, impactOn, impactRating, likelihoodSignals, lostOn, m1, movers, planEffect, planFor, priorityOf, ratingOf, readingOf, score, seenOf, shortSite, trendOf, valOf, weighted, type Contract, type Priority, type When } from '../../data/risk'
import { design, unpublished, useDesign, useDesignV, type DashVersion } from '../../store/designStore'
import { useNavigate } from 'react-router-dom'
import { appPath } from '../../api/dataset'
import { useJourney, type Journey } from '../../store/journeyStore'
import { SRC_ICON, StepModal, drillFor, firedOf, seenDrill, useStepCalls } from './ScoreBoard'
import './RiskBoard.css'

interface PlanStore { assigned: Record<string, string>; assign: (id: string, at: string) => void }
export const usePlans = create<PlanStore>((set) => ({ assigned: {}, assign: (id, at) => set((s) => ({ assigned: { ...s.assigned, [id]: at } })) }))

const SHORT: Record<string, string> = { gr: 'Core terms', cr: 'Contract terms', os: 'Safety', en: 'Environment', st: 'Staffing', cu: 'Client', co: 'Community', fp: 'Financial', sl: 'State courts', li: 'Litigation', in: 'Assets', sp: 'Homes nearby', iq: 'Influent', cp: 'Client politics', cl: 'Competitors', rs: 'Resilience' }
const ORDER: Priority[] = ['Act now', 'Manage', 'Watch', 'Routine']
type Filter = 'all' | 'act' | 'high' | 'rising' | 'renew' | 'moved'
const Rt = ({ r, big }: { r: number; big?: boolean }) => <span className={`rk-rt${big ? ' is-big' : ''}`} style={{ background: RATING_SOFT[r], color: RATING_COLOR[r] }}>{r}</span>
const Pr = ({ p }: { p: Priority }) => <span className="rk-pr" style={{ color: PRIORITY_COLOR[p], borderColor: PRIORITY_COLOR[p] }}>{p}</span>
const Dir = ({ d }: { d: number }) => d > 0.08 ? <span className="rk-up"><ArrowUpOutlined /> {d.toFixed(2)}</span> : d < -0.08 ? <span className="rk-down"><ArrowDownOutlined /> {Math.abs(d).toFixed(2)}</span> : <span className="rk-flat"><MinusOutlined /></span>
function Spark({ pts, w = 70, h = 20, color = '#4b5a75' }: { pts: number[]; w?: number; h?: number; color?: string }) {
  const lo = Math.min(...pts, 2.5) - 0.1, hi = Math.max(...pts, 2.5) + 0.1
  const x = (i: number) => (i / (pts.length - 1)) * (w - 4) + 2, y = (v: number) => h - 2 - ((v - lo) / (hi - lo)) * (h - 4)
  return <svg width={w} height={h} className="rk-spark" aria-hidden="true"><line x1="0" x2={w} y1={y(2.5)} y2={y(2.5)} stroke="#e2812a" strokeDasharray="2 3" strokeWidth="1" /><polyline fill="none" stroke={color} strokeWidth="1.5" points={pts.map((v, i) => `${x(i)},${y(v)}`).join(' ')} /><circle cx={x(pts.length - 1)} cy={y(pts[pts.length - 1])} r="2.2" fill={color} /></svg>
}
const decides = (c: Contract) => (c.evergreen ? 'Evergreen' : c.monthsLeft <= 24 ? `${c.monthsLeft} mo` : `${Math.round(c.monthsLeft / 12)} yr`)

const MONTHS = ['Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov']
const UP = '#c0392b', DOWN = '#1f8a5b'
type Way = 'all' | 'up' | 'down' | 'flat'
/*
 * Direction of travel: every project as one line over twelve months. The projects that rose or fell in the
 * last 90 days are drawn in colour (rose solid, fell dashed, so colour is not the only sign); the rest stay
 * grey as context. The largest movers are named at the line end and listed below.
 */
function Travel({ w, fired, onPick }: { w: When; fired: boolean; onPick: (id: string) => void }) {
  const [way, setWay] = useState<Way>('all')
  const [hov, setHov] = useState<{ id: string; px: number; py: number } | null>(null)
  const box = useRef<HTMLDivElement>(null)
  const data = CONTRACTS.map((c) => { const t = trendOf(c, w), d = deltaOf(c, w); return { c, t, d, dir: d > 0.08 ? 'up' as const : d < -0.08 ? 'down' as const : 'flat' as const } })
  const ups = data.filter((x) => x.dir === 'up').sort((a, b) => b.d - a.d), downs = data.filter((x) => x.dir === 'down').sort((a, b) => a.d - b.d), flats = data.filter((x) => x.dir === 'flat')
  const W = 640, H = 300, L = 34, R = 168, T = 20, B = 28
  const all = data.flatMap((x) => x.t), lo = Math.min(1, Math.floor(Math.min(...all) * 2) / 2), hi = Math.max(3, Math.ceil(Math.max(...all) * 2) / 2)
  const X = (i: number) => L + (i * (W - L - R)) / 11, Y = (v: number) => T + ((hi - v) / (hi - lo)) * (H - T - B)
  const path = (t: number[]) => t.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join('')
  const ticks: number[] = []; for (let v = Math.ceil(lo * 2) / 2; v <= hi + 0.001; v += 0.5) ticks.push(v)
  const lit = (dir: 'up' | 'down' | 'flat') => way === 'all' ? dir !== 'flat' : way === dir
  /* the largest movers are named at the line end; labels are pushed apart so none overlap */
  const named = [...(way === 'down' || way === 'flat' ? [] : ups.slice(0, way === 'up' ? 6 : 4)), ...(way === 'up' || way === 'flat' ? [] : downs.slice(0, way === 'down' ? 6 : 3))].map((x) => ({ x, y: Y(x.t[11]) })).sort((a, b) => a.y - b.y)
  for (let k = 1; k < named.length; k += 1) if (named[k].y < named[k - 1].y + 14) named[k].y = named[k - 1].y + 14
  for (let k = named.length - 1; k >= 0; k -= 1) { const max = H - B - (named.length - 1 - k) * 14; if (named[k].y > max) named[k].y = max }
  const pool = way === 'all' ? data : data.filter((x) => x.dir === way)
  const move = (e: React.MouseEvent<SVGSVGElement>) => {
    const r = e.currentTarget.getBoundingClientRect(), k = W / r.width, mx = (e.clientX - r.left) * k, my = (e.clientY - r.top) * k
    if (mx < L - 6 || mx > X(11) + 8) { setHov(null); return }
    const i = Math.max(0, Math.min(11, Math.round(((mx - L) / (W - L - R)) * 11)))
    let best: typeof data[number] | null = null, gap = 12
    for (const x of pool) { const g = Math.abs(Y(x.t[i]) - my) - (x.dir === 'flat' ? 0 : 3); if (g < gap) { gap = g; best = x } }
    setHov(best ? { id: best.c.id, px: (e.clientX - r.left), py: (e.clientY - r.top) } : null)
  }
  const h = hov ? data.find((x) => x.c.id === hov.id) : null
  const Row = ({ x }: { x: typeof data[number] }) => (
    <button type="button" className="rk-tr-row" data-c={x.c.id} onClick={() => onPick(x.c.id)}>
      <span><b>{shortSite(x.c)}</b><small>{x.c.id} · {x.c.region}</small></span>
      <span className="rk-tr-fig">{(x.t[11] - x.d).toFixed(2)} to <b>{x.t[11].toFixed(2)}</b></span>
      <Dir d={x.d} />
    </button>
  )
  return (
    <section className="rk-sec" data-panel="travel" data-testid="rk-travel">
      <h3>Direction of travel: every project over twelve months</h3>
      <p className="rk-sub">Each line is one project’s risk score, month by month. Over the last 90 days <b>{ups.length} rose</b>, <b>{downs.length} fell</b> and {flats.length} held (a move of more than 0.08 counts). Point at a line to see the project; click it to open it.</p>
      <div className="rk-tr-chips" role="group" aria-label="Which projects to pick out">
        {([['all', `All ${data.length}`], ['up', `Rose ${ups.length}`], ['down', `Fell ${downs.length}`], ['flat', `Held ${flats.length}`]] as [Way, string][]).map(([k, t]) => (
          <button key={k} type="button" aria-pressed={way === k} className={`rk-tr-chip${way === k ? ' is-on' : ''}`} data-testid={`rk-travel-${k}`} onClick={() => setWay(k)}>
            {k === 'up' ? <svg width="18" height="8" aria-hidden="true"><line x1="0" x2="18" y1="4" y2="4" stroke={UP} strokeWidth="2" /></svg> : k === 'down' ? <svg width="18" height="8" aria-hidden="true"><line x1="0" x2="18" y1="4" y2="4" stroke={DOWN} strokeWidth="2" strokeDasharray="5 3" /></svg> : k === 'flat' ? <svg width="18" height="8" aria-hidden="true"><line x1="0" x2="18" y1="4" y2="4" stroke="#aab3c2" strokeWidth="1.5" /></svg> : null}
            {k === 'up' ? <ArrowUpOutlined /> : k === 'down' ? <ArrowDownOutlined /> : null}{t}
          </button>))}
      </div>
      <div className="rk-tr-box" ref={box}>
        <svg viewBox={`0 0 ${W} ${H}`} className="rk-tr-svg" role="img" aria-label={`Risk score of every project over twelve months. ${ups.length} rose, ${downs.length} fell and ${flats.length} held over the last 90 days.`} onMouseMove={move} onMouseLeave={() => setHov(null)} onClick={() => { if (hov) onPick(hov.id) }} style={{ cursor: hov ? 'pointer' : 'default' }}>
          {ticks.map((v) => <g key={v}><line x1={L} x2={X(11)} y1={Y(v)} y2={Y(v)} stroke={v === 2.5 ? '#e2812a' : '#eef1f5'} strokeWidth="1" strokeDasharray={v === 2.5 ? '4 4' : undefined} /><text x={L - 6} y={Y(v) + 3.5} textAnchor="end" className="rk-tr-tick">{v.toFixed(1)}</text></g>)}
          
          <line x1={X(8)} x2={X(8)} y1={T - 6} y2={H - B} stroke="#cfd6e2" strokeWidth="1" strokeDasharray="2 3" />
          <text x={X(8)} y={T - 9} textAnchor="middle" className="rk-tr-note">90 days ago</text>
          <text x={X(11)} y={T - 9} textAnchor="middle" className="rk-tr-note">{fired ? '20 Nov' : 'Now'}</text>
          {MONTHS.map((m, i) => (i % 2 ? <text key={m} x={X(i)} y={H - B + 16} textAnchor="middle" className="rk-tr-tick">{m}</text> : null))}
          <g fill="none" strokeLinejoin="round" strokeLinecap="round">
            {data.filter((x) => !lit(x.dir)).map((x) => <path key={x.c.id} d={path(x.t)} stroke={way === 'flat' ? '#dfe4ec' : '#c9d0db'} strokeWidth="1" opacity={way === 'all' ? 0.55 : 0.4} />)}
            {way === 'flat' ? flats.map((x) => <path key={x.c.id} d={path(x.t)} stroke="#8a94a6" strokeWidth="1" opacity="0.6" />) : null}
            {way !== 'flat' ? data.filter((x) => x.dir === 'down' && lit('down')).map((x) => <path key={x.c.id} data-line={x.c.id} d={path(x.t)} stroke={DOWN} strokeWidth="1.75" strokeDasharray="5 3" />) : null}
            {way !== 'flat' ? data.filter((x) => x.dir === 'up' && lit('up')).map((x) => <path key={x.c.id} data-line={x.c.id} d={path(x.t)} stroke={UP} strokeWidth="1.75" />) : null}
            {h ? <path d={path(h.t)} stroke="#18212f" strokeWidth="2.5" /> : null}
          </g>
          <text x={L + 4} y={Y(2.5) - 5} className="rk-tr-note">Above this line a project rates 3 or 4</text>
          {way !== 'flat' ? data.filter((x) => x.dir !== 'flat' && lit(x.dir)).map((x) => <circle key={x.c.id} cx={X(11)} cy={Y(x.t[11])} r="3.5" fill={x.dir === 'up' ? UP : DOWN} stroke="#fff" strokeWidth="1.5" />) : null}
          {named.map(({ x, y }) => (
            <g key={x.c.id} className="rk-tr-lab" data-label={x.c.id}>
              <line x1={X(11) + 5} x2={X(11) + 14} y1={Y(x.t[11])} y2={y} stroke="#b6bfcc" strokeWidth="1" />
              <text x={X(11) + 17} y={y + 3.5}><tspan fill={x.dir === 'up' ? UP : DOWN} fontWeight="700">{x.dir === 'up' ? '↑' : '↓'}</tspan> {shortSite(x.c)} <tspan className="rk-tr-d">{x.d > 0 ? '+' : '−'}{Math.abs(x.d).toFixed(2)}</tspan></text>
            </g>))}
        </svg>
        {h && hov ? <div className="rk-tr-tip" style={{ left: Math.min(hov.px + 12, (box.current?.clientWidth ?? 600) - 210), top: Math.max(0, hov.py - 74) }}><b>{shortSite(h.c)}</b><small>{h.c.id} · {h.c.region}</small><span>Now <b>{h.t[11].toFixed(2)}</b> · 90 days ago {(h.t[11] - h.d).toFixed(2)}</span><span>{h.dir === 'up' ? `Rose ${h.d.toFixed(2)}` : h.dir === 'down' ? `Fell ${Math.abs(h.d).toFixed(2)}` : 'Held'} · click to open</span></div> : null}
      </div>
      <div className="rk-tr-lists">
        <div data-testid="rk-travel-rose"><h4><ArrowUpOutlined style={{ color: UP }} /> Rose most in 90 days</h4>{ups.length ? ups.slice(0, 5).map((x) => <Row key={x.c.id} x={x} />) : <p className="rk-sub">None.</p>}</div>
        <div data-testid="rk-travel-fell"><h4><ArrowDownOutlined style={{ color: DOWN }} /> Fell most in 90 days</h4>{downs.length ? downs.slice(0, 5).map((x) => <Row key={x.c.id} x={x} />) : <p className="rk-sub">None.</p>}</div>
      </div>
    </section>
  )
}

export default function RiskBoard({ j, onOpen, onTab, embedded }: { j: Journey; onOpen: (d: Drill) => void; onTab: (t: 'findings' | 'deliverables' | 'plan') => void; embedded?: boolean }) {
  useDesignV()
  const fired = firedOf(j), w: When = fired ? 'after' : 'before'
  const [sel, setSel] = useState<string | null>(null)
  const [flt, setFlt] = useState<Filter>('all')
  const [region, setRegion] = useState('')
  const [hf, setHf] = useState('')
  const [all, setAll] = useState(false)
  const [step, setStep] = useState(false)
  const [vsel, setVsel] = useState<number | null>(null)
  const versions = useDesign((s) => s.versions)
  const latest = versions[versions.length - 1], ver = versions.find((x) => x.v === vsel) ?? latest
  const calls = useStepCalls((s) => s.calls[j.id])
  const P = DESIGN.panels, imp = impactOn()
  const mv = fired ? movers() : []
  const movedIds = new Set(mv.map((m) => m.c.id))
  const rows = CONTRACTS.map((c) => { const s = score(c, DESIGN.rule, w); return { c, s, r: ratingOf(s), I: imp ? impactRating(c) : 0, p: priorityOf(c, w), d: deltaOf(c, w) } })
  const dist = [0, 0, 0, 0, 0]; rows.forEach((x) => { dist[x.r] += 1 })
  const rev = (xs: typeof rows) => xs.reduce((n, x) => n + x.c.revenue, 0)
  const high = rows.filter((x) => x.r >= 3), act = rows.filter((x) => x.p === 'Act now'), rising = rows.filter((x) => x.d > 0.08), falling = rows.filter((x) => x.d < -0.08)
  const renew = rows.filter((x) => (x.c.monthsLeft <= 18 && !x.c.evergreen))
  const total = rev(rows)
  const sig = likelihoodSignals().length, nF = activeFactors().length
  const pick = (id: string) => { setSel(id); document.querySelector('.hub-panel')?.scrollTo({ top: 0 }); document.querySelector('.panel-body')?.scrollTo({ top: 0 }) }
  const head = (
    <div className="rk-head">
      <div><h2>Contract risk dashboard</h2><p>{rows.length} projects, one risk score each, on the scorecard you agreed: {nF} factors · {sig} signals. 1 is good, 4 is bad. <a data-testid="rk-edit" onClick={() => onTab('plan')}>Edit the scoring</a></p><p className="rk-where" data-testid="rk-where">{embedded ? <>This is where the dashboard lives. I refresh it every morning after the 06:00 check. The version number changes only when the scoring changes; older versions stay in the list on the right.</> : <>You find this dashboard any time under <b>Submissions</b> in the left menu, and here on the goal’s Deliverables tab. I refresh it every morning after the 06:00 check. The version number changes only when the scoring changes.{j.built['sub-risk-scorecard'] ? <> <a data-testid="rk-open-sub" onClick={() => window.dispatchEvent(new CustomEvent('cw:open-sub', { detail: { sid: j.built['sub-risk-scorecard'] } }))}>Open it in Submissions</a></> : null}</>}</p></div>
      {versions.length ? <div className="rk-ver"><label>Version <select data-testid="rk-version" aria-label="Version of the dashboard" value={ver.v} onChange={(e) => setVsel(Number(e.target.value))}>{versions.slice().reverse().map((x) => <option key={x.v} value={x.v}>v{x.v} · scoring of {x.at}</option>)}</select></label><small data-testid="rk-why">{ver.why}</small><small data-testid="rk-refreshed">{ver.refreshed ? `Refreshed ${ver.refreshed}, at the morning check` : `Scored ${ver.at}`}</small></div> : <span className="rk-asof"><i />{fired ? 'As of the 20 November check' : 'As of the 19 November check'}</span>}
    </div>
  )
  if (latest && ver.v !== latest.v) return <OldVersion ver={ver} latest={latest} head={head} onLatest={() => setVsel(null)} />
  if (sel) { const c = CONTRACTS.find((x) => x.id === sel)!; return <ContractView c={c} w={w} fired={fired} j={j} onBack={() => setSel(null)} onOpen={onOpen} onTab={onTab} /> }

  const inFlt = (x: (typeof rows)[number]) => (flt === 'all' || (flt === 'act' && x.p === 'Act now') || (flt === 'high' && x.r >= 3) || (flt === 'rising' && x.d > 0.08) || (flt === 'renew' && x.c.monthsLeft <= 18 && !x.c.evergreen) || (flt === 'moved' && movedIds.has(x.c.id))) && (!region || x.c.region === region) && (!hf || (factorScore(x.c, hf, w) ?? 0) >= 3)
  const list = rows.filter(inFlt).sort((a, b) => ORDER.indexOf(a.p) - ORDER.indexOf(b.p) || b.s - a.s)
  const shown = all ? list : list.slice(0, 12)
  const chips: [Filter, string, number][] = [['all', 'All', rows.length], ['act', 'Act now', act.length], ['high', 'Rated 3 or 4', high.length], ['rising', 'Rising over 90 days', rising.length], ['renew', 'Decide in 18 months', renew.length], ...(fired ? [['moved', 'Changed at this check', mv.length] as [Filter, string, number]] : [])]
  const risers = fired ? [] : rows.filter((x) => x.d > 0.08).sort((a, b) => b.d - a.d).slice(0, 3)
  const W = 560, H = 290, L = 46, B = 34, T = 10, R = 12
  const mLeft = (c: Contract) => (c.evergreen ? 6 : Math.max(0, Math.min(60, c.monthsLeft)))
  const sx = (v: number) => L + ((v - 1) / 3) * (W - L - R), sy = (m: number) => H - B - (m / 60) * (H - T - B), rad = (n: number) => Math.max(3, Math.sqrt(n / 1e6) * 2.3)
  const zone = rows.filter((x) => x.s >= 2.5 && mLeft(x.c) <= 18)
  const planned = P.plans ? rows.map((x) => ({ ...x, plan: planFor(x.c, w).filter((p) => !p.fixed && !p.later) })).filter((x) => x.plan.length).sort((a, b) => b.s - a.s) : []

  return (
    <div className="rk" data-testid="target-board">
      {head}
      {unpublished() ? <div className="rk-fired" data-testid="rk-unpublished"><b>You are looking at changes that are not published yet.</b> The scoring was changed after version {latest?.v}. <a onClick={() => onTab('plan')}>Publish the next version from the Plan tab</a></div> : null}

      {fired && mv.length ? <div className="rk-fired" data-testid="rk-fired"><b>This morning:</b> {mv.filter((m) => m.r1 > m.r0).length ? <>{mv.filter((m) => m.r1 > m.r0).map((m) => shortSite(m.c)).join(' and ')} moved up a rating.</> : 'no rating moved.'} {mv.filter((m) => m.r1 === m.r0 && m.s1 > m.s0 + 0.004).length ? <>{mv.filter((m) => m.r1 === m.r0 && m.s1 > m.s0 + 0.004).map((m) => shortSite(m.c)).join(', ')} rose inside its rating.</> : null} <a onClick={() => setFlt('moved')}>Show them</a></div> : null}

      {P.kpi ? <div className="rk-kpis" data-testid="rk-kpis">
        <button type="button" className="rk-kpi" onClick={() => setFlt('high')}><small>Rated 3 or 4</small><b data-testid="rk-high">{high.length}</b><span>{m1(rev(high))} a year, {Math.round(rev(high) / total * 100)}% of revenue</span><div className="rk-mini">{[1, 2, 3, 4].map((r) => dist[r] ? <i key={r} style={{ flex: dist[r], background: RATING_COLOR[r] }} title={`${dist[r]} rated ${r}`} /> : null)}</div></button>
        {imp ? <button type="button" className="rk-kpi is-act" onClick={() => setFlt('act')}><small>Act now</small><b data-testid="rk-act">{act.length}</b><span>High risk and a lot at stake: {m1(rev(act))} a year</span></button> : null}
        <button type="button" className="rk-kpi" onClick={() => setFlt(fired ? 'moved' : 'rising')}><small>{fired ? 'Changed at this check' : 'Rising over 90 days'}</small><b data-testid="rk-moved">{fired ? mv.length : rising.length}</b><span>{fired ? `${mv.filter((m) => m.r1 > m.r0).length} moved up a rating` : `${falling.length} came down in the same time`}</span></button>
        <button type="button" className="rk-kpi" onClick={() => setFlt('renew')}><small>Decide in 18 months</small><b data-testid="rk-renew">{renew.length}</b><span>{renew.filter((x) => x.r >= 3).length} of them rated 3 or 4: {m1(rev(renew.filter((x) => x.r >= 3)))} a year</span></button>
      </div> : null}
      <div className="rk-dist" data-testid="rk-dist">{[1, 2, 3, 4].map((r) => <span key={r}><i style={{ background: RATING_COLOR[r] }} />{RATING_NAME[r]} <b data-testid={`sb-n${r}`}>{dist[r]}</b></span>)}</div>

      {P.movers ? <section className="rk-sec" data-panel="movers">
        <h3>{fired ? 'What moved this morning, and why' : 'What moved'}</h3>
        <p className="rk-sub">{fired ? 'Every project where a reading changed since yesterday, on your scorecard.' : 'No rating moved at the 19 November check. These rose the most over the last 90 days.'}</p>
        <div className="rk-movers" data-testid="sb-changed">
          {mv.map((m) => (
            <button type="button" key={m.c.id} className={`rk-mover${m.r1 > m.r0 ? ' is-up' : ''}`} data-c={m.c.id} onClick={() => pick(m.c.id)}>
              <span className="rk-mover-h"><b>{m.c.site}</b><small>{m.c.id} · {m.c.state} · {m.c.region}</small><Pr p={m.p1} /></span>
              <span className="rk-mover-s">{m.r1 > m.r0 ? <><Rt r={m.r0} /> <ArrowUpOutlined rotate={90} /> <Rt r={m.r1} /></> : <Rt r={m.r1} />} <em>{f1(m.s0)} to {f1(m.s1)}</em>{flagsOf(m.c, 'after').length ? <span className="rk-flagchip"><FlagFilled /> red flag</span> : null}</span>
              {m.sigs.map((x) => <span key={x.s.id} className="rk-mover-why"><i style={{ background: RATING_COLOR[Math.round(x.to)] }}>{x.to}</i>{x.s.name}: {x.raw} <small>was {x.from}</small></span>)}
              {m.unscored.map((x) => <span key={x.k} className="rk-mover-why is-un"><i>?</i>{x.label}: not on your scorecard</span>)}
            </button>
          ))}
          {risers.map((x) => <button type="button" key={x.c.id} className="rk-mover" data-c={x.c.id} onClick={() => pick(x.c.id)}><span className="rk-mover-h"><b>{x.c.site}</b><small>{x.c.id} · {x.c.state} · {x.c.region}</small><Pr p={x.p} /></span><span className="rk-mover-s"><Rt r={x.r} /> <em>{f1(x.s)}</em> <Dir d={x.d} /> <Spark pts={trendOf(x.c, w)} color={RATING_COLOR[x.r]} /></span>{driversOf(x.c, w, 2).filter((d) => d.was && d.was < d.v).map((d) => <span key={d.s.id} className="rk-mover-why"><i style={{ background: RATING_COLOR[Math.round(d.v)] }}>{d.v}</i>{d.s.name}: {d.raw} <small>was {d.was}</small></span>)}</button>)}
        </div>
      </section> : null}

      {P.travel ? <Travel w={w} fired={fired} onPick={pick} /> : null}

      {P.matrix ? <section className="rk-sec" data-panel="matrix">
        <h3>Risk, time left and size</h3>
        <p className="rk-sub">One bubble per project. Left to right is the risk score. Bottom to top is the months left before the contract ends or renews, so the lower a bubble sits, the sooner it decides. The bubble is annual revenue. The shaded corner is high risk and ending within 18 months: {zone.length} projects, {m1(rev(zone))} a year.</p>
        <div className="rk-matrix" data-testid="rk-matrix">
          <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Projects by risk score and months left on the contract; bubble size is annual revenue">
            <rect x={sx(2.5)} y={sy(18)} width={W - R - sx(2.5)} height={H - B - sy(18)} fill="#fbe4e1" opacity="0.65" />
            {[1, 2, 3, 4].map((v) => <g key={v}><line x1={sx(v)} x2={sx(v)} y1={T} y2={H - B} stroke="#eff1f5" /><text x={sx(v)} y={H - B + 14} textAnchor="middle" fontSize="10.5" fill="#6b778a">{v}</text></g>)}
            {[0, 12, 18, 24, 36, 48, 60].map((m) => <g key={m}><line x1={L} x2={W - R} y1={sy(m)} y2={sy(m)} stroke={m === 18 ? '#e2812a' : '#eff1f5'} strokeDasharray={m === 18 ? '4 4' : undefined} /><text x={L - 7} y={sy(m) + 4} textAnchor="end" fontSize="10.5" fill="#6b778a">{m === 60 ? '60+' : m}</text></g>)}
            <line x1={sx(2.5)} x2={sx(2.5)} y1={T} y2={H - B} stroke="#e2812a" strokeDasharray="4 4" />
            <text x={(L + W - R) / 2} y={H - 3} textAnchor="middle" fontSize="11" fill="#3b4658">Risk score (1 good, 4 bad). A project rates 3 from 2.5.</text>
            <text x={11} y={(T + H - B) / 2} textAnchor="middle" fontSize="11" fill="#3b4658" transform={`rotate(-90 11 ${(T + H - B) / 2})`}>Months left on the contract</text>
            <text x={W - R - 6} y={H - B - 8} textAnchor="end" fontSize="11" fontWeight="600" fill="#c0392b">High risk, ending within 18 months</text>
            {rows.slice().sort((a, b) => b.c.revenue - a.c.revenue).map((x) => <circle key={x.c.id} data-c={x.c.id} cx={sx(x.s)} cy={sy(mLeft(x.c))} r={rad(x.c.revenue)} fill={RATING_COLOR[x.r]} fillOpacity={movedIds.has(x.c.id) ? 0.95 : 0.5} stroke={movedIds.has(x.c.id) ? '#18212f' : '#fff'} strokeWidth={movedIds.has(x.c.id) ? 1.6 : 0.6} style={{ cursor: 'pointer' }} onClick={() => pick(x.c.id)}><title>{`${x.c.site}, ${x.c.state} · risk score ${f1(x.s)} · ${x.c.evergreen ? 'evergreen: the client can end on notice' : `${x.c.monthsLeft} months left`} · ${m1(x.c.revenue)} a year`}</title></circle>)}
          </svg>
          <div className="rk-legend"><span><i className="rk-b1" /><i className="rk-b2" /><i className="rk-b3" /> Bubble size: annual revenue ($2M, $6M, $12M)</span>{[1, 2, 3, 4].map((r) => <span key={r}><u style={{ background: RATING_COLOR[r] }} />Rated {r}</span>)}<span>Evergreen contracts sit at 6 months: the client can end them on notice.</span></div>
        </div>
      </section> : null}

      {P.plans ? <section className="rk-sec" data-panel="plans">
        <h3>Mitigation plans</h3>
        <p className="rk-sub"><b data-testid="rk-plan-sites">{planned.length}</b> sites have at least one signal at 3 or 4 that can be moved, whether or not their score changed. Each has a plan written for that site. The ten with the highest score are listed; open one for the actions.</p>
        <div className="rk-tbl-wrap"><table className="rk-tbl" data-testid="rk-plans"><thead><tr><th>Project</th><th className="c">Score</th><th className="n">Actions</th><th>What the plan addresses</th><th className="c">If the plan lands</th></tr></thead>
          <tbody>{planned.slice(0, 10).map((x) => { const e = planEffect(x.c, w); return <tr key={x.c.id} data-c={x.c.id} onClick={() => pick(x.c.id)}><td><b>{x.c.site}</b><small>{x.c.id} · {x.c.state}</small></td><td className="c"><Rt r={x.r} /><small>{f1(x.s)}</small></td><td className="n">{x.plan.length}</td><td className="rk-first">{[...new Set(x.plan.map((p) => p.s.name))].slice(0, 4).join(' · ')}</td><td className="c"><b style={{ color: RATING_COLOR[e.rTo] }}>{f1(e.to)}</b></td></tr> })}</tbody>
        </table></div>
      </section> : null}

      {P.ranked ? <section className="rk-sec" data-panel="ranked">
        <h3>Every project, one score</h3>
        <p className="rk-sub">Ranked by priority, then by score. Open a project for its web of factors, the reasons, the evidence and the plan for that site.</p>
        <div className="rk-chips">{chips.map(([k, t, n]) => <button type="button" key={k} data-filter={k} className={`rk-chip${flt === k ? ' is-on' : ''}`} onClick={() => setFlt(k)}>{t} <b>{n}</b></button>)}
          <select aria-label="Region" value={region} onChange={(e) => setRegion(e.target.value)}><option value="">All regions</option>{REGIONS.map((r) => <option key={r.name}>{r.name}</option>)}</select>
          {hf ? <button type="button" className="rk-chip is-on" onClick={() => setHf('')}>{FACTORS.find((f) => f.id === hf)!.name} at 3 or more ×</button> : null}
        </div>
        <div className="rk-tbl-wrap"><table className="rk-tbl is-fixed" data-testid="rk-ranked">
          <colgroup><col style={{ width: 74 }} /><col /><col style={{ width: 50 }} /><col style={{ width: 112 }} /><col style={{ width: 62 }} /><col style={{ width: 62 }} /></colgroup><thead><tr><th>Priority</th><th>Contract, and what drives it</th><th className="c">Rating</th><th>12 months</th><th className="n">A year</th><th className="n">Decides</th></tr></thead>
          <tbody>{shown.map((x) => { const dr = driversOf(x.c, w, 2); return (
            <tr key={x.c.id} data-c={x.c.id} className={movedIds.has(x.c.id) ? 'is-moved' : ''} onClick={() => pick(x.c.id)}>
              <td><Pr p={x.p} /></td>
              <td className="rk-who"><b>{x.c.site}</b><small>{x.c.id} · {x.c.state} · {x.c.region}</small><span className="rk-drv">{dr.length ? dr.map((d) => <i key={d.s.id}><u style={{ background: RATING_COLOR[Math.round(d.v)] }} />{d.s.name}</i>) : <i className="rk-none">Nothing at 3 or 4</i>}</span></td>
              <td className="c"><Rt r={x.r} /><small>{f1(x.s)}</small></td>
              <td className="rk-tr"><Spark pts={trendOf(x.c, w)} color={RATING_COLOR[x.r]} /><Dir d={x.d} /></td>
              <td className="n">{m1(x.c.revenue)}</td>
              <td className="n">{decides(x.c)}</td>
            </tr>) })}</tbody>
        </table></div>
        <div className="rk-more"><span data-testid="sb-count">{list.length}</span> projects{list.length > 12 ? <a onClick={() => setAll(!all)}>{all ? 'Show the first 12' : `Show all ${list.length}`}</a> : null}<a onClick={() => onOpen({ view: 'scorecard', note: '' })}>Open as a worksheet</a></div>
      </section> : null}

      {P.heat ? <section className="rk-sec" data-panel="heat">
        <h3>Where the risk sits</h3>
        <p className="rk-sub">Average score of each factor in each region. A dark column is a problem across the business; a dark cell is local. Click a cell to list its projects.</p>
        <div className="rk-tbl-wrap"><table className="rk-heat" data-testid="rk-heat">
          <thead><tr><th />{activeFactors().map((f) => <th key={f.id} title={f.name}><span>{SHORT[f.id] ?? f.name}</span></th>)}</tr></thead>
          <tbody>{REGIONS.map((rg) => { const cs = CONTRACTS.filter((c) => c.region === rg.name); return <tr key={rg.name}><th>{rg.name}</th>{activeFactors().map((f) => { const xs = cs.map((c) => factorScore(c, f.id, w)).filter((v): v is number => v !== null); const a = xs.length ? xs.reduce((n, v) => n + v, 0) / xs.length : 1; const t = Math.max(0, Math.min(1, (a - 1.3) / 1.5)); return <td key={f.id} data-cell={`${rg.name}:${f.id}`} className={region === rg.name && hf === f.id ? 'is-sel' : ''} style={{ background: `rgba(192, 57, 43, ${(t * 0.78).toFixed(2)})`, color: t > 0.55 ? '#fff' : '#3b4658' }} onClick={() => { setRegion(rg.name); setHf(f.id); setFlt('all'); document.querySelector('[data-panel="ranked"]')?.scrollIntoView({ block: 'start' }) }} title={`${rg.name} · ${f.name}: ${a.toFixed(2)}`}>{a.toFixed(1)}</td> })}</tr> })}</tbody>
        </table></div>
      </section> : null}

      {P.renew && imp ? <section className="rk-sec" data-panel="renew">
        <h3>Renewals ahead</h3>
        <p className="rk-sub">{renew.length} contracts decide in the next 18 months. The ones above the line need a renewal plan now.</p>
        <svg viewBox="0 0 560 120" width="100%" data-testid="rk-renewals" role="img" aria-label="Contracts deciding in 18 months, by score">
          {[0, 6, 12, 18].map((m) => <g key={m}><line x1={40 + m * 28} x2={40 + m * 28} y1="8" y2="96" stroke="#eff1f5" /><text x={40 + m * 28} y="110" textAnchor="middle" fontSize="10.5" fill="#6b778a">{m === 0 ? 'today' : `${m} months`}</text></g>)}
          <line x1="40" x2="548" y1={96 - (1.5 / 3) * 88} y2={96 - (1.5 / 3) * 88} stroke="#e2812a" strokeDasharray="4 4" />
          {renew.map((x) => <circle key={x.c.id} data-c={x.c.id} cx={40 + Math.max(0, x.c.monthsLeft) * 28} cy={96 - ((x.s - 1) / 3) * 88} r={rad(x.c.revenue)} fill={RATING_COLOR[x.r]} fillOpacity="0.6" stroke="#fff" strokeWidth="0.6" style={{ cursor: 'pointer' }} onClick={() => pick(x.c.id)}><title>{`${x.c.site} · ${x.c.monthsLeft} months · risk ${f1(x.s)} · ${m1(x.c.revenue)} a year`}</title></circle>)}
        </svg>
      </section> : null}

      {P.grid ? <section className="rk-sec" data-panel="grid"><h3>All contracts at a glance</h3><div className="rk-grid">{REGIONS.map((rg) => <div key={rg.name} className="rk-reg"><small>{rg.name}</small><div>{rows.filter((x) => x.c.region === rg.name).sort((a, b) => b.s - a.s).map((x) => <button type="button" key={x.c.id} className="rk-cell" data-c={x.c.id} style={{ background: RATING_COLOR[x.r] }} title={`${x.c.site} · ${f1(x.s)}`} aria-label={x.c.site} onClick={() => pick(x.c.id)} />)}</div></div>)}</div></section> : null}

      {P.cover ? <section className="rk-sec" data-panel="cover"><h3>Where every signal comes from</h3><p className="rk-sub">Nobody fills this in. I read each signal from its source at every check.</p><div className="rk-tbl-wrap"><table className="rk-tbl is-plain" data-testid="sb-cov"><thead><tr><th>Signal</th><th>Read from</th><th className="n">Weight</th><th className="n">Contracts</th></tr></thead><tbody>{activeSignals().map((s) => { const cv = coverOf(s.id); return <tr key={s.id}><td>{s.name}{DESIGN.flag[s.id] ? <FlagFilled className="rk-flagi" /> : null}</td><td>{SRC_ICON[s.src.kind]} {s.src.name}</td><td className="n">{s.f === 'im' ? '' : `${(factorShare(s.f) * 100).toFixed(0)}% of its half`}</td><td className="n">{cv.n} of {cv.of}</td></tr> })}</tbody></table></div></section> : null}

      {P.back ? <section className="rk-sec" data-panel="back"><h3>Tested against contracts already lost</h3><p className="rk-sub">What this scorecard would have said twelve months before each loss.</p><div className="rk-tbl-wrap"><table className="rk-tbl is-plain" data-testid="sb-lost"><thead><tr><th>Contract</th><th>How it was lost</th><th className="c">Rated a year before</th></tr></thead><tbody>{LOST.map((l) => { const x = lostOn(l); return <tr key={l.site}><td><b>{l.site}</b><small>{l.state} · {m1(l.revenue)} a year</small></td><td>{l.how}, {l.lost}</td><td className="c"><Rt r={x.rated} />{x.flags.length ? <small>red flag</small> : <small>{f1(x.s)}</small>}</td></tr> })}</tbody></table></div></section> : null}

      <section className="rk-sec rk-step" data-panel="step">
        <h3>Where else I can be reached</h3>
        <p className="rk-sub">The same scorecard answers when a contract is being drafted, renewed or bid, inside the system where that happens.</p>
        <Button size="small" data-testid="open-step" onClick={() => setStep(true)}>See it at the step</Button>
        {calls?.length ? <ul className="rk-calls" data-testid="step-calls">{calls.map((c) => <li key={c.id}><b>{c.item}</b> {c.outcome}</li>)}</ul> : null}
      </section>
      <StepModal open={step} onClose={() => setStep(false)} j={j} onOpen={onOpen} />
    </div>
  )
}

function ContractView({ c, w, fired, j, onBack, onOpen, onTab }: { c: Contract; w: When; fired: boolean; j: Journey; onBack: () => void; onOpen: (d: Drill) => void; onTab: (t: 'findings' | 'deliverables' | 'plan') => void }) {
  const [openF, setOpenF] = useState<string | null>(null)
  const [facts, setFacts] = useState(false)
  const plans = usePlans()
  const s = score(c, DESIGN.rule, w), r = ratingOf(s), wsc = weighted(c, DESIGN.rule, w), flags = flagsOf(c, w), p = priorityOf(c, w), d = deltaOf(c, w)
  const sBefore = score(c, DESIGN.rule, 'before'), moved = fired && !!c.night && Math.abs(s - sBefore) > 0.004
  const [allD, setAllD] = useState(false)
  const drivers = driversOf(c, w).sort((x, y) => Number(fired && !!c.night?.[y.s.id]) - Number(fired && !!c.night?.[x.s.id])), plan = planFor(c, w), eff = planEffect(c, w), todo = plan.filter((x) => !x.fixed && !x.later), fixed = plan.filter((x) => x.fixed), later = plan.filter((x) => x.later)
  const seen = seenOf(c).filter((x) => fired || !x.night)
  const at = plans.assigned[c.id]
  const built = fired && Object.keys(j.built).length > 0
  const tot = drivers.reduce((n, x) => n + x.pts, 0) || 1
  return (
    <div className="rk rk-one" data-testid="sb-detail" data-c={c.id}>
      <button type="button" className="rk-back" data-testid="rk-back" onClick={onBack}><ArrowLeftOutlined /> The dashboard</button>
      <div className="rk-one-head">
        <Rt r={r} big />
        <div><h2>{c.site}</h2><p>{c.id} · {c.client}, {c.state} · {c.region}, {c.rvp} · project leader {c.leader}</p><p>{c.kind} · {m1(c.revenue)} a year at {c.margin}% margin · {c.evergreen ? 'evergreen' : `ends ${c.end}, ${c.monthsLeft} months`}{c.tfc ? ' · the client can end it on notice' : ''}</p></div>
      </div>
      <div className="rk-one-kpis">
        <div><small>Risk score</small><b><i data-testid="sb-score" style={{ color: RATING_COLOR[r] }}>{f1(s)}</i></b><span>Rated <i data-testid="sb-rating">{r}</i>, {RATING_NAME[r].toLowerCase()}{moved ? <em data-testid="sb-moved"> · was {f1(sBefore)}</em> : null}</span></div>
        {impactOn() ? <div><small>At stake</small><b>{impactRating(c)}</b><span><Pr p={p} /> {PRIORITY_WHAT[p]}</span></div> : null}
        <div><small>12 months</small><Spark pts={trendOf(c, w)} w={110} h={30} color={RATING_COLOR[r]} /><span><Dir d={d} /> over 90 days</span></div>
      </div>
      {flags.length ? <div className="rk-flagline" data-testid="rk-flagline"><FlagFilled /> <span><b>Red flag: {flags.map((f) => SIGNALS.find((x) => x.id === f)!.name.toLowerCase()).join('; ')}.</b> The weights alone give {f1(wsc)}; a red flag rates the contract at least 3.</span></div> : null}

      <section className="rk-sec" data-testid="rk-web">
        <h3>Where the score comes from</h3>
        <p className="rk-sub">One spoke per factor, 1 at the centre and 4 at the edge. The filled shape is {shortSite(c)}; the dashed line is the average of all projects. Where the shape pokes out past the line, this site is worse than the portfolio.</p>
        <Web c={c} w={w} />
      </section>

      <section className="rk-sec">
        <h3>Why it scores {f1(s)}</h3>
        <p className="rk-sub">{drivers.length ? `${drivers.length} signals stand at 3 or 4${moved ? '; what changed this morning comes first' : ''}. The bar shows how much each one carries.` : 'No signal stands at 3 or 4.'}</p>
        <div className="rk-drivers" data-testid="rk-drivers">{(allD ? drivers : drivers.slice(0, 7)).map((x) => { const ch = moved && !!c.night?.[x.s.id]; return (
          <div key={x.s.id} className={`rk-driver${ch ? ' is-chg' : ''}`} data-signal={x.s.id}>
            <Rt r={Math.round(x.v)} />
            <div><b>{x.s.name}{DESIGN.flag[x.s.id] && x.v >= 4 ? <FlagFilled className="rk-flagi" /> : null}</b><span>{x.raw}{ch ? <em> · was {readingOf(c, x.s.id, 'before')?.raw}</em> : x.was && x.was !== x.v ? <em> · was {x.was} 90 days ago</em> : null}</span><a className="sb-ev" onClick={() => onOpen(drillFor(c, x.s.id, fired))}>{SRC_ICON[x.s.src.kind]} {x.s.src.name}</a></div>
            <div className="rk-driver-bar" title={`${x.f.name}`}><i style={{ width: `${Math.max(4, (x.pts / tot) * 100 * 2.2)}%`, background: RATING_COLOR[Math.round(x.v)] }} /><small>{x.f.name}</small></div>
          </div>) })}</div>
        {drivers.length > 7 ? <p className="rk-fixed"><a data-testid="rk-all-drivers" onClick={() => setAllD(!allD)}>{allD ? 'Show the seven that carry most' : `Show all ${drivers.length}`}</a></p> : null}
      </section>

      <section className="rk-sec" data-testid="sb-do">
        <div className="rk-plan-h"><div><h3>Mitigation plan for {shortSite(c)}</h3><p className="rk-sub">{todo.length ? 'For each signal at 3 or 4 that can be moved: what to do at this site, written from its own records. It stands whether or not the score changed.' : 'No signal on this project stands at 3 or 4, so there is nothing to mitigate today.'}</p></div>{todo.length ? at ? <span className="rk-assigned" data-testid="rk-assigned"><CheckOutlined /> Assigned {at}. Owners told.</span> : <Button size="small" type="primary" data-testid="rk-assign" onClick={() => plans.assign(c.id, fired ? '20 Nov' : '19 Nov')}>Assign the plan</Button> : null}</div>
        {todo.length ? <div className="rk-effect" data-testid="rk-effect"><span>If the plan lands</span><b>{f1(eff.from)}</b><ArrowUpOutlined rotate={90} /><b style={{ color: RATING_COLOR[eff.rTo] }}>{f1(eff.to)}</b><span>{eff.rTo < eff.rFrom ? <>rating <Rt r={eff.rFrom} /> to <Rt r={eff.rTo} /></> : flags.length && todo.some((x) => flags.includes(x.s.id)) ? 'the red flag clears when the action lands' : `stays at ${eff.rTo}, with ${f1(eff.from - eff.to)} more room under the line`}</span></div> : null}
        <div className="rk-plan">{todo.map((x) => (
          <div key={x.id} className="rk-act" data-signal={x.s.id}>
            <div className="rk-act-s"><Rt r={Math.round(x.v)} /><ArrowUpOutlined rotate={90} /><Rt r={x.to} /></div>
            <div><small>{x.s.name}</small><p>{x.text}</p>{x.basis ? <span className="rk-basis">Written from: {x.basis.map((b, i) => <a key={i} className="sb-ev" onClick={() => onOpen(drillFor(c, x.s.id, fired))}>{SRC_ICON[b.kind]} {b.text}</a>)}</span> : null}<span><b>{x.owner}</b> · by {x.due} · <em className={at ? 'is-open' : ''}>{at ? 'Open' : 'Proposed'}</em></span></div>
          </div>))}</div>
        {later.length ? <p className="rk-fixed" data-testid="rk-later">{later.length} more {later.length === 1 ? 'signal stands' : 'signals stand'} at 3 or 4 and can wait for the next plan: {later.map((x) => x.s.name.toLowerCase()).join('; ')}.</p> : null}
        {fixed.length ? <p className="rk-fixed"><a onClick={() => setFacts(!facts)}>{fixed.length} {fixed.length === 1 ? 'signal is a fact' : 'signals are facts'} of the site or the contract</a>{facts ? `: ${fixed.map((x) => `${x.s.name.toLowerCase()} (${x.raw.toLowerCase()})`).join('; ')}. Nothing to do today; they are priced and argued at renewal.` : '.'}</p> : null}
        {built ? <p className="rk-fixed"><a onClick={() => onTab('deliverables')}>Open the deck and the plan built this morning</a></p> : null}
      </section>

      {seen.length ? <section className="rk-sec" data-testid="sb-seen">
        <h3>Seen, not scored</h3>
        <p className="rk-sub">What I read about this contract that your scorecard has no signal for.</p>
        {seen.map((x) => { const dr = seenDrill(x.src.ref); const sg = x.sig ? SIGNALS.find((y) => y.id === x.sig) : undefined; return <div className={`rk-seen is-${x.tone}`} key={x.k} data-seen={x.k}><b>{x.label}</b><p>{x.text}</p><a className="sb-ev" onClick={() => onOpen(dr ?? { view: 'contract', contract: c.id, note: '' })}>{SRC_ICON[x.src.kind]} {x.src.name}</a>{sg ? <Button size="small" icon={<PlusOutlined />} data-testid={`rk-add-${sg.id}`} onClick={() => design.adopt([sg.id])}>Score it: add "{sg.name}"</Button> : null}</div> })}
      </section> : null}

      <section className="rk-sec">
        <h3>Every factor</h3>
        {(['internal', 'external'] as const).map((g) => (
          <div key={g} className="rk-fgrp"><small>{g === 'internal' ? 'What we control' : 'What we do not control'} · {f1(groupScore(c, g, w))}{DESIGN.rule === 'avg' ? ' · half of the score' : ''}</small>
            {activeFactors(g).map((f) => { const fs = factorScore(c, f.id, w); if (fs === null) return null; const fb = factorScore(c, f.id, 'before') ?? fs; const open = openF === f.id; return (
              <div key={f.id} className={`rk-f${open ? ' is-open' : ''}`} data-factor={f.id}>
                <button type="button" className="rk-f-row" onClick={() => setOpenF(open ? null : f.id)} aria-expanded={open}><span>{f.name}<small>{(finalShare(f.id) * 100).toFixed(0)}% of the score</small></span><span className="rk-f-bar"><i style={{ width: `${((fs - 1) / 3) * 100}%`, background: RATING_COLOR[ratingOf(fs)] }} /></span><b>{f1(fs)}{moved && Math.abs(fs - fb) > 0.004 ? <ArrowUpOutlined /> : null}</b></button>
                {open ? <div className="rk-f-sigs">{SIGNALS.filter((x) => x.f === f.id && DESIGN.on[x.id] && c.v[x.id]).map((x) => { const v = valOf(c, x.id, w) ?? 1; return <div key={x.id} className="rk-f-sig" data-signal={x.id}><Rt r={Math.round(v)} /><span><b>{x.name}</b> {readingOf(c, x.id, w)?.raw}</span><a className="sb-ev" onClick={() => onOpen(drillFor(c, x.id, fired))}>{SRC_ICON[x.src.kind]}</a></div> })}</div> : null}
              </div>) })}
          </div>))}
      </section>
    </div>
  )
}

const WEB_SHORT: Record<string, string> = { gr: 'Core terms', cr: 'Contract terms', os: 'Safety', en: 'Environment', st: 'Staffing', cu: 'Client', co: 'Community', fp: 'Financial', sl: 'State courts', li: 'Litigation', in: 'Assets', sp: 'Homes nearby', iq: 'Influent', cp: 'Client politics', cl: 'Competitors', rs: 'Resilience' }
/** The web of a site: one spoke per factor, the site against the average of all projects. */
function Web({ c, w }: { c: Contract; w: When }) {
  const av = factorAverages(w).filter((x) => factorScore(c, x.f.id, w) !== null)
  const n = av.length, W = 520, H = 330, cx = W / 2, cy = H / 2 + 4, R = 112
  const pt = (i: number, v: number) => { const a = -Math.PI / 2 + (i / n) * Math.PI * 2, r = ((v - 1) / 3) * R; return [cx + Math.cos(a) * r, cy + Math.sin(a) * r] }
  const poly = (vals: number[]) => vals.map((v, i) => pt(i, v).join(',')).join(' ')
  const mine = av.map((x) => factorScore(c, x.f.id, w) ?? 1)
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" className="rk-web" role="img" aria-label={`Factor scores of ${c.site} against the portfolio average`}>
      {[2, 3, 4].map((v) => <polygon key={v} points={poly(av.map(() => v))} fill="none" stroke={v === 4 ? '#d5dbe5' : '#eceff4'} />)}
      {av.map((x, i) => { const [x2, y2] = pt(i, 4), [lx, ly] = pt(i, 4.75), v = mine[i]; return <g key={x.f.id} data-factor={x.f.id}><line x1={cx} y1={cy} x2={x2} y2={y2} stroke="#eceff4" /><text x={lx} y={ly} textAnchor={Math.abs(lx - cx) < 12 ? 'middle' : lx > cx ? 'start' : 'end'} fontSize="10.5" fill={v >= 3 ? '#c0392b' : '#3b4658'} fontWeight={v >= 3 ? 600 : 400}>{WEB_SHORT[x.f.id] ?? x.f.name} {v.toFixed(1)}</text></g> })}
      <polygon points={poly(av.map((x) => x.avg))} fill="none" stroke="#8a94a6" strokeDasharray="4 3" strokeWidth="1.2" />
      <polygon points={poly(mine)} fill="rgba(226, 129, 42, 0.22)" stroke="#e2812a" strokeWidth="1.8" />
      {mine.map((v, i) => { const [x, y] = pt(i, v); return <circle key={i} cx={x} cy={y} r="3" fill={RATING_COLOR[ratingOf(v)]} stroke="#fff" strokeWidth="0.8" /> })}
      <text x={cx + 3} y={cy - (1 / 3) * R + 3} fontSize="9" fill="#a7b0bf">2</text><text x={cx + 3} y={cy - (2 / 3) * R + 3} fontSize="9" fill="#a7b0bf">3</text><text x={cx + 3} y={cy - R + 3} fontSize="9" fill="#a7b0bf">4</text>
    </svg>
  )
}

/** An earlier version of the dashboard, as it was published. */
function OldVersion({ ver, latest, head, onLatest }: { ver: DashVersion; latest: DashVersion; head: JSX.Element; onLatest: () => void }) {
  const d = ver.snap.dist
  return (
    <div className="rk" data-testid="rk-old">
      {head}
      <div className="rk-fired"><b>This is version {ver.v}, the scoring of {ver.at}{ver.refreshed ? `, last refreshed ${ver.refreshed}` : ''}.</b> {ver.why}. The scoring in force is version {latest.v}. <a data-testid="rk-latest" onClick={onLatest}>Open the latest</a></div>
      <div className="rk-kpis">
        <div className="rk-kpi"><small>Rated 3 or 4</small><b>{ver.snap.n34}</b><span>{m1(ver.snap.revenue34)} a year</span><div className="rk-mini">{[1, 2, 3, 4].map((r) => d[r] ? <i key={r} style={{ flex: d[r], background: RATING_COLOR[r] }} /> : null)}</div></div>
        <div className="rk-kpi"><small>High risk with a lot at stake</small><b>{ver.snap.act}</b><span>at that version</span></div>
        <div className="rk-kpi"><small>Scored on</small><b>{ver.snap.signals}</b><span>signals in {ver.snap.factors} factors</span></div>
      </div>
      <div className="rk-dist">{[1, 2, 3, 4].map((r) => <span key={r}><i style={{ background: RATING_COLOR[r] }} />{RATING_NAME[r]} <b>{d[r]}</b></span>)}</div>
      <section className="rk-sec"><h3>The ten highest scores at version {ver.v}</h3><div className="rk-tbl-wrap"><table className="rk-tbl is-plain"><thead><tr><th>Project</th><th className="c">Rating</th><th className="n">Score</th></tr></thead><tbody>{ver.snap.top.map((x) => <tr key={x.id}><td><b>{x.site}</b><small>{x.id}</small></td><td className="c"><Rt r={x.r} /></td><td className="n">{f1(x.s)}</td></tr>)}</tbody></table></div></section>
    </div>
  )
}

/** The same dashboard, opened from Submissions. Evidence and the plan open in the goal it belongs to. */
export function DashEmbed({ journeyId, onLeave }: { journeyId?: string; onLeave?: () => void }) {
  const j = useJourney((st) => (journeyId ? st.goals[journeyId] : undefined))
  const navigate = useNavigate()
  if (!j) return <p className="rk-sub">The goal this dashboard belongs to is not open in this session.</p>
  const go = () => { onLeave?.(); navigate(appPath(`/goals/${j.id}`)) }
  return <div className="dash-embed" data-testid="dash-embed"><p className="rk-sub">This is the live dashboard of the goal “{j.title}”. <a onClick={go}>Open the goal</a> to edit the scoring or to open the evidence behind a reading.</p><RiskBoard j={j} onOpen={go} onTab={go} embedded /></div>
}
