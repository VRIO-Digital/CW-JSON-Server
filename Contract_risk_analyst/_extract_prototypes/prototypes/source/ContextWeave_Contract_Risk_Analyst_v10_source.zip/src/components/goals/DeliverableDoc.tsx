import { DownloadOutlined, EditOutlined, FileExcelOutlined, FileImageOutlined, FilePdfOutlined, FilePptOutlined, FileTextOutlined, TableOutlined } from '@ant-design/icons'
import { App, Button, Dropdown, Typography } from 'antd'
import { useRef } from 'react'
import type { Drill, Goal } from '../../data/goalCases'
import { download } from '../../data/drill'
import { downloadPptx } from '../../data/pptxExport'
import { nodeToPng, printNode } from '../../data/rasterize'
import { visualForFormat } from '../../data/visuals'
import { buildDraft, FORMAT_ICON, FORMAT_LABEL, VisualBlock } from '../../pages/SubmissionsPage'
import type { Submission } from '../../store/submissionStore'
import '../../pages/SubmissionDoc.css'
import '../../pages/SubmissionsHub.css'

const { Paragraph } = Typography

/** A slide shows its point, not its paragraph: the first three sentences or lines, each kept short. */
const bullets = (body: string) => body.split(/\n+/).flatMap((l) => l.split(/(?<=[.!?])\s+(?=[A-Z$"(0-9])/)).map((x) => x.replace(/^[•\-\d.\s]+/, '').trim()).filter((x) => x.length > 3).slice(0, 3).map((x) => (x.length > 120 ? `${x.slice(0, x.lastIndexOf(' ', 118))}…` : x))

/** The files a deliverable downloads as, by its format: the real artefact, never a description of one. */
export function useDownloads(x: Submission | null, goal: Goal | null, canvas: React.RefObject<HTMLDivElement | null>) {
  const { message } = App.useApp()
  if (!x) return []
  const inc = x.sections.filter((y) => y.included)
  const dl = {
    html: { key: 'html', icon: <FileTextOutlined />, label: 'HTML page', run: () => download(`${x.id}.html`, buildDraft(x), 'text/html') },
    pdf: { key: 'pdf', icon: <FilePdfOutlined />, label: 'PDF', run: () => { if (canvas.current) printNode(canvas.current) } },
    png: { key: 'png', icon: <FileImageOutlined />, label: 'Image (PNG)', run: async () => { if (!canvas.current) return; try { await nodeToPng(canvas.current, `${x.id}.png`); message.success('Image saved.') } catch { message.error('Could not render the image; use PDF.') } } },
    pptx: { key: 'pptx', icon: <FilePptOutlined />, label: 'PowerPoint (.pptx)', run: async () => { const h = message.loading('Building the PowerPoint…', 0); try { await downloadPptx(x, goal, inc); message.success('PowerPoint saved.') } catch { message.error('Could not build the PowerPoint.') } finally { h() } } },
    csv: { key: 'csv', icon: <FileExcelOutlined />, label: 'CSV', run: () => download(`${x.id}.csv`, ['sheet,row,text', ...inc.flatMap((y) => (y.body || '').split('\n').filter(Boolean).map((row, i) => `"${y.heading.replace(/"/g, '""')}",${i + 1},"${row.replace(/"/g, '""')}"`))].join('\n'), 'text/csv') },
  }
  return x.format === 'Slide pack' ? [dl.pptx, dl.pdf] : x.format === 'Dashboard' ? [dl.pdf, dl.png] : x.format === 'Workbook' ? [dl.csv, dl.pdf] : x.format === 'Email' ? [dl.html] : [dl.pdf, dl.html]
}

/** A deliverable as built, read-only, with its downloads and the way into Submissions to edit it. */
export default function DeliverableDoc({ s, goal, onEdit, onDrill, drillFor, shown }: { s: Submission; goal: Goal | null; onEdit?: () => void; onDrill?: (d: Drill) => void; drillFor?: (heading: string) => Drill | null; shown?: number }) {
  const canvas = useRef<HTMLDivElement>(null)
  const downloads = useDownloads(s, goal, canvas)
  const all = s.sections.filter((y) => y.included)
  const building = typeof shown === 'number' && shown < all.length
  const inc = typeof shown === 'number' ? all.slice(0, shown) : all
  const unit = s.format === 'Slide pack' ? 'slide' : s.format === 'Workbook' ? 'sheet' : s.format === 'Dashboard' ? 'panel' : 'section'
  const fmt = s.format.replace(' ', '-').toLowerCase()
  return (
    <div className="dd" data-testid="deliverable" data-sub={s.id}>
      <div className="dd-bar">
        <span className="dd-meta">{FORMAT_ICON[s.format]} {FORMAT_LABEL[s.format]} · version {s.version ?? 1} · on {s.basis ?? 'the findings'}</span>
        {typeof shown === 'number' ? <span className="dd-acts"><span className="bld-note">{building ? `Writing ${unit} ${inc.length + 1} of ${all.length}` : 'Done'}</span></span> : <span className="dd-acts">
          {downloads.length === 1 ? <Button size="small" icon={downloads[0].icon} onClick={() => void downloads[0].run()}>Download</Button>
            : <Dropdown trigger={['click']} menu={{ items: downloads.map((d) => ({ key: d.key, icon: d.icon, label: d.label, onClick: () => void d.run() })) }}><Button size="small" icon={<DownloadOutlined />}>Download</Button></Dropdown>}
          {onEdit ? <Button size="small" icon={<EditOutlined />} onClick={onEdit}>Edit in Submissions</Button> : null}
        </span>}
      </div>
      <div className="dd-sub">For {s.audience} · on the template “{s.template.replace(/^[^:]+:\s*/, '').replace(/\.(xlsx|pptx|docx)$/i, '')}”</div>
      <div className="hp-canvas">
        <div ref={canvas} className={`sd-canvas is-${fmt}`}>
          <div className="sd-print-title">{s.title}<div>To {s.audience} · {FORMAT_LABEL[s.format]} · version {s.version ?? 1}</div></div>
          {inc.map((y, i) => {
            const v = goal && y.body.trim() ? visualForFormat(goal, y.role, y.heading, s.format) : null
            void i
            const d = drillFor?.(`${y.heading} ${y.body.slice(0, 200)}`) ?? null
            return (
              <div key={y.id} className={`sd-part is-${fmt}`}>
                <div className="sd-part-head"><span className="sd-n">{s.format === 'Slide pack' ? `${i + 1} / ${all.length}` : i + 1}</span><div className="sd-h">{y.heading}</div>{d && onDrill ? <span className="sd-tools no-print"><TableOutlined onClick={() => onDrill(d)} /></span> : null}</div>
                {!y.body.trim() ? <Paragraph className="sd-text" style={{ color: '#a15c00' }}>Nothing in the analysis covers this part; write it in Submissions.</Paragraph>
                  : v ? (s.format === 'Dashboard'
                    ? <div className="sd-dash-body"><div className="sd-slide-vis"><VisualBlock v={v} compact /></div><Paragraph className="sd-text sd-clamp">{y.body}</Paragraph></div>
                    : <div className="sd-slide-body">{s.format === 'Slide pack' ? <ul className="sd-text sd-bullets">{bullets(y.body).map((b, k) => <li key={k}>{b}</li>)}</ul> : <Paragraph className="sd-text">{y.body}</Paragraph>}<div className="sd-slide-vis"><VisualBlock v={v} compact /></div></div>)
                  : <Paragraph className="sd-text">{y.body}</Paragraph>}
                {y.body.trim() ? <div className="sd-from no-print">↳ {y.from}{d && onDrill ? <> · <a onClick={() => onDrill(d)}>open the data</a></> : null}</div> : null}
              </div>
            )
          })}
          {building ? <div className="sd-building no-print bld-next"><span className="st-pulse" /> {all[inc.length]?.heading ?? ''}: reading the findings and writing it…</div> : null}
        </div>
      </div>
    </div>
  )
}
