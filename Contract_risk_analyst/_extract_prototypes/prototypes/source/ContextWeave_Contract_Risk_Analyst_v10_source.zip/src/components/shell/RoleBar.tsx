import { DownOutlined, SolutionOutlined } from '@ant-design/icons'
import { Popover, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'
import { appPath } from '../../api/dataset'
import { useGoalStore } from '../../store/goalStore'
import { useSubmissionStore } from '../../store/submissionStore'
import { AgentBadge, NotificationBell } from '../goals/parts'
import './RoleBar.css'

const { Text } = Typography

/*
 * The role the workspace is playing, always on top. A role is what used to be called a use case: the
 * analyst Context Weave stands in for, with the data it reads, its graph, its agents and its
 * templates. Northline Water Group has the Contract Risk Analyst in use; opening it shows what it covers.
 */

export const ROLE = {
  name: 'Contract Risk Analyst',
  org: 'Northline Water Group',
  does: 'Runs the capital program for four regulated water utilities: budgets, forecasts, spend, commitments, change orders, in-service dates for the rate cases, and the decisions they need.',
  covers: '4,500 capital projects · 3,768 approved · FY26 plan $1.18B · four state commissions',
  graph: 'Contract Risk Analyst graph v1 · published 10 Nov',
  reads: [
    'EPBCS: plan of record, plan vintages and the monthly working forecast',
    'PeopleSoft: posted ledger, commitments and WIN budget revisions',
    'PMO project master and the governed in-service date file',
    'OneDrive: 21 documents (decks, contracts, orders, minutes) · Outlook: 12 threads',
  ],
}

export default function RoleBar() {
  const navigate = useNavigate()
  const goals = useGoalStore((s) => s.goals)
  const templates = useSubmissionStore((s) => s.templates.length)
  const agents = [...new Map(goals.map((g) => [g.agent.name, g.agent])).values()]

  const card = (
    <div className="rb-card">
      <Text style={{ display: 'block', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.4, color: '#8994a8' }}>Role · {ROLE.org}</Text>
      <Text style={{ display: 'block', fontSize: 16, fontWeight: 500, margin: '2px 0 6px' }}>{ROLE.name}</Text>
      <Text style={{ display: 'block', fontSize: 13 }}>{ROLE.does}</Text>
      <div className="rb-kv">
        <span>Covers</span><span>{ROLE.covers}</span>
        <span>Graph</span><span>{ROLE.graph}</span>
        <span>Reads</span><span>{ROLE.reads.map((r) => <span key={r} style={{ display: 'block' }}>{r}</span>)}</span>
        <span>Agents</span>
        <span className="rb-agents">{agents.map((a) => <span key={a.name} role="link" onClick={() => { const g = goals.find((x) => x.agent.name === a.name); if (g) navigate(appPath(`/goals/${g.id}`)) }}><AgentBadge agent={a} /></span>)}</span>
        <span>Goals</span><span>{goals.length} · <a onClick={() => navigate(appPath('/goals'))}>open</a></span>
        <span>Templates</span><span>{templates} · <a onClick={() => navigate(appPath('/submissions'), { state: { tab: 'templates' } })}>open</a></span>
      </div>
      <Text type="secondary" style={{ display: 'block', fontSize: 11.5, marginTop: 10 }}>The role in use for this tenant. New roles, and new versions of this one, are set up under New Role.</Text>
    </div>
  )

  return (
    <div className="rb">
      <Popover content={card} trigger="click" placement="bottomLeft" arrow={false}>
        <span className="rb-role" role="button" tabIndex={0} aria-label={`Role: ${ROLE.name}`}>
          <SolutionOutlined className="rb-icon" />
          <span className="rb-label">Role</span>
          <span className="rb-name">{ROLE.name}</span>
          <span className="rb-org">· {ROLE.org}</span>
          <DownOutlined style={{ fontSize: 10, color: '#8994a8' }} />
        </span>
      </Popover>
      <NotificationBell />
    </div>
  )
}
