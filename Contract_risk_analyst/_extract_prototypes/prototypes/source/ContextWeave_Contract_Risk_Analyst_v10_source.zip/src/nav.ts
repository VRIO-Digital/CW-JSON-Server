import {
  // ApartmentOutlined,
  // CheckCircleOutlined,
  DatabaseOutlined,
  DeploymentUnitOutlined,
  AimOutlined,
  // ExperimentOutlined,
  FileTextOutlined,
  // LineChartOutlined,
  PlusOutlined,
  RobotOutlined,
  SafetyCertificateOutlined,
  SettingOutlined,
  TableOutlined,
  QuestionCircleOutlined,
} from '@ant-design/icons'
import type { ComponentType } from 'react'

export type NavKey =
  | 'new-graph'
  | 'ask'
  | 'goals'
  | 'reports'
  | 'sources'
  | 'catalog'
  | 'graph-builds'
  | 'graph-studio'
  | 'what-if'
  | 'ai-submissions'
  | 'settings'
  | 'trace'
  | 'validation'
  | 'feedback'
  | 'audit'
  | 'db'

/**
 * The three things a persona comes here to do, in the order it does them.
 *
 * **A group is a heading, never a permission.** `visibleNavItems` still decides item by item what a
 * persona sees, and the sidebar draws a heading only where something under it survived that filter —
 * a lone `EXPLORE` over nothing would read as a section that failed to load rather than as one the
 * persona may not open. Adding a group means adding it here *and* naming it on the items, because
 * an item whose group is not in this list has no heading to sit under and would fall off the menu.
 */
export type NavGroup = 'Explore' | 'Build & Configure' | 'Trust & Operations'

export const NAV_GROUPS: NavGroup[] = [
  'Explore',
  'Build & Configure',
  'Trust & Operations',
]

export interface NavItem {
  key: NavKey
  label: string
  path: string
  icon: ComponentType
  group: NavGroup
  /** A small word or two under the label, for an entry whose name alone does not say who does the work. */
  caption?: string
}

/*
 * The list is in group order, so the sidebar, the Settings permission rows and the seed's `NAV_KEYS`
 * all read in the order a reader sees on screen. `check-docs` compares this order to the seed's
 * literally, so reordering here means reordering there and re-running `npm run seed:settings`.
 */
/* A build can carry one journey only (VITE_CW_ONLY=goals|submissions): the other entry leaves the menu and the landing follows. */
const ONLY = (import.meta as unknown as { env: Record<string, string | undefined> }).env?.VITE_CW_ONLY
const NAV_ALL: NavItem[] = [
  /* ---------- Explore — reading what the graph already answers. ---------- */
  {
    key: 'reports',
    label: 'Reports',
    path: '/reports',
    icon: FileTextOutlined,
    group: 'Explore',
  },
  {
    key: 'ask',
    label: 'Ask',
    path: '/ask',
    icon: QuestionCircleOutlined,
    group: 'Explore',
  },
  {
    key: 'goals',
    label: 'Goals',
    caption: 'by my agents',
    path: '/goals',
    icon: AimOutlined,
    group: 'Explore',
  },
  /*
   * A fixed showcase page rather than a computed one — see `AISubmissionsPage` for why it is gated
   * on nothing. Last in Explore because it reads no source and no graph, unlike the three above it.
   */
  {
    key: 'ai-submissions',
    label: 'Submissions',
    caption: 'by my agents',
    path: '/submissions',
    icon: RobotOutlined,
    group: 'Explore',
  },

  /* ---------- Build & Configure — everything upstream of a published graph. ---------- */
  {
    key: 'new-graph',
    label: 'New Role',
    path: '/new-graph',
    icon: PlusOutlined,
    group: 'Build & Configure',
  },
  {
    key: 'sources',
    label: 'Sources',
    path: '/sources',
    icon: DatabaseOutlined,
    group: 'Build & Configure',
  },
  {
    key: 'catalog',
    label: 'Data Catalog',
    path: '/catalog',
    icon: TableOutlined,
    group: 'Build & Configure',
  },
  // Commented out, not deleted — both want BuildOutlined back when they land.
  // { key: 'graph-builds', label: 'Graph Builds', path: '/graph-builds', icon: BuildOutlined, group: 'Build & Configure' },
  {
    key: 'graph-studio',
    label: 'Graph Studio',
    path: '/graph-studio',
    icon: DeploymentUnitOutlined,
    group: 'Build & Configure',
  },

  /* ---------- Trust & Operations — who sees what, and who may change it. ---------- */
  /*
   * Who sees what, and what this server has recorded about it. Sits beside Settings because the two
   * administer different halves of the same question — Settings decides which *pages* a persona
   * reaches, this decides which *rows* it may see and who a published artifact was shared with.
   */
  {
    key: 'audit',
    label: 'Audit & Governance',
    path: '/audit',
    icon: SafetyCertificateOutlined,
    group: 'Trust & Operations',
  },
  /*
   * Users and persona access. Last on purpose — it is the one entry that configures the others, and a
   * sidebar reads better with the thing that changes it at the bottom.
   *
   * **This list is also what Settings configures.** `PERMISSION_KEYS` is derived from it rather than
   * written again, so an entry added here gains a permission row for free, and a permission row can
   * never name an item the sidebar does not have.
   */
  {
    key: 'settings',
    label: 'Settings',
    path: '/settings',
    icon: SettingOutlined,
    group: 'Trust & Operations',
  },
  // {
  //   key: 'trace',
  //   label: 'Trace & Observability',
  //   path: '/trace',
  //   icon: LineChartOutlined,
  //   group: 'Trust & Operations',
  // },
  // {
  //   key: 'validation',
  //   label: 'Validation & Evals',
  //   path: '/validation',
  //   icon: CheckCircleOutlined,
  //   group: 'Trust & Operations',
  // },
  // {
  //   key: 'feedback',
  //   label: 'Feedback & Learning',
  //   path: '/feedback',
  //   icon: ApartmentOutlined,
  //   group: 'Trust & Operations',
  // },

  // Dev tool — routed, reachable by URL only.
  // { key: 'db', label: 'Mock Data', path: '/db', icon: BuildOutlined, group: 'Build & Configure' },
]

/**
 * Where a sign-in with no particular destination lands, and where a bare `/` goes.
 *
 * Here rather than in either reader, because both are route decisions and each used to hold its own
 * copy — two answers to "where does no particular page go" send a fresh sign-in and a bare `/` to
 * different places. In `nav.ts` rather than `routes.tsx` so `LoginPage` can read it without the two
 * modules importing each other.
 *
 * Dataset-relative: `appPath` and `DatasetRedirect` put the selected dataset's letter on the front.
 */
/**
 * The two words on the sidebar's collapse control.
 *
 * Here rather than inline in the component for the reason every other pair of act labels is in
 * `src/data/`: they are the only thing telling a reader what the chevron does, and the collapsed
 * rail is one button with no text beside it — so the label *is* the affordance, and it has to be
 * assertable without rendering the shell's own state.
 */
export const NAV_COLLAPSE_LABEL = 'Hide navigation'
export const NAV_EXPAND_LABEL = 'Show navigation'

/* roles: only New Role and Graph Studio of the journeys (Goals and Submissions leave the menu). */
export const NAV_ITEMS: NavItem[] = NAV_ALL.filter((n) => !(ONLY === 'goals' && n.key === 'ai-submissions') && !(ONLY === 'submissions' && n.key === 'goals') && !(ONLY === 'roles' && (n.key === 'goals' || n.key === 'ai-submissions')))
export const LANDING = ONLY === 'submissions' ? '/submissions' : ONLY === 'roles' ? '/new-graph' : '/goals'
