import { useLocation } from 'react-router-dom'
import { splitDatasetPath } from '../api/dataset'
import { NAV_ITEMS } from '../nav'

/* Sources and Data Catalog stay in the menu for orientation; this prototype does not redesign them. */
export default function BlankPage() {
  const { pathname } = useLocation()
  const route = splitDatasetPath(pathname).rest
  const item = NAV_ITEMS.find((i) => route.startsWith(i.path))
  return (
    <div style={{ maxWidth: 1080, margin: '0 auto' }}>
      <h2 style={{ margin: 0, fontSize: 24, fontWeight: 600, letterSpacing: -0.4, color: '#18212f' }}>{item?.label ?? 'Not in this prototype'}</h2>
      <p style={{ margin: '6px 0 0', color: '#98a2b3', fontSize: 14 }}>Not part of this prototype</p>
    </div>
  )
}
