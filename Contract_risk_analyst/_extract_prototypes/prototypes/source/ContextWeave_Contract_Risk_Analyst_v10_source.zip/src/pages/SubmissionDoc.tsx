import { ApartmentOutlined, ArrowLeftOutlined, BulbOutlined, CheckOutlined, CopyOutlined, DownloadOutlined, EditOutlined, FileExcelOutlined, FileImageOutlined, FilePdfOutlined, FilePptOutlined, FileTextOutlined, HolderOutlined, LinkOutlined, MessageOutlined, PlusOutlined, ReloadOutlined, ShareAltOutlined, TableOutlined, UploadOutlined } from '@ant-design/icons'
import { App, Button, Checkbox, Drawer, Dropdown, Flex, Input, Modal, Row, Col, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { appPath } from '../api/dataset'
import ChatPane from '../components/goals/ChatPane'
import DataExplorer from '../components/goals/DataExplorer'
import '../components/goals/ChatPane.css'
import { DRILL, download } from '../data/drill'
import type { Drill, Goal } from '../data/goalCases'
import { designOutline, formatInfo, roleOf, OUTPUT_FORMATS } from '../data/outputDesigner'
import { downloadPptx } from '../data/pptxExport'
import { nodeToPng, printNode } from '../data/rasterize'
import { describeRead, readUpload } from '../data/readFile'
import { bestMatch, interpretSub, smsg, templateFromRead, useSubChat } from '../data/subChat'
import type { Template } from '../data/submissionTemplates'
import { LINEAGE, visualFor } from '../data/visuals'
import { useAuthStore } from '../store/authStore'
import { useGoalStore } from '../store/goalStore'
import { suggestFill, useSubmissionStore, type Section, type Submission } from '../store/submissionStore'
import { SP, STATUS } from '../theme'
import { FORMAT_ICON, FORMAT_LABEL, TemplateCard, VisualBlock, buildDraft, short } from './SubmissionsPage'
import './SubmissionDoc.css'

const { Text, Paragraph } = Typography

/*
 * A submission as one surface: the document itself, as the reader will see it, from the first second.
 * The brief is the title line, the template a "Built on" label, the outline the numbered rail on the left,
 * review a button. The agent works inside the document (where each part came from, an offer on every
 * empty part, instructions scoped to the part you picked) and keeps a slim thread on the right.
 */

const NEUTRAL = { name: 'Your agents', icon: 'bulb', colour: '#4b5a75' }

/** Which finding a section leans on, for "open the data". */
const drillFor = (g: Goal | null, x: Section): Drill | null => {
  if (!g || !g.findings.length) return null
  const f = bestMatch(`${x.heading} ${x.body.slice(0, 200)}`, g.findings, (y) => `${y.headline} ${y.detail}`) ?? g.findings[0]
  return f.drill
}

export default function SubmissionDoc({ s }: { s: Submission }) {
  const navigate = useNavigate()
  const location = useLocation()
  const me = useAuthStore((st) => st.identity?.name) ?? 'You'
  const { message } = App.useApp()
  const { update, setSections, applyTemplate, saveOutlineAsTemplate, addTemplate, templates } = useSubmissionStore()
  const allGoals = useGoalStore((st) => st.goals)
  const goals = s.goalIds.map((id) => allGoals.find((g) => g.id === id)).filter(Boolean) as Goal[]
  const g0 = goals[0] ?? null
  const agent = (g0?.agent ?? NEUTRAL) as Goal['agent']
  const info = formatInfo(s.format)
  const unit = info.unit
  const Unit = unit.charAt(0).toUpperCase() + unit.slice(1)
  const tpl = templates.find((t) => t.id === s.templateId)
  const included = s.sections.filter((x) => x.included)
  const empties = included.filter((x) => !x.body.trim())
  const isLive = s.format === 'Dashboard'
  const reviewed = s.stage === 'reviewed'

  const [sel, setSel] = useState<string | null>(null)
  const [editing, setEditing] = useState<string | null>(null)
  const [drill, setDrill] = useState<Drill | null>(null)
  const [sharing, setSharing] = useState(false)
  const [lineage, setLineage] = useState(false)
  const [picking, setPicking] = useState(false)
  const [saveName, setSaveName] = useState<string | null>(null)
  const [pendingUpload, setPendingUpload] = useState<Template | null>(null)
  const [refreshedAt, setRefreshedAt] = useState(() => new Date())
  const [threadOpen, setThreadOpen] = useState(true)
  /* Text selected in the draft: the pill that offers to change it, and the quote the next message is about. */
  const [pill, setPill] = useState<null | { id: string; text: string; x: number; y: number }>(null)
  const [quote, setQuote] = useState<null | { id: string; text: string }>(null)
  const fresh = !!(location.state as { fresh?: boolean } | null)?.fresh
  const [shown, setShown] = useState(fresh ? 0 : Number.MAX_SAFE_INTEGER)
  const canvasRef = useRef<HTMLDivElement>(null)
  const attachRef = useRef<HTMLInputElement>(null)
  const dragFrom = useRef<string | null>(null)
  const chat = useSubChat((st) => st.chats[s.id]) ?? []
  const typing = useSubChat((st) => !!st.typing[s.id])
  const sayA = (t: string) => useSubChat.getState().say(s.id, 'agent', t)
  const shareUrl = `${window.location.href.split('#')[0]}#${appPath(`/submissions/${s.id}`)}`
  const selSec = s.sections.find((x) => x.id === sel) ?? null
  const numOf = (id: string) => s.sections.findIndex((x) => x.id === id) + 1

  const summary = (x: Submission) => {
    const inc = x.sections.filter((y) => y.included)
    const emp = x.sections.map((y, i) => ({ y, i })).filter(({ y }) => y.included && !y.body.trim())
    return `${inc.length} ${unit}s, ${inc.length - emp.length} filled from ${goals.length ? `"${goals[0].title}"` : 'the goal'}${emp.length ? `, ${emp.length} empty: ${emp.map(({ y, i }) => `${i + 1} (${y.heading})`).join(', ')}` : ''}.\n\nClick a ${unit} to work on it, or tell me what to change.${emp.length ? '' : ' When it reads right, mark it as reviewed.'}`
  }

  /* Open the thread; on a fresh document, build it part by part while the agent says what went where. */
  useEffect(() => {
    const c = useSubChat.getState()
    if (fresh) {
      c.reset(s.id, [smsg('agent', `Building the ${FORMAT_LABEL[s.format].toLowerCase()} for ${(s.audience || 'its reader').replace(/^The /, 'the ')}${tpl ? ` on "${tpl.name}"` : ''}.`)])
      const inc = s.sections.filter((x) => x.included)
      inc.forEach((x, i) => window.setTimeout(() => {
        setShown(i + 1)
        useSubChat.getState().say(s.id, 'event', `${Unit} ${i + 1} · ${x.body.trim() ? `filled from ${x.from}` : 'empty, nothing in the goal covers it yet'}`)
        if (i === inc.length - 1) window.setTimeout(() => { setShown(Number.MAX_SAFE_INTEGER); useSubChat.getState().say(s.id, 'agent', summary(useSubmissionStore.getState().submissions.find((y) => y.id === s.id) ?? s)) }, 500)
      }, 500 + i * 550))
      navigate(location.pathname, { replace: true, state: null })
    } else if (!c.chats[s.id]?.length) {
      c.reset(s.id, [smsg('agent', inSetup ? stepMsg(step) : summary(s))])
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /* Changes after review reopen it. */
  const touched = () => { if (useSubmissionStore.getState().submissions.find((y) => y.id === s.id)?.stage === 'reviewed') { update(s.id, { stage: 'draft', reviewedBy: undefined }, me, 'Changed after review; reopened.'); sayA('That changed it after review, so it is open again.') } }
  const setSec = (id: string, p: Partial<Section>, silent = false) => { setSections(s.id, useSubmissionStore.getState().submissions.find((y) => y.id === s.id)!.sections.map((x) => (x.id === id ? { ...x, ...p } : x))); if (!silent) touched() }
  const fill = (x: Section) => { const f = suggestFill(goals, x.role, x.heading); if (!f.body) return false; setSec(x.id, { body: f.body, from: f.from }); return true }

  /* ---------------- set-up: the journey before the draft, on the same surface */
  type Step = 'goal' | 'brief' | 'structure' | 'outline'
  const STEPS: { key: Step; label: string; stage: Submission['stage'] }[] = [
    { key: 'goal', label: 'What it draws on', stage: 'brief' },
    { key: 'brief', label: 'Who it is for', stage: 'brief' },
    { key: 'structure', label: 'Structure', stage: 'template' },
    { key: 'outline', label: 'Outline', stage: 'outline' },
  ]
  const inSetup = s.stage === 'brief' || s.stage === 'template' || s.stage === 'outline'
  const [step, setStepRaw] = useState<Step>(s.stage === 'template' ? 'structure' : s.stage === 'outline' ? 'outline' : 'goal')
  const [reached, setReached] = useState<number>(STEPS.findIndex((x) => x.key === (s.stage === 'template' ? 'structure' : s.stage === 'outline' ? 'outline' : 'goal')))
  const [describeText, setDescribeText] = useState(s.brief?.description && s.brief.description !== 'Started blank, written by hand.' ? s.brief.description : '')
  const [libOpen, setLibOpen] = useState(false)
  const readyGoals = allGoals.filter((g) => g.findings.length)
  const stepIdx = STEPS.findIndex((x) => x.key === step)
  const stepMsg = (k: Step, x: Submission = s): string => {
    const gs = x.goalIds.map((id) => allGoals.find((g) => g.id === id)).filter(Boolean) as Goal[]
    const t = templates.find((y) => y.id === x.templateId)
    const inc = x.sections.filter((y) => y.included)
    const emp = inc.filter((y) => !y.body.trim())
    switch (k) {
      case 'goal': return gs.length ? `This ${FORMAT_LABEL[x.format].toLowerCase()} draws on ${gs.map((g) => `"${g.title}" (${g.agent.name}: ${g.findings.length} findings, ${g.recommendations.length} recommendations)`).join(' and ')}.\n\nIs that the right analysis? Tick another goal on the left to add it, or say "next".` : 'Which analysis does it draw on? Pick a goal with findings.'
      case 'brief': return `Who reads it, and what should they decide? It says ${x.audience ? `"${x.audience}"` : 'nobody yet'}${x.purpose ? ` and "${x.purpose}"` : ''}. Change it on the left or say "for …", "purpose …". Then "next".`
      case 'structure': return t ? `It is built on "${t.name}" (${t.sections.length} parts)${x.origin === 'recommendation' ? `, which ${x.agentName ?? 'the agent'} recommended because it is in your library` : ''}. Keep it, pick another template, use your own file, describe the structure in words, or start blank. Say "next" to see the outline.` : `The structure comes from ${x.brief?.description === 'Started blank, written by hand.' ? 'the usual parts of a ' + FORMAT_LABEL[x.format].toLowerCase() : 'your description'}: ${inc.length} parts. Keep it, pick a library template, use your own file, or describe it again. Say "next" to see the outline.`
      case 'outline': return `${inc.length} parts: ${inc.length - emp.length} I fill from the goal${emp.length ? `, ${emp.length} you write (${emp.map((y) => y.heading).join('; ')})` : ''}. Untick, rename, reorder or add parts. When it is right, say "build the draft".`
    }
  }
  const setStep = (k: Step, quiet = false) => {
    const i = STEPS.findIndex((x) => x.key === k)
    setStepRaw(k)
    setReached((r) => Math.max(r, i))
    const st = STEPS[i].stage
    if (useSubmissionStore.getState().submissions.find((y) => y.id === s.id)?.stage !== st) update(s.id, { stage: st })
    if (!quiet) { useSubChat.getState().say(s.id, 'event', `${i + 1} · ${STEPS[i].label}`); window.setTimeout(() => sayA(stepMsg(k, useSubmissionStore.getState().submissions.find((y) => y.id === s.id) ?? s)), 50) }
  }
  const toggleGoal = (g: Goal) => {
    const x = useSubmissionStore.getState().submissions.find((y) => y.id === s.id)!
    const ids = x.goalIds.includes(g.id) ? x.goalIds.filter((i) => i !== g.id) : [...x.goalIds, g.id]
    if (!ids.length) { sayA('It has to draw on at least one goal.'); return }
    const gs = ids.map((i) => allGoals.find((y) => y.id === i)).filter(Boolean) as Goal[]
    update(s.id, { goalIds: ids, fromGoal: { id: gs[0].id, title: gs[0].title } }, me, `Draws on ${gs.map((y) => y.title).join('; ')}.`)
    const t = templates.find((y) => y.id === x.templateId)
    if (t) applyTemplate(s.id, t, gs, me)
    else setSections(s.id, x.sections.map((y) => { const f = suggestFill(gs, y.role, y.heading); return y.from === 'You' && y.body.trim() ? y : { ...y, body: f.body, from: f.body ? f.from : 'You' } }))
    sayA(`${x.goalIds.includes(g.id) ? 'Removed' : 'Added'} "${g.title}". It now draws on ${gs.length} goal${gs.length === 1 ? '' : 's'}; the parts are refilled.`)
  }
  const structureFrom = (format: Submission['format'], words: string, blank = false) => {
    const p = designOutline(format, words, g0 ?? undefined)
    const sections: Section[] = p.sections.map((y, i) => { const f = blank ? { body: '', from: 'You' } : suggestFill(goals, y.role, `${y.heading} ${y.hint ?? ''}`); return { id: `d-${i}-${Date.now().toString(36)}`, heading: y.heading, role: y.role, included: true, body: f.body, from: f.body ? f.from : y.hint ? `You · ${y.hint}` : 'You' } })
    update(s.id, { templateId: undefined, template: `${FORMAT_LABEL[format]}, ${blank ? 'blank' : 'defined from your description'}`, origin: 'described', format, brief: { format, description: blank ? 'Started blank, written by hand.' : words, reading: p.reading }, sections }, me, blank ? 'Started blank.' : 'Structure read from a description.')
    return p
  }
  const build = () => {
    update(s.id, { stage: 'draft' }, me, 'Built the draft.')
    setSel(null)
    setShown(0)
    const inc = (useSubmissionStore.getState().submissions.find((y) => y.id === s.id) ?? s).sections.filter((y) => y.included)
    useSubChat.getState().say(s.id, 'event', 'Draft')
    sayA(`Building the ${FORMAT_LABEL[s.format].toLowerCase()}, part by part.`)
    inc.forEach((y, i) => window.setTimeout(() => {
      setShown(i + 1)
      useSubChat.getState().say(s.id, 'event', `${Unit} ${i + 1} · ${y.body.trim() ? `filled from ${y.from}` : 'empty, for you to write'}`)
      if (i === inc.length - 1) window.setTimeout(() => { setShown(Number.MAX_SAFE_INTEGER); sayA(summary(useSubmissionStore.getState().submissions.find((z) => z.id === s.id) ?? s)) }, 500)
    }, 400 + i * 450))
  }

  const select = (id: string | null) => {
    setSel(id)
    if (id) window.setTimeout(() => document.getElementById(`doc-${id}`)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }), 30)
  }

  /* Downloads, by format. */
  const dl = {
    html: { key: 'html', icon: <FileTextOutlined />, label: 'HTML page', run: () => download(`${s.id}_DRAFT.html`, buildDraft(s), 'text/html') },
    pdf: { key: 'pdf', icon: <FilePdfOutlined />, label: 'PDF', run: () => { if (canvasRef.current) printNode(canvasRef.current) } },
    png: { key: 'png', icon: <FileImageOutlined />, label: 'Image (PNG)', run: async () => { if (!canvasRef.current) return; try { await nodeToPng(canvasRef.current, `${s.id}.png`); message.success('Image saved.') } catch { message.error('Could not render the image in this browser; use PDF.') } } },
    pptx: { key: 'pptx', icon: <FilePptOutlined />, label: 'PowerPoint (.pptx)', run: async () => { const h = message.loading('Building the PowerPoint…', 0); try { await downloadPptx(s, g0, included); message.success('PowerPoint saved.') } catch { message.error('Could not build the PowerPoint.') } finally { h() } } },
    csv: { key: 'csv', icon: <FileExcelOutlined />, label: 'CSV', run: () => download(`${s.id}.csv`, ['sheet,row,text', ...included.flatMap((x) => (x.body || '').split('\n').filter(Boolean).map((row, i) => `"${x.heading.replace(/"/g, '""')}",${i + 1},"${row.replace(/"/g, '""')}"`))].join('\n'), 'text/csv') },
  }
  const downloads = s.format === 'Slide pack' ? [dl.pptx] : isLive ? [dl.pdf, dl.png] : s.format === 'Workbook' ? [dl.csv] : s.format === 'Email' ? [dl.html] : [dl.pdf, dl.html]

  /* ---------------- the conversation */
  const act = (raw: string) => {
    const x = useSubmissionStore.getState().submissions.find((y) => y.id === s.id)
    if (!x) return
    const t = raw.trim().toLowerCase()
    const cur = x.sections.find((y) => y.id === sel)
    if (pendingUpload && /^keep\b/.test(t)) { setPendingUpload(null); sayA('Kept the current template. Yours stays in the library.'); return }
    if (x.stage === 'brief' || x.stage === 'template' || x.stage === 'outline') {
      let m: RegExpMatchArray | null
      if ((m = t.match(/\bgoal\s+(\d)\b/))) { const g = readyGoals[Number(m[1]) - 1]; if (g) { toggleGoal(g); return } }
      if (/\b(add|include|also use|draw on)\b.*\bgoal\b/.test(t) || /\b(renewal|scorecard|contract risk|harlow)\b.*\bgoal\b/.test(t)) { const g = bestMatch(t, readyGoals, (y) => y.title); if (g) { toggleGoal(g); return } }
      if ((m = raw.match(/^describe(?: it)?\s*[:-]?\s+(.{10,})$/i))) { setDescribeText(m[1]); const p = structureFrom(x.format, m[1]); sayA(`Read it as ${p.sections.length} parts:\n${p.sections.map((y, i) => `${i + 1}. ${y.heading}`).join('\n')}\n\nSay "next" to see the outline.`); return }
      if (/\b(start blank|blank|from scratch|write it myself)\b/.test(t)) { const p = structureFrom(x.format, '', true); sayA(`Blank ${FORMAT_LABEL[x.format].toLowerCase()} with its usual ${p.sections.length} parts, all for you to write. Say "next".`); return }
      if (/\b(build( the)? draft|build it|create( it)?|make the draft)\b/.test(t)) { build(); return }
      if (/^(next|continue|go on|looks good|ok|okay|yes|that'?s (right|fine)|keep it|confirm)$/.test(t) || /\b(next|continue)\b/.test(t)) {
        if (step === 'brief' && !x.audience) { sayA('Who reads it? Say "for …".'); return }
        if (step === 'outline') { build(); return }
        setStep(STEPS[stepIdx + 1].key)
        return
      }
      if ((m = t.match(/\b(?:back to|go to|open)\s+(?:the\s+)?(goal|goals|analysis|brief|audience|structure|template|outline)\b/))) { const k: Step = /goal|analysis/.test(m[1]) ? 'goal' : /brief|audience/.test(m[1]) ? 'brief' : /structure|template/.test(m[1]) ? 'structure' : 'outline'; setStep(k); return }
      if (/^(back|previous|go back)$/.test(t)) { if (stepIdx > 0) setStep(STEPS[stepIdx - 1].key); return }
      if (/\b(change|another|different|pick a|library) template\b/.test(t)) { if (step !== 'structure') setStep('structure', true); setLibOpen(true); sayA(`The library is open in the structure step. Pick one, or say "use" and its number:\n${templates.map((y, i) => `${i + 1}. ${y.name}`).join('\n')}`); return }
    }
    /* Instructions about the text selected in the draft. */
    if (quote) {
      const part = x.sections.find((y) => y.id === quote.id)
      const n = part ? numOf(part.id) : 0
      const swap = (repl: string) => {
        if (!part) return false
        const inHead = part.heading.includes(quote.text)
        const src = inHead ? part.heading : part.body
        let next: string | null = src.includes(quote.text) ? src.replace(quote.text, repl) : null
        if (next === null) {
          const re = new RegExp(quote.text.split(/\s+/).map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('\\s+'))
          if (re.test(src)) next = src.replace(re, repl)
        }
        if (next === null) return false
        setSec(part.id, inHead ? { heading: next.trim() } : { body: next.replace(/\n{3,}/g, '\n\n').trim(), from: part.from.startsWith('You') ? 'You' : `${part.from.replace(/, edited by .*$/, '')}, edited by ${me}` })
        return true
      }
      let m: RegExpMatchArray | null
      const done = (msg: string) => { setQuote(null); sayA(msg) }
      if ((m = raw.match(/^(?:replace(?: it| this)?(?: with)?|change(?: it| this)? to|say|write|make it say|should be|instead)\s*[:-]?\s+["“]?(.+?)["”]?$/i))) { if (swap(m[1].trim())) done(`Changed in ${unit} ${n}.`); else done('I could not find that text in the part (it may be in a chart or table). Edit the part instead.'); return }
      if (/^(remove|delete|drop|cut)( it| this| that)?$/.test(t) || /\b(take (it|this) out)\b/.test(t)) { if (swap('')) done(`Removed it from ${unit} ${n}.`); else done('I could not find that text in the part.'); return }
      if (/\b(short(er|en)|tighten|trim|concise)\b/.test(t)) { const first = (quote.text.match(/[^.!?]+[.!?]+/g) ?? [quote.text])[0].trim(); const words = first.split(/\s+/); const cut = words.length > 18 ? `${words.slice(0, 16).join(' ')}…` : first; if (swap(cut)) done(`Shortened it in ${unit} ${n}.`); else done('I could not find that text in the part.'); return }
      if (/\b(more detail|expand|explain)\b/.test(t) && part) { const f = suggestFill(goals, 'findings', `${part.heading} ${quote.text}`); if (f.body && swap(`${quote.text}\n${f.body.split('\n').slice(0, 3).join('\n')}`)) done(`Added the detail behind it in ${unit} ${n}.`); else done('I have nothing more on that in the goal.'); return }
      if (/\b(where|source|data|evidence|prove)\b/.test(t) && part) { const d = drillFor(g0, part); if (d) { setDrill(d); done(`The data behind that is open.`) } else done('No data behind that.'); return }
      sayA('With text selected I can: "replace with …", "make it shorter", "remove it", "more detail", or "where is this from?".')
      return
    }
    /* Instructions about the part in focus. */
    if (cur) {
      const n = numOf(cur.id)
      let m: RegExpMatchArray | null
      if (/\b(short(er|en)|tighten|trim|concise|one line|less text)\b/.test(t)) {
        if (!cur.body.trim()) { sayA(`${Unit} ${n} is empty; there is nothing to shorten.`); return }
        const sentences = cur.body.replace(/\n+/g, ' ').match(/[^.!?]+[.!?]+/g) ?? [cur.body]
        setSec(cur.id, { body: sentences.slice(0, /one line/.test(t) ? 1 : 2).join(' ').trim(), from: `${cur.from.replace(/, edited by .*$/, '')}, shortened` })
        sayA(`Shortened ${unit} ${n}. Say "fill it" to bring the full text back.`)
        return
      }
      if (/\b(fill( it)?|draft it|from the goal|write it for me|bring (it|the full text) back)\b/.test(t)) { sayA(fill(cur) ? `Filled ${unit} ${n} from the goal.` : `Nothing in the goal covers "${cur.heading}". Write it here ("write: …") or on the ${unit}.`); return }
      if ((m = raw.match(/^(?:write|text|replace (?:it )?with|say)\s*[:-]?\s+(.{3,})$/i))) { setSec(cur.id, { body: m[1].trim(), from: 'You' }); sayA(`Written into ${unit} ${n}.`); return }
      if ((m = raw.match(/^(?:rename(?: it)?|call it|heading|retitle)\s*(?:to|:)?\s+(.{3,})$/i))) { setSec(cur.id, { heading: m[1].trim() }); sayA(`${Unit} ${n} is now "${m[1].trim()}".`); return }
      if (/^(remove( it)?|leave (it )?out|drop( it)?|delete( it)?)$/.test(t)) { setSec(cur.id, { included: false }); select(null); sayA(`Left out ${unit} ${n}. Tick it in the list to bring it back.`); return }
      if (/\b(data|source|where .* from|evidence|numbers)\b/.test(t) && !/lineage/.test(t)) { const d = drillFor(g0, cur); if (d) { setDrill(d); sayA(`The data behind ${unit} ${n} is open.`) } else sayA('No data behind this one.'); return }
      if (/\b(more detail|expand|longer|add detail)\b/.test(t)) { const f = suggestFill(goals, 'findings', cur.heading); if (f.body) { setSec(cur.id, { body: `${cur.body.trim()}\n\n${f.body}`.trim(), from: f.from }); sayA(`Added the detail behind it to ${unit} ${n}.`) } else sayA('I have nothing more on this in the goal.'); return }
    }
    const it = interpretSub(raw, 'outline')
    const sec = (k: number) => x.sections[k - 1]
    const noSec = (k: number) => sayA(`There is no ${unit} ${k}; it has ${x.sections.length}.`)
    switch (it.k) {
      case 'title': update(s.id, { title: it.v }, me, `Retitled "${it.v}".`); sayA(`Title set: "${it.v}".`); return
      case 'audience': update(s.id, { audience: it.v }, me, `Audience: ${it.v}.`); sayA(`For ${it.v}.`); return
      case 'purpose': update(s.id, { purpose: it.v }, me, 'Purpose stated.'); sayA('Purpose noted.'); return
      case 'pickTemplate': setPicking(true); sayA(`The library is open. Pick one, or say "use" and its number:\n${templates.map((y, i) => `${i + 1}. ${y.name}`).join('\n')}`); return
      case 'useTemplate': { const y = it.n ? templates[it.n - 1] : bestMatch(it.words ?? '', templates, (z) => `${z.name} ${z.family}`); if (!y) { sayA('Which one? Say "use" and its number.'); return } applyTemplate(s.id, y, goals, me); setPicking(false); touched(); sayA(`Rebuilt on "${y.name}": ${y.sections.length} ${unit}s, filled from the goal where the role matches.`); return }
      case 'useUploaded': { if (!pendingUpload) { sayA('Attach the file first, with the clip.'); return } applyTemplate(s.id, pendingUpload, goals, me); setPendingUpload(null); touched(); sayA(`Rebuilt on your file "${pendingUpload.name}".`); return }
      case 'saveTemplate': { if (x.templateId) { sayA(`It already follows "${tpl?.name ?? x.template}" from your library.`); return } const name = it.name ?? `${FORMAT_LABEL[x.format]}: ${x.title.replace(/:.*$/, '')}`; saveOutlineAsTemplate(s.id, name, me); sayA(`Saved to your library as "${name}". I can recommend it next time.`); return }
      case 'remove': { const y = sec(it.n); if (!y) return noSec(it.n); setSec(y.id, { included: false }); sayA(`Left out ${it.n}: "${y.heading}".`); return }
      case 'restore': { const y = sec(it.n); if (!y) return noSec(it.n); setSec(y.id, { included: true }); sayA(`${it.n} is back in.`); return }
      case 'add': { const id = `u${Date.now().toString(36)}`; setSections(s.id, [...x.sections, { id, heading: it.heading, body: '', from: 'You', role: roleOf(it.heading), included: true }]); touched(); select(id); sayA(`Added ${unit} ${x.sections.length + 1}: "${it.heading}". It is empty: "fill it" or "write: …".`); return }
      case 'rename': { const y = sec(it.n); if (!y) return noSec(it.n); setSec(y.id, { heading: it.v }); sayA(`${Unit} ${it.n} is now "${it.v}".`); return }
      case 'write': { const y = sec(it.n); if (!y) return noSec(it.n); setSec(y.id, { body: it.v, from: 'You' }); select(y.id); sayA(`Written into ${it.n}.`); return }
      case 'show': { const y = sec(it.n); if (!y) return noSec(it.n); select(y.id); sayA(`${Unit} ${it.n} is selected. Tell me what to change in it.`); return }
      case 'review': if (empties.length) { sayA(`Write, fill or leave out the empty ${unit}s first: ${empties.map((y) => `${numOf(y.id)} (${y.heading})`).join(', ')}.`); return } update(s.id, { stage: 'reviewed', reviewedBy: me }, me, 'Marked as reviewed.'); sayA(`Marked as reviewed. Download it (${downloads.map((d) => d.label).join(' or ')}) or share the link.`); return
      case 'download': { const pick = it.as ? downloads.find((d) => d.label.toLowerCase().includes(it.as === 'powerpoint' ? 'pptx' : it.as === 'image' ? 'png' : it.as!)) : undefined; const d = pick ?? downloads[0]; sayA(`Downloading the ${d.label}.`); void d.run(); return }
      case 'share': setSharing(true); sayA('The link is open; copy it from there.'); return
      case 'lineage': setLineage(true); sayA(`Data lineage is open: where every ${unit} reads from.`); return
      case 'refresh': if (isLive) { setRefreshedAt(new Date()); sayA('Refreshed from the goal’s data.') } else sayA('Only a dashboard refreshes.'); return
      case 'goal': if (g0) navigate(appPath(`/goals/${g0.id}`)); return
      default: sayA(cur ? `For ${unit} ${numOf(cur.id)} I can: "make it shorter", "fill it", "more detail", "write: …", "rename to …", "show the data", "remove it".` : `Pick a ${unit} to work on it, or say: "write 3: …", "remove 2", "add a ${unit} on …", "use template 2", "mark as reviewed", "download", "share".`)
    }
  }
  const send = (text: string) => {
    const c = useSubChat.getState()
    c.say(s.id, 'me', text)
    c.setTyping(s.id, true)
    window.setTimeout(() => { useSubChat.getState().setTyping(s.id, false); act(text) }, 420 + Math.random() * 300)
  }
  const upload = async (file: File) => {
    const c = useSubChat.getState()
    c.say(s.id, 'me', 'Here is a template.', { name: file.name, size: file.size })
    c.setTyping(s.id, true)
    const r = await readUpload(file)
    const t = templateFromRead(r)
    window.setTimeout(() => {
      c.setTyping(s.id, false)
      addTemplate(t, me)
      setPendingUpload(t)
      sayA(`Read ${r.name}: ${describeRead(r)}. In your library now as "${t.name}":\n${t.sections.map((y, i) => `${i + 1}. ${y.heading}`).join('\n')}\n\nRebuild this ${FORMAT_LABEL[s.format].toLowerCase()} on it? Say "use it", or "keep".`)
    }, 900)
  }

  const otherGoal = readyGoals.findIndex((g) => !s.goalIds.includes(g.id))
  const chips = quote ? ['Make it shorter', 'Remove it', 'Where is this from?', 'Replace with: ']
    .filter((c) => c !== 'Replace with: ')
    : inSetup
    ? (step === 'goal' ? ['Next', ...(otherGoal >= 0 ? [`Goal ${otherGoal + 1}`] : [])]
      : step === 'brief' ? (s.audience ? ['Next', 'Purpose: decide who gets a renewal plan'] : ['For Renee Halvorsen and the leadership team'])
      : step === 'structure' ? ['Next', 'Change the template', 'Start blank']
      : ['Build the draft', 'Add a part on next steps', 'Back'])
    : selSec
    ? (!selSec.body.trim() ? ['Fill it', 'Write: ', 'Remove it'].filter((c) => c !== 'Write: ') : ['Make it shorter', 'More detail', 'Show the data', 'Remove it'])
    : pendingUpload ? ['Use it', 'Keep'] : empties.length ? [`Show ${numOf(empties[0].id)}`, `Remove ${numOf(empties[0].id)}`, `Add a ${unit} on next steps`] : reviewed ? ['Download', 'Share'] : ['Mark as reviewed', 'Download', 'Where do the figures come from?']

  /* ---------------- set-up, rendered as one flowing column: done steps fold to a line, the current one is open */
  const renderSetup = () => {
    const card = (k: Step, i: number, sumLine: React.ReactNode, body: React.ReactNode) => {
      const active = step === k
      const done = i < stepIdx || (i <= reached && !active)
      return (
        <section key={k} className={`sd-su${active ? ' is-on' : ''}${done ? ' is-done' : ''}${i > reached ? ' is-later' : ''}`}>
          <div className="sd-su-head" onClick={() => { if (i <= reached && !active) setStep(k) }}>
            <span className="sd-step-n">{i < stepIdx ? <CheckOutlined /> : i + 1}</span>
            <span className="sd-su-title">{STEPS[i].label}</span>
            {!active ? <span className="sd-su-sum">{sumLine}</span> : null}
            {!active && i <= reached ? <a className="sd-su-change">change</a> : null}
          </div>
          {active ? <div className="sd-su-body">{body}</div> : null}
        </section>
      )
    }
    const inc = s.sections.filter((y) => y.included)
    const goalBody = (
      <>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginBottom: 8 }}>The analysis the submission is made from. Its findings, recommendations and evidence fill the parts.</Text>
        <Flex vertical gap={8}>
          {allGoals.map((g, i) => {
            const ready = g.findings.length > 0
            const on = s.goalIds.includes(g.id)
            const pref = g.recommendations.find((r) => r.preferred)
            return (
              <div key={g.id} className={`sd-pick${on ? ' is-on' : ''}${ready ? '' : ' is-off'}`} style={{ ['--agent' as string]: g.agent.colour }} onClick={() => ready && send(`Goal ${readyGoals.indexOf(g) + 1}`)}>
                <Checkbox checked={on} disabled={!ready} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <Flex justify="space-between" gap={8}><Text style={{ fontWeight: 500 }}>{g.title}</Text><Text style={{ fontSize: 12, color: g.agent.colour, whiteSpace: 'nowrap' }}>{g.agent.name}</Text></Flex>
                  {ready ? (
                    <>
                      <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>{g.findings.length} findings · {g.recommendations.length} recommendations{pref ? ` · preferred: ${pref.title.split(/[;:,]\s/)[0]}` : ''}</Text>
                      {on ? <ul className="g-ul" style={{ fontSize: 12.5, marginTop: 4 }}>{g.findings.map((f) => <li key={f.id}>{f.headline.split(':')[0]}</li>)}</ul> : null}
                    </>
                  ) : <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>No findings yet{i >= 0 ? ` (${g.status === 'armed' ? 'waiting for its trigger' : 'not run'})` : ''}; nothing to draw on.</Text>}
                </div>
              </div>
            )
          })}
        </Flex>
        <Button type="primary" style={{ marginTop: 12 }} onClick={() => send('Next')}>Continue</Button>
      </>
    )
    const briefBody = (
      <>
        <div className="sd-form">
          <label>Title</label><Input value={s.title} onChange={(e) => update(s.id, { title: e.target.value })} />
          <label>Who reads it</label><Input value={s.audience} onChange={(e) => update(s.id, { audience: e.target.value })} placeholder="e.g. BPUC staff, working session 4 November" />
          <label>What they should decide or do</label><Input.TextArea value={s.purpose} autoSize={{ minRows: 2, maxRows: 4 }} onChange={(e) => update(s.id, { purpose: e.target.value })} />
          <label>Format</label>
          <Flex gap={6} wrap>{OUTPUT_FORMATS.map((f) => <span key={f.key} className={`gc-chip${s.format === f.key ? ' is-sel' : ''}`} onClick={() => update(s.id, { format: f.key }, me, `Format: ${FORMAT_LABEL[f.key]}.`)}>{FORMAT_ICON[f.key]} {FORMAT_LABEL[f.key]}</span>)}</Flex>
        </div>
        <Button type="primary" style={{ marginTop: 12 }} disabled={!s.audience} onClick={() => send('Next')}>Continue</Button>
      </>
    )
    const structBody = (
      <>
        <div className="sd-current">
          <Flex justify="space-between" gap={8} align="baseline">
            <Text style={{ fontWeight: 500 }}>{tpl ? `Template: ${tpl.name}` : s.brief?.description === 'Started blank, written by hand.' ? `Blank ${FORMAT_LABEL[s.format].toLowerCase()}` : 'From your description'}</Text>
            <Text type="secondary" style={{ fontSize: 12 }}>{tpl ? tpl.family : 'not in the library'}</Text>
          </Flex>
          {tpl && s.origin === 'recommendation' ? <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>Recommended by {s.agentName ?? 'the agent'} because it is in your library.</Text> : null}
          {!tpl && s.brief?.description && s.brief.description !== 'Started blank, written by hand.' ? <Text type="secondary" style={{ display: 'block', fontSize: 12.5, fontStyle: 'italic' }}>"{s.brief.description}"</Text> : null}
          <ol className="g-ul" style={{ fontSize: 12.5, marginTop: 6 }}>{inc.map((y) => <li key={y.id}>{y.heading}</li>)}</ol>
          {!tpl && s.origin === 'described' ? <a style={{ fontSize: 12.5 }} onClick={() => setSaveName(`${FORMAT_LABEL[s.format]}: ${s.title.replace(/:.*$/, '')}`)}>Save this structure as a template</a> : null}
        </div>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, margin: '12px 0 6px' }}>Or build it on something else</Text>
        <div className="sd-alts">
          <div className={`sd-alt${libOpen ? ' is-on' : ''}`} onClick={() => setLibOpen((o) => !o)}><b>Another template</b><span>{templates.length} in your library</span></div>
          <div className="sd-alt" onClick={() => attachRef.current?.click()}><b><UploadOutlined /> Your own file</b><span>I read its slides or headings</span></div>
          <div className="sd-alt" onClick={() => send('Start blank')}><b>Blank</b><span>The usual parts, you write them</span></div>
        </div>
        {libOpen ? <Row gutter={[8, 8]} style={{ marginTop: 8 }}>{templates.map((t, i) => <Col key={t.id} xs={24} xl={12}><TemplateCard t={t} compact selected={s.templateId === t.id} onPick={() => { send(`Use template ${i + 1}`); setLibOpen(false) }} /></Col>)}</Row> : null}
        <div style={{ marginTop: 10 }}>
          <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginBottom: 4 }}>Or describe it in words</Text>
          <Input.TextArea value={describeText} onChange={(e) => setDescribeText(e.target.value)} autoSize={{ minRows: 2, maxRows: 6 }} placeholder={`e.g. one ${unit} with the position, one on forecast against budget by project, one on the decisions with owners`} />
          <Button size="small" style={{ marginTop: 6 }} disabled={describeText.trim().length < 12} onClick={() => send(`Describe: ${describeText.trim()}`)}>Read it into a structure</Button>
        </div>
        <Button type="primary" style={{ marginTop: 14 }} onClick={() => send('Next')}>Continue to the outline</Button>
      </>
    )
    const move = (id: string, dir: -1 | 1) => { const list = [...s.sections]; const a = list.findIndex((y) => y.id === id); const b = a + dir; if (b < 0 || b >= list.length) return; [list[a], list[b]] = [list[b], list[a]]; setSections(s.id, list) }
    const outlineBody = (
      <>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginBottom: 8 }}>What goes into each {unit}, and where it comes from. Untick, rename, reorder or add; nothing is built until you say so.</Text>
        <Flex vertical gap={6}>
          {s.sections.map((y, i) => (
            <div key={y.id} className={`sd-ol${y.included ? '' : ' is-out'}`}>
              <Checkbox checked={y.included} onChange={(e) => setSec(y.id, { included: e.target.checked }, true)} />
              <span className="sd-rail-n">{i + 1}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Input variant="borderless" value={y.heading} onChange={(e) => setSec(y.id, { heading: e.target.value }, true)} style={{ fontWeight: 500, padding: 0 }} />
                <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>{y.body.trim() ? <>From {y.from}: <span style={{ color: '#4b5a75' }}>{y.body.replace(/\s+/g, ' ').slice(0, 120)}{y.body.length > 120 ? '…' : ''}</span></> : <span style={{ color: STATUS.warn }}>Empty: nothing in the goal covers it; you write it in the draft{y.from.startsWith('You · ') ? ` (${y.from.slice(6)})` : ''}</span>}</Text>
              </div>
              <Tag style={{ marginInlineEnd: 0 }}>{y.role}</Tag>
              <span className="sd-ol-tools"><a onClick={() => move(y.id, -1)}>↑</a><a onClick={() => move(y.id, 1)}>↓</a></span>
            </div>
          ))}
        </Flex>
        <a className="sd-add" onClick={() => send(`Add a ${unit} on New ${unit}`)}><PlusOutlined /> Add a {unit}</a>
        <div><Button type="primary" style={{ marginTop: 14 }} onClick={() => send('Build the draft')}>Build the draft</Button></div>
      </>
    )
    return (
      <div className="sd-setup">
        {card('goal', 0, goals.map((g) => g.title).join(' + ') || 'not chosen', goalBody)}
        {card('brief', 1, `${FORMAT_LABEL[s.format]} for ${s.audience || '…'}`, briefBody)}
        {card('structure', 2, tpl ? tpl.name : s.origin === 'described' ? 'from your description' : 'not chosen', structBody)}
        {card('outline', 3, `${inc.length} ${unit}s, ${inc.filter((y) => !y.body.trim()).length} to write`, outlineBody)}
      </div>
    )
  }

  /* ---------------- one part of the document */
  const renderPart = (x: Section, i: number) => {
    const on = sel === x.id
    const empty = !x.body.trim()
    const v = g0 && !empty ? visualFor(g0, x.role, x.heading) : null
    const offer = empty ? suggestFill(goals, x.role, x.heading) : null
    const d = drillFor(g0, x)
    const ed = editing === x.id
    const body = ed ? (
      <div className="no-print" onClick={(e) => e.stopPropagation()}>
        <Input value={x.heading} onChange={(e) => setSec(x.id, { heading: e.target.value })} style={{ fontWeight: 600, marginBottom: 6 }} />
        <Input.TextArea value={x.body} autoSize={{ minRows: 3, maxRows: 14 }} onChange={(e) => setSec(x.id, { body: e.target.value, from: x.from.startsWith('You') ? 'You' : `${x.from.replace(/, edited by .*$/, '')}, edited by ${me}` })} placeholder={`Write this ${unit}.`} />
        <Button size="small" type="primary" style={{ marginTop: 6 }} onClick={() => setEditing(null)}>Done</Button>
      </div>
    ) : empty ? (
      <div className="sd-offer no-print" onClick={(e) => e.stopPropagation()}>
        <span className="sd-offer-mark" style={{ background: `${agent.colour}18`, color: agent.colour }}><BulbOutlined /></span>
        <div style={{ flex: 1 }}>
          <Text style={{ fontSize: 13 }}>{offer?.body ? `I can fill this from ${offer.from.replace(/, Agent.*$/, '').toLowerCase()}.` : 'Nothing in the goal covers this yet.'}</Text>
          <Flex gap={6} style={{ marginTop: 6 }} wrap>
            {offer?.body ? <Button size="small" type="primary" onClick={() => { setSel(x.id); send('Fill it') }}>Fill it</Button> : null}
            <Button size="small" onClick={() => setEditing(x.id)}>Write it myself</Button>
            <Button size="small" type="text" onClick={() => { setSel(x.id); send('Remove it') }}>Leave it out</Button>
          </Flex>
        </div>
      </div>
    ) : s.format === 'Slide pack' && v ? (
      <div className="sd-slide-body"><Paragraph className="sd-text">{short(x.body)}</Paragraph><div className="sd-slide-vis"><VisualBlock v={v} compact /></div></div>
    ) : (
      <>{v ? <div style={{ marginBottom: 8 }}><VisualBlock v={v} compact /></div> : null}<Paragraph className="sd-text">{isLive && v ? short(x.body, 240) : x.body}</Paragraph></>
    )
    return (
      <div key={x.id} id={`doc-${x.id}`} className={`sd-part is-${s.format.replace(' ', '-').toLowerCase()}${on ? ' is-on' : ''}${empty ? ' is-empty' : ''}`} style={{ ['--agent' as string]: agent.colour }} onClick={() => { if ((window.getSelection()?.toString().trim().length ?? 0) > 2) return; select(on ? null : x.id) }}>
        <div className="sd-part-head">
          <span className="sd-n">{s.format === 'Slide pack' ? `${i + 1} / ${included.length}` : i + 1}</span>
          {!ed ? <div className="sd-h">{x.heading}</div> : null}
          {!ed ? (
            <span className="sd-tools no-print" onClick={(e) => e.stopPropagation()}>
              <Tooltip title="Edit"><EditOutlined onClick={() => setEditing(x.id)} /></Tooltip>
              {d ? <Tooltip title="The data behind it"><TableOutlined onClick={() => setDrill(d)} /></Tooltip> : null}
              <Tooltip title={`Ask ${agent.name} about this ${unit}`}><MessageOutlined onClick={() => { setSel(x.id); setThreadOpen(true); window.setTimeout(() => (document.querySelector('.sd-thread textarea') as HTMLTextAreaElement | null)?.focus(), 50) }} /></Tooltip>
            </span>
          ) : null}
        </div>
        {body}
        {!empty && !ed ? <div className="sd-from no-print">↳ {x.from}{d ? <> · <a onClick={(e) => { e.stopPropagation(); setDrill(d) }}>open the data</a></> : null}</div> : null}
      </div>
    )
  }

  const visibleParts = useMemo(() => included.slice(0, shown), [included, shown])

  return (
    <div className={`sd${threadOpen ? '' : ' no-thread'}`}>
      <input ref={attachRef} type="file" accept=".pptx,.docx,.txt,.md,.pdf,.xlsx" style={{ display: 'none' }} onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); e.target.value = '' }} />
      {/* ---------------- header: the brief, the template, readiness, one action bar */}
      <header className="sd-top">
        <span className="gw-back" role="link" onClick={() => navigate(appPath('/submissions'))}><ArrowLeftOutlined /> Submissions</span>
        <Input.TextArea className="sd-title" variant="borderless" autoSize={{ minRows: 1, maxRows: 3 }} value={s.title} onChange={(e) => update(s.id, { title: e.target.value.replace(/\n/g, ' ') })} placeholder="Title" />
        <Flex gap={SP.sm} wrap align="center" className="sd-meta">
          <Tag icon={FORMAT_ICON[s.format]} style={{ marginInlineEnd: 0 }}>{FORMAT_LABEL[s.format]}</Tag>
          <span>for</span>
          <Input variant="borderless" className="sd-aud" value={s.audience} onChange={(e) => update(s.id, { audience: e.target.value })} placeholder="who reads it" />
          <span className="sd-sep">·</span>
          <span>Built on <b>{tpl?.name ?? (s.origin === 'described' ? 'your description' : 'no template')}</b></span>
          <a onClick={() => send('Change the template')}>change</a>
          <a onClick={() => attachRef.current?.click()}><UploadOutlined /> use my file</a>
          {s.origin === 'described' && !s.templateId ? <a onClick={() => setSaveName(`${FORMAT_LABEL[s.format]}: ${s.title.replace(/:.*$/, '')}`)}>save as a template</a> : null}
          {g0 ? <><span className="sd-sep">·</span><span>from <a onClick={() => navigate(appPath(`/goals/${g0.id}`))}>{g0.title.length > 48 ? `${g0.title.slice(0, 46)}…` : g0.title}</a></span></> : null}
        </Flex>
        {inSetup ? (
          <Flex justify="space-between" align="center" gap={SP.sm} wrap className="sd-bar">
            <span className="sd-ready">Setting up · step {stepIdx + 1} of 4: {STEPS[stepIdx].label.toLowerCase()} · {included.length} parts so far</span>
            <Flex gap={6} wrap>
              {stepIdx > 0 ? <Button onClick={() => send('Back')}>Back</Button> : null}
              {step === 'outline' ? <Button type="primary" onClick={() => send('Build the draft')}>Build the draft</Button> : <Button type="primary" disabled={step === 'brief' && !s.audience} onClick={() => send('Next')}>Continue</Button>}
              {!threadOpen ? <Button icon={<MessageOutlined />} onClick={() => setThreadOpen(true)}>{agent.name}</Button> : null}
            </Flex>
          </Flex>
        ) : (
        <Flex justify="space-between" align="center" gap={SP.sm} wrap className="sd-bar">
          <span className="sd-ready">
            {included.length} {unit}s · {empties.length ? <span style={{ color: STATUS.warn }}>{empties.length} empty</span> : 'none empty'} · {reviewed ? <span style={{ color: STATUS.good }}><CheckOutlined /> reviewed{s.reviewedBy ? ` by ${s.reviewedBy}` : ''}</span> : 'draft'}
            {isLive ? <> · <Tag color="processing" style={{ marginInlineEnd: 0 }}>Live</Tag> data as of {DRILL.as_of}, refreshed {refreshedAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</> : null}
          </span>
          <Flex gap={6} wrap>
            {!reviewed ? (
              <Tooltip title={empties.length ? `Fill, write or leave out ${empties.length} empty ${unit}${empties.length === 1 ? '' : 's'} first` : 'You have read it and it can leave'}>
                <Button type="primary" icon={<CheckOutlined />} disabled={empties.length > 0} onClick={() => send('Mark as reviewed')}>Mark as reviewed</Button>
              </Tooltip>
            ) : null}
            {downloads.length === 1 ? <Button icon={downloads[0].icon} onClick={() => send(`Download the ${downloads[0].label}`)}>Download {downloads[0].label}</Button> : <Dropdown trigger={['click']} menu={{ items: downloads.map((d) => ({ key: d.key, icon: d.icon, label: d.label, onClick: () => send(`Download the ${d.label}`) })) }}><Button icon={<DownloadOutlined />}>Download</Button></Dropdown>}
            <Button icon={<ShareAltOutlined />} onClick={() => send('Share')}>Share</Button>
            <Tooltip title="Where every figure comes from"><Button icon={<ApartmentOutlined />} onClick={() => send('Where do the figures come from?')} /></Tooltip>
            {isLive ? <Tooltip title="Refresh from the goal’s data"><Button icon={<ReloadOutlined />} onClick={() => send('Refresh')} /></Tooltip> : null}
            {!threadOpen ? <Button icon={<MessageOutlined />} onClick={() => setThreadOpen(true)}>{agent.name}</Button> : null}
          </Flex>
        </Flex>
        )}
        {pendingUpload ? (
          <div className="sd-note">Read from your file: "{pendingUpload.name}", {pendingUpload.sections.length} parts. <a onClick={() => send('Use it')}>Rebuild on it</a> · <a onClick={() => send('Keep')}>keep the current one</a></div>
        ) : null}
      </header>

      {/* ---------------- rail: the set-up steps, then the parts in order */}
      {inSetup ? (
        <nav className="sd-rail" aria-label="Steps">
          {STEPS.map((x, i) => (
            <div key={x.key} className={`sd-step${step === x.key ? ' is-on' : ''}${i < stepIdx || i <= reached ? ' is-done' : ''}`} onClick={() => (i <= reached ? setStep(x.key) : undefined)} role="button" aria-disabled={i > reached}>
              <span className="sd-step-n">{i < stepIdx ? <CheckOutlined /> : i + 1}</span>
              <span>{x.label}</span>
            </div>
          ))}
          <div className="sd-step is-later"><span className="sd-step-n">5</span><span>Draft</span></div>
          <div className="sd-step is-later"><span className="sd-step-n">6</span><span>Review</span></div>
        </nav>
      ) : (
      <nav className="sd-rail" aria-label="Parts">
        <a className="sd-setup-link" onClick={() => { update(s.id, { stage: 'outline' }); setStepRaw('outline'); setReached(3); sayA(stepMsg('outline')) }}>← Set-up: analysis, reader, structure, outline</a>
        {s.sections.map((x, i) => (
          <div
            key={x.id}
            className={`sd-rail-item${sel === x.id ? ' is-on' : ''}${x.included ? '' : ' is-out'}`}
            draggable
            onDragStart={() => { dragFrom.current = x.id }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => {
              const from = dragFrom.current
              dragFrom.current = null
              if (!from || from === x.id) return
              const list = [...s.sections]
              const a = list.findIndex((y) => y.id === from)
              const [moved] = list.splice(a, 1)
              list.splice(list.findIndex((y) => y.id === x.id), 0, moved)
              setSections(s.id, list)
              touched()
            }}
            onClick={() => x.included && select(x.id)}
          >
            <HolderOutlined className="sd-grip" />
            <Checkbox checked={x.included} onClick={(e) => e.stopPropagation()} onChange={(e) => { setSec(x.id, { included: e.target.checked }); if (!e.target.checked && sel === x.id) setSel(null) }} />
            <span className="sd-rail-n">{i + 1}</span>
            <span className={`sd-dot${x.body.trim() ? ' is-full' : ''}`} />
            <span className="sd-rail-h">{x.heading}</span>
          </div>
        ))}
        <a className="sd-add" onClick={() => send(`Add a ${unit} on New ${unit}`)}><PlusOutlined /> Add a {unit}</a>
        <Text type="secondary" style={{ display: 'block', fontSize: 11.5, marginTop: 10, lineHeight: 1.4 }}>Drag to reorder. Untick to leave out. Filled ● · empty ○</Text>
      </nav>
      )}

      {/* ---------------- the document */}
      <main className="sd-canvas-wrap" onClick={() => { if ((window.getSelection()?.toString().trim().length ?? 0) > 2) return; setSel(null); setPill(null) }} onMouseUp={() => {
        if (inSetup) return
        const ws = window.getSelection()
        const text = ws?.toString().trim() ?? ''
        if (!ws || text.length < 3 || !ws.rangeCount) { setPill(null); return }
        const node = ws.anchorNode instanceof Element ? ws.anchorNode : ws.anchorNode?.parentElement
        const partEl = node?.closest('.sd-part') as HTMLElement | null
        if (!partEl || node?.closest('.no-print, .sb-vis')) { setPill(null); return }
        const r = ws.getRangeAt(0).getBoundingClientRect()
        setPill({ id: partEl.id.replace(/^doc-/, ''), text, x: Math.min(r.right, window.innerWidth - 220), y: r.top })
      }}>
        {inSetup ? renderSetup() : (
        <div ref={canvasRef} className={`sd-canvas is-${s.format.replace(' ', '-').toLowerCase()}`}>
          <div className="sd-print-title">{s.title}<div>To {s.audience} · {FORMAT_LABEL[s.format]} · prepared by {s.createdBy}{s.reviewedBy ? ` · reviewed by ${s.reviewedBy}` : ' · draft, not reviewed'}</div></div>
          {visibleParts.map((x, i) => renderPart(x, i))}
          {shown < included.length ? <div className="sd-building no-print"><span className="st-pulse" /> {agent.name} is building {unit} {shown + 1}…</div> : null}
        </div>
        )}
      </main>

      {pill ? (
        <div className="sd-pill no-print" style={{ left: pill.x, top: pill.y - 40 }} onMouseDown={(e) => {
          e.preventDefault()
          setQuote({ id: pill.id, text: pill.text })
          setSel(pill.id)
          setThreadOpen(true)
          setPill(null)
          window.setTimeout(() => (document.querySelector('.sd-thread textarea') as HTMLTextAreaElement | null)?.focus(), 60)
        }}><MessageOutlined /> Change this with {agent.name}</div>
      ) : null}
      {/* ---------------- the thread */}
      {threadOpen ? (
        <div className="sd-thread">
          <ChatPane agent={agent} messages={chat} typing={typing} chips={chips} onSend={send} onUpload={upload} controls={false} accept=".pptx,.docx,.txt,.md,.pdf,.xlsx"
            title="" scope={quote ? `${Unit} ${numOf(quote.id)}: "${quote.text.length > 46 ? `${quote.text.slice(0, 44)}…` : quote.text}"` : selSec ? `${Unit} ${numOf(selSec.id)}: ${selSec.heading}` : undefined} onClearScope={() => { setSel(null); setQuote(null) }}
            placeholder={quote ? 'What should it say instead? e.g. replace with …' : selSec ? `Tell me what to change in ${unit} ${numOf(selSec.id)}` : `Ask ${agent.name}, or pick a ${unit}`} />
          <span className="sd-thread-close" role="button" aria-label="Hide the thread" onClick={() => setThreadOpen(false)}>×</span>
        </div>
      ) : null}

      <Drawer open={!!drill} onClose={() => setDrill(null)} width="min(1280px, 94vw)" title="The data behind it" destroyOnHidden styles={{ body: { padding: SP.base } }}>
        {drill ? <DataExplorer start={drill} height={Math.max(360, window.innerHeight - 150)} /> : null}
      </Drawer>
      <Drawer title="Pick a template" open={picking} onClose={() => setPicking(false)} width={720} destroyOnHidden>
        <Row gutter={[SP.sm, SP.sm]}>{templates.map((t, i) => <Col key={t.id} span={12}><TemplateCard t={t} compact selected={s.templateId === t.id} onPick={() => send(`Use template ${i + 1}`)} /></Col>)}</Row>
      </Drawer>
      <Drawer open={lineage} onClose={() => setLineage(false)} width={600} title="Data lineage" destroyOnHidden>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginBottom: SP.base }}>Where each {unit} gets its figures. Data as of {DRILL.as_of}.</Text>
        {included.map((x) => { const v = g0 ? visualFor(g0, x.role, x.heading) : null; return (
          <div key={x.id} className="gw-card" style={{ cursor: 'default', marginBottom: 8 }}>
            <Text style={{ display: 'block', fontWeight: 500, fontSize: 13 }}>{numOf(x.id)}. {x.heading}</Text>
            <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>Filled from: {x.from}</Text>
            {v ? <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>Picture: {v.title} · {LINEAGE[v.kind].tables.join(', ')}</Text> : null}
          </div>
        ) })}
      </Drawer>
      <Modal open={sharing} onCancel={() => setSharing(false)} footer={null} title={isLive ? 'Share the live dashboard' : `Share this ${FORMAT_LABEL[s.format].toLowerCase()}`}>
        <Flex gap={SP.xs} style={{ marginBottom: SP.base }}>
          <Input value={shareUrl} readOnly prefix={<LinkOutlined />} />
          <Button icon={<CopyOutlined />} onClick={() => { navigator.clipboard?.writeText(shareUrl).then(() => message.success('Link copied.')).catch(() => message.info('Copy the link from the box.')) }}>Copy</Button>
        </Flex>
        <Text type="secondary" style={{ fontSize: 12.5 }}>Anyone at Northline with the link opens it as it stands. Sending and publishing are not part of this product today.</Text>
      </Modal>
      <Modal open={saveName !== null} title="Save as a template" okText="Save to the library" onCancel={() => setSaveName(null)} onOk={() => { if (saveName?.trim()) { saveOutlineAsTemplate(s.id, saveName.trim(), me); sayA(`Saved to your library as "${saveName.trim()}". I can recommend it next time.`); setSaveName(null) } }}>
        <Input value={saveName ?? ''} onChange={(e) => setSaveName(e.target.value)} />
      </Modal>
    </div>
  )
}
