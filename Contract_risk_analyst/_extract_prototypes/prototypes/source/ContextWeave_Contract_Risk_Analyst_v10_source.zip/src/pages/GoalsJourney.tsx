import { ArrowUpOutlined, BellOutlined, CheckOutlined, ClockCircleOutlined, CloseOutlined, CloudUploadOutlined, DatabaseOutlined, EyeInvisibleOutlined, EyeOutlined, FileTextOutlined, FolderOpenOutlined, GlobalOutlined, LayoutOutlined, MailOutlined, PaperClipOutlined, PauseOutlined, PlayCircleOutlined, PlusOutlined, SaveOutlined, TableOutlined, ThunderboltOutlined, UploadOutlined, WarningOutlined } from '@ant-design/icons'
import { isTargetGoal } from '../components/goals/ScoreBoard'
import TargetBoard from '../components/goals/RiskBoard'
import ScorecardDesign from '../components/goals/ScorecardDesign'
import { downloadTemplate } from '../data/templateFile'
import { changeEffect, peekNotes, unpublished, useDesign, useDesignV } from '../store/designStore'
import { Button, Drawer, Input, Tooltip } from 'antd'
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { appPath } from '../api/dataset'
import DataExplorer from '../components/goals/DataExplorer'
import { StoryPlayer } from '../components/goals/GoalWorkspace'
import DelivPicker from '../components/goals/DelivPicker'
import DeliverableDoc from '../components/goals/DeliverableDoc'
import { templateLine } from '../data/deliverFlow'
import { bestMatch } from '../data/subChat'
import { Figure } from '../components/goals/parts'
import '../components/goals/ChatPane.css'
import { downloadPack } from '../data/exportPack'
import { STATUS_LABEL, TRIGGER_LABEL, type Drill, type Goal } from '../data/goalCases'
import { LIB, ONCE_BASE, ONCE_FILES, ONCE_PROMPT, WATCH_BASE, WATCH_PROMPT, type Node, type NodeContent, type RowVal } from '../data/journeyCases'
import { CONTRACTS, DESIGN, PANELS, RATING_NAME, RULE_TEXT, activeFactors, likelihoodSignals, specCoverage } from '../data/risk'
import { describeRead, readUpload } from '../data/readFile'
import { useAuthStore } from '../store/authStore'
import { baseIdOf, liveNodes, openQuestion, toGoal, useJourney, type Att, type Journey, type Msg } from '../store/journeyStore'
import { useSubmissionStore } from '../store/submissionStore'
import { SP } from '../theme'
import { P } from '../data/pace'
import './GoalsPage.css'
import './SubmissionsHub.css'
import './GoalsJourney.css'
import './HubPolish.css'
import HubFrame, { AgentMark, Dock, JourneyBar, RailItem, RailSearch, RailSection, RailToggle, RichText, scrollToMsg, useDock, useRailMatch, useSlashToSearch, useStickToBottom, type JStep } from './HubFrame'

/*
 * Goals, 4 November 2026: one human touchpoint, at the start. The agent plans, asks only what it could
 * not find and, in the same step, agrees the deliverables and their templates (and, for a standing goal,
 * what it may do when it fires). Then it runs to the end by itself: findings accepted, the top
 * recommendation chosen, the deliverables built and shown on the right. Everything stays open to change
 * afterwards in the chat; the run is kept under Executed.
 *
 * Earlier header, v30. The conversation is the main thing; the plan on the right is what you and the agent agree.
 * One brief in plain words, then the agent reads and the plan fills in with provenance on every row;
 * it asks only what it could not find, one card at a time; you edit any row through the chat, agree,
 * and the plan runs as a workflow you can pause, steer, fork or stop at a checkpoint. Findings land as
 * steps finish; you accept or challenge them, choose the way forward, and build the output in
 * Submissions. The step bar on top says where you are; the list on the left holds every goal.
 */

type Tab = 'plan' | 'workflow' | 'findings' | 'data' | 'outputs' | 'runs' | 'log' | 'deliverables' | 'target'
const TYPE_LABEL: Record<Node['type'], string> = { gather: 'Gather', compute: 'Compute', model: 'Model', checkpoint: 'Checkpoint', scenario: 'What-if', synthesize: 'Synthesize', deliver: 'Deliver' }
const esc = (s: string) => s.replace(/<[^>]+>/g, '')
const Html = ({ html, className }: { html: string; className?: string }) => <span className={className} dangerouslySetInnerHTML={{ __html: html }} />

const LABELS: Record<string, string> = { question: 'Question', decision: 'Decision it informs', who: 'Who decides, by when', scope: 'Scope', success: 'What counts as success', 'as:four': 'Evergreen contracts', 'as:t3': 'NPS from a predecessor', watch: 'What I watch', against: 'Against', where: 'Checked where and when', combine: 'One rating from two halves', fires: 'Fires when', then: 'Then I', tell: 'Who is told', until: 'Runs until', target: 'The scorecard' }
const TAGL: Record<string, string> = { you: 'You', inf: 'Inferred', need: 'Needs you', ok: 'From your files' }


/* ---------------- small parts, outside the page so they keep their identity across renders */
function Sec({ title, right, children, id, intro }: { title: string; right?: React.ReactNode; children: React.ReactNode; id?: string; intro?: string }) {
  return <section className="pd-sec" id={id}><div className="pd-h"><h3>{title}</h3>{right ? <span className="r">{right}</span> : null}</div>{intro ? <p className="pd-intro">{intro}</p> : null}{children}</section>
}
function Grp({ title, sub, children }: { title: string; sub?: string; children: React.ReactNode }) {
  return <div className="ctx-g"><div className="ctx-gh">{title}{sub ? <span>{sub}</span> : null}</div>{children}</div>
}
function Src({ n, t, m, warn, off, drill, onOpen }: { n: string; t?: string; m: string; warn?: boolean; off?: boolean; drill?: Drill; onOpen: (d: Drill) => void }) {
  return <div className={`src${off ? ' is-off' : ''}`}><b>{n}</b>{t ? <code>{t}</code> : <span />}<span className={warn ? 'warn' : ''}>{m}{drill ? <> · <a onClick={() => onOpen(drill)}>open</a></> : null}</span></div>
}
function Doc({ n, took, warn, mine, drill, onOpen, onRemove }: { n: string; took: string; warn?: boolean; mine?: boolean; drill?: Drill; onOpen: (d: Drill) => void; onRemove?: (n: string) => void }) {
  return <div className="doc-in"><span className="doc-ic"><FileTextOutlined /></span><span className="doc-b"><b>{n}</b><small className={warn ? 'warn' : ''}>{took}{drill ? <> · <a onClick={() => onOpen(drill)}>open</a></> : null}</small>{mine ? <span className="tag you">Added by you</span> : null}</span>{mine && onRemove ? <button className="doc-x" type="button" aria-label={`Stop using ${n}`} onClick={() => onRemove(n)}><CloseOutlined /></button> : null}</div>
}
function BriefRow({ k, label, val, pending, target, canEdit, onEdit }: { k: string; label: string; val: RowVal | null; pending?: string; target: string | null; canEdit: boolean; onEdit: (k: string) => void }) {
  const isNeed = !!val && val.tag === 'need' && !val.soft
  const isTarget = target === k
  return (
    <div className={`bf-row${isNeed ? ' is-need' : ''}${isTarget ? ' is-target' : ''}`} data-row={k}>
      <div className="bf-k">{label}</div>
      <div className="bf-v" onClick={(e) => { const go = (e.target as HTMLElement).closest('[data-go]')?.getAttribute('data-go'); if (go) window.dispatchEvent(new CustomEvent('cw:go', { detail: go })) }}>{val ? <><Html html={val.v} />{val.sub ? <small>{val.sub}</small> : null}</> : <span className="bf-pend"><span className="skel" /><small>{pending ?? 'Reading…'}</small></span>}</div>
      <div className="bf-t">{val ? <><span className={`tag ${val.tag}`}>{val.label ?? TAGL[val.tag]}</span>{isTarget ? <span className="bf-hint">in the chat</span> : canEdit && k !== 'target' ? <button className="bf-edit" type="button" onClick={() => onEdit(k)}>{isNeed ? 'Fill in' : 'Edit'}</button> : null}</> : null}</div>
    </div>
  )
}
function InspHead({ n, meta, acts, onClose }: { n: Node; meta: React.ReactNode; acts?: React.ReactNode; onClose: () => void }) {
  return <div className="insp-head"><div className="insp-title"><div className="tt"><span className="ty">{TYPE_LABEL[n.type]}</span>{n.title}</div><div className="mt">{meta}</div></div><div className="insp-acts">{acts}<button className="btn is-ghost" type="button" aria-label="Close" onClick={onClose}><CloseOutlined /></button></div></div>
}
/* The change plan of a live goal: what the person asked to change, what it does to the scores, and what publishing does. */
function ChangeCard({ j, done }: { j: Journey; done?: string }) {
  useDesignV()
  const st = useJourney()
  const e = changeEffect()
  if (done || !e || !unpublished()) return <Fold label="Change plan" sum={done ?? 'Closed'} />
  const m1 = (x: number) => `$${(x / 1e6).toFixed(1)}M`
  const d = (a: number, b: number, f: (x: number) => string = String, tone = true) => (a === b ? <span className="chg-same">no change</span> : <span className={tone ? (b > a ? 'chg-up' : 'chg-down') : 'chg-plain'}>{b > a ? '+' : '−'}{f(Math.abs(b - a))}</span>)
  const two = (a: number, b: number) => (a.toFixed(2) === b.toFixed(2) ? `${a.toFixed(3)} to ${b.toFixed(3)}` : `${a.toFixed(2)} to ${b.toFixed(2)}`)
  const moved = [...e.up, ...e.down], asked = j.changes ?? [], extra = peekNotes().filter((n) => !asked.some((c) => (c.own ?? []).includes(n)))
  return (
    <div className="hc chg" data-card="change" data-testid="chg-card">
      <div className="hc-head"><span className="sd-step-n">{e.next}</span><b>Change plan: version {e.next} of the dashboard</b><span className="hc-of">Draft · not published</span></div>
      <div className="chg-sec" data-testid="chg-what">
        <h5>What changes</h5>
        <div className="diff">{asked.map((c, i) => <div key={i} className={`diff-row ${c.k}`}><span className="k">{c.k === 'add' ? 'new' : 'changes'}</span><span><RichText text={c.text} /></span></div>)}</div>
        {extra.length ? <p className="chg-note">Also changed on the Plan tab: {extra.join('; ')}.</p> : null}
      </div>
      <div className="chg-sec">
        <h5>What it does to the scores</h5>
        <table className="chg-t" data-testid="chg-table">
          <thead><tr><th /><th>Version {e.version}</th><th>Draft</th><th>Change</th></tr></thead>
          <tbody>
            {[1, 2, 3, 4].map((r) => <tr key={r}><td>Rating {r} · {RATING_NAME[r].toLowerCase()}</td><td>{e.dist[0][r]}</td><td>{e.dist[1][r]}</td><td>{d(e.dist[0][r], e.dist[1][r], String, false)}</td></tr>)}
            <tr className="is-sum"><td>Rated 3 or 4</td><td>{e.n34[0]}</td><td>{e.n34[1]}</td><td>{d(e.n34[0], e.n34[1])}</td></tr>
            <tr><td>Revenue rated 3 or 4</td><td>{m1(e.rev34[0])}</td><td>{m1(e.rev34[1])}</td><td>{d(e.rev34[0], e.rev34[1], m1)}</td></tr>
            <tr><td>Act now</td><td>{e.act[0]}</td><td>{e.act[1]}</td><td>{d(e.act[0], e.act[1])}</td></tr>
            <tr><td>Factors and signals in the score</td><td>{e.factors[0]} · {e.signals[0]}</td><td>{e.factors[1]} · {e.signals[1]}</td><td>{e.factors[0] === e.factors[1] && e.signals[0] === e.signals[1] ? <span className="chg-same">no change</span> : <span>{e.factors[1] - e.factors[0] >= 0 ? '+' : '−'}{Math.abs(e.factors[1] - e.factors[0])} · {e.signals[1] - e.signals[0] >= 0 ? '+' : '−'}{Math.abs(e.signals[1] - e.signals[0])}</span>}</td></tr>
          </tbody>
        </table>
        <p className="chg-line" data-testid="chg-line"><b>{e.scoresMoved} of {CONTRACTS.length} scores move{e.scoresMoved ? `, by ${Math.abs(e.largest).toFixed(2)} at most` : ''}.</b> {moved.length ? `${moved.length} ${moved.length === 1 ? 'project changes' : 'projects change'} rating: ${e.up.length} up, ${e.down.length} down.` : 'No project changes rating.'}</p>
        {moved.length ? (
          <ul className="chg-moves" data-testid="chg-moves">{moved.slice(0, 6).map((x) => <li key={x.id} className={x.to > x.from ? 'is-up' : 'is-down'}><b>{x.site}</b><span>{x.from} to {x.to}</span><em>{two(x.s0, x.s1)}</em></li>)}{moved.length > 6 ? <li className="is-more">and {moved.length - 6} more, on the dashboard once it is published</li> : null}</ul>
        ) : e.biggest.length ? (
          <ul className="chg-moves" data-testid="chg-moves">{e.biggest.slice(0, 4).map((x) => <li key={x.id} className={x.s1 > x.s0 ? 'is-up' : 'is-down'}><b>{x.site}</b><span>stays at {x.r}</span><em>{two(x.s0, x.s1)}</em></li>)}</ul>
        ) : null}
      </div>
      <div className="chg-sec">
        <h5>When you publish</h5>
        <ul className="chg-pub">
          <li>All {CONTRACTS.length} projects are scored again. The dashboard becomes <b>version {e.next}</b> and says why.</li>
          <li>Version {e.version} stays in the version list of the dashboard.</li>
          <li>The mitigation plans are written again for {e.plans} {e.plans === 1 ? 'site' : 'sites'}.</li>
          <li>Nobody is alerted. The scores move because the scoring changed, not because something happened at a site.</li>
          <li>The next morning check uses the new scoring.</li>
        </ul>
      </div>
      <div className="hc-actions"><Button size="small" type="primary" data-testid="chg-publish" disabled={!!j.changing} onClick={() => st.republish(j.id)}>Publish version {e.next}</Button><Button size="small" data-testid="chg-discard" disabled={!!j.changing} onClick={() => st.discardChange(j.id)}>Discard the change</Button><span className="chg-hint">or tell me what else to change</span></div>
    </div>
  )
}

function Fold({ label, sum }: { label: string; sum: string }) {
  return <div className="hc hc-folded"><span className="sd-step-n is-done"><CheckOutlined /></span><b>{label}</b><span className="hc-sum">{sum}</span></div>
}

/* What the agents are doing right now: each running step with its calls appearing as it works, and how long it has been at it. */
const EXPECT: Record<string, number> = { n1: 10500, n2: 12000, n3: 9000, n4: 10000, n5: 10500, f1: 10000, w1: 10000, w2: 9500, w3: 12000, w4: 10000, g1: 9000, g2: 9000, g3: 9000, g4: 9000 }
function Activity({ j, content, num }: { j: Journey; content: (nodeId: string) => NodeContent | null; num: Record<string, string> }) {
  const [, tick] = useState(0)
  useEffect(() => { const t = window.setInterval(() => tick((x) => x + 1), 400); return () => window.clearInterval(t) }, [])
  const running = liveNodes(j).filter((n) => ['running', 'stale'].includes(j.ns[n.id]?.state ?? '') && j.ns[n.id]?.t0 && n.type !== 'deliver')
  if (!running.length) return null
  return (
    <div className="act-now" data-testid="activity">
      {running.map((n) => {
        const c = content(n.id)
        const lines: [string, string][] = c ? [[c.live[0], c.live[1]], ...c.trace.map((t) => { const [a, b] = t.split(' → '); return [a, b ?? 'done'] as [string, string] }), ...c.receipts.slice(0, 3).map((r) => [`read ${r.n}`, r.m] as [string, string]), ...c.checks.slice(0, 2).map((x) => ['check', x] as [string, string])] : [...n.draws.map((d) => [`read ${d}`, 'read'] as [string, string]), ['check', n.check]]
        const el = Date.now() - (j.ns[n.id]?.t0 ?? Date.now())
        const frac = Math.min(0.95, el / P(j.ns[n.id]?.state === 'stale' ? 6000 : EXPECT[n.id] ?? 10000))
        const k = Math.max(1, Math.min(lines.length, Math.ceil(frac * lines.length)))
        return (
          <div key={n.id} className="act-step">
            <div className="act-h"><span className="act-pulse" /><b>{num[n.id] ? `Step ${num[n.id]} · ` : ''}{n.title}</b><span className="act-t">{j.ns[n.id]?.state === 'stale' ? 're-running · ' : ''}{Math.max(1, Math.round(el / 1000))}s</span></div>
            <div className="act-bar"><i style={{ width: `${Math.round(frac * 100)}%` }} /></div>
            <div className="ap">{lines.slice(0, k).map((l, i) => <div key={i} className={`ap-line${i === k - 1 ? ' is-live' : ''}`}><span className="ap-tool" title={l[0]}><span className="ap-dot" />{l[0]}</span><span className="ap-res">{i === k - 1 ? 'working…' : l[1]}</span></div>)}</div>
          </div>
        )
      })}
    </div>
  )
}

/** Where the scoring template is handed over: drop the file, or choose it. The template itself can be downloaded here. */
function UploadBox({ onFile, onSample }: { onFile: (f: File) => void; onSample: () => void }) {
  const [over, setOver] = useState(false)
  const input = useRef<HTMLInputElement>(null)
  return (
    <div className={`upl${over ? ' is-over' : ''}`} data-testid="tpl-upload" onDragOver={(e) => { e.preventDefault(); setOver(true) }} onDragLeave={() => setOver(false)} onDrop={(e) => { e.preventDefault(); setOver(false); const f = e.dataTransfer.files?.[0]; if (f) onFile(f) }}>
      <CloudUploadOutlined />
      <b>Drop your scoring template here</b>
      <p>An Excel or CSV file with one row per signal: the factor, the weights, and when the signal scores 1, 2, 3 and 4.</p>
      <input ref={input} type="file" accept=".xlsx,.xls,.csv" hidden data-testid="tpl-file" onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = '' }} />
      <Button type="primary" onClick={() => input.current?.click()}>Choose a file</Button>
      <div className="upl-links"><a data-testid="tpl-download" onClick={() => downloadTemplate()}>Download the template to fill in</a><a data-testid="tpl-sample" onClick={onSample}>Use the sample template</a></div>
    </div>
  )
}

export default function GoalsJourney({ routeId }: { routeId?: string }) {
  useDesignV()
  const navigate = useNavigate()
  const location = useLocation()
  const me = useAuthStore((s) => s.identity?.name) ?? 'You'
  const st = useJourney()
  const { goals, order, saved, current, start } = st
  const j = current ? goals[current] : null
  const [tab, setTabRaw] = useState<Tab>('plan')
  /* One set of tabs, always in the same order; "runs" and "outputs" from older links land on their new homes. */
  const setTab = (t: Tab) => setTabRaw(t === 'runs' ? 'findings' : t === 'outputs' ? 'deliverables' : t)
  const [sel, setSel] = useState<string | null>(null)
  const [panelOpen, setPanelOpen] = useState(true)
  const [convHidden, setConvHidden] = useState(false)
  const [drawer, setDrawer] = useState<Drill | null>(null)
  const [text, setText] = useState('')
  const [target, setTarget] = useState<string | null>(null)
  const [menu, setMenu] = useState<null | 'main' | 'onedrive' | 'outlook'>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const feedRef = useRef<HTMLDivElement>(null)
  const endRef = useRef<HTMLDivElement>(null)
  useStickToBottom(feedRef)
  useSlashToSearch()
  const startSubmission = useSubmissionStore((s) => s.startFromGoal)
  const templates = useSubmissionStore((s) => s.templates)

  /* arriving by link */
  useEffect(() => { if (!routeId) return; if (goals[routeId]) { if (current !== routeId) st.open(routeId); return } const alias = order.map((id) => goals[id]).find((x) => x && baseIdOf(x) === routeId && x.findings.length); if (alias) navigate(appPath(`/goals/${alias.id}`), { replace: true }) }, [routeId]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!routeId && location.state && (location.state as { fresh?: boolean }).fresh) st.open(null) }, [location.key]) // eslint-disable-line react-hooks/exhaustive-deps
  /* the panel follows the step: an event from the store opens a tab */
  useEffect(() => { const on = (e: Event) => { const d = (e as CustomEvent).detail; if (d?.id === current) { setTab(d.tab); setPanelOpen(true) } }; window.addEventListener('cw:tab', on); return () => window.removeEventListener('cw:tab', on) }, [current])
  useEffect(() => { const on = (e: Event) => { const t = (e as CustomEvent).detail as Tab; if (t) { setTab(t); setPanelOpen(true) } }; window.addEventListener('cw:go', on); return () => window.removeEventListener('cw:go', on) }, [])
  useEffect(() => { const on = (e: Event) => { const d = (e as CustomEvent).detail; if (d?.sid) navigate(appPath(`/submissions/${d.sid}`)) }; window.addEventListener('cw:open-sub', on); return () => window.removeEventListener('cw:open-sub', on) }, [navigate])
  /* "Make more deliverables": Submissions opens with this run picked. */
  useEffect(() => { const on = (e: Event) => { const d = (e as CustomEvent).detail; if (d?.id) navigate(appPath('/submissions/new'), { state: { fromJourney: d.id } }) }; window.addEventListener('cw:more', on); return () => window.removeEventListener('cw:more', on) }, [navigate])
  const subsAll = useSubmissionStore((s) => s.submissions)
  const [delivOn, setDelivOn] = useState<string | null>(null)
  useEffect(() => { setSel(null); setTarget(null); setText(''); setMenu(null); if (j) setTab(Object.keys(j.built).length && ['delivered', 'executed'].includes(j.status) ? 'deliverables' : (j.stage === 'running' && j.status === 'running') || ['fired', 'executing'].includes(j.status) ? 'workflow' : isTargetGoal(j) && j.stage === 'armed' && j.status === 'armed' && Object.keys(j.built).length ? 'deliverables' : 'plan') }, [current]) // eslint-disable-line react-hooks/exhaustive-deps
  /* the tab follows the run: workflow while running, findings when they land */
  const prevStatus = useRef<string>('')
  useEffect(() => { if (!j) return; const k = `${j.stage}:${j.status}`; if (prevStatus.current && prevStatus.current !== k) { if (j.stage === 'running' && j.status === 'running' && prevStatus.current.startsWith('plan')) { setTab('workflow'); setSel(null) } if (j.status === 'fired') { setTab('workflow'); setSel(null) } if (isTargetGoal(j) && k === 'armed:armed' && !prevStatus.current.startsWith('armed')) { setTab('deliverables'); setPanelOpen(true) } } prevStatus.current = k }, [j?.stage, j?.status]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }) }, [j?.chat.length, j?.typing, current])
  const dock = useDock(feedRef, [j?.chat.length, current, j?.status, j?.typing])

  const startOut = (o: { id: string; label: string }) => { if (!j) return; const full = j.outputs.find((x) => x.id === o.id); if (!full) return; const sid = startSubmission(baseGoal(j), full, me); st.markStarted(j.id, full.id); window.setTimeout(() => navigate(appPath(`/submissions/${sid}`)), 700) }
  const send = (t: string) => {
    const v = t.trim(); if (!v || !j) return; setText(''); setTarget(null)
    void startOut
    if (/^execute$/i.test(v) && j.exec?.state === 'confirm') { st.execute(j.id); return }
    if (/^not now$/i.test(v) && j.exec?.state === 'confirm') { st.notNow(j.id); return }
    st.input(j.id, v)
  }
  const prefill = (t: string) => { setText(t); window.setTimeout(() => { const ta = document.querySelector<HTMLTextAreaElement>('.hub-input textarea, .start textarea'); ta?.focus(); ta?.setSelectionRange(t.length, t.length) }, 30) }
  const editRow = (k: string) => { setTarget(k); prefill(`${LABELS[k] ?? k}: `) }
  const openStep = (id: string) => { setTab('workflow'); setSel(id); setPanelOpen(true) }

  /* ---------------- the start screen */
  const upload = async (f: File) => {
    const r = await readUpload(f)
    const att: Att = { id: 'up', n: r.name, s: describeRead(r) }
    if (!j) { st.setStart({ files: [...start.files, att] }); if (!start.prompt && r.problem) st.setStart({ prompt: r.problem }); return }
    void st.attach(j.id, [att], text.trim() || undefined); setText('')
  }
  const pick = (id: string) => { const f = LIB[id]; const att: Att = { id, n: f.n, s: f.ext }; setMenu(null); if (!j) { if (!start.files.some((a) => a.id === id)) st.setStart({ files: [...start.files, att] }); return } void st.attach(j.id, [att], text.trim() || undefined); setText('') }
  const menuEl = () => {
    if (!menu) return null
    const web = j ? j.web : start.web
    const toggleWeb = () => { if (j) void st.toggleWeb(j.id); else st.setStart({ web: !start.web }); setMenu(null) }
    if (menu === 'onedrive' || menu === 'outlook') {
      const files = Object.values(LIB).filter((f) => f.from === menu)
      return (
        <div className="cmenu" role="menu">
          <button className="mi mi-back" type="button" onClick={() => setMenu('main')}>‹ <b>{menu === 'onedrive' ? 'OneDrive' : 'Outlook'}</b></button>
          <div className="menu-h">Suggested for this goal</div>
          {files.map((f) => <button key={f.id} className="mi" type="button" role="menuitem" onClick={() => pick(f.id)}><span className="mi-ic">{f.icon === 'mail' ? <MailOutlined /> : <FileTextOutlined />}</span><span><b>{f.n}</b><small>{f.ext}</small></span></button>)}
          <div className="menu-sep" />
          <button className="mi" type="button" role="menuitem" onClick={() => { setMenu(null); setDrawer({ view: menu === 'outlook' ? 'mail' : 'documents', note: '' }) }}><span className="mi-ic"><FolderOpenOutlined /></span><span><b>Browse everything</b><small>{menu === 'outlook' ? '12 threads in the role’s mailbox' : '21 documents in the Capital Program folder'}</small></span></button>
        </div>
      )
    }
    return (
      <div className="cmenu" role="menu">
        <div className="menu-h">Add to this goal</div>
        <button className="mi" type="button" role="menuitem" onClick={() => { setMenu(null); fileRef.current?.click() }}><span className="mi-ic"><UploadOutlined /></span><span><b>Upload from your computer</b><small>PowerPoint, Word, PDF, text, CSV</small></span></button>
        <div className="menu-sep" />
        <div className="menu-h">Connected</div>
        <button className="mi" type="button" role="menuitemcheckbox" aria-checked={web} onClick={toggleWeb}><span className="mi-ic"><GlobalOutlined /></span><span><b>Web search</b><small>Public sources, always cited</small></span><span className={`sw${web ? ' is-on' : ''}`}><i /></span></button>
        <button className="mi" type="button" role="menuitem" onClick={() => setMenu('onedrive')}><span className="mi-ic"><FolderOpenOutlined /></span><span><b>OneDrive</b><small>Connected · 21 documents</small></span><span className="mi-r">›</span></button>
        <button className="mi" type="button" role="menuitem" onClick={() => setMenu('outlook')}><span className="mi-ic"><MailOutlined /></span><span><b>Outlook</b><small>Connected · 12 threads</small></span><span className="mi-r">›</span></button>
        <button className="mi" type="button" role="menuitem" onClick={() => { setMenu(null); if (j) { setTab('data'); setPanelOpen(true) } else setDrawer({ view: 'scorecard', note: '' }) }}><span className="mi-ic"><DatabaseOutlined /></span><span><b>Operations data hub · northline</b><small>Connected · opens the worksheet</small></span><span className="mi-r">›</span></button>
      </div>
    )
  }
  const composer = (big?: boolean) => {
    const atts = j ? [] : start.files
    const web = j ? j.web : start.web
    const on = j ? j.composer.on : true
    const ph = j ? (target ? 'Type the new value after the label, then send' : j.composer.ph) : start.mode === 'once' ? 'e.g. Which contracts in the Southeast have no backup for the licence the contract requires?' : 'e.g. Tell me when a client puts in-house operation on a council agenda.'
    const go = () => { if (j) send(text); else if (start.prompt.trim() || atts.length) { setText(''); const id = st.begin(); navigate(appPath(`/goals/${id}`)) } }
    return (
      <div className={`composer${big ? ' is-big' : ''}${on ? '' : ' is-off'}`}>
        {atts.length ? <div className="cmp-att">{atts.map((f, i) => <span key={`${f.n}${i}`} className="att"><FileTextOutlined /><span>{f.n}</span><small>{f.s}</small><button type="button" aria-label={`Remove ${f.n}`} onClick={() => st.setStart({ files: atts.filter((_, k) => k !== i) })}><CloseOutlined /></button></span>)}</div> : null}
        <Input.TextArea value={j ? text : start.prompt} disabled={!on} onChange={(e) => (j ? setText(e.target.value) : st.setStart({ prompt: e.target.value }))} autoSize={{ minRows: big ? 3 : 1, maxRows: 7 }} variant="borderless" aria-label="Message" placeholder={ph}
          onPressEnter={(e) => { if (!e.shiftKey) { e.preventDefault(); go() } }} />
        <div className="cmp-bar">
          <button className="cmp-btn" type="button" aria-label="Add documents or connect a source" aria-expanded={!!menu} onClick={() => setMenu(menu ? null : 'main')} disabled={!on}><PlusOutlined /></button>
          {web ? <span className="tool-pill"><GlobalOutlined /> Web search<button type="button" aria-label="Turn web search off" onClick={() => (j ? void st.toggleWeb(j.id) : st.setStart({ web: false }))}><CloseOutlined /></button></span> : null}
          <span className="spacer" />
          <button className={`send${(j ? text.trim() : start.prompt.trim() || atts.length) ? ' is-on' : ''}`} type="button" aria-label="Send" disabled={!on || !(j ? text.trim() : start.prompt.trim() || atts.length)} onClick={go}><ArrowUpOutlined /></button>
        </div>
        {menuEl()}
      </div>
    )
  }

  const renderStart = () => {
    const once = start.mode === 'once'
    return (
      <div className="start">
        <div className="nstart">
          <div className="ns-toggle" role="tablist" aria-label="Kind of goal">
            <button type="button" role="tab" aria-selected={once} className={once ? 'is-on' : ''} onClick={() => st.setStart({ mode: 'once', approachId: undefined })}>Answer once</button>
            <button type="button" role="tab" aria-selected={!once} className={once ? '' : 'is-on'} onClick={() => st.setStart({ mode: 'watch', approachId: undefined })}>Keep watching</button>
          </div>
          <h1 className="ns-q">{once ? 'What do you need to find out?' : 'What should I keep an eye on?'}</h1>
          <p className="ns-sub">{once ? 'Brief it the way you would brief an analyst. I ask only what I cannot find and what you want at the end, then run it to the end and hand you the deliverables.' : 'Say what to watch, in plain words. We agree how it is measured, what you want to see and what happens when something changes. Then it watches and tells you.'}</p>
          {composer(true)}
          <div className="ns-ex">
            {once ? <>
              <button className="gc-chip" type="button" onClick={() => st.setStart({ prompt: ONCE_PROMPT, files: ONCE_FILES, approachId: undefined })}>Use the renewal risk review example</button>
              <button className="gc-chip" type="button" onClick={() => st.setStart({ prompt: 'Harlow Creek moved from 2 to 3 overnight after a demand letter and a sixth odor complaint: why, and what should we do about it?', files: [], approachId: undefined })}>Harlow Creek moved from 2 to 3 overnight: why, and what do we do?</button>
            </> : <>
              <button className="gc-chip" type="button" onClick={() => st.setStart({ prompt: WATCH_PROMPT, files: [], approachId: undefined })}>Use the contract risk example: build a scorecard from nothing</button>
              <button className="gc-chip" type="button" onClick={() => st.setStart({ prompt: 'Before every quarterly portfolio review, refresh the renewal risk review and update the pack.', files: ONCE_FILES, approachId: 'schedule' })}>Renewal review before every portfolio review</button>
            </>}
          </div>
          {saved.filter((a) => a.mode === start.mode).length ? <>
            <div className="ns-h">Or start from a saved plan</div>
            <div className="ns-cards">{saved.filter((a) => a.mode === start.mode).map((a) => <button key={a.id} className="ns-card" type="button" onClick={() => st.setStart({ prompt: a.prompt, files: a.files, approachId: a.id, mode: a.mode })}><b>{a.name}</b><span>{a.steps.length} steps · from “{a.from}” · saved by {a.by}, {a.at}</span></button>)}</div>
          </> : null}
          {once ? <div className="ns-standing"><BellOutlined /><div>Want this to run on a schedule, or when something changes in the data? That is a <a onClick={() => st.setStart({ mode: 'watch' })}>standing goal</a>: it watches instead of answering once.</div></div>
            : <><div className="ns-h">How a standing goal differs</div><div className="ns-cards is-three"><div className="ns-card is-static"><b>It has a trigger, not a deadline</b><span>A rule checked in your data, your mail and on the web, or a schedule. It stays armed between checks.</span></div><div className="ns-card is-static"><b>It runs, decides and acts by itself</b><span>It builds what you agreed and follows the rules you set for when something changes. A rule can run by itself or wait for your OK.</span></div><div className="ns-card is-static" data-testid="ns-target"><b>It builds the scorecard with you</b><span>It proposes what to measure, with the reason and the source for each signal. You decide the signals, the weights and the scoring. Then it reads every source itself, so nobody collates anything.</span></div></div><div className="ns-standing"><CheckOutlined /><div>Need one answer, now? Switch to <a onClick={() => st.setStart({ mode: 'once' })}>Answer once</a>.</div></div></>}
        </div>
      </div>
    )
  }

  /* ---------------- the plan document */
  const dashV = useDesign((x) => x.versions.length)
  const R = (k: string) => !!j && (j.stage !== 'reading' || j.rv.includes(k))
  const canEdit = !!j && ['questions', 'plan'].includes(j.stage)
  const ov = (k: string, val: RowVal | null): RowVal | null => (j?.over[k] ? { v: j.over[k], tag: 'you', label: 'You', sub: 'Edited by you.' } : val)
  const skel = (w: string) => <span className="skel blk" style={{ width: w }} />

  const stepsList = () => {
    if (!j) return null
    const ns = liveNodes(j).slice().sort((a, b) => a.col - b.col || a.row - b.row)
    const cols: Node[][] = []
    ns.forEach((n) => { (cols[n.col] = cols[n.col] || []).push(n) })
    let k = 0
    const num: Record<string, number> = {}
    ns.forEach((n) => { if (n.type !== 'checkpoint' && !n.fork) { k += 1; num[n.id] = k } })
    const li = (n: Node) => {
      const s = j.ns[n.id]?.state ?? 'pending'
      const glyph = s === 'done' ? <CheckOutlined /> : s === 'wait' || n.type === 'checkpoint' ? '!' : n.fork ? '+' : num[n.id]
      const stText = { done: 'Done', running: 'Running', wait: 'Waits for you', stale: 'Re-running', pending: '' }[s]
      return (
        <li key={n.id} className={`st is-${s}${n.type === 'checkpoint' ? ' is-cp' : ''}`}>
          <button className="st-row" type="button" onClick={() => openStep(n.id)}>
            <span className="sn">{glyph}</span>
            <span className="st-b"><b>{n.title}</b><span>{n.type === 'checkpoint' ? n.how : n.purpose}</span>{n.type === 'checkpoint' ? null : <small>Uses {n.draws.join(' · ')}</small>}</span>
            <span className="st-state">{stText}</span>
          </button>
          {canEdit && n.type !== 'checkpoint' && !n.fork ? <span className="st-tools"><a onClick={() => { send(`Drop the step: ${n.title}`); st.removeStep(j.id, n.id) }}>remove</a></span> : null}
        </li>
      )
    }
    const removed = j.nodes.filter((n) => j.removed.includes(n.id))
    return <>
      <ol className="steps">{cols.filter(Boolean).map((list, i) => list.length > 1 ? <li key={i} className="st-par"><span className="st-par-h">Side by side</span><ol className="steps">{list.map(li)}</ol></li> : li(list[0]))}</ol>
      {removed.length ? <div className="st-removed">{removed.map((n) => <span key={n.id}>Removed: {n.title}{canEdit ? <> · <a onClick={() => st.restoreStep(j.id, n.id)}>put back</a></> : null}</span>)}</div> : null}
    </>
  }

  /* ---------------- open points: missing until clarified, then green */
  const ANS_FROM = (key: string) => { if (!j) return ''; if (j.armedBy && j.armedBy !== 'You' && !j.chat.some((m) => m.card?.kind === 'q')) return `Set by ${j.armedBy} at set-up`; const c = j.chat.find((m) => m.card?.kind === 'q' && m.card.key === key && m.card.done)?.card?.done; const q = j.questions.find((x) => x.key === key); const tile = q?.tiles.find((t) => t.v === j.answers[key]); if (!c || c === tile?.t) return 'Your answer in the chat'; return /^from |^changed/.test(c) ? `Settled ${c}` : 'Your answer in the chat' }
  const POINT_NEED: Record<string, string> = { four: 'Whether the evergreen contracts count as up for renewal: they have no end date in the window, but each client can end on notice.', t3: 'How to treat an NPS answer given by a client lead who has since changed. The scorecard has no rule for it.', frame: 'Whether you have a scoring template. None is connected.', design: j?.rv.includes('sheet') ? 'The scorecard: factors, weights, signals and the rule for 1 to 4 on each. It is below for you to agree.' : 'The scorecard: factors, weights, signals and the rule for 1 to 4 on each. It comes after your answer on the template.', check: j?.rv.includes('sheet') ? 'The assumptions that bring every figure to one score per project. They are in the data check below.' : 'The assumptions that bring every figure to one score per project. I list them once the scorecard is there.', tell: 'Who is told when it has run.' }
  const POINT_TITLE: Record<string, string> = { four: 'The evergreen contracts', t3: 'NPS answers from a predecessor', frame: 'A scoring template', design: 'The scorecard, agreed', check: 'The data check, confirmed', tell: 'Who is told' }
  const openPoints = (): React.ReactNode[] => {
    if (!j) return []
    const out: React.ReactNode[] = j.questions.map((q) => {
      const v = j.answers[q.key]
      const tile = q.tiles.find((t) => t.v === v)
      const done = v ? (tile?.t ?? v) : null
      return (
        <div key={q.key} className={`miss${done ? ' is-done' : ''}`} data-point={q.key}>
          <div className="miss-h"><b>{POINT_TITLE[q.key] ?? q.title}</b><span className={`tag ${done ? 'ok' : 'need'}`}>{done ? <><CheckOutlined /> Clarified</> : 'Missing'}</span></div>
          <p>{done ? <><b className="miss-a">{done}.</b> {tile?.s ? <span>{tile.s}.</span> : null}</> : POINT_NEED[q.key] ?? q.text}</p>
          {done ? <small>{ANS_FROM(q.key)}{j.flags.steered && q.key === 'four' ? '; changed after the run' : ''}</small> : <small className="miss-ask">{openQuestion(j) === q.key ? 'Asked in the chat now' : 'Asked in the chat, one at a time'}</small>}
        </div>
      )
    })
    const on = j.deliv.filter((d) => d.on)
    const dd = j.delivConfirmed
    out.push(
      <div key="deliv" className={`miss${dd ? ' is-done' : ''}`} data-point="deliv">
        <div className="miss-h"><b>{j.case === 'watch' ? 'The dashboard, and what I do when risk goes up' : j.mode === 'watch' ? 'What it builds and what it may do' : 'What you want at the end'}</b><span className={`tag ${dd ? 'ok' : 'need'}`}>{dd ? <><CheckOutlined /> Clarified</> : 'Missing'}</span></div>
        <p>{dd ? <><b className="miss-a">{on.map((d) => d.label.split(':')[0]).join(', ')}.</b>{j.acts.length ? <span> {j.acts.filter((a) => a.mode === 'auto').length} kinds of action by itself, {j.acts.filter((a) => a.mode === 'ask').length} for your OK.</span> : null}</> : j.case === 'watch' ? 'What the dashboard shows and what happens when a score rises. Both are proposed on the plan once the scorecard is there.' : 'Which deliverables to build at the end and the template for each: the one I recommend, one from your library, your own file, or one I design.'}</p>
        {dd ? <small>{j.armedBy && j.armedBy !== 'You' ? `Agreed by ${j.armedBy} at set-up` : 'Agreed in the chat'}</small> : <small className="miss-ask">{j.chat.some((m) => m.card?.kind === 'deliv' && !m.card.done) ? 'Asked in the chat now' : 'Asked last, before the run'}</small>}
      </div>,
    )
    return out
  }
  const pointsSub = () => { if (!j) return ''; const n = j.questions.length + 1; const d = j.questions.filter((q) => j.answers[q.key]).length + (j.delivConfirmed ? 1 : 0); return d === n ? `all ${n} clarified` : `${d} of ${n} clarified` }
  const delivSec = (lead: string) => {
    if (!j) return null
    const on = j.deliv.filter((d) => d.on)
    return (
      <Sec title="What you’ll get" id="get" right={Object.keys(j.built).length ? <a onClick={() => setTab('deliverables')}>Open the deliverables</a> : null}>
        <ul className="dl-l">{on.map((d) => <li key={d.id}><FileTextOutlined /><span><b>{d.label}</b><small>For {d.audience} · on {templateLine(d, templates)}</small></span>{j.built[d.id] ? <span className="tag ok">Built</span> : <span className={`tag ${j.delivConfirmed ? 'inf' : 'need'}`}>{j.delivConfirmed ? 'At the end of the run' : 'Proposed'}</span>}</li>)}</ul>
        <p className="pd-intro" style={{ marginTop: 8 }}>{j.delivConfirmed ? lead : 'Proposed from your brief and the library; agree it in the chat, then it runs.'}</p>
      </Sec>
    )
  }

  const planOnce = () => {
    if (!j) return null
    const p = j
    const isQ3 = p.case === 'once' || p.case === 'schedule'
    const isOvr = p.case === 'overrun-once'
    const who = p.who ? { v: p.who, tag: 'you' as const, sub: 'From your answer. The plan is timed to it.' } : isQ3 ? { v: 'Renee Halvorsen, SVP Contract Operations: pack by Friday 27 November; portfolio review with the leadership team on Wednesday 2 December.', tag: 'you' as const, sub: 'From your brief and Renee’s mail of 16 November.' } : isOvr ? { v: 'Marisol Vega, Regional VP Southeast, with Legal: the demand letter asks for a response by 19 December.', tag: 'inf' as const, sub: 'From the contract master and the letter.' } : { v: 'Not stated.', tag: 'need' as const, soft: true, sub: 'Say who decides and by when, or leave it.' }
    const brief = isQ3 ? [
      ['question', ov('question', { v: 'Of the contracts that decide in the next 18 months, which are we most likely to lose, what are they worth and what should we do about each; and would our scorecard have warned us about the renewals we already lost?', tag: 'you', sub: 'Your words, tightened.' }), ''],
      ['decision', R('decision') ? ov('decision', { v: 'Which contracts go on a renewal plan now, and who leads each.', tag: 'inf', sub: 'From Renee’s request and last year’s review.' }) : null, 'Reading what the review is for…'],
      ['who', who, ''],
      ['scope', R('scope') ? ov('scope', { v: 'All 300 agreements read for end date, options and termination rights; the contracts that decide in 18 months; their scorecard rating, client mail, council agendas and local news; the three renewals lost since 2024.', tag: 'inf', sub: 'Matched the brief to the contract master, the agreements, the scorecard and the renewals folder.' }) : null, 'Matching the brief to the warehouse…'],
      ['success', R('success') ? ov('success', { v: 'Every end date is read from its agreement; every client-side sign points at a dated source; the scorecard rating is used as written and never mixed with the signs; the pack follows the five sections of 2025.', tag: 'inf', sub: 'From role memory and last year’s review. Say “you decide” to let me set it.' }) : null, 'Looking for a measure in role memory…'],
    ] : isOvr ? [
      ['question', ov('question', { v: 'Harlow Creek moved from 2 to 3 overnight after a demand letter and a sixth odor complaint: why, what does the agreement say, and what should we do about it?', tag: 'you', sub: 'Your words, tightened.' }), ''],
      ['decision', R('decision') ? ov('decision', { v: 'What to do about each contract that changed, and who does it.', tag: 'inf', sub: 'From the site plans and the claims procedure.' }) : null, 'Reading the matrix…'],
      ['who', who, ''],
      ['scope', R('scope') ? ov('scope', { v: 'The three contracts that changed at the 20 November check; their agreements, the mail and documents behind each change, and the pages on the web.', tag: 'inf', sub: 'The other 297 contracts are out of scope.' }) : null, 'Scoping to the contracts…'],
      ['success', R('success') ? ov('success', { v: 'Every rating recomputes from its signals; every change points at a dated source; every action has an owner and a date, including “do nothing”.', tag: 'inf', sub: 'From role memory.' }) : null, 'Looking for a measure…'],
    ] : [
      ['question', ov('question', { v: esc(p.prompt), tag: 'you', sub: 'Your words.' }), ''],
      ['decision', R('decision') ? ov('decision', { v: 'Not stated; I take it from the goal as the run goes.', tag: 'need', soft: true, sub: 'Edit this row to name the decision.' }) : null, 'Reading…'],
      ['who', who, ''],
      ['scope', R('scope') ? ov('scope', { v: 'The role graph: 300 contracts, the signals of the scorecard, the agreements, the tracked actions, documents, mail and web pages.', tag: 'inf', sub: 'Everything the Contract Risk Analyst role holds.' }) : null, 'Matching…'],
      ['success', R('success') ? ov('success', { v: 'Totals reconcile to the governed measures; nothing is attributed without a dated reference.', tag: 'inf', sub: 'From role memory.' }) : null, 'Looking for a measure…'],
    ]
    const docs = [
      isQ3 && R('doc:q2') && { n: 'Renewal_Review_2025-12.pptx', took: 'Took: the five sections of last year’s review; used as the template for the pack', drill: LIB.deck.drill },
      isQ3 && R('doc:deck') && { n: 'Calder_Valley_Loss_Review_2026-03.pdf', took: 'Took: lost at re-bid after a new client lead, an adviser and a stale NPS; the pattern to test the scorecard against', drill: { view: 'documents', doc: 'DOC:calder-review', note: '' } as Drill },
      ...(j.files.filter((f) => f.id === 'seed' && !isQ3).map((f) => ({ n: f.n, took: 'Read' }))),
    ].filter(Boolean) as { n: string; took: string; drill?: Drill }[]
    const extra = j.extraDocs.map((d) => ({ n: d.n, took: d.took, mine: true, drill: d.drill }))
    const srcs = isOvr ? [
      <Src onOpen={setDrawer} key="po" n="Scorecard" t="300 contracts · every signal" m="Every reading with its band and its source" drill={{ view: 'contract', contract: 'NCO-047', note: '' }} />,
      <Src onOpen={setDrawer} key="fw" n="The signed agreement" t="Harlow_Creek_OM_Agreement_2018.pdf" m="Liability, odor control capital, termination" drill={{ view: 'documents', doc: 'DOC:hc-contract', note: '' }} />,
      R('src:mail') && <Src onOpen={setDrawer} key="mail" n="Outlook · OneDrive" t="legal notices · operations mail" m="The demand letter and the project leader’s mail" drill={{ view: 'mail', thread: 'H1', note: '' }} />,
    ].filter(Boolean) : [
      R('src:fin') && <Src onOpen={setDrawer} key="fin" n="Contract master and agreements" t="master.contract · 300 signed agreements" m="End dates, renewal options and termination rights, read from each agreement" drill={{ view: 'renewals', note: '' }} />,
      R('src:ppm') && <Src onOpen={setDrawer} key="ppm" n="Scorecard" t="Factors and signals" m="The rating of every contract on the scorecard you agreed" drill={{ view: 'scorecard', note: '' }} />,
      R('src:ins') && <Src onOpen={setDrawer} key="ins" n="Contract ledger" t="fin.contract_pnl" m="Revenue and margin by contract, October" drill={{ view: 'renewals', note: '' }} />,
      R('src:mail') && <Src onOpen={setDrawer} key="mail" n="Outlook · OneDrive" t="leadership and operations mail · renewals folder" m="Client correspondence and last year’s review" drill={{ view: 'mail', note: '' }} />,
      j.stage !== 'reading' && <Src onOpen={setDrawer} key="p6" n="Client procurement portals" m="Not connected; a tender is seen only when it reaches an agenda, the news or the mail" off />,
    ].filter(Boolean)
    /* Open points: what only you could answer, shown as missing until it is clarified, then green with the answer and where it came from. Gaps in the data stay as gaps. */
    const missing: React.ReactNode[] = openPoints()
    if (isQ3 && R('miss:t3') && j.stage !== 'reading') missing.push(<div key="t3gap" className="miss is-gap" data-point="gap-confirmations"><div className="miss-h"><b>What the new client leads think of us</b><span className="tag inf">Gap · noted</span></div><p>{p.web ? 'Council agendas and local news were read for every client in the set.' : 'The score on file for these contracts was given by a predecessor.'} A fresh answer needs a pulse survey; the review lists the contracts.</p></div>)
    if (isOvr && j.stage !== 'reading') missing.push(<div key="pm" className="miss is-gap" data-point="gap-confirm"><div className="miss-h"><b>Whether the City received the same letter</b><span className="tag inf">Gap · noted</span></div><p>The City Attorney was copied. How the City responds is not known yet.</p></div>)
    if (p.case === 'generic' && R('miss:generic')) missing.push(<div key="g" className="miss is-gap" data-point="gap-generic"><div className="miss-h"><b>A recorded analysis for this goal</b><span className="tag inf">Gap · noted</span></div><p>This copy carries recorded analyses for the renewal review and the contract risk watch. The run shows the graph’s position and ends on a question.</p></div>)
    const given: [string, string, RowVal | null][] = []
    if (R('fixed')) {
      if (isQ3) { given.push(['g:fixed1', 'The scorecard', ov('g:fixed1', { v: 'Ratings are those of the scorecard you agreed: its factors, weights and bands.', tag: 'you', label: 'Fixed', sub: 'From the scorecard. Never varied except in a what-if you ask for.' })]); given.push(['g:fixed2', 'Client-side signs', ov('g:fixed2', { v: 'Shown beside the scorecard rating, never mixed into it.', tag: 'you', label: 'Fixed', sub: 'From role memory.' })]); given.push(['g:fixed3', 'Pack structure', ov('g:fixed3', { v: 'The five sections of the December 2025 review; the plan and the briefs draw on the same figures.', tag: 'you', label: 'Fixed', sub: 'From your brief and Renee’s mail.' })]) }
      else if (isOvr) { given.push(['g:fixed1', 'The scorecard', ov('g:fixed1', { v: 'The bands and weights of the scorecard you agreed.', tag: 'you', label: 'Fixed' })]); given.push(['g:fixed2', 'After a written demand', ov('g:fixed2', { v: 'Contact with the claimants about the matter goes through Legal.', tag: 'you', label: 'Fixed', sub: 'Claims notice and legal hold procedure, item 4.' })]) }
      else given.push(['g:fixed1', 'Approved budgets', ov('g:fixed1', { v: 'Move only by WIN budget revision.', tag: 'you', label: 'Fixed', sub: 'From role memory.' })])
      p.fixedExtra.forEach((t, i) => given.push([`g:x${i}`, 'Also fixed', ov(`g:x${i}`, { v: esc(t), tag: 'you', label: 'Fixed' })]))
    }
    if (isQ3 && R('as:four')) {
      const A: Record<string, RowVal> = {
        june: { v: 'Counted as deciding in the window: each client can end on notice.', tag: 'you', label: 'Your call', sub: 'What the Calder Valley review recommends.' },
        standin: { v: 'Left out: no end date in the window. The review covers fewer contracts for that reason only.', tag: 'you', label: 'Your call', sub: 'Contracts the client can end on notice are not covered; flagged as a judgement.' },
        wait: { v: 'Counted as deciding in the window.', tag: 'you', label: 'Your call' },
        ask: { v: 'Counted as deciding in the window.', tag: 'you', label: 'Your call' },
      }
      given.push(['as:four', 'Evergreen contracts', ov('as:four', p.answers.four ? (p.flags.steered && p.answers.four === 'standin' ? { ...A.standin, sub: 'Changed during the run.' } : A[p.answers.four]) : { v: 'Whether contracts that renew by themselves, and that the client can end on notice, count as up for renewal.', tag: 'need', label: 'Needs your call', sub: 'They have no end date in the next 18 months.' })])
    }
    if (isQ3 && R('as:t3')) {
      const web = p.web ? ' The public docket shows the update still due 13 November.' : ''
      const T: Record<string, RowVal> = { out: { v: 'The scorecard is kept as written; contracts whose NPS was given by a predecessor are flagged in the review.', tag: 'you', label: 'Your call', sub: `The rating does not change.${web}` }, expected: { v: 'The score is kept and the contracts are listed separately for the client experience team.', tag: 'you', label: 'Your call', sub: `A list, no flag in the pack.${web}` }, approved: { v: 'The score is kept as surveyed, with no flag.', tag: 'you', label: 'Your call', sub: 'As the scorecard does today.' + web } }
      given.push(['as:t3', 'NPS from a predecessor', ov('as:t3', p.answers.t3 ? T[p.answers.t3] : { v: 'How to treat an NPS answer given by a client lead who has since changed.', tag: 'need', label: 'Needs your call', sub: 'The scorecard has no rule for it.' + web })])
    }
    if (isQ3 && R('memory')) given.push(['as:tol', 'At risk', { v: 'A contract is at risk if it rates 3 or 4, or shows a client-side sign with twelve months or less to run.', tag: 'inf', label: 'Assumed', sub: 'From the Calder Valley review and role memory. Edit it to change the test.' }])
    if (isOvr && R('memory')) given.push(['as:lift', 'The City', { v: 'That the City of Harlow Creek has not yet answered the letter.', tag: 'need', soft: true, label: 'Assumption', sub: 'The City Attorney was copied on 19 November.' }])
    const due = isQ3 ? 'ready for Renee by 27 November' : isOvr ? 'ready this morning, for the Regional VP and Legal' : 'ready when the run ends'
    const get = `Built at the end of the run on the top recommendation, every figure linked to the step that produced it, ${due}. I accept the findings for you and keep them, with the other options, under Findings; change anything afterwards in the chat and the deliverables are rebuilt.`
    return (
      <div className="pd">
        <div className="pd-status">{statusLine()}{legend}</div>
        {j.stage !== 'reading' ? <Sec title="Open points" id="points" right={pointsSub()} intro="What only you could answer. Each one turns green once it is clarified in the chat."><div className="pts">{missing}</div></Sec> : null}
        <Sec title="The brief"><div className="bf">{brief.map(([k, val, pend]) => <BriefRow key={k as string} k={k as string} label={LABELS[k as string]} val={val as RowVal | null} pending={pend as string} target={target} canEdit={canEdit} onEdit={editRow} />)}</div></Sec>
        <Sec title="What I’m working from" id="ctx" intro="Everything the steps may draw on. Add to it from the chat: upload, pick a file from a connected source, or just tell me.">
          <div className="ctx">
            <Grp title="Your documents">{docs.length || extra.length ? <div className="docs">{docs.map((d) => <Doc key={d.n} {...d} onOpen={setDrawer} onRemove={(n) => st.rmDoc(j.id, n)} />)}{extra.map((d) => <Doc key={d.n} {...d} onOpen={setDrawer} onRemove={(n) => st.rmDoc(j.id, n)} />)}</div> : j.stage === 'reading' ? skel('60%') : <span className="none">None attached.</span>}</Grp>
            <Grp title="Connected data">{srcs.length ? srcs : skel('70%')}</Grp>
            {R('memory') ? <Grp title="Company context" sub="role memory · Contract Risk Analyst">{isOvr ? <ul className="mem"><li>The scorecard is used as written; an unclear band is read one way and the reading is stated</li><li>A rating read from a contract clause is a draft until Legal confirms it</li><li>After a written demand, contact with claimants goes through Legal</li></ul> : <ul className="mem"><li>The scorecard is used as written</li><li>Client-side signs are shown beside the rating, never inside it</li><li>A rating read from a contract clause is a draft until Legal confirms it</li><li>An NPS answer given by a predecessor is marked as such</li></ul>}</Grp> : null}
            {isQ3 && R('src:mail') ? <Grp title="Earlier work"><div className="src"><b>Renewal review, December 2025</b><span /><span>Presented 3 December 2025 · five sections · Calder Valley was lost two weeks later</span></div></Grp> : null}
            {isOvr && R('prior') ? <Grp title="Earlier work"><div className="src"><b>Watch: a contract’s risk changes</b><span /><span>Armed 12 Nov by Renee Halvorsen · checks every morning at 06:00</span></div></Grp> : null}
            {p.web ? <Grp title="From the web" sub="cited where it is used"><ul className="mem"><li>Council agendas and minutes of the clients in the set (public)</li><li>Local news about each plant and client</li></ul></Grp> : null}
          </div>
        </Sec>
        <Sec title="What I’m taking as given" id="given">{given.length ? <div className="bf">{given.map(([k, label, val]) => <BriefRow key={k} k={k} label={label} val={val} target={target} canEdit={canEdit} onEdit={editRow} />)}</div> : <>{skel('80%')}{skel('60%')}</>}</Sec>
        <Sec title="How I’ll go about it" right={R('steps') ? <a onClick={() => { setTab('workflow'); setSel(null) }}>Open as a workflow</a> : null}>{R('steps') ? stepsList() : <><p className="pd-intro">Drafted once I have read everything.</p>{skel('70%')}{skel('55%')}{skel('64%')}</>}</Sec>
        {R('steps') ? delivSec(get) : null}
        {j.history.length ? <Sec title="Changes" right={`v${j.version}`}><ul className="hist">{j.history.slice().reverse().map((h, i) => <li key={i}><time>{h.t}</time><span>{h.what}</span></li>)}</ul></Sec> : null}
        {foot()}
      </div>
    )
  }

  const planWatch = () => {
    if (!j) return null
    const p = j
    const sched = p.case === 'schedule'
    const COV = specCoverage()
    const TELL: Record<string, string> = { me: 'You. Nobody else until you forward the brief.', pm: 'You and the Regional VP of each contract that changed.', controller: 'You, the Regional VP and the project leader of each contract that changed, and Legal when it reads as a claim.' }
    const rows: [string, string, RowVal | null, string][] = sched ? [
      ['watch', 'What I run', R('watch') ? ov('watch', { v: 'The renewal review you agreed: six steps, no checkpoint, the pack on the 2025 structure.', tag: 'you', sub: 'From the goal you just ran.' }) : null, 'Reusing the plan…'],
      ['against', 'Over what', R('against') ? ov('against', { v: 'The agreements, the scorecard and the contract ledger, read fresh each run; agendas, news and mail read at run time.', tag: 'inf', sub: 'The contract master, the scorecard, the web and Outlook.' }) : null, 'Reading…'],
      ['where', 'When it runs', R('where') ? ov('where', { v: 'The week before every quarterly portfolio review. Next: before 3 February 2027.', tag: 'inf', sub: 'From the review calendar.' }) : null, 'Reading the review calendar…'],
      ['fires', 'Fires when', ov('fires', { v: 'On the schedule, or when you say “run now”.', tag: 'inf' }), ''],
      ['then', 'Then I', R('steps') ? ov('then', { v: 'Run the six steps by myself, refresh the pack, the plan and the briefs, and tell you.', tag: 'inf', sub: 'Runs by itself. Anything missing goes in the pack as a gap.' }) : null, 'Working out what to do when it runs…'],
      ['tell', 'Who is told', p.answers.tell ? ov('tell', { v: TELL[p.answers.tell], tag: 'you', sub: 'From your answer.' }) : j.stage === 'reading' ? null : { v: '<span class="ph">who: your call</span>', tag: 'need', sub: 'No regulatory list is connected.' }, 'Looking for a distribution list…'],
      ['until', 'Runs until', R('where') ? ov('until', { v: 'You turn it off.', tag: 'inf' }) : null, '…'],
    ] : [
      ['watch', 'What I watch', R('watch') ? ov('watch', { v: `The risk of every contract in the portfolio: ${CONTRACTS.length} active operations and maintenance contracts, found in the contract master.`, tag: 'inf', sub: 'From your words and the connected data. One rating per contract.' }) : null, 'Finding the contracts…'],
      ['against', 'Scored on', !R('until') ? null : j.rv.includes('sheet') ? ov('against', { v: `The scorecard below: ${activeFactors().length} factors and ${likelihoodSignals().length} signals, one score per project. ${DESIGN.source === 'uploaded' ? 'From the template you uploaded, as written.' : 'Proposed by me; yours to change.'}`, tag: DESIGN.edits > 0 || p.answers.design ? 'you' : 'inf', sub: p.answers.design ? 'Agreed by you. Change it below at any time; a change is published as a new version of the dashboard.' : 'A proposal until you agree it.' }) : j.draft ? { v: `<span class="ph">${j.draft.title.toLowerCase()}…</span>`, tag: 'inf', sub: 'It appears below when it is ready.' } : { v: '<span class="ph">a scorecard: your template, or one I propose</span>', tag: 'need', sub: 'Asked in the chat: do you have a scoring template?' }, 'Looking for a scoring template…'],
      ['where', 'Checked where and when', R('where') ? ov('where', { v: 'In the operations data, the contracts and documents, the mailboxes and on the public web, every morning at 06:00. The dashboard is refreshed after each check.', tag: 'inf', sub: 'When the nightly data has landed. Next: tomorrow, Friday 20 November.' }) : null, 'Checking when the data settles…'],
      ['then', 'When a score rises', R('steps') ? ov('then', { v: 'Read the evidence, weigh what is at stake, refresh the plan for the site, then do what your rules say and tell you.', tag: 'inf', sub: 'Runs by itself. A rule set to "ask me first" waits for your OK.' }) : null, 'Working out what to do when it fires…'],
      ['until', 'Runs until', R('until') ? ov('until', { v: 'You turn it off.', tag: 'inf' }) : null, '…'],
    ]
    const srcs = sched ? [R('src:fin') && <Src onOpen={setDrawer} key="fin" n="Contract master and agreements" t="master.contract" m="End dates, options and ratings, read fresh each run" drill={{ view: 'renewals', note: '' }} />, R('src:cal') && <Src onOpen={setDrawer} key="cal" n="Review calendar" t="review_date" m="The run starts the week before a portfolio review" />, j.stage !== 'reading' && <Src onOpen={setDrawer} key="mail" n="Outlook · OneDrive · web" m="Read at run time, for what has changed on the client side" drill={{ view: 'mail', note: '' }} />].filter(Boolean) : [R('src:fin') && <Src onOpen={setDrawer} key="fin" n="Operations data hub" t={`${COV.bySrc[0].n} signals · safety, compliance, labour, HR, CMMS, lab, receivables, NPS, GIS`} m="Read from the tables; no monthly report compiled by hand" drill={{ view: 'signals', note: '' }} />, R('src:proc') && <Src onOpen={setDrawer} key="proc" n="Contracts and documents · OneDrive" t={`${COV.bySrc[1].n} signals · 300 agreements, consent orders, capital plans, notices`} m="Read clause by clause; clause readings are drafts for Legal" drill={{ view: 'documents', note: '' }} />, R('src:mail') && <Src onOpen={setDrawer} key="mail" n="Mail · Outlook" t={`${COV.bySrc[2].n} signal · legal notices and operations mailboxes`} m="Demand letters and claim correspondence, read as they arrive" drill={{ view: 'mail', note: '' }} />, R('src:web') && <Src onOpen={setDrawer} key="web" n="Public web" t={`${COV.bySrc[3].n} signals · state liability ranking, local news`} m="Also council agendas and regulator pages; every page cited" drill={{ view: 'web', doc: 'WEB:state-rank', note: '' }} />].filter(Boolean)
    const given: [string, string, RowVal | null][] = []
    if (R('against')) given.push(['g:thr', sched ? 'The plan' : 'The scorecard', { v: sched ? 'Runs as agreed; changes between runs are logged against the version.' : 'Factors, weights and bands change only when you change them here. Every change is logged.', tag: 'you', label: 'Fixed' }])
    if (R('where')) given.push(['g:prov', sched ? 'Ledger figures' : 'Clause readings', { v: sched ? 'The contract ledger of the last closed month.' : 'A rating read from a contract clause (Non-negotiable terms, certified operators) is a draft until Legal confirms it.', tag: 'inf', label: 'Assumption' }])
    if (R('steps')) given.push(['g:run', 'How it runs', { v: 'Runs without waiting for you; only actions that go outside the company wait for your OK.', tag: 'inf', label: 'Rule' }])
    p.fixedExtra.forEach((t, i) => given.push([`g:x${i}`, 'Also', { v: esc(t), tag: 'you', label: 'You said' }]))
    const readings = null
    return (
      <div className="pd">
        <div className="pd-status">{statusLine()}{legend}</div>
        {j.stage !== 'reading' ? <Sec title="Open points" id="points" right={pointsSub()} intro="What only you could answer. Each one turns green once it is clarified in the chat."><div className="pts">{openPoints()}</div></Sec> : null}
        {!sched && j.stage !== 'reading' && R('until') ? (
          j.rv.includes('sheet') ? <ScorecardDesign j={j} onOpen={setDrawer} canEdit={canEdit || j.stage === 'armed' || j.runs.length > 0} />
          : j.draft ? (
            <div className="sdz-wait" data-testid="sdz-drafting">
              <h3>{j.draft.title}</h3>
              <p>{DESIGN.source === 'uploaded' ? 'I read it as written and change nothing. It appears here when I am through.' : 'You have no template, so I work one out from what is connected. It appears here when it is ready.'}</p>
              <ol className="sdz-wait-steps">{j.draft.steps.map((t, i) => <li key={i} className={i < j.draft!.done ? 'is-done' : i === j.draft!.done ? 'is-live' : ''}><span>{i < j.draft!.done ? '✓' : ''}</span>{t.replace(/^(.)/, (m) => m.toUpperCase())}</li>)}</ol>
              <div className="sdz-wait-bar"><i style={{ width: `${Math.round((j.draft.done / j.draft.steps.length) * 100)}%` }} /></div>
            </div>
          ) : (
            <div className="sdz-wait" data-testid="sdz-waiting">
              <h3>The scorecard</h3>
              <p>Not here yet. First tell me in the chat whether you have a scoring template. If you upload one, I use it exactly as written. If you do not, I propose one. It appears here after your answer.</p>
            </div>
          )
        ) : null}
        <Sec title={sched ? 'The schedule' : 'The watch'}><div className="bf">{rows.map(([k, label, val, pend]) => <BriefRow key={k} k={k} label={label} val={val} pending={pend} target={target} canEdit={canEdit} onEdit={editRow} />)}</div></Sec>
        {readings}
        <Sec title="What I’m working from" id="ctx" intro="Everything it may draw on when it fires. Add to it from the chat.">
          <div className="ctx">
            <Grp title="Your documents">{j.extraDocs.length || j.files.length ? <div className="docs">{j.files.filter((f) => f.id === 'seed' || f.id === 'deck' || f.id === 'q2').map((f) => <Doc key={f.n} n={f.n} took="Read" onOpen={setDrawer} />)}{j.extraDocs.map((d) => <Doc key={d.n} n={d.n} took={d.took} mine drill={d.drill} onOpen={setDrawer} onRemove={(n) => st.rmDoc(j.id, n)} />)}</div> : <span className="none">None attached.</span>}</Grp>
            <Grp title="Connected data">{srcs.length ? srcs : skel('70%')}</Grp>
            {R('memory') || sched ? <Grp title="Company context" sub="role memory · Contract Risk Analyst">{sched ? <ul className="mem"><li>The scorecard is used as written</li><li>Client-side signs are shown beside the rating, never inside it</li><li>An NPS answer given by a predecessor is marked as such</li></ul> : <ul className="mem"><li>The Non-negotiable terms of the Contracting Policy (Legal, 2024)</li><li>A score read from a contract clause is a draft until Legal confirms it</li><li>What I read that your scorecard does not score is shown as unscored, never mixed in</li></ul>}</Grp> : null}
            {R('prior') ? <Grp title="Who owns each contract"><div className="src"><b>Contract master</b><span /><span>A Regional VP and a project leader for every contract; five regions</span></div></Grp> : null}
            {p.web ? <Grp title="From the web"><ul className="mem"><li>Public price indices for ductile iron and valves, checked each time it fires</li></ul></Grp> : null}
          </div>
        </Sec>
        <Sec title="What I’m taking as given">{given.length ? <div className="bf">{given.map(([k, label, val]) => <BriefRow key={k} k={k} label={label} val={val} target={target} canEdit={canEdit} onEdit={editRow} />)}</div> : skel('70%')}</Sec>
        <Sec title={sched ? 'When it runs, I’ll' : 'When it fires, I’ll'} right={R('steps') ? <a onClick={() => { setTab('workflow'); setSel(null) }}>Open as a workflow</a> : null}>{R('steps') ? stepsList() : <><p className="pd-intro">Drafted once I have read everything.</p>{skel('70%')}{skel('55%')}</>}</Sec>
        {R('steps') ? delivSec(sched ? 'Before every quarterly portfolio review, without a reminder: the run, the top option, the deliverables rebuilt and sent. Every run stays here under Runs.' : 'Before the working day starts: the run, the top option, the deliverables built, the actions you allowed done, and a notification with what it found and what it did. Every run is kept under Executed.') : null}
        {R('steps') && j.acts.length && sched ? <Sec title={sched ? 'When it runs, it may' : 'When it fires, it may'} intro="Agreed at set-up. Change any line here; it applies from the next run."><div className="acts-l">{j.acts.map((a) => <div key={a.key} className="dv-act" data-act={a.key}><div className="dv-act-t"><b>{a.text}</b><small>{a.why}</small></div><div className="dv-seg" role="radiogroup" aria-label={a.text}><button type="button" role="radio" aria-checked={a.mode === 'auto'} className={a.mode === 'auto' ? 'is-on' : ''} onClick={() => st.setActMode(j.id, a.key, 'auto')}>By itself</button><button type="button" role="radio" aria-checked={a.mode === 'ask'} className={a.mode === 'ask' ? 'is-on is-ask' : ''} onClick={() => st.setActMode(j.id, a.key, 'ask')}>Ask me first</button></div></div>)}</div></Sec> : null}
        {j.history.length ? <Sec title="Changes" right={`v${j.version}`}><ul className="hist">{j.history.slice().reverse().map((h, i) => <li key={i}><time>{h.t}</time><span>{h.what}</span></li>)}</ul></Sec> : null}
        {foot()}
      </div>
    )
  }
  const legend = <span className="pd-legend"><span className="tag you">You</span><span className="tag inf">Inferred</span><span className="tag need">Needs you</span><span>where each line came from</span></span>
  const needCount = () => (j ? (j.stage === 'reading' ? 0 : j.questions.filter((q) => !j.answers[q.key]).length + (j.delivConfirmed ? 0 : 1)) : 0)
  const statusLine = () => {
    if (!j) return null
    if (j.stage === 'reading') return <><span className="tag you">Drafting</span><span>from what you wrote and what is connected</span></>
    if (j.stage === 'running' || j.stage === 'armed') { const d = j.version - j.agreedV; return <><span className="tag ok">{j.stage === 'armed' ? 'Armed' : 'Agreed'}</span><span>by {j.armedBy ?? 'you'} at {j.agreedAt}{d ? ` · ${d} change${d > 1 ? 's' : ''} since` : ''}</span></> }
    return <><span className={`tag ${needCount() ? 'need' : 'inf'}`}>Draft v{j.version}</span><span>built from what you wrote, {j.files.length + j.extraDocs.length} document{j.files.length + j.extraDocs.length === 1 ? '' : 's'} and 4 connected sources</span></>
  }
  const foot = () => {
    if (!j) return null
    const n = needCount()
    if (j.stage === 'questions') return <div className="pd-foot"><p className="need">{n} thing{n === 1 ? ' needs' : 's need'} you, in the chat. Then it {j.mode === 'watch' ? 'arms' : 'runs to the end'} by itself.</p></div>
    if (j.stage === 'plan') return <div className="pd-foot"><p>{j.mode === 'watch' ? 'Arming…' : 'Starting the run…'}</p></div>
    return null
  }

  /* ---------------- the workflow */
  const dagRef = useRef<HTMLDivElement>(null)
  const drawDag = () => {
    const root = dagRef.current; if (!root || !j) return
    const inner = root.querySelector<HTMLElement>('.dag-inner')!; const svg = inner.querySelector('svg')!
    const items = Array.from(inner.querySelectorAll<HTMLElement>('.node')); if (!items.length) return
    const cols = Math.max(...items.map((n) => +n.dataset.col!)) + 1, rows = Math.max(...items.map((n) => +n.dataset.row!)) + 1
    const W = root.clientWidth || 800; const pad = 16, gapX = cols > 5 ? 18 : 28, rowH = 122
    let nodeW = Math.floor((W - pad * 2 - gapX * (cols - 1)) / cols); nodeW = Math.max(150, Math.min(cols > 5 ? 180 : 214, nodeW))
    const innerW = Math.max(W, pad * 2 + cols * nodeW + (cols - 1) * gapX)
    inner.style.width = `${innerW}px`; inner.style.height = `${pad * 2 + rows * rowH - 16}px`
    items.forEach((n) => { n.style.left = `${pad + +n.dataset.col! * (nodeW + gapX)}px`; n.style.top = `${pad + +n.dataset.row! * rowH}px`; n.style.width = `${nodeW}px` })
    const pos: Record<string, HTMLElement> = {}; items.forEach((n) => { pos[n.dataset.id!] = n })
    let paths = '<defs><marker id="mG" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0L6 3L0 6z" fill="#b7c0cc"/></marker><marker id="mD" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0L6 3L0 6z" fill="#7fb79a"/></marker></defs>'
    j.edges.filter(([a, b]) => pos[a] && pos[b]).forEach(([a, b]) => {
      const A = pos[a], B = pos[b]
      const x1 = A.offsetLeft + A.offsetWidth, y1 = A.offsetTop + A.offsetHeight / 2, x2 = B.offsetLeft - 1, y2 = B.offsetTop + B.offsetHeight / 2; const dx = Math.max(12, (x2 - x1) * 0.5)
      const d = j.ns[a]?.state === 'done' && ['done', 'running', 'wait', 'stale'].includes(j.ns[b]?.state ?? '')
      paths += `<path class="${d ? 'is-done' : ''} ${B.classList.contains('is-fork') ? 'is-dashed' : ''}" d="M${x1} ${y1} C${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}" marker-end="url(#${d ? 'mD' : 'mG'})"/>`
    })
    svg.setAttribute('width', String(innerW)); svg.setAttribute('height', String(inner.offsetHeight)); svg.innerHTML = paths
  }
  useLayoutEffect(() => { if (tab === 'workflow') drawDag() })
  useEffect(() => { const on = () => { if (tab === 'workflow') drawDag() }; window.addEventListener('resize', on); return () => window.removeEventListener('resize', on) })
  const nodeNum = useMemo(() => { const m: Record<string, string> = {}; if (!j) return m; let k = 0; liveNodes(j).slice().sort((a, b) => a.col - b.col || a.row - b.row).forEach((n) => { if (n.type !== 'checkpoint' && !n.fork) { k += 1; m[n.id] = String(k) } }); return m }, [j])
  const nodeStateText = (n: Node) => { const s = j!.ns[n.id] ?? { state: 'pending' as const }; if (s.text) return s.text; if (s.state === 'running') return 'Running'; if (s.state === 'wait') return 'Waits for you'; if (s.state === 'stale') return 'Stale · re-running'; if (n.type === 'checkpoint') return 'Stops here for you'; if (j!.mode === 'watch' && j!.stage === 'armed' && j!.status === 'armed') return 'Runs when it fires'; return 'Not started' }
  const renderWorkflow = () => {
    if (!j) return null
    const ns = liveNodes(j)
    const done = ns.filter((n) => j.ns[n.id]?.state === 'done').length, running = ns.filter((n) => j.ns[n.id]?.state === 'running').length
    const bar = j.stage === 'running' || j.status === 'fired' || j.runs.length ? <><b>Workflow</b><span>{ns.length} steps · {j.stage === 'armed' ? `armed ${j.agreedAt}` : `started ${j.agreedAt}`} · {done} done{running ? ` · ${running} running` : ''}</span></> : <><b>Workflow</b><span>{j.mode === 'watch' ? 'What runs each time it fires' : 'The plan’s steps as they will run'} · {ns.length} steps · {ns.some((n) => n.type === 'checkpoint') ? 'one checkpoint' : 'no checkpoint'}</span></>
    return (
      <div className="dag-wrap">
        <Activity j={j} content={(nid) => st.content(j.id, nid)} num={nodeNum} />
        <div className="dag-bar">{bar}<div className="legend"><span><i className="d" />Done</span><span><i className="r" />Running</span><span><i className="p" />{j.mode === 'watch' && j.status === 'armed' ? 'Waits for the trigger' : 'Not started'}</span>{ns.some((n) => n.type === 'checkpoint') ? <span><i className="c" />Checkpoint</span> : null}</div></div>
        <div className="dag" ref={dagRef}><div className="dag-inner"><svg className="edges" aria-hidden="true" />{ns.map((n) => { const s = j.ns[n.id] ?? { state: 'pending' as const }; return <button key={n.id} className={['node', `is-${s.state}`, sel === n.id ? 'is-sel' : '', n.type === 'checkpoint' && s.state !== 'wait' && s.state !== 'done' ? 'is-cp' : '', s.caveat ? 'is-caveat' : '', n.fork ? 'is-fork' : ''].join(' ')} type="button" data-id={n.id} data-col={n.col} data-row={n.row} aria-pressed={sel === n.id} onClick={() => setSel(sel === n.id ? null : n.id)}><span className="nb"><span className="nt">{TYPE_LABEL[n.type]}{nodeNum[n.id] ? ` · ${nodeNum[n.id]}` : ''}</span><span className="nn">{n.title}</span><span className="ns">{nodeStateText(n)}</span></span></button> })}</div></div>
        {sel ? null : <div className="dag-hint">{j.stage === 'running' || j.runs.length ? 'Tap a step to see what it did, the data it used and its caveats.' : 'The same steps as the plan, laid out as they run. Tap one to see what it draws on.'}</div>}
        {sel ? renderInspector(sel) : null}
      </div>
    )
  }
  const renderInspector = (id: string) => {
    if (!j) return null
    const n = j.nodes.find((x) => x.id === id); if (!n) return null
    const s = j.ns[id] ?? { state: 'pending' as const }
    const anatomy = <div className="insp-cols two"><div className="insp-col"><h4>Purpose</h4><p>{n.purpose}</p><h4>How</h4><p>{n.how}</p></div><div className="insp-col"><h4>Draws on</h4><ul className="rcpt">{n.draws.map((d) => <li key={d}><span className="rn">{/[.]/.test(d) && !/ /.test(d) ? <code>{d}</code> : d}</span></li>)}</ul><h4>Check before moving on</h4><p>{n.check}</p></div></div>
    if (s.state === 'wait') return <div className="insp"><InspHead n={n} onClose={() => setSel(null)} meta={<><span className="tag need">Waits for you</span><span>Nothing after this runs until you answer.</span></>} /><div style={{ padding: '14px 16px' }}><p style={{ margin: '0 0 10px', fontSize: 13.5 }}>{n.how}</p>{cpTiles()}</div></div>
    if (s.state === 'pending') {
      const editable = canEdit || (j.stage === 'armed' && j.status === 'armed')
      const acts = editable && n.type !== 'checkpoint' && !n.fork ? <><button className="btn" type="button" onClick={() => prefill(`Change step ${nodeNum[n.id] ?? ''}, ${n.title.toLowerCase()}: `)}>Change this step</button><button className="btn is-ghost" type="button" onClick={() => { send(`Drop the step: ${n.title}`); st.removeStep(j.id, n.id); setSel(null) }}>Remove</button></> : j.stage === 'running' ? <button className="btn" type="button" onClick={() => prefill(`Before it runs, change ${n.title.toLowerCase()}: `)}>Change before it runs</button> : null
      return <div className="insp"><InspHead n={n} onClose={() => setSel(null)} meta={j.mode === 'watch' && j.stage === 'armed' ? <span>Runs when the rule fires</span> : <><span>Not run yet</span>{n.id === 'n4' || n.id === 'f1' ? <span>Runs after the checkpoint</span> : null}</>} acts={acts} />{anatomy}</div>
    }
    const c = st.content(j.id, id)
    if (s.state === 'running' || s.state === 'stale') return <div className="insp"><InspHead n={n} onClose={() => setSel(null)} meta={<><span className="pill is-orange"><i />{s.state === 'stale' ? 'Re-running after your steer' : 'Running'}</span><span>Started {s.at ?? 'just now'}</span></>} acts={j.mode === 'once' && j.stage === 'running' ? <button className="btn" type="button" onClick={() => st.pause(j.id)}><PauseOutlined /> Pause after this step</button> : null} /><div className="insp-cols two"><div className="insp-col"><h4>What it is doing</h4><p>{n.how}</p></div><div className="insp-col"><h4>Right now</h4><div className="ap"><div className="ap-line is-live"><span className="ap-tool"><span className="ap-dot" />{c?.live[0] ?? 'working…'}</span><span className="ap-res">{c?.live[1] ?? ''}</span></div></div><h4 style={{ marginTop: 8 }}>Check before moving on</h4><p>{n.check}</p></div></div></div>
    if (!c) return <div className="insp"><InspHead n={n} onClose={() => setSel(null)} meta={<span>Done</span>} />{anatomy}</div>
    const table = c.table ? <div className="tbl-wrap"><table className="tbl"><thead><tr>{c.table.cols.map((h, i) => <th key={h} className={(c.table!.num ?? []).includes(i) ? 'n' : ''}>{h}</th>)}</tr></thead><tbody>{c.table.rows.map((r, ri) => <tr key={ri} className={c.table!.warn === ri ? 'warn' : ''}>{r.map((v, i) => <td key={i} className={(c.table!.num ?? []).includes(i) ? 'n' : ''}>{v}</td>)}</tr>)}{c.table.tot ? <tr className="tot">{c.table.tot.map((v, i) => <td key={i} className={(c.table!.num ?? []).includes(i) ? 'n' : ''}>{v}</td>)}</tr> : null}</tbody></table></div> : null
    const caveatAct = (a: string) => { if (/leave the evergreen/i.test(a)) { if (j.stage === 'running' || j.status === 'ready') st.steer(j.id) } }
    return (
      <div className="insp">
        <InspHead n={n} onClose={() => setSel(null)} meta={<><span style={{ color: '#0f7b4f', fontWeight: 500 }}>Done in {c.dur}</span><span>Ran {s.at ?? ''}</span><span>Confidence <b>{c.conf}</b></span>{c.caveats.length ? <span>{c.caveats.length} caveat{c.caveats.length > 1 ? 's' : ''}</span> : null}</>} acts={<><button className="btn" type="button" onClick={() => prefill(`Re-run ${n.title.toLowerCase()} with `)}>Re-run with a change</button><button className="btn is-ghost" type="button" onClick={() => prefill(`About ${n.title.toLowerCase()}: `)}>Ask about this step</button></>} />
        <div className="insp-cols">
          <div className="insp-col"><h4>What I did and found</h4>{c.summary.map((x, i) => <p key={i}><Html html={x} /></p>)}{table}{c.table ? <a style={{ fontSize: 12.5 }} onClick={() => setDrawer(c.receipts.find((r) => r.drill)?.drill ?? { view: 'portfolio', note: '' })}>Open the rows behind it</a> : null}</div>
          <div className="insp-col"><h4>Receipts: data this step used</h4><ul className="rcpt">{c.receipts.map((r, i) => <li key={i}><span className="rn">{r.mono ? <code>{r.n}</code> : r.n}{r.drill ? <a onClick={() => setDrawer(r.drill!)}>Open</a> : null}</span><span className="rm">{r.m}</span></li>)}</ul>{c.subs ? <><h4>Spawned while running</h4><ul className="rcpt">{c.subs.map((x) => <li key={x[0]}><span className="rn">{x[0]}</span><span className="rm">{x[1]}</span></li>)}</ul></> : null}</div>
          <div className="insp-col"><h4>Checks</h4>{c.checks.map((x) => <div key={x} className="chk"><CheckOutlined /><span>{x}</span></div>)}<h4 style={{ marginTop: 4 }}>Caveats</h4>{c.caveats.length ? c.caveats.map((v, i) => <div key={i} className={`cav${v.assume ? ' is-assume' : ''}`}><span className="ck">{v.k}</span><span>{v.t}</span><span className="cp">Propagates to: {v.p}</span>{v.acts && !(j.flags.steered || j.answers.four === 'standin') ? <div className="acts">{v.acts.map((a) => <button key={a} className="btn" type="button" onClick={() => caveatAct(a)}>{a}</button>)}</div> : null}</div>) : <p style={{ color: '#6b778a', fontSize: 12.5 }}>No caveats on this step.</p>}</div>
        </div>
        <div className="trace"><div className="tl"><b>Raw trace · {c.traceN} calls</b>{c.trace.map((t) => <span key={t}>{t}</span>)}</div></div>
      </div>
    )
  }
  const cpTiles = () => j ? <div className="tiles three"><button className="tile" type="button" onClick={() => st.checkpoint(j.id, 'june')}>Count the evergreen contracts<small>Each client can end on notice</small></button><button className="tile" type="button" onClick={() => st.checkpoint(j.id, 'standin')}>Leave them out<small>No end date in the window</small></button><button className="tile" type="button" onClick={() => st.checkpoint(j.id, 'both')}>Run both<small>Adds a what-if with the evergreen contracts left out</small></button></div> : null

  /* ---------------- findings, decision, outputs, runs, log */
  const findingsMap = j ? st.findingsOf(j.id) : {}
  const orderedFindings = useMemo(() => { if (!j) return [] as string[]; const rank = (k: string) => { const f = findingsMap[k]; const n = f ? liveNodes(j).findIndex((x) => x.id === f.from) : 99; return n < 0 ? 99 : n }; return j.findings.slice().sort((a, b) => rank(a) - rank(b)) }, [j, findingsMap])
  const allAccepted = !!j && j.findings.length > 0 && j.findings.every((k) => j.over[`acc:${k}`])
  const renderFindings = () => {
    if (!j) return null
    if (!j.findings.length) return <div className="panel-empty">{j.stage === 'armed' ? 'Findings land here when the trigger runs the plan.' : 'Findings land here as steps finish, provisional until the run completes.'}</div>
    const ready = ['ready', 'accepted', 'sent', 'executing', 'executed', 'delivered'].includes(j.status)
    const prov = ready ? null : <div className="provisional"><ClockCircleOutlined /><span>Still running. These findings are provisional and may change as later steps finish.</span></div>
    const built = Object.keys(j.built).length > 0
    const reco = j.recs.length ? (
      <div className="reco-wrap">
        <div className="pd-h"><h3>Recommendations</h3><span className="r">{j.chosen ? (j.chosenBy === 'auto' ? `option ${j.recs.findIndex((r) => r.id === j.chosen) + 1} chosen automatically, the top one` : `option ${j.recs.findIndex((r) => r.id === j.chosen) + 1} chosen by you`) : 'chosen when the run ends'}</span></div>
        {j.recs.map((r, i) => {
          const chosen = j.chosen === r.id
          const on = sel === `story:${r.id}`
          return (
            <div key={r.id} className={`reco${chosen ? ' is-chosen' : ''}`} data-rec={r.id}>
              <div className="reco-top"><h3>{i + 1}. {r.title}</h3><span className={`tag ${chosen ? 'ok' : 'inf'}`}>{chosen ? (j.chosenBy === 'auto' ? 'Chosen automatically' : 'Chosen by you') : 'Alternative'}</span></div>
              <p>{r.summary}</p>
              <div className="figs">{r.figures.map((f) => <Figure key={f.label} {...f} />)}</div>
              <p className="tradeoff">Trade-off: {r.tradeoff}</p>
              <div className="hc-actions">
                <Button size="small" icon={<PlayCircleOutlined />} onClick={() => setSel(on ? null : `story:${r.id}`)}>{on ? 'Hide the path' : 'Why this'}</Button>
                {!chosen && ready ? <Button size="small" onClick={() => st.choose(j.id, r.id)}>{built ? 'Use this instead' : 'Choose this'}</Button> : null}
                {chosen && built ? <span className="reco-note-in">The deliverables are built on this option.</span> : null}
              </div>
              {on ? <StoryPlayer g={baseGoal(j)} r={r} onDrill={setDrawer} /> : null}
            </div>
          )
        })}
        <div className="reco-note">{caveatText(j)}</div>
      </div>
    ) : null
    const auto = j.findings.filter((k) => j.over[`acc:${k}`] === 'auto').length
    return (
      <>
        {prov}
        {reco}
        <div className="pd-h" style={{ marginTop: reco ? 18 : 0 }}><h3>Findings</h3><span className="r">{ready ? (auto === j.findings.length ? `all ${j.findings.length} accepted automatically` : `${j.findings.filter((k) => j.over[`acc:${k}`]).length} of ${j.findings.length} accepted`) : 'provisional'}</span></div>
        {orderedFindings.map((k, i) => {
          const f = findingsMap[k]; if (!f) return null
          const n = j.nodes.find((x) => x.id === f.from)
          const acc = j.over[`acc:${k}`], chal = j.over[`chal:${k}`]
          return (
            <div key={k} className={`finding${ready ? '' : ' is-prov'}${acc ? ' is-acc' : ''}`} data-finding={k}>
              <div className="f-top"><span className="f-n">{i + 1}</span><h3>{f.h}</h3>{chal ? <span className="tag need">Challenged</span> : acc ? <span className="tag ok">{acc === 'auto' ? 'Accepted automatically' : 'Accepted'}</span> : null}</div>
              <p>{f.d}</p>
              {f.base?.evidence.length ? <div className="ev">{f.base.evidence.map((e, ei) => { const dr: Drill | null = e.ref?.thread ? { view: 'mail', thread: e.ref.thread, note: '' } : e.ref?.doc ? { view: 'documents', doc: e.ref.doc, note: '' } : e.ref?.sheet ? { view: e.ref.sheet as Drill['view'], project: e.ref.project, contract: e.ref.contract, note: '' } : null; return <div key={ei} className={`ev-line is-${e.kind}`}><span className="ev-k">{e.kind}</span><span className="ev-t">{e.text}</span><span className="ev-s">{e.source}{e.asOf ? ` · ${e.asOf}` : ''}{dr ? <> · <a onClick={() => setDrawer(dr)}>open</a></> : null}</span></div> })}</div> : null}
              {chal ? <p className="f-chal">Your challenge: {chal}</p> : null}
              <div className="f-foot"><button className="from" type="button" onClick={() => openStep(f.from)}>From step {nodeNum[f.from] ?? ''}: {n?.title ?? f.from}</button>{f.cav.map((c) => <span key={c} className="fc">{c}</span>)}<span className="spacer" /><Button size="small" icon={<TableOutlined />} onClick={() => setDrawer(f.drill)}>Open the data</Button>{ready && !chal ? <Button size="small" onClick={() => { const t = window.prompt(`What is wrong with finding ${i + 1}? One sentence is enough.`); if (t) st.challenge(j.id, k, t) }}>Challenge</Button> : null}</div>
            </div>
          )
        })}
        {j.gaps.length ? <div className="gaps"><WarningOutlined /> <b>Gaps and open questions</b><ul>{j.gaps.map((x) => <li key={x}>{x}</li>)}</ul></div> : null}
      </>
    )
  }
  const caveatText = (x: Journey) => { let n = 1; if (x.case === 'once' && x.answers.four !== 'standin' && !x.flags.steered) n += 1; if (x.case === 'once' && x.answers.t3 !== 'out') n += 1; if (x.case !== 'once') n = 2; return `${n} caveat${n > 1 ? 's' : ''} reached it. Each one is on the step that raised it: tap a finding’s step to see it.` }
  const baseGoal = (x: Journey): Goal => toGoal(x)
  const renderOutputs = () => {
    if (!j) return null
    const built = j.mode === 'once' ? j.ns.n6?.state === 'done' : j.ns.w5?.state === 'done'
    const outs = j.outputs.length ? j.outputs : (j.case === 'once' || j.case === 'schedule' ? ONCE_BASE : WATCH_BASE).submissions
    return (
      <>
        {outs.map((o, i) => {
          const tpl = templates.find((t) => t.id === o.templateId)
          const started = j.started.includes(o.id)
          const state = started ? 'Started in Submissions · its own chat there' : j.sentAt && i === 0 ? `Sent at ${j.sentAt} · copy in Submissions` : j.chosen ? `Ready to build · for ${o.audience}` : built ? `Draft ready · on the template “${tpl?.name ?? o.template}” · every figure linked to its step` : `Planned · drafted by the last step on the template “${tpl?.name ?? o.template}”`
          return (
            <div key={o.id} className="out">
              <span className="out-ic"><FileTextOutlined /></span>
              <div><b>{o.label}</b><span>{state}</span><small>{o.why}</small></div>
              {started ? <span className="tag ok">Started</span> : <Button size="small" type={j.chosen ? 'primary' : 'default'} disabled={!built || !tpl} onClick={() => { const sid = startSubmission(baseGoal(j), o, me); st.markStarted(j.id, o.id); window.setTimeout(() => navigate(appPath(`/submissions/${sid}`)), 700) }}>{built ? 'Build in Submissions' : 'Not yet'}</Button>}
            </div>
          )
        })}
        <p className="out-note">{j.chosen ? 'Choosing the recommendation made the output final. It still goes nowhere until you build and send it in Submissions.' : 'Outputs belong to the goal. Nothing leaves it until you build it; every figure stays linked to the step that produced it.'}</p>
        <div className="hc-actions"><Button size="small" icon={<SaveOutlined />} disabled={!j.findings.length} onClick={() => { downloadPack(baseGoal(j), STATUS_LABEL[baseGoal(j).status], TRIGGER_LABEL[baseGoal(j).trigger]); st.input(j.id, 'Download the analysis pack') }}>Download the analysis pack</Button></div>
      </>
    )
  }
  /* ---------------- the deliverables, as built */
  const builtSubs = () => (j ? j.deliv.filter((d) => d.on && j.built[d.id]).map((d) => subsAll.find((x) => x.id === j.built[d.id])).filter((x): x is NonNullable<typeof x> => !!x) : [])
  const drillFor = (text: string): Drill | null => { if (!j) return null; const fm = st.findingsOf(j.id); const list = j.findings.map((k) => fm[k]).filter(Boolean); const f = bestMatch(text, list, (y) => `${y.h} ${y.d}`); return f?.drill ?? null }
  const actionsList = (compact?: boolean) => {
    if (!j || !j.execActs.length) return null
    return (
      <ol className={`ex-steps acts-run${compact ? ' is-compact' : ''}`} data-testid="actions">
        {j.execActs.map((a, i) => (
          <li key={`${a.text}-${i}`} className={a.state === 'done' || a.state === 'approved' ? 'is-done' : a.state === 'waiting' ? 'is-waiting' : a.state === 'declined' ? 'is-declined' : ''} data-act-state={a.state}>
            <span className="ex-n">{a.state === 'done' || a.state === 'approved' ? <CheckOutlined /> : a.state === 'waiting' ? '!' : a.state === 'declined' ? '×' : i + 1}</span>
            <span className="ex-t">{a.text}<small>{a.state === 'done' ? 'Done by itself' : a.state === 'approved' ? 'Done after your OK' : a.state === 'waiting' ? `Waits for your OK: ${j.acts.find((c) => c.key === a.cat)?.why.toLowerCase() ?? 'agreed at set-up'}` : a.state === 'declined' ? 'Left by you; not done' : 'Next'}</small></span>
            {a.state === 'waiting' ? <span className="ex-acts"><Button size="small" type="primary" onClick={() => st.approveAct(j.id, i, true)}>Approve</Button><Button size="small" onClick={() => st.approveAct(j.id, i, false)}>Leave it</Button></span> : null}
          </li>
        ))}
      </ol>
    )
  }
  const renderDeliverables = () => {
    if (!j) return null
    if (j.prog) {
      const list = j.prog.sids.map((sid) => subsAll.find((x) => x.id === sid)).filter((x): x is NonNullable<typeof x> => !!x)
      const cur = list[j.prog.i] ?? list[0]
      if (!cur) return null
      const n = cur.sections.filter((y) => y.included).length
      return (
        <div className="bld" data-testid="building">
          <div className="bld-h"><span className="bld-spin" /><b>Building the deliverables</b><span>{j.prog.i + 1} of {list.length} · {cur.title.split(':')[0]}, {Math.min(j.prog.shown, n)} of {n} parts</span></div>
          <div className="bld-list">{list.map((x, i) => <span key={x.id} className={`bld-chip${i < j.prog!.i ? ' is-done' : i === j.prog!.i ? ' is-now' : ''}`}>{i < j.prog!.i ? <CheckOutlined /> : i === j.prog!.i ? <span className="bld-dot" /> : null}{x.title.split(':')[0]}</span>)}</div>
          <DeliverableDoc key={`b-${cur.id}-${cur.version}`} s={cur} goal={baseGoal(j)} shown={j.prog.shown} />
        </div>
      )
    }
    const list = builtSubs()
    if (!list.length) return <div className="panel-empty">{j.case === 'generic' && j.status === 'ready' ? 'Nothing built: there is no recorded analysis for this goal in this copy.' : j.delivConfirmed ? `${j.deliv.filter((d) => d.on).map((d) => d.label.split(':')[0]).join(', ')}: built here at the end of the run, part by part.` : 'The deliverables you choose in the chat are built here at the end of the run.'}</div>
    const cur = list.find((x) => x.id === delivOn) ?? list[0]
    const waiting = j.execActs.filter((a) => a.state === 'waiting').length
    return (
      <>
        <div className="dl-head">
          <span>{j.case === 'watch' && !j.runs.length ? `Published ${j.deliveredAt ?? ''} at the first scoring · refreshed at every morning check` : j.mode === 'watch' ? `Built ${j.deliveredAt ?? ''} on the run of ${j.runs[j.runs.length - 1]?.at ?? 'today'} · findings accepted automatically · ${j.chosenBy === 'you' ? 'your choice of option' : 'top option chosen automatically'}` : `Built ${j.deliveredAt ?? ''} · findings accepted automatically · ${j.chosenBy === 'you' ? 'your choice of option' : 'top option chosen automatically'}`}</span>
          <span className="dl-links"><a onClick={() => setTab(j.mode === 'watch' && j.case !== 'schedule' ? 'runs' : 'findings')}>Findings and options</a>{!st.goals[j.id] ? null : <a onClick={() => navigate(appPath('/submissions/new'), { state: { fromJourney: j.id } })}>Make more from this analysis</a>}</span>
        </div>
        {j.execActs.length ? <div className={`dl-acts${waiting ? ' is-waiting' : ''}`}><b>{waiting ? `${waiting} action${waiting === 1 ? '' : 's'} wait${waiting === 1 ? 's' : ''} for your OK` : 'What it did'}</b>{actionsList(true)}</div> : null}
        {list.length > 1 ? <div className="dl-tabs" role="tablist">{list.map((x) => <button key={x.id} type="button" role="tab" aria-selected={x.id === cur.id} className={`dl-tab${x.id === cur.id ? ' is-on' : ''}`} title={x.title} onClick={() => setDelivOn(x.id)}>{x.title.split(':')[0]}<small>v{x.delivId === 'sub-risk-scorecard' && j.case === 'watch' ? Math.max(1, dashV) : x.version ?? 1}</small></button>)}</div> : null}
        {cur.delivId === 'sub-risk-scorecard' && j.case === 'watch' ? <div className="dash-deliv" data-testid="dash-deliv"><TargetBoard j={j} onOpen={setDrawer} onTab={(t) => setTab(t)} /></div> : <DeliverableDoc key={`${cur.id}-${cur.version}`} s={cur} goal={baseGoal(j)} onEdit={() => navigate(appPath(`/submissions/${cur.id}`))} onDrill={setDrawer} drillFor={drillFor} />}
      </>
    )
  }
  const renderRuns = () => {
    if (!j) return null
    if (!j.runs.length) return <div className="panel-empty">No runs yet. The first check is the {j.nextCheck ?? 'next trigger'}; or simulate it from the button above.</div>
    return <>{j.runs.map((r) => <div key={r.id} className="out" style={{ marginBottom: 14 }}><span className="out-ic"><BellOutlined /></span><div><b>{r.label}</b><span>Fired {r.at} · {r.status === 'executed' ? `handled at ${j.executedAt}: ${liveNodes(j).length} steps, option ${j.recs.findIndex((x) => x.id === j.chosen) + 1}, ${Object.keys(j.built).length} deliverables, ${j.execActs.filter((a) => a.state === 'done' || a.state === 'approved').length} of ${j.execActs.length} actions done` : 'running the plan'}</span></div><span className={`pill ${r.status === 'executed' ? 'is-green' : 'is-orange'}`}><i />{r.status === 'executed' ? 'Handled' : 'Running'}</span></div>)}{j.execActs.length ? <div className="exec-box"><b>Actions on option {j.recs.findIndex((r) => r.id === j.chosen) + 1}</b>{actionsList()}</div> : null}{renderFindings()}</>
  }
  const renderLog = () => (j && j.log.length ? <ul className="log">{j.log.slice().reverse().map((l, i) => <li key={i}><time>{l.t}</time><span><b>{l.who}</b> · {l.what}</span></li>)}</ul> : <div className="panel-empty">Nothing yet.</div>)

  /* ---------------- the panel */
  /* The same six tabs from the first message to the last, in the same order; a tab with nothing yet says what will land there. */
  /* A standing goal with a number and a date carries one more, first: the Target. */
  const tabsFor = (): Tab[] => ['plan', 'workflow', 'findings', 'deliverables', 'data', 'log']
  const TAB_LABEL: Record<Tab, string> = { plan: 'Plan', workflow: 'Workflow', findings: 'Findings', data: 'Data', outputs: 'Outputs', runs: 'Runs', log: 'Log', deliverables: 'Deliverables', target: 'Scorecard' }
  const tabs = tabsFor()
  useEffect(() => { if (!tabs.includes(tab)) setTab(tabs[0]) }, [tabs.join(','), tab]) // eslint-disable-line react-hooks/exhaustive-deps
  const pill = () => {
    if (!j) return null
    const N = liveNodes(j).filter((n) => n.type !== 'checkpoint' && !n.fork).length
    const waiting = j.execActs.filter((a) => a.state === 'waiting').length
    if (j.stage === 'running') return j.status === 'delivered' ? <span className="pill is-green"><i />Delivered · {Object.keys(j.built).length} built</span> : j.status === 'paused' ? <span className="pill is-grey"><i />Paused after step {j.doneCount}</span> : j.status === 'ready' ? <span className="pill is-amber"><i />Ended on a question</span> : <span className="pill is-orange"><i />Running · step {Math.min(j.doneCount + 1, N)} of {N}</span>
    if (j.stage === 'armed') return j.status === 'fired' ? <span className="pill is-orange"><i />Fired · running</span> : j.status === 'executing' ? <span className="pill is-orange"><i />Acting</span> : j.status === 'executed' ? (waiting ? <span className="pill is-amber"><i />Handled · {waiting} waits for your OK</span> : <span className="pill is-green"><i />Handled · still armed</span>) : <span className="pill is-blue"><i />Armed · checks {j.case === 'schedule' ? 'each quarter' : 'every morning at 06:00'}</span>
    const n = needCount()
    return j.stage === 'reading' ? <span className="pill is-orange"><i />Drafting the plan</span> : n ? <span className="pill is-amber"><i />{n} thing{n === 1 ? ' needs' : 's need'} you</span> : <span className="pill is-blue"><i />{j.mode === 'watch' ? 'Arming' : 'Starting'}</span>
  }
  const renderPanel = () => {
    if (!j) return null
    const live = j.stage === 'running' && !['ready', 'accepted', 'sent', 'wait', 'delivered'].includes(j.status)
    const cnt = (t: Tab) => t === 'findings' && j.findings.length ? <span className={`cnt ${['delivered', 'executed'].includes(j.status) ? 'green' : 'amber'}`}>{j.findings.length}</span> : t === 'runs' && j.runs.length ? <span className={`cnt ${j.status === 'executed' ? 'green' : 'amber'}`}>{j.runs.length}</span> : t === 'plan' && needCount() ? <span className="cnt amber">{needCount()}</span> : t === 'deliverables' && Object.keys(j.built).length ? <span className="cnt green">{Object.keys(j.built).length}</span> : null
    return (
      <div className="gp">
        <div className="panel-head">
          <div className="panel-title-row"><div className="panel-title">{j.title}</div>
            <div className="panel-actions">
              {live ? <button className="btn" type="button" onClick={() => st.pause(j.id)}>{j.paused ? <PlayCircleOutlined /> : <PauseOutlined />} {j.paused ? 'Resume' : 'Pause after this step'}</button> : null}
              {j.stage === 'armed' && j.status === 'armed' ? <button className="btn" type="button" onClick={() => st.fire(j.id)}><ThunderboltOutlined /> {j.case === 'schedule' ? 'Simulate: run now' : 'Simulate tomorrow’s morning check (20 November)'}</button> : null}
              <button className="btn is-ghost" type="button" onClick={() => setConvHidden(!convHidden)}>{convHidden ? <EyeOutlined /> : <EyeInvisibleOutlined />} {convHidden ? 'Show chat' : 'Hide chat'}</button>
              <span className="hp-x" role="button" aria-label="Close the panel" onClick={() => setPanelOpen(false)}><CloseOutlined /></span>
            </div>
          </div>
          <div className="panel-meta">{pill()}<span>{j.mode === 'watch' ? (j.case === 'schedule' ? 'Standing goal · schedule' : 'Standing goal · rule') : 'One-off analysis'}</span><span>{j.agent.name}</span>{j.agreedAt ? <span>{j.stage === 'armed' ? `Armed ${j.armedAt}` : `Started ${j.agreedAt}`}</span> : null}{j.nextCheck && ['armed', 'executed'].includes(j.status) && j.stage === 'armed' ? <span>Next check: {j.nextCheck}</span> : null}</div>
          <div className="tabs" role="tablist">{tabs.map((t) => <button key={t} className={`tab${tab === t ? ' is-on' : ''}`} role="tab" aria-selected={tab === t} type="button" onClick={() => setTab(t)}>{TAB_LABEL[t]}{cnt(t)}</button>)}</div>
        </div>
        <div className="panel-body" key={tab} data-tab={tab}>{tab === 'target' && isTargetGoal(j) ? <TargetBoard j={j} onOpen={setDrawer} onTab={(t) => setTab(t)} /> : tab === 'plan' || tab === 'target' ? (j.mode === 'watch' ? planWatch() : planOnce()) : tab === 'workflow' ? renderWorkflow() : tab === 'findings' ? (j.mode === 'watch' && j.case !== 'schedule' ? renderRuns() : renderFindings()) : tab === 'deliverables' ? renderDeliverables() : tab === 'outputs' ? renderOutputs() : tab === 'runs' ? renderRuns() : tab === 'data' ? <DataExplorer start={{ view: j.case === 'once' || j.case === 'schedule' ? 'ratebase' : 'procure', note: '' }} height={Math.max(420, window.innerHeight - 300)} /> : renderLog()}</div>
      </div>
    )
  }

  /* ---------------- the cards inside the conversation */
  const renderCard = (m: Msg) => {
    if (!j || !m.card) return null
    const c = m.card
    if (c.kind === 'reads') return <div className="ap">{(c.lines ?? []).map((l, i) => <div key={i} className={`ap-line${l.live ? ' is-live' : ''}${l.warn ? ' is-warn' : ''}`}><span className="ap-tool"><span className="ap-dot" />{l.tool}</span><span className="ap-res">{l.res}</span></div>)}</div>
    if (c.kind === 'change') return <ChangeCard j={j} done={c.done} />
    if (c.kind === 'upload') return c.done ? <Fold label="Scoring template" sum={c.done} /> : <UploadBox onFile={(f) => void st.uploadTemplate(j.id, f)} onSample={() => void st.uploadTemplate(j.id)} />
    if (c.kind === 'q') {
      const q = j.questions.find((x) => x.key === c.key); if (!q) return null
      const idx = j.questions.indexOf(q) + 1
      if (c.done) return <Fold label={LABELS[q.key === 'four' ? 'as:four' : q.key === 't3' ? 'as:t3' : q.key] ?? q.title} sum={c.done} />
      return (
        <div className="hc" data-q={q.key}><div className="hc-head"><span className="sd-step-n">{idx}</span><b>{q.title}</b><span className="hc-of">{idx} of {j.questions.length}</span></div>
          <p className="hc-text">{q.text}</p>
          <div className={`tiles${q.tiles.length === 3 ? ' three' : ''}`}>{q.tiles.map((t) => <button key={t.v} className="tile" type="button" onClick={() => st.answer(j.id, q.key, t.v)}>{t.t}<small>{t.s}</small>{t.rec ? <span className="rec">Recommended</span> : null}</button>)}</div>
          {q.key === 'design' || q.key === 'check' ? <span className="hc-note"><a onClick={() => { setTab('plan'); setPanelOpen(true); window.setTimeout(() => document.querySelector(q.key === 'check' ? '[data-part="check"]' : '[data-part="sheet"]')?.scrollIntoView({ block: 'start' }), 60) }}>{q.key === 'check' ? 'Open the data check on the plan' : 'Open the scorecard on the plan'}</a></span> : <span className="hc-note">Or answer below in your own words{q.key === 'four' || q.key === 't3' ? ', or add a document or a thread from the + menu' : ''}.</span>}
        </div>
      )
    }
    if (c.kind === 'cp') {
      if (c.done) return <Fold label="Checkpoint · the evergreen contracts" sum={c.done} />
      const txt = 'Steps 1 to 3 are done. The review rests on one assumption: whether the evergreen contracts count as up for renewal. Only you can confirm it.'
      return <div className="hc" data-cp="1"><div className="hc-head"><span className="sd-step-n is-cp">!</span><b>Before the back-test</b><span className="hc-of">checkpoint</span></div><p className="hc-text">{txt}</p>{cpTiles()}</div>
    }
    if (c.kind === 'diff' && c.diff) {
      if (c.done) return <div className="hc-folded"><span className={`sd-step-n${c.left ? '' : ' is-done'}`}>{c.left ? '×' : <CheckOutlined />}</span><span className="hc-sum" style={{ margin: 0 }}>{c.left ? `Left as it was · ${c.diff.title}` : `${c.done} · ${c.diff.title}`}</span></div>
      return <div className="diff">{c.diff.rows.map((r, i) => <div key={i} className={`diff-row ${r.k}`}><span className="k">{{ add: '+ step', chg: 'changes', rerun: 're-runs', caveat: 'caveat' }[r.k]}</span><span><RichText text={r.text} /></span></div>)}<div className="hc-actions"><Button size="small" type="primary" onClick={() => st.applyDiff(j.id, m.id)}>{c.diff.apply}</Button><Button size="small" onClick={() => st.leaveDiff(j.id, m.id)}>Leave it</Button></div></div>
    }
    if (c.kind === 'forkpick') {
      if (c.done) return <Fold label="Fork added" sum={c.done} />
      return <div className="hc"><div className="hc-head"><b>Which assumption should the what-if vary?</b><span className="hc-of">shares steps 1 to 3</span></div><div className="tiles three"><button className="tile" type="button" onClick={() => st.applyFork(j.id, 'rc')}>The window is 24 months<small>Contracts that decide 18 to 24 months out</small></button><button className="tile" type="button" onClick={() => st.applyFork(j.id, 't3')}>The predecessors’ NPS set aside<small>Counted as no answer</small></button><button className="tile" type="button" onClick={() => st.applyFork(j.id, 'four')}>The evergreen contracts left out<small>Only contracts with an end date</small></button></div></div>
    }
    if (c.kind === 'findings' || c.kind === 'note') {
      const acc = j.findings.filter((k) => j.over[`acc:${k}`]).length
      return (
        <div className="hc"><div className="hc-head"><span className="sd-step-n">·</span><b>Findings</b><span className="hc-of">{acc} of {j.findings.length} accepted · click one to open it</span></div>
          <div className="hc-list">{orderedFindings.map((k, i) => { const f = findingsMap[k]; if (!f) return null; const a = !!j.over[`acc:${k}`]; return <div key={k} className="hc-li" onClick={() => { setTab(j.mode === 'watch' ? 'runs' : 'findings'); setPanelOpen(true) }}><span className="sd-rail-n">{i + 1}</span><span className="hc-li-t">{f.h.split(/[:.]\s/)[0]}</span>{a ? <span className="tag ok">Accepted</span> : <span className="hc-li-acts" onClick={(e) => e.stopPropagation()}><a onClick={() => st.acceptFinding(j.id, k)}>Accept</a><a onClick={() => { const t = window.prompt(`What is wrong with finding ${i + 1}? One sentence is enough.`); if (t !== null) st.challenge(j.id, k, t) }}>Challenge</a></span>}</div> })}</div>
          {j.gaps.length ? <span className="hc-note"><WarningOutlined /> Gaps and open questions: {j.gaps.length}, listed on the right.</span> : null}
          <div className="hc-actions">{allAccepted ? <Button size="small" type="primary" onClick={() => { setTab(j.mode === 'watch' ? 'runs' : 'findings'); setPanelOpen(true) }}>Go to the decision</Button> : <Button size="small" type="primary" onClick={() => st.acceptFinding(j.id, 'all')}>Accept all</Button>}<Button size="small" onClick={() => { setTab('data'); setPanelOpen(true) }}>Open the data</Button></div>
        </div>
      )
    }
    if (c.kind === 'decision') {
      return (
        <div className="hc"><div className="hc-head"><span className="sd-step-n">·</span><b>Decision</b><span className="hc-of">{j.chosen ? 'chosen' : `${j.recs.length} ways forward`}</span></div>
          <div className="hc-list">{j.recs.map((r, i) => <div key={r.id} className={`hc-li${r.preferred ? ' is-pref' : ''}`}><span className="sd-rail-n">{i + 1}</span><span className="hc-li-t">{r.title}</span>{j.chosen === r.id ? <span className="tag ok">Chosen</span> : r.preferred ? <span className="tag you">Preferred</span> : null}{!j.chosen ? <span className="hc-li-acts"><a onClick={() => { setTab(j.mode === 'watch' ? 'runs' : 'findings'); setSel(`story:${r.id}`); setPanelOpen(true) }}>Why this</a><a onClick={() => st.choose(j.id, r.id)}>Choose</a></span> : null}</div>)}</div>
        </div>
      )
    }
    if (c.kind === 'send') {
      const outs = j.outputs
      return (
        <div className="hc"><div className="hc-head"><span className="sd-step-n">·</span><b>What to send</b><span className="hc-of">from the templates in your library</span></div>
          <div className="hc-list">{outs.map((o, i) => { const tpl = templates.find((t) => t.id === o.templateId); const started = j.started.includes(o.id); return <div key={o.id} className="hc-li"><span className="sd-rail-n">{i + 1}</span><span className="hc-li-t"><b>{o.label}</b><small>To {o.audience} · {tpl?.name ?? o.template}</small></span>{started ? <span className="tag ok">Started</span> : <Button size="small" type="primary" disabled={!tpl} onClick={() => { const sid = startSubmission(baseGoal(j), o, me); st.markStarted(j.id, o.id); window.setTimeout(() => navigate(appPath(`/submissions/${sid}`)), 700) }}>Build in Submissions</Button>}</div> })}</div>
          <div className="hc-actions"><Button size="small" onClick={() => { downloadPack(baseGoal(j), STATUS_LABEL[baseGoal(j).status], TRIGGER_LABEL[baseGoal(j).trigger]); st.input(j.id, 'Download the analysis pack') }}>Download the analysis pack</Button>{!j.flags.saved ? <Button size="small" icon={<SaveOutlined />} onClick={() => st.savePlan(j.id)}>Save this plan</Button> : null}</div>
        </div>
      )
    }
    if (c.kind === 'execute') {
      const x = j.exec; if (!x) return null
      return (
        <div className={`hc hc-exec is-${x.state}`} data-exec="1"><div className="hc-head"><span className={`sd-step-n${x.state === 'done' ? ' is-done' : ''}`}>{x.state === 'done' ? <CheckOutlined /> : <ThunderboltOutlined />}</span><b>{x.state === 'done' ? 'Executed' : x.state === 'running' ? 'Executing' : 'Ready to execute'}</b><span className="hc-of">{x.title}</span></div>
          <ol className="ex-steps">{x.steps.map((t, i) => <li key={t} className={i < x.done ? 'is-done' : x.state === 'running' && i === x.done ? 'is-running' : ''}><span className="ex-n">{i < x.done ? <CheckOutlined /> : i + 1}</span><span>{t}</span></li>)}</ol>
          {x.state === 'confirm' ? <><span className="hc-note">Nothing has happened yet. I do these {x.steps.length} things only when you say execute; you can still choose another option.</span><div className="hc-actions"><Button size="small" type="primary" icon={<ThunderboltOutlined />} onClick={() => st.execute(j.id)}>Execute</Button><Button size="small" onClick={() => st.notNow(j.id)}>Not now</Button></div></> : null}
          {x.state === 'done' ? <><span className="hc-note">{x.doneText} Executed at {j.executedAt}.</span><div className="hc-actions">{x.sid ? <Button size="small" type="primary" onClick={() => navigate(appPath(`/submissions/${x.sid}`))}>Open the draft in Submissions</Button> : null}<Button size="small" onClick={() => { setTab('runs'); setPanelOpen(true) }}>See the run</Button></div></> : null}
        </div>
      )
    }
    if (c.kind === 'deliv') {
      if (c.done) return <Fold label={j.case === 'watch' ? 'The dashboard, and what I do when risk goes up' : j.mode === 'watch' ? 'What it builds and what it may do' : 'What you get at the end'} sum={c.done} />
      return (
        <div className="hc" data-card="deliv"><div className="hc-head"><span className="sd-step-n">{j.questions.length + 1}</span><b>{j.case === 'watch' ? 'The dashboard, and what I do when risk goes up' : j.mode === 'watch' ? 'What it builds, and what it may do' : 'What should I hand you at the end?'}</b><span className="hc-of">{j.questions.length + 1} of {j.questions.length + 1}</span></div>
          {j.case === 'watch' ? <div className="ws-card" data-testid="watch-setup">
            <div className="ws-row"><b>The dashboard</b><span>{PANELS.filter((p) => DESIGN.panels[p.k]).map((p) => p.name.toLowerCase()).join(' · ') || 'nothing ticked yet'}</span></div>
            <div className="ws-row"><b>When a score rises</b><span>{j.acts.filter((a) => a.on !== false).map((a) => `${a.text.replace(/,.*$/, '').replace(/ of that contract| on why.*$/g, '')}${a.mode === 'ask' ? ' (asks first)' : ''}`).join(' · ')}</span></div>
            <div className="ws-row"><b>The scorecard</b><span>{activeFactors().length} factors · {likelihoodSignals().length} signals · one score per project, {RULE_TEXT[DESIGN.rule]}</span></div>
            <div className="hc-actions"><Button type="primary" onClick={() => st.confirmDeliv(j.id)}>Build the scorecard and start watching</Button><Button onClick={() => { setTab('plan'); setPanelOpen(true); window.setTimeout(() => document.querySelector('[data-part="dashboard"]')?.scrollIntoView({ block: 'start' }), 60) }}>Change them on the plan</Button></div>
          </div> : <DelivPicker specs={j.deliv} onSpecs={(x) => st.setDeliv(j.id, x)} acts={j.mode === 'watch' ? j.acts : undefined} onAct={(k, md) => st.setActMode(j.id, k, md)} onConfirm={() => st.confirmDeliv(j.id)} confirmLabel={j.mode === 'watch' ? 'Arm the watch' : 'Run it'} audience={j.case === 'once' ? 'Renee Halvorsen' : 'Marisol Vega'} />}
        </div>
      )
    }
    if (c.kind === 'delivered') {
      const list = builtSubs()
      return (
        <div className="hc hc-dlv" data-card="delivered"><div className="hc-head"><span className="sd-step-n is-done"><CheckOutlined /></span><b>{j.mode === 'watch' ? 'Handled' : 'Delivered'}</b><span className="hc-of">{list.length} built · option {j.recs.findIndex((r) => r.id === j.chosen) + 1}</span></div>
          <div className="hc-list">{list.map((x) => <div key={x.id} className="hc-li" onClick={() => { setDelivOn(x.id); setTab('deliverables'); setPanelOpen(true) }}><span className="sd-rail-n"><FileTextOutlined /></span><span className="hc-li-t"><b>{x.title}</b><small>For {x.audience.length > 70 ? `${x.audience.slice(0, 68)}…` : x.audience} · version {x.delivId === 'sub-risk-scorecard' && j.case === 'watch' ? Math.max(1, dashV) : x.version ?? 1}</small></span><span className="hc-li-acts"><a>open</a></span></div>)}</div>
          <div className="hc-actions"><Button size="small" onClick={() => { setTab(j.mode === 'watch' && j.case !== 'schedule' ? 'runs' : 'findings'); setPanelOpen(true) }}>Findings and options</Button><Button size="small" onClick={() => navigate(appPath('/submissions/new'), { state: { fromJourney: j.id } })}>Make more in Submissions</Button>{!j.flags.saved ? <Button size="small" type="text" icon={<SaveOutlined />} onClick={() => st.savePlan(j.id)}>Save this plan</Button> : null}</div>
        </div>
      )
    }
    if (c.kind === 'actions') {
      const lastAct = [...j.chat].reverse().find((x) => x.card?.kind === 'actions')?.id
      if (lastAct !== m.id) return <Fold label="Actions" sum="As they stood then; the latest list is further down" />
      const waiting = j.execActs.filter((a) => a.state === 'waiting').length
      return <div className="hc" data-card="actions"><div className="hc-head"><span className={`sd-step-n${j.status === 'executed' && !waiting ? ' is-done' : ''}`}>{j.status === 'executed' && !waiting ? <CheckOutlined /> : <ThunderboltOutlined />}</span><b>{j.status === 'executing' ? 'Acting on the top option' : waiting ? 'Actions: some wait for your OK' : 'Actions done'}</b><span className="hc-of">option {j.recs.findIndex((r) => r.id === j.chosen) + 1}</span></div>{actionsList()}</div>
    }
    if (c.kind === 'fired') return null
    return null
  }

  /* ---------------- where you are */
  const journey = useMemo((): (JStep & { dock?: string; waiting?: boolean })[] => {
    if (!j) return []
    const findMsg = (pred: (m: Msg) => boolean) => j.chat.find(pred)?.id
    const at = (t: Tab, msgId?: string) => () => { setTab(t); setPanelOpen(true); scrollToMsg(msgId) }
    const waiting = j.execActs.filter((a) => a.state === 'waiting').length
    const total = j.questions.length + 1
    const answered = j.questions.filter((q) => j.answers[q.key]).length + (j.delivConfirmed ? 1 : 0)
    const watch = j.mode === 'watch'
    const nowKey = j.stage === 'reading' ? 'plan' : ['questions', 'plan'].includes(j.stage) ? 'input'
      : !watch ? (['delivered', 'ready'].includes(j.status) ? 'end' : 'run')
      : j.status === 'armed' ? 'armed' : ['fired', 'executing'].includes(j.status) ? 'run' : waiting ? 'handled' : 'end'
    const order = watch ? ['plan', 'input', 'armed', 'run', 'handled'] : ['plan', 'input', 'run', 'delivered']
    const idx = nowKey === 'end' ? order.length : order.indexOf(nowKey)
    const s = (k: string): JStep['state'] => { const i = order.indexOf(k); return i < idx ? 'done' : i === idx ? 'now' : 'todo' }
    const N = liveNodes(j).filter((n) => n.type !== 'checkpoint' && !n.fork).length
    const steps: (JStep & { dock?: string; waiting?: boolean })[] = [
      { key: 'plan', label: 'Plan', state: s('plan'), onClick: at('plan', findMsg((m) => m.card?.kind === 'reads')), dock: 'Drafting the plan', waiting: false },
      { key: 'input', label: 'Your input', state: s('input'), sub: s('input') === 'now' ? `${answered} of ${total}` : undefined, onClick: at('plan', findMsg((m) => m.card?.kind === 'q' || m.card?.kind === 'deliv')), dock: j.chat.some((m) => m.card?.kind === 'deliv' && !m.card.done) ? (watch ? 'Pick what it builds and may do, then arm it' : 'Pick the deliverables, then run it') : 'Answer the question', waiting: j.stage === 'questions' },
      ...(watch ? [{ key: 'armed', label: 'Armed', state: s('armed'), sub: s('armed') === 'now' ? 'waiting' : undefined, onClick: at('plan', findMsg((m) => m.who === 'event' && /armed/i.test(m.text))), dock: 'Waiting for the trigger', waiting: false }] : []),
      { key: 'run', label: watch ? 'Run and act' : 'Run', state: s('run'), sub: s('run') === 'now' ? `${j.doneCount} of ${N}` : undefined, onClick: at('workflow', findMsg((m) => m.who === 'event' && /running|fired|scheduled run/i.test(m.text))), dock: watch ? 'Running, choosing and acting by itself' : 'Running to the end by itself', waiting: false },
      watch ? { key: 'handled', label: 'Handled', state: s('handled'), sub: waiting ? `${waiting} for your OK` : undefined, onClick: at('deliverables', findMsg((m) => m.card?.kind === 'delivered')), dock: 'Approve or leave the held action', waiting: true }
        : { key: 'delivered', label: 'Delivered', state: s('delivered'), onClick: at('deliverables', findMsg((m) => m.card?.kind === 'delivered')), dock: '', waiting: false },
    ]
    return steps
  }, [j]) // eslint-disable-line react-hooks/exhaustive-deps
  const nowStep = journey.find((x) => x.state === 'now')
  const nowIdx = nowStep ? journey.indexOf(nowStep) + 1 : journey.length
  const [resume, setResume] = useState<string | null>(null)
  const seenLen = useRef(0)
  useEffect(() => { setResume(j?.chat.length ? current : null); seenLen.current = j?.chat.length ?? 0 }, [current]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (resume && (j?.chat.length ?? 0) !== seenLen.current) setResume(null) }, [j?.chat.length]) // eslint-disable-line react-hooks/exhaustive-deps
  const resumeLine = resume && resume === current && j && j.chat.length > 3 ? (nowStep ? `Back on this. Step ${nowIdx} of ${journey.length}, ${nowStep.label}. Next: ${nowStep.dock?.toLowerCase()}.` : 'Back on this. It is done: the deliverables are on the right, with the findings, the options, every step and its receipts.') : null

  /* ---------------- the list on the left */
  const match = useRailMatch()
  const all = order.map((id) => goals[id]).filter(Boolean)
  const section = (pred: (x: Journey) => boolean) => all.filter(pred).filter((x) => match(x.title))
  /* Five groups: what needs you (set-up not finished, or an action held for your OK), what is running by itself, the standing goals, what is executed (every finished run, with its deliverables), and the saved plans. */
  const waitingOf = (x: Journey) => x.execActs.filter((a) => a.state === 'waiting').length
  const needsYou = section((x) => ['reading', 'questions', 'plan'].includes(x.stage) || x.status === 'paused' || (x.mode === 'watch' && x.status === 'executed' && waitingOf(x) > 0))
  const ready = section((x) => (x.mode === 'once' && x.stage === 'running' && ['running', 'wait'].includes(x.status)) || (x.mode === 'watch' && ['fired', 'executing'].includes(x.status)))
  const standing = section((x) => x.mode === 'watch' && x.stage === 'armed')
  const executed = section((x) => (x.mode === 'once' && ['delivered', 'ready'].includes(x.status)) || (x.mode === 'watch' && x.status === 'executed'))
  const needCountOf = (x: Journey) => x.questions.filter((q) => !x.answers[q.key]).length + (x.delivConfirmed ? 0 : 1)
  const statusOf = (x: Journey, where?: 'needs' | 'standing' | 'executed') => {
    const nb = Object.keys(x.built).length
    if (where === 'executed') return <span className="is-good">{x.status === 'ready' ? 'Ended on a question' : `${x.mode === 'watch' ? 'Handled' : 'Delivered'} ${x.executedAt ?? ''} · ${nb} deliverable${nb === 1 ? '' : 's'}`}</span>
    if (where === 'standing' && x.mode === 'watch') return x.status === 'armed' ? <span>Armed · next {x.nextCheck}</span> : x.status === 'executed' ? <span>Armed · last run handled{waitingOf(x) ? `, ${waitingOf(x)} for your OK` : ''}</span> : <span className="is-warn">Armed · running now</span>
    if (x.mode === 'watch' && x.status === 'executed' && waitingOf(x)) return <span className="is-warn">{waitingOf(x)} action{waitingOf(x) === 1 ? '' : 's'} wait{waitingOf(x) === 1 ? 's' : ''} for your OK</span>
    if (x.mode === 'watch' && ['fired', 'executing'].includes(x.status)) return <span className="is-warn">{x.status === 'fired' ? 'Fired · running' : 'Acting'}</span>
    return x.stage === 'questions' ? <span className="is-warn">{needCountOf(x)} thing{needCountOf(x) === 1 ? ' needs' : 's need'} you</span> : x.stage === 'reading' ? 'Drafting the plan' : x.stage === 'plan' ? (x.mode === 'watch' ? 'Arming' : 'Starting') : x.status === 'running' ? `Running by itself · step ${x.doneCount + 1}` : x.status === 'paused' ? 'Paused by you' : x.status
  }
  const item = (where?: 'needs' | 'standing' | 'executed') => (x: Journey) => <RailItem key={`${where ?? 'r'}-${x.id}`} title={(where === 'needs' || where === 'executed') && x.mode === 'watch' && x.runs.length ? x.runs[x.runs.length - 1].label : x.title} status={<span>{statusOf(x, where)} · {x.agent.name}</span>} on={current === x.id} icon={where === 'executed' ? <CheckOutlined /> : x.mode === 'watch' ? (x.case === 'schedule' ? <ClockCircleOutlined /> : <BellOutlined />) : <FileTextOutlined />} onClick={() => { navigate(appPath(`/goals/${x.id}`)); if ((where === 'executed' || where === 'needs') && x.runs.length && Object.keys(x.built).length) window.setTimeout(() => window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id: x.id, tab: 'deliverables' } })), 60) }} extra={where === 'standing' && x.status === 'armed' ? <a className="rl-mini" onClick={(e) => { e.stopPropagation(); st.fire(x.id); navigate(appPath(`/goals/${x.id}`)) }}><ThunderboltOutlined /> {x.case === 'schedule' ? 'Simulate: run now' : 'Simulate tomorrow’s morning check'}</a> : null} />
  const rail = (
    <>
      <RailSearch placeholder="Search goals" />
      <RailSection id="j-needs" label="Needs you" n={needsYou.length} empty="Nothing waits for you.">{needsYou.map(item('needs'))}</RailSection>
      <RailSection id="j-ready" label="Running" n={ready.length} empty="Nothing running.">{ready.map(item())}</RailSection>
      <RailSection id="j-standing" label="Standing goals" n={standing.length} empty="None yet.">{standing.map(item('standing'))}</RailSection>
      <RailSection id="j-executed" label="Executed" n={executed.length} empty="Every finished run lands here, with its deliverables.">{executed.map(item('executed'))}</RailSection>
      <RailSection id="j-saved" label="Saved plans" n={saved.length}>{saved.filter((a) => match(a.name)).map((a) => <RailItem key={a.id} title={a.name} status={<span>{a.steps.length} steps · new goal from it</span>} icon={<SaveOutlined />} onClick={() => { st.setStart({ mode: a.mode, prompt: a.prompt, files: a.files, approachId: a.id }); st.open(null); navigate(appPath('/goals'), { state: { fresh: true } }) }} />)}</RailSection>
    </>
  )

  const newGoal = () => { st.open(null); st.setStart({ prompt: '', files: [], approachId: undefined }); navigate(appPath('/goals'), { state: { fresh: true } }) }
  const cont = (m: Msg) => { const i = j!.chat.findIndex((y) => y.id === m.id); return i > 0 && j!.chat[i - 1].who === 'agent' }

  return (
    <>
      <HubFrame rail={rail} panel={j && panelOpen ? renderPanel() : null}>
        <input ref={fileRef} type="file" accept=".pptx,.docx,.pdf,.txt,.md,.csv,.xlsx" style={{ display: 'none' }} data-testid="goal-upload" onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); e.target.value = '' }} />
        <div className="hub-top">
          <RailToggle />
          <span className="hub-top-title"><span title={j ? j.title : undefined}>{j ? j.title : start.mode === 'once' ? 'New goal' : 'New standing goal'}</span>{j && !panelOpen ? pill() : null}</span>
          {j && !panelOpen ? <Tooltip title="Show the plan on the right"><span role="button" aria-label="Show the panel" className="hub-icon" onClick={() => setPanelOpen(true)}><LayoutOutlined /></span></Tooltip> : null}
          {j ? <Button className="hub-new" icon={<PlusOutlined />} onClick={newGoal}>New goal</Button> : null}
        </div>
        {j ? <JourneyBar steps={journey} /> : null}
        {!j ? renderStart() : convHidden && panelOpen ? <div className="conv-hidden"><Button onClick={() => setConvHidden(false)} icon={<EyeOutlined />}>Show chat</Button></div> : (
          <>
            <div className="hub-feed" ref={feedRef}>
              {j.chat.map((m) => m.who === 'event' ? <div key={m.id} id={`msg-${m.id}`} className="gc-event">{m.text}</div>
                : m.who === 'me' ? <div key={m.id} id={`msg-${m.id}`} className="hub-me"><div className="gc-bubble is-me">{m.text}{m.files?.length ? <div className="files">{m.files.map((f) => <span key={f.n} className="file"><PaperClipOutlined /> {f.n}<small>{f.s}</small></span>)}</div> : null}</div></div>
                : <div key={m.id} id={`msg-${m.id}`} className={`hub-agent${cont(m) ? ' is-cont' : ''}`}><AgentMark agent={j.agent} /><div className="hub-agent-body">{m.text ? <div className="hub-text"><RichText text={m.text} /></div> : null}{m.card ? renderCard(m) : null}</div></div>)}
              {j.typing ? <div className="hub-agent"><AgentMark agent={j.agent} /><div className="gc-bubble is-agent gc-typing"><span /><span /><span /></div></div> : null}
              {resumeLine && !j.typing ? <div className="gc-event is-resume" data-testid="resume">{resumeLine}</div> : null}
              <div ref={endRef} />
            </div>
            <div className="hub-input">
              {nowStep?.dock ? <Dock away={dock.away} go={dock.go} lead={nowStep.waiting ? 'Waiting for you' : 'In progress'} label={nowStep.dock} /> : null}
              {j.chips.length && j.composer.on ? <div className="gc-chips">{j.chips.map((c) => <span key={c} className="gc-chip" onClick={() => send(c)}>{c}</span>)}</div> : null}
              {composer()}
              <div className="hub-hint">Nothing you say here changes the data.</div>
            </div>
          </>
        )}
      </HubFrame>
      <Drawer open={!!drawer} onClose={() => setDrawer(null)} width="min(1280px, 94vw)" title="The data behind it" destroyOnHidden styles={{ body: { padding: SP.base } }}>
        {drawer ? <DataExplorer start={drawer} height={Math.max(360, window.innerHeight - 150)} /> : null}
      </Drawer>
    </>
  )
}

