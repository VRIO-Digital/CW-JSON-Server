/*
 * Ask, for contract risk: the layer most people use. A leader types a question, or picks one of the
 * questions leaders ask, and gets the answer with the projects behind it, where it was read from, and
 * what to ask next. Every answer is worked out from the same scorecard as the dashboard (data/askRisk.ts).
 */
import { ArrowUpOutlined, FileTextOutlined, GlobalOutlined, MailOutlined, SearchOutlined, TableOutlined, UnorderedListOutlined } from '@ant-design/icons'
import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { create } from 'zustand'
import { appPath } from '../api/dataset'
import { ASK_COUNT, ASK_LIBRARY, askRisk, type AskAnswer } from '../data/askRisk'
import { P } from '../data/pace'
import { CONTRACTS, DESIGN, activeFactors, likelihoodSignals, type SrcKind, type When } from '../data/risk'
import { useDesign, useDesignV } from '../store/designStore'
import { useJourney } from '../store/journeyStore'
import './AskRisk.css'

interface Msg { id: number; q: string; steps: string[]; done: number; a?: AskAnswer }
interface AskStore { msgs: Msg[]; busy: boolean; ask: (q: string, w: When) => Promise<void>; clear: () => void }
const wait = (ms: number) => new Promise((r) => window.setTimeout(r, P(ms)))
let SEQ = 0
export const useAsk = create<AskStore>((set, get) => ({
  msgs: [], busy: false,
  clear: () => set({ msgs: [] }),
  ask: async (q, w) => {
    const text = q.trim(); if (!text || get().busy) return
    const a = askRisk(text, w), id = (SEQ += 1)
    const steps = a.key === 'none' ? ['understand the question'] : ['understand the question', `read the scorecard for ${CONTRACTS.length} projects`, ...a.sources.filter((s) => s.name !== 'The contract risk scorecard').slice(0, 2).map((s) => `read ${s.name}`), 'write the answer']
    set((s) => ({ busy: true, msgs: [...s.msgs, { id, q: text, steps, done: 0 }] }))
    for (let i = 0; i < steps.length; i += 1) { await wait(650 + Math.random() * 450); set((s) => ({ msgs: s.msgs.map((m) => (m.id === id ? { ...m, done: i + 1 } : m)) })) }
    await wait(250)
    set((s) => ({ busy: false, msgs: s.msgs.map((m) => (m.id === id ? { ...m, a } : m)) }))
  },
}))
if (typeof window !== 'undefined') (window as unknown as { __cwAsk: unknown }).__cwAsk = useAsk

const ICON: Record<SrcKind, JSX.Element> = { table: <TableOutlined />, document: <FileTextOutlined />, mail: <MailOutlined />, web: <GlobalOutlined /> }
const rich = (t: string) => t.split(/(\*\*[^*]+\*\*)/g).map((x, i) => (x.startsWith('**') ? <b key={i}>{x.slice(2, -2)}</b> : <span key={i}>{x}</span>))

function Answer({ a, onAsk }: { a: AskAnswer; onAsk: (q: string) => void }) {
  const [all, setAll] = useState(false)
  const t = a.table, rows = t ? (all ? t.rows : t.rows.slice(0, 8)) : [], max = a.bars ? Math.max(...a.bars.map((b) => b.value)) : 0, min = a.bars && a.bars.length > 6 ? Math.min(...a.bars.map((b) => b.value)) * 0.98 : 0
  return (
    <div className="aq-a" data-answer={a.key}>
      <p className="aq-head">{rich(a.head)}</p>
      {a.points?.length ? <ul className="aq-points">{a.points.map((p, i) => <li key={i}>{rich(p)}</li>)}</ul> : null}
      {a.bars ? <div className="aq-bars">{a.bars.map((b) => <div key={b.label} className="aq-bar"><span>{b.label}</span><div><i style={{ width: `${Math.max(2, ((b.value - min) / ((max - min) || 1)) * 100)}%` }} /></div><em>{b.text}</em></div>)}</div> : null}
      {t ? (
        <div className="aq-tbl-wrap">
          <table className="aq-tbl" data-testid="aq-table">
            <thead><tr>{t.cols.map((c, i) => <th key={i} className={t.num?.includes(i) ? 'n' : ''}>{c}</th>)}</tr></thead>
            <tbody>{rows.map((r, ri) => { const cid = t.ids?.[ri]; return (
              <tr key={ri} className={cid ? 'is-link' : ''} onClick={cid ? () => onAsk(`What is the status of ${CONTRACTS.find((c) => c.id === cid)!.site} and why?`) : undefined}>{r.map((v, i) => <td key={i} className={t.num?.includes(i) ? 'n' : ''}>{i === 0 && cid ? <b>{v}</b> : v}</td>)}</tr>) })}</tbody>
          </table>
          {t.rows.length > 8 ? <button type="button" className="aq-more" data-testid="aq-more" onClick={() => setAll(!all)}>{all ? 'Show the first 8' : `Show all ${t.rows.length}`}</button> : null}
          {t.ids ? <small className="aq-hint">Click a project to ask about it.</small> : null}
        </div>
      ) : null}
      {a.sources.length ? <div className="aq-src"><span>Read from</span>{a.sources.map((s) => <em key={s.name}>{ICON[s.kind]} {s.name}</em>)}</div> : null}
      <div className="aq-follow">{a.follow.map((f) => <button key={f} type="button" onClick={() => onAsk(f)}>{f}</button>)}</div>
    </div>
  )
}

function Library({ onAsk, compact }: { onAsk: (q: string) => void; compact?: boolean }) {
  return (
    <div className={`aq-lib${compact ? ' is-compact' : ''}`} data-testid="aq-library">
      {ASK_LIBRARY.map((t) => (
        <section key={t.theme}>
          <h4>{t.theme}</h4>
          {t.qs.map((q) => <button key={q} type="button" className="aq-q" onClick={() => onAsk(q)}>{q}</button>)}
        </section>
      ))}
    </div>
  )
}

export default function AskRiskPage() {
  useDesignV()
  const { msgs, busy, ask, clear } = useAsk()
  const versions = useDesign((s) => s.versions)
  const watch = useJourney((s) => Object.values(s.goals).find((g) => g.case === 'watch' && (g.stage === 'armed' || g.runs.length > 0)))
  const navigate = useNavigate()
  const [text, setText] = useState('')
  const [lib, setLib] = useState(false)
  const end = useRef<HTMLDivElement>(null)
  const w: When = watch && watch.runs.length > 0 ? 'after' : 'before'
  const send = (q: string) => { setLib(false); setText(''); void ask(q, w) }
  useEffect(() => { end.current?.scrollIntoView({ block: 'end', behavior: 'smooth' }) }, [msgs.length, msgs[msgs.length - 1]?.done, msgs[msgs.length - 1]?.a])
  const ver = versions[versions.length - 1]
  const asOf = watch ? `Answers come from your contract risk scorecard: ${activeFactors().length} factors, ${likelihoodSignals().length} signals${ver ? `, version ${ver.v}` : ''}, ${w === 'after' ? 'as of the 20 November morning check' : 'as of the 19 November check'}.` : `No contract risk goal is live yet, so I answer on the scorecard I would propose: ${activeFactors().length} factors, ${likelihoodSignals().length} signals.`
  return (
    <div className="aq" data-testid="ask-risk">
      <header className="aq-top">
        <div><h1>Ask the Contract Risk Analyst</h1><p data-testid="aq-asof">{asOf} {watch ? <a onClick={() => navigate(appPath(`/goals/${watch.id}`))}>Open the goal</a> : <a onClick={() => navigate(appPath('/goals'))}>Set up the goal</a>}{DESIGN.source === 'uploaded' && DESIGN.tplName ? ` Scored on your template, ${DESIGN.tplName}.` : ''}</p></div>
        {msgs.length ? <div className="aq-top-a"><button type="button" data-testid="aq-lib-btn" onClick={() => setLib(!lib)}><UnorderedListOutlined /> {lib ? 'Hide the questions' : `All ${ASK_COUNT} questions`}</button><button type="button" onClick={() => { clear(); setLib(false) }}>New conversation</button></div> : null}
      </header>
      <div className="aq-body">
        {!msgs.length ? (
          <div className="aq-empty">
            <h2>What do you want to know about your contracts?</h2>
            <p>Ask in your own words, about the portfolio, a region, a project by name or a signal such as overtime or missed samples. Or pick one of the {ASK_COUNT} questions leaders ask.</p>
            <Library onAsk={send} />
          </div>
        ) : (
          <div className="aq-feed">
            {msgs.map((m) => (
              <div key={m.id} className="aq-turn" data-turn={m.id}>
                <div className="aq-me">{m.q}</div>
                {m.a ? <Answer a={m.a} onAsk={send} /> : <div className="aq-think" data-testid="aq-thinking">{m.steps.map((s, i) => <div key={i} className={i < m.done ? 'is-done' : i === m.done ? 'is-live' : ''}><span />{s}</div>)}</div>}
              </div>
            ))}
            {lib ? <Library onAsk={send} compact /> : null}
            <div ref={end} />
          </div>
        )}
      </div>
      <form className="aq-ask" onSubmit={(e) => { e.preventDefault(); send(text) }}>
        <SearchOutlined />
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Ask about a project, a region, a signal, what moved and why…" aria-label="Your question" data-testid="aq-input" disabled={busy} />
        <button type="submit" disabled={busy || !text.trim()} aria-label="Ask" data-testid="aq-send"><ArrowUpOutlined /></button>
      </form>
    </div>
  )
}
