import {
  ArrowRightOutlined,
  BellOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  FileSearchOutlined,
  MailOutlined,
  PlusOutlined,
  QuestionCircleOutlined,
  TableOutlined,
  UserOutlined,
  WarningOutlined,
} from '@ant-design/icons'
import { Alert, Button, Card, Col, Drawer, Flex, Form, Input, Radio, Row, Segmented, Space, Table, Tag, Timeline, Typography } from 'antd'
import { useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import PageHeader from '../components/common/PageHeader'
import { appPath } from '../api/dataset'
import {
  STATUS_LABEL,
  TRIGGER_LABEL,
  WATCHERS,
  type Analysis,
  type AnalysisStatus,
  type Evidence,
  type Option,
  type Trigger,
} from '../data/analysisCases'
import { useAnalysisStore } from '../store/analysisStore'
import { useAuthStore } from '../store/authStore'
import { BRAND, BRAND_INK, BRAND_SOFT, SP, STATUS } from '../theme'

const { Text, Title, Paragraph } = Typography

/* ------------------------------------------------------------------ small parts */

const TRIGGER_ICON: Record<Trigger, React.ReactNode> = {
  person: <UserOutlined />,
  schedule: <ClockCircleOutlined />,
  rule: <BellOutlined />,
}

const STATUS_COLOR: Record<AnalysisStatus, string> = {
  investigating: 'processing',
  'needs-input': 'warning',
  'findings-ready': 'success',
  accepted: 'default',
}

const EVIDENCE_ICON: Record<Evidence['kind'], React.ReactNode> = {
  table: <TableOutlined />,
  document: <FileSearchOutlined />,
  mail: <MailOutlined />,
  assumption: <QuestionCircleOutlined />,
  gap: <WarningOutlined />,
}

const EVIDENCE_LABEL: Record<Evidence['kind'], string> = {
  table: 'Table',
  document: 'Document',
  mail: 'Mail',
  assumption: 'Assumption',
  gap: 'Not established',
}

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })

function TriggerTag({ trigger }: { trigger: Trigger }) {
  return (
    <Tag icon={TRIGGER_ICON[trigger]} style={{ marginInlineEnd: 0 }}>
      {TRIGGER_LABEL[trigger]}
    </Tag>
  )
}

function StatusTag({ status }: { status: AnalysisStatus }) {
  return (
    <Tag color={STATUS_COLOR[status]} style={{ marginInlineEnd: 0 }}>
      {STATUS_LABEL[status]}
    </Tag>
  )
}

function Figure({ label, value, tone }: { label: string; value: string; tone?: 'good' | 'warn' | 'crit' }) {
  const color = tone === 'good' ? STATUS.good : tone === 'warn' ? STATUS.warn : tone === 'crit' ? STATUS.crit : undefined
  return (
    <div style={{ minWidth: 120 }}>
      <Text type="secondary" style={{ fontSize: 11.5, textTransform: 'uppercase', letterSpacing: 0.3, display: 'block' }}>
        {label}
      </Text>
      <Text strong style={{ fontSize: 18, color, letterSpacing: -0.3 }}>
        {value}
      </Text>
    </div>
  )
}

function EvidenceLine({ e }: { e: Evidence }) {
  const muted = e.kind === 'assumption' || e.kind === 'gap'
  return (
    <Flex gap={SP.sm} align="flex-start" style={{ padding: `${SP.xs}px 0` }}>
      <span style={{ color: muted ? STATUS.warn : BRAND_INK, marginTop: 2 }}>{EVIDENCE_ICON[e.kind]}</span>
      <div style={{ minWidth: 0 }}>
        <Text style={{ fontSize: 13 }}>{e.text}</Text>
        <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>
          {EVIDENCE_LABEL[e.kind]} · {e.source}
          {e.asOf ? ` · as of ${e.asOf}` : ''}
        </Text>
      </div>
    </Flex>
  )
}

/* ------------------------------------------------------------------ list page */

function AnalysisList() {
  const analyses = useAnalysisStore((s) => s.analyses)
  const start = useAnalysisStore((s) => s.start)
  const identity = useAuthStore((s) => s.identity)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [form] = Form.useForm<{ goal: string; scope: string; constraints: string; trigger: Trigger; when: string }>()
  const trigger = Form.useWatch('trigger', form) ?? 'person'

  const columns = [
    {
      title: 'Goal',
      dataIndex: 'title',
      key: 'title',
      render: (_: string, a: Analysis) => (
        <div>
          <Text strong style={{ display: 'block' }}>{a.title}</Text>
          <Text type="secondary" style={{ fontSize: 12.5 }}>{a.goal.length > 140 ? `${a.goal.slice(0, 138)}…` : a.goal}</Text>
        </div>
      ),
    },
    { title: 'Started', key: 'trigger', width: 190, render: (_: unknown, a: Analysis) => <TriggerTag trigger={a.trigger} /> },
    { title: 'Where it is', key: 'status', width: 180, render: (_: unknown, a: Analysis) => <StatusTag status={a.status} /> },
    {
      title: 'Accountable',
      key: 'owner',
      width: 200,
      render: (_: unknown, a: Analysis) => (
        <div>
          <Text style={{ display: 'block' }}>{a.owner}</Text>
          <Text type="secondary" style={{ fontSize: 12 }}>{a.ownerRole}</Text>
        </div>
      ),
    },
    { title: '', key: 'open', width: 48, render: () => <ArrowRightOutlined style={{ color: BRAND }} /> },
  ]

  return (
    <>
      <PageHeader
        title="Analysis"
        subtitle="Give the analyst a goal, or let a schedule or a rule give it one. It works the question through the published graph, shows its evidence and what it could not establish, and brings back options and a recommendation for you to accept, change or challenge."
        actions={
          <Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>
            New analysis
          </Button>
        }
      />

      <Table<Analysis>
        rowKey="id"
        columns={columns}
        dataSource={analyses}
        pagination={false}
        onRow={(a) => ({ onClick: () => navigate(appPath(`/analysis/${a.id}`)), style: { cursor: 'pointer' } })}
        style={{ marginBottom: SP.xxl }}
      />

      <Title level={5} style={{ marginBottom: SP.xs }}>Watching for you</Title>
      <Paragraph type="secondary" style={{ fontSize: 13, marginBottom: SP.base }}>
        Schedules and rules that can start an analysis without anyone asking. A rule names a condition the graph can check; it never guesses.
      </Paragraph>
      <Row gutter={[SP.base, SP.base]} style={{ marginBottom: SP.xl }}>
        {WATCHERS.map((w) => (
          <Col key={w.id} xs={24} md={12}>
            <Card size="small" styles={{ body: { padding: `${SP.md}px ${SP.base}px` } }}>
              <Flex justify="space-between" align="flex-start" gap={SP.sm}>
                <div>
                  <Space size={SP.xs}>
                    <span style={{ color: BRAND_INK }}>{TRIGGER_ICON[w.kind]}</span>
                    <Text strong>{w.label}</Text>
                  </Space>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: SP.xs }}>{w.detail}</Text>
                </div>
                <Tag style={{ marginInlineEnd: 0 }}>{w.state}</Tag>
              </Flex>
            </Card>
          </Col>
        ))}
      </Row>

      <Drawer title="New analysis" open={open} onClose={() => setOpen(false)} width={520} destroyOnHidden>
        <Form
          form={form}
          layout="vertical"
          initialValues={{ trigger: 'person' }}
          onFinish={(v) => {
            const id = start({ ...v, owner: identity?.name ?? 'You' })
            setOpen(false)
            navigate(appPath(`/analysis/${id}`))
          }}
        >
          <Form.Item name="goal" label="What do you want to know or achieve?" rules={[{ required: true, message: 'Say the goal in plain words.' }]}>
            <Input.TextArea rows={3} placeholder="e.g. Can we bring the Saint-Roch charging expansion back inside its €4.3M budget without moving the service date?" />
          </Form.Item>
          <Form.Item name="scope" label="Scope" extra="One line each: which projects, period, contract. Leave empty and the analyst takes the whole published graph.">
            <Input.TextArea rows={2} placeholder={'P-VM-026 Depot charging expansion\nFY2026 and FY2027'} />
          </Form.Item>
          <Form.Item name="constraints" label="Constraints" extra="What must not move. The analyst treats these as fixed, not as levers.">
            <Input.TextArea rows={2} placeholder={'Service date 1 March 2027 is fixed\nNo change to the PPI envelope'} />
          </Form.Item>
          <Form.Item name="trigger" label="How should it start?">
            <Radio.Group
              options={[
                { label: 'Now, by me', value: 'person' },
                { label: 'On a schedule', value: 'schedule' },
                { label: 'When a rule fires', value: 'rule' },
              ]}
              optionType="button"
            />
          </Form.Item>
          <Form.Item
            name="when"
            label={trigger === 'person' ? 'Deadline (optional)' : trigger === 'schedule' ? 'Schedule' : 'Condition the graph can check'}
          >
            <Input
              placeholder={
                trigger === 'person'
                  ? 'e.g. before the executive committee on 14 October'
                  : trigger === 'schedule'
                    ? 'e.g. every Monday 06:00, or the first working day of the month'
                    : 'e.g. forecast total of any project rises more than 5% between snapshots'
              }
            />
          </Form.Item>
          <Alert
            type="info"
            showIcon
            style={{ marginBottom: SP.base }}
            message="The analyst asks before it assumes."
            description="If the goal needs something the graph does not hold, the analysis stops at 'Needs your input' and tells you what is missing, rather than filling the gap itself."
          />
          <Button type="primary" htmlType="submit" block>
            Start
          </Button>
        </Form>
      </Drawer>
    </>
  )
}

/* ------------------------------------------------------------------ detail page */

function OptionCard({ o, chosen }: { o: Option; chosen: boolean }) {
  return (
    <Card
      size="small"
      style={{ height: '100%', borderColor: chosen ? BRAND : undefined, background: chosen ? BRAND_SOFT : undefined }}
      styles={{ body: { padding: `${SP.base}px ${SP.lg}px` } }}
    >
      <Flex justify="space-between" align="flex-start" gap={SP.sm}>
        <Text strong style={{ color: chosen ? BRAND_INK : undefined }}>{o.label}</Text>
        {chosen ? (
          <Tag color="orange" style={{ marginInlineEnd: 0 }}>
            Recommended
          </Tag>
        ) : null}
      </Flex>
      <Paragraph style={{ fontSize: 13, margin: `${SP.sm}px 0` }}>{o.outcome}</Paragraph>
      <Flex gap={SP.lg} wrap style={{ margin: `${SP.sm}px 0` }}>
        {o.figures.map((f) => (
          <Figure key={f.label} {...f} />
        ))}
      </Flex>
      <Text type="secondary" style={{ fontSize: 12.5, display: 'block' }}>
        Trade-off: {o.tradeoff}
      </Text>
    </Card>
  )
}

function AnalysisDetail({ a }: { a: Analysis }) {
  const navigate = useNavigate()
  const identity = useAuthStore((s) => s.identity)
  const addLog = useAnalysisStore((s) => s.addLog)
  const accept = useAnalysisStore((s) => s.accept)
  const answer = useAnalysisStore((s) => s.answer)
  const [view, setView] = useState<'decision' | 'evidence'>('decision')
  const [drawer, setDrawer] = useState<null | 'add' | 'challenge' | 'answer'>(null)
  const [note, setNote] = useState('')
  const me = identity?.name ?? 'You'

  const submit = () => {
    if (!note.trim()) return
    if (drawer === 'add') addLog(a.id, me, `Added information: ${note.trim()}`)
    if (drawer === 'challenge') addLog(a.id, me, `Challenged a finding: ${note.trim()}`)
    if (drawer === 'answer') answer(a.id, me, note.trim())
    setNote('')
    setDrawer(null)
  }

  const hasFindings = a.findings.length > 0

  return (
    <>
      <Button type="link" style={{ padding: 0, marginBottom: SP.sm }} onClick={() => navigate(appPath('/analysis'))}>
        ← All analyses
      </Button>
      <PageHeader
        title={a.title}
        subtitle={a.goal}
        actions={
          <>
            <Segmented
              value={view}
              onChange={(v) => setView(v as 'decision' | 'evidence')}
              options={[
                { label: 'Decision view', value: 'decision' },
                { label: 'Evidence view', value: 'evidence' },
              ]}
            />
          </>
        }
      />

      {/* Goal strip */}
      <Card size="small" style={{ marginBottom: SP.base }} styles={{ body: { padding: `${SP.md}px ${SP.lg}px` } }}>
        <Flex gap={SP.base} wrap align="center" justify="space-between">
          <Space size={SP.sm} wrap>
            <TriggerTag trigger={a.trigger} />
            <StatusTag status={a.status} />
            <Text type="secondary" style={{ fontSize: 12.5 }}>
              Accountable: <Text>{a.owner}</Text>, {a.ownerRole} · started {fmtDate(a.startedAt)}
            </Text>
          </Space>
        </Flex>
        <Text type="secondary" style={{ display: 'block', fontSize: 13, marginTop: SP.sm }}>{a.triggerDetail}</Text>
        {view === 'evidence' ? (
          <Row gutter={[SP.lg, SP.sm]} style={{ marginTop: SP.md }}>
            <Col xs={24} md={12}>
              <Text strong style={{ fontSize: 12.5 }}>Scope</Text>
              <ul style={{ margin: `${SP.xs}px 0 0`, paddingLeft: 18, fontSize: 13 }}>
                {a.scope.map((s) => <li key={s}>{s}</li>)}
              </ul>
            </Col>
            <Col xs={24} md={12}>
              <Text strong style={{ fontSize: 12.5 }}>Constraints, treated as fixed</Text>
              <ul style={{ margin: `${SP.xs}px 0 0`, paddingLeft: 18, fontSize: 13 }}>
                {a.constraints.length ? a.constraints.map((s) => <li key={s}>{s}</li>) : <li>None stated</li>}
              </ul>
            </Col>
          </Row>
        ) : null}
      </Card>

      {/* Open question */}
      {a.question ? (
        <Alert
          type="warning"
          showIcon
          style={{ marginBottom: SP.base }}
          message="The analyst needs one answer from you before the recommendation is final."
          description={a.question}
          action={
            <Button size="small" type="primary" onClick={() => setDrawer('answer')}>
              Answer
            </Button>
          }
        />
      ) : null}

      {!hasFindings ? (
        <Card size="small" style={{ marginBottom: SP.base }}>
          <Text strong>Investigating.</Text>
          <Text type="secondary" style={{ display: 'block', fontSize: 13 }}>
            The analyst is working through the goal. The log at the bottom shows each step as it happens; findings, options and a recommendation appear here when it has something it can stand behind.
          </Text>
        </Card>
      ) : null}

      {/* Recommendation first in the decision view */}
      {hasFindings && view === 'decision' ? (
        <Card
          size="small"
          title={<Space><CheckCircleOutlined style={{ color: BRAND }} />Recommendation</Space>}
          style={{ marginBottom: SP.base, borderColor: BRAND }}
          extra={
            a.status === 'accepted' ? (
              <Tag color="green" style={{ marginInlineEnd: 0 }}>Accepted</Tag>
            ) : (
              <Button size="small" type="primary" disabled={!!a.question} onClick={() => accept(a.id, me)}>
                Accept
              </Button>
            )
          }
        >
          <Paragraph style={{ fontSize: 14.5, marginBottom: SP.sm }}>{a.recommendation}</Paragraph>
          <Text strong style={{ fontSize: 12.5 }}>Why</Text>
          <ul style={{ margin: `${SP.xs}px 0 0`, paddingLeft: 18, fontSize: 13 }}>
            {a.recommendationWhy.map((w) => <li key={w}>{w}</li>)}
          </ul>
          {a.question ? (
            <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: SP.sm }}>
              Draft until the open question above is answered.
            </Text>
          ) : null}
        </Card>
      ) : null}

      {/* Options */}
      {hasFindings ? (
        <>
          <Title level={5} style={{ marginBottom: SP.sm }}>Options, with the numbers</Title>
          <Row gutter={[SP.base, SP.base]} style={{ marginBottom: SP.xl }}>
            {a.options.map((o) => (
              <Col key={o.id} xs={24} lg={8}>
                <OptionCard o={o} chosen={!!o.recommended} />
              </Col>
            ))}
          </Row>
        </>
      ) : null}

      {/* Findings */}
      {hasFindings ? (
        <>
          <Title level={5} style={{ marginBottom: SP.sm }}>What the analyst found</Title>
          <Row gutter={[SP.base, SP.base]} style={{ marginBottom: SP.base }}>
            {a.findings.map((f, i) => (
              <Col key={f.id} xs={24} md={view === 'evidence' ? 24 : 12}>
                <Card size="small" style={{ height: '100%' }} styles={{ body: { padding: `${SP.base}px ${SP.lg}px` } }}>
                  <Text strong>
                    {i + 1}. {f.headline}
                  </Text>
                  <Paragraph style={{ fontSize: 13, margin: `${SP.sm}px 0 ${view === 'evidence' ? SP.sm : 0}px` }}>{f.detail}</Paragraph>
                  {view === 'evidence' ? (
                    <div style={{ borderTop: '1px solid #e9ecf1', paddingTop: SP.xs }}>
                      {f.evidence.map((e, j) => <EvidenceLine key={j} e={e} />)}
                    </div>
                  ) : (
                    <Text type="secondary" style={{ fontSize: 12 }}>
                      {f.evidence.length} source{f.evidence.length === 1 ? '' : 's'}
                      {f.evidence.some((e) => e.kind === 'assumption') ? ', one assumption' : ''} · open the evidence view to read them
                    </Text>
                  )}
                </Card>
              </Col>
            ))}
          </Row>
          <Card
            size="small"
            title={<Space><WarningOutlined style={{ color: STATUS.warn }} />What it could not establish</Space>}
            style={{ marginBottom: SP.xl }}
          >
            <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13 }}>
              {a.gaps.map((g) => <li key={g}>{g}</li>)}
            </ul>
          </Card>
        </>
      ) : null}

      {/* Your part */}
      <Card size="small" title="Your part" style={{ marginBottom: SP.base }}>
        <Space wrap>
          <Button onClick={() => setDrawer('add')}>Add information</Button>
          <Button onClick={() => setDrawer('challenge')} disabled={!hasFindings}>Challenge a finding</Button>
          {a.askRefs.length ? (
            <Button onClick={() => navigate(appPath('/ask'))}>Open the questions in Ask</Button>
          ) : null}
        </Space>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: SP.sm }}>
          Anything you add goes into the log with your name and reaches the analyst on its next step. Nothing here sends a message, changes a record or commits money.
        </Text>
      </Card>

      {/* Submissions */}
      {a.submissions.length ? (
        <Card size="small" title="Make a submission from these findings" style={{ marginBottom: SP.xl }}>
          <Row gutter={[SP.base, SP.base]}>
            {a.submissions.map((s) => (
              <Col key={s.label} xs={24} md={12}>
                <Flex justify="space-between" align="center" gap={SP.sm} style={{ border: '1px solid #e9ecf1', borderRadius: 8, padding: `${SP.md}px ${SP.base}px` }}>
                  <div>
                    <Text strong style={{ display: 'block' }}>{s.label}</Text>
                    <Text type="secondary" style={{ fontSize: 12.5 }}>To {s.audience} · {s.template}</Text>
                  </div>
                  <Button
                    type="primary"
                    ghost
                    onClick={() => {
                      addLog(a.id, me, `Opened AI Submissions to draft "${s.label}" from these findings.`)
                      navigate(appPath('/aisubmission'))
                    }}
                  >
                    Draft
                  </Button>
                </Flex>
              </Col>
            ))}
          </Row>
          <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: SP.sm }}>
            A draft carries the findings, their sources and the assumptions as stated here. It is a draft until you confirm it; sending it is not part of this product today.
          </Text>
        </Card>
      ) : null}

      {/* Log */}
      <Title level={5} style={{ marginBottom: SP.sm }}>How it got here</Title>
      <Timeline
        items={a.log.map((l) => ({
          color: l.who.startsWith('Context Weave') ? BRAND : l.who.startsWith('Rule') ? STATUS.warn : 'gray',
          children: (
            <div>
              <Text type="secondary" style={{ fontSize: 12 }}>{fmtDate(l.at)} · {l.who}</Text>
              <Text style={{ display: 'block', fontSize: 13 }}>{l.what}</Text>
            </div>
          ),
        }))}
      />

      <Drawer
        open={drawer !== null}
        onClose={() => setDrawer(null)}
        width={480}
        title={drawer === 'add' ? 'Add information' : drawer === 'challenge' ? 'Challenge a finding' : 'Answer the open question'}
        destroyOnHidden
      >
        {drawer === 'answer' ? <Alert type="warning" message={a.question} style={{ marginBottom: SP.base }} /> : null}
        <Input.TextArea
          rows={5}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder={
            drawer === 'add'
              ? 'e.g. The project office confirmed P-VM-061 rail grinding will not start before March 2027.'
              : drawer === 'challenge'
                ? 'e.g. Finding 2: the indexation figure should use the June index, not May.'
                : 'e.g. No, batch 3 results come on 8 October. Decide on 12 trams now.'
          }
          style={{ marginBottom: SP.base }}
        />
        <Button type="primary" onClick={submit} disabled={!note.trim()} block>
          {drawer === 'answer' ? 'Send answer' : 'Add to the analysis'}
        </Button>
      </Drawer>
    </>
  )
}

/* ------------------------------------------------------------------ route entry */

export default function AnalysisPage() {
  const { analysisId } = useParams()
  const analyses = useAnalysisStore((s) => s.analyses)
  const a = useMemo(() => analyses.find((x) => x.id === analysisId) ?? null, [analyses, analysisId])
  if (analysisId && !a) {
    return (
      <>
        <PageHeader title="Analysis" subtitle="That analysis does not exist in this copy." />
        <Button type="link" style={{ padding: 0 }} href={`#${appPath('/analysis')}`}>← All analyses</Button>
      </>
    )
  }
  return a ? <AnalysisDetail a={a} /> : <AnalysisList />
}
