import { ArrowUpOutlined, EditOutlined, LayoutOutlined, SaveOutlined, BellOutlined, CheckCircleOutlined, CheckOutlined, ClockCircleOutlined, CloseOutlined, GlobalOutlined, LoadingOutlined, PaperClipOutlined, PlusOutlined, ThunderboltOutlined, UserOutlined, WarningOutlined } from '@ant-design/icons'
import { Button, Drawer, Flex, Input, Tabs, Tag, Timeline, Tooltip, Typography } from 'antd'
import { Fragment, useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { create } from 'zustand'
import { appPath } from '../api/dataset'
import DataExplorer from '../components/goals/DataExplorer'
import { ApproachTab, DecisionTab, FindingsTab, GoalTab, SubmissionsTab } from '../components/goals/GoalWorkspace'
import { AgentBadge, Figure, fmtDate, TRIGGER_ICON } from '../components/goals/parts'
import '../components/goals/ChatPane.css'
import { downloadPack } from '../data/exportPack'
import { AGENT_POOL, GOALS, STATUS_LABEL, TRIGGER_LABEL, type Agent, type Drill, type Goal, type PlanStep, type Recommendation, type Trigger } from '../data/goalCases'
import { count, draftStep, extendStep, findingsSummary, helpText, interpret, rewordStep, shortHeadline, suggestions, type Tab } from '../data/goalChat'
import { describeRead, fileSize, readUpload } from '../data/readFile'
import { useAuthStore } from '../store/authStore'
import { exampleInput, useGoalStore, type ChatMsg, type GoalView } from '../store/goalStore'
import { useSubmissionStore } from '../store/submissionStore'
import { SP, STATUS } from '../theme'
import './GoalsPage.css'
import './SubmissionDoc.css'
import './SubmissionsHub.css'
import HubFrame, { AgentMark, Dock, JourneyBar, RailItem, RichText, RailSearch, RailSection, RailToggle, scrollToMsg, useDock, useFrame, useRailMatch, useSlashToSearch, useStickToBottom, type JStep } from './HubFrame'

const { Text } = Typography

/*
 * Goals, the same way as submissions: the conversation is always in the middle, and each step of the
 * journey is a small screen inside it. A new goal is briefed in five steps (what you want to know, how
 * it starts, the deadline, schedule or condition, what it is held against, check and create). Then the
 * agent proposes its approach, you change and approve it, it runs (now, on the schedule, or when the
 * rule fires), the findings come back to accept or challenge, then the decision, then what to send.
 * The panel on the right shows every goal, what is watching for you and your saved approaches, or the
 * open goal in full (goal, approach, findings, data, decision, submissions, log).
 */

type Stage = 'goal' | 'trigger' | 'when' | 'measure' | 'confirm'
interface Draft {
  goal?: string
  trigger?: Trigger
  when?: string
  conditionSource?: 'data' | 'external'
  measure?: string
  target?: string
  agentName?: string
  approachId?: string
  exampleOf?: string
  scope?: string
  constraints?: string
  files?: { name: string; size: number; read: string; problem?: string }[]
}
const BRIEF: { key: Stage; card: string }[] = [
  { key: 'goal', card: 'b-goal' }, { key: 'trigger', card: 'b-trigger' }, { key: 'when', card: 'b-when' }, { key: 'measure', card: 'b-measure' }, { key: 'confirm', card: 'b-check' },
]
const briefLabel = (card: string, t?: Trigger) => ({ 'b-goal': 'What you want to know', 'b-trigger': 'How it starts', 'b-when': t === 'rule' ? 'The condition' : t === 'schedule' ? 'The schedule' : 'The deadline', 'b-measure': 'What it is held against', 'b-check': 'Check and create' } as Record<string, string>)[card]
const WORK_LABEL: Record<string, string> = { run: 'Running the approach', approach: 'Approach', armed: 'Waiting for its trigger', findings: 'Findings', question: 'One question for you', decision: 'Decision', send: 'What to send' }
const STARTS: Record<Trigger, string> = { person: 'Now, by you', schedule: 'On a schedule', rule: 'When a rule fires' }
const EX_RULE = 'Example: over-budget project (rule)'
const EX_SCHED = 'Example: quarterly committee pack (schedule)'
const shortRec = (r: Recommendation) => (r.title.split(/[;:,]\s/)[0] ?? r.title)

let seq = 0
const m = (who: ChatMsg['who'], text: string, extra: Partial<ChatMsg> = {}): ChatMsg => ({ id: `gh${(seq += 1)}-${Date.now().toString(36)}`, at: new Date().toISOString(), who, text, ...extra })

interface Brief { msgs: ChatMsg[]; draft: Draft; stage: Stage; lastField: string; at: number }
interface GHub {
  /** The chat on screen: "brief-…" (a goal being briefed) or a goal id. */
  current: string
  /** Briefs you left before creating the goal: they stay in Drafts, to pick up again. */
  briefs: Record<string, Brief>
  newMsgs: ChatMsg[]
  draft: Draft
  stage: Stage
  typing: boolean
  lastField: string
  fresh?: string
  /** A "change" from the check step: once answered, go straight back to the check. */
  editing?: boolean
  set: (p: Partial<Omit<GHub, 'set'>>) => void
}
const useGH = create<GHub>((set) => ({ current: 'brief-0', briefs: {}, newMsgs: [], draft: {}, stage: 'goal', typing: false, lastField: '', set: (p) => set(p) }))
const gh = useGH.getState
const isBrief = (k: string) => k.startsWith('brief-')
const begun = (msgs: ChatMsg[], d: Draft) => msgs.some((x) => x.who === 'me') || !!d.approachId
/** Show another chat. A brief you leave is kept in Drafts if you had started it. */
const switchTo = (key: string) => {
  const st = gh()
  if (st.current === key) return
  const briefs = { ...st.briefs }
  if (isBrief(st.current)) {
    if (begun(st.newMsgs, st.draft)) briefs[st.current] = { msgs: st.newMsgs, draft: st.draft, stage: st.stage, lastField: st.lastField, at: Date.now() }
    else delete briefs[st.current]
  }
  const b = isBrief(key) ? briefs[key] : undefined
  if (b) delete briefs[key]
  st.set({ briefs, current: key, typing: false, ...(isBrief(key) ? { newMsgs: b?.msgs ?? [], draft: b?.draft ?? {}, stage: b?.stage ?? 'goal', lastField: b?.lastField ?? '' } : {}) })
}


export default function GoalsHub({ routeId }: { routeId?: string }) {
  const navigate = useNavigate()
  const location = useLocation()
  const me = useAuthStore((s) => s.identity?.name) ?? 'You'
  const { goals, approaches, watchers, chats, views, typing: gTyping, start, setView } = useGoalStore()
  const { current, briefs, newMsgs, draft, stage, typing: nTyping, lastField, fresh } = useGH()
  const templates = useSubmissionStore((s) => s.templates)
  const startSubmission = useSubmissionStore((s) => s.startFromGoal)
  const g = isBrief(current) ? null : goals.find((x) => x.id === current) ?? null
  const v: GoalView = (g && views[g.id]) || { tab: 'approach' }
  const nextAgent = useMemo(() => AGENT_POOL.find((a) => !goals.some((x) => x.agent.name === a.name)) ?? AGENT_POOL[goals.length % AGENT_POOL.length], [goals])
  const newAgent: Agent = { ...nextAgent, name: draft.agentName ? (/^agent\b/i.test(draft.agentName) ? draft.agentName : `Agent ${draft.agentName}`) : nextAgent.name }
  const agent = g?.agent ?? newAgent
  const msgs = g ? chats[g.id] ?? [] : newMsgs
  const typing = g ? !!gTyping[g.id] : nTyping

  const [text, setText] = useState('')
  const [panelOpen, setPanelOpen] = useState(true)
  const [drawer, setDrawer] = useState<Drill | null>(null)
  const [addStep, setAddStep] = useState('')
  const endRef = useRef<HTMLDivElement>(null)
  /** An agent message right after another agent message continues the same turn: no second avatar. */
  const cont = (mm: { id: string }) => { const i = msgs.findIndex((y) => y.id === mm.id); return i > 0 && msgs[i - 1].who === 'agent' }
  const feedRef = useRef<HTMLDivElement>(null)
  useStickToBottom(feedRef)
  useSlashToSearch()
  const dock = useDock(feedRef, [msgs.length, current, g?.status, typing])
  /* Coming back to something half done: one quiet line saying where you are and what is next. Gone once you act. */
  const [resume, setResume] = useState<string | null>(null)
  const seenLen = useRef(0)
  useEffect(() => { setResume(msgs.length ? current : null); seenLen.current = msgs.length }, [current]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (resume && msgs.length !== seenLen.current) setResume(null) }, [msgs.length]) // eslint-disable-line react-hooks/exhaustive-deps
  const startedSubs = useSubmissionStore((s) => s.submissions)
  const fileRef = useRef<HTMLInputElement>(null)
  const pending = useRef<null | { k: 'challenge'; id: string; n: number }>(null)
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end', behavior: 'smooth' })
    /* Cards grow as they render; settle at the bottom once they have. */
    const t = window.setTimeout(() => endRef.current?.scrollIntoView({ block: 'end', behavior: 'smooth' }), 320)
    return () => window.clearTimeout(t)
  }, [msgs.length, typing, current])

  /* ---------------- the new-goal brief */
  const nsay = (t: string) => gh().set({ newMsgs: [...gh().newMsgs, m('agent', t)] })
  const ncard = (card: string) => gh().set({ newMsgs: [...gh().newMsgs, m('agent', '', { card })] })
  const whenQuestion = (t?: Trigger) => (t === 'rule' ? 'What is the condition, and where do I check it: in our data at every snapshot, or on the internet every morning?' : t === 'schedule' ? 'When should it run?' : 'Is there a deadline?')
  const askFor = (st: Stage, d: Draft) => (st === 'goal' ? 'What do you want to know or achieve? Say it in plain words.' : st === 'trigger' ? 'How should it start: now, by you; on a schedule; or when a rule fires?' : st === 'when' ? whenQuestion(d.trigger) : st === 'measure' ? 'What do I hold it against? A measure and a target, or say "you decide".' : 'Check it, then say "create it".')
  const summary = (d: Draft) => `Here is the goal. I am ${newAgent.name}. ${d.trigger === 'rule' ? 'Once it is created I propose my approach; you approve and save it, and it runs by itself when the rule fires.' : d.trigger === 'schedule' ? 'Once it is created I propose my approach; after you approve it, it runs by itself on the schedule.' : 'Once it is created I propose my approach and start when you approve it.'}\n\nIf it looks right, say "create it". Change anything with its "change" link, or give me another name in the card.`

  const greet = () => {
    gh().set({ newMsgs: [], draft: {}, stage: 'goal', lastField: '' })
    nsay('What do you want to find out? Describe it the way you would brief an analyst, or start from one below.')
    ncard('b-goal')
  }
  /* A fresh brief. The one you were on stays in Drafts if you had started it. */
  const newGoal = (approachId?: string) => {
    switchTo(`brief-${Date.now().toString(36)}`)
    setText(''); setPanelOpen(true)
    greet()
    if (approachId) { const a = approaches.find((x) => x.id === approachId); if (a) pickApproach(a) }
    if (routeId) navigate(appPath('/goals'))
  }
  /* Starting from a saved approach: it becomes the agent's approach, and the brief carries on from the goal. */
  const pickApproach = (a: (typeof approaches)[number]) => {
    gh().set({ newMsgs: [...gh().newMsgs, m('me', `Start from my saved approach "${a.name}"`)], typing: true })
    window.setTimeout(() => {
      gh().set({ typing: false, draft: { ...gh().draft, approachId: a.id, scope: a.scope.join('\n'), constraints: a.constraints.join('\n') }, lastField: 'approach' })
      nsay(`Good. **${a.name}** is ${count(a.plan.length)} steps, saved from "${a.fromGoal}". I use it as my approach, and you can still change it before I start.\n\nWhat should it work on this time? Say the goal in plain words.`)
      ncard('b-goal')
    }, 500)
  }

  const create = (d: Draft) => {
    const id = start({
      goal: d.goal!, measure: d.measure ?? 'Read from the goal', target: d.target ?? 'Set out in the findings', scope: d.scope ?? '', constraints: d.constraints ?? '',
      trigger: d.trigger ?? 'person', when: d.when ?? '', owner: me, approachId: d.approachId, exampleOf: d.exampleOf, agentName: d.agentName, conditionSource: d.conditionSource, files: d.files,
      chat: [...gh().newMsgs, m('agent', 'Created. Drafting my approach now.')],
    })
    const briefs = { ...gh().briefs }
    delete briefs[gh().current]
    gh().set({ briefs, current: id, newMsgs: [], draft: {}, stage: 'goal' })
    navigate(appPath(`/goals/${id}`))
  }

  const afterGoal = (next: Draft, t: string): { st: Stage; out: string } => {
    const rule = /\b(whenever|as soon as|every time|if any|when any|when a|when an|alert me)\b/.test(t)
    const sched = /\b(each|every (week|month|quarter|monday|tuesday|wednesday|thursday|friday|day|morning)|weekly|monthly|quarterly)\b/.test(t)
    if (rule || sched) { next.trigger = rule ? 'rule' : 'schedule'; return { st: 'when', out: `Sounds like ${rule ? 'a rule: it starts when something happens' : 'a schedule: it runs by itself'}. ${whenQuestion(next.trigger)}` } }
    return { st: 'trigger', out: askFor('trigger', next) }
  }

  const briefAct = (raw: string) => {
    const t = raw.toLowerCase().trim()
    const d = gh().draft
    const s = gh().stage
    let next: Draft = { ...d }
    let st = s
    let out = ''
    let lf = gh().lastField
    let mm: RegExpMatchArray | null
    let isChange = false
    const STAGE_WORDS: [RegExp, Stage][] = [[/goal|question|problem/, 'goal'], [/start|trigger/, 'trigger'], [/condition|schedule|deadline|when/, 'when'], [/measure|target/, 'measure']]
    if (raw === EX_RULE || raw === EX_SCHED || /^example\b/.test(t)) {
      const ex = GOALS.find((x) => x.trigger === (raw === EX_RULE || /rule|budget/.test(t) ? 'rule' : 'schedule'))!
      const val = exampleInput(ex, me)
      next = { ...next, goal: val.goal, measure: val.measure, target: val.target, scope: val.scope, constraints: val.constraints, trigger: val.trigger, when: val.when, conditionSource: val.conditionSource, exampleOf: ex.id, approachId: undefined }
      lf = 'all'; st = 'confirm'; out = summary(next)
    } else if ((mm = raw.match(/(?:call|name|rename)\s+(?:the agent|it|you|yourself|agent)\s+(?:agent\s+)?(.+)$/i))) {
      next.agentName = mm[1].trim().replace(/[.!]$/, '')
      lf = 'agent'
      out = `${/^agent\b/i.test(next.agentName) ? next.agentName : `Agent ${next.agentName}`} it is.${st === 'confirm' ? ' Say "create it" when ready.' : ''}`
    } else if ((mm = t.match(/^(?:change|edit|back to|go back to)\s+(?:the\s+|how it\s+)?(goal|question|problem|starts?|trigger|condition|schedule|deadline|when|measure|target)\b/)) && (d.goal || /goal/.test(mm[1]))) {
      st = STAGE_WORDS.find(([re]) => re.test(mm![1]))![1]
      if (st === 'when' && !next.trigger) st = 'trigger'
      out = askFor(st, next)
      isChange = true
      gh().set({ editing: !!(next.goal && next.trigger && next.measure) })
    } else if (d.goal && (mm = t.match(/make it (?:a |an )?(rule|schedule|scheduled|now|one-off|manual)/))) {
      next.trigger = /rule/.test(mm[1]) ? 'rule' : /sched/.test(mm[1]) ? 'schedule' : 'person'
      next.when = undefined
      lf = 'trigger'; st = 'when'; out = whenQuestion(next.trigger)
    } else if (s === 'confirm' && (mm = raw.match(/^deadline\s+(.+)$/i))) {
      next.when = mm[1]; lf = 'when'; out = 'Deadline set. Say "create it" when ready.'
    } else if (s === 'confirm' && /\b(create|yes|go|looks good|do it|ok|okay|confirm|make it)\b/.test(t)) {
      create(next)
      return
    } else if (s === 'goal') {
      if (t.length < 8) { nsay(d.approachId ? 'What should the approach work on this time? Name the project or question, e.g. "Depot lifts renewal is late: what does it cost us?"' : 'Say a little more: what you want to know or achieve. Or pick an example.'); return }
      next.goal = raw.trim(); lf = 'goal'
      const r = gh().editing ? { st: 'trigger' as Stage, out: '' } : afterGoal(next, t); st = r.st; out = r.out
    } else if (s === 'trigger') {
      const tr: Trigger | undefined = /\b(rule|condition|fires|when|whenever|alert)\b/.test(t) ? 'rule' : /\b(schedule|scheduled|each|every|weekly|monthly|quarterly|regular)\b/.test(t) ? 'schedule' : /\b(now|me|by you|by me|once|manual|today)\b/.test(t) ? 'person' : undefined
      if (!tr) out = 'Now, on a schedule, or when a rule fires?'
      else { next.trigger = tr; next.when = undefined; lf = 'trigger'; st = 'when'; out = whenQuestion(tr) }
    } else if (s === 'when') {
      if (next.trigger === 'rule') {
        const ext = /^on the internet\b|\b(internet|tariff|news|index|indices|market price|announces?)\b/.test(t)
        next.conditionSource = ext ? 'external' : /^in our data\b/.test(t) || !next.conditionSource ? 'data' : next.conditionSource
        const cond = raw.replace(/^(in our data|on the internet)\s*[:,-]?\s*/i, '').trim()
        if (cond.length < 6) { lf = 'source'; out = `I check it ${next.conditionSource === 'external' ? 'on the internet, every morning' : 'in our data, at every snapshot'}. What is the condition?` }
        else { next.when = cond.charAt(0).toUpperCase() + cond.slice(1); lf = 'when'; st = 'measure' }
      } else if (next.trigger === 'person') {
        next.when = /^(no|none|no deadline|not really|nope)\b/.test(t) ? '' : raw.replace(/^yes,?\s*/i, '')
        lf = 'when'; st = 'measure'
      } else { next.when = raw; lf = 'when'; st = 'measure' }
      if (st === 'measure') out = 'What do I hold it against? A measure and a target, e.g. "forecast against approved budget, within 10%". Or say "you decide".'
    } else if (s === 'measure') {
      if (/^(continue|next|done|ok|okay|that'?s it)$/.test(t) && next.measure) { /* typed into the card */ }
      else if (/\b(you decide|up to you|no idea|not sure|skip)\b/.test(t)) { next.measure = 'Read from the goal'; next.target = 'Set out in the findings' }
      else {
        const parts = raw.split(/,\s*|\s+(?=within\b|under\b|below\b|at or under\b)/i)
        next.measure = parts[0].trim().replace(/^./, (c) => c.toUpperCase())
        next.target = parts.slice(1).join(' ').trim() || 'As stated'
      }
      lf = 'measure'; st = 'confirm'; out = summary(next)
    } else out = 'Say "create it", or tell me what to change.'
    /* Answering a change: once nothing is missing, straight back to the check. */
    if (!isChange && gh().editing && st !== 'confirm' && st !== s && next.goal && next.trigger && next.when !== undefined && next.measure) { st = 'confirm'; out = `Changed. ${summary(next)}` }
    if (st === 'confirm') gh().set({ editing: false })
    const moved = st !== s || lf === 'all'
    gh().set({ draft: next, stage: st, lastField: lf })
    nsay(out)
    if (moved) ncard(BRIEF.find((b) => b.key === st)!.card)
  }

  const briefUpload = async (file: File) => {
    gh().set({ newMsgs: [...gh().newMsgs, m('me', 'Here is the problem statement.', { file: { name: file.name, size: file.size } })], typing: true })
    const r = await readUpload(file)
    window.setTimeout(() => {
      const d = gh().draft
      const next: Draft = { ...d, files: [...(d.files ?? []).filter((f) => f.name !== r.name), { name: r.name, size: r.size, read: describeRead(r), problem: r.problem }] }
      let st = gh().stage
      let out = `Read ${r.name}: ${describeRead(r)}.`
      if (!d.goal && r.problem) {
        next.goal = r.problem
        const a = afterGoal(next, r.problem.toLowerCase())
        st = a.st
        out += `\n\nThe problem it states: "${r.problem}"\n\nI have taken that as the goal. If it is not quite right, say it in your own words.\n\n${a.out}`
      } else if (!d.goal) out += `\n\nI could not find a problem statement in it, so I keep it as background. ${askFor('goal', next)}`
      else out += `${r.problem ? `\n\nIt says: "${r.problem}"` : ''}\n\nI keep it with the goal as background and read it on every run. ${askFor(st, next)}`
      const moved = st !== gh().stage
      gh().set({ typing: false, draft: next, stage: st, lastField: next.goal !== d.goal ? 'goal' : 'files' })
      nsay(out)
      if (moved) ncard(BRIEF.find((b) => b.key === st)!.card)
    }, 900)
  }

  /* Light up a goal in the list on the left (opening the list over the conversation if it had stepped aside). */
  const revealInList = (id: string) => {
    const f = useFrame.getState()
    if (f.tight) { f.set({ peek: true }); window.setTimeout(() => useFrame.getState().set({ peek: false }), 3200) } else f.set({ railOpen: true })
    gh().set({ fresh: id })
    window.setTimeout(() => gh().set({ fresh: undefined }), 2800)
  }

  /* ---------------- a goal's conversation */
  const goalAct = (id: string, raw: string) => {
    const st = useGoalStore.getState()
    const g0 = st.goals.find((x) => x.id === id)
    if (!g0) return
    const vv = st.views[id] ?? { tab: 'approach' as Tab }
    const say = (t: string) => st.say(id, 'agent', t)
    const post = (c: string) => useGoalStore.getState().post(id, c)
    const show = (x: GoalView) => { st.setView(id, x); setPanelOpen(true) }
    const live = g0.plan.filter((s) => s.state !== 'removed')
    const removed = g0.plan.filter((s) => s.state === 'removed')
    const planOpen = g0.status === 'plan-review'
    const findingNo = (fid?: string) => g0.findings.findIndex((f) => f.id === fid) + 1
    const pref = Math.max(0, g0.recommendations.findIndex((r) => r.preferred)) + 1
    const offered = g0.submissions.filter((s) => useSubmissionStore.getState().templates.some((t) => t.id === s.templateId))

    if (pending.current?.k === 'challenge' && pending.current.id === id) {
      const n = pending.current.n
      pending.current = null
      st.addLog(id, me, `Challenged finding ${n}: ${raw}`)
      say(`Noted against finding ${n}. I recheck it on the next run; it stays open until you accept it.`)
      return
    }
    /* "Run it again" on a scheduled goal that has already run: the next run, now. */
    if (g0.trigger === 'schedule' && g0.status !== 'armed' && g0.status !== 'analysing' && /\b(simulate|run (it )?(now|again)|re-?run)\b/i.test(raw)) {
      st.rearm(id)
      useGoalStore.getState().fire(id, me)
      show({ tab: 'approach' })
      return
    }
    const intent = interpret(raw, g0, vv.tab)
    const lockedEdit = () => say(g0.status === 'analysing' ? 'I am running the approach now. Changes wait until the findings land.' : 'The approach is approved and locked. Say "change the approach" to reopen it.')
    /* A change to the approach: the card comes back under the reply, so the live one is always at the bottom. */
    const commit = (plan: PlanStep[], focus?: string) => { st.setPlan(id, plan, me); show({ tab: 'approach', step: focus }); queueMicrotask(() => post('approach')) }

    switch (intent.k) {
      case 'help': say(helpText(g0)); return
      case 'approve':
        if (!live.length) { say('Every step is removed. Put one back first.'); return }
        st.approvePlan(id, me)
        /* A rule now waits under "Watching for you" in the list on the left; it lights up there. */
        if (g0.trigger !== 'person') window.setTimeout(() => revealInList(id), 900)
        show({ tab: 'approach' })
        return
      case 'remove': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}. The approach has ${count(live.length)}.`); return }
        commit(g0.plan.map((x) => (x.id === s.id ? { ...x, state: 'removed', editedBy: me } : x)), s.id)
        say(`Removed: ${s.title}. Say "put back step ${intent.n}" if you change your mind.`)
        return
      }
      case 'restore': {
        if (!planOpen) return lockedEdit()
        const cand = g0.plan[intent.n - 1]?.state === 'removed' ? g0.plan[intent.n - 1] : removed[removed.length - 1]
        if (!cand) { say('Nothing is removed.'); return }
        commit(g0.plan.map((x) => (x.id === cand.id ? { ...x, state: 'pending', editedBy: me } : x)), cand.id)
        say(`Put back: ${cand.title}.`)
        return
      }
      case 'move': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        const to = Math.max(1, Math.min(live.length, intent.to))
        if (!s) { say(`There is no step ${intent.n}.`); return }
        const order = live.filter((x) => x.id !== s.id)
        order.splice(to - 1, 0, s)
        commit([...order, ...removed], s.id)
        say(`Moved. "${s.title}" is now step ${to}.`)
        return
      }
      case 'add': {
        if (!planOpen) return lockedEdit()
        const step = draftStep(intent.text, me)
        const at = intent.after ? Math.min(live.length, intent.after) : live.length
        const order = [...live]
        order.splice(at, 0, step)
        commit([...order, ...removed], step.id)
        say(`Added as step ${at + 1}: **${step.title}**\nReads ${step.sources.join(', ')}. Done when: ${step.check.charAt(0).toLowerCase()}${step.check.slice(1)}${at + 1 < order.length ? '' : `\n\nWant it earlier? Say "move step ${at + 1} up".`}`)
        return
      }
      case 'change': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}.`); return }
        const nx = rewordStep(s, intent.text, me)
        commit(g0.plan.map((x) => (x.id === s.id ? nx : x)), s.id)
        say(`Step ${intent.n} now reads: **${nx.title}**\nReads ${nx.sources.join(', ')}.`)
        return
      }
      case 'extend': {
        if (!planOpen) return lockedEdit()
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}.`); return }
        const nx = extendStep(s, intent.text, me)
        commit(g0.plan.map((x) => (x.id === s.id ? nx : x)), s.id)
        say(`Step ${intent.n} now covers that too. Sources: ${nx.sources.join(', ')}.`)
        return
      }
      case 'explain': {
        const s = live[intent.n - 1]
        if (!s) { say(`There is no step ${intent.n}.`); return }
        show({ tab: 'approach', step: s.id })
        say(`Step ${intent.n} is open on the right. In short: ${s.how.split('. ')[0].replace(/\.$/, '')}.`)
        return
      }
      case 'save': {
        if (!g0.plan.length) { say('Nothing to save yet.'); return }
        const name = intent.name?.trim() || g0.approachName || (g0.title.length > 48 ? `${g0.title.slice(0, 46)}…` : g0.title)
        st.saveApproach(id, name, me)
        say(`Saved to your approaches as "${name}". A new goal can start from it; they are on the right under Saved approaches.`)
        return
      }
      case 'revise':
        if (g0.status === 'analysing') { say('I am running it now. Wait for the findings, then reopen it.'); return }
        st.revisePlan(id, me)
        setPanelOpen(true)
        return
      case 'fire':
        st.fire(id, 'Agent')
        show({ tab: 'approach' })
        return
      case 'status': {
        if (g0.status === 'analysing') {
          const i = live.findIndex((s) => s.state === 'running')
          const s = live[i]
          const last = s?.trace?.[s.trace.length - 1]
          show({ tab: 'approach', step: s?.id })
          say(s ? `Step ${i + 1} of ${live.length}: ${s.title}.${last ? `\nLast: ${last.split(' → ')[0]}.` : ''}` : 'Finishing up.')
          return
        }
        say(g0.status === 'plan-review' ? 'Waiting for your go on the approach.' : g0.status === 'armed' ? `Armed. ${g0.trigger === 'rule' ? 'Waiting for the rule to fire.' : 'Waiting for the next scheduled run.'}` : `${STATUS_LABEL[g0.status]}. ${g0.target.current}.`)
        return
      }
      case 'summary':
        if (!g0.findings.length) { say('No findings yet.'); return }
        show({ tab: 'findings', finding: vv.finding })
        say(findingsSummary(g0))
        post('findings')
        return
      case 'finding': {
        const f = g0.findings[intent.n - 1]
        if (!f) { say(`There are ${count(g0.findings.length)} findings.`); return }
        show({ tab: 'findings', finding: f.id })
        say(`Finding ${intent.n} is open on the right, with ${count(f.evidence.length)} pieces of evidence. Say "show the data" for the rows behind it, or "accept ${intent.n}".`)
        return
      }
      case 'drill': {
        const n = intent.n ?? (findingNo(vv.finding) || 1)
        const f = g0.findings[n - 1]
        if (!f) { show({ tab: 'data' }); say('The worksheet is on the right.'); return }
        show({ tab: 'data', drill: f.drill, finding: f.id })
        say(`The data behind finding ${n} is on the right. ${f.drill.note}`)
        return
      }
      case 'accept': {
        const ids = intent.ns === 'all' ? g0.findings.map((f) => f.id) : intent.ns.map((n) => g0.findings[n - 1]?.id).filter(Boolean) as string[]
        if (!ids.length) { say('Which finding? Say "accept 2" or "accept all".'); return }
        st.acceptFindings(id, ids, me)
        const now = new Set([...(g0.acceptedFindings ?? []), ...ids])
        const all = now.size === g0.findings.length
        const nextOpen = g0.findings.findIndex((f) => !now.has(f.id)) + 1
        if (all) {
          say(`${intent.ns === 'all' ? 'All findings' : `Finding${ids.length > 1 ? 's' : ''} ${ids.map(findingNo).join(' and ')}`} accepted${intent.ns !== 'all' ? '; that is all of them' : ''}.\n\nNext, the decision: ${count(g0.recommendations.length)} ways forward, and I prefer option ${pref}. Or open the data behind the findings first.`)
          if (g0.recommendations.length) { post('decision'); show({ tab: 'decision' }) }
        } else say(`Finding${ids.length > 1 ? 's' : ''} ${ids.map(findingNo).join(' and ')} accepted. Next: finding ${nextOpen}, or accept the rest.`)
        return
      }
      case 'challenge':
        if (!g0.findings[intent.n - 1]) { say(`There is no finding ${intent.n}.`); return }
        show({ tab: 'findings', finding: g0.findings[intent.n - 1].id })
        if (!intent.text.trim()) { pending.current = { k: 'challenge', id, n: intent.n }; say(`What is wrong with finding ${intent.n}? One sentence is enough.`); return }
        st.addLog(id, me, `Challenged finding ${intent.n}: ${intent.text}`)
        say(`Noted against finding ${intent.n}. I recheck it on the next run; it stays open until you accept it.`)
        return
      case 'recs':
        if (!g0.recommendations.length) { say('No recommendations yet.'); return }
        show({ tab: 'decision' })
        say(`${count(g0.recommendations.length).replace(/^./, (c) => c.toUpperCase())} ways forward:\n${g0.recommendations.map((r, i) => `${i + 1}. ${shortRec(r)}`).join('\n')}\n\nI prefer option ${pref}. "Why this" plays how I got there, on the right.`)
        post('decision')
        return
      case 'why': {
        const n = intent.n && g0.recommendations[intent.n - 1] ? intent.n : pref
        const r = g0.recommendations[n - 1]
        if (!r) { say('No recommendations yet.'); return }
        show({ tab: 'decision', story: r.id })
        say(`Playing how I got to option ${n} on the right: what I asked, read, found and compared.`)
        return
      }
      case 'choose': {
        if (g0.question) { say(`Answer my question first: ${g0.question}`); return }
        const n = intent.n && g0.recommendations[intent.n - 1] ? intent.n : pref
        const r = g0.recommendations[n - 1]
        if (!r) { say('No recommendations yet.'); return }
        st.choose(id, r.id, me)
        show({ tab: 'decision', story: vv.story })
        say(`Recorded: option ${n}. ${offered.length ? `Next, what to send: I can draft ${count(offered.length)} submission${offered.length === 1 ? '' : 's'} from your templates, or you describe a new one.` : 'Describe a new output if something should go out.'}`)
        post('send')
        return
      }
      case 'subs':
        if (!g0.findings.length) { say('Submissions come once the findings are in.'); return }
        show({ tab: 'submissions' })
        say(offered.length ? 'Based on the templates in your library. Start one, or describe a new output if none fits.' : 'None of your templates fits this goal. Describe a new output and I propose a structure.')
        post('send')
        return
      case 'startSub': {
        if (!offered.length) { say('No template in your library fits. Say "describe a new output".'); return }
        const words = (intent.words ?? '').toLowerCase().split(/\W+/).filter((w) => w.length > 3)
        const byWords = words.length ? offered.map((s) => ({ s, score: words.filter((w) => s.label.toLowerCase().includes(w)).length })).sort((a, b) => b.score - a.score)[0] : undefined
        const s = intent.n ? offered[intent.n - 1] : byWords?.score ? byWords.s : offered[0]
        if (!s) { say(`There ${offered.length === 1 ? 'is one' : `are ${count(offered.length)}`} to choose from.`); return }
        const sid = startSubmission(g0, s, me)
        st.addLog(id, me, `Started the submission "${s.label}" from ${g0.agent.name}'s recommendation.`)
        say(`Opening "${s.label}" in Submissions, with this goal attached. It is in its own chat there, at its first step.`)
        window.setTimeout(() => navigate(appPath(`/submissions/${sid}`)), 900)
        return
      }
      case 'describe':
        say('Opening Submissions to describe a new output for this goal.')
        window.setTimeout(() => navigate(appPath('/submissions/new'), { state: { newFromGoal: g0.id, describe: true } }), 900)
        return
      case 'pack':
        downloadPack(g0, STATUS_LABEL[g0.status], TRIGGER_LABEL[g0.trigger])
        st.addLog(id, me, 'Downloaded the analysis pack.')
        say('Downloaded the analysis pack: one HTML file with the findings, the evidence and the tables behind them.')
        return
      case 'info':
        st.addLog(id, me, `Added information: ${intent.text}`)
        say('Added to the goal. I use it on the next run.')
        return
      case 'tab':
        show({ tab: intent.tab })
        say('On the right.')
        return
      default:
        if (g0.question) {
          st.answer(id, me, raw)
          if (g0.findings.length) { say(`Thanks. The recommendation stands with your answer taken into account. Next, the decision: I prefer option ${pref}.`); post('decision'); show({ tab: 'decision' }) }
          else say('Thanks, noted. This goal has no recorded analysis behind it in this copy, so there are no findings to write. The two example goals carry full ones.')
          return
        }
        if (g0.status === 'analysing') { say('I am running the approach. Ask "where are you?", or wait for the findings.'); return }
        say(`I did not catch that. ${helpText(g0)}`)
    }
  }

  const goalUpload = async (id: string, file: File) => {
    const st = useGoalStore.getState()
    st.say(id, 'me', 'Here is a file for this goal.', { name: file.name, size: file.size })
    st.setTyping(id, true)
    const r = await readUpload(file)
    window.setTimeout(() => {
      const s2 = useGoalStore.getState()
      s2.setTyping(id, false)
      s2.attach(id, { name: r.name, size: r.size, read: describeRead(r), problem: r.problem }, me)
      s2.setView(id, { tab: 'target' })
      s2.say(id, 'agent', `Read ${r.name}: ${describeRead(r)}.${r.problem ? `\n\nWhat it says: "${r.problem}"` : ''}\n\nIt is on the Goal tab on the right, and I read it on every run from now on. Anything in it I should treat as fixed?`)
    }, 900)
  }

  const send = (t0: string) => {
    const t = t0.trim()
    if (!t) return
    setText('')
    if (/^(new (chat|goal)|start (a )?new( goal| chat)?)$/i.test(t)) { newGoal(); return }
    if (!g) {
      gh().set({ newMsgs: [...gh().newMsgs, m('me', t)], typing: true })
      window.setTimeout(() => { gh().set({ typing: false }); briefAct(t) }, 420 + Math.random() * 320)
      return
    }
    const id = g.id
    const st = useGoalStore.getState()
    st.say(id, 'me', t)
    st.setTyping(id, true)
    window.setTimeout(() => { useGoalStore.getState().setTyping(id, false); goalAct(id, t) }, 420 + Math.random() * 380)
  }
  const upload = (f: File) => (g ? void goalUpload(g.id, f) : void briefUpload(f))

  /* ---------------- arriving: the menu, a goal's link, a notice, "new goal from this approach" */
  const arrived = useRef('')
  useEffect(() => {
    const key = `${location.key}|${routeId ?? ''}`
    if (arrived.current === key) return
    arrived.current = key
    const st = (location.state as { approachId?: string } | null) ?? null
    if (routeId === 'new') { newGoal(st?.approachId); return }
    if (routeId) {
      if (!useGoalStore.getState().goals.some((x) => x.id === routeId)) return
      switchTo(routeId)
      setPanelOpen(true)
      return
    }
    /* From the menu: the chat you were in stays in the middle; every goal is in the list on the left. */
    setPanelOpen(true)
    if (isBrief(gh().current) && !gh().newMsgs.length) greet()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.key, routeId])

  /* ---------------- the cards inside the conversation */
  const lastOf = (card: string) => { for (let i = msgs.length - 1; i >= 0; i -= 1) if (msgs[i].card === card) return msgs[i].id; return null }
  const lastBrief = () => { for (let i = msgs.length - 1; i >= 0; i -= 1) if (msgs[i].card?.startsWith('b-')) return msgs[i].id; return null }
  const Head = ({ label, sub, done, onChange, icon }: { label: string; sub?: string; done?: boolean; onChange?: () => void; icon?: React.ReactNode }) => (
    <div className="hc-head">
      <span className={`sd-step-n${done ? ' is-done' : ''}`}>{done ? <CheckOutlined /> : icon}</span>
      <b>{label}</b>
      {sub ? <span className="hc-of">{sub}</span> : null}
      {onChange ? <a onClick={onChange}>change</a> : null}
    </div>
  )
  const changeWord: Record<string, string> = { 'b-goal': 'Change the goal', 'b-trigger': 'Change how it starts', 'b-when': 'Change the condition', 'b-measure': 'Change the measure' }

  const renderBrief = (msg: ChatMsg) => {
    const c = msg.card!
    const i = BRIEF.findIndex((b) => b.card === c)
    const sub = `Step ${i + 1} of 5`
    /* In a goal's own chat the brief is history: one line per step, from the goal itself. */
    if (g) {
      const sum = c === 'b-goal' ? g.goal : c === 'b-trigger' ? STARTS[g.trigger] : c === 'b-when' ? g.triggerDetail : c === 'b-measure' ? `${g.target.measure} · ${g.target.target}` : `Created · ${g.agent.name}`
      return <div className="hc hc-folded"><Head label={briefLabel(c, g.trigger)} done /><span className="hc-sum">{sum}</span></div>
    }
    const live = lastBrief() === msg.id && BRIEF[i].key === stage
    if (!live) {
      const sum = c === 'b-goal' ? draft.goal ?? (draft.approachId ? 'A saved approach' : '…') : c === 'b-trigger' ? (draft.trigger ? STARTS[draft.trigger] : '…') : c === 'b-when' ? (draft.when === '' ? 'None' : draft.when ?? '…') : c === 'b-measure' ? `${draft.measure ?? '…'} · ${draft.target ?? '…'}` : 'Created'
      return <div className="hc hc-folded"><Head label={briefLabel(c, draft.trigger)} done onChange={changeWord[c] ? () => send(changeWord[c]) : undefined} /><span className="hc-sum">{sum}</span></div>
    }
    const ex = (tr: Trigger) => GOALS.find((x) => x.trigger === tr)!
    const apNow = approaches.find((a) => a.id === draft.approachId)
    if (c === 'b-goal' && apNow) return (
      <div className="hc"><Head label="What you want to know" sub={sub} icon={1} />
        <div className="sd-current">
          <Text style={{ fontWeight: 600, fontSize: 13.5 }}>Approach: {apNow.name}</Text>
          <ol className="g-steps" style={{ fontSize: 12.5, marginTop: 6 }}>{apNow.plan.map((x) => <li key={x.id}>{x.title}</li>)}</ol>
        </div>
        <div className="hc-label">This time, it works on</div>
        <Flex gap={6} wrap>
          <span className="gc-chip" onClick={() => send(apNow.fromGoal)}>The same as before: {apNow.fromGoal.length > 52 ? `${apNow.fromGoal.slice(0, 50)}…` : apNow.fromGoal}</span>
          <span className="gc-chip" onClick={() => fileRef.current?.click()}><PaperClipOutlined /> A problem statement</span>
        </Flex>
        <span className="hc-note">Or type the goal below. <a onClick={() => { gh().set({ draft: { ...gh().draft, approachId: undefined, scope: undefined, constraints: undefined } }) }}>Use no saved approach</a></span>
      </div>
    )
    if (c === 'b-goal') return (
      <div className="hc"><Head label="What you want to know" sub={sub} icon={1} />
        <div className="hc-label">Start from an example</div>
        <div className="hc-grid">
          {(['rule', 'schedule'] as Trigger[]).map((tr) => (
            <div key={tr} className="hc-tile" onClick={() => send(tr === 'rule' ? EX_RULE : EX_SCHED)}>
              <Tag icon={tr === 'rule' ? <BellOutlined /> : <ClockCircleOutlined />} style={{ marginInlineEnd: 0 }}>{STARTS[tr]}</Tag>
              <Text style={{ display: 'block', fontWeight: 500, margin: '6px 0 2px' }}>{ex(tr).title}</Text>
              <Text type="secondary" style={{ fontSize: 12 }}>{ex(tr).target.measure}</Text>
            </div>
          ))}
        </div>
        <div className="hc-label">Or</div>
        <Flex gap={6} wrap>
          <span className="gc-chip" onClick={() => fileRef.current?.click()}><PaperClipOutlined /> Attach a problem statement</span>
          {approaches.slice(0, 3).map((a) => <span key={a.id} className={`gc-chip${draft.approachId === a.id ? ' is-sel' : ''}`} onClick={() => pickApproach(a)}>From saved approach: {a.name.length > 34 ? `${a.name.slice(0, 32)}…` : a.name}</span>)}
        </Flex>
        <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: 10 }}>Or type the goal below, in plain words.</Text>
      </div>
    )
    if (c === 'b-trigger') return (
      <div className="hc"><Head label="How it starts" sub={sub} icon={2} />
        <div className="hc-grid hc-grid-3">
          {([['person', <UserOutlined key="p" />, 'You start it, now; I work it once.'], ['schedule', <ClockCircleOutlined key="s" />, 'It runs by itself, e.g. each quarter.'], ['rule', <BellOutlined key="r" />, 'It runs when something happens in our data or outside.']] as [Trigger, React.ReactNode, string][]).map(([tr, ic, d]) => (
            <div key={tr} className={`hc-tile${draft.trigger === tr ? ' is-sel' : ''}`} onClick={() => send(STARTS[tr])}>
              <Text style={{ fontWeight: 500 }}>{ic} {STARTS[tr]}</Text>
              <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: 2 }}>{d}</Text>
            </div>
          ))}
        </div>
      </div>
    )
    if (c === 'b-when') {
      const opts = draft.trigger === 'rule' ? ['In our data: a project in delivery more than 10% off its budget', 'On the internet: tariffs on steel raised by 20%'] : draft.trigger === 'schedule' ? ['Every Monday at 06:00', 'Each quarter, two weeks before the committee'] : ['No deadline', 'Before the committee on 8 October']
      return (
        <div className="hc"><Head label={briefLabel(c, draft.trigger)} sub={sub} icon={3} />
          {draft.trigger === 'rule' ? (
            <Flex gap={6} wrap style={{ marginBottom: 8 }}>
              <Text type="secondary" style={{ fontSize: 12.5 }}>Checked</Text>
              <span className={`gc-chip${draft.conditionSource !== 'external' ? ' is-sel' : ''}`} onClick={() => gh().set({ draft: { ...draft, conditionSource: 'data' }, lastField: 'source' })}><BellOutlined /> In our data, every snapshot</span>
              <span className={`gc-chip${draft.conditionSource === 'external' ? ' is-sel' : ''}`} onClick={() => gh().set({ draft: { ...draft, conditionSource: 'external' }, lastField: 'source' })}><GlobalOutlined /> On the internet, every morning</span>
            </Flex>
          ) : null}
          <Flex gap={6} wrap>{opts.map((o) => <span key={o} className="gc-chip" onClick={() => send(o)}>{o}</span>)}</Flex>
          <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: 10 }}>Or type it below. <a onClick={() => send('Change how it starts')}>Change how it starts</a></Text>
        </div>
      )
    }
    if (c === 'b-measure') return (
      <div className="hc"><Head label="What it is held against" sub={sub} icon={4} />
        <div className="sd-form">
          <label>Measure</label><Input size="small" value={draft.measure ?? ''} placeholder="e.g. Forecast against approved budget" onChange={(e) => gh().set({ draft: { ...gh().draft, measure: e.target.value }, lastField: 'measure' })} />
          <label>Target</label><Input size="small" value={draft.target ?? ''} placeholder="e.g. within 10%" onChange={(e) => gh().set({ draft: { ...gh().draft, target: e.target.value }, lastField: 'measure' })} />
        </div>
        <Flex gap={6} style={{ marginTop: 10 }}>
          <Button size="small" type="primary" disabled={!draft.measure?.trim()} onClick={() => send('Continue')}>Continue</Button>
          <Button size="small" onClick={() => send('You decide')}>You decide</Button>
        </Flex>
      </div>
    )
    /* check and create */
    const rows: [string, string, string | undefined][] = [
      ['Goal', 'Change the goal', draft.goal],
      ['Starts', 'Change how it starts', draft.trigger ? STARTS[draft.trigger] : undefined],
      [draft.trigger === 'rule' ? 'Condition' : draft.trigger === 'schedule' ? 'Schedule' : 'Deadline', 'Change the condition', draft.when === '' ? 'None' : draft.when],
      ...(draft.trigger === 'rule' ? [['Checked', 'Change the condition', draft.conditionSource === 'external' ? 'On the internet, every morning' : 'In our data, at every snapshot'] as [string, string, string]] : []),
      ['Measure', 'Change the measure', draft.measure],
      ['Target', 'Change the measure', draft.target],
      ...(draft.files?.length ? [['Files', '', draft.files.map((f) => f.name).join(' · ')] as [string, string, string]] : []),
      ...(draft.approachId ? [['Approach', '', `Saved: ${approaches.find((a) => a.id === draft.approachId)?.name}`] as [string, string, string]] : []),
    ]
    return (
      <div className="hc"><Head label="Check and create" sub={sub} icon={5} />
        <div className="hc-kv">
          {rows.map(([label, ch, val]) => <Fragment key={label}><span>{label}</span><span>{val ?? <Text type="secondary">not yet</Text>}</span><span>{ch ? <a onClick={() => send(ch)}>change</a> : null}</span></Fragment>)}
          <span>Agent</span><span><Input size="small" variant="underlined" style={{ maxWidth: 220, padding: 0 }} value={draft.agentName ?? nextAgent.name.replace(/^Agent /, '')} onChange={(e) => gh().set({ draft: { ...gh().draft, agentName: e.target.value }, lastField: 'agent' })} prefix={<Text type="secondary" style={{ fontSize: 12.5 }}>Agent</Text>} /></span><span />
        </div>
        <Button size="small" type="primary" style={{ marginTop: 10 }} disabled={!draft.goal} onClick={() => send('Create it')}>Create it</Button>
      </div>
    )
  }

  const focusStep = (id: string, sid: string) => { setView(id, { tab: 'approach', step: sid }); setPanelOpen(true) }
  const focusFinding = (id: string, fid: string) => { setView(id, { tab: 'findings', finding: fid }); setPanelOpen(true) }

  const renderWork = (msg: ChatMsg, x: Goal) => {
    const c = msg.card!
    const latest = lastOf(c) === msg.id
    const label = WORK_LABEL[c] ?? c
    if (c === 'approach') {
      const live = latest && x.status === 'plan-review'
      const steps = x.plan.filter((s) => s.state !== 'removed')
      if (!live) return <div className="hc hc-folded" role="button" onClick={() => focusStep(x.id, steps[0]?.id ?? '')}><Head label={label} done={!!x.planApproved} icon={<span>·</span>} /><span className="hc-sum">{count(steps.length)} steps · {x.planApproved ? `approved by ${x.planApproved.by}, ${fmtDate(x.planApproved.at)}` : x.status === 'plan-review' ? 'open for changes' : 'proposed'} · open on the right</span></div>
      if (!x.plan.length) return <div className="hc"><Head label={label} icon={<LoadingOutlined />} /><Text type="secondary"><LoadingOutlined /> {x.agent.name} is drafting the approach…</Text></div>
      let n = 0
      return (
        <div className="hc"><Head label={label} sub={`${count(steps.length)} steps · click one to see it in full`} icon={<span>·</span>} />
          <Flex vertical gap={4}>{x.plan.map((s) => {
            const out = s.state === 'removed'
            if (!out) n += 1
            const k = n
            return (
              <div key={s.id} className={`sd-ol${out ? ' is-out' : ''}${v.step === s.id ? ' is-focus' : ''}`} onClick={() => focusStep(x.id, s.id)} style={{ cursor: 'pointer' }}>
                <span className="sd-rail-n">{out ? '–' : k}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <Text delete={out} style={{ fontWeight: 500, fontSize: 13 }}>{s.title}</Text>
                  {s.editedBy ? <Tag style={{ marginLeft: 6, fontSize: 11 }}>changed by {s.editedBy.split(' ')[0]}</Tag> : null}
                  <Text type="secondary" style={{ display: 'block', fontSize: 11.5 }}>{s.sources.join(' · ')}</Text>
                </div>
                <span className="sd-ol-tools" onClick={(e) => e.stopPropagation()}>
                  {out ? <a onClick={() => send(`Put back step ${x.plan.indexOf(s) + 1}`)}>put back</a> : <>{k > 1 ? <a title="Move up" onClick={() => send(`Move step ${k} up`)}>↑</a> : null}<a title="Remove" onClick={() => send(`Remove step ${k}`)}>✕</a></>}
                </span>
              </div>
            )
          })}</Flex>
          <Flex gap={6} style={{ marginTop: 8 }}>
            <Input size="small" value={addStep} onChange={(e) => setAddStep(e.target.value)} placeholder="Add a step, e.g. read the supplier mail for promised dates" onPressEnter={() => { if (addStep.trim().length > 3) { send(`Add a step to ${addStep.trim()}`); setAddStep('') } }} />
            <Button size="small" icon={<PlusOutlined />} disabled={addStep.trim().length < 4} onClick={() => { send(`Add a step to ${addStep.trim()}`); setAddStep('') }}>Add</Button>
          </Flex>
          <Flex gap={6} style={{ marginTop: 10 }}>
            <Button size="small" type="primary" disabled={!steps.length} onClick={() => send(x.trigger === 'rule' ? 'Approve and save the approach' : 'Approve the approach')}>{x.trigger === 'rule' ? 'Approve and save with the rule' : x.trigger === 'schedule' ? 'Approve and save' : 'Approve and start'}</Button>
            <Button size="small" onClick={() => send('Save it for reuse')}>Save for reuse</Button>
          </Flex>
        </div>
      )
    }
    if (c === 'run') {
      const steps = x.plan.filter((st) => st.state !== 'removed')
      const done = steps.filter((st) => st.state === 'done').length
      const running = latest && (x.status === 'analysing' || x.status === 'fired')
      if (!running) return <div className="hc hc-folded" role="button" onClick={() => focusStep(x.id, steps[0]?.id ?? '')}><Head label={`Ran ${count(steps.length)} steps`} done /><span className="hc-sum">{steps.map((st) => st.title).join(' · ')}</span></div>
      const cur = steps.find((st) => st.state === 'running')
      const lastAct = cur?.trace?.[cur.trace.length - 1]
      return (
        <div className="hc hc-run"><Head label={label} sub={`${done} of ${steps.length} steps`} icon={<LoadingOutlined />} />
          <div className="hc-progress"><span style={{ width: `${Math.max(4, (done / steps.length) * 100)}%` }} /></div>
          <Flex vertical gap={2} style={{ marginTop: 10 }}>{steps.map((st, i) => (
            <div key={st.id} className={`hc-runstep is-${st.state}`} role="button" onClick={() => focusStep(x.id, st.id)}>
              <span className="hc-runicon">{st.state === 'done' ? <CheckOutlined /> : st.state === 'running' ? <LoadingOutlined /> : i + 1}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="hc-runtitle">{st.title}</div>
                {st.state === 'running' && lastAct ? <div className="hc-runact">{lastAct.replace(/\s*→\s*/, ' · ').replace(/\.$/, '')}</div> : null}
              </div>
            </div>
          ))}</Flex>
          <div className="hc-actions" style={{ marginTop: 10 }}>
            <Button size="small" onClick={() => send('Where are you?')}>Where are you?</Button>
            <Button size="small" type="text" onClick={() => { useGoalStore.getState().finishNow(x.id, me); setPanelOpen(true) }}>Skip to the findings (demo)</Button>
          </div>
        </div>
      )
    }
    if (c === 'armed') {
      const w = watchers.find((y) => y.goalId === x.id)
      const live = latest && x.status === 'armed'
      if (!live) return <div className="hc hc-folded"><Head label={x.trigger === 'rule' ? 'Waited for the rule' : 'Waited for the schedule'} done /><span className="hc-sum">{w?.last ?? x.triggerDetail}</span></div>
      return (
        <div className="hc"><Head label={label} icon={x.trigger === 'rule' ? <BellOutlined /> : <ClockCircleOutlined />} />
          <Text style={{ display: 'block', fontSize: 13 }}>{w?.condition ?? x.triggerDetail}</Text>
          <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>{x.trigger === 'rule' ? (w?.source === 'external' ? 'Checked on the internet, every morning' : 'Checked in our data, at every snapshot') : 'Runs by itself'} · approach approved{x.planApproved ? ` by ${x.planApproved.by}` : ''}</Text>
          <Flex gap={6} wrap style={{ marginTop: 10 }}>
            <Button size="small" type="primary" icon={<ThunderboltOutlined />} onClick={() => send(x.trigger === 'rule' ? 'Simulate the rule' : 'Simulate: run now')}>{x.trigger === 'rule' ? 'Simulate: the rule fires' : 'Simulate: run now'}</Button>
            <Button size="small" onClick={() => send('Change the approach')}>Change the approach</Button>
            <Button size="small" type="link" onClick={() => revealInList(x.id)}>Show it in Watching for you</Button>
          </Flex>
        </div>
      )
    }
    if (c === 'findings') {
      if (!x.findings.length) return null
      const acc = new Set(x.acceptedFindings ?? [])
      const allIn = x.findings.every((f) => acc.has(f.id))
      if (!latest) return <div className="hc hc-folded"><Head label={label} done={allIn} icon={<span>·</span>} /><span className="hc-sum">{count(x.findings.length)} findings · {acc.size} accepted</span></div>
      return (
        <div className="hc"><Head label={label} sub={`${acc.size} of ${x.findings.length} accepted · click one to open it`} icon={<span>·</span>} />
          <Flex vertical gap={4}>{x.findings.map((f, i) => (
            <div key={f.id} className={`sd-ol${v.finding === f.id ? ' is-focus' : ''}`} onClick={() => focusFinding(x.id, f.id)} style={{ cursor: 'pointer' }}>
              <span className="sd-rail-n">{i + 1}</span>
              <div style={{ flex: 1, minWidth: 0 }}><Text style={{ fontSize: 13 }}>{shortHeadline(f.headline)}</Text></div>
              <span className="sd-ol-tools" onClick={(e) => e.stopPropagation()}>
                {acc.has(f.id) ? <Tag color="success" icon={<CheckCircleOutlined />} style={{ marginInlineEnd: 0 }}>Accepted</Tag> : <><a onClick={() => send(`Accept ${i + 1}`)}>Accept</a><a onClick={() => send(`Challenge ${i + 1}`)}>Challenge</a></>}
              </span>
            </div>
          ))}</Flex>
          {x.gaps.length ? <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: 6 }}><WarningOutlined style={{ color: STATUS.warn }} /> Not established: {x.gaps.length} item{x.gaps.length > 1 ? 's' : ''}, listed on the right.</Text> : null}
          <Flex gap={6} wrap style={{ marginTop: 10 }}>
            {allIn ? <Button size="small" type="primary" onClick={() => send('What do you recommend?')}>Go to the decision</Button> : <Button size="small" type="primary" onClick={() => send('Accept all findings')}>Accept all</Button>}
            <Button size="small" onClick={() => send('Show the data')}>Open the data</Button>
          </Flex>
        </div>
      )
    }
    if (c === 'question') {
      const live = latest && !!x.question
      if (!live) return <div className="hc hc-folded"><Head label={label} done /><span className="hc-sum">Answered</span></div>
      return (
        <div className="hc"><Head label={label} icon={<WarningOutlined />} />
          <Text style={{ display: 'block', fontSize: 13 }}>{x.question}</Text>
          {!x.findings.length ? <Flex gap={6} wrap style={{ marginTop: 8 }}>{['Drop it from the goal', 'State it as a range from recorded positions'].map((o) => <span key={o} className="gc-chip" onClick={() => send(o)}>{o}</span>)}</Flex> : null}
          <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: 8 }}>Answer below, in your own words.</Text>
        </div>
      )
    }
    if (c === 'decision') {
      if (!x.recommendations.length) return null
      const chosen = x.status === 'accepted' ? x.recommendations.findIndex((r) => r.preferred) + 1 : 0
      if (!latest) return <div className="hc hc-folded"><Head label={label} done={!!chosen} icon={<span>·</span>} /><span className="hc-sum">{chosen ? `Chose option ${chosen}` : `${count(x.recommendations.length)} options`}</span></div>
      return (
        <div className="hc"><Head label={label} sub={chosen ? `option ${chosen} chosen` : `${count(x.recommendations.length)} ways forward`} icon={<span>·</span>} />
          <Flex vertical gap={6}>{x.recommendations.map((r, i) => {
            const isChosen = chosen === i + 1
            return (
              <div key={r.id} className={`sd-pick${r.preferred ? ' is-on' : ''}`} style={{ ['--agent' as string]: x.agent.colour, cursor: 'default' }}>
                <span className="sd-rail-n" style={{ paddingTop: 2 }}>{i + 1}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <Flex justify="space-between" gap={8}><Text style={{ fontWeight: 500, fontSize: 13 }}>{r.title}</Text>{isChosen ? <Tag color="green" style={{ marginInlineEnd: 0 }}>Chosen</Tag> : r.preferred && !chosen ? <Tag style={{ marginInlineEnd: 0 }}>Preferred</Tag> : null}</Flex>
                  <Flex gap={SP.lg} wrap style={{ marginTop: 4 }}>{r.figures.slice(0, 3).map((f) => <Figure key={f.label} {...f} />)}</Flex>
                  <Flex gap={6} style={{ marginTop: 6 }}>
                    <Button size="small" onClick={() => send(`Why option ${i + 1}?`)}>Why this</Button>
                    {!chosen ? <Button size="small" type={r.preferred ? 'primary' : 'default'} onClick={() => send(`Choose option ${i + 1}`)}>Choose</Button> : null}
                  </Flex>
                </div>
              </div>
            )
          })}</Flex>
        </div>
      )
    }
    if (c === 'send') {
      const offered = x.submissions.filter((s) => templates.some((t) => t.id === s.templateId))
      if (!latest) return <div className="hc hc-folded"><Head label={label} done icon={<span>·</span>} /><span className="hc-sum">{count(offered.length)} offered from your templates</span></div>
      return (
        <div className="hc"><Head label={label} sub="from the templates in your library" icon={<span>·</span>} />
          <Flex vertical gap={6}>{offered.map((s, i) => (
            <div key={s.id} className="sd-ol" style={{ alignItems: 'center' }}>
              <span className="sd-rail-n">{i + 1}</span>
              <div style={{ flex: 1, minWidth: 0 }}><Text style={{ fontWeight: 500, fontSize: 13 }}>{s.label}</Text><Text type="secondary" style={{ display: 'block', fontSize: 12 }}>To {s.audience} · {templates.find((t) => t.id === s.templateId)?.name}</Text></div>
              <Button size="small" type="primary" onClick={() => send(`Start ${i + 1}`)}>Start</Button>
            </div>
          ))}</Flex>
          {!offered.length ? <Text type="secondary" style={{ fontSize: 12.5 }}>None of your templates fits this goal.</Text> : null}
          <Flex gap={6} wrap style={{ marginTop: 10 }}>
            <Button size="small" icon={<PlusOutlined />} onClick={() => send('Describe a new output')}>Describe a new output</Button>
            <Button size="small" onClick={() => send('Download the analysis pack')}>Download the analysis pack</Button>
          </Flex>
        </div>
      )
    }
    return null
  }

  /* ---------------- the list on the left: drafts, goals, what is watching for you, saved approaches */
  const briefStep = (st: Stage) => BRIEF.findIndex((b) => b.key === st) + 1
  const match = useRailMatch()
  const draftBriefs = [
    ...(isBrief(current) && begun(newMsgs, draft) ? [{ key: current, draft, stage }] : []),
    ...Object.entries(briefs).sort((a, b) => b[1].at - a[1].at).map(([key, b]) => ({ key, draft: b.draft, stage: b.stage })),
  ]
  const toApprove = goals.filter((x) => x.status === 'plan-review')
  const armed = (x: Goal) => x.status === 'armed'
  const active = goals.filter((x) => x.status !== 'plan-review' && !armed(x))
  const openBrief = (key: string) => { switchTo(key); setPanelOpen(true); if (routeId) navigate(appPath('/goals')) }
  const rail = (
    <>
      <RailSearch placeholder="Search goals" />
      <RailSection id="g-drafts" label="Drafts" n={draftBriefs.length + toApprove.length} empty="Nothing half done.">
        {draftBriefs.filter((b) => match(b.draft.goal ?? 'New goal')).map((b) => <RailItem key={b.key} title={b.draft.goal ?? (b.draft.approachId ? `From "${approaches.find((a) => a.id === b.draft.approachId)?.name ?? 'saved approach'}"` : 'New goal')} status={<span>Brief · step {briefStep(b.stage)} of 5</span>} on={current === b.key} icon={<EditOutlined />} onClick={() => openBrief(b.key)} />)}
        {toApprove.filter((x) => match(x.title)).map((x) => <RailItem key={x.id} title={x.title} status={<span className="is-warn">Approach to approve · {x.agent.name}</span>} on={current === x.id} icon={TRIGGER_ICON[x.trigger]} onClick={() => navigate(appPath(`/goals/${x.id}`))} />)}
      </RailSection>
      <RailSection id="g-goals" label="Goals" n={active.length} empty="None yet.">
        {active.filter((x) => match(x.title)).map((x) => <RailItem key={x.id} title={x.title} status={<span className={x.question ? 'is-warn' : x.status === 'findings-ready' || x.status === 'accepted' ? 'is-good' : undefined}>{x.question ? 'One question for you' : STATUS_LABEL[x.status]} · {x.agent.name}</span>} on={current === x.id} fresh={fresh === x.id} icon={TRIGGER_ICON[x.trigger]} onClick={() => navigate(appPath(`/goals/${x.id}`))} />)}
      </RailSection>
      <RailSection id="g-watching" label="Watching for you" n={watchers.length}>
        {watchers.filter((w) => match(w.label)).map((w) => {
          const wg = goals.find((x) => x.id === w.goalId)
          return (
            <RailItem key={w.id} title={w.label.replace(/^(Rule|Schedule):\s*/, '')} fresh={!!wg && fresh === wg.id}
              icon={w.kind === 'rule' ? (w.source === 'external' ? <GlobalOutlined /> : <BellOutlined />) : <ClockCircleOutlined />}
              status={<span className={w.state === 'Fired' ? 'is-warn' : undefined}>{w.state} · {w.last}</span>}
              extra={wg && (armed(wg) || (wg.trigger === 'schedule' && wg.status !== 'analysing')) ? <a className="rl-mini" onClick={(e) => { e.stopPropagation(); useGoalStore.getState().rearm(wg.id); useGoalStore.getState().fire(wg.id, 'Agent'); useGoalStore.getState().setView(wg.id, { tab: 'approach' }); navigate(appPath(`/goals/${wg.id}`)) }}><ThunderboltOutlined /> {w.kind === 'rule' ? 'Simulate: the rule fires' : 'Simulate: run now'}</a> : null}
              onClick={() => { if (wg) navigate(appPath(`/goals/${wg.id}`)) }} />
          )
        })}
      </RailSection>
      <RailSection id="g-approaches" label="Saved approaches" n={approaches.length}>
        {approaches.filter((a) => match(a.name)).map((a) => <RailItem key={a.id} title={a.name} status={<span>{count(a.plan.length)} steps · new goal from it</span>} icon={<SaveOutlined />} onClick={() => newGoal(a.id)} />)}
      </RailSection>
    </>
  )

  /* ---------------- the panel: the open goal in full, or the brief filling in; nothing otherwise */
  const panelKind: 'goal' | 'brief' | null = g ? 'goal' : begun(newMsgs, draft) ? 'brief' : null
  const renderPanel = () => {
    if (panelKind === 'brief') {
      const rows: [string, string, string | undefined][] = [
        ['goal', 'Goal', draft.goal], ['trigger', 'Starts', draft.trigger ? STARTS[draft.trigger] : undefined],
        ['when', draft.trigger === 'rule' ? 'Condition' : draft.trigger === 'schedule' ? 'Schedule' : 'Deadline', draft.trigger && draft.when !== undefined ? draft.when || 'None' : undefined],
        ...(draft.trigger === 'rule' ? [['source', 'Checked', draft.conditionSource === 'external' ? 'On the internet, every morning' : draft.conditionSource ? 'In our data, at every snapshot' : undefined] as [string, string, string | undefined]] : []),
        ['measure', 'Measure', draft.measure], ['measure', 'Target', draft.target], ['agent', 'Agent', newAgent.name],
        ...(draft.files?.length ? [['files', 'Files', draft.files.map((f) => `${f.name} (${f.read})`).join(' · ')] as [string, string, string | undefined]] : []),
        ...(draft.approachId ? [['approach', 'Approach', `Saved: ${approaches.find((a) => a.id === draft.approachId)?.name}`] as [string, string, string | undefined]] : []),
      ]
      const n = briefStep(stage)
      const ap = approaches.find((a) => a.id === draft.approachId)
      return (
        <div className="hp">
          <div className="hp-head"><span>Brief · step {n} of 5</span><span className="hp-x" role="button" aria-label="Close the panel" onClick={() => setPanelOpen(false)}><CloseOutlined /></span></div>
          <div className="hp-title">New goal</div>
          <span className="hp-sub">Fills in as you brief {newAgent.name}. It is kept in Drafts until you create it.</span>
          <div className="hp-steps">{BRIEF.map((b, i) => <span key={b.key} className={i + 1 < n ? 'is-done' : i + 1 === n ? 'is-now' : ''} />)}</div>
          <div className="hp-kv">
            {rows.map(([k, label, val]) => <Fragment key={`${label}-${lastField === k || lastField === 'all' ? msgs.length : 0}`}><span>{label}</span><span className={(lastField === k || lastField === 'all') && val ? 'gw-draft-field' : undefined} style={{ color: val ? undefined : '#b6bdc9' }}>{val ?? 'not yet'}</span></Fragment>)}
          </div>
          {ap ? <><div className="hc-label" style={{ marginTop: 18 }}>The approach it will follow</div><ol className="g-steps" style={{ fontSize: 13 }}>{ap.plan.map((x) => <li key={x.id}>{x.title}</li>)}</ol></> : null}
        </div>
      )
    }
    if (!g) return null
    const items: { key: Tab; label: string; children: React.ReactNode }[] = [
      { key: 'target', label: 'Goal', children: <GoalTab g={g} /> },
      { key: 'approach', label: 'Approach', children: <ApproachTab g={g} v={v} say={send} onFocus={(id) => setView(g.id, { tab: 'approach', step: v.step === id ? undefined : id })} /> },
      { key: 'findings', label: `Findings${g.findings.length ? ` · ${g.findings.length}` : ''}`, children: <FindingsTab g={g} v={v} say={send} onFocus={(id) => setView(g.id, { tab: 'findings', finding: id })} onDrill={setDrawer} /> },
      { key: 'data', label: 'Data', children: <DataExplorer key={JSON.stringify(v.drill ?? null)} start={v.drill ?? { view: g.findings[0]?.drill.project ? 'snapshots' : 'portfolio', project: g.findings[0]?.drill.project, note: '' }} height={Math.max(420, window.innerHeight - 260)} /> },
      { key: 'decision', label: 'Decision', children: <DecisionTab g={g} v={v} say={send} onDrill={setDrawer} /> },
      { key: 'submissions', label: 'Submissions', children: <SubmissionsTab g={g} say={send} /> },
      { key: 'log', label: 'Log', children: <Timeline style={{ paddingTop: 6 }} items={[...g.log].reverse().map((l) => ({ color: l.who === g.agent.name ? g.agent.colour : /^(Rule|Schedule)/.test(l.who) ? STATUS.warn : 'gray', children: <div><Text type="secondary" style={{ fontSize: 11.5 }}>{fmtDate(l.at)} · {l.who}</Text><Text style={{ display: 'block', fontSize: 12.5 }}>{l.what}</Text></div> }))} /> },
    ]
    return (
      <div className="hp">
        <div className="hp-head"><span>{TRIGGER_LABEL[g.trigger]} · {g.owner}</span><span className="hp-x" role="button" aria-label="Close the panel" onClick={() => setPanelOpen(false)}><CloseOutlined /></span></div>
        <div className="hp-title">{g.title}</div>
        <Flex gap={6} align="center" wrap style={{ margin: '4px 0 2px' }}><AgentBadge agent={g.agent} /><GoalPill status={g.status} /></Flex>
        <span className="hp-sub" style={{ marginBottom: 8 }}>Target: {g.target.target}</span>
        <Tabs className="hp-tabs" size="small" tabBarGutter={14} activeKey={v.tab} onChange={(k) => setView(g.id, { tab: k as Tab, finding: v.finding, drill: v.drill, story: v.story, step: v.step })} items={items} />
      </div>
    )
  }

  /* ---------------- what you could say next */
  const live = g ? g.plan.filter((s) => s.state !== 'removed') : []
  const focus = g ? { step: v.step ? live.findIndex((s) => s.id === v.step) + 1 || undefined : undefined, finding: v.finding ? g.findings.findIndex((f) => f.id === v.finding) + 1 || undefined : undefined } : {}
  const chips = g ? suggestions(g, v.tab, g.agent.name.replace(/^Agent /, ''), { step: v.tab === 'approach' ? focus.step : undefined, finding: v.tab === 'findings' ? focus.finding : undefined })
    : stage === 'goal' ? [] : stage === 'trigger' ? [] : stage === 'when' ? [] : stage === 'measure' ? ['You decide'] : ['Create it']

  /* ---------------- where you are: the journey bar, the docked step, the resume line */
  const journey: (JStep & { next: string; dock?: string })[] = (() => {
    const at = (tab: Tab, card?: string) => () => { if (g) { setView(g.id, { tab }); setPanelOpen(true) } scrollToMsg(card ? lastOf(card) : null) }
    if (!g) {
      const n = briefStep(stage)
      const t = draft.trigger
      const out: (JStep & { next: string; dock?: string })[] = [
        { key: 'brief', label: 'Brief', state: 'now', sub: `${n} of 5`, onClick: () => { setPanelOpen(true); scrollToMsg(lastOf(BRIEF[n - 1].card)) }, next: briefLabel(BRIEF[n - 1].card, t).toLowerCase(), dock: briefLabel(BRIEF[n - 1].card, t) },
        { key: 'approach', label: 'Approach', state: 'todo', next: '' },
        ...(t && t !== 'person' ? [{ key: 'trigger', label: t === 'rule' ? 'Rule' : 'Schedule', state: 'todo' as const, next: '' }] : []),
        { key: 'run', label: 'Run', state: 'todo', next: '' }, { key: 'findings', label: 'Findings', state: 'todo', next: '' },
        { key: 'decision', label: 'Decision', state: 'todo', next: '' }, { key: 'send', label: 'Send', state: 'todo', next: '' },
      ]
      return out
    }
    const s0 = g.status
    const acc = new Set(g.acceptedFindings ?? [])
    const allIn = g.findings.length > 0 && g.findings.every((f) => acc.has(f.id))
    const sent = startedSubs.some((x) => x.fromGoal?.id === g.id)
    const order = ['brief', 'approach', 'trigger', 'run', 'findings', 'decision', 'send']
    const nowKey = s0 === 'plan-review' ? 'approach' : s0 === 'armed' ? (g.trigger === 'person' ? 'run' : 'trigger') : s0 === 'fired' || s0 === 'analysing' || (s0 === 'needs-input' && !g.findings.length) ? 'run'
      : s0 === 'findings-ready' || s0 === 'needs-input' ? (allIn ? 'decision' : 'findings') : sent ? 'end' : 'send'
    const idx = nowKey === 'end' ? order.length : order.indexOf(nowKey)
    const st = (k: string): JStep['state'] => { const i = order.indexOf(k); return i < idx ? 'done' : i === idx ? 'now' : 'todo' }
    const steps: (JStep & { next: string; dock?: string })[] = [
      { key: 'brief', label: 'Brief', state: st('brief'), onClick: at('target'), next: '' },
      { key: 'approach', label: 'Approach', state: st('approach'), sub: st('approach') === 'now' ? 'to approve' : undefined, onClick: at('approach', 'approach'), next: 'approve the approach, or change it', dock: 'Approve the approach' },
      ...(g.trigger !== 'person' ? [{ key: 'trigger', label: g.trigger === 'rule' ? 'Rule' : 'Schedule', state: st('trigger'), sub: st('trigger') === 'now' ? 'armed' : undefined, onClick: at('approach', 'armed'), next: g.trigger === 'rule' ? 'nothing from you, it runs when the rule fires' : 'nothing from you, it runs on the schedule', dock: g.trigger === 'rule' ? 'Waiting for the rule' : 'Waiting for the schedule' }] : []),
      { key: 'run', label: 'Run', state: st('run'), sub: st('run') === 'now' ? (g.question ? 'a question' : s0 === 'armed' ? undefined : 'running') : undefined, onClick: at('approach', g.question && !g.findings.length ? 'question' : 'run'), next: g.question && !g.findings.length ? 'answer one question' : 'nothing from you, the findings land when the run ends', dock: g.question && !g.findings.length ? 'One question for you' : 'Running the approach' },
      { key: 'findings', label: 'Findings', state: st('findings'), sub: st('findings') === 'now' && g.findings.length ? `${acc.size} of ${g.findings.length}` : undefined, onClick: at('findings', 'findings'), next: 'accept or challenge each finding', dock: 'Accept or challenge the findings' },
      { key: 'decision', label: 'Decision', state: st('decision'), onClick: at('decision', 'decision'), next: 'choose a way forward', dock: 'Choose a way forward' },
      { key: 'send', label: 'Send', state: st('send'), onClick: at('submissions', 'send'), next: 'start a submission from your templates', dock: 'Start a submission' },
    ]
    return steps
  })()
  const nowStep = journey.find((x) => x.state === 'now')
  /* Opening a goal: the right panel shows the step you are on. */
  const STEP_TAB: Record<string, Tab> = { approach: 'approach', trigger: 'approach', run: 'approach', findings: 'findings', decision: 'decision', send: 'submissions' }
  useEffect(() => {
    if (!g || !nowStep || !STEP_TAB[nowStep.key]) return
    const cur = useGoalStore.getState().views[g.id]
    if (cur?.tab !== STEP_TAB[nowStep.key]) setView(g.id, { ...(cur ?? {}), tab: STEP_TAB[nowStep.key] })
  }, [current]) // eslint-disable-line react-hooks/exhaustive-deps
  const nowIdx = nowStep ? journey.indexOf(nowStep) + 1 : journey.length
  const waitingOnYou = !!nowStep && !/^nothing from you/.test(nowStep.next)
  const resumeLine = !resume || resume !== current ? null
    : nowStep ? `Back on this. Step ${nowIdx} of ${journey.length}, ${nowStep.label}. Next: ${nowStep.next}.`
      : 'Back on this. Every step is done. Re-run it, or start another submission from it.'

  return (
    <>
    <HubFrame rail={rail} panel={panelOpen && panelKind ? renderPanel() : null}>
      <input ref={fileRef} type="file" accept=".pptx,.docx,.pdf,.txt,.md,.csv,.xlsx" style={{ display: 'none' }} data-testid="goal-upload" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); e.target.value = '' }} />
        <div className="hub-top">
          <RailToggle />
          <span className="hub-top-title"><span>{g ? g.title : draft.goal ? draft.goal : 'New goal'}</span>{g && !(panelOpen && panelKind) ? <GoalPill status={g.status} /> : !g && begun(newMsgs, draft) ? <span className="pill is-grey"><i />Draft</span> : null}</span>
          {!panelOpen && panelKind ? <Tooltip title="Show it on the right"><span role="button" aria-label="Show the panel" className="hub-icon" onClick={() => setPanelOpen(true)}><LayoutOutlined /></span></Tooltip> : null}
          {g || begun(newMsgs, draft) ? <Button className="hub-new" icon={<PlusOutlined />} onClick={() => newGoal()}>New goal</Button> : null}
        </div>
        <JourneyBar steps={journey} />
        <div className="hub-feed" ref={feedRef}>
          {msgs.map((x) => x.who === 'event' ? <div key={x.id} className="gc-event">{x.text}</div>
            : x.who === 'me' ? <div key={x.id} id={`msg-${x.id}`} className="hub-me"><div className="gc-bubble is-me">{x.file ? <span className="gc-file"><PaperClipOutlined /> {x.file.name} <span className="gc-file-size">{fileSize(x.file.size)}</span></span> : null}{x.text}</div></div>
            : (
              <div key={x.id} id={`msg-${x.id}`} className={`hub-agent${cont(x) ? ' is-cont' : ''}`}>
                <AgentMark agent={agent} />
                <div className="hub-agent-body">
                  {x.text ? <div className="hub-text"><RichText text={x.text} /></div> : null}
                  {x.card ? (x.card.startsWith('b-') ? renderBrief(x) : g ? renderWork(x, g) : null) : null}
                </div>
              </div>
            ))}
          {typing ? <div className="hub-agent"><AgentMark agent={agent} /><div className="gc-bubble is-agent gc-typing"><span /><span /><span /></div></div> : null}
          {resumeLine && !typing ? <div className="gc-event is-resume" data-testid="resume">{resumeLine}</div> : null}
          <div ref={endRef} />
        </div>
        <div className="hub-input">
          {nowStep?.dock ? <Dock away={dock.away} go={dock.go} lead={waitingOnYou ? 'Waiting for you' : 'In progress'} label={nowStep.dock} /> : null}
          {chips.length ? <div className="gc-chips">{chips.map((c) => <span key={c} className="gc-chip" onClick={() => send(c)}>{c}</span>)}</div> : null}
          <div className="gc-box" style={{ margin: 0 }}>
            <span role="button" aria-label="Attach a file" className="gc-clip" onClick={() => fileRef.current?.click()}><PaperClipOutlined /></span>
            <Input.TextArea value={text} onChange={(e) => setText(e.target.value)} autoSize={{ minRows: 1, maxRows: 6 }} variant="borderless" aria-label="Message"
              placeholder={g ? `Message ${g.agent.name}` : stage === 'goal' ? 'What do you want to know or achieve?' : 'Answer here, or use the card above'}
              onPressEnter={(e) => { if (!e.shiftKey) { e.preventDefault(); send(text) } }} />
            <span role="button" aria-label="Send" className={`gc-send${text.trim() ? ' is-on' : ''}`} onClick={() => send(text)}><ArrowUpOutlined /></span>
          </div>
        </div>
    </HubFrame>
      <Drawer open={!!drawer} onClose={() => setDrawer(null)} width="min(1280px, 94vw)" title="The data behind it" destroyOnHidden styles={{ body: { padding: SP.base } }}>
        {drawer ? <DataExplorer start={drawer} height={Math.max(360, window.innerHeight - 150)} /> : null}
      </Drawer>
    </>
  )
}

/** A goal's status as a dot and a word; the dot pulses while the agent works. */
const PILL_TONE: Record<Goal['status'], string> = { 'plan-review': 'amber', armed: 'blue', fired: 'orange', analysing: 'orange', 'needs-input': 'amber', 'findings-ready': 'green', accepted: 'green' }
function GoalPill({ status }: { status: Goal['status'] }) {
  return <span className={`pill is-${PILL_TONE[status]}`}><i />{STATUS_LABEL[status]}</span>
}
