import { AimOutlined, ApartmentOutlined, ArrowRightOutlined, BulbOutlined, CheckOutlined, CopyOutlined, DashboardOutlined, DownloadOutlined, FileExcelOutlined, FileImageOutlined, FilePdfOutlined, FilePptOutlined, FileTextOutlined, LinkOutlined, MailOutlined, PlusOutlined, ReloadOutlined, SaveOutlined, ShareAltOutlined, TableOutlined, UploadOutlined } from '@ant-design/icons'
import { Alert, App, Button, Card, Checkbox, Col, Descriptions, Drawer, Dropdown, Flex, Form, Input, Modal, Radio, Row, Select, Space, Steps, Tabs, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { appPath } from '../api/dataset'
import PageHeader from '../components/common/PageHeader'
import SubmissionsHub from './SubmissionsHub'
import ChatPane from '../components/goals/ChatPane'
import TwoPane from '../components/goals/TwoPane'
import '../components/goals/ChatPane.css'
import { describeRead, readUpload } from '../data/readFile'
import { bestMatch, interpretNew, interpretSub, smsg, templateFromRead, useSubChat } from '../data/subChat'
import { download } from '../data/drill'
import type { Goal } from '../data/goalCases'
import { type OutputFormat, type SectionRole, type Template } from '../data/submissionTemplates'
import { EXAMPLE_BRIEFS, OUTPUT_FORMATS, designOutline, formatInfo, roleOf, type OutlineProposal } from '../data/outputDesigner'
import { LINEAGE, VISUAL_CSS, tableOf, visualFor, visualForFormat, visualHtml, type Visual } from '../data/visuals'
import { nodeToPng, printNode } from '../data/rasterize'
import { downloadPptx } from '../data/pptxExport'
import { DRILL } from '../data/drill'
import { useAuthStore } from '../store/authStore'
import { useGoalStore } from '../store/goalStore'
import { useSubmissionStore, type Section, type Submission, type SubmissionStage } from '../store/submissionStore'
import { BRAND, BRAND_INK, BRAND_SOFT, SP, STATUS } from '../theme'
import './GoalsPage.css'

const { Text, Title, Paragraph } = Typography

/*
 * Submissions, by my agents. Two tabs on the landing page: the submissions, and the template library
 * the author maintains. A new submission starts from a goal (its agent's recommendation) or from a
 * template, and in both cases ties back to the goals it draws on. Five steps: brief, template,
 * outline, draft, review. Sending is not part of this product today.
 */

const STAGES: SubmissionStage[] = ['brief', 'template', 'outline', 'draft', 'reviewed']
const STAGE_LABEL: Record<SubmissionStage, string> = { brief: 'Brief', template: 'Template', outline: 'Outline', draft: 'Draft', reviewed: 'Reviewed' }
const FAMILIES = ['Contract risk', 'Renewals', 'Client reporting', 'Your prior deliverables', 'Described for a goal', 'Your file'] as const
export const ROLES: { value: SectionRole; label: string }[] = [
  { value: 'purpose', label: 'Purpose / decision asked' }, { value: 'summary', label: 'Summary / recommendation' }, { value: 'findings', label: 'Findings' }, { value: 'options', label: 'Options' },
  { value: 'why', label: 'Why' }, { value: 'evidence', label: 'Evidence' }, { value: 'assumptions', label: 'Assumptions / open items' }, { value: 'next', label: 'Next steps' }, { value: 'free', label: 'Free text' },
]
const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c] as string)
export const FORMAT_ICON: Record<OutputFormat, React.ReactNode> = { Document: <FileTextOutlined />, Memo: <FileTextOutlined />, 'Slide pack': <FilePptOutlined />, Dashboard: <DashboardOutlined />, Workbook: <FileExcelOutlined />, Email: <MailOutlined /> }
export const FORMAT_LABEL: Record<OutputFormat, string> = { Document: 'Document', Memo: 'Memo', 'Slide pack': 'Slide pack', Dashboard: 'Dashboard', Workbook: 'Spreadsheet', Email: 'Email' }

/* ------------------------------------------------------------------ templates */

export function TemplateCard({ t, selected, onPick, compact }: { t: Template; selected?: boolean; onPick?: () => void; compact?: boolean }) {
  return (
    <Card hoverable={!!onPick} size="small" onClick={onPick} style={{ height: '100%', borderColor: selected ? BRAND : undefined, background: selected ? BRAND_SOFT : undefined }} styles={{ body: { padding: `${SP.md}px ${SP.base}px` } }}>
      <Flex justify="space-between" align="flex-start" gap={SP.sm}>
        <Space size={SP.xs}><span style={{ color: BRAND_INK }}>{FORMAT_ICON[t.format]}</span><Text style={{ fontWeight: 500, fontSize: 13.5, color: selected ? BRAND_INK : undefined }}>{t.name}</Text></Space>
        {selected ? <CheckOutlined style={{ color: BRAND }} /> : <Tag style={{ marginInlineEnd: 0 }}>{t.format}</Tag>}
      </Flex>
      <Text type="secondary" style={{ display: 'block', fontSize: 12, margin: `${SP.xs}px 0 ${SP.sm}px` }}>{t.note}</Text>
      {!compact ? <ol style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: '#4b5a75' }}>{t.sections.map((s) => <li key={s.heading}>{s.heading}</li>)}</ol> : <Text type="secondary" style={{ fontSize: 12 }}>{t.sections.length} sections</Text>}
    </Card>
  )
}

/** Add a template to the library: from a file (name only in this prototype) or written here. */
export function TemplateEditor({ open, onClose }: { open: boolean; onClose: () => void }) {
  const addTemplate = useSubmissionStore((s) => s.addTemplate)
  const identity = useAuthStore((s) => s.identity)
  const [form] = Form.useForm<{ name: string; family: Template['family']; format: Template['format']; note: string; sections: { heading: string; role: SectionRole }[]; file?: string }>()
  return (
    <Drawer title="Add a template" open={open} onClose={onClose} width={560} destroyOnHidden>
      <Form
        form={form}
        layout="vertical"
        initialValues={{ family: 'Your prior deliverables', format: 'Document', sections: [{ heading: 'Purpose', role: 'purpose' }, { heading: 'Summary', role: 'summary' }, { heading: 'Evidence', role: 'evidence' }, { heading: 'Next steps', role: 'next' }] }}
        onFinish={(v) => {
          addTemplate({ id: `t-user-${Date.now().toString(36)}`, name: v.name, file: v.file, family: v.family, format: v.format, note: v.note || 'Written here.', sections: v.sections.filter((s) => s.heading.trim()) }, identity?.name ?? 'You')
          onClose()
        }}
      >
        <Form.Item name="file" hidden><Input /></Form.Item>
        <div style={{ marginBottom: SP.lg }}>
          <Text style={{ display: 'block', fontSize: 13, marginBottom: 4 }}>From a file (optional)</Text>
          <input type="file" accept=".pptx,.docx,.txt,.md,.pdf,.xlsx" data-testid="template-file" onChange={async (e) => {
            const f = e.target.files?.[0]
            if (!f) return
            const t = templateFromRead(await readUpload(f))
            form.setFieldsValue({ file: f.name, name: t.name, family: 'Your file', format: t.format, note: t.note, sections: t.sections })
          }} />
          <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: 4 }}>A past deliverable or a template your audience gave you. PowerPoint and Word files are read: one section per slide, or per heading.</Text>
        </div>
        <Form.Item name="name" label="Name" rules={[{ required: true, message: 'Name it.' }]}><Input placeholder="e.g. Depot monthly note" /></Form.Item>
        <Row gutter={SP.base}>
          <Col span={12}><Form.Item name="family" label="Family"><Select options={FAMILIES.map((f) => ({ value: f, label: f }))} /></Form.Item></Col>
          <Col span={12}><Form.Item name="format" label="Format"><Select options={OUTPUT_FORMATS.map((f) => ({ value: f.key, label: FORMAT_LABEL[f.key] }))} /></Form.Item></Col>
        </Row>
        <Form.Item name="note" label="When to use it"><Input placeholder="One line" /></Form.Item>
        <Text style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: SP.xs }}>Sections</Text>
        <Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: SP.sm }}>Each section names the role it plays, so content from a goal lands in the right place.</Text>
        <Form.List name="sections">
          {(fields, { add, remove }) => (
            <>
              {fields.map((f) => (
                <Flex key={f.key} gap={SP.xs} style={{ marginBottom: SP.xs }}>
                  <Form.Item name={[f.name, 'heading']} style={{ flex: 1, marginBottom: 0 }}><Input placeholder="Heading" /></Form.Item>
                  <Form.Item name={[f.name, 'role']} style={{ width: 210, marginBottom: 0 }}><Select options={ROLES} /></Form.Item>
                  <Button type="text" danger onClick={() => remove(f.name)}>×</Button>
                </Flex>
              ))}
              <Button size="small" icon={<PlusOutlined />} onClick={() => add({ heading: '', role: 'free' })}>Add a section</Button>
            </>
          )}
        </Form.List>
        <Button type="primary" htmlType="submit" block style={{ marginTop: SP.lg }}>Add to the library</Button>
      </Form>
    </Drawer>
  )
}

export function TemplateLibrary() {
  const templates = useSubmissionStore((s) => s.templates)
  const [adding, setAdding] = useState(false)
  return (
    <>
      <Flex justify="space-between" align="center" style={{ marginBottom: SP.base }}>
        <Text type="secondary" style={{ fontSize: 13 }}>The forms your audiences expect. A submission follows one of these and fills it from the goals it draws on.</Text>
        <Button type="primary" icon={<UploadOutlined />} onClick={() => setAdding(true)}>Add a template</Button>
      </Flex>
      {FAMILIES.map((fam) => {
        const list = templates.filter((t) => t.family === fam)
        if (!list.length) return null
        return (
          <div key={fam} style={{ marginBottom: SP.lg }}>
            <Text type="secondary" style={{ fontSize: 11.5, textTransform: 'uppercase', letterSpacing: 0.3, display: 'block', marginBottom: SP.sm }}>{fam}</Text>
            <Row gutter={[SP.base, SP.base]}>{list.map((t) => <Col key={t.id} xs={24} md={12} xl={8}><TemplateCard t={t} /></Col>)}</Row>
          </div>
        )
      })}
      <TemplateEditor open={adding} onClose={() => setAdding(false)} />
    </>
  )
}

/* ------------------------------------------------------------------ new submission */

/** The agent's recommendations for a goal, each resting on a template that exists in the library. */
export function Recommendations({ g, value, onPick }: { g: Goal; value?: string; onPick: (id: string) => void }) {
  const templates = useSubmissionStore((s) => s.templates)
  const offered = g.submissions.filter((x) => templates.some((t) => t.id === x.templateId))
  const missing = g.submissions.filter((x) => !templates.some((t) => t.id === x.templateId))
  return (
    <>
      <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.xs }}><BulbOutlined style={{ color: BRAND }} /> Based on the templates in your library, {g.agent.name} recommends</Text>
      {offered.length ? (
        <Radio.Group value={value} onChange={(e) => onPick(e.target.value)} style={{ width: '100%' }}>
          <Flex vertical gap={SP.sm}>
            {offered.map((x) => {
              const t = templates.find((tt) => tt.id === x.templateId)!
              return (
                <Card key={x.id} size="small" onClick={() => onPick(x.id)} style={{ cursor: 'pointer', borderColor: value === x.id ? BRAND : undefined }} styles={{ body: { padding: `${SP.sm}px ${SP.base}px` } }}>
                  <Radio value={x.id}><Text style={{ fontWeight: 500 }}>{x.label}</Text></Radio>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginLeft: 24 }}>To {x.audience}</Text>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginLeft: 24 }}>{x.why}</Text>
                  <div style={{ marginLeft: 24, marginTop: SP.xs }}><Tag icon={FORMAT_ICON[t.format]} color="success" style={{ marginInlineEnd: 0 }}>Template in your library: {t.name}</Tag></div>
                </Card>
              )
            })}
          </Flex>
        </Radio.Group>
      ) : <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>None of the templates in your library fits this goal. Describe the output you want instead.</Text>}
      {missing.length ? <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: SP.sm }}>Not offered because their template is not in the library: {missing.map((x) => x.label).join('; ')}.</Text> : null}
    </>
  )
}

/** Describe a new output for a goal: pick the format, say what it should cover, read the agent's outline, edit, create.
 *  Controlled from outside, so the chat and the screen drive the same state. */
interface DescribeCtl {
  format: OutputFormat
  text: string
  proposal: OutlineProposal | null
  thinking: boolean
  setFormat: (f: OutputFormat) => void
  setText: (t: string) => void
  setProposal: (fn: (p: OutlineProposal | null) => OutlineProposal | null) => void
  propose: () => void
  create: () => void
  say: (t: string) => void
}
export function DescribeOutput({ g, c }: { g: Goal; c: DescribeCtl }) {
  const { format, text, proposal, thinking } = c
  const examples = EXAMPLE_BRIEFS[g.exampleOf ?? g.id] ?? []
  const setSec = (i: number, p: Partial<OutlineProposal['sections'][number]>) => c.setProposal((pr) => (pr ? { ...pr, sections: pr.sections.map((x, j) => (j === i ? { ...x, ...p } : x)) } : pr))
  const info = formatInfo(format)
  return (
    <>
      <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.xs }}>1 · What kind of output?</Text>
      <Row gutter={[SP.sm, SP.sm]} style={{ marginBottom: SP.base }}>
        {OUTPUT_FORMATS.map((f) => (
          <Col key={f.key} span={8}>
            <Card hoverable size="small" onClick={() => c.say(`A ${FORMAT_LABEL[f.key].toLowerCase()}`)} style={{ height: '100%', borderColor: format === f.key ? BRAND : undefined, background: format === f.key ? BRAND_SOFT : undefined }} styles={{ body: { padding: `${SP.sm}px ${SP.md}px` } }}>
              <Flex align="center" gap={SP.xs}><span style={{ color: BRAND_INK, fontSize: 16 }}>{FORMAT_ICON[f.key]}</span><Text style={{ fontWeight: 500, fontSize: 13 }}>{FORMAT_LABEL[f.key]}</Text>{format === f.key ? <CheckOutlined style={{ color: BRAND, marginLeft: 'auto' }} /> : null}</Flex>
              <Text type="secondary" style={{ display: 'block', fontSize: 11.5, marginTop: 4, lineHeight: 1.35 }}>{f.goodFor}</Text>
            </Card>
          </Col>
        ))}
      </Row>
      <Flex justify="space-between" align="center" style={{ marginBottom: SP.xs }}>
        <Text style={{ fontSize: 13 }}>2 · What should the {FORMAT_LABEL[format].toLowerCase()} cover, for this goal?</Text>
        {examples.length ? <Space size={4}>{examples.map((e) => <Button key={e.format} size="small" type="link" style={{ padding: 0 }} onClick={() => { c.setFormat(e.format); c.say(`Example: ${FORMAT_LABEL[e.format].toLowerCase()}`) }}>Example: {FORMAT_LABEL[e.format].toLowerCase()}</Button>)}</Space> : null}
      </Flex>
      <Input.TextArea value={text} onChange={(e) => { c.setText(e.target.value); c.setProposal(() => null) }} autoSize={{ minRows: 3, maxRows: 7 }} placeholder={`In your own words, here or in the chat: who it is for and what it should show.`} style={{ marginBottom: SP.sm }} />
      <Space wrap style={{ marginBottom: SP.base }}>
        <Button type="primary" ghost icon={<BulbOutlined />} loading={thinking} disabled={text.trim().length < 12} onClick={c.propose}>{proposal ? `Ask ${g.agent.name} again` : `Let ${g.agent.name} propose the structure`}</Button>
        <Button onClick={() => c.say(`Start a blank ${FORMAT_LABEL[format].toLowerCase()}`)}>Start blank, write it myself</Button>
      </Space>
      {proposal ? (
        <>
          <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.xs }}>3 · {g.agent.name} read your description as {proposal.sections.length} {info.unit}{proposal.sections.length === 1 ? '' : 's'}{proposal.audience ? `, for ${proposal.audience.replace(/^The /, 'the ')}` : ''}. Change anything.</Text>
          <Flex vertical gap={SP.xs} style={{ marginBottom: SP.sm }}>
            {proposal.sections.map((sec, i) => (
              <Flex key={i} gap={SP.xs} align="center">
                <Text type="secondary" style={{ width: 22, fontSize: 12 }}>{i + 1}</Text>
                <Input value={sec.heading} onChange={(e) => setSec(i, { heading: e.target.value })} style={{ flex: 1 }} />
                <Select value={sec.role} onChange={(v) => setSec(i, { role: v })} options={ROLES} style={{ width: 190 }} />
                <Tooltip title={sec.because ? `From your words: "${sec.because}"` : `What a ${FORMAT_LABEL[format].toLowerCase()} always needs`}><Tag style={{ marginInlineEnd: 0, width: 64, textAlign: 'center' }}>{sec.because ? 'yours' : 'format'}</Tag></Tooltip>
                <Button type="text" danger onClick={() => c.say(`Remove ${i + 1}`)}>×</Button>
              </Flex>
            ))}
          </Flex>
          <Button size="small" icon={<PlusOutlined />} onClick={() => c.setProposal((pr) => (pr ? { ...pr, sections: [...pr.sections, { heading: `New ${info.unit}`, role: 'free' }] } : pr))}>Add a {info.unit}</Button>
          <Button type="primary" block style={{ marginTop: SP.lg }} disabled={!proposal.sections.length} onClick={() => c.say('Create it')}>Create the {FORMAT_LABEL[format].toLowerCase()}</Button>
        </>
      ) : null}
    </>
  )
}

const NEUTRAL_AGENT = { name: 'Your agents', icon: 'bulb', colour: '#4b5a75' }

/** A new submission, in two panes: the choices on the left, the agent on the right. Every choice can be clicked or said. */
export function NewSubmissionPage() {
  const goals = useGoalStore((s) => s.goals)
  const ready = goals.filter((g) => g.findings.length)
  const templates = useSubmissionStore((s) => s.templates)
  const { startFromGoal, startFromTemplate, startDescribed, addTemplate } = useSubmissionStore()
  const me = useAuthStore((s) => s.identity?.name) ?? 'You'
  const navigate = useNavigate()
  const location = useLocation()
  const initial = (location.state as { newFromGoal?: string; describe?: boolean } | null) ?? null
  const [mode, setMode] = useState<'goal' | 'template'>('goal')
  const [path, setPath] = useState<'recommend' | 'describe'>(initial?.describe ? 'describe' : 'recommend')
  const [goalId, setGoalId] = useState<string | undefined>(initial?.newFromGoal)
  const [templateId, setTemplateId] = useState<string | undefined>()
  const [goalIds, setGoalIds] = useState<string[]>([])
  const [format, setFormat] = useState<OutputFormat>('Slide pack')
  const [text, setText] = useState('')
  const [proposal, setProposalRaw] = useState<OutlineProposal | null>(null)
  const [thinking, setThinking] = useState(false)
  const setProposal = (fn: (p: OutlineProposal | null) => OutlineProposal | null) => setProposalRaw(fn)
  const g = goals.find((x) => x.id === goalId)
  const agent = g?.agent ?? NEUTRAL_AGENT
  const chat = useSubChat((s) => s.chats.new) ?? []
  const typing = useSubChat((s) => !!s.typing.new)
  const offered = g ? g.submissions.filter((x) => templates.some((t) => t.id === x.templateId)) : []
  const tpl = templates.find((t) => t.id === templateId)
  const live = useRef({ mode, path, goalId, templateId, goalIds, format, text, proposal })
  live.current = { mode, path, goalId, templateId, goalIds, format, text, proposal }
  const go = (id: string) => navigate(appPath(`/submissions/${id}`))
  const unitOf = (f: OutputFormat) => formatInfo(f).unit

  const recList = (gg: Goal) => {
    const off = gg.submissions.filter((x) => templates.some((t) => t.id === x.templateId))
    return off.length ? `Based on the templates in your library I recommend:\n${off.map((x, i) => `${i + 1}. ${x.label}`).join('\n')}\n\nSay "start 1", or "describe a new output" if none fits.` : 'None of the templates in your library fits this goal. Say "describe a new output" and I will propose a structure.'
  }
  const goalList = () => ready.map((x, i) => `${i + 1}. ${x.title} (${x.agent.name})`).join('\n')

  /* Open the conversation once per visit. */
  useEffect(() => {
    const gg = goals.find((x) => x.id === initial?.newFromGoal)
    const open = gg
      ? initial?.describe
        ? [smsg('agent', `A new output for "${gg.title}". What kind: slide pack, dashboard, document, memo, spreadsheet or email? Then tell me in a sentence or two what it should cover, or say "example".`)]
        : [smsg('agent', `For "${gg.title}". ${recList(gg)}`)]
      : [smsg('agent', `What do you need to send? Pick the goal it comes from and I show what its agent recommends, or describe something new. You can also start from a template, or attach your own template file with the clip.\n\nGoals with findings:\n${goalList()}\n\nSay "goal 1", or "from a template".`)]
    useSubChat.getState().reset('new', open)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.key])

  const propose = (f = live.current.format, words = live.current.text, gg = g) => {
    if (!gg) return
    setThinking(true)
    setProposalRaw(null)
    useSubChat.getState().setTyping('new', true)
    window.setTimeout(() => {
      const p = designOutline(f, words, gg)
      setProposalRaw(p)
      setThinking(false)
      useSubChat.getState().setTyping('new', false)
      useSubChat.getState().say('new', 'agent', `I read it as ${p.sections.length} ${unitOf(f)}s${p.audience ? ` for ${p.audience.replace(/^The /, 'the ')}` : ''}:\n${p.sections.map((x, i) => `${i + 1}. ${x.heading}`).join('\n')}\n\nChange anything: "remove 3", "rename 2 to …", "add a ${unitOf(f)} on …". Or say "create it".`)
    }, 1400)
  }

  const act = (raw: string) => {
    const L = live.current
    const say = (t: string) => useSubChat.getState().say('new', 'agent', t)
    const gg = goals.find((x) => x.id === L.goalId)
    const it = interpretNew(raw, { mode: L.mode, path: L.path, hasProposal: !!L.proposal, goals: ready })
    switch (it.k) {
      case 'help':
        say('You can say: "goal 1", "what do you recommend?", "start 1", "describe a new output", "a slide pack: …", "example", "remove 3", "create it", "from a template", "template 2", "both goals", "start". Or attach a template file.')
        return
      case 'fromGoal': {
        setMode('goal')
        const pick = it.goal ?? gg ?? ready[0]
        if (!pick) { say('No goal has findings yet.'); return }
        setGoalId(pick.id)
        setPath('recommend')
        setProposalRaw(null)
        say(`"${pick.title}", worked by ${pick.agent.name}. ${recList(pick)}`)
        return
      }
      case 'fromTemplate':
        setMode('template')
        say(`Which template? Say its number or name.\n${templates.map((t, i) => `${i + 1}. ${t.name} (${FORMAT_LABEL[t.format]})`).join('\n')}`)
        return
      case 'recommend':
        if (!gg) { say(`Which goal first?\n${goalList()}`); return }
        setPath('recommend')
        say(recList(gg))
        return
      case 'startRec': {
        if (!gg) { say(`Which goal first?\n${goalList()}`); return }
        const offs = gg.submissions.filter((x) => templates.some((t) => t.id === x.templateId))
        const s = it.n ? offs[it.n - 1] : bestMatch(it.words ?? '', offs, (x) => x.label) ?? offs[0]
        if (!s) { say('None of the templates in your library fits. Say "describe a new output".'); return }
        say(`Starting "${s.label}".`)
        window.setTimeout(() => go(startFromGoal(gg, s, me)), 600)
        return
      }
      case 'describe':
        if (!gg) { say(`For which goal?\n${goalList()}`); setPath('describe'); return }
        setMode('goal')
        setPath('describe')
        say('What kind of output: slide pack, dashboard, document, memo, spreadsheet or email? Then tell me in a sentence or two what it should cover, or say "example".')
        return
      case 'format': {
        if (!gg) { say(`For which goal?\n${goalList()}`); return }
        setMode('goal')
        setPath('describe')
        setFormat(it.f)
        setProposalRaw(null)
        const rest = it.rest.replace(/^(an?|the)\s+[\w-]+(\s+pack)?\s*[:,.-]?\s*/i, '').trim()
        if (rest.length > 30) { setText(it.rest); propose(it.f, it.rest, gg); return }
        say(`A ${FORMAT_LABEL[it.f].toLowerCase()}. What should it cover? Say it in your own words, or say "example".`)
        return
      }
      case 'example': {
        if (!gg) { say(`For which goal?\n${goalList()}`); return }
        const exs = EXAMPLE_BRIEFS[gg.exampleOf ?? gg.id] ?? []
        const ex = exs.find((e) => e.format === L.format) ?? exs[0]
        if (!ex) { say('No example for this goal. Describe it in your own words.'); return }
        setMode('goal'); setPath('describe'); setFormat(ex.format); setText(ex.text)
        say(`Here is an example ${FORMAT_LABEL[ex.format].toLowerCase()} brief: "${ex.text}"`)
        propose(ex.format, ex.text, gg)
        return
      }
      case 'text':
        if (!gg) { say(`For which goal?\n${goalList()}`); return }
        setText(it.v)
        propose(L.format, it.v, gg)
        return
      case 'remove': {
        const p = L.proposal!
        if (!p.sections[it.n - 1]) { say(`There is no ${unitOf(L.format)} ${it.n}.`); return }
        const next = { ...p, sections: p.sections.filter((_, i) => i !== it.n - 1) }
        setProposalRaw(next)
        say(`Removed. Now ${next.sections.length} ${unitOf(L.format)}s. Say "create it" when ready.`)
        return
      }
      case 'rename': {
        const p = L.proposal!
        if (!p.sections[it.n - 1]) { say(`There is no ${unitOf(L.format)} ${it.n}.`); return }
        setProposalRaw({ ...p, sections: p.sections.map((x, i) => (i === it.n - 1 ? { ...x, heading: it.v } : x)) })
        say(`${FORMAT_LABEL[L.format] === 'Slide pack' ? 'Slide' : 'Section'} ${it.n} is now "${it.v}".`)
        return
      }
      case 'add': {
        const p = L.proposal!
        setProposalRaw({ ...p, sections: [...p.sections, { heading: it.heading, role: roleOf(it.heading), because: it.heading }] })
        say(`Added as ${unitOf(L.format)} ${p.sections.length + 1}: "${it.heading}".`)
        return
      }
      case 'create':
        if (!gg || !L.proposal) return
        say(`Creating the ${FORMAT_LABEL[L.format].toLowerCase()}.`)
        window.setTimeout(() => go(startDescribed(gg, L.text.trim(), L.proposal!, me)), 600)
        return
      case 'blank': {
        if (!gg) { say(`For which goal?\n${goalList()}`); return }
        const p = designOutline(L.format, '', gg)
        say(`Starting a blank ${FORMAT_LABEL[L.format].toLowerCase()} with the usual ${unitOf(L.format)}s; you write each one, by hand on the left or here with "write 2: …".`)
        window.setTimeout(() => {
          const id = startDescribed(gg, 'Started blank, written by hand.', p, me)
          const st = useSubmissionStore.getState()
          const sub = st.submissions.find((x) => x.id === id)
          if (sub) st.setSections(id, sub.sections.map((x) => ({ ...x, body: '', from: 'You' })))
          go(id)
        }, 600)
        return
      }
      case 'template': {
        const t = it.n ? templates[it.n - 1] : bestMatch(it.words ?? '', templates, (x) => `${x.name} ${x.family}`)
        if (!t) { say(`Which one? Say its number:\n${templates.map((x, i) => `${i + 1}. ${x.name}`).join('\n')}`); return }
        setMode('template')
        setTemplateId(t.id)
        say(L.goalIds.length ? `Template "${t.name}". Say "start".` : `Template "${t.name}", ${t.sections.length} sections. Which goal does it draw on?\n${goalList()}\n\nSay "goal 1", "goal 2" or "both goals".`)
        return
      }
      case 'goals': {
        setGoalIds(it.goals.map((x) => x.id))
        say(`Draws on ${it.goals.map((x) => `"${x.title}"`).join(' and ')}. ${L.templateId ? 'Say "start".' : 'Which template?'}`)
        return
      }
      case 'start': {
        const t = templates.find((x) => x.id === L.templateId)
        const gs = L.goalIds.map((i) => goals.find((x) => x.id === i)).filter(Boolean) as Goal[]
        if (!t) { say('Which template first?'); return }
        if (!gs.length) { say(`Which goal does it draw on?\n${goalList()}`); return }
        say(`Starting from "${t.name}".`)
        window.setTimeout(() => go(startFromTemplate(t, gs, me)), 600)
        return
      }
      default:
        say(L.mode === 'template' ? 'Say a template number or name, then which goals it draws on, then "start".' : !gg ? `Which goal is it for?\n${goalList()}` : L.path === 'describe' ? 'Tell me what it should cover, in a sentence or two, or say "example".' : 'Say "start 1", or "describe a new output".')
    }
  }

  const send = (text0: string) => {
    useSubChat.getState().say('new', 'me', text0)
    useSubChat.getState().setTyping('new', true)
    window.setTimeout(() => { useSubChat.getState().setTyping('new', false); act(text0) }, 450 + Math.random() * 350)
  }

  /* A template file dropped into the chat: read its structure, add it to the library, and use it. */
  const upload = async (file: File) => {
    const c = useSubChat.getState()
    c.say('new', 'me', 'Here is a template I want to use.', { name: file.name, size: file.size })
    c.setTyping('new', true)
    const r = await readUpload(file)
    const t = templateFromRead(r)
    window.setTimeout(() => {
      c.setTyping('new', false)
      addTemplate(t, me)
      setMode('template')
      setTemplateId(t.id)
      c.say('new', 'agent', `Read ${r.name}: ${describeRead(r)}. It is in your library now as "${t.name}" (${FORMAT_LABEL[t.format]}), with these sections:\n${t.sections.map((x, i) => `${i + 1}. ${x.heading}`).join('\n')}\n\n${live.current.goalIds.length ? 'Say "start".' : `Which goal does it draw on?\n${goalList()}`}`)
    }, 900)
  }

  const chips = mode === 'template'
    ? (!templateId ? ['Template 1', 'Template 2', 'From a goal'] : !goalIds.length ? ready.map((_, i) => `Goal ${i + 1}`).concat(ready.length > 1 ? ['Both goals'] : []) : ['Start'])
    : !g ? ready.map((_, i) => `Goal ${i + 1}`).concat(['From a template'])
    : path === 'recommend' ? (offered.length ? offered.map((_, i) => `Start ${i + 1}`).concat(['Describe a new output']) : ['Describe a new output'])
    : proposal ? ['Create it', 'Remove 1', `Add a ${unitOf(format)} on next steps`]
    : ['Example', 'A slide pack', 'A dashboard', 'A memo']

  const dc: DescribeCtl = { format, text, proposal, thinking, setFormat: (f) => { setFormat(f); setProposalRaw(null) }, setText, setProposal, propose: () => { send(text) }, create: () => send('Create it'), say: send }

  return (
    <TwoPane left={(
      <div className="sbw">
        <span className="gw-back" role="link" onClick={() => navigate(appPath('/submissions'))}>← Submissions</span>
        <div className="gw-title" style={{ marginBottom: SP.base }}>New submission</div>
        <Radio.Group value={mode} onChange={(e) => send(e.target.value === 'goal' ? 'From a goal' : 'From a template')} optionType="button" style={{ marginBottom: SP.lg }}
          options={[{ label: 'From a goal', value: 'goal' }, { label: 'From a template', value: 'template' }]} />
        {mode === 'goal' ? (
          <>
            <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.xs }}>Which goal?</Text>
            <Flex vertical gap={SP.xs} style={{ marginBottom: SP.base }}>
              {ready.map((x, i) => (
                <div key={x.id} className={`gw-card${goalId === x.id ? ' gw-focus' : ''}`} style={{ ['--agent' as string]: x.agent.colour }} onClick={() => send(`Goal ${i + 1}`)}>
                  <Flex gap={SP.sm} align="center"><span className={`gw-num${goalId === x.id ? ' is-on' : ''}`}>{i + 1}</span><Text style={{ fontSize: 13.5, fontWeight: 500, flex: 1 }}>{x.title}</Text><Text style={{ fontSize: 12, color: x.agent.colour }}>{x.agent.name}</Text></Flex>
                </div>
              ))}
            </Flex>
            {g ? (
              <>
                <Radio.Group value={path} onChange={(e) => send(e.target.value === 'describe' ? 'Describe a new output' : 'What do you recommend?')} optionType="button" size="small" style={{ marginBottom: SP.base }}
                  options={[{ label: `Use a recommendation (${offered.length})`, value: 'recommend' }, { label: 'Describe a new output', value: 'describe' }]} />
                {path === 'recommend' ? (
                  <Flex vertical gap={SP.sm}>
                    <Text style={{ fontSize: 13 }}><BulbOutlined style={{ color: BRAND }} /> Based on the templates in your library, {g.agent.name} recommends</Text>
                    {offered.map((x, i) => {
                      const t = templates.find((tt) => tt.id === x.templateId)!
                      return (
                        <div key={x.id} className="gw-card" style={{ cursor: 'default' }}>
                          <Flex gap={SP.sm} align="flex-start">
                            <span className="gw-num">{i + 1}</span>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <Text style={{ fontWeight: 500 }}>{x.label}</Text>
                              <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>To {x.audience}</Text>
                              <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>{x.why}</Text>
                              <Tag icon={FORMAT_ICON[t.format]} color="success" style={{ marginTop: 4 }}>Template in your library: {t.name}</Tag>
                            </div>
                            <Button size="small" type="primary" onClick={() => send(`Start ${i + 1}`)}>Start</Button>
                          </Flex>
                        </div>
                      )
                    })}
                    {!offered.length ? <Text type="secondary" style={{ fontSize: 12.5 }}>None of the templates in your library fits this goal. Describe the output you want instead.</Text> : null}
                  </Flex>
                ) : <DescribeOutput g={g} c={dc} />}
              </>
            ) : null}
          </>
        ) : (
          <>
            <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.xs }}>Which template? (or attach your own in the chat)</Text>
            <Row gutter={[SP.sm, SP.sm]} style={{ marginBottom: SP.base }}>
              {templates.map((t, i) => <Col key={t.id} span={12}><TemplateCard t={t} compact selected={templateId === t.id} onPick={() => send(`Template ${i + 1}`)} /></Col>)}
            </Row>
            <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.xs }}>Which goals does it draw on?</Text>
            <Select mode="multiple" style={{ width: '100%' }} value={goalIds} onChange={setGoalIds} options={ready.map((x) => ({ value: x.id, label: `${x.title} · ${x.agent.name}` }))} placeholder="Pick one or more goals with findings" />
            <Button type="primary" block style={{ marginTop: SP.lg }} disabled={!tpl || !goalIds.length} onClick={() => send('Start')}>Start</Button>
          </>
        )}
      </div>
    )} right={<ChatPane agent={agent as Goal['agent']} messages={chat} typing={typing} chips={chips} onSend={send} onUpload={upload} accept=".pptx,.docx,.txt,.md,.pdf,.xlsx" title="new submission" placeholder="Say what you need to send, or attach a template" />} />
  )
}

/* ------------------------------------------------------------------ list */

/** One submission as a card: what it is, who it is for, the goals it draws on, and where it is in the five steps. */
export function SubmissionCard({ s, goals, onOpen }: { s: Submission; goals: Goal[]; onOpen: () => void }) {
  const linked = s.goalIds.map((id) => goals.find((g) => g.id === id)).filter((g): g is Goal => !!g)
  const idx = STAGES.indexOf(s.stage)
  return (
    <Card hoverable size="small" className="sb-card" onClick={onOpen} styles={{ body: { padding: `${SP.base}px ${SP.lg}px`, height: '100%', display: 'flex', flexDirection: 'column' } }}>
      <Flex justify="space-between" align="center" gap={SP.sm}>
        <Text type="secondary" style={{ fontSize: 12.5, whiteSpace: 'nowrap' }}><span style={{ color: BRAND_INK }}>{FORMAT_ICON[s.format]}</span> {FORMAT_LABEL[s.format]}{s.origin === 'described' ? ' · described' : s.origin === 'recommendation' ? ' · recommended' : ''}{s.agentName ? ` · ${s.agentName}` : ''}</Text>
        <Space size={4}>{s.format === 'Dashboard' ? <Tag color="processing" style={{ marginInlineEnd: 0 }}>Live</Tag> : null}<Tag color={s.stage === 'reviewed' ? 'success' : s.stage === 'draft' ? 'processing' : 'default'} style={{ marginInlineEnd: 0 }}>{STAGE_LABEL[s.stage]}</Tag></Space>
      </Flex>
      <Text style={{ display: 'block', fontSize: 15, fontWeight: 500, lineHeight: 1.3, margin: `${SP.sm}px 0 ${SP.xs}px` }}>{s.title || 'Untitled'}</Text>
      <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>To: {s.audience || 'Not stated'}</Text>
      <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>Template: {s.template || 'Not chosen yet'}</Text>
      <div style={{ marginTop: SP.md }}>
        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.3, display: 'block', marginBottom: 4 }}>Draws on</Text>
        <Flex vertical gap={4}>
          {linked.length ? linked.map((g) => (
            <Flex key={g.id} align="center" gap={6} className="sb-goal">
              <span className="sb-goal-icon" style={{ background: `${g.agent.colour}18`, color: g.agent.colour }}><AimOutlined /></span>
              <Text style={{ fontSize: 12.5, flex: 1, minWidth: 0 }} ellipsis>{g.title}</Text>
              <Text style={{ fontSize: 12, color: g.agent.colour, whiteSpace: 'nowrap' }}>{g.agent.name}</Text>
            </Flex>
          )) : <Text type="secondary" style={{ fontSize: 12.5 }}>No goal linked</Text>}
        </Flex>
      </div>
      <Flex align="center" gap={SP.xs} style={{ marginTop: 'auto', paddingTop: SP.sm, borderTop: '1px solid #e9ecf1' }}>
        <Text type="secondary" style={{ fontSize: 12, flex: 1 }} ellipsis>{s.createdBy} · {new Date(s.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</Text>
        <Flex gap={4} align="center">
          {STAGES.map((st, i) => <Tooltip key={st} title={STAGE_LABEL[st]}><span className={`g-dot${i <= idx ? ' is-done' : ''}${i === idx ? ' is-now' : ''}`} /></Tooltip>)}
        </Flex>
        <ArrowRightOutlined style={{ color: BRAND }} />
      </Flex>
    </Card>
  )
}

export function SubmissionList() {
  const submissions = useSubmissionStore((s) => s.submissions)
  const goals = useGoalStore((s) => s.goals)
  const navigate = useNavigate()
  const location = useLocation()
  const initial = (location.state as { newFromGoal?: string; describe?: boolean; tab?: string } | null) ?? null
  const [tab, setTab] = useState(initial?.tab ?? 'submissions')
  useEffect(() => { if (initial?.tab) setTab(initial.tab) }, [initial])
  return (
    <>
      <PageHeader
        title="Submissions"
        subtitle="Documents your audiences expect, drafted from your goals. Every submission ties back to the goals it draws on."
        actions={<Button type="primary" icon={<PlusOutlined />} onClick={() => navigate(appPath('/submissions/new'))}>New submission</Button>}
      />
      <Tabs activeKey={tab} onChange={setTab} items={[
        {
          key: 'submissions',
          label: `Submissions${submissions.length ? ` · ${submissions.length}` : ''}`,
          children: !submissions.length ? (
            <Card size="small">
              <Text>Nothing drafted yet. Start one from a goal’s Submissions tab, or with "New submission" from a goal or a template.</Text>
            </Card>
          ) : (
            <Row gutter={[SP.base, SP.base]}>
              {submissions.map((sub) => (
                <Col key={sub.id} xs={24} md={12} xl={8}>
                  <SubmissionCard s={sub} goals={goals} onOpen={() => navigate(appPath(`/submissions/${sub.id}`))} />
                </Col>
              ))}
            </Row>
          ),
        },
        { key: 'templates', label: 'Templates', children: <TemplateLibrary /> },
      ]} />
    </>
  )
}

/* ------------------------------------------------------------------ detail */

/** The draft as the reader will see it, in the shape of its format: slides, dashboard panels, sheets, or prose. */
export function buildDraft(s: Submission): string {
  const date = new Date().toLocaleDateString('en-GB', { dateStyle: 'long' })
  const secs = s.sections.filter((x) => x.included)
  const body = (x: Section) => esc(x.body || '(to be written)')
  const g0 = goalsOf(s)
  const vis = (x: Section) => { const v = g0 ? visualForFormat(g0, x.role, x.heading, s.format) : null; return v ? visualHtml(v) : '' }
  const common = `${VISUAL_CSS}body{font:14px/1.55 -apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#0f1729;margin:32px auto;padding:0 24px}.draft{border:1px solid #b45309;color:#b45309;border-radius:6px;padding:8px 12px;font-size:13px;margin-bottom:18px}h1{font-size:24px;letter-spacing:-.4px;margin:0 0 4px}h2{font-size:16px;margin:24px 0 6px}.meta{color:#4b5a75;font-size:13px}p{white-space:pre-wrap;margin:6px 0}.src{font-size:11.5px;color:#8994a8}@media print{body{margin:0}}`
  const head = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${esc(s.title)} · DRAFT</title>`
  const banner = `<div class="draft">DRAFT, not approved. Prepared with Context Weave from "${esc(s.fromGoal?.title ?? 'no goal')}" as a ${esc(FORMAT_LABEL[s.format].toLowerCase())}${s.templateId ? ` following "${esc(s.template)}"` : ' defined from the author’s description'}. Assumptions and open items are stated inside.</div>`
  const meta = `<div class="meta">To ${esc(s.audience)} · ${esc(FORMAT_LABEL[s.format])} · ${esc(date)} · prepared by ${esc(s.createdBy)}${s.reviewedBy ? ` · reviewed by ${esc(s.reviewedBy)}` : ''}</div>`
  if (s.format === 'Slide pack') {
    return `${head}<style>${common}body{max-width:1040px}.slide{border:1px solid #d9dde6;border-radius:10px;padding:28px 36px;margin:18px 0;min-height:260px;position:relative;background:#fff}.slide h2{margin:0 0 14px;font-size:22px}.two{display:grid;grid-template-columns:1fr 1.2fr;gap:18px;align-items:start}.n{position:absolute;right:16px;bottom:10px;font-size:11px;color:#8994a8}</style></head><body>${banner}<h1>${esc(s.title)}</h1>${meta}
${secs.map((x, i) => { const v = vis(x); return `<section class="slide"><h2>${esc(x.heading)}</h2>${v ? `<div class="two"><p>${esc(short(x.body))}</p>${v}</div>` : `<p>${body(x)}</p>`}<div class="src">Source: ${esc(x.from)}</div><span class="n">${i + 1} / ${secs.length}</span></section>` }).join('')}</body></html>`
  }
  if (s.format === 'Dashboard') {
    const secs = s.sections.filter((x) => x.included && x.role !== 'evidence')
    return `${head}<style>${common}body{max-width:1180px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px;margin-top:16px}.panel{border:1px solid #d9dde6;border-radius:10px;padding:16px 18px;background:#fff}.panel.wide{grid-column:1/-1}.panel h2{margin:0 0 8px;font-size:14px;text-transform:uppercase;letter-spacing:.3px;color:#4b5a75}.tiles{display:flex;gap:12px;flex-wrap:wrap}.tile{flex:1 1 180px;background:#f6f7fa;border-radius:8px;padding:12px 14px}.tile b{display:block;font-size:20px;color:#0f1729}.tile span{font-size:12px;color:#4b5a75}</style></head><body>${banner}<h1>${esc(s.title)}</h1>${meta}<div class="grid">
${secs.map((x) => x.role === 'summary' ? `<div class="panel wide"><h2>${esc(x.heading)}</h2>${vis(x)}<div class="tiles">${(x.body.match(/[^\n]*(\$[\d.,]+[MBK]?|\d+(?:\.\d+)?%)[^\n]*/g) ?? []).slice(0, 4).map((line) => { const m = line.match(/\$[\d.,]+[MBK]?|\d+(?:\.\d+)?%/); return `<div class="tile"><b>${esc(m?.[0] ?? '')}</b><span>${esc(line.replace(m?.[0] ?? '', '').replace(/^[\s:·,-]+|[\s:·,-]+$/g, '').slice(0, 80))}</span></div>` }).join('') || `<p>${body(x)}</p>`}<div class="src">Source: ${esc(x.from)}</div></div>` : `<div class="panel${x.role === 'findings' || x.role === 'options' ? ' wide' : ''}"><h2>${esc(x.heading)}</h2>${vis(x)}<p>${esc(vis(x) ? short(x.body) : x.body || '(to be written)')}</p><div class="src">Source: ${esc(x.from)}</div></div>`).join('')}</div><div class="meta" style="margin-top:14px">Live dashboard · reads the goal’s data each time it opens · data as of ${esc(DRILL.as_of)} · where each panel’s data comes from: Submissions › this dashboard › Data lineage</div></body></html>`
  }
  if (s.format === 'Workbook') {
    return `${head}<style>${common}body{max-width:1040px}.tabs{display:flex;gap:4px;margin:16px 0 0;flex-wrap:wrap}.tab{border:1px solid #d9dde6;border-bottom:none;border-radius:8px 8px 0 0;padding:6px 12px;font-size:12.5px;background:#f6f7fa}.sheet{border:1px solid #d9dde6;padding:16px 18px;margin-bottom:18px;background:#fff}.sheet h2{margin:0 0 8px;font-size:15px}table{border-collapse:collapse;width:100%;font-size:13px}td{border:1px solid #e3e6ec;padding:6px 8px;vertical-align:top;white-space:pre-wrap}td:first-child{width:36px;color:#8994a8;background:#f6f7fa;text-align:right}</style></head><body>${banner}<h1>${esc(s.title)}</h1>${meta}<div class="tabs">${secs.map((x) => `<span class="tab">${esc(x.heading)}</span>`).join('')}</div>
${secs.map((x) => `<section class="sheet"><h2>${esc(x.heading)}</h2>${vis(x)}<table>${(x.body || '(to be written)').split('\n').filter(Boolean).map((row, i) => `<tr><td>${i + 1}</td><td>${esc(row)}</td></tr>`).join('')}</table><div class="src">Source: ${esc(x.from)}</div></section>`).join('')}</body></html>`
  }
  if (s.format === 'Email') {
    const [first, ...rest] = secs
    return `${head}<style>${common}body{max-width:680px}.mail{border:1px solid #d9dde6;border-radius:10px;padding:18px 22px;background:#fff}.hdr{font-size:13px;color:#4b5a75;border-bottom:1px solid #e3e6ec;padding-bottom:10px;margin-bottom:14px}.hdr b{color:#0f1729}h2{font-size:13px;text-transform:uppercase;letter-spacing:.3px;color:#4b5a75;margin:16px 0 4px}</style></head><body>${banner}<div class="mail"><div class="hdr"><div><b>To:</b> ${esc(s.audience)}</div><div><b>From:</b> ${esc(s.createdBy)}</div><div><b>Subject:</b> ${esc(first?.heading ?? s.title)}</div></div><p>${body(first ?? { body: '', from: 'You' } as Section)}</p>${rest.map((x) => `<h2>${esc(x.heading)}</h2><p>${body(x)}</p><div class="src">Source: ${esc(x.from)}</div>`).join('')}</div></body></html>`
  }
  const memo = s.format === 'Memo'
  return `${head}<style>${common}body{max-width:${memo ? 720 : 820}px}${memo ? 'h2{font-size:14px;text-transform:uppercase;letter-spacing:.3px;color:#4b5a75;margin:18px 0 4px}' : ''}</style></head><body>${banner}<h1>${esc(s.title)}</h1>${meta}
${secs.map((x) => `<h2>${esc(x.heading)}</h2><p>${body(x)}</p>${x.role === 'findings' || x.role === 'summary' ? vis(x) : ''}<div class="src">Source: ${esc(x.from)}</div>`).join('')}
</body></html>`
}

/** The first goal a submission draws on, read from the goal store at call time. */
const goalsOf = (s: Submission): Goal | null => useGoalStore.getState().goals.find((g) => g.id === s.goalIds[0]) ?? null
/** The first paragraph or so of a section, for a slide or a panel that also carries a picture. */
export const short = (body: string, n = 420) => { const t = body.trim(); if (!t) return '(to be written)'; const cut = t.length > n ? `${t.slice(0, t.lastIndexOf(' ', n))}…` : t; return cut }

/** A visual on screen: the picture, a table view on demand, the note. */
export function VisualBlock({ v, compact }: { v: Visual; compact?: boolean }) {
  const [asTable, setAsTable] = useState(false)
  const table = tableOf(v)
  return (
    <figure className="sb-vis">
      <Flex justify="space-between" align="center" gap={SP.xs}>
        <Text type="secondary" style={{ fontSize: 11.5, textTransform: 'uppercase', letterSpacing: 0.3 }}>{v.title}</Text>
        {table && v.kind !== 'table' ? <Button type="link" size="small" className="no-print" icon={<TableOutlined />} style={{ padding: 0, fontSize: 11.5 }} onClick={() => setAsTable((x) => !x)}>{asTable ? 'Chart' : 'Table'}</Button> : null}
      </Flex>
      {v.kind === 'kpis' ? (
        <Flex gap={SP.sm} wrap style={{ marginTop: SP.xs }}>
          {(v.data as { items: { label: string; value: string }[] }).items.slice(0, 4).map((i) => <div key={i.label} className="sb-tile"><Text style={{ display: 'block', fontSize: compact ? 17 : 20, fontWeight: 600 }}>{i.value}</Text><Text type="secondary" style={{ fontSize: 12 }}>{i.label}</Text></div>)}
        </Flex>
      ) : asTable || v.kind === 'table' ? (
        table ? <table className="sb-vt"><thead><tr>{table.columns.map((c) => <th key={c}>{c}</th>)}</tr></thead><tbody>{table.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{String(c)}</td>)}</tr>)}</tbody></table> : null
      ) : v.svg ? (
        <div className="sb-svg" dangerouslySetInnerHTML={{ __html: v.svg }} />
      ) : null}
      <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: SP.xs }}>{v.note}</Text>
    </figure>
  )
}

/** The draft on screen, in the shape of its format. */
function DraftView({ s, included }: { s: Submission; included: Section[] }) {
  const empty = (x: Section) => !x.body.trim()
  const g0 = useGoalStore((st) => st.goals.find((g) => g.id === s.goalIds[0]) ?? null)
  const vis = (x: Section) => (g0 ? visualFor(g0, x.role, x.heading) : null)
  const para = (x: Section) => <Paragraph style={{ whiteSpace: 'pre-wrap', fontSize: 13.5, marginBottom: SP.xs, color: empty(x) ? STATUS.warn : undefined }}>{x.body.trim() || '(still to be written)'}</Paragraph>
  const src = (x: Section) => <Text type="secondary" style={{ fontSize: 11.5 }}>Source: {x.from}</Text>
  if (s.format === 'Slide pack') return (
    <Flex vertical gap={SP.base}>
      {included.map((x, i) => (
        <Card key={x.id} size="small" className="sb-slide" styles={{ body: { padding: `${SP.lg}px ${SP.xl}px`, minHeight: 180 } }}>
          <Title level={4} style={{ margin: `0 0 ${SP.sm}px`, fontWeight: 600 }}>{x.heading}</Title>
          {(() => { const v = vis(x); return v ? (
            <Row gutter={[SP.lg, SP.sm]}>
              <Col xs={24} md={11}><Paragraph style={{ whiteSpace: 'pre-wrap', fontSize: 13, marginBottom: SP.xs, color: empty(x) ? STATUS.warn : undefined }}>{short(x.body)}</Paragraph></Col>
              <Col xs={24} md={13}><VisualBlock v={v} /></Col>
            </Row>
          ) : para(x) })()}
          {src(x)}
          <Text type="secondary" style={{ position: 'absolute', right: 14, bottom: 8, fontSize: 11 }}>{i + 1} / {included.length}</Text>
        </Card>
      ))}
    </Flex>
  )
  if (s.format === 'Dashboard') return (
    <Row gutter={[SP.base, SP.base]}>
      {included.filter((x) => x.role !== 'evidence').map((x) => {
        const wide = x.role === 'summary' || x.role === 'findings' || x.role === 'options'
        const tiles = x.role === 'summary' ? (x.body.match(/[^\n]*(\$[\d.,]+[MBK]?|\d+(?:\.\d+)?%)[^\n]*/g) ?? []).slice(0, 4) : []
        return (
          <Col key={x.id} xs={24} lg={wide ? 24 : 12}>
            <Card size="small" title={<Text style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: 0.3, color: '#4b5a75' }}>{x.heading}</Text>} style={{ height: '100%' }}>
              {(() => { const v = vis(x); return v ? <VisualBlock v={v} compact /> : null })()}
              {tiles.length ? (
                <Flex gap={SP.sm} wrap>
                  {tiles.map((line, i) => { const m = line.match(/\$[\d.,]+[MBK]?|\d+(?:\.\d+)?%/); return (
                    <div key={i} className="sb-tile"><Text style={{ display: 'block', fontSize: 20, fontWeight: 600 }}>{m?.[0]}</Text><Text type="secondary" style={{ fontSize: 12 }}>{line.replace(m?.[0] ?? '', '').replace(/^[\s:·,-]+|[\s:·,-]+$/g, '').slice(0, 80)}</Text></div>
                  ) })}
                </Flex>
              ) : vis(x) ? <Paragraph type="secondary" style={{ whiteSpace: 'pre-wrap', fontSize: 12.5, margin: `${SP.sm}px 0 ${SP.xs}px` }}>{short(x.body, 260)}</Paragraph> : para(x)}
              {src(x)}
            </Card>
          </Col>
        )
      })}
    </Row>
  )
  if (s.format === 'Workbook') return (
    <Tabs size="small" items={included.map((x) => ({ key: x.id, label: x.heading, children: (
      <>
        {(() => { const v = vis(x); return v ? <div style={{ marginBottom: SP.sm }}><VisualBlock v={v} compact /></div> : null })()}
        <table className="sb-sheet">{(x.body || '(to be written)').split('\n').filter(Boolean).map((row, i) => <tbody key={i}><tr><td className="sb-rn">{i + 1}</td><td style={{ color: empty(x) ? STATUS.warn : undefined }}>{row}</td></tr></tbody>)}</table>
        <div style={{ marginTop: SP.xs }}>{src(x)}</div>
      </>
    ) }))} />
  )
  if (s.format === 'Email') {
    const [first, ...rest] = included
    return (
      <div className="sb-mail">
        <div className="sb-mail-hdr"><div><b>To:</b> {s.audience || 'Not stated'}</div><div><b>From:</b> {s.createdBy}</div><div><b>Subject:</b> {first?.heading ?? s.title}</div></div>
        {first ? <>{para(first)}{src(first)}</> : null}
        {rest.map((x) => (
          <div key={x.id} style={{ marginTop: SP.base }}>
            <Title level={5} style={{ marginBottom: SP.xs, fontWeight: 600, fontSize: 12.5, textTransform: 'uppercase', letterSpacing: 0.3, color: '#4b5a75' }}>{x.heading}</Title>
            {para(x)}{src(x)}
          </div>
        ))}
      </div>
    )
  }
  return (
    <>
      {included.map((x) => (
        <div key={x.id} style={{ marginBottom: SP.lg }}>
          <Title level={5} style={{ marginBottom: SP.xs, fontWeight: 600, ...(s.format === 'Memo' ? { fontSize: 12.5, textTransform: 'uppercase' as const, letterSpacing: 0.3, color: '#4b5a75' } : {}) }}>{x.heading}</Title>
          {para(x)}{(() => { const v = x.role === 'findings' || x.role === 'summary' ? vis(x) : null; return v ? <VisualBlock v={v} compact /> : null })()}{src(x)}
        </div>
      ))}
    </>
  )
}

export function SubmissionDetail({ s }: { s: Submission }) {
  const navigate = useNavigate()
  const identity = useAuthStore((s) => s.identity)
  const me = identity?.name ?? 'You'
  const { update, setSections, setStage, applyTemplate, saveOutlineAsTemplate, templates, addTemplate } = useSubmissionStore()
  const [saveName, setSaveName] = useState<string | null>(null)
  const { message } = App.useApp()
  const draftRef = useRef<HTMLDivElement>(null)
  const [sharing, setSharing] = useState(false)
  const [lineage, setLineage] = useState(false)
  const [refreshedAt, setRefreshedAt] = useState(() => new Date())
  const shareUrl = `${window.location.href.split('#')[0]}#${appPath(`/submissions/${s.id}`)}`
  const isLive = s.format === 'Dashboard'
  /* What each format downloads as: a slide pack is PowerPoint, a dashboard is PDF or image, a spreadsheet is CSV, the written formats are PDF or HTML. */
  const dlHtml = { key: 'html', icon: <FileTextOutlined />, label: 'HTML page', onClick: () => download(`${s.id}_DRAFT.html`, buildDraft(s), 'text/html') }
  const dlPdf = { key: 'pdf', icon: <FilePdfOutlined />, label: 'PDF', onClick: () => { if (draftRef.current) printNode(draftRef.current) } }
  const dlPng = { key: 'png', icon: <FileImageOutlined />, label: 'Image (PNG)', onClick: async () => { if (!draftRef.current) return; try { await nodeToPng(draftRef.current, `${s.id}.png`); message.success('Image saved.') } catch { message.error('Could not render the image in this browser; use PDF.') } } }
  const dlPptx = { key: 'pptx', icon: <FilePptOutlined />, label: 'PowerPoint (.pptx)', onClick: async () => { const h = message.loading('Building the PowerPoint…', 0); try { await downloadPptx(s, goals[0] ?? null, included); message.success('PowerPoint saved.') } catch { message.error('Could not build the PowerPoint.') } finally { h() } } }
  const dlCsv = { key: 'csv', icon: <FileExcelOutlined />, label: 'CSV (all sheets)', onClick: () => download(`${s.id}.csv`, ['sheet,row,text', ...included.flatMap((x) => (x.body || '').split('\n').filter(Boolean).map((row, i) => `"${x.heading.replace(/"/g, '""')}",${i + 1},"${row.replace(/"/g, '""')}"`))].join('\n'), 'text/csv') }
  const downloadItems = s.format === 'Slide pack' ? [dlPptx] : s.format === 'Dashboard' ? [dlPdf, dlPng] : s.format === 'Workbook' ? [dlCsv] : s.format === 'Email' ? [dlHtml] : [dlPdf, dlHtml]
  const allGoals = useGoalStore((st) => st.goals)
  const goals = s.goalIds.map((id) => allGoals.find((g) => g.id === id)).filter(Boolean) as Goal[]
  const [picking, setPicking] = useState(false)
  const stageIdx = STAGES.indexOf(s.stage)
  const included = s.sections.filter((x) => x.included)
  const empty = included.filter((x) => !x.body.trim())
  const tpl = templates.find((t) => t.id === s.templateId)

  const setSection = (id: string, p: Partial<Section>) => setSections(s.id, s.sections.map((x) => (x.id === id ? { ...x, ...p } : x)))
  const addSection = () => setSections(s.id, [...s.sections, { id: `u${Date.now().toString(36)}`, heading: 'New section', body: '', from: 'You', role: 'free', included: true }])

  /* ---------------- the agent's side: one chat per submission, following the steps */
  const agent = (goals[0]?.agent ?? NEUTRAL_AGENT) as Goal['agent']
  const chat = useSubChat((st) => st.chats[s.id]) ?? []
  const typing = useSubChat((st) => !!st.typing[s.id])
  const attachRef = useRef<HTMLInputElement>(null)
  const [pendingUpload, setPendingUpload] = useState<Template | null>(null)
  const unit = formatInfo(s.format).unit
  const Unit = unit.charAt(0).toUpperCase() + unit.slice(1)
  const sayA = (t: string) => useSubChat.getState().say(s.id, 'agent', t)

  const stageMsg = (x: Submission): string => {
    const t = templates.find((tt) => tt.id === x.templateId)
    const inc = x.sections.filter((y) => y.included)
    const emp = x.sections.map((y, i) => ({ y, i })).filter(({ y }) => y.included && !y.body.trim())
    switch (x.stage) {
      case 'brief':
        return !x.title || !x.audience
          ? `A ${FORMAT_LABEL[x.format].toLowerCase()} drawing on ${goals.map((gg) => `"${gg.title}"`).join(' and ') || 'no goal yet'}. ${!x.title ? 'What is it called? Say "title …".' : 'Who reads it? Say "for …".'}`
          : `A ${FORMAT_LABEL[x.format].toLowerCase()} for ${x.audience}, drawing on ${goals.map((gg) => `"${gg.title}"`).join(' and ')}. Check the brief on the left: is the title right, and is that who reads it?\n\nSay "title …", "for …", "purpose …", or "next" for the template.`
      case 'template':
        return t
          ? `It follows "${t.name}" (${t.sections.length} sections)${x.origin === 'recommendation' ? ', which I recommended because it is in your library' : ''}. Keep it and say "next", say "change the template" to see the others, or attach your own template file with the clip.`
          : x.origin === 'described'
            ? `No template in your library fits, so the structure comes from your description: ${inc.length} ${unit}s. Shall I save it as a template so I can recommend it next time?\n\nSay "save as a template", "use a library template", or "next".`
            : 'Which template? Say "change the template" to see the library, or attach a file.'
      case 'outline':
        return `The outline has ${inc.length} ${unit}s; ${inc.length - emp.length} filled from the goal${emp.length ? `, ${emp.length} still to write: ${emp.map(({ y, i }) => `${i + 1} (${y.heading})`).join(', ')}` : ''}.\n\nSay "write ${emp[0] ? emp[0].i + 1 : 2}: …", "remove ${emp[0] ? emp[0].i + 1 : 3}", "add a ${unit} on …", "rename 1 to …", or "build the draft".`
      case 'draft':
        return `The draft is on the left, as the reader will see it.${x.format === 'Dashboard' ? ' It is live: it reads the goal’s data each time it opens.' : ''}${emp.length ? ` ${emp.length} ${unit}${emp.length === 1 ? ' is' : 's are'} still empty; write ${emp.length === 1 ? 'it' : 'them'} before I can mark it reviewed.` : ''}\n\nSay "mark as reviewed", "download", "share", "where do the figures come from?", or "back to the outline".`
      default:
        return `Marked as reviewed. Download it (${downloadItems.map((d) => d.label).join(' or ')}) or share the link. Sending and publishing are not part of the product today.`
    }
  }

  const lastStage = useRef<string | null>(null)
  const lastTpl = useRef<string | undefined>(s.templateId)
  useEffect(() => {
    const c = useSubChat.getState()
    if (!c.chats[s.id]?.length) { c.reset(s.id, [smsg('agent', stageMsg(s))]); lastStage.current = s.stage; return }
    if (lastStage.current === null) { lastStage.current = s.stage; return }
    if (lastStage.current !== s.stage) { lastStage.current = s.stage; c.say(s.id, 'event', STAGE_LABEL[s.stage]); c.say(s.id, 'agent', stageMsg(s)) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.stage])
  useEffect(() => {
    if (lastTpl.current === s.templateId) return
    lastTpl.current = s.templateId
    const t = templates.find((tt) => tt.id === s.templateId)
    if (t) sayA(`Now on "${t.name}": ${s.sections.filter((y) => y.included).length} sections, filled from the goal where the role matches. Say "next" for the outline.`)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.templateId])

  const act = (raw: string) => {
    const x = useSubmissionStore.getState().submissions.find((y) => y.id === s.id)
    if (!x) return
    const idx = STAGES.indexOf(x.stage)
    if (pendingUpload && /^keep\b/i.test(raw.trim())) { setPendingUpload(null); sayA('Kept the current template. Yours stays in the library for next time.'); return }
    const it = interpretSub(raw, x.stage)
    const secs = x.sections
    const sec = (n: number) => secs[n - 1]
    const noSec = (n: number) => sayA(`There is no ${unit} ${n}; the outline has ${secs.length}.`)
    const emp = secs.filter((y) => y.included && !y.body.trim())
    switch (it.k) {
      case 'help': sayA(stageMsg(x)); return
      case 'next':
        if (x.stage === 'brief') { if (!x.title || !x.audience) { sayA(!x.title ? 'A title first: say "title …".' : 'Who reads it? Say "for …".'); return } setStage(s.id, 'template', me); return }
        if (x.stage === 'template') { setStage(s.id, 'outline', me); return }
        if (x.stage === 'outline') { setStage(s.id, 'draft', me); return }
        if (x.stage === 'draft') { sayA(emp.length ? `Write or remove the empty ${unit}s first: ${emp.map((y) => `"${y.heading}"`).join(', ')}. Say "back to the outline".` : 'Read it through on the left. When it reads right, say "mark as reviewed".'); return }
        sayA('It is reviewed. Say "download" or "share".')
        return
      case 'back': {
        const to = it.to === 'draft' ? 'draft' : it.to ?? STAGES[Math.max(0, idx - 1)]
        if (STAGES.indexOf(to as SubmissionStage) > idx) { sayA(`Not there yet. ${stageMsg(x)}`); return }
        setStage(s.id, to as SubmissionStage, me)
        return
      }
      case 'title': update(s.id, { title: it.v }, me, `Retitled "${it.v}".`); sayA(`Title set: "${it.v}".${x.audience ? ' Say "next" when the brief is right.' : ' Who reads it? Say "for …".'}`); return
      case 'audience': update(s.id, { audience: it.v }, me, `Audience: ${it.v}.`); sayA(`For ${it.v}. ${x.title ? 'Say "next" for the template, or "purpose …".' : 'And the title? Say "title …".'}`); return
      case 'purpose': update(s.id, { purpose: it.v }, me, 'Purpose stated.'); sayA('Purpose noted. Say "next" for the template.'); return
      case 'pickTemplate':
        if (x.stage !== 'template') setStage(s.id, 'template', me)
        setPicking(true)
        sayA(`The library is open on the left. Click one, or say "use" and its number or name:\n${templates.map((t, i) => `${i + 1}. ${t.name} (${FORMAT_LABEL[t.format]})`).join('\n')}`)
        return
      case 'useTemplate': {
        const t = it.n ? templates[it.n - 1] : bestMatch(it.words ?? '', templates, (y) => `${y.name} ${y.family}`)
        if (!t) { sayA(`Which one? Say "use" and its number:\n${templates.map((y, i) => `${i + 1}. ${y.name}`).join('\n')}`); return }
        setPicking(false)
        applyTemplate(s.id, t, goals, me)
        return
      }
      case 'useUploaded': {
        const t = pendingUpload ? templates.find((y) => y.id === pendingUpload.id) ?? pendingUpload : undefined
        if (!t) { sayA('Attach the file first, with the clip below or "Use my own file" on the left.'); return }
        if (x.stage !== 'template') setStage(s.id, 'template', me)
        applyTemplate(s.id, t, goals, me)
        setPendingUpload(null)
        return
      }
      case 'saveTemplate': {
        if (x.origin !== 'described' || x.templateId) { sayA(`It already follows "${x.template}" from your library.`); return }
        const name = it.name ?? `${FORMAT_LABEL[x.format]}: ${x.title.replace(/:.*$/, '')}`
        saveOutlineAsTemplate(s.id, name, me)
        sayA(`Saved to your library as "${name}", under "Described for a goal". I can recommend it next time. Say "next" for the outline.`)
        return
      }
      case 'remove': { const y = sec(it.n); if (!y) return noSec(it.n); setSections(s.id, secs.map((z) => (z.id === y.id ? { ...z, included: false } : z))); sayA(`Left out ${it.n}: "${y.heading}". Say "put back ${it.n}" to include it again.`); return }
      case 'restore': { const y = sec(it.n); if (!y) return noSec(it.n); setSections(s.id, secs.map((z) => (z.id === y.id ? { ...z, included: true } : z))); sayA(`${it.n} is back in: "${y.heading}".`); return }
      case 'add': setSections(s.id, [...secs, { id: `u${Date.now().toString(36)}`, heading: it.heading, body: '', from: 'You', role: roleOf(it.heading), included: true }]); sayA(`Added ${unit} ${secs.length + 1}: "${it.heading}". It is empty: say "write ${secs.length + 1}: …".`); return
      case 'rename': { const y = sec(it.n); if (!y) return noSec(it.n); setSections(s.id, secs.map((z) => (z.id === y.id ? { ...z, heading: it.v } : z))); sayA(`${Unit} ${it.n} is now "${it.v}".`); return }
      case 'write': { const y = sec(it.n); if (!y) return noSec(it.n); setSections(s.id, secs.map((z) => (z.id === y.id ? { ...z, body: it.v, from: z.from.startsWith('You') ? 'You' : `${z.from.replace(/, edited by .*$/, '')}, edited by ${me}` } : z))); const left = emp.filter((z) => z.id !== y.id).length; sayA(`Written into ${it.n}.${left ? ` ${left} still empty.` : ' Nothing is empty now.'}`); return }
      case 'show': { const y = sec(it.n); if (!y) return noSec(it.n); sayA(`${it.n}. ${y.heading} (from ${y.from})\n${y.body.trim() ? (y.body.length > 420 ? `${y.body.slice(0, 418)}…` : y.body) : 'Empty so far.'}`); return }
      case 'review':
        if (idx < 3) { sayA('Build the draft first: say "build the draft".'); return }
        if (emp.length) { sayA(`Write or remove the empty ${unit}s first: ${emp.map((y) => `"${y.heading}"`).join(', ')}.`); return }
        setStage(s.id, 'reviewed', me)
        return
      case 'download': {
        if (idx < 3) { sayA('Downloads come with the draft. Say "build the draft".'); return }
        const pick = it.as ? downloadItems.find((d) => d.label.toLowerCase().includes(it.as === 'powerpoint' ? 'pptx' : it.as === 'image' ? 'png' : it.as!)) : undefined
        const d = pick ?? downloadItems[0]
        sayA(`Downloading the ${d.label}.${downloadItems.length > 1 && !pick ? ` Also available: ${downloadItems.filter((z) => z !== d).map((z) => z.label).join(', ')}.` : ''}`)
        void d.onClick()
        return
      }
      case 'share': if (idx < 3) { sayA('Sharing comes with the draft.'); return } setSharing(true); sayA('The link is open on the left; copy it from there.'); return
      case 'lineage': setLineage(true); sayA(`Data lineage is open: where every ${unit} reads from, and the evidence behind it.`); return
      case 'refresh': if (isLive) { setRefreshedAt(new Date()); sayA('Refreshed from the goal’s data.') } else sayA('Only a dashboard refreshes; this one is a fixed draft.'); return
      case 'goal': if (goals[0]) { sayA(`Opening "${goals[0].title}".`); window.setTimeout(() => navigate(appPath(`/goals/${goals[0].id}`)), 600) } return
      default: sayA(`I did not catch that. ${stageMsg(x)}`)
    }
  }
  const send = (text: string) => {
    const c = useSubChat.getState()
    c.say(s.id, 'me', text)
    c.setTyping(s.id, true)
    window.setTimeout(() => { useSubChat.getState().setTyping(s.id, false); act(text) }, 450 + Math.random() * 350)
  }
  /* A template file dropped into the chat: read it, add it to the library, and offer to use it here. */
  const upload = async (file: File) => {
    const c = useSubChat.getState()
    c.say(s.id, 'me', 'Here is a template.', { name: file.name, size: file.size })
    c.setTyping(s.id, true)
    const r = await readUpload(file)
    const t = templateFromRead(r)
    window.setTimeout(() => {
      c.setTyping(s.id, false)
      addTemplate(t, me)
      setPendingUpload(t)
      if (s.stage !== 'template' && STAGES.indexOf(s.stage) < 3) setStage(s.id, 'template', me)
      sayA(`Read ${r.name}: ${describeRead(r)}. It is in your library now as "${t.name}", with these sections:\n${t.sections.map((y, i) => `${i + 1}. ${y.heading}`).join('\n')}\n\nUse it for this submission? Say "use it" (or click Use it on the left), or "keep" the current one.`)
    }, 900)
  }
  const firstEmpty = s.sections.findIndex((y) => y.included && !y.body.trim()) + 1
  const audHint = goals[0]?.submissions[0]?.audience
  const chips = s.stage === 'brief' ? (!s.audience && audHint ? [`For ${audHint}`, 'Open the goal'] : !s.title ? ['Title: ', 'Open the goal'].slice(1) : ['Next', 'Change the template', 'Open the goal'])
    : s.stage === 'template' ? (pendingUpload && s.templateId !== pendingUpload.id ? ['Use it', 'Next'] : s.origin === 'described' && !s.templateId ? ['Save as a template', 'Use a library template', 'Next'] : ['Next', 'Change the template'])
    : s.stage === 'outline' ? (firstEmpty ? [`Show ${firstEmpty}`, `Remove ${firstEmpty}`, `Add a ${unit} on next steps`, 'Build the draft'] : ['Build the draft', `Add a ${unit} on next steps`, 'Show 1'])
    : s.stage === 'draft' ? ['Mark as reviewed', 'Download', 'Where do the figures come from?', 'Back to the outline']
    : ['Download', 'Share', 'Open the goal']

  return (
    <TwoPane left={(
    <div className="sbw">
      <input ref={attachRef} type="file" accept=".pptx,.docx,.txt,.md,.pdf,.xlsx" style={{ display: 'none' }} onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); e.target.value = '' }} />
      <span className="gw-back" role="link" onClick={() => navigate(appPath('/submissions'))}>← All submissions</span>
      <PageHeader
        title={s.title || 'New submission'}
        subtitle={goals.length ? `Draws on ${goals.map((g) => `"${g.title}"`).join(' and ')}.` : 'No goal behind it yet.'}
        actions={
          <>
            {goals[0] ? <Button onClick={() => navigate(appPath(`/goals/${goals[0].id}`))}>Open the goal</Button> : null}
          </>
        }
      />

      <Steps size="small" labelPlacement="vertical" current={stageIdx} onChange={(i) => { if (i <= stageIdx) setStage(s.id, STAGES[i], me) }} style={{ marginBottom: SP.xl }}
        items={[{ title: 'Brief' }, { title: 'Template' }, { title: 'Outline' }, { title: 'Draft' }, { title: 'Review' }]} />

      <Drawer open={lineage} onClose={() => setLineage(false)} width={640} title="Data lineage" destroyOnHidden>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginBottom: SP.base }}>Where each {isLive ? 'panel' : 'section'} of this {FORMAT_LABEL[s.format].toLowerCase()} gets its figures: the goal it draws on, the part of the analysis that filled it, the tables of the published graph behind its picture, and the evidence lines the agent recorded. Data as of {DRILL.as_of}.</Text>
        {included.filter((x) => x.role !== 'evidence').map((x) => {
          const g0 = goals[0]
          const v = g0 ? visualFor(g0, x.role, x.heading) : null
          return (
            <Card key={x.id} size="small" style={{ marginBottom: SP.sm }} styles={{ body: { padding: `${SP.sm}px ${SP.base}px` } }}>
              <Text style={{ display: 'block', fontWeight: 500, fontSize: 13 }}>{x.heading}</Text>
              <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>Filled from: {x.from}{g0 ? ` · goal "${g0.title}"` : ''}</Text>
              {v ? <><Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: 4 }}>Picture: {v.title}</Text><ul className="g-ul" style={{ fontSize: 12.5, marginTop: 2 }}>{LINEAGE[v.kind].tables.map((t) => <li key={t}>{t}</li>)}</ul></> : null}
            </Card>
          )
        })}
        {goals.length ? (
          <>
            <Text style={{ display: 'block', fontWeight: 500, fontSize: 13, margin: `${SP.base}px 0 ${SP.xs}px` }}>Evidence lines recorded by {goals.map((g) => g.agent.name).join(' and ')}</Text>
            <table className="sb-vt"><thead><tr><th>Evidence</th><th>Kind</th><th>Source</th><th>As of</th></tr></thead><tbody>
              {goals.flatMap((g) => g.findings.flatMap((f) => f.evidence.map((e, i) => <tr key={`${f.id}-${i}`}><td>{e.text}</td><td>{e.kind}</td><td>{e.source}</td><td>{e.asOf ?? ''}</td></tr>)))}
            </tbody></table>
          </>
        ) : null}
      </Drawer>

      <Modal open={sharing} onCancel={() => setSharing(false)} footer={null} title={isLive ? 'Share the live dashboard' : `Share this ${FORMAT_LABEL[s.format].toLowerCase()}`}>
        <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.sm }}>{isLive ? 'Anyone at Northline with the link opens the dashboard and sees the goal’s data as it stands when they open it, not a copy.' : 'Anyone at Northline with the link opens the draft as it stands; download a copy to send outside.'}</Text>
        <Flex gap={SP.xs} style={{ marginBottom: SP.base }}>
          <Input value={shareUrl} readOnly prefix={<LinkOutlined />} />
          <Button icon={<CopyOutlined />} onClick={() => { navigator.clipboard?.writeText(shareUrl).then(() => message.success('Link copied.')).catch(() => message.info('Copy the link from the box.')) }}>Copy</Button>
        </Flex>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>Draws on: {goals.map((g) => g.title).join('; ')}. Readers see the same drill-downs as you; sending by mail or publishing is not part of this product today.</Text>
      </Modal>

      {s.stage === 'brief' ? (
        <Card size="small" title="Brief">
          <Form layout="vertical" initialValues={s} onValuesChange={(_, all) => update(s.id, all)}>
            <Row gutter={SP.base}>
              <Col xs={24} md={12}><Form.Item name="title" label="Title" rules={[{ required: true }]}><Input /></Form.Item></Col>
              <Col xs={24} md={12}><Form.Item name="audience" label="Audience" rules={[{ required: true }]}><Input placeholder="Who reads it and decides" /></Form.Item></Col>
            </Row>
            <Form.Item name="purpose" label="Purpose: what the reader should decide or do"><Input.TextArea rows={2} /></Form.Item>
          </Form>
          <Descriptions column={1} size="small" colon={false} labelStyle={{ width: 110, color: '#4b5a75', fontSize: 12.5 }} contentStyle={{ fontSize: 13 }} style={{ marginBottom: SP.base }}
            items={[
              { key: 'g', label: 'Draws on', children: goals.length ? goals.map((g) => <Tag key={g.id} style={{ marginInlineEnd: 4 }}>{g.title} · {g.agent.name}</Tag>) : 'No goal' },
              { key: 'f', label: 'Format', children: <Space size={4}>{FORMAT_ICON[s.format]}{FORMAT_LABEL[s.format]}</Space> },
              { key: 't', label: 'Template', children: tpl ? `${tpl.family}: ${tpl.name}` : s.origin === 'described' ? 'None in the library fits; defined from your description' : 'Not chosen yet' },
              ...(s.brief ? [{ key: 'd', label: 'Your words', children: <Text style={{ fontSize: 13, fontStyle: 'italic' }}>“{s.brief.description}”</Text> }] : []),
            ]} />
          <Button type="primary" disabled={!s.title || !s.audience} onClick={() => send('Next')}>Continue</Button>
        </Card>
      ) : null}

      {s.stage === 'template' ? (
        <>
          {tpl ? (
            <Row gutter={[SP.base, SP.base]} style={{ marginBottom: SP.base }}>
              <Col xs={24} md={12} xl={8}><TemplateCard t={tpl} selected /></Col>
              <Col xs={24} md={12} xl={16}>
                <Card size="small" style={{ height: '100%' }}>
                  <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.sm }}>{s.origin === 'described' ? 'Saved to your library from your description; the agent can recommend it from now on.' : s.origin === 'recommendation' ? `Recommended by ${s.agentName ?? 'the agent'} because this template is in your library.` : 'Chosen when the submission was started.'} Its {tpl.sections.length} sections are filled from the goal{goals.length === 1 ? '' : 's'} where the role matches.</Text>
                  <Space wrap>
                    <Button onClick={() => send('Change the template')}>Change template</Button>
                    <Button icon={<UploadOutlined />} onClick={() => attachRef.current?.click()}>Use my own file</Button>
                    <Button type="primary" onClick={() => send('Next')}>Continue to the outline</Button>
                  </Space>
                </Card>
              </Col>
            </Row>
          ) : s.origin === 'described' && s.brief ? (
            <Row gutter={[SP.base, SP.base]} style={{ marginBottom: SP.base }}>
              <Col xs={24} md={12} xl={8}>
                <Card size="small" style={{ height: '100%', borderColor: BRAND, background: BRAND_SOFT }} styles={{ body: { padding: `${SP.md}px ${SP.base}px` } }}>
                  <Flex justify="space-between" align="flex-start" gap={SP.sm}>
                    <Space size={SP.xs}><span style={{ color: BRAND_INK }}>{FORMAT_ICON[s.format]}</span><Text style={{ fontWeight: 500, fontSize: 13.5, color: BRAND_INK }}>{FORMAT_LABEL[s.format]} from your description</Text></Space>
                    <Tag style={{ marginInlineEnd: 0 }}>not in the library</Tag>
                  </Flex>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12, margin: `${SP.xs}px 0 ${SP.sm}px`, fontStyle: 'italic' }}>“{s.brief.description}”</Text>
                  <ol style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: '#4b5a75' }}>{s.sections.filter((x) => x.included).map((x) => <li key={x.id}>{x.heading}</li>)}</ol>
                </Card>
              </Col>
              <Col xs={24} md={12} xl={16}>
                <Card size="small" style={{ height: '100%' }}>
                  <Text style={{ display: 'block', fontSize: 13, marginBottom: SP.xs }}>No template in the library fits this goal, so {s.agentName ?? 'the agent'} built the structure from what you described:</Text>
                  {s.brief.reading.map((r, i) => <Text key={i} type="secondary" style={{ display: 'block', fontSize: 12, lineHeight: 1.5 }}>· {r}</Text>)}
                  <Space style={{ marginTop: SP.base }} wrap>
                    <Button icon={<SaveOutlined />} onClick={() => setSaveName(`${FORMAT_LABEL[s.format]}: ${s.title.replace(/:.*$/, '')}`)}>Save as a template</Button>
                    <Button onClick={() => send('Use a library template')}>Use a library template instead</Button>
                    <Button icon={<UploadOutlined />} onClick={() => attachRef.current?.click()}>Use my own file</Button>
                    <Button type="primary" onClick={() => send('Next')}>Continue to the outline</Button>
                  </Space>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12, marginTop: SP.sm }}>Saved, it joins the library under "Described for a goal" and the agent can recommend it next time.</Text>
                </Card>
              </Col>
            </Row>
          ) : (
            <Card size="small" style={{ marginBottom: SP.base }}>
              <Text style={{ display: 'block', marginBottom: SP.sm }}>No template yet.</Text>
              <Space><Button type="primary" onClick={() => send('Change the template')}>Pick a template</Button><Button icon={<UploadOutlined />} onClick={() => attachRef.current?.click()}>Use my own file</Button></Space>
            </Card>
          )}
          <Modal open={saveName !== null} title="Save this outline as a template" okText="Save to the library" onCancel={() => setSaveName(null)} onOk={() => { if (saveName?.trim()) { saveOutlineAsTemplate(s.id, saveName.trim(), me); sayA(`Saved to your library as "${saveName.trim()}", under "Described for a goal". I can recommend it next time. Say "next" for the outline.`); setSaveName(null) } }}>
            <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginBottom: SP.sm }}>The {s.sections.filter((x) => x.included).length} sections and their roles are kept; your description becomes the note that says when to use it.</Text>
            <Input value={saveName ?? ''} onChange={(e) => setSaveName(e.target.value)} placeholder="Name it, e.g. Committee dashboard" />
          </Modal>
          <Drawer title="Pick a template" open={picking} onClose={() => setPicking(false)} width={720} destroyOnHidden>
            {FAMILIES.map((fam) => {
              const list = templates.filter((t) => t.family === fam)
              if (!list.length) return null
              return (
                <div key={fam} style={{ marginBottom: SP.lg }}>
                  <Text type="secondary" style={{ fontSize: 11.5, textTransform: 'uppercase', letterSpacing: 0.3, display: 'block', marginBottom: SP.sm }}>{fam}</Text>
                  <Row gutter={[SP.sm, SP.sm]}>{list.map((t) => <Col key={t.id} span={12}><TemplateCard t={t} compact selected={s.templateId === t.id} onPick={() => { applyTemplate(s.id, t, goals, me); setPicking(false) }} /></Col>)}</Row>
                </div>
              )
            })}
            <Text type="secondary" style={{ fontSize: 12.5 }}>Missing one? Add it under Submissions → Templates.</Text>
          </Drawer>
        </>
      ) : null}

      {s.stage === 'outline' ? (
        <>
          <Paragraph type="secondary" style={{ fontSize: 13 }}>{s.origin === 'described' ? `${formatInfo(s.format).label} ${formatInfo(s.format).unit}s follow your description` : 'Sections follow the template'}; each says where it came from. Untick, reword, add.</Paragraph>
          <Flex vertical gap={SP.sm}>
            {s.sections.map((x, i) => (
              <Card key={x.id} size="small" style={{ opacity: x.included ? 1 : 0.6 }} styles={{ body: { padding: `${SP.md}px ${SP.base}px` } }}>
                <Flex gap={SP.sm} align="center" style={{ marginBottom: SP.xs }}>
                  <span className="gw-num">{i + 1}</span>
                  <Checkbox checked={x.included} onChange={(e) => setSection(x.id, { included: e.target.checked })} />
                  <Input value={x.heading} onChange={(e) => setSection(x.id, { heading: e.target.value })} variant="borderless" style={{ fontWeight: 500, padding: 0, flex: 1 }} />
                  <Tag style={{ marginInlineEnd: 0 }}>{x.from}</Tag>
                </Flex>
                <Input.TextArea value={x.body} onChange={(e) => setSection(x.id, { body: e.target.value, from: x.from.startsWith('You') ? 'You' : `${x.from.replace(/, edited by .*$/, '')}, edited by ${me}` })} autoSize={{ minRows: 2, maxRows: 12 }} placeholder="Write this section, or leave it and the draft marks it as still to be written." />
              </Card>
            ))}
          </Flex>
          <Space style={{ marginTop: SP.base }}>
            <Button onClick={addSection} icon={<PlusOutlined />}>Add a section</Button>
            <Button type="primary" onClick={() => send('Build the draft')}>Build the draft</Button>
          </Space>
        </>
      ) : null}

      {s.stage === 'draft' || s.stage === 'reviewed' ? (
        <div className="sb-actions">
          <Button onClick={() => send('Back to the outline')}>{s.stage === 'reviewed' ? 'Reopen the outline' : 'Back to the outline'}</Button>
          {s.stage === 'draft' ? (
            <Tooltip title={empty.length ? `Write or remove ${empty.length} empty ${unit}${empty.length === 1 ? '' : 's'} first: ${empty.map((x) => x.heading).join('; ')}` : 'You have read it and it can leave'}>
              <Button type="primary" icon={<CheckOutlined />} disabled={empty.length > 0} onClick={() => send('Mark as reviewed')}>Mark as reviewed</Button>
            </Tooltip>
          ) : <Tag color="success" icon={<CheckOutlined />} style={{ marginInlineEnd: 0, padding: '4px 10px' }}>Reviewed{s.reviewedBy ? ` by ${s.reviewedBy}` : ''}</Tag>}
          {downloadItems.length === 1
            ? <Button icon={downloadItems[0].icon} onClick={() => send(`Download the ${downloadItems[0].label}`)}>Download {downloadItems[0].label}</Button>
            : <Dropdown trigger={['click']} menu={{ items: downloadItems.map((d) => ({ key: d.key, icon: d.icon, label: d.label, onClick: () => send(`Download the ${d.label}`) })) }}><Button icon={<DownloadOutlined />}>Download</Button></Dropdown>}
          <Button icon={<ShareAltOutlined />} onClick={() => send('Share')}>Share{isLive ? ' live' : ''}</Button>
          <Button icon={<ApartmentOutlined />} onClick={() => send('Where do the figures come from?')}>Data lineage</Button>
          {isLive ? <Button icon={<ReloadOutlined />} onClick={() => send('Refresh')}>Refresh</Button> : null}
        </div>
      ) : null}
      {s.stage === 'template' && pendingUpload && s.templateId !== pendingUpload.id ? (
        <Alert type="info" showIcon style={{ marginBottom: SP.base }} message={`Read from your file: "${pendingUpload.name}", ${pendingUpload.sections.length} sections.`} action={<Space><Button size="small" type="primary" onClick={() => send('Use it')}>Use it</Button><Button size="small" onClick={() => { setPendingUpload(null); sayA('Kept the current template. Yours stays in the library.') }}>Keep current</Button></Space>} />
      ) : null}
      {s.stage === 'draft' || s.stage === 'reviewed' ? (
        <Row gutter={[SP.base, SP.base]}>
          <Col xs={24}>
            <Card size="small" styles={{ body: { padding: `${SP.xl}px ${SP.xxl}px` } }}>
              <div ref={draftRef} id="sb-draft">
              {isLive ? (
                <Alert type="info" showIcon className="no-print" style={{ marginBottom: SP.base }} message={<Flex justify="space-between" align="center" gap={SP.sm} wrap><span><Tag color="processing" style={{ marginInlineEnd: 6 }}>Live</Tag>Reads the goal’s data each time it opens · data as of {DRILL.as_of} · refreshed {refreshedAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span><Button size="small" icon={<ReloadOutlined />} onClick={() => setRefreshedAt(new Date())}>Refresh</Button></Flex>} />
              ) : (
                <Alert type="warning" showIcon style={{ marginBottom: SP.base }} message="Draft, not approved." description="Prepared from the goals it draws on. Assumptions and open items are stated inside." />
              )}
              <Title level={3} style={{ margin: 0, letterSpacing: -0.4, fontWeight: 600 }}>{s.title}</Title>
              <Text type="secondary" style={{ display: 'block', fontSize: 13, marginBottom: SP.lg }}>To {s.audience} · {s.template} · {FORMAT_LABEL[s.format]} · prepared by {s.createdBy}{s.reviewedBy ? ` · reviewed by ${s.reviewedBy}` : ''}</Text>
              <DraftView key={refreshedAt.getTime()} s={s} included={included} />
              </div>
            </Card>
          </Col>
          <Col xs={24} xl={12}>
            <Card size="small" title="Before it leaves" style={{ marginBottom: SP.base }}>
              <Descriptions column={1} size="small" colon={false} labelStyle={{ width: 110, color: '#4b5a75', fontSize: 12.5 }} contentStyle={{ fontSize: 13 }}
                items={[
                  { key: 'f', label: 'Format', children: FORMAT_LABEL[s.format] },
                  { key: 't', label: 'Template', children: s.template },
                  { key: 'g', label: 'Draws on', children: goals.map((g) => g.title).join('; ') || 'No goal' },
                  { key: 'a', label: isLive ? 'Panels' : 'Sections', children: isLive ? `${included.filter((x) => x.role !== 'evidence').length} panels` : `${included.length} included, ${empty.length} to write` },
                  { key: 'c', label: 'Status', children: <Tag color={s.stage === 'reviewed' ? 'success' : 'processing'} style={{ marginInlineEnd: 0 }}>{STAGE_LABEL[s.stage]}</Tag> },
                  { key: 'd', label: 'Data', children: <Button type="link" size="small" icon={<ApartmentOutlined />} style={{ padding: 0, height: 'auto' }} onClick={() => send('Where do the figures come from?')}>Data lineage: where every {isLive ? 'panel' : 'section'} reads from</Button> },
                ]} />
              <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: SP.sm }}>Sending, approvals and publishing are not part of this product today.</Text>
            </Card>
            <Card size="small" title="Log">
              {s.log.map((l, i) => <Text key={i} style={{ display: 'block', fontSize: 12.5, marginBottom: SP.xs }}><Text type="secondary">{new Date(l.at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} · {l.who}</Text><br />{l.what}</Text>)}
            </Card>
          </Col>
        </Row>
      ) : null}
    </div>
    )} right={<ChatPane agent={agent} messages={chat} typing={typing} chips={chips} onSend={send} onUpload={upload} accept=".pptx,.docx,.txt,.md,.pdf,.xlsx" title={`step: ${STAGE_LABEL[s.stage].toLowerCase()}`} />} />
  )
}

export default function SubmissionsPage() {
  const { submissionId } = useParams()
  const submissions = useSubmissionStore((s) => s.submissions)
  const s = useMemo(() => submissions.find((x) => x.id === submissionId) ?? null, [submissions, submissionId])
  const location = useLocation()
  if (submissionId && submissionId !== 'new' && !s) {
    return <><PageHeader title="Submissions" subtitle="That submission does not exist in this copy." /><Button type="link" style={{ padding: 0 }} href={`#${appPath('/submissions')}`}>← All submissions</Button></>
  }
  void location
  return <SubmissionsHub routeId={submissionId} />
}
