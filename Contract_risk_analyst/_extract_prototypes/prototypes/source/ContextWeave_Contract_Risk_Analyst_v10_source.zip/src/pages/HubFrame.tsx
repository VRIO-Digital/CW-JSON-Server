import { CheckOutlined, CloseCircleFilled, MenuFoldOutlined, MenuUnfoldOutlined, RightOutlined, SearchOutlined } from '@ant-design/icons'
import { Tooltip } from 'antd'
import { Fragment, useEffect, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { create } from 'zustand'

/*
 * The frame Goals and Submissions share, laid out like a conversation with an assistant:
 *   left   your history (drafts, reviewed, goals, what is watching for you), can be folded away
 *   middle the conversation, always
 *   right  the thing the conversation is about (the output, the goal's work, the brief filling in),
 *          only when there is one; drag the bar between them to make it wider or narrower.
 */

const read = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(k); return v ? (JSON.parse(v) as T) : d } catch { return d } }
const write = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch { /* storage off: the width is kept for this visit only */ } }

/*
 * railOpen is your choice. When something is open on the right and the screen is not wide enough for
 * all three, the list steps aside (as an assistant hides its sidebar when it opens a document); the
 * list button then shows it over the conversation instead of squeezing it.
 */
/* The panel opens at a width that suits the screen: 600 on a laptop, wider on a large display. Dragging the bar overrides it. */
export const defaultPanelW = () => { const w = typeof window === 'undefined' ? 1440 : window.innerWidth; return w >= 1600 ? Math.min(700, Math.round(w * 0.38)) : 600 }
interface Frame { railOpen: boolean; panelW: number; peek: boolean; tight: boolean; set: (p: Partial<Pick<Frame, 'railOpen' | 'panelW' | 'peek' | 'tight'>>) => void }
export const useFrame = create<Frame>((set) => ({
  railOpen: read('cw.hub.rail', true),
  /* Its own key: an older prototype opened from the same disk shares this browser storage and may have left the panel dragged narrow. */
  panelW: Math.max(480, read('cw.wsa.panelW.v2', defaultPanelW())),
  peek: false,
  tight: false,
  set: (p) => { set(p); if (p.railOpen !== undefined) write('cw.hub.rail', p.railOpen); if (p.panelW !== undefined) write('cw.wsa.panelW.v2', p.panelW) },
}))

export function RailToggle() {
  const { railOpen, peek, tight, set } = useFrame()
  const shown = tight ? peek : railOpen
  const flip = () => (tight ? set({ peek: !peek }) : set({ railOpen: !railOpen }))
  return <Tooltip title={shown ? 'Hide the list' : 'Show the list'}><span role="button" aria-label={shown ? 'Hide the list' : 'Show the list'} className="hub-icon" onClick={flip}>{shown ? <MenuFoldOutlined /> : <MenuUnfoldOutlined />}</span></Tooltip>
}

export default function HubFrame({ rail, children, panel }: { rail: React.ReactNode; children: React.ReactNode; panel: React.ReactNode | null }) {
  const { railOpen, panelW, peek, set } = useFrame()
  const ref = useRef<HTMLDivElement>(null)
  const [width, setWidth] = useState(1400)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const ro = new ResizeObserver(([e]) => setWidth(e.contentRect.width))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])
  /* All three side by side only when the conversation keeps room to breathe. */
  const tight = !!panel && width < 236 + 14 + 600 + 14 + Math.min(panelW, 470)
  useEffect(() => { if (useFrame.getState().tight !== tight) set({ tight, peek: false }) }, [tight, set])
  const showRail = railOpen && !tight
  const where = useLocation().key
  useEffect(() => { if (useFrame.getState().peek) set({ peek: false }) }, [where, set])
  const drag = (e: React.MouseEvent) => {
    e.preventDefault()
    const box = ref.current!.getBoundingClientRect()
    const railW = showRail ? 250 : 0
    const move = (ev: MouseEvent) => set({ panelW: Math.round(Math.max(420, Math.min(box.width - railW - 380, box.right - ev.clientX - 6))) })
    const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); document.body.classList.remove('tp-dragging') }
    document.addEventListener('mousemove', move)
    document.addEventListener('mouseup', up)
    document.body.classList.add('tp-dragging')
  }
  const cols = [showRail ? '236px' : null, 'minmax(360px, 1fr)', panel ? '14px' : null, panel ? `minmax(320px, ${panelW}px)` : null].filter(Boolean).join(' ')
  return (
    <div ref={ref} className={`hub${showRail ? ' has-rail' : ''}${panel ? ' has-panel' : ''}`} style={{ gridTemplateColumns: cols }}>
      {showRail ? <aside className="hub-rail" aria-label="History">{rail}</aside> : null}
      {tight && peek ? <><div className="hub-veil" onClick={() => set({ peek: false })} /><aside className="hub-rail is-peek" aria-label="History" onClickCapture={(e) => { if ((e.target as HTMLElement).closest('.rl-item, .rl-link, .rl-mini')) window.setTimeout(() => set({ peek: false }), 50) }}>{rail}</aside></> : null}
      <section className="hub-conv" aria-label="Conversation">{children}</section>
      {panel ? (
        <>
          <div className="hub-drag" role="separator" aria-orientation="vertical" tabIndex={0} aria-label="Width of the panel" aria-valuenow={panelW} aria-valuemin={420} aria-valuemax={1100} title="Drag to resize, or use the arrow keys; double-click to reset" onMouseDown={drag} onDoubleClick={() => set({ panelW: defaultPanelW() })} onKeyDown={(e) => { if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault(); const box = ref.current!.getBoundingClientRect(); set({ panelW: Math.round(Math.max(420, Math.min(box.width - (showRail ? 250 : 0) - 380, panelW + (e.key === 'ArrowLeft' ? 24 : -24)))) }) } if (e.key === 'Home') set({ panelW: defaultPanelW() }) }}><span /></div>
          <aside className="hub-panel">{panel}</aside>
        </>
      ) : null}
    </div>
  )
}

/** One entry in the history rail. */
export function RailItem({ title, status, on, fresh, icon, onClick, extra }: { title: string; status: React.ReactNode; on?: boolean; fresh?: boolean; icon?: React.ReactNode; onClick: () => void; extra?: React.ReactNode }) {
  return (
    <div className={`rl-item${on ? ' is-on' : ''}${fresh ? ' is-fresh' : ''}`} role="button" tabIndex={0} onClick={onClick} onKeyDown={(e) => { if (e.key === 'Enter') onClick() }}>
      {icon ? <span className="rl-icon">{icon}</span> : null}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="rl-t">{title}</div>
        <div className="rl-s">{status}</div>
        {extra}
      </div>
    </div>
  )
}

/* The list's own state: which sections are folded (remembered) and what you are searching for. */
interface RailState { q: string; closed: Record<string, boolean>; set: (p: Partial<Pick<RailState, 'q' | 'closed'>>) => void }
export const useRail = create<RailState>((set) => ({
  q: '',
  closed: read('cw.hub.closed', {} as Record<string, boolean>),
  set: (p) => { set(p); if (p.closed) write('cw.hub.closed', p.closed) },
}))
/** Does a title match what is typed in the list's search box. */
export const useRailMatch = () => { const q = useRail((st) => st.q.trim().toLowerCase()); return (t: string) => !q || t.toLowerCase().includes(q) }

export function RailSearch({ placeholder }: { placeholder: string }) {
  const { q, set } = useRail()
  return (
    <label className="rl-search">
      <SearchOutlined />
      <input value={q} onChange={(e) => set({ q: e.target.value })} placeholder={placeholder} aria-label={placeholder} onKeyDown={(e) => { if (e.key === 'Escape') set({ q: '' }) }} />
      {q ? <CloseCircleFilled role="button" aria-label="Clear the search" onClick={() => set({ q: '' })} /> : <kbd>/</kbd>}
    </label>
  )
}

/** A foldable group in the list. While searching, every group opens and shows only what matches. */
export function RailSection({ id, label, n, children, empty }: { id?: string; label: string; n?: number; children?: React.ReactNode; empty?: string }) {
  const { q, closed, set } = useRail()
  const key = id ?? label
  const searching = !!q.trim()
  const open = searching || !closed[key]
  const count = Array.isArray(children) ? children.flat().filter(Boolean).length : n
  if (searching && !count) return null
  return (
    <div className={`rl-sec${open ? '' : ' is-closed'}`} id={id}>
      <div className="rl-h" role="button" tabIndex={0} aria-expanded={open} onClick={() => !searching && set({ closed: { ...closed, [key]: open } })} onKeyDown={(e) => { if ((e.key === 'Enter' || e.key === ' ') && !searching) { e.preventDefault(); set({ closed: { ...closed, [key]: open } }) } }}>
        <span className="rl-h-l"><RightOutlined className="rl-chev" />{label}</span>{n !== undefined ? <span className="rl-n">{searching ? count : n}</span> : null}
      </div>
      {open ? <div className="rl-body">{n === 0 && empty && !searching ? <div className="rl-empty">{empty}</div> : children}</div> : null}
    </div>
  )
}

/** "/" puts you in the search box, as in most lists you can type into. */
export function useSlashToSearch() {
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (e.key !== '/' || t.closest('input, textarea, [contenteditable]')) return
      const box = document.querySelector('.rl-search input') as HTMLInputElement | null
      if (box) { e.preventDefault(); box.focus() }
    }
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [])
}

/** Keep the conversation pinned to its latest message while cards render and grow, unless you scrolled up to read. */
export function useStickToBottom(ref: React.RefObject<HTMLDivElement | null>) {
  useEffect(() => {
    const el = ref.current
    if (!el) return
    let atBottom = true
    const pin = () => { if (atBottom) el.scrollTop = el.scrollHeight }
    const onScroll = () => { atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 160 }
    el.addEventListener('scroll', onScroll, { passive: true })
    const ro = new ResizeObserver(pin)
    const watch = () => { ro.disconnect(); ro.observe(el); Array.from(el.children).forEach((c) => ro.observe(c)) }
    watch()
    const mo = new MutationObserver(() => { watch(); pin() })
    mo.observe(el, { childList: true })
    return () => { el.removeEventListener('scroll', onScroll); ro.disconnect(); mo.disconnect() }
  }, [ref])
}

/** A message's text: paragraphs, **bold**, and numbered or bulleted lines as real lists. */
export function RichText({ text }: { text: string }) {
  const inline = (l: string) => l.split(/(\*\*[^*]+\*\*)/g).map((p, j) => (p.startsWith('**') && p.endsWith('**') ? <strong key={j}>{p.slice(2, -2)}</strong> : <Fragment key={j}>{p}</Fragment>))
  const blocks: { kind: 'p' | 'ol' | 'ul'; lines: string[] }[] = []
  for (const raw of text.split('\n')) {
    const l = raw.trimEnd()
    const kind = /^\d+\.\s/.test(l) ? 'ol' : /^[•\-]\s/.test(l) ? 'ul' : 'p'
    const last = blocks[blocks.length - 1]
    if (!l.trim()) { blocks.push({ kind: 'p', lines: [] }); continue }
    if (last && last.kind === kind && (kind !== 'p' || last.lines.length)) last.lines.push(kind === 'p' ? l : l.replace(/^(\d+\.|[•\-])\s+/, ''))
    else blocks.push({ kind, lines: [kind === 'p' ? l : l.replace(/^(\d+\.|[•\-])\s+/, '')] })
  }
  return (
    <>
      {blocks.filter((b) => b.lines.length).map((b, i) => b.kind === 'p'
        ? <p key={i}>{b.lines.map((l, j) => <Fragment key={j}>{inline(l)}{j < b.lines.length - 1 ? <br /> : null}</Fragment>)}</p>
        : b.kind === 'ol' ? <ol key={i}>{b.lines.map((l, j) => <li key={j}>{inline(l)}</li>)}</ol> : <ul key={i}>{b.lines.map((l, j) => <li key={j}>{inline(l)}</li>)}</ul>)}
    </>
  )
}

/** The agent as a monogram in its colour: quieter than an icon, and the same everywhere. */
export function AgentMark({ agent }: { agent: { name: string; colour: string } }) {
  const short = agent.name.replace(/^Agent\s+/i, '')
  return <span className="agent-mark" title={agent.name} style={{ color: agent.colour, background: `${agent.colour}16`, boxShadow: `inset 0 0 0 1px ${agent.colour}33` }}>{short.charAt(0).toUpperCase()}</span>
}

/* ------------------------------------------------------------------ the journey, always in view */

export interface JStep { key: string; label: string; state: 'done' | 'now' | 'todo'; sub?: string; onClick?: () => void }

/**
 * The steps of the journey as a bar that never scrolls away: done ones ticked and clickable (they take you
 * back to that step), the current one marked, the rest ahead. The conversation is how you work; this is
 * where you are.
 */
export function JourneyBar({ steps, lead }: { steps: JStep[]; lead?: string }) {
  const ref = useRef<HTMLElement>(null)
  const nowKey = steps.find((x) => x.state === 'now')?.key
  /* If the bar is ever wider than the conversation, keep the current step in view. */
  useEffect(() => {
    const bar = ref.current, el = bar?.querySelector<HTMLElement>('.jb-step.is-now')
    if (!bar || !el || bar.scrollWidth <= bar.clientWidth) return
    bar.scrollLeft = Math.max(0, el.offsetLeft - bar.clientWidth / 2 + el.offsetWidth / 2)
  }, [nowKey])
  return (
    <nav className="jb" ref={ref} aria-label="Where you are">
      {lead ? <span className="jb-lead">{lead}</span> : null}
      <ol className="jb-list">
        {steps.map((st, i) => (
          <li key={st.key} className={`jb-step is-${st.state}`}>
            <button type="button" disabled={st.state === 'todo' || !st.onClick} onClick={st.onClick} aria-current={st.state === 'now' ? 'step' : undefined} title={st.state === 'todo' ? `${st.label}: later` : st.state === 'done' ? `${st.label}: done, click to look again` : `${st.label}: now`}>
              <span className="jb-dot">{st.state === 'done' ? <CheckOutlined /> : i + 1}</span>
              <span className="jb-label">{st.label}{st.sub ? <em>{st.sub}</em> : null}</span>
            </button>
          </li>
        ))}
      </ol>
    </nav>
  )
}

/** The latest step card in the conversation, the one waiting for you. */
const liveCard = (feed: HTMLElement | null) => {
  if (!feed) return null
  const cards = Array.from(feed.querySelectorAll<HTMLElement>('.hc:not(.hc-folded)')).filter((c) => c.querySelector('.hc-head'))
  return cards[cards.length - 1] ?? null
}

/** Whether the step waiting for you has scrolled out of sight, and a way back to it. */
export function useDock(feedRef: React.RefObject<HTMLDivElement | null>, deps: unknown[]) {
  const [away, setAway] = useState(false)
  useEffect(() => {
    const feed = feedRef.current
    if (!feed) return
    const check = () => {
      const c = liveCard(feed)
      if (!c) { setAway(false); return }
      const f = feed.getBoundingClientRect(), r = c.getBoundingClientRect()
      setAway(r.bottom < f.top + 48 || r.top > f.bottom - 24)
    }
    check()
    feed.addEventListener('scroll', check, { passive: true })
    const t = window.setTimeout(check, 400)
    return () => { feed.removeEventListener('scroll', check); window.clearTimeout(t) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
  const go = () => { const c = liveCard(feedRef.current); c?.scrollIntoView({ block: 'center', behavior: 'smooth' }); c?.classList.add('is-ping'); window.setTimeout(() => c?.classList.remove('is-ping'), 1200) }
  return { away, go }
}

/** Docked above the message box while the step waiting for you is out of sight. */
export function Dock({ away, go, label, lead = 'Waiting for you' }: { away: boolean; go: () => void; label: string; lead?: string }) {
  if (!away) return null
  return (
    <div className="dock" role="status">
      <span className="dock-dot" />
      <span className="dock-text">{lead}: <b>{label}</b></span>
      <button type="button" className="dock-go" onClick={go}>Go to it</button>
    </div>
  )
}

/** Take the conversation to a message, and light it briefly. */
export const scrollToMsg = (id: string | null | undefined) => {
  if (!id) return
  const el = document.getElementById(`msg-${id}`)
  if (!el) return
  el.scrollIntoView({ block: 'center', behavior: 'smooth' })
  el.classList.add('is-ping')
  window.setTimeout(() => el.classList.remove('is-ping'), 1200)
}
