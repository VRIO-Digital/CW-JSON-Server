import {
  ArrowRightOutlined,
  CheckOutlined,
  DownOutlined,
  FileTextOutlined,
  LockOutlined,
  PlusOutlined,
  ReloadOutlined,
  RightOutlined,
  SaveOutlined,
  UploadOutlined,
} from '@ant-design/icons'
import { App, Button, Checkbox, Col, Input, Row, Space, Spin, Tag, Typography, Upload } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import type { DraftedItem, HeroQuestion, RoleDetails, SourcePick } from '../api/client'
import { questionSql as questionSqlRequest } from '../api/client'
import ApiErrorAlert from '../components/common/ApiErrorAlert'
import PageHeader from '../components/common/PageHeader'
import DraftedStep from '../components/graph/DraftedStep'
import HeroQuestionsStep from '../components/graph/HeroQuestionsStep'
import { LlmRunInline } from '../components/graph/LlmRun'
import SourcesStep from '../components/graph/SourcesStep'
import {
  DISCOVERY,
  DISCOVERY_STEP_MS,
  DOMAIN_OF,
  DRAFT_MS,
  DRAFT_STAGES,
  INDUSTRIES,
  JD_MS,
  JD_STAGES,
  OUT_REASONS,
  ROLES,
  businessNeed,
  industryName,
  jdFindings,
  roleById,
  shortUtility,
  type Area,
  type Finding,
} from '../data/newRole'
import { firstIncompleteStep, stepIssue, type WizardDraft } from '../data/wizardSteps'
import { toMessage } from '../store/asyncState'
import {
  useCoverageStore,
  useDerivationStore,
  useGraphSourcesStore,
  useMetricSuggestStore,
  usePersonaSuggestStore,
  useQuestionSuggestStore,
  useUseCasesStore,
} from '../store/graphStore'
import { useStudioStore } from '../store/studioStore'
import { SP } from '../theme'
import { appPath } from '../api/dataset'
import './NewGraphPage.css'
import './NewRolePage.css'

/*
 * New Role (Veolia CPA prototype, 19 Oct 2026).
 *
 * The New Graph wizard with a role in front of it. Steps 1 and 2 say who the analyst is: the role
 * from the library, the industry, the utilities it covers (found by reading the connected data, not
 * typed), who it reports to, and its responsibilities and tasks (drafted, with an optional job
 * description that suggests changes). Steps 3 to 6 are New Graph's own: the sources the graph is
 * built from, the personas the role serves, the metrics that matter to them and the hero questions.
 * Save and build commits the role and opens it in Graph Studio, which builds the graph as before.
 */

const STEPS = ['Role', 'Responsibilities', 'Sources', 'Personas', 'Metrics', 'Hero questions']
const LAST_STEP = STEPS.length
const DEFAULT_RUN_STAGES = ['Reading the role', 'Drafting candidates']
const formatUpdated = (iso: string | null) => (iso ? new Date(iso).toLocaleString() : 'not saved yet')

type JdState = { file: string; reading: boolean; status: Record<string, 'open' | 'accepted' | 'dismissed'> } | null

export default function NewRolePage() {
  const { message } = App.useApp()
  const navigate = useNavigate()
  const location = useLocation()

  const error = useUseCasesStore((s) => s.error)
  const saving = useUseCasesStore((s) => s.saving)
  const load = useUseCasesStore((s) => s.load)
  const save = useUseCasesStore((s) => s.save)

  const sourcesData = useGraphSourcesStore((s) => s.data)
  const sourcesLoading = useGraphSourcesStore((s) => s.loading)
  const loadGraphSources = useGraphSourcesStore((s) => s.load)

  const persona = usePersonaSuggestStore()
  const metric = useMetricSuggestStore()
  const question = useQuestionSuggestStore()
  const resetDerivation = useDerivationStore((s) => s.reset)
  const resetCoverage = useCoverageStore((s) => s.reset)
  const selectStudioUseCase = useStudioStore((s) => s.select)

  const mode = 'edit' as const
  const [useCaseId, setUseCaseId] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [nameTouched, setNameTouched] = useState(false)
  const [roleId, setRoleId] = useState<string | null>(null)
  const [industry, setIndustry] = useState<string | null>(null)
  const [found, setFound] = useState<{ shown: number; done: boolean }>({ shown: 0, done: false })
  const [utilities, setUtilities] = useState<string[]>([])
  const [reportsTo, setReportsTo] = useState('')
  const [areas, setAreas] = useState<Area[]>([])
  const [drafting, setDrafting] = useState(false)
  const [ready, setReady] = useState(false)
  const [out, setOut] = useState<Record<string, string>>({})
  const [tasksOff, setTasksOff] = useState<Record<string, string[]>>({})
  const [openArea, setOpenArea] = useState<string | null>(null)
  const [taskDraft, setTaskDraft] = useState<Record<string, string>>({})
  const [jd, setJd] = useState<JdState>(null)
  const [personas, setPersonas] = useState<DraftedItem[]>([])
  const [metrics, setMetrics] = useState<DraftedItem[]>([])
  const [sourcePicks, setSourcePicks] = useState<SourcePick[]>([])
  const [heroQuestions, setHeroQuestions] = useState<HeroQuestion[]>([])
  const [step, setStep] = useState(1)
  const [maxStep, setMaxStep] = useState(1)
  const [savedAt, setSavedAt] = useState<string | null>(null)
  const timers = useRef<ReturnType<typeof setTimeout>[]>([])

  const later = (fn: () => void, ms: number) => {
    const t = setTimeout(fn, ms)
    timers.current.push(t)
  }
  useEffect(() => () => timers.current.forEach(clearTimeout), [])

  useEffect(() => {
    void load()
    void loadGraphSources()
  }, [load, loadGraphSources])


  const role = roleById(roleId)
  const discovery = industry ? DISCOVERY[industry] : null
  const inScopeAreas = areas.filter((a) => !out[a.id])
  const graphSources = sourcesData?.sources ?? []
  const domainId = roleId ? DOMAIN_OF[roleId] ?? 'capital-program' : null

  const autoName = useMemo(() => {
    if (!role) return ''
    const names = (discovery?.found ?? []).filter((u) => utilities.includes(u.code) && u.code !== 'SSD').map((u) => shortUtility(u.name))
    return names.length ? `${role.name} · ${names.join(', ')}` : role.name
  }, [role, discovery, utilities])
  useEffect(() => {
    if (!nameTouched) setName(autoName)
  }, [autoName, nameTouched])

  const draft: WizardDraft = {
    name,
    roleId,
    industry,
    utilitiesFound: found.done,
    utilities,
    reportsTo,
    responsibilitiesReady: ready,
    inScope: inScopeAreas.length,
    domainId,
    personas,
    metrics,
    graphSources,
    sourcePicks,
    heroQuestions,
  }

  const roleDetails = (): RoleDetails | null =>
    roleId
      ? {
          role_id: roleId,
          role_name: role?.name ?? roleId,
          industry: industry ?? '',
          utilities,
          reports_to: reportsTo.trim(),
          responsibilities: inScopeAreas.map((a) => a.id),
          tasks: Object.fromEntries(areas.map((a) => [a.id, a.tasks.filter((t) => !(tasksOff[a.id] || []).includes(t))])),
          out,
          job_description: jd?.file ?? null,
        }
      : null

  const need = () => (role ? businessNeed({ role, industry, utilities, reportsTo, inScope: inScopeAreas }) : '')

  /* ------------------------------------------------------------- starting, opening, leaving */

  function resetSuggestions() {
    persona.reset()
    metric.reset()
    question.reset()
    resetCoverage()
    resetDerivation()
  }

  function clearForm() {
    timers.current.forEach(clearTimeout)
    timers.current = []
    setUseCaseId(null)
    setName('')
    setNameTouched(false)
    setRoleId(null)
    setIndustry(null)
    setFound({ shown: 0, done: false })
    setUtilities([])
    setReportsTo('')
    setAreas([])
    setDrafting(false)
    setReady(false)
    setOut({})
    setTasksOff({})
    setOpenArea(null)
    setJd(null)
    setPersonas([])
    setMetrics([])
    setSourcePicks([])
    setHeroQuestions([])
    setStep(1)
    setMaxStep(1)
    setSavedAt(null)
    resetSuggestions()
  }

  function startNew(preselect?: string) {
    clearForm()
    if (preselect) setRoleId(preselect)
  }

  /* Graph Studio's empty state links here with { start: true }. */
  useEffect(() => {
    const st = location.state as { start?: boolean } | null
    if (st?.start) startNew()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /* ------------------------------------------------------------- step 1: finding the utilities */

  function pickIndustry(id: string) {
    if (id === industry) return
    timers.current.forEach(clearTimeout)
    timers.current = []
    setIndustry(id)
    setUtilities([])
    setFound({ shown: 0, done: false })
    const d = DISCOVERY[id]
    d.steps.forEach((_, i) => later(() => setFound({ shown: i + 1, done: false }), DISCOVERY_STEP_MS * (i + 1)))
    later(() => {
      setFound({ shown: d.steps.length, done: true })
      setUtilities(d.found.filter((u) => u.preselect).map((u) => u.code))
    }, DISCOVERY_STEP_MS * (d.steps.length + 1))
  }

  function pickRole(id: string) {
    if (id === roleId) return
    setRoleId(id)
    // The responsibilities belong to the role they were drafted for.
    setAreas([])
    setReady(false)
    setOut({})
    setTasksOff({})
    setJd(null)
  }

  /* ------------------------------------------------------------- step 2: responsibilities */

  function draftResponsibilities() {
    if (!role) return
    setDrafting(true)
    setReady(false)
    later(() => {
      setAreas(role.areas.map((a) => ({ ...a, tasks: [...a.tasks] })))
      setOut({})
      setTasksOff({})
      setJd(null)
      setDrafting(false)
      setReady(true)
      setOpenArea(role.areas[0]?.id ?? null)
    }, DRAFT_MS)
  }

  useEffect(() => {
    if (mode === 'edit' && step === 2 && !ready && !drafting && role) draftResponsibilities()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, step, ready, drafting, roleId])

  function toggleArea(id: string, keep: boolean) {
    setOut((o) => {
      const n = { ...o }
      if (keep) delete n[id]
      else n[id] = OUT_REASONS[0]
      return n
    })
  }

  function toggleTask(areaId: string, task: string, keep: boolean) {
    setTasksOff((t) => {
      const cur = t[areaId] || []
      return { ...t, [areaId]: keep ? cur.filter((x) => x !== task) : [...cur, task] }
    })
  }

  function addTask(areaId: string) {
    const text = (taskDraft[areaId] || '').trim()
    if (!text) return
    setAreas((as) => as.map((a) => (a.id === areaId && !a.tasks.includes(text) ? { ...a, tasks: [...a.tasks, text] } : a)))
    setTaskDraft((d) => ({ ...d, [areaId]: '' }))
  }

  function readJobDescription(file: string) {
    if (!role) return
    setJd({ file, reading: true, status: {} })
    later(() => setJd({ file, reading: false, status: Object.fromEntries(jdFindings(role).map((f) => [f.id, 'open'])) }), JD_MS)
  }

  function decideFinding(f: Finding, accept: boolean) {
    setJd((j) => (j ? { ...j, status: { ...j.status, [f.id]: accept ? 'accepted' : 'dismissed' } } : j))
    if (!accept) return
    if (f.kind === 'task' && f.area && f.value) {
      const v = f.value
      setAreas((as) => as.map((a) => (a.id === f.area && !a.tasks.includes(v) ? { ...a, tasks: [...a.tasks, v] } : a)))
      setOpenArea(f.area)
    }
    if (f.kind === 'scope' && f.area) setOut((o) => ({ ...o, [f.area as string]: f.reason || OUT_REASONS[0] }))
  }

  /* ------------------------------------------------------------- steps 4 to 6 */

  async function runSuggest(what: 'personas' | 'metrics' | 'questions') {
    const ask = what === 'metrics' ? metric.suggest : what === 'questions' ? question.suggest : persona.suggest
    const result = await ask({ domainId, businessNeed: need(), personas: personas.map((p) => p.name) })
    if (!result.ok) message.error(result.error)
  }

  async function writeSql(text: string) {
    if (!useCaseId) return { sql: null, reason: 'Save this draft first: a query is written against the tables this role picked.' }
    try {
      return await questionSqlRequest({ useCaseId, question: text })
    } catch (e) {
      return { sql: null, reason: toMessage(e) }
    }
  }

  /* A metric accepted into the list gets the query it is computed by. */
  useEffect(() => {
    const missing = metrics.filter((m) => m.sql === undefined)
    if (!missing.length || !useCaseId) return
    missing.forEach((m) => {
      void writeSql(m.name).then((out) => setMetrics((prev) => prev.map((x) => (x.name === m.name ? { ...x, sql: out.sql ?? null } : x))))
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [metrics, useCaseId])

  async function editMetric(input: { id: string; name: string; detail: string }) {
    if (!metric.edit) return { ok: false as const, error: 'This pool has no editable metrics.' }
    const result = await metric.edit(input)
    if (!result.ok && !result.savedLocally) message.error(result.error)
    return result
  }

  /* ------------------------------------------------------------- saving and moving */

  async function saveDraft(nextStep = step, status?: 'committed') {
    const result = await save({
      useCaseId,
      name,
      domainId,
      businessNeed: need(),
      personas,
      metrics,
      sources: sourcePicks,
      heroQuestions,
      gapDecisions: [],
      step: nextStep,
      status,
      role: roleDetails(),
    })
    if (!result.ok) {
      message.error(result.error)
      return null
    }
    setUseCaseId(result.useCase.useCaseId)
    setSavedAt(result.useCase.updatedAt)
    return result.useCase
  }

  async function next() {
    const issue = stepIssue(step, draft)
    if (issue) {
      message.warning(issue)
      return
    }
    const nextStep = Math.min(step + 1, LAST_STEP)
    if (!(await saveDraft(nextStep))) return
    message.success('Draft saved.')
    setStep(nextStep)
    setMaxStep((m) => Math.max(m, nextStep))
  }

  function goToStep(target: number) {
    if (target <= step) {
      setStep(target)
      return
    }
    if (target > maxStep) {
      message.warning(`Complete step ${maxStep} first. Steps unlock as you finish them.`)
      return
    }
    const blocked = firstIncompleteStep(target - 1, draft, step)
    if (blocked !== null) {
      setStep(blocked)
      message.warning(`Step ${blocked} is unfinished: ${stepIssue(blocked, draft)}`)
      return
    }
    setStep(target)
  }

  async function buildRole() {
    const issue = firstIncompleteStep(LAST_STEP, draft)
    if (issue !== null) {
      setStep(issue)
      message.warning(`Step ${issue} is unfinished: ${stepIssue(issue, draft)}`)
      return
    }
    const u = await saveDraft(LAST_STEP, 'committed')
    if (!u) return
    selectStudioUseCase(u.useCaseId)
    message.success('Role saved. Build its graph in Graph Studio.')
    navigate(appPath(`/graph-studio/${encodeURIComponent(u.useCaseId)}`), { state: { tab: 'build' } })
  }

  if (error) return <ApiErrorAlert error={error} onRetry={() => void load()} />

  /* ------------------------------------------------------------- the wizard */

  const stepBody = () => {
    if (step === 1) {
      return (
        <Row gutter={[SP.lg, SP.lg]}>
          <Col xs={24} xl={18}>
            <div className="ng-field">
              <span className="ng-label">Role</span>
              <div className="nr-pick">
                {ROLES.map((r) => (
                  <button key={r.id} type="button" className={`nr-opt${roleId === r.id ? ' is-on' : ''}`} onClick={() => pickRole(r.id)} aria-pressed={roleId === r.id}>
                    <b>{r.name}</b>
                    <span>{r.blurb}</span>
                  </button>
                ))}
              </div>
            </div>

            {role ? (
              <div className="ng-field">
                <span className="ng-label">Industry</span>
                <div className="nr-inds">
                  {INDUSTRIES.map((i) => (
                    <button key={i.id} type="button" className={`nr-ind${industry === i.id ? ' is-on' : ''}`} onClick={() => pickIndustry(i.id)} aria-pressed={industry === i.id}>
                      <b>{i.name}</b>
                      <span>{i.note}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : null}

            {discovery ? (
              <div className="ng-field" data-testid="utilities">
                <span className="ng-label">Utilities this role covers</span>
                <div className="nr-disc">
                  <div className="nr-disc-head">
                    {found.done ? <CheckOutlined className="nr-ok" /> : <Spin size="small" />}
                    <span>{found.done ? `Read from your connected data` : `Finding the ${industryName(industry).toLowerCase()} utilities in your connected data`}</span>
                  </div>
                  <ol className="nr-disc-steps">
                    {discovery.steps.slice(0, found.shown).map((s) => (
                      <li key={s}><CheckOutlined /> {s}</li>
                    ))}
                  </ol>
                  {found.done ? (
                    discovery.found.length ? (
                      <div className="nr-utils">
                        {discovery.found.map((u) => (
                          <label key={u.code} className={`nr-util${utilities.includes(u.code) ? ' is-on' : ''}`}>
                            <Checkbox
                              checked={utilities.includes(u.code)}
                              onChange={(e) => setUtilities((cur) => (e.target.checked ? [...cur, u.code] : cur.filter((c) => c !== u.code)))}
                            />
                            <span className="nr-util-body">
                              <b>{u.name}</b>
                              <span>{u.region} · {u.commission}</span>
                              <span className="nr-util-n">{u.projects.toLocaleString('en-US')} projects · ${u.approvedB.toFixed(2)}B approved</span>
                            </span>
                          </label>
                        ))}
                      </div>
                    ) : (
                      <div className="nr-none">{discovery.none}</div>
                    )
                  ) : null}
                </div>
              </div>
            ) : null}

            {found.done && utilities.length ? (
              <>
                <div className="ng-field">
                  <label className="ng-label" htmlFor="nr-reports">Reports to</label>
                  <Input
                    id="nr-reports"
                    type="email"
                    value={reportsTo}
                    onChange={(e) => setReportsTo(e.target.value)}
                    placeholder="name@company.com"
                    style={{ maxWidth: 360 }}
                  />
                  <span className="ng-help">The person this role reports its work to. Any email address.</span>
                </div>
                <div className="ng-field">
                  <label className="ng-label" htmlFor="nr-name">Role name</label>
                  <Input
                    id="nr-name"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value)
                      setNameTouched(true)
                    }}
                    style={{ maxWidth: 520 }}
                  />
                </div>
              </>
            ) : null}
          </Col>
        </Row>
      )
    }

    if (step === 2) {
      const findings = role ? jdFindings(role) : []
      return (
        <Row gutter={[SP.lg, SP.lg]}>
          <Col xs={24} xl={18}>
            <div className="nr-resp-head">
              <div>
                <div className="nr-resp-title">What the {role?.name ?? 'role'} is responsible for</div>
                <div className="ng-help">Drafted from the role library for {industryName(industry).toLowerCase()} utilities. Keep what applies, take out what is done elsewhere, and open one to change its tasks.</div>
              </div>
              <Space size={SP.sm}>
                <Upload
                  showUploadList={false}
                  disabled={!ready || !!jd?.reading}
                  beforeUpload={(file) => {
                    readJobDescription(file.name)
                    return Upload.LIST_IGNORE
                  }}
                >
                  <Button icon={<UploadOutlined />} disabled={!ready || !!jd?.reading} data-testid="jd-upload">
                    Add job description
                  </Button>
                </Upload>
                <Button icon={<ReloadOutlined />} disabled={drafting} onClick={draftResponsibilities}>
                  Draft again
                </Button>
              </Space>
            </div>

            {drafting ? <LlmRunInline label={`Drafting the responsibilities of a ${role?.name ?? 'role'}…`} stages={DRAFT_STAGES} /> : null}

            {jd ? (
              <div className="nr-jd" data-testid="jd">
                <div className="nr-jd-head">
                  <FileTextOutlined /> <b>{jd.file}</b>
                  <span className="nr-dim">{jd.reading ? ' · reading' : ` · ${findings.length} suggestions`}</span>
                </div>
                {jd.reading ? (
                  <LlmRunInline label="Reading the job description…" stages={JD_STAGES} />
                ) : (
                  findings.map((f) => (
                    <div key={f.id} className={`nr-find is-${jd.status[f.id] ?? 'open'}`}>
                      <div className="nr-find-body">
                        <div>{f.text}</div>
                        <div className="nr-quote">{f.quote}</div>
                      </div>
                      <div className="nr-find-acts">
                        {f.kind === 'confirm' ? (
                          <Tag color="green">Matches</Tag>
                        ) : jd.status[f.id] === 'open' ? (
                          <>
                            <Button size="small" type="primary" onClick={() => decideFinding(f, true)}>Accept</Button>
                            <Button size="small" onClick={() => decideFinding(f, false)}>Dismiss</Button>
                          </>
                        ) : (
                          <Tag>{jd.status[f.id] === 'accepted' ? 'Accepted' : 'Dismissed'}</Tag>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            ) : null}

            {ready ? (
              <div className="nr-areas">
                {areas.map((a) => {
                  const kept = !out[a.id]
                  const isOpen = openArea === a.id
                  const off = tasksOff[a.id] || []
                  return (
                    <div key={a.id} className={`nr-area${kept ? '' : ' is-out'}`} data-area={a.id}>
                      <div className="nr-area-row">
                        <Checkbox checked={kept} onChange={(e) => toggleArea(a.id, e.target.checked)} aria-label={`Keep ${a.name}`} />
                        <button type="button" className="nr-area-name" onClick={() => setOpenArea(isOpen ? null : a.id)}>
                          {isOpen ? <DownOutlined /> : <RightOutlined />}
                          <b>{a.name}</b>
                          <span className="nr-area-what">{a.what}</span>
                        </button>
                        <span className="nr-area-n">{kept ? `${a.tasks.length - off.length} tasks` : 'Out of scope'}</span>
                      </div>
                      {!kept ? (
                        <div className="nr-reasons">
                          {OUT_REASONS.map((r) => (
                            <button key={r} type="button" className={`gc-chip${out[a.id] === r ? ' is-on' : ''}`} onClick={() => setOut((o) => ({ ...o, [a.id]: r }))}>
                              {r}
                            </button>
                          ))}
                        </div>
                      ) : null}
                      {isOpen && kept ? (
                        <div className="nr-tasks">
                          {a.tasks.map((t) => (
                            <label key={t} className="nr-task">
                              <Checkbox checked={!off.includes(t)} onChange={(e) => toggleTask(a.id, t, e.target.checked)} />
                              <span>{t}</span>
                            </label>
                          ))}
                          <div className="nr-task-add">
                            <Input
                              size="small"
                              placeholder="Add a task"
                              value={taskDraft[a.id] || ''}
                              onChange={(e) => setTaskDraft((d) => ({ ...d, [a.id]: e.target.value }))}
                              onPressEnter={() => addTask(a.id)}
                            />
                            <Button size="small" icon={<PlusOutlined />} onClick={() => addTask(a.id)}>Add</Button>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  )
                })}
                <div className="ng-help">{inScopeAreas.length} of {areas.length} responsibilities in scope.</div>
              </div>
            ) : null}
          </Col>
        </Row>
      )
    }

    if (step === 3) {
      return (
        <Row gutter={[SP.lg, SP.lg]}>
          <Col xs={24}>
            <div className="ng-help" style={{ marginBottom: SP.md }}>Pick the connected data this role's graph is built from. Tables become the structured lane; documents and mail become the document lane.</div>
            <SourcesStep sources={graphSources} loading={sourcesLoading} picks={sourcePicks} onPicks={setSourcePicks} />
          </Col>
        </Row>
      )
    }

    if (step === 4) {
      return (
        <Row gutter={[SP.lg, SP.lg]}>
          <Col xs={24} xl={16}>
            <DraftedStep
              intro={
                <div className="ng-ai">
                  <div>
                    <strong>Who does this role serve?</strong>
                    <div className="ng-ai-sub">The people it reports its analysis to. Drafted from the responsibilities and the connected data; keep the ones that fit, or add your own.</div>
                  </div>
                </div>
              }
              suggestLabel="Suggest personas"
              suggestedLabel="Suggested personas"
              addLabel="Add persona"
              namePlaceholder="Persona, e.g. Capital Controller"
              descriptionPlaceholder="What they ask, e.g. Will we spend the year's plan by December?"
              listLabel="Personas this role serves"
              listEmptyText="No personas yet. Add one, or use Suggest personas."
              items={personas}
              onItems={setPersonas}
              suggestions={persona.suggestions}
              asked={persona.asked}
              emptyReason={persona.emptyReason}
              suggesting={persona.suggesting}
              runStages={persona.run?.stages ?? DEFAULT_RUN_STAGES}
              runCost={persona.run?.costUsd}
              runCap={persona.run?.costCapUsd}
              onSuggest={() => void runSuggest('personas')}
              onDismiss={persona.dismiss}
            />
          </Col>
        </Row>
      )
    }

    if (step === 5) {
      return (
        <Row gutter={[SP.lg, SP.lg]}>
          <Col xs={24} xl={18}>
            <DraftedStep
              intro={
                <div className="ng-ai">
                  <div>
                    <strong>What matters to {personas.length === 1 ? personas[0].name : `the ${personas.length} personas`}?</strong>
                    <div className="ng-ai-sub">Each metric is computed from the sources you picked; the query is written when you keep it, and Graph Studio's Playground runs it.</div>
                  </div>
                </div>
              }
              suggestLabel="Suggest metrics"
              suggestedLabel="Suggested metrics"
              addLabel="Add metric"
              namePlaceholder="Metric, e.g. Forecast variance"
              descriptionPlaceholder="How it is measured, e.g. forecast at completion minus approved budget"
              listLabel="Metrics this role reports"
              listEmptyText="No metrics yet. Add one, or use Suggest metrics."
              items={metrics}
              onItems={setMetrics}
              suggestions={metric.suggestions}
              asked={metric.asked}
              emptyReason={metric.emptyReason}
              suggesting={metric.suggesting}
              runStages={metric.run?.stages ?? DEFAULT_RUN_STAGES}
              runCost={metric.run?.costUsd}
              runCap={metric.run?.costCapUsd}
              onSuggest={() => void runSuggest('metrics')}
              onDismiss={metric.dismiss}
              onEdit={metric.edit ? editMetric : undefined}
              itemExtra={(m) =>
                m.sql === undefined ? (
                  <span className="nr-sql-wait"><Spin size="small" /> Writing the query…</span>
                ) : m.sql ? (
                  <details className="nr-sql">
                    <summary>SQL</summary>
                    <pre>{m.sql}</pre>
                  </details>
                ) : (
                  <span className="nr-sql-wait">No query: nothing in the picked tables computes it yet.</span>
                )
              }
            />
          </Col>
        </Row>
      )
    }

    return (
      <Row gutter={[SP.lg, SP.lg]}>
        <Col xs={24} xl={18}>
          <HeroQuestionsStep
            questions={heroQuestions}
            onQuestions={setHeroQuestions}
            onWriteSql={writeSql}
            suggestions={question.suggestions}
            asked={question.asked}
            emptyReason={question.emptyReason}
            suggesting={question.suggesting}
            runStages={question.run?.stages ?? DEFAULT_RUN_STAGES}
            runCost={question.run?.costUsd}
            runCap={question.run?.costCapUsd}
            onSuggest={() => void runSuggest('questions')}
            onDismiss={question.dismiss}
          />
        </Col>
      </Row>
    )
  }

  return (
    <>
      <PageHeader
        title="Add a new role"
        subtitle={role ? `${role.name}${industry ? ` · ${industryName(industry)}` : ''}` : 'Pick the role, the industry it works in and the utilities it covers.'}
        actions={
          <>
            <Tag>{savedAt ? `Draft · saved ${formatUpdated(savedAt)}` : 'Draft · not saved yet'}</Tag>
            <Button icon={<SaveOutlined />} loading={saving} disabled={!name.trim()} onClick={() => void saveDraft().then((u) => u && message.success('Draft saved.'))}>
              Save draft
            </Button>
          </>
        }
      />

      <Typography.Paragraph type="secondary" style={{ fontSize: 13, marginTop: -SP.md }}>
        Step {step} of {LAST_STEP} · {STEPS[step - 1]}. Steps unlock as you complete them; your answers stay editable.
      </Typography.Paragraph>

      <div className="ng-steps">
        {STEPS.map((label, i) => {
          const n = i + 1
          const locked = n > maxStep
          const state = n === step ? ' is-active' : locked ? ' is-locked' : ' is-done'
          return (
            <span key={label} style={{ display: 'inline-flex', alignItems: 'center', gap: SP.sm }}>
              {i > 0 ? <span className="ng-step-dash" /> : null}
              <button
                type="button"
                className={`ng-step${state}`}
                onClick={() => goToStep(n)}
                aria-current={n === step ? 'step' : undefined}
                aria-disabled={locked || undefined}
              >
                <span className="ng-step-num">{locked ? <LockOutlined /> : n}</span>
                {label}
              </button>
            </span>
          )
        })}
      </div>

      <div className="ng-form">
        {stepBody()}
        <div className="ng-foot">
          <span />
          <Space size={SP.sm}>
            {step > 1 ? <Button onClick={() => setStep(step - 1)}>Back</Button> : null}
            {step < LAST_STEP ? (
              <Button type="primary" loading={saving} onClick={() => void next()}>
                Next <ArrowRightOutlined />
              </Button>
            ) : (
              <Button type="primary" loading={saving} disabled={stepIssue(LAST_STEP, draft) !== null} onClick={() => void buildRole()}>
                Save and build graph <ArrowRightOutlined />
              </Button>
            )}
          </Space>
        </div>
      </div>
    </>
  )
}
