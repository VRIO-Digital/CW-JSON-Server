import { App, Alert, Select, Space, Spin, Tabs, Tag, Typography } from 'antd'
import { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import type { TypeLinkDecision } from '../api/client'
import ApiErrorAlert from '../components/common/ApiErrorAlert'
import NoSourceConnected from '../components/common/NoSourceConnected'
import PageHeader from '../components/common/PageHeader'
import { brandWords } from '../data/providerBrand'
import StudioBridgeTab from '../components/studio/StudioBridgeTab'
import StudioBuildTab from '../components/studio/StudioBuildTab'
import StudioCanvas2Tab from '../components/studio/StudioCanvas2Tab'
// Hidden with the tab that used it: see the commented-out 'canvas' tab entry below.
// import StudioCanvasTab from '../components/studio/StudioCanvasTab'
import StudioPlaygroundTab from '../components/studio/StudioPlaygroundTab'
import StudioVersionsTab from '../components/studio/StudioVersionsTab'
import { useAuthStore } from '../store/authStore'
import {
  selectBridgeForming,
  selectBuildRunning,
  selectFormingBridge,
  selectOutputReadable,
  selectUseCase,
  useStudioStore,
} from '../store/studioStore'
import { appPath } from '../api/dataset'
import { SP } from '../theme'

/**
 * Graph Studio: **one studio for a role, whichever lanes it has.**
 *
 * This replaces a split between a structured studio and a document studio, which forced a reader to
 * know which screen a role belonged to and could not show that two graphs answer one business
 * question. What the studio offers follows from what the role has *attached*: never from a
 * declared kind, which would be single-valued (so "both lanes" is unexpressible) and frozen at
 * commit (so a role could not grow into a second one).
 *
 * **One selector governs the whole page.** Every tab reads the role held in the store, so no tab
 * carries a picker that could disagree with the one above it.
 *
 * **The two graphs remain two graphs**: separate builds, separate canvases, and neither resolving
 * entities against the other. What is unified is the role and its *approval*: a version names
 * the artifacts published together, in one act.
 */
export default function GraphStudioPage() {
  const { message } = App.useApp()
  const navigate = useNavigate()
  /* Named, because `location` is also a global and reading that one would silently return undefined
     rather than the router's state. */
  const routerLocation = useLocation()
  const { useCaseId: routeUseCaseId } = useParams<{ useCaseId?: string }>()

  const useCases = useStudioStore((s) => s.useCases)
  const connectedSources = useStudioStore((s) => s.connectedSources)
  const useCaseId = useStudioStore((s) => s.useCaseId)
  const loading = useStudioStore((s) => s.loading)
  const error = useStudioStore((s) => s.error)
  const sgbBuild = useStudioStore((s) => s.sgbBuild)
  const dgbJob = useStudioStore((s) => s.dgbJob)
  const sgbGraph = useStudioStore((s) => s.sgbGraph)
  const story = useStudioStore((s) => s.story)
  const storyDraft = useStudioStore((s) => s.storyDraft)
  const drafting = useStudioStore((s) => s.drafting)
  const entities = useStudioStore((s) => s.entities)
  const relations = useStudioStore((s) => s.relations)
  const bridges = useStudioStore((s) => s.bridges)
  const bridgeId = useStudioStore((s) => s.bridgeId)
  const typeLinks = useStudioStore((s) => s.typeLinks)
  const unreviewedCount = useStudioStore((s) => s.unreviewedCount)
  const versions = useStudioStore((s) => s.versions)
  const playground = useStudioStore((s) => s.playground)
  const playgroundLoading = useStudioStore((s) => s.playgroundLoading)
  const building = useStudioStore((s) => s.building)
  const busy = useStudioStore((s) => s.busy)
  const sweeping = useStudioStore((s) => s.sweeping)
  const savingLinkId = useStudioStore((s) => s.savingLinkId)

  const useCase = useStudioStore(selectUseCase)
  const buildRunning = useStudioStore(selectBuildRunning)
  const bridgeForming = useStudioStore(selectBridgeForming)
  const formingBridge = useStudioStore(selectFormingBridge)
  const outputReadable = useStudioStore(selectOutputReadable)

  const load = useStudioStore((s) => s.load)
  const select = useStudioStore((s) => s.select)
  const build = useStudioStore((s) => s.build)
  const poll = useStudioStore((s) => s.poll)
  const draft = useStudioStore((s) => s.draft)
  const saveStory = useStudioStore((s) => s.saveStory)
  const selectBridge = useStudioStore((s) => s.selectBridge)
  const decide = useStudioStore((s) => s.decide)
  const acceptAll = useStudioStore((s) => s.acceptAll)
  const publish = useStudioStore((s) => s.publish)
  const recordVersion = useStudioStore((s) => s.recordVersion)
  const unpublish = useStudioStore((s) => s.unpublish)
  const savePlaygroundLists = useStudioStore((s) => s.savePlaygroundLists)

  const signedInAs = useAuthStore((s) => s.identity?.email ?? null)

  /* Land on Build when arriving from the wizard's last step: the run it just started is the thing
     to watch. Every other arrival lands there too, because a studio with nothing built has nothing
     else to show. */
  const [tab, setTab] = useState(
    () => (routerLocation.state as { tab?: string } | null)?.tab ?? 'build',
  )

  useEffect(() => {
    void load()
  }, [load])

  /* A role named in the URL wins over the store's default, so New Role can hand a reader
     straight to the graph they just committed. Only honoured once it is really in the list, so a
     stale or hand-edited address leaves the selector where it was rather than emptying the page. */
  const claimed = useRef<string | null>(null)
  useEffect(() => {
    if (!routeUseCaseId || claimed.current === routeUseCaseId) return
    if (!useCases.some((u) => u.useCaseId === routeUseCaseId)) return
    claimed.current = routeUseCaseId
    select(routeUseCaseId)
  }, [routeUseCaseId, useCases, select])

  /*
   * The build watch. **A poll that stops is not a subscription**, so it runs only while something is
   * in flight and the store's own `poll` re-reads the whole studio once the last lane settles: which
   * is what records the version and unlocks the other tabs.
   */
  useEffect(() => {
    /* **The lanes and the Bridge are one run**, so the watch spans both: a Bridge is formed FROM two
       finished graphs, and a poll that stopped with the lanes would leave the formation to be found
       by a reader pressing reload. */
    if (!buildRunning && !bridgeForming) return
    const id = window.setInterval(() => void poll(), 1200)
    return () => window.clearInterval(id)
  }, [buildRunning, bridgeForming, poll])

  /*
   * **Where the run ends is the Bridge tab**, because that is where the next act is: every
   * correspondence has to be decided before a version can be published, and a reader left on Build
   * would be looking at a finished pipeline with nothing left to do on it.
   *
   * Only after a formation this reader actually watched: the ref is what says so. Arriving at a
   * studio whose Bridge succeeded last week must not yank them off the tab they opened.
   */
  const watchedFormation = useRef(false)
  useEffect(() => {
    if (bridgeForming) {
      watchedFormation.current = true
      return
    }
    if (!watchedFormation.current) return
    watchedFormation.current = false
    setTab('bridge')
  }, [bridgeForming])

  const report = async (run: () => Promise<{ ok: true } | { ok: false; error: string }>) => {
    const result = await run()
    if (!result.ok) message.error(result.error)
    return result
  }

  /* The whole-window canvas, addressed from here because the dataset prefix is the page's to add , 
     a tab that built its own in-app URL would be a second place the dataset letter lives. */
  // Hidden with the 'canvas' tab that read it: see the commented-out entry below.
  // const fullViewHref = appPath(`/graph-studio/${encodeURIComponent(useCaseId ?? '')}/canvas`)

  const publishedBridgeId =
    versions.find((v) => v.publishedAt !== null)?.bridgeBuildId ?? null

  /* The version this Bridge would publish as, where one is already recorded: `null` for a draft,
     which is normal: a version is minted when somebody approves, not on their first edit. */
  const pendingVersion = versions.find((v) => v.bridgeBuildId === bridgeId) ?? null

  /* Publishing from the Bridge tab records the version first where there is not one yet, which is
     the normal case for a draft. One path, so the two tabs cannot approve different things. */
  const publishThisBridge = async () => {
    const existing = versions.find((v) => v.bridgeBuildId === bridgeId)
    if (existing) return publish(existing.graphVersionId, signedInAs)
    const recorded = await recordVersion()
    if (!recorded.ok) return recorded
    const next = useStudioStore.getState().versions.find((v) => v.bridgeBuildId === bridgeId)
    if (!next) {
      return { ok: false as const, error: 'No version names this Bridge yet: rebuild it and try again.' }
    }
    return publish(next.graphVersionId, signedInAs)
  }

  if (loading && useCases.length === 0) {
    return (
      <div style={{ padding: SP.xl, textAlign: 'center' }}>
        <Spin />
      </div>
    )
  }

  return (
    <>
      <PageHeader
        title="Graph Studio"
        subtitle="Build a role's graph from its tables, documents and mail, review what the Bridge found between them, and publish the version the role answers from."
      />

      {error ? <ApiErrorAlert error={error} onRetry={() => void load()} /> : null}

      {/*
        * **Two dead ends, and they need different exits.**
        *
        * Nothing connected at all is the outer one: every lane derives from a source somebody
        * connected, so the studio has nothing to build *from* and the fix is on Sources. Connected
        * but no role is the inner one, and the fix is New Role. Telling a reader to connect a
        * source when they already have three would be useless advice, and telling them to write a
        * brief when there is no data behind it sends them to a wizard that cannot finish.
        *
        * `connectedSources === 0` rather than falsy: it is null until the first load lands, and
        * treating that as zero would flash "no data source is connected" over a tenant that has some.
        */}
      {connectedSources === 0 ? (
        <NoSourceConnected detail={`A graph is built from data this tenant has connected. Connect ${brandWords().structuredSource}, ${brandWords().docsSource} or ${brandWords().mailSource}: its tables, documents and mail become the lanes a role is built from here.`} />
      ) : useCases.length === 0 ? (
        <Alert
          type="info"
          showIcon
          title="No role to build yet"
          description="Set one up in New Role. Graph Studio is where a saved role becomes a graph, so there is nothing here until one exists."
          action={
            <Typography.Link onClick={() => navigate(appPath('/new-graph'), { state: { start: true } })}>
              Open New Role
            </Typography.Link>
          }
        />
      ) : (
        <Space direction="vertical" size={SP.base} style={{ width: '100%' }}>
          <Space wrap size={SP.sm} align="center">
            <Typography.Text type="secondary">Role</Typography.Text>
            <Select
              style={{ minWidth: 320 }}
              value={useCaseId ?? undefined}
              onChange={select}
              options={useCases.map((u) => ({
                value: u.useCaseId,
                label: u.name ?? u.useCaseId,
              }))}
            />
            {useCase ? (
              <>
                {/* The lanes, stated on the selector as well as on the Build tab: "why does this
                    one offer no document build" is the question a shortened list cannot answer. */}
                <Tag color={useCase.hasStructured ? 'blue' : 'default'}>
                  {useCase.hasStructured ? 'structured' : 'no structured lane'}
                </Tag>
                <Tag color={useCase.hasDocuments ? 'purple' : 'default'}>
                  {useCase.hasDocuments ? 'documents' : 'no document lane'}
                </Tag>
                <Tag color={useCase.status === 'committed' ? 'green' : 'default'}>
                  {useCase.status}
                </Tag>
              </>
            ) : null}
          </Space>

          {/*
           * **What happens between the lanes finishing and the Bridge tab opening**, said where the
           * reader is watching rather than left as a tab that lights up on its own.
           *
           * It states the two things a formation decides on their behalf: that a model is asked once
           * per Concept, and that what it produces is recorded **unpublished**: because a build
           * never publishes, and a reader who was not told would meet a live graph they never
           * approved.
           */}
          {/*
           * **The formation notice stood here and is gone: removed on request.** While a Bridge
           * was forming it said *Both graphs are built. Forming the Bridge between them.*, and
           * stated the two things a formation decides on a reader's behalf: that a model is asked
           * once per Concept, and that what it produces is recorded **unpublished**.
           *
           * **Neither fact changed, only the saying of it.** `maybeAutoFormBridge` still forms the
           * Bridge once both lanes land, a build still publishes nothing, and the run is still
           * narrated on the Build tab: which keeps its own *Both lanes have landed* notice, so a
           * reader watching the run is not left with nothing.
           *
           * **What it costs is stated rather than glossed**: a reader on another tab no longer
           * learns that a formation is in flight, or that a model is involved in it.
           * **Do not restore it without being asked.**
           */}

          {/*
           * **The lock notice stood here and is gone: removed on request.** It was an Alert above
           * the tabs saying either *Nothing has been built for this role yet* or, while a run
           * was in flight, *A build is running*, each naming the three tabs that read a build's
           * output and what to do about it.
           *
           * **The lock itself is untouched**: `selectOutputReadable` still closes Bridge, Canvas
           * and Versions until a build lands and again while one runs, because what they would
           * otherwise show is the previous build's output with nothing saying so, and settling a
           * correspondence against a canvas being superseded is a decision made on stale evidence.
           *
           * **What it costs is stated rather than glossed**: three tabs are now disabled with
           * nothing on screen saying why or which act opens them. Both branches went together,
           * because a notice that appeared only mid-run would read as a fault rather than as the
           * one state it still covered. `check-docs` asserts the absence of both.
           * **Do not restore either without being asked.**
           */}

          {useCase ? (
            <Tabs
              activeKey={tab}
              onChange={setTab}
              items={[
                {
                  key: 'build',
                  label: 'Build',
                  children: (
                    <StudioBuildTab
                      useCase={useCase}
                      sgbBuild={sgbBuild}
                      dgbJob={dgbJob}
                      formingBridge={formingBridge}
                      bridgeFollows={bridgeForming}
                      story={story}
                      storyDraft={storyDraft}
                      drafting={drafting}
                      building={building}
                      busy={busy}
                      onBuild={(text) => void report(() => build(text))}
                      onDraft={() => void report(() => draft())}
                      onSaveStory={(text) => void report(() => saveStory(text))}
                    />
                  ),
                },
                {
                  key: 'bridge',
                  label: 'Bridge',
                  disabled: !outputReadable,
                  children: (
                    <StudioBridgeTab
                      bridges={bridges}
                      bridgeId={bridgeId}
                      typeLinks={typeLinks}
                      unreviewedCount={unreviewedCount}
                      canForm={useCase.hasStructured && useCase.hasDocuments}
                      laneNote={null}
                      publishedBridgeId={publishedBridgeId}
                      onSelectBridge={(id) => void selectBridge(id)}
                      sweeping={sweeping}
                      savingLinkId={savingLinkId}
                      publishing={busy}
                      pendingVersionNumber={pendingVersion?.versionNumber ?? null}
                      onDecide={(link, decision: TypeLinkDecision) =>
                        void report(() => decide(link, decision, signedInAs))
                      }
                      onAcceptAll={() => void report(() => acceptAll(signedInAs))}
                      onPublish={() => void report(publishThisBridge)}
                    />
                  ),
                },
                {
                  /*
                   * **Locked with the three below it, on request: a reversal on record.** It was
                   * deliberately unlocked, because it reads the *brief* (the metrics and hero
                   * questions the wizard accepted), which exists the moment a role does, and a
                   * lock hid a ready list behind a build that had not run. That reasoning is still
                   * true of the data; what the request weighs heavier is the strip moving as one , 
                   * a single tab left open while a run supersedes everything beside it reads as a
                   * tab the lock forgot. The flag is the same `outputReadable` the other three
                   * read, never a second expression of the gate.
                   */
                  key: 'playground',
                  label: 'Playground',
                  disabled: !outputReadable,
                  children: (
                    <StudioPlaygroundTab
                      playground={playground}
                      loading={playgroundLoading}
                      busy={busy}
                      signedInAs={signedInAs}
                      onSaveMetrics={(metrics) =>
                        void report(() => savePlaygroundLists({ metrics }, signedInAs))
                      }
                      onSaveQueries={(goldenQueries) =>
                        void report(() => savePlaygroundLists({ goldenQueries }, signedInAs))
                      }
                      onSaveFiles={(files) =>
                        void report(() => savePlaygroundLists({ files }, signedInAs))
                      }
                      onError={(text) => message.error(text)}
                    />
                  ),
                },
                // Hidden on request: kept rather than deleted so it can come back with one
                // uncomment. Canvas 2 (below) now carries the "Canvas" name and the active tab
                // slot; this is "Canvas_old", off the tab strip entirely.
                //
                // {
                //   key: 'canvas',
                //   label: 'Canvas_old',
                //   disabled: !outputReadable,
                //   children: (
                //     <StudioCanvasTab
                //       structured={sgbGraph}
                //       entities={entities}
                //       relations={relations}
                //       typeLinks={typeLinks}
                //       hasStructured={useCase.hasStructured}
                //       hasDocuments={useCase.hasDocuments}
                //       fullViewHref={fullViewHref}
                //     />
                //   ),
                // },
                {
                  /*
                   * **A second reading of one graph, never a second graph.** It builds its nodes and
                   * lane edges from the same two derivations the Canvas tab does: so the two frames
                   * cannot come to hold different graphs: and what it adds is a settled arrangement,
                   * an entity type raised to a node so the Bridge is drawn where it is claimed, and
                   * filters that remove rows rather than dim them. Locked with the three tabs that
                   * read a build's output, for the reason they are: what it would otherwise show is
                   * the previous build's graph with nothing saying so.
                   *
                   * Carries the "Canvas" name now: the previous Canvas tab (`StudioCanvasTab`,
                   * key `canvas`) is commented out above on request rather than deleted.
                   */
                  key: 'canvas2',
                  label: 'Canvas',
                  disabled: !outputReadable,
                  children: (
                    <StudioCanvas2Tab
                      structured={sgbGraph}
                      entities={entities}
                      relations={relations}
                      typeLinks={typeLinks}
                    />
                  ),
                },
                {
                  key: 'versions',
                  label: 'Versions',
                  disabled: !outputReadable,
                  children: (
                    <StudioVersionsTab
                      versions={versions}
                      busy={busy}
                      signedInAs={signedInAs}
                      onPublish={(id) => void report(() => publish(id, signedInAs))}
                      onUnpublish={(id) => void report(() => unpublish(id))}
                    />
                  ),
                },
              ]}
            />
          ) : null}
        </Space>
      )}
    </>
  )
}
