import { ApartmentOutlined, FundProjectionScreenOutlined, LayoutOutlined, LeftOutlined, RightOutlined, ArrowUpOutlined, BulbOutlined, CheckOutlined, CloseOutlined, CopyOutlined, DownloadOutlined, EditOutlined, FileAddOutlined, FileExcelOutlined, FileImageOutlined, FilePdfOutlined, FilePptOutlined, FileTextOutlined, LinkOutlined, MessageOutlined, PaperClipOutlined, PlusOutlined, ReloadOutlined, ShareAltOutlined, TableOutlined, UploadOutlined } from '@ant-design/icons'
import { App, Button, Checkbox, Col, Drawer, Dropdown, Flex, Input, Modal, Row, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { create } from 'zustand'
import { appPath } from '../api/dataset'
import DataExplorer from '../components/goals/DataExplorer'
import { AgentBadge } from '../components/goals/parts'
import '../components/goals/ChatPane.css'
import { DRILL, download } from '../data/drill'
import type { Agent, Drill, Goal } from '../data/goalCases'
import { EXAMPLE_BRIEFS, OUTPUT_FORMATS, designOutline, formatInfo, roleOf } from '../data/outputDesigner'
import { downloadPptx } from '../data/pptxExport'
import { nodeToPng, printNode } from '../data/rasterize'
import { describeRead, fileSize, readUpload } from '../data/readFile'
import { FORMAT_WORDS, bestMatch, interpretSub, templateFromRead } from '../data/subChat'
import type { OutputFormat, Template } from '../data/submissionTemplates'
import { LINEAGE, visualForFormat } from '../data/visuals'
import { useAuthStore } from '../store/authStore'
import { useGoalStore } from '../store/goalStore'
import { suggestFill, useSubmissionStore, type Section, type Submission } from '../store/submissionStore'
import { useJourney, type Journey } from '../store/journeyStore'
import DelivPicker from '../components/goals/DelivPicker'
import type { DelivSpec } from '../data/deliverFlow'
import { SP, STATUS } from '../theme'
import { P, now as clockNow } from '../data/pace'
import { FORMAT_ICON, FORMAT_LABEL, TemplateCard, TemplateLibrary, VisualBlock, buildDraft } from './SubmissionsPage'
import './SubmissionDoc.css'
import { DashEmbed } from '../components/goals/RiskBoard'
import { DESIGN, PANELS } from '../data/risk'
import { useDesign } from '../store/designStore'
import './SubmissionsHub.css'
import './HubPolish.css'
import HubFrame, { AgentMark, Dock, JourneyBar, RailItem, RichText, RailSearch, RailSection, RailToggle, scrollToMsg, useDock, useRailMatch, useSlashToSearch, useStickToBottom, type JStep } from './HubFrame'

const { Text, Paragraph } = Typography

/*
 * Submissions, 4 November 2026: a goal run already builds the deliverables agreed at its start. Here you
 * pick an analysis that has run (one-off or a standing goal's run) and make more deliverables from it:
 * tick the ones it recommends, or describe one, choose the template for each, and they are built at once.
 * The deliverable opens on the right, where you select any text and ask for a change.
 *
 * Earlier header: Submissions, the way you work with an assistant. The conversation is always in the middle. The agent
 * walks every submission through the same steps, each shown as a small screen inside the conversation:
 * which analysis it draws on, who it is for, what structure it follows, the outline. When you say
 * "build it", the output opens in the panel on the right, where you can select any text and ask for a
 * change. Arriving from the menu, the panel lists every submission and the template library.
 */

type Step = 'goal' | 'reader' | 'structure' | 'outline'
type CardKind = 'start' | Step | 'output' | 'make'
interface HubMsg { id: string; at: string; who: 'agent' | 'me' | 'event'; text?: string; card?: { kind: CardKind; subId?: string }; agent?: Agent; file?: { name: string; size: number } }

const NEUTRAL: Agent = { name: 'Your agents', icon: 'bulb', colour: '#4b5a75' }
const STEPS: { key: Step; label: string; stage: Submission['stage'] }[] = [
  { key: 'goal', label: 'What it draws on', stage: 'brief' },
  { key: 'reader', label: 'Who it is for', stage: 'brief' },
  { key: 'structure', label: 'Structure', stage: 'template' },
  { key: 'outline', label: 'Outline', stage: 'outline' },
]
const BLANK = 'Started blank, written by hand.'
let seq = 0
const mk = (m: Omit<HubMsg, 'id' | 'at'>): HubMsg => ({ id: `h${(seq += 1)}-${Date.now().toString(36)}`, at: clockNow().toISOString(), ...m })

/*
 * One chat per submission, like conversations with an assistant. A new chat has a key of its own until
 * something is started in it; from then on it is that submission's chat. Opening a submission from the
 * list brings its chat back, so you carry on where you stopped.
 */
interface HubState {
  /** The chat on screen. */
  msgs: HubMsg[]
  /** Its key: a submission id, or "new-…" for a chat where nothing has started yet. */
  chat: string
  /** Every other chat, by key. */
  threads: Record<string, HubMsg[]>
  typing: boolean
  activeId: string | null
  panel: 'list' | 'doc' | 'templates'
  steps: Record<string, Step>
  /** The chat you came back to, until you say something in it: it opens with a line saying where you are. */
  resumed: string | null
  /** The analysis (a goal run) the chat on screen makes deliverables from. */
  analysis: string | null
  /** Add to the chat on screen, or to another chat by its key (messages that arrive after you moved on). */
  push: (m: Omit<HubMsg, 'id' | 'at'>, key?: string) => void
  set: (p: Partial<Pick<HubState, 'typing' | 'activeId' | 'panel' | 'analysis'>>) => void
  setStep: (id: string, s: Step) => void
  /** Show another chat (empty if it has none yet). */
  switchTo: (key: string) => void
  /** Something was started in this chat: it becomes that submission's chat. From inside another submission's chat, the request moves to a chat of its own. */
  adopt: (subId: string, title: string) => void
}
const useHub = create<HubState>((set, get) => ({
  msgs: [],
  chat: 'new-0',
  threads: {},
  typing: false,
  activeId: null,
  panel: 'list',
  steps: {},
  resumed: null,
  analysis: null,
  push: (m, key) => {
    const { chat, msgs, threads } = get()
    const k = key ?? chat
    if (k === chat) set({ msgs: [...msgs, mk(m)], ...(m.who === 'me' ? { resumed: null } : {}) })
    else set({ threads: { ...threads, [k]: [...(threads[k] ?? []), mk(m)] } })
  },
  set: (p) => set(p),
  setStep: (id, s) => set({ steps: { ...get().steps, [id]: s } }),
  switchTo: (key) => {
    const { chat, msgs, threads } = get()
    if (key === chat) return
    const keep = chat.startsWith('new-') && !msgs.some((m) => m.who === 'me') ? Object.fromEntries(Object.entries(threads).filter(([k]) => k !== chat)) : { ...threads, [chat]: msgs }
    set({ threads: keep, chat: key, msgs: threads[key] ?? [], resumed: threads[key]?.length ? key : null })
  },
  adopt: (subId, title) => {
    const { chat, msgs, threads } = get()
    if (chat === subId) return
    if (chat.startsWith('new-')) { set({ resumed: null, chat: subId, msgs: [...(threads[subId] ?? []), ...msgs], threads: Object.fromEntries(Object.entries(threads).filter(([k]) => k !== subId)) }); return }
    let from = msgs.length
    for (let i = msgs.length - 1; i >= 0; i -= 1) if (msgs[i].who === 'me') { from = i; break }
    const carried = msgs.slice(from)
    const left = [...msgs.slice(0, from), mk({ who: 'event', text: `"${title}" continues in its own chat` })]
    set({ resumed: null, threads: { ...threads, [chat]: left }, chat: subId, msgs: [...(threads[subId] ?? []), ...carried] })
  },
}))

const drillFor = (g: Goal | null, x: Section): Drill | null => {
  if (!g || !g.findings.length) return null
  const f = bestMatch(`${x.heading} ${x.body.slice(0, 200)}`, g.findings, (y) => `${y.headline} ${y.detail}`) ?? g.findings[0]
  return f.drill
}


export default function SubmissionsHub({ routeId }: { routeId?: string }) {
  const navigate = useNavigate()
  const location = useLocation()
  const { message } = App.useApp()
  const me = useAuthStore((st) => st.identity?.name) ?? 'You'
  const allGoals = useGoalStore((st) => st.goals)
  const ready = allGoals.filter((g) => g.findings.length)
  const store = useSubmissionStore()
  const { submissions, templates } = store
  const { msgs, typing, activeId, panel, steps, chat, resumed } = useHub()
  const hub = useHub.getState
  const s = submissions.find((x) => x.id === activeId) ?? null
  const goalsOf = (x: Submission | null) => (x ? (x.goalIds.map((id) => allGoals.find((g) => g.id === id)).filter(Boolean) as Goal[]) : [])
  const goals = goalsOf(s)
  const g0 = goals[0] ?? null
  const agentOf = (x: Submission | null) => goalsOf(x)[0]?.agent ?? NEUTRAL
  const unitOf = (x: Submission | null) => (x ? formatInfo(x.format).unit : 'part')
  const UnitOf = (x: Submission | null) => { const u = unitOf(x); return u.charAt(0).toUpperCase() + u.slice(1) }
  const sub = (id: string) => useSubmissionStore.getState().submissions.find((x) => x.id === id)
  const inSetup = (x: Submission | null) => !!x && (x.stage === 'brief' || x.stage === 'template' || x.stage === 'outline')
  /* The analyses that have run: one-off goals delivered, standing goals' runs handled. Each already carries the deliverables agreed at its start. */
  const jstore = useJourney()
  const analyses = jstore.order.map((id) => jstore.goals[id]).filter((x): x is Journey => !!x && Object.keys(x.built).length > 0)
  const analysis = useHub((st) => st.analysis)
  const [makeSpecs, setMakeSpecs] = useState<Record<string, DelivSpec[]>>({})
  const [doneCards, setDoneCards] = useState<Record<string, string>>({})
  /** While Create is building: which deliverables, which one is on screen, and the agent's preparation lines for it. */
  const [bld, setBld] = useState<null | { sids: string[]; i: number; lines: string[] }>(null)
  const specsFor = (jid: string) => makeSpecs[jid] ?? jstore.offerFor(jid)
  const runLabel = (x: Journey) => (x.mode === 'watch' && x.runs.length ? x.runs[x.runs.length - 1].label : x.title)
  const kindLabel = (x: Journey) => (x.mode === 'watch' ? (x.case === 'schedule' ? 'Scheduled run' : 'Standing goal run') : 'One-off analysis')

  const [text, setText] = useState('')
  const [sel, setSel] = useState<string | null>(null)
  const [quote, setQuote] = useState<null | { id: string; text: string }>(null)
  const [pill, setPill] = useState<null | { id: string; text: string; x: number; y: number }>(null)
  const [editing, setEditing] = useState<string | null>(null)
  const [drill, setDrill] = useState<Drill | null>(null)
  const [sharing, setSharing] = useState(false)
  const [lineage, setLineage] = useState(false)
  const [shown, setShown] = useState(Number.MAX_SAFE_INTEGER)
  const [presenting, setPresenting] = useState<number | null>(null)
  const dashVers = useDesign((d) => d.versions)
  const [refreshedAt, setRefreshedAt] = useState(() => new Date())
  const [panelOpen, setPanelOpen] = useState(true)
  const [tplPickFor, setTplPickFor] = useState<string | null>(null)
  const [describeFor, setDescribeFor] = useState<Record<string, string>>({})
  const [startTpl, setStartTpl] = useState(false)
  void startTpl; void AgentBadge; void EXAMPLE_BRIEFS
  const endRef = useRef<HTMLDivElement>(null)
  /** An agent message right after another agent message continues the same turn: no second avatar. */
  const cont = (mm: { id: string }) => { const i = msgs.findIndex((y) => y.id === mm.id); return i > 0 && msgs[i - 1].who === 'agent' }
  const feedRef = useRef<HTMLDivElement>(null)
  useStickToBottom(feedRef)
  useSlashToSearch()
  const dock = useDock(feedRef, [msgs.length, chat, typing, s?.stage])
  const fileRef = useRef<HTMLInputElement>(null)
  const canvasRef = useRef<HTMLDivElement>(null)
  const fileFor = useRef<'start' | 'structure'>('start')

  /* A message about a submission goes to that submission's chat, even if you have moved to another one meanwhile. */
  const keyOf = (x: Submission | null) => (x && (hub().chat === x.id || hub().threads[x.id]) ? x.id : undefined)
  const say = (t: string, x: Submission | null = s) => hub().push({ who: 'agent', text: t, agent: agentOf(x) }, keyOf(x))
  const event = (t: string, x: Submission | null = null) => hub().push({ who: 'event', text: t }, keyOf(x))
  const card = (kind: CardKind, subId?: string, x: Submission | null = subId ? sub(subId) ?? null : null) => hub().push({ who: 'agent', card: { kind, subId }, agent: agentOf(x) }, keyOf(x))
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end', behavior: 'smooth' })
    /* Cards grow as they render; settle at the bottom once they have. */
    const t = window.setTimeout(() => endRef.current?.scrollIntoView({ block: 'end', behavior: 'smooth' }), 320)
    return () => window.clearTimeout(t)
  }, [msgs.length, typing])

  /* ---------------- the steps */
  const stepMsg = (k: Step, x: Submission): string => {
    const gs = goalsOf(x)
    const t = templates.find((y) => y.id === x.templateId)
    const inc = x.sections.filter((y) => y.included)
    const emp = inc.filter((y) => !y.body.trim())
    switch (k) {
      case 'goal': return gs.length ? `First, the analysis it is made from. I have picked **${gs.map((g) => g.title).join(' + ')}**. Is that right? Tick another goal to add it, or continue.` : 'First, which analysis is it made from?'
      case 'reader': return `Who reads it, and what should they decide? ${x.audience ? `I have **${x.audience.replace(/^The /, 'the ')}**.` : 'I do not know yet.'} Check the title and the format too.`
      case 'structure': return t ? `What should it follow? I suggest **${t.name}** (${t.sections.length} parts)${x.origin === 'recommendation' ? ', because it is in your library and fits this goal' : ''}. Keep it, or pick another, use your own file, describe it, or start blank.` : `What should it follow? ${x.brief?.description === BLANK ? `The usual parts of a ${FORMAT_LABEL[x.format].toLowerCase()}, all for you to write.` : `I read your description into ${inc.length} parts.`} Keep it, or pick a library template, use your own file, or start blank.`
      case 'outline': return `Here is the outline: ${inc.length} ${unitOf(x)}s. ${inc.length - emp.length} I fill from the goal${emp.length ? `, ${emp.length} you write` : ''}. Untick, rename, reorder or add, then say **build it**.`
    }
  }
  const goStep = (id: string, k: Step) => {
    const x = sub(id)
    if (!x) return
    const st = STEPS.find((y) => y.key === k)!.stage
    if (x.stage !== st) store.update(id, { stage: st })
    hub().setStep(id, k)
    hub().set({ activeId: id, panel: 'doc' })
    window.setTimeout(() => { const y = sub(id)!; say(stepMsg(k, y), y); card(k, id, y) }, 60)
  }
  const nextStep = (id: string) => {
    const k = hub().steps[id] ?? 'goal'
    const x = sub(id)!
    if (k === 'reader' && !x.audience) { say('Who reads it? Type it in the card or say "for …".', x); return }
    if (k === 'outline') { build(id); return }
    goStep(id, STEPS[STEPS.findIndex((y) => y.key === k) + 1].key)
  }
  const build = (id: string) => {
    const x = sub(id)!
    store.update(id, { stage: 'draft' }, me, 'Built the draft.')
    hub().set({ activeId: id, panel: 'doc' })
    setPanelOpen(true)
    setSel(null)
    setShown(0)
    const inc = x.sections.filter((y) => y.included)
    say(`Building the ${FORMAT_LABEL[x.format].toLowerCase()} on the right, ${unitOf(x)} by ${unitOf(x)}.`, x)
    inc.forEach((y, i) => window.setTimeout(() => {
      setShown(i + 1)
      event(`${formatInfo(x.format).unit} ${i + 1} · ${y.body.trim() ? `filled from ${y.from}` : 'empty, for you to write'}`, x)
      if (i === inc.length - 1) window.setTimeout(() => { setShown(Number.MAX_SAFE_INTEGER); const z = sub(id)!; say(draftSummary(z), z); card('output', id, z) }, 450)
    }, 350 + i * 420))
  }
  const draftSummary = (x: Submission) => {
    const inc = x.sections.filter((y) => y.included)
    const emp = x.sections.map((y, i) => ({ y, i })).filter(({ y }) => y.included && !y.body.trim())
    if (isDash(x)) return 'It is on the right, the same live dashboard as in the goal. It uses the full width here; **Full screen** shows it with nothing else around it. Click a project to open it. To change the scoring, open the goal.'
    return `It is on the right: ${inc.length} ${unitOf(x)}s${emp.length ? `, ${emp.length} still empty (${emp.map(({ y, i }) => `${i + 1} ${y.heading}`).join('; ')})` : ''}. Click a ${unitOf(x)} or select any text to change it. ${emp.length ? 'Fill or write the empty ones, then mark it as reviewed.' : 'When it reads right, mark it as reviewed.'}`
  }

  /* ---------------- starting: every start creates a submission at its first step */
  /* Keep the address on the open submission, so the link can be shared and the menu always returns to the list. */
  const follow = (id: string) => {
    hub().adopt(id, sub(id)?.title ?? 'New submission')
    if (routeId !== id) navigate(appPath(`/submissions/${id}`))
  }
  const startWith = (id: string, intro: string) => {
    follow(id)
    store.update(id, { stage: 'brief' })
    const x = sub(id)!
    say(intro, x)
    goStep(id, 'goal')
  }
  const startDescribed = (words: string, g: Goal) => {
    const f = FORMAT_WORDS.find(([re]) => re.test(words))?.[1] ?? 'Document'
    const p = designOutline(f, words, g)
    const id = store.startDescribed(g, words, p, me)
    startWith(id, `A ${FORMAT_LABEL[f].toLowerCase()} from your description. Four short steps to set it up, then the draft and your review.`)
  }
  const startBlank = (f: OutputFormat, g: Goal) => {
    const p = designOutline(f, '', g)
    const id = store.startDescribed(g, BLANK, p, me)
    store.setSections(id, sub(id)!.sections.map((y) => ({ ...y, body: '', from: 'You' })))
    store.update(id, { template: `${FORMAT_LABEL[f]}, blank` })
    startWith(id, `A blank ${FORMAT_LABEL[f].toLowerCase()}. Same steps; the parts will be empty for you to write.`)
  }
  const startRec = (g: Goal, sugId: string) => {
    const x = g.submissions.find((y) => y.id === sugId)!
    const id = store.startFromGoal(g, x, me)
    startWith(id, `**${x.label}**, as ${g.agent.name} recommends. Let us check it step by step.`)
  }
  const startTemplate = (t: Template, g: Goal) => {
    const id = store.startFromTemplate(t, [g], me)
    startWith(id, `Starting from the template **${t.name}**. Four short steps to set it up, then the draft.`)
  }

  const greet = () => {
    say(analyses.length ? 'Which analysis should it come from? Every one below has run and already has its first deliverables; pick one and say what else you need.' : 'Nothing has run yet. A goal builds its deliverables when it runs, and they land here; then you can make more from it.', null)
    card('start')
  }
  /* An analysis picked: what else it can make, with what is already made marked. */
  const pickAnalysis = (jid: string) => {
    const x = useJourney.getState().goals[jid]; if (!x) return
    hub().set({ analysis: jid })
    const made = Object.keys(x.built).length
    hub().push({ who: 'agent', agent: x.agent, text: `From **${runLabel(x)}**, ${x.mode === 'watch' ? `handled ${x.executedAt ?? ''}` : `delivered ${x.executedAt ?? ''}`} on ${x.recs.find((r) => r.id === x.chosen) ? `option ${x.recs.findIndex((r) => r.id === x.chosen) + 1}` : 'its findings'}. ${made} ${made === 1 ? 'deliverable is' : 'deliverables are'} already made from it. What else do you need? Tick what I suggest or add one in your words, choose the template for each, and I build them now.` })
    hub().push({ who: 'agent', agent: x.agent, card: { kind: 'make', subId: jid } })
  }
  /* Build them at once: no outline to approve. The first opens on the right as it is built. */
  /*
   * Create: the agent works in the open, the same way a goal run builds its deliverables. For each deliverable it first
   * reads the analysis, matches the template and pulls the figures (a line each on the right), then writes it part by
   * part; the next one follows. About fifteen seconds for a six-part deliverable.
   */
  const createFrom = (jid: string, specs: DelivSpec[]) => {
    const x = useJourney.getState().goals[jid]; if (!x) return
    const sids = useJourney.getState().makeMore(jid, specs)
    if (!sids.length) { hub().push({ who: 'agent', agent: x.agent, text: 'Nothing new is ticked. Tick one, or describe what you need.' }); return }
    const list = sids.map((id) => sub(id)!).filter(Boolean)
    const first = list[0]
    follow(first.id)
    hub().set({ activeId: first.id, panel: 'doc', typing: true })
    setPanelOpen(true); setSel(null); setShown(0)
    setBld({ sids, i: 0, lines: [] })
    say(`Building ${list.length === 1 ? `the ${FORMAT_LABEL[first.format].toLowerCase()}` : `${list.length} deliverables`} from **${runLabel(x)}**, on ${first.basis ?? 'its findings'}. It comes together on the right.`, first)
    const rec = x.recs.find((r) => r.id === x.chosen)
    const steps: { d: number; fn: () => void }[] = []
    list.forEach((y, i) => {
      const inc = y.sections.filter((z) => z.included)
      const unit = formatInfo(y.format).unit
      const tpl = templates.find((t) => t.id === y.templateId)
      const prep = i === 0
        ? [`Reading the analysis: ${x.findings.length} findings, option ${x.recs.findIndex((r) => r.id === x.chosen) + 1} chosen${rec ? `: ${rec.title.split(/[;:,]\s/)[0]}` : ''}`, `Matching the template: ${(tpl?.name ?? y.template).replace(/\.(xlsx|pptx|docx)$/i, '')}, ${inc.length} ${unit}s`, `Pulling the figures and the evidence behind each ${unit}`]
        : [`Matching the template: ${(tpl?.name ?? y.template).replace(/\.(xlsx|pptx|docx)$/i, '')}, ${inc.length} ${unit}s`, `Pulling the figures behind each ${unit}`]
      steps.push({ d: i === 0 ? 300 : 900, fn: () => { hub().set({ activeId: y.id, panel: 'doc' }); setShown(0); setBld({ sids, i, lines: [] }) } })
      prep.forEach((l) => steps.push({ d: 1900, fn: () => setBld((b) => (b ? { ...b, lines: [...b.lines, l] } : b)) }))
      inc.forEach((z, k) => steps.push({ d: k === 0 ? 1700 : 1500, fn: () => { setShown(k + 1); event(`${y.title.split(':')[0]} · ${unit} ${k + 1} of ${inc.length} · ${z.heading}`, y) } }))
      steps.push({ d: 700, fn: () => event(`Built · ${y.title.split(':')[0]} · ${inc.length} ${unit}s`, y) })
    })
    let k = 0
    const next = () => {
      if (k >= steps.length) {
        setBld(null); setShown(Number.MAX_SAFE_INTEGER); hub().set({ typing: false, activeId: first.id })
        const all = sids.map((id) => sub(id)!).filter(Boolean)
        say(`Built: ${all.map((y) => `**${y.title}**`).join(', ')}. ${all.length > 1 ? 'The first is on the right; open the others below.' : 'It is on the right.'} Select any text and tell me what to change, or download it. They also show in the goal, under Deliverables.`, first)
        all.forEach((y) => card('output', y.id, y))
        return
      }
      const st = steps[k]; k += 1
      window.setTimeout(() => { st.fn(); next() }, P(st.d))
    }
    next()
  }
  /* A fresh chat; whatever you were setting up stays in Drafts, to pick up from the list. */
  const newChat = (withGreeting = true) => {
    hub().switchTo(`new-${Date.now().toString(36)}`)
    hub().set({ activeId: null, panel: 'list', analysis: null })
    setSel(null); setQuote(null); setTplPickFor(null); setStartTpl(false); setText('')
    setPanelOpen(true)
    if (withGreeting) greet()
    if (routeId) navigate(appPath('/submissions'))
  }

  /* Arriving: from the menu, from a goal, or on a submission's own link. */
  const arrived = useRef<string>('')
  useEffect(() => {
    const st = (location.state as { newFromGoal?: string; describe?: boolean } | null) ?? null
    const key = `${location.key}|${routeId ?? ''}`
    if (arrived.current === key) return
    arrived.current = key
    const fromGoal = st?.newFromGoal ? allGoals.find((g) => g.id === st.newFromGoal) : undefined
    if (routeId && routeId !== 'new') {
      const x = sub(routeId)
      if (!x) return
      /* Its own chat: back where you stopped, or a first chat that starts its set-up. (Arriving on one just started here changes nothing.) */
      const already = hub().chat === x.id && hub().activeId === x.id
      hub().switchTo(x.id)
      hub().set({ activeId: x.id, panel: 'doc' })
      setPanelOpen(true)
      setSel(null); setQuote(null)
      if (!hub().msgs.length) {
        if (inSetup(x)) startWith(x.id, `**${x.title}**${x.agentName ? `, from ${x.agentName}` : ''}. Four short steps to set it up, then the draft and your review.`)
        else { say(`Opened **${x.title}**. ${draftSummary(x)}`, x); card('output', x.id, x) }
      } else if (!already && inSetup(x) && hub().steps[x.id] && latestCardIn(hub().msgs, x.id) !== hub().steps[x.id]) goStep(x.id, hub().steps[x.id])
      return
    }
    const fromJourney = (location.state as { fromJourney?: string } | null)?.fromJourney
    if (fromJourney && useJourney.getState().goals[fromJourney]) {
      newChat(false)
      hub().push({ who: 'me', text: `More from ${runLabel(useJourney.getState().goals[fromJourney])}` })
      pickAnalysis(fromJourney)
      return
    }
    if (fromGoal) {
      newChat(false)
      hub().push({ who: 'agent', agent: fromGoal.agent, text: st?.describe ? `A new output for **${fromGoal.title}**. Tell me what it is and who reads it, in your own words, or pick an example below.` : `What should go out from **${fromGoal.title}**? Pick one of ${fromGoal.agent.name}'s recommendations, or describe something new.` })
      hub().push({ who: 'agent', card: { kind: 'start', subId: fromGoal.id }, agent: fromGoal.agent })
      return
    }
    /* From the menu: the chat you were in stays in the middle, with what it is about on the right. */
    hub().set({ panel: 'doc' })
    setPanelOpen(true)
    if (!hub().msgs.length) greet()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.key, routeId])

  /* ---------------- the conversation */
  const after = (msg: string, x: Submission | null = s) => say(msg, x)
  const touched = (id: string) => { const x = sub(id); if (x?.stage === 'reviewed') { store.update(id, { stage: 'draft', reviewedBy: undefined }, me, 'Changed after review; reopened.'); after('That changed it after review, so it is open again.', x) } }
  const setSec = (id: string, secId: string, p: Partial<Section>, quiet = false) => { const x = sub(id)!; store.setSections(id, x.sections.map((y) => (y.id === secId ? { ...y, ...p } : y))); if (!quiet) touched(id) }
  const toggleGoal = (id: string, g: Goal) => {
    const x = sub(id)!
    const ids = x.goalIds.includes(g.id) ? x.goalIds.filter((i) => i !== g.id) : [...x.goalIds, g.id]
    if (!ids.length) { after('It has to draw on at least one goal.', x); return }
    const gs = ids.map((i) => allGoals.find((y) => y.id === i)).filter(Boolean) as Goal[]
    store.update(id, { goalIds: ids, fromGoal: { id: gs[0].id, title: gs[0].title } }, me, `Draws on ${gs.map((y) => y.title).join('; ')}.`)
    const t = templates.find((y) => y.id === x.templateId)
    if (t) store.applyTemplate(id, t, gs, me)
    else store.setSections(id, x.sections.map((y) => { const f = suggestFill(gs, y.role, y.heading); return y.from === 'You' && y.body.trim() ? y : { ...y, body: x.brief?.description === BLANK ? '' : f.body, from: f.body && x.brief?.description !== BLANK ? f.from : 'You' } }))
  }
  const structureFrom = (id: string, words: string, blank = false) => {
    const x = sub(id)!
    const gs = goalsOf(x)
    const p = designOutline(x.format, words, gs[0])
    const sections: Section[] = p.sections.map((y, i) => { const f = blank ? { body: '', from: 'You' } : suggestFill(gs, y.role, `${y.heading} ${y.hint ?? ''}`); return { id: `d-${i}-${Date.now().toString(36)}`, heading: y.heading, role: y.role, included: true, body: f.body, from: f.body ? f.from : y.hint ? `You · ${y.hint}` : 'You' } })
    store.update(id, { templateId: undefined, template: `${FORMAT_LABEL[x.format]}, ${blank ? 'blank' : 'defined from your description'}`, origin: 'described', brief: { format: x.format, description: blank ? BLANK : words, reading: p.reading }, sections }, me, blank ? 'Structure: blank.' : 'Structure read from a description.')
    return p
  }

  const downloadsOf = (x: Submission) => {
    const inc = x.sections.filter((y) => y.included)
    const dl = {
      html: { key: 'html', icon: <FileTextOutlined />, label: 'HTML page', run: () => download(`${x.id}_DRAFT.html`, buildDraft(x), 'text/html') },
      pdf: { key: 'pdf', icon: <FilePdfOutlined />, label: 'PDF', run: () => { if (canvasRef.current) printNode(canvasRef.current) } },
      png: { key: 'png', icon: <FileImageOutlined />, label: 'Image (PNG)', run: async () => { if (!canvasRef.current) return; try { await nodeToPng(canvasRef.current, `${x.id}.png`); message.success('Image saved.') } catch { message.error('Could not render the image; use PDF.') } } },
      pptx: { key: 'pptx', icon: <FilePptOutlined />, label: 'PowerPoint (.pptx)', run: async () => { const h = message.loading('Building the PowerPoint…', 0); try { await downloadPptx(x, goalsOf(x)[0] ?? null, inc); message.success('PowerPoint saved.') } catch { message.error('Could not build the PowerPoint.') } finally { h() } } },
      csv: { key: 'csv', icon: <FileExcelOutlined />, label: 'CSV', run: () => download(`${x.id}.csv`, ['sheet,row,text', ...inc.flatMap((y) => (y.body || '').split('\n').filter(Boolean).map((row, i) => `"${y.heading.replace(/"/g, '""')}",${i + 1},"${row.replace(/"/g, '""')}"`))].join('\n'), 'text/csv') },
    }
    return x.format === 'Slide pack' ? [dl.pptx] : x.format === 'Dashboard' ? [dl.pdf, dl.png] : x.format === 'Workbook' ? [dl.csv] : x.format === 'Email' ? [dl.html] : [dl.pdf, dl.html]
  }

  const act = (raw: string) => {
    const t = raw.trim().toLowerCase()
    const x = activeId ? sub(activeId) ?? null : null
    let m: RegExpMatchArray | null
    const wantsNew = /^(new|another|start (a )?new|i need|i want|we need|make me|can you (make|draft|prepare)|draft (me )?a|prepare a)\b/.test(t) || (!x && t.length > 14)

    if (/^(new (chat|submission)|start (a )?new( one| chat)?|another one)$/.test(t)) { newChat(); return }
    if (/^make another from the same analysis$|^more from (this|the same) analysis$/.test(t) && x?.journeyId && useJourney.getState().goals[x.journeyId]) { const jid = x.journeyId; newChat(false); hub().push({ who: 'me', text: raw.trim() }); pickAnalysis(jid); return }
    /* A new submission. */
    if (!x || wantsNew) {
      void startBlank; void startRec; void startDescribed
      if (!analyses.length) { after('Nothing has run yet. Run a goal first; its deliverables land here and you can make more from it.', null); return }
      const jid = hub().analysis ?? bestMatch(t, analyses, (a) => `${a.title} ${runLabel(a)}`)?.id ?? analyses[0].id
      const ja = useJourney.getState().goals[jid]
      if ((m = t.match(/^(?:from|use|pick)\s+(?:analysis\s+)?(\d)$/))) { const a = analyses[Number(m[1]) - 1]; if (a) { pickAnalysis(a.id); return } }
      if (t.length < 12) { after(hub().analysis ? 'Tell me a little more: what it is and who reads it. Or tick one above.' : 'Pick the analysis above first, or say what you need and which analysis it comes from.', null); return }
      const f = FORMAT_WORDS.find(([re]) => re.test(t))?.[1] ?? 'Document'
      const aud = raw.match(/\bfor (the )?([A-Z][\w,.'-]*(?:\s+(?!on\b|about\b|with\b|of\b|to\b)[\w,.'-]+){0,6})/)?.[2]?.trim()
      const label = raw.trim().replace(/^(new|another|i need|i want|we need|make me|can you (make|draft|prepare)|draft (me )?|prepare)\s+(a|an)?\s*/i, '').replace(/^./, (c) => c.toUpperCase()).replace(/\.$/, '')
      const had = hub().analysis
      hub().set({ analysis: jid })
      if (had !== jid) hub().push({ who: 'agent', agent: ja.agent, text: `From **${runLabel(ja)}**.` })
      createFrom(jid, [{ id: `custom-${Date.now().toString(36)}`, label: label.length > 90 ? `${label.slice(0, label.lastIndexOf(' ', 88)).replace(/[\s,;:]+$/, '')}…` : label, audience: aud ?? 'As you described', purpose: raw.trim(), format: f, on: true, mode: 'ai', describe: raw.trim(), custom: true }])
      return
    }

    /* Set-up steps. */
    if (inSetup(x)) {
      const k = hub().steps[x.id] ?? 'goal'
      if ((m = t.match(/\bgoal\s+(\d)\b/))) { const g = ready[Number(m[1]) - 1]; if (g) { toggleGoal(x.id, g); after(`It now draws on ${goalsOf(sub(x.id)!).map((y) => `"${y.title}"`).join(' and ')}.`, x) } return }
      if ((m = raw.match(/^describe(?: it)?\s*[:-]?\s+(.{10,})$/i))) { const p = structureFrom(x.id, m[1]); after(`Read it as ${p.sections.length} parts. Say "next" to see the outline.`, x); return }
      if (/\b(start blank|blank|from scratch|write it myself)\b/.test(t)) { const p = structureFrom(x.id, '', true); after(`Blank, with the usual ${p.sections.length} parts. Say "next".`, x); return }
      if (/\b(build( it| the draft)?|create( it)?|make the draft)\b/.test(t)) { build(x.id); return }
      if (/^(next|continue|go on|looks good|ok|okay|yes|that'?s (right|fine)|keep it|confirm|right)$/.test(t) || /\b(next|continue)\b/.test(t)) { nextStep(x.id); return }
      if (/^(back|previous|go back)$/.test(t)) { const i = STEPS.findIndex((y) => y.key === k); if (i > 0) goStep(x.id, STEPS[i - 1].key); return }
      if ((m = t.match(/\b(?:back to|go to|change)\s+(?:the\s+)?(goal|analysis|reader|audience|brief|structure|template|outline)\b/)) && !/template\s*\d/.test(t) && !/^change (the )?template$/.test(t)) { goStep(x.id, /goal|analysis/.test(m[1]) ? 'goal' : /reader|audience|brief/.test(m[1]) ? 'reader' : /structure|template/.test(m[1]) ? 'structure' : 'outline'); return }
      if (/\b(change|another|different|pick a|library) template\b/.test(t)) { if (k !== 'structure') goStep(x.id, 'structure'); setTplPickFor(x.id); after('The library is open in the structure card. Pick one, or say "use template" and its number.', x); return }
    }

    /* Text selected in the output. */
    if (quote && x) {
      const part = x.sections.find((y) => y.id === quote.id)
      const n = part ? x.sections.indexOf(part) + 1 : 0
      const swap = (repl: string) => {
        if (!part) return false
        /* Match the selection whatever its line breaks or display case (headings show in capitals). */
        const words = quote.text.replace(/\s+/g, ' ').trim().split(' ').map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
        const re = new RegExp(words.join('\\s+'), 'i')
        const inHead = re.test(part.heading)
        const src = inHead ? part.heading : part.body
        if (!re.test(src)) return false
        const next = src.replace(re, repl)
        setSec(x.id, part.id, inHead ? { heading: next.trim() } : { body: next.replace(/\n{3,}/g, '\n\n').trim(), from: part.from.startsWith('You') ? 'You' : `${part.from.replace(/, edited by .*$/, '')}, edited by ${me}` })
        return true
      }
      const done = (msgText: string) => { setQuote(null); after(msgText, x) }
      if ((m = raw.match(/^(?:replace(?: it| this)?(?: with)?|change(?: it| this)? to|say|write|make it say|should be|instead)\s*[:-]?\s+["“]?(.+?)["”]?$/i))) { done(swap(m[1].trim()) ? `Changed in ${unitOf(x)} ${n}.` : 'I could not find that text (it may be in a chart). Edit the part instead.'); return }
      if (/^(remove|delete|drop|cut)( it| this| that)?$/.test(t)) { done(swap('') ? `Removed it from ${unitOf(x)} ${n}.` : 'I could not find that text.'); return }
      if (/\b(short(er|en)|tighten|trim|concise)\b/.test(t)) { const first = (quote.text.match(/[^.!?]+[.!?]+/g) ?? [quote.text])[0].trim(); const w = first.split(/\s+/); done(swap(w.length > 18 ? `${w.slice(0, 16).join(' ')}…` : first) ? `Shortened it in ${unitOf(x)} ${n}.` : 'I could not find that text.'); return }
      if (/\b(where|source|data|evidence)\b/.test(t) && part) { const d = drillFor(goalsOf(x)[0] ?? null, part); if (d) setDrill(d); done(d ? 'The data behind that is open.' : 'No data behind that.'); return }
      after('With text selected I can: "replace with …", "make it shorter", "remove it", or "where is this from?".', x)
      return
    }

    /* A part picked in the output. */
    const cur = x.sections.find((y) => y.id === sel)
    if (cur) {
      const n = x.sections.indexOf(cur) + 1
      if (/\b(short(er|en)|tighten|trim|concise|one line)\b/.test(t)) { const ss = cur.body.replace(/\n+/g, ' ').match(/[^.!?]+[.!?]+/g) ?? [cur.body]; setSec(x.id, cur.id, { body: ss.slice(0, 2).join(' ').trim() }); after(`Shortened ${unitOf(x)} ${n}. Say "fill it" for the full text again.`, x); return }
      if (/\b(fill( it)?|draft it|from the goal)\b/.test(t)) { const f = suggestFill(goalsOf(x), cur.role, cur.heading); if (f.body) { setSec(x.id, cur.id, { body: f.body, from: f.from }); after(`Filled ${unitOf(x)} ${n} from the goal.`, x) } else after(`Nothing in the goal covers "${cur.heading}". Write it ("write: …").`, x); return }
      if ((m = raw.match(/^(?:write|text|replace (?:it )?with)\s*[:-]?\s+(.{3,})$/i))) { setSec(x.id, cur.id, { body: m[1].trim(), from: 'You' }); after(`Written into ${unitOf(x)} ${n}.`, x); return }
      if ((m = raw.match(/^(?:rename(?: it)?|call it|retitle)\s*(?:to|:)?\s+(.{3,})$/i))) { setSec(x.id, cur.id, { heading: m[1].trim() }); after(`${UnitOf(x)} ${n} is now "${m[1].trim()}".`, x); return }
      if (/^(remove( it)?|leave (it )?out|drop( it)?|delete( it)?)$/.test(t)) { setSec(x.id, cur.id, { included: false }); setSel(null); after(`Left out ${unitOf(x)} ${n}.`, x); return }
      if (/\b(data|source|evidence)\b/.test(t)) { const d = drillFor(goalsOf(x)[0] ?? null, cur); if (d) setDrill(d); after(d ? 'The data is open.' : 'No data behind it.', x); return }
    }

    /* Anything else about the open submission. */
    const it = interpretSub(raw, x.stage)
    const secAt = (k: number) => x.sections[k - 1]
    const downloads = downloadsOf(x)
    const emp = x.sections.filter((y) => y.included && !y.body.trim())
    switch (it.k) {
      case 'title': store.update(x.id, { title: it.v }, me, 'Retitled.'); after(`Title: "${it.v}".`, x); return
      case 'audience': store.update(x.id, { audience: it.v }, me, `For ${it.v}.`); after(`For ${it.v}.${inSetup(x) ? ' Say "next".' : ''}`, x); return
      case 'purpose': store.update(x.id, { purpose: it.v }, me, 'Purpose.'); after('Noted.', x); return
      case 'useTemplate': { const tt = it.n ? templates[it.n - 1] : bestMatch(it.words ?? '', templates, (z) => `${z.name} ${z.family}`); if (!tt) { after('Which one? Say "use template" and its number.', x); return } store.applyTemplate(x.id, tt, goalsOf(x), me); setTplPickFor(null); touched(x.id); after(`Now on **${tt.name}**: ${tt.sections.length} parts, filled from the goal where they match.${inSetup(x) ? ' Say "next".' : ''}`, x); return }
      case 'saveTemplate': { if (x.templateId) { after('It already follows a library template.', x); return } const name = it.name ?? `${FORMAT_LABEL[x.format]}: ${x.title.replace(/:.*$/, '')}`; store.saveOutlineAsTemplate(x.id, name, me); after(`Saved to your library as "${name}".`, x); return }
      case 'remove': { const y = secAt(it.n); if (!y) return; setSec(x.id, y.id, { included: false }); after(`Left out ${it.n}: "${y.heading}".`, x); return }
      case 'restore': { const y = secAt(it.n); if (!y) return; setSec(x.id, y.id, { included: true }); after(`${it.n} is back in.`, x); return }
      case 'add': store.setSections(x.id, [...x.sections, { id: `u${Date.now().toString(36)}`, heading: it.heading, body: '', from: 'You', role: roleOf(it.heading), included: true }]); touched(x.id); after(`Added ${unitOf(x)} ${x.sections.length + 1}: "${it.heading}".`, x); return
      case 'rename': { const y = secAt(it.n); if (!y) return; setSec(x.id, y.id, { heading: it.v }); after(`${UnitOf(x)} ${it.n} is now "${it.v}".`, x); return }
      case 'write': { const y = secAt(it.n); if (!y) return; setSec(x.id, y.id, { body: it.v, from: 'You' }); after(`Written into ${it.n}.`, x); return }
      case 'show': { const y = secAt(it.n); if (y) { setSel(y.id); document.getElementById(`hp-${y.id}`)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }) } after(`${UnitOf(x)} ${it.n} is selected. Tell me what to change.`, x); return }
      case 'review': if (inSetup(x)) { after('Build it first.', x); return } if (emp.length) { after(`Fill, write or leave out the empty ones first: ${emp.map((y) => y.heading).join('; ')}.`, x); return } store.update(x.id, { stage: 'reviewed', reviewedBy: me }, me, 'Marked as reviewed.'); after(`Marked as reviewed. Download it (${downloads.map((d) => d.label).join(' or ')}) or share the link.`, x); return
      case 'download': { if (inSetup(x)) { after('Build it first.', x); return } const pick = it.as ? downloads.find((d) => d.label.toLowerCase().includes(it.as === 'powerpoint' ? 'pptx' : it.as === 'image' ? 'png' : it.as!)) : undefined; const d = pick ?? downloads[0]; after(`Downloading the ${d.label}.`, x); void d.run(); return }
      case 'share': setSharing(true); after('The link is open; copy it from there.', x); return
      case 'lineage': setLineage(true); after('Data lineage is open.', x); return
      case 'refresh': setRefreshedAt(new Date()); after('Refreshed.', x); return
      case 'goal': if (goalsOf(x)[0]) navigate(appPath(`/goals/${goalsOf(x)[0].id}`)); return
      case 'next': if (inSetup(x)) nextStep(x.id); else after(emp.length ? 'Fill or write the empty parts, then mark it as reviewed.' : 'Say "mark as reviewed" when it reads right.', x); return
      default: after(inSetup(x) ? stepMsg(hub().steps[x.id] ?? 'goal', x) : `Click a ${unitOf(x)} or select text on the right and tell me what to change; or say "mark as reviewed", "download", "share". To start something new, say "new …".`, x)
    }
  }
  const send = (t0: string) => {
    const v = t0.trim()
    if (!v) return
    hub().push({ who: 'me', text: v })
    setText('')
    hub().set({ typing: true })
    window.setTimeout(() => { hub().set({ typing: false }); act(v) }, 380 + Math.random() * 280)
  }
  const upload = async (file: File) => {
    hub().push({ who: 'me', text: 'Here is a template.', file: { name: file.name, size: file.size } })
    hub().set({ typing: true })
    const r = await readUpload(file)
    const t = templateFromRead(r)
    store.addTemplate(t, me)
    window.setTimeout(() => {
      hub().set({ typing: false })
      const x = activeId ? sub(activeId) : undefined
      if (x && inSetup(x)) { store.applyTemplate(x.id, t, goalsOf(x), me); after(`Read ${r.name}: ${describeRead(r)}. In your library now, and this submission follows it: ${t.sections.length} parts.`, x); goStep(x.id, 'structure'); return }
      const g = ready[0]
      if (!g) return
      after(`Read ${r.name}: ${describeRead(r)}. It is in your library as "${t.name}".`, null)
      startTemplate(t, g)
    }, 800)
  }

  /* ---------------- the step cards */
  const latestCard = (kind: CardKind, subId?: string) => { for (let i = msgs.length - 1; i >= 0; i -= 1) { const c = msgs[i].card; if (c && c.subId === subId && c.kind !== 'start') return c.kind === kind ? msgs[i].id : null } return null }
  const latestCardIn = (list: HubMsg[], subId: string) => { for (let i = list.length - 1; i >= 0; i -= 1) { const c = list[i].card; if (c && c.subId === subId && c.kind !== 'start') return c.kind } return null }
  const StepHead = ({ k, x, live }: { k: Step; x: Submission; live: boolean }) => {
    const i = STEPS.findIndex((y) => y.key === k)
    return (
      <div className="hc-head">
        <span className={`sd-step-n${live ? '' : ' is-done'}`}>{live ? i + 1 : <CheckOutlined />}</span>
        <b>{STEPS[i].label}</b>
        {live ? <span className="hc-of">Step {i + 1} of 6</span> : null}
        {!live && inSetup(x) ? <a onClick={() => { goStep(x.id, activeId === x.id ? k : steps[x.id] ?? k); if (routeId !== x.id) navigate(appPath(`/submissions/${x.id}`)) }}>{activeId === x.id ? 'change' : 'pick up here'}</a> : null}
      </div>
    )
  }
  const renderCard = (m: HubMsg) => {
    const c = m.card!
    if (c.kind === 'start') {
      if (!analyses.length) return <div className="hc" data-card="start"><Text type="secondary" style={{ display: 'block', fontSize: 13, marginBottom: 8 }}>Run a goal in Goals: when it ends, its deliverables are here, and this is where you make more from it.</Text><Button size="small" type="primary" onClick={() => navigate(appPath('/goals'))}>Go to Goals</Button></div>
      const later = msgs.slice(msgs.findIndex((y) => y.id === m.id) + 1).some((y) => y.card?.kind === 'make')
      const pickedA = later && analysis ? analyses.find((a) => a.id === analysis) : undefined
      if (pickedA) return <div className="hc hc-folded"><span className="sd-step-n is-done"><CheckOutlined /></span><b>Analysis</b><span className="hc-sum">{runLabel(pickedA)}</span></div>
      return (
        <div className="hc" data-card="start">
          <div className="hc-label">Analyses that have run</div>
          <Flex vertical gap={6}>{analyses.map((a, i) => {
            const made = Object.keys(a.built).length
            return (
              <div key={a.id} className={`sd-pick${analysis === a.id ? ' is-on' : ''}`} style={{ ['--agent' as string]: a.agent.colour }} data-analysis={a.id} data-n={i + 1} onClick={() => { hub().push({ who: 'me', text: `From ${runLabel(a)}` }); pickAnalysis(a.id) }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <Flex justify="space-between" gap={8}><Text style={{ fontWeight: 500 }}>{runLabel(a)}</Text><Text style={{ fontSize: 12, color: a.agent.colour, whiteSpace: 'nowrap' }}>{a.agent.name}</Text></Flex>
                  <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>{kindLabel(a)} · {a.mode === 'watch' ? 'handled' : 'delivered'} {a.executedAt ?? ''} · option {a.recs.findIndex((r) => r.id === a.chosen) + 1} · {made} deliverable{made === 1 ? '' : 's'} made</Text>
                </div>
              </div>
            )
          })}</Flex>
          <span className="hc-note" style={{ display: 'block', marginTop: 8 }}>Or say what you need, e.g. "a one-page note for the insurer on the Harlow Creek claim".</span>
        </div>
      )
    }
    if (c.kind === 'make') {
      const jx = c.subId ? jstore.goals[c.subId] : undefined
      if (!jx) return null
      if (doneCards[m.id]) return <div className="hc hc-folded"><span className="sd-step-n is-done"><CheckOutlined /></span><b>Made</b><span className="hc-sum">{doneCards[m.id]}</span></div>
      return (
        <div className="hc" data-card="make">
          <div className="hc-head"><span className="sd-step-n">·</span><b>What else from it</b><span className="hc-of">{Object.keys(jx.built).length} already made</span></div>
          <DelivPicker specs={specsFor(jx.id)} onSpecs={(sp) => setMakeSpecs((d) => ({ ...d, [jx.id]: sp }))} made={jx.built} confirmLabel="Create" audience={jx.case === 'once' ? 'Renee Halvorsen' : 'Marisol Vega'}
            onConfirm={() => { const sp = specsFor(jx.id).filter((d) => d.on && !jx.built[d.id]); setDoneCards((d) => ({ ...d, [m.id]: sp.map((y) => y.label.split(':')[0]).join(' · ') })); setMakeSpecs((d) => ({ ...d, [jx.id]: undefined as unknown as DelivSpec[] })); hub().push({ who: 'me', text: `Create: ${sp.map((y) => y.label.split(':')[0]).join(' and ')}` }); createFrom(jx.id, sp) }} />
        </div>
      )
    }
    const x = c.subId ? sub(c.subId) : undefined
    if (!x) return null
    const live = latestCard(c.kind, x.id) === m.id && (c.kind === 'output' || (activeId === x.id && inSetup(x) && (steps[x.id] ?? 'goal') === c.kind))
    const inc = x.sections.filter((y) => y.included)
    const tpl = templates.find((y) => y.id === x.templateId)
    if (c.kind === 'output') {
      const emp = inc.filter((y) => !y.body.trim())
      return (
        <div className={`hc hc-out${activeId === x.id && panel === 'doc' ? ' is-open' : ''}`} onClick={() => { hub().set({ activeId: x.id, panel: 'doc' }); setPanelOpen(true); if (routeId !== x.id) navigate(appPath(`/submissions/${x.id}`)) }}>
          <span className="hc-out-icon">{FORMAT_ICON[x.format]}</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <Text style={{ display: 'block', fontWeight: 500 }}>{x.title}</Text>
            <Text type="secondary" style={{ fontSize: 12 }}>{isDash(x) ? `Dashboard · live · ${PANELS.filter((q) => DESIGN.panels[q.k]).length} views · ${x.stage === 'reviewed' ? 'reviewed' : 'draft'}` : <>{FORMAT_LABEL[x.format]} · {inc.length} {unitOf(x)}s · {emp.length ? `${emp.length} empty` : 'none empty'} · {x.stage === 'reviewed' ? 'reviewed' : 'draft'}</>}</Text>
          </div>
          <Text type="secondary" style={{ fontSize: 12 }}>open →</Text>
        </div>
      )
    }
    if (!live) {
      const sum = c.kind === 'goal' ? goalsOf(x).map((g) => g.title).join(' + ') : c.kind === 'reader' ? `${FORMAT_LABEL[x.format]} for ${x.audience || '…'}` : c.kind === 'structure' ? (tpl ? tpl.name : x.brief?.description === BLANK ? 'Blank' : 'From your description') : `${inc.length} ${unitOf(x)}s`
      return <div className="hc hc-folded"><StepHead k={c.kind as Step} x={x} live={false} /><span className="hc-sum">{sum}</span></div>
    }
    if (c.kind === 'goal') return (
      <div className="hc"><StepHead k="goal" x={x} live />
        <Flex vertical gap={6}>{allGoals.map((g) => {
          const ok = g.findings.length > 0
          const on = x.goalIds.includes(g.id)
          return (
            <div key={g.id} className={`sd-pick${on ? ' is-on' : ''}${ok ? '' : ' is-off'}`} style={{ ['--agent' as string]: g.agent.colour }} onClick={() => ok && send(`Goal ${ready.indexOf(g) + 1}`)}>
              <Checkbox checked={on} disabled={!ok} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <Flex justify="space-between" gap={8}><Text style={{ fontWeight: 500 }}>{g.title}</Text><Text style={{ fontSize: 12, color: g.agent.colour, whiteSpace: 'nowrap' }}>{g.agent.name}</Text></Flex>
                <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>{ok ? `${g.findings.length} findings · ${g.recommendations.length} recommendations` : 'No findings yet; nothing to draw on'}</Text>
              </div>
            </div>
          )
        })}</Flex>
        <Button type="primary" size="small" style={{ marginTop: 10 }} onClick={() => send('Next')}>Continue</Button>
      </div>
    )
    if (c.kind === 'reader') return (
      <div className="hc"><StepHead k="reader" x={x} live />
        <div className="sd-form">
          <label>Title</label><Input size="small" value={x.title} onChange={(e) => store.update(x.id, { title: e.target.value })} />
          <label>Who reads it</label><Input size="small" value={x.audience} onChange={(e) => store.update(x.id, { audience: e.target.value })} placeholder="e.g. BPUC staff, working session 4 November" />
          <label>What they decide</label><Input.TextArea size="small" autoSize={{ minRows: 1, maxRows: 3 }} value={x.purpose} onChange={(e) => store.update(x.id, { purpose: e.target.value })} />
          <label>Format</label><Flex gap={4} wrap>{OUTPUT_FORMATS.map((f) => <span key={f.key} className={`gc-chip${x.format === f.key ? ' is-sel' : ''}`} onClick={() => store.update(x.id, { format: f.key }, me, `Format: ${FORMAT_LABEL[f.key]}.`)}>{FORMAT_LABEL[f.key]}</span>)}</Flex>
        </div>
        <Button type="primary" size="small" style={{ marginTop: 10 }} disabled={!x.audience} onClick={() => send('Next')}>Continue</Button>
      </div>
    )
    if (c.kind === 'structure') return (
      <div className="hc"><StepHead k="structure" x={x} live />
        <div className="sd-current">
          <Text style={{ fontWeight: 500 }}>{tpl ? `Template: ${tpl.name}` : x.brief?.description === BLANK ? `Blank ${FORMAT_LABEL[x.format].toLowerCase()}` : 'From your description'}</Text>
          {!tpl && x.brief?.description && x.brief.description !== BLANK ? <Text type="secondary" style={{ display: 'block', fontSize: 12, fontStyle: 'italic' }}>"{x.brief.description.length > 160 ? `${x.brief.description.slice(0, 158)}…` : x.brief.description}"</Text> : null}
          <ol className="g-ul" style={{ fontSize: 12.5, marginTop: 4, marginBottom: 0 }}>{inc.map((y) => <li key={y.id}>{y.heading}</li>)}</ol>
          {!tpl && x.brief?.description !== BLANK ? <a style={{ fontSize: 12 }} onClick={() => send('Save as a template')}>Save as a template</a> : null}
        </div>
        <Flex gap={6} wrap style={{ marginTop: 8 }}>
          <span className={`gc-chip${tplPickFor === x.id ? ' is-sel' : ''}`} onClick={() => setTplPickFor(tplPickFor === x.id ? null : x.id)}>Another template</span>
          <span className="gc-chip" onClick={() => { fileFor.current = 'structure'; fileRef.current?.click() }}><UploadOutlined /> Your own file</span>
          <span className="gc-chip" onClick={() => send('Start blank')}>Blank</span>
        </Flex>
        {tplPickFor === x.id ? <Row gutter={[6, 6]} style={{ marginTop: 8 }}>{templates.map((tt, i) => <Col key={tt.id} xs={24} xl={12}><TemplateCard t={tt} compact selected={x.templateId === tt.id} onPick={() => send(`Use template ${i + 1}`)} /></Col>)}</Row> : null}
        <Flex gap={6} style={{ marginTop: 8 }}>
          <Input.TextArea size="small" autoSize={{ minRows: 1, maxRows: 4 }} value={describeFor[x.id] ?? ''} onChange={(e) => setDescribeFor((d) => ({ ...d, [x.id]: e.target.value }))} placeholder="Or describe the structure in words" />
          <Button size="small" disabled={(describeFor[x.id] ?? '').trim().length < 12} onClick={() => send(`Describe: ${describeFor[x.id]}`)}>Read it</Button>
        </Flex>
        <Button type="primary" size="small" style={{ marginTop: 10 }} onClick={() => send('Next')}>Continue to the outline</Button>
      </div>
    )
    if (c.kind === 'outline') {
      const move = (id: string, d: -1 | 1) => { const l = [...x.sections]; const a = l.findIndex((y) => y.id === id); const b = a + d; if (b < 0 || b >= l.length) return; [l[a], l[b]] = [l[b], l[a]]; store.setSections(x.id, l) }
      return (
        <div className="hc"><StepHead k="outline" x={x} live />
          <Flex vertical gap={4}>{x.sections.map((y, i) => (
            <div key={y.id} className={`sd-ol${y.included ? '' : ' is-out'}`}>
              <Checkbox checked={y.included} onChange={(e) => setSec(x.id, y.id, { included: e.target.checked }, true)} />
              <span className="sd-rail-n">{i + 1}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Input size="small" variant="borderless" value={y.heading} onChange={(e) => setSec(x.id, y.id, { heading: e.target.value }, true)} style={{ fontWeight: 500, padding: 0 }} />
                <Text type="secondary" style={{ display: 'block', fontSize: 11.5 }}>{y.body.trim() ? `From ${y.from}` : <span style={{ color: STATUS.warn }}>Empty: you write it</span>}</Text>
              </div>
              <span className="sd-ol-tools"><a onClick={() => move(y.id, -1)}>↑</a><a onClick={() => move(y.id, 1)}>↓</a></span>
            </div>
          ))}</Flex>
          <a className="sd-add" onClick={() => send(`Add a ${unitOf(x)} on New ${unitOf(x)}`)}><PlusOutlined /> Add a {unitOf(x)}</a>
          <div><Button type="primary" size="small" style={{ marginTop: 10 }} onClick={() => send('Build it')}>Build it</Button></div>
        </div>
      )
    }
    return null
  }

  /* ---------------- the output panel */
  const renderPart = (x: Submission, y: Section, i: number) => {
    const on = sel === y.id
    const empty = !y.body.trim()
    const gg = goalsOf(x)[0] ?? null
    const v = gg && !empty ? visualForFormat(gg, y.role, y.heading, x.format) : null
    const offer = empty ? suggestFill(goalsOf(x), y.role, y.heading) : null
    const d = drillFor(gg, y)
    const ed = editing === y.id
    const inc = x.sections.filter((z) => z.included)
    return (
      <div key={y.id} id={`hp-${y.id}`} className={`sd-part is-${x.format.replace(' ', '-').toLowerCase()}${on ? ' is-on' : ''}${empty ? ' is-empty' : ''}`} style={{ ['--agent' as string]: agentOf(x).colour }} onClick={() => { if ((window.getSelection()?.toString().trim().length ?? 0) > 2) return; setSel(on ? null : y.id); setQuote(null) }}>
        <div className="sd-part-head">
          <span className="sd-n">{x.format === 'Slide pack' ? `${i + 1} / ${inc.length}` : i + 1}</span>
          {!ed ? <div className="sd-h">{y.heading}</div> : null}
          {!ed ? <span className="sd-tools no-print" onClick={(e) => e.stopPropagation()}><Tooltip title="Edit"><EditOutlined onClick={() => setEditing(y.id)} /></Tooltip>{d ? <Tooltip title="The data behind it"><TableOutlined onClick={() => setDrill(d)} /></Tooltip> : null}</span> : null}
        </div>
        {ed ? (
          <div className="no-print" onClick={(e) => e.stopPropagation()}>
            <Input value={y.heading} onChange={(e) => setSec(x.id, y.id, { heading: e.target.value })} style={{ fontWeight: 600, marginBottom: 6 }} />
            <Input.TextArea value={y.body} autoSize={{ minRows: 3, maxRows: 14 }} onChange={(e) => setSec(x.id, y.id, { body: e.target.value, from: y.from.startsWith('You') ? 'You' : `${y.from.replace(/, edited by .*$/, '')}, edited by ${me}` })} />
            <Button size="small" type="primary" style={{ marginTop: 6 }} onClick={() => setEditing(null)}>Done</Button>
          </div>
        ) : empty ? (
          <div className="sd-offer no-print" onClick={(e) => e.stopPropagation()}>
            <span className="sd-offer-mark" style={{ background: `${agentOf(x).colour}18`, color: agentOf(x).colour }}><BulbOutlined /></span>
            <div style={{ flex: 1 }}>
              <Text style={{ fontSize: 13 }}>{offer?.body ? `I can fill this from ${offer.from.replace(/, Agent.*$/, '').toLowerCase()}.` : 'Nothing in the goal covers this yet.'}</Text>
              <Flex gap={6} style={{ marginTop: 6 }} wrap>
                {offer?.body ? <Button size="small" type="primary" onClick={() => { setSel(y.id); send('Fill it') }}>Fill it</Button> : null}
                <Button size="small" onClick={() => setEditing(y.id)}>Write it myself</Button>
                <Button size="small" type="text" onClick={() => { setSel(y.id); send('Remove it') }}>Leave it out</Button>
              </Flex>
            </div>
          </div>
        ) : v ? (
          x.format === 'Dashboard'
            ? <div className="sd-dash-body"><div className="sd-slide-vis"><VisualBlock v={v} compact /></div><Paragraph className="sd-text sd-clamp">{y.body}</Paragraph></div>
            : <div className="sd-slide-body">{x.format === 'Slide pack' ? <ul className="sd-text sd-bullets">{slideBullets(y.body).map((b, k) => <li key={k}>{b}</li>)}</ul> : <Paragraph className="sd-text">{y.body}</Paragraph>}<div className="sd-slide-vis"><VisualBlock v={v} compact /></div></div>
        ) : <Paragraph className="sd-text">{y.body}</Paragraph>}
        {!empty && !ed ? <div className="sd-from no-print">↳ {y.from}{d ? <> · <a onClick={(e) => { e.stopPropagation(); setDrill(d) }}>open the data</a></> : null}</div> : null}
      </div>
    )
  }

  /* One line per submission: what it is, where it stands, and the way back into its chat. */
  const match = useRailMatch()
  const drafts = submissions.filter((x) => x.stage !== 'reviewed')
  const reviewed = submissions.filter((x) => x.stage === 'reviewed')
  const stepOf = (x: Submission): Step => steps[x.id] ?? (x.stage === 'template' ? 'structure' : x.stage === 'outline' ? 'outline' : 'goal')
  const row = (x: Submission) => {
    const inc = x.sections.filter((y) => y.included)
    const emp = inc.filter((y) => !y.body.trim())
    const setup = inSetup(x)
    const k = STEPS.findIndex((y) => y.key === stepOf(x))
    const status = x.stage === 'reviewed' ? <span className="is-good"><CheckOutlined /> Reviewed · {FORMAT_LABEL[x.format].toLowerCase()}</span>
      : setup ? <span>Setting up · step {k + 1} of 6</span>
      : emp.length ? <span className="is-warn">{emp.length} {unitOf(x)}{emp.length > 1 ? 's' : ''} to write</span>
      : <span>{FORMAT_LABEL[x.format]} · version {isDash(x) ? Math.max(1, useDesign.getState().versions.length) : x.version ?? 1}{x.journeyId && useJourney.getState().goals[x.journeyId]?.built[x.delivId ?? ''] === x.id && (useJourney.getState().goals[x.journeyId]?.deliv.find((d) => d.id === x.delivId)?.custom || !['sub-rb-schedules', 'sub-rb-memo', 'sub-rb-deck', 'sub-proc-note', 'sub-proc-change'].includes(x.delivId ?? '')) ? ' · made here' : ''}</span>
    const on = activeId === x.id && hub().chat === x.id
    return <RailItem key={x.id} title={x.title} status={status} on={on} icon={FORMAT_ICON[x.format]} onClick={() => { if (on) { hub().set({ panel: 'doc' }); setPanelOpen(true) } else navigate(appPath(`/submissions/${x.id}`)) }} />
  }
  /* One group per analysis that has run, holding everything made from it: what the run built and what was made here since. */
  const loose = submissions.filter((x) => !x.journeyId || !analyses.some((a) => a.id === x.journeyId))
  void drafts; void reviewed
  const rail = (
    <>
      <RailSearch placeholder="Search deliverables" />
      {analyses.length ? analyses.map((a) => { const list = submissions.filter((x) => x.journeyId === a.id && match(`${x.title} ${runLabel(a)}`)); return <RailSection key={a.id} id={`s-a-${a.id}`} label={runLabel(a)} n={list.length}>{list.map(row)}<div className="rl-link" role="button" onClick={() => { newChat(false); hub().push({ who: 'me', text: `More from ${runLabel(a)}` }); pickAnalysis(a.id) }}><PlusOutlined /> Make more from it</div></RailSection> })
        : <RailSection id="s-none" label="Deliverables" n={0} empty="Nothing has run yet. Every goal run's deliverables land here." />}
      {loose.length ? <RailSection id="s-other" label="Other" n={loose.length}>{loose.filter((x) => match(x.title)).map(row)}</RailSection> : null}
      <RailSection id="s-library" label="Library">
        <div className={`rl-link${panel === 'templates' && panelOpen ? ' is-on' : ''}`} role="button" onClick={() => { hub().set({ panel: 'templates' }); setPanelOpen(true) }}><FileAddOutlined /> Templates <span style={{ marginLeft: 'auto', color: '#98a2b3', fontSize: 12 }}>{templates.length}</span></div>
      </RailSection>
    </>
  )

  /* The panel shows only what the chat is about: the submission, or the template library when asked for. */
  const panelFor = (): 'doc' | 'templates' | null => (panel === 'templates' ? 'templates' : s && (hub().chat === s.id || bld?.sids.includes(s.id) || submissions.some((y) => y.id === hub().chat && y.journeyId && y.journeyId === s.journeyId)) ? 'doc' : null)
  const renderPanel = () => {
    if (panelFor() === 'templates') {
      return (
        <div className="hp">
          <div className="hp-head"><span>Library</span><span className="hp-x" role="button" aria-label="Close the panel" onClick={() => hub().set({ panel: 'doc' })}><CloseOutlined /></span></div>
          <div className="hp-title">Templates</div>
          <span className="hp-sub" style={{ marginBottom: 12 }}>Every recommendation rests on one of these. Attach a file in the chat to add your own.</span>
          <TemplateLibrary />
        </div>
      )
    }
    if (!s) return null
    const x = s
    const inc = x.sections.filter((y) => y.included)
    const emp = inc.filter((y) => !y.body.trim())
    const tpl = templates.find((y) => y.id === x.templateId)
    const downloads = downloadsOf(x)
    const setup = inSetup(x)
    const isLive = x.format === 'Dashboard'
    return (
      <div className="hp">
        <div className="hp-head">
          <span>{setup ? 'Setting up' : x.stage === 'reviewed' ? 'Reviewed' : 'Draft'} · {FORMAT_LABEL[x.format]}</span>
          <span className="hp-x" role="button" aria-label="Close the panel" onClick={() => setPanelOpen(false)}><CloseOutlined /></span>
        </div>
        <div className="hp-title">{x.title}</div>
        <span className="hp-sub">For {(x.audience || '…').replace(/^The /, 'the ')} · built on {tpl?.name ?? (x.brief?.description === BLANK ? 'blank' : 'your description')} · from {goalsOf(x).map((g) => g.title).join(' + ') || '…'}</span>
        {setup ? (
          <div className="hp-setup">
            <Text style={{ display: 'block', fontSize: 13, margin: '0 0 10px', color: '#3c4859' }}>Step {STEPS.findIndex((y) => y.key === (steps[x.id] ?? 'goal')) + 1} of 6, {STEPS.find((y) => y.key === (steps[x.id] ?? 'goal'))!.label.toLowerCase()}. The outline so far; the output is built here when you say "build it".</Text>
            <ol className="hp-preview">{inc.map((y) => <li key={y.id}><span>{y.heading}</span><span className={`sd-dot${y.body.trim() ? ' is-full' : ''}`} /></li>)}</ol>
          </div>
        ) : (
          <>
            {bld && bld.sids.includes(x.id) ? (
              <div className="bld" data-testid="building">
                <div className="bld-h"><span className="bld-spin" /><b>Building</b><span>{bld.i + 1} of {bld.sids.length} · {Math.min(shown, inc.length)} of {inc.length} {unitOf(x)}s</span></div>
                {bld.sids.length > 1 ? <div className="bld-list">{bld.sids.map((id, i) => { const y = sub(id); return y ? <span key={id} className={`bld-chip${i < bld.i ? ' is-done' : i === bld.i ? ' is-now' : ''}`}>{i < bld.i ? <CheckOutlined /> : i === bld.i ? <span className="bld-dot" /> : null}{y.title.split(':')[0]}</span> : null })}</div> : null}
                {bld.lines.length ? <div className="ap">{bld.lines.map((l, i) => <div key={i} className={`ap-line is-one${i === bld.lines.length - 1 && shown === 0 ? ' is-live' : ''}`}><span className="ap-tool"><span className="ap-dot" />{l}</span></div>)}</div> : <div className="ap"><div className="ap-line is-one is-live"><span className="ap-tool"><span className="ap-dot" />Starting</span></div></div>}
              </div>
            ) : null}
            <Flex justify="space-between" align="center" gap={8} wrap className="hp-bar" style={bld && bld.sids.includes(x.id) ? { display: 'none' } : undefined}>
              <span className="sd-ready">{isDash(x) ? <span data-testid="dash-meta">{PANELS.filter((q) => DESIGN.panels[q.k]).length} views · version {Math.max(1, dashVers.length)} · {dashVers.length && dashVers[dashVers.length - 1].refreshed ? `refreshed ${dashVers[dashVers.length - 1].refreshed}` : dashVers.length ? `scored ${dashVers[dashVers.length - 1].at}` : 'live'} · {x.stage === 'reviewed' ? <span style={{ color: STATUS.good }}><CheckOutlined /> reviewed</span> : 'draft'}</span> : <>{inc.length} {unitOf(x)}s · {emp.length ? <span style={{ color: STATUS.warn }}>{emp.length} empty</span> : 'none empty'} · {x.stage === 'reviewed' ? <span style={{ color: STATUS.good }}><CheckOutlined /> reviewed</span> : 'draft'}{isLive ? <> · <Tag color="processing" style={{ marginInlineEnd: 0 }}>Live</Tag> as of {DRILL.as_of}, {refreshedAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</> : null}</>}</span>
              <Flex gap={4} wrap>
                {x.stage !== 'reviewed' ? <Tooltip title={emp.length ? 'Fill, write or leave out the empty parts first' : 'You have read it and it can leave'}><Button size="small" type="primary" icon={<CheckOutlined />} disabled={emp.length > 0} onClick={() => send('Mark as reviewed')}>Mark as reviewed</Button></Tooltip> : null}
                {x.format === 'Slide pack' || x.format === 'Dashboard' ? <Tooltip title={x.format === 'Slide pack' ? 'Present the slides full screen (arrow keys, Esc to leave)' : isDash(x) ? 'The whole dashboard on the full screen (Esc to leave)' : 'Full screen'}><Button size="small" icon={<FundProjectionScreenOutlined />} onClick={() => setPresenting(0)}>{x.format === 'Slide pack' ? 'Present' : 'Full screen'}</Button></Tooltip> : null}
                {downloads.length === 1 ? <Button size="small" icon={downloads[0].icon} onClick={() => send(`Download the ${downloads[0].label}`)}>Download</Button> : <Dropdown trigger={['click']} menu={{ items: downloads.map((d) => ({ key: d.key, icon: d.icon, label: d.label, onClick: () => send(`Download the ${d.label}`) })) }}><Button size="small" icon={<DownloadOutlined />}>Download</Button></Dropdown>}
                <Button size="small" icon={<ShareAltOutlined />} onClick={() => send('Share')} />
                <Tooltip title="Where every figure comes from"><Button size="small" icon={<ApartmentOutlined />} onClick={() => send('Where do the figures come from?')} /></Tooltip>
                {isLive ? <Button size="small" icon={<ReloadOutlined />} onClick={() => send('Refresh')} /> : null}
              </Flex>
            </Flex>
            <div className="hp-canvas" onMouseUp={() => {
              const ws = window.getSelection()
              const tx = ws?.toString().trim() ?? ''
              if (!ws || tx.length < 3 || !ws.rangeCount) { setPill(null); return }
              const node = ws.anchorNode instanceof Element ? ws.anchorNode : ws.anchorNode?.parentElement
              const el = node?.closest('.sd-part') as HTMLElement | null
              if (!el || node?.closest('.no-print, .sb-vis')) { setPill(null); return }
              const r = ws.getRangeAt(0).getBoundingClientRect()
              setPill({ id: el.id.replace(/^hp-/, ''), text: tx, x: Math.min(r.left, window.innerWidth - 240), y: r.top })
            }}>
              <div ref={canvasRef} className={`sd-canvas is-${x.format.replace(' ', '-').toLowerCase()}${x.delivId === 'sub-risk-scorecard' ? ' is-dash' : ''}`}>
                {x.delivId === 'sub-risk-scorecard' ? <DashEmbed journeyId={x.journeyId} /> : null}
                <div className="sd-print-title">{x.title}<div>To {x.audience} · {FORMAT_LABEL[x.format]} · {x.reviewedBy ? `reviewed by ${x.reviewedBy}` : 'draft, not reviewed'}</div></div>
                {inc.slice(0, shown).map((y, i) => renderPart(x, y, i))}
                {shown < inc.length ? <div className="sd-building no-print"><span className="st-pulse" /> {shown === 0 && bld ? 'preparing…' : `writing ${unitOf(x)} ${shown + 1} of ${inc.length}: ${inc[shown]?.heading ?? ''}…`}</div> : null}
              </div>
            </div>
          </>
        )}
      </div>
    )
  }

  /* ---------------- chips: what you could say next */
  const x0 = s
  const chips = quote ? ['Make it shorter', 'Remove it', 'Where is this from?']
    : !x0 ? []
    : inSetup(x0) ? ((steps[x0.id] ?? 'goal') === 'outline' ? ['Build it', 'Back'] : (steps[x0.id] ?? 'goal') === 'reader' && !x0.audience ? [] : ['Next', ...((steps[x0.id] ?? 'goal') !== 'goal' ? ['Back'] : [])])
    : sel ? ['Make it shorter', 'Fill it', 'Show the data', 'Remove it']
    : x0.stage === 'reviewed' ? ['Download', 'Share', 'New submission'] : ['Download', 'Where do the figures come from?', 'Make another from the same analysis']

  const scopeLabel = quote && s ? `${unitOf(s)} ${s.sections.findIndex((y) => y.id === quote.id) + 1}: "${quote.text.length > 44 ? `${quote.text.slice(0, 42)}…` : quote.text}"` : sel && s ? `${unitOf(s)} ${s.sections.findIndex((y) => y.id === sel) + 1}: ${s.sections.find((y) => y.id === sel)?.heading ?? ''}` : null

  /* ---------------- where you are: the journey bar, the docked step, the resume line */
  type JS = JStep & { next: string; dock?: string }
  const mine = s && chat === s.id ? s : null
  const lastCard = (kind: CardKind, subId: string) => { for (let i = msgs.length - 1; i >= 0; i -= 1) { const c = msgs[i].card; if (c && c.subId === subId && c.kind === kind) return msgs[i].id } return null }
  const journey: JS[] = (() => {
    if (!mine) return [
      { key: 'analysis', label: 'Analysis', state: analysis ? 'done' : 'now', next: 'pick the analysis', onClick: undefined },
      { key: 'make', label: 'What to make', state: analysis ? 'now' : 'todo', next: 'tick what to make and the template' },
      { key: 'built', label: 'Built', state: 'todo', next: '' },
    ]
    const x = mine
    const emp = x.sections.filter((y) => y.included && !y.body.trim()).length
    const openDoc = () => { hub().set({ activeId: x.id, panel: 'doc' }); setPanelOpen(true); scrollToMsg(lastCard('output', x.id)) }
    return [
      { key: 'analysis', label: 'Analysis', state: 'done', next: '', onClick: () => { const jid = x.journeyId; if (jid) navigate(appPath(`/goals/${jid}`)) } },
      { key: 'make', label: 'What to make', state: 'done', next: '' },
      { key: 'built', label: x.stage === 'reviewed' ? 'Reviewed' : 'Built', state: emp ? 'now' : 'done', sub: emp ? `${emp} empty` : `v${isDash(x) ? Math.max(1, dashVers.length) : x.version ?? 1}`, onClick: openDoc, next: `fill or write the ${emp === 1 ? 'empty part' : `${emp} empty parts`}` },
    ]
  })()
  void STEPS
  const nowStep = journey.find((y) => y.state === 'now')
  const nowIdx = nowStep ? journey.indexOf(nowStep) + 1 : journey.length
  const resumeLine = !mine || resumed !== mine.id ? null
    : nowStep ? `Back on this. Step ${nowIdx} of ${journey.length}, ${nowStep.label}. Next: ${nowStep.next}.`
      : 'Back on this. It is reviewed: download it or share the link.'

  const panelKind = panelFor()
  const chatTitle = s && hub().chat === s.id ? s.title : 'Make more deliverables'
  return (
    <>
    <HubFrame rail={rail} panel={panelOpen && panelKind ? renderPanel() : null}>
      <input ref={fileRef} type="file" accept=".pptx,.docx,.txt,.md,.pdf,.xlsx" style={{ display: 'none' }} data-testid="hub-upload" onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); e.target.value = '' }} />
        <div className="hub-top">
          <RailToggle />
          <span className="hub-top-title"><span>{chatTitle}</span>{s && hub().chat === s.id ? <span className={`pill ${s.stage === 'reviewed' ? 'is-green' : inSetup(s) ? 'is-amber' : 'is-grey'}`}><i />{s.stage === 'reviewed' ? 'Reviewed' : inSetup(s) ? 'Setting up' : 'Draft'}</span> : null}</span>
          {!panelOpen && panelKind ? <Tooltip title="Show it on the right"><span role="button" aria-label="Show the panel" className="hub-icon" onClick={() => setPanelOpen(true)}><LayoutOutlined /></span></Tooltip> : null}
          {hub().chat.startsWith('new-') && !msgs.some((m) => m.who === 'me') ? null : <Button className="hub-new" icon={<PlusOutlined />} onClick={() => newChat()}>New submission</Button>}
        </div>
        <JourneyBar steps={journey} />
        <div className="hub-feed" ref={feedRef}>
          {msgs.map((m) => m.who === 'event' ? <div key={m.id} className="gc-event">{m.text}</div>
            : m.who === 'me' ? <div key={m.id} id={`msg-${m.id}`} className="hub-me"><div className="gc-bubble is-me">{m.file ? <span className="gc-file"><PaperClipOutlined /> {m.file.name} <span className="gc-file-size">{fileSize(m.file.size)}</span></span> : null}{m.text}</div></div>
            : (
              <div key={m.id} id={`msg-${m.id}`} className={`hub-agent${cont(m) ? ' is-cont' : ''}`}>
                <AgentMark agent={m.agent ?? NEUTRAL} />
                <div className="hub-agent-body">
                  {m.text ? <div className="hub-text"><RichText text={m.text} /></div> : null}
                  {m.card ? renderCard(m) : null}
                </div>
              </div>
            ))}
          {typing ? <div className="hub-agent"><AgentMark agent={agentOf(s)} /><div className="gc-bubble is-agent gc-typing"><span /><span /><span /></div></div> : null}
          {resumeLine && !typing ? <div className="gc-event is-resume" data-testid="resume">{resumeLine}</div> : null}
          <div ref={endRef} />
        </div>
        <div className="hub-input">
          {nowStep?.dock && mine && inSetup(mine) ? <Dock away={dock.away} go={dock.go} label={nowStep.dock} /> : null}
          {chips.length ? <div className="gc-chips" style={{ borderTop: 0, padding: '0 0 6px' }}>{chips.map((c) => <span key={c} className="gc-chip" onClick={() => send(c)}>{c}</span>)}</div> : null}
          {scopeLabel ? <div className="gc-scope" style={{ margin: '0 0 4px' }}>About: <b>{scopeLabel}</b><span role="button" onClick={() => { setSel(null); setQuote(null) }}>×</span></div> : null}
          <div className="gc-box" style={{ margin: 0 }}>
            <span role="button" aria-label="Attach a file" className="gc-clip" onClick={() => { fileFor.current = s && inSetup(s) ? 'structure' : 'start'; fileRef.current?.click() }}><PaperClipOutlined /></span>
            <Input.TextArea value={text} onChange={(e) => setText(e.target.value)} autoSize={{ minRows: 1, maxRows: 6 }} variant="borderless" aria-label="Message"
              placeholder={quote ? 'What should it say instead? e.g. replace with …' : s && inSetup(s) ? 'Answer here, change the card above, or say "next"' : s ? 'Tell me what to change, or say "new …" to start another' : 'What do you need to send?'}
              onPressEnter={(e) => { if (!e.shiftKey) { e.preventDefault(); send(text) } }} />
            <span role="button" aria-label="Send" className={`gc-send${text.trim() ? ' is-on' : ''}`} onClick={() => send(text)}><ArrowUpOutlined /></span>
          </div>
        </div>
    </HubFrame>

      {pill ? (
        <div className="sd-pill no-print" style={{ left: pill.x, top: pill.y - 40 }} onMouseDown={(e) => { e.preventDefault(); setQuote({ id: pill.id, text: pill.text }); setSel(pill.id); setPill(null); window.setTimeout(() => (document.querySelector('.hub-input textarea') as HTMLTextAreaElement | null)?.focus(), 60) }}>
          <MessageOutlined /> Change this
        </div>
      ) : null}
      {presenting !== null && s ? (isDash(s) ? <DashFull s={s} onClose={() => setPresenting(null)} /> : <Presenter s={s} goal={g0} at={presenting} onAt={setPresenting} onClose={() => setPresenting(null)} />) : null}
      <Drawer open={!!drill} onClose={() => setDrill(null)} width="min(1280px, 94vw)" title="The data behind it" destroyOnHidden styles={{ body: { padding: SP.base } }}>
        {drill ? <DataExplorer start={drill} height={Math.max(360, window.innerHeight - 150)} /> : null}
      </Drawer>
      <Drawer open={lineage} onClose={() => setLineage(false)} width={600} title="Data lineage" destroyOnHidden>
        {s ? s.sections.filter((y) => y.included).map((y, i) => { const v = g0 ? visualForFormat(g0, y.role, y.heading, s.format) : null; return <div key={y.id} className="gw-card" style={{ cursor: 'default', marginBottom: 8 }}><Text style={{ display: 'block', fontWeight: 500, fontSize: 13 }}>{i + 1}. {y.heading}</Text><Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>Filled from: {y.from}</Text>{v ? <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>Picture: {v.title} · {LINEAGE[v.kind].tables.join(', ')}</Text> : null}</div> }) : null}
      </Drawer>
      <Modal open={sharing} onCancel={() => setSharing(false)} footer={null} title="Share">
        {s ? <Flex gap={SP.xs}><Input value={`${window.location.href.split('#')[0]}#${appPath(`/submissions/${s.id}`)}`} readOnly prefix={<LinkOutlined />} /><Button icon={<CopyOutlined />} onClick={() => { navigator.clipboard?.writeText(`${window.location.href.split('#')[0]}#${appPath(`/submissions/${s.id}`)}`).then(() => message.success('Link copied.')).catch(() => message.info('Copy it from the box.')) }}>Copy</Button></Flex> : null}
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: 8 }}>Sending and publishing are not part of this product today.</Text>
      </Modal>
    </>
  )
}

/** A slide shows its point, not its paragraph: the first three sentences or lines, each kept short. */
function slideBullets(body: string): string[] {
  const parts = body.split(/\n+/).flatMap((l) => l.split(/(?<=[.!?])\s+(?=[A-Z$"(0-9])/)).map((x) => x.replace(/^[•\-\d.\s]+/, '').trim()).filter((x) => x.length > 3)
  return parts.slice(0, 3).map((x) => (x.length > 120 ? `${x.slice(0, x.lastIndexOf(' ', 118))}…` : x))
}

/** The live contract risk dashboard: it is drawn by the goal, not from the sections of the submission. */
const isDash = (x: { delivId?: string }) => x.delivId === 'sub-risk-scorecard'

/** The dashboard on the full screen: the same live dashboard, nothing else around it. Esc to leave. */
function DashFull({ s, onClose }: { s: Submission; onClose: () => void }) {
  useEffect(() => { const on = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }; window.addEventListener('keydown', on); return () => window.removeEventListener('keydown', on) }, [onClose])
  return (
    <div className="dfs" role="dialog" aria-label="The dashboard, full screen" data-testid="dash-full">
      <div className="dfs-bar"><b>{s.title}</b><span>Live · the same dashboard as in the goal</span><Button size="small" data-testid="dash-full-close" onClick={onClose}>Exit full screen (Esc)</Button></div>
      <div className="dfs-body"><DashEmbed journeyId={s.journeyId} onLeave={onClose} /></div>
    </div>
  )
}

/** Full-screen presenting, one 16:9 slide at a time: arrows or space to move, Esc to leave. */
function Presenter({ s, goal, at, onAt, onClose }: { s: Submission; goal: Goal | null; at: number; onAt: (n: number) => void; onClose: () => void }) {
  const slides = s.sections.filter((y) => y.included)
  const n = slides.length + 1
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      else if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') { e.preventDefault(); onAt(Math.min(n - 1, at + 1)) }
      else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); onAt(Math.max(0, at - 1)) }
    }
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [at, n, onAt, onClose])
  const y = at > 0 ? slides[at - 1] : null
  const v = y && goal && y.body.trim() ? visualForFormat(goal, y.role, y.heading, s.format) : null
  return (
    <div className="pr" role="dialog" aria-label="Presenting" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="pr-stage">
        {y ? (
          <div className="pr-slide">
            <div className="pr-head"><span className="pr-kicker">{s.title}</span><span className="pr-n">{at} / {n - 1}</span></div>
            <h2 className="pr-title">{y.heading}</h2>
            <div className={`pr-body${v ? '' : ' is-text'}`}>
              {y.body.trim() ? <ul className="pr-bullets">{slideBullets(y.body).map((b, k) => <li key={k}>{b}</li>)}</ul> : <p className="pr-empty">Still to be written.</p>}
              {v ? <div className="pr-vis">{v.kind === 'bullet' ? <BigStat v={v} /> : null}<VisualBlock v={v} /></div> : null}
            </div>
            <div className="pr-foot"><span>Source: {y.from}</span><span>Draft · Context Weave</span></div>
          </div>
        ) : (
          <div className="pr-slide is-cover">
            <span className="pr-kicker">Northline Water Group · {FORMAT_LABEL[s.format]}</span>
            <h1 className="pr-cover-title">{s.title}</h1>
            <p className="pr-cover-meta">To {s.audience || 'the reader'} · prepared by {s.createdBy}{s.agentName ? ` with ${s.agentName}` : ''}</p>
            <p className="pr-cover-draft">{s.reviewedBy ? `Reviewed by ${s.reviewedBy}` : 'Draft, not reviewed'}</p>
          </div>
        )}
      </div>
      <div className="pr-bar">
        <button type="button" aria-label="Previous slide" disabled={at === 0} onClick={() => onAt(at - 1)}><LeftOutlined /></button>
        <div className="pr-dots">{Array.from({ length: n }, (_, i) => <span key={i} className={i === at ? 'is-on' : ''} role="button" aria-label={`Slide ${i}`} onClick={() => onAt(i)} />)}</div>
        <button type="button" aria-label="Next slide" disabled={at === n - 1} onClick={() => onAt(at + 1)}><RightOutlined /></button>
        <button type="button" className="pr-close" onClick={onClose}>Esc · close</button>
      </div>
    </div>
  )
}

/** The figure a forecast-against-budget slide is about, set large above its chart. */
function BigStat({ v }: { v: { data: Record<string, unknown> } }) {
  const d = v.data as { approved: number; forecast: number; variancePct: number; rulePct: number }
  const eur = (n: number) => (n >= 1e9 ? `$${(n / 1e9).toFixed(2)}B` : n >= 1e6 ? `$${(n / 1e6).toFixed(2)}M` : `$${Math.round(n / 1000)}k`)
  return (
    <div className="pr-stat">
      <div><b>{eur(d.forecast)}</b><span>forecast</span></div>
      <div><b>{eur(d.approved)}</b><span>approved</span></div>
      <div className={d.variancePct > d.rulePct ? 'is-crit' : d.variancePct > 0 ? 'is-warn' : ''}><b>{d.variancePct >= 0 ? '+' : ''}{d.variancePct}%</b><span>{d.variancePct > d.rulePct ? `above the ${d.rulePct}% rule` : `inside the ${d.rulePct}% rule`}</span></div>
    </div>
  )
}
