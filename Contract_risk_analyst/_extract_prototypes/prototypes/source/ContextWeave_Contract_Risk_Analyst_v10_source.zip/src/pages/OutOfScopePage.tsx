import { Button, Card, Typography } from 'antd'
import { useLocation, useNavigate } from 'react-router-dom'
import { appPath, splitDatasetPath } from '../api/dataset'
import PageHeader from '../components/common/PageHeader'
import { NAV_ITEMS } from '../nav'
import { SP } from '../theme'

/*
 * The screens this prototype does not redesign. They stay in the sidebar so the shell reads as the
 * whole product, but the prototype is about Goals and the submission journey that follows from them.
 * The working versions of these screens are in the platform demo file beside this one.
 */
export default function OutOfScopePage() {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const route = splitDatasetPath(pathname).rest
  const item = NAV_ITEMS.find((i) => route.startsWith(i.path))
  return (
    <>
      <PageHeader title={item?.label ?? 'Not in this prototype'} subtitle={item?.key === 'new-graph' ? 'Where a role is defined: what used to be the use case. Not part of this prototype.' : 'Not part of this prototype.'} />
      <Card size="small" style={{ maxWidth: 720 }}>
        <Typography.Paragraph style={{ fontSize: 13.5, marginBottom: SP.sm }}>
          This file focuses on <strong>Goals</strong> (what the agent pursues for you, how it plans and shows its work) and on the <strong>Submissions</strong> journey that follows from a goal. The working {item?.label ?? 'screen'} is in the platform demo, <code>ContextWeave_Keolis_Platform_offline.html</code>, in the same folder.
        </Typography.Paragraph>
        <Button type="primary" onClick={() => navigate(appPath('/goals'))}>Go to Goals</Button>
      </Card>
    </>
  )
}
