import { ArrowLeftOutlined, ArrowUpOutlined, FileAddOutlined, LoadingOutlined, PaperClipOutlined, UploadOutlined } from '@ant-design/icons'
import { Col, Drawer, Flex, Input, Row, Tag, Typography } from 'antd'
import { useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { appPath } from '../api/dataset'
import { AgentBadge } from '../components/goals/parts'
import type { Goal } from '../data/goalCases'
import { EXAMPLE_BRIEFS, OUTPUT_FORMATS, designOutline } from '../data/outputDesigner'
import { readUpload } from '../data/readFile'
import { FORMAT_WORDS, bestMatch, templateFromRead } from '../data/subChat'
import type { OutputFormat, Template } from '../data/submissionTemplates'
import { useAuthStore } from '../store/authStore'
import { useGoalStore } from '../store/goalStore'
import { useSubmissionStore } from '../store/submissionStore'
import { SP } from '../theme'
import { FORMAT_ICON, FORMAT_LABEL, TemplateCard } from './SubmissionsPage'
import './SubmissionDoc.css'

const { Text } = Typography

/*
 * New submission: one question, "what do you need to send?". Say it in your own words (the agent reads it
 * into a structure and builds the document in front of you), take one of the outputs your agents
 * recommend, start from a template or your own file, or start blank. Every path opens the document.
 */
export default function NewSubmissionStart() {
  const navigate = useNavigate()
  const location = useLocation()
  const me = useAuthStore((s) => s.identity?.name) ?? 'You'
  const goals = useGoalStore((s) => s.goals)
  const ready = goals.filter((g) => g.findings.length)
  const { templates, startFromGoal, startFromTemplate, startDescribed, addTemplate, update, setSections } = useSubmissionStore()
  const initial = (location.state as { newFromGoal?: string } | null)?.newFromGoal
  const [goalId, setGoalId] = useState<string | undefined>(initial ?? ready[0]?.id)
  const [text, setText] = useState('')
  const [thinking, setThinking] = useState<string | null>(null)
  const [hint, setHint] = useState<string | null>(null)
  const [picking, setPicking] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const g = goals.find((x) => x.id === goalId) ?? ready[0]

  /* Every path opens the set-up on the same surface, at its first step, with the agent's choices filled in for you to confirm or change. */
  const open = (id: string) => { update(id, { stage: 'brief' }); navigate(appPath(`/submissions/${id}`)) }

  const blank = (f: OutputFormat, gg: Goal) => {
    const p = designOutline(f, '', gg)
    const id = startDescribed(gg, 'Started blank, written by hand.', p, me)
    const sub = useSubmissionStore.getState().submissions.find((x) => x.id === id)
    if (sub) setSections(id, sub.sections.map((x) => ({ ...x, body: '', from: 'You' })))
    open(id)
  }

  const submit = () => {
    const words = text.trim()
    if (!g) { setHint('No goal has findings yet; a submission always draws on one.'); return }
    const gg = bestMatch(words, ready, (x) => x.title) ?? g
    const f = FORMAT_WORDS.find(([re]) => re.test(words))?.[1]
    if (/\b(blank|from scratch|write it myself|by hand)\b/i.test(words)) { blank(f ?? 'Document', gg); return }
    if (words.length < 12) { setHint('Say a little more: who it is for and what it should show. Or pick one below.'); return }
    setHint(null)
    setThinking(`${gg.agent.name} is reading your description into a ${FORMAT_LABEL[f ?? 'Document'].toLowerCase()}…`)
    window.setTimeout(() => {
      const p = designOutline(f ?? 'Document', words, gg)
      open(startDescribed(gg, words, p, me))
    }, 1300)
  }

  const fromTemplate = (t: Template) => { if (!g) return; const id = startFromTemplate(t, [g], me); open(id) }
  const onFile = async (file: File) => {
    if (!g) return
    setThinking(`Reading ${file.name}…`)
    const t = templateFromRead(await readUpload(file))
    addTemplate(t, me)
    window.setTimeout(() => fromTemplate(t), 600)
  }

  const recs = ready.flatMap((gg) => gg.submissions.filter((x) => templates.some((t) => t.id === x.templateId)).map((x) => ({ g: gg, x, t: templates.find((t) => t.id === x.templateId)! })))
  const examples = g ? EXAMPLE_BRIEFS[g.id] ?? [] : []

  return (
    <div className="ns">
      <span className="gw-back" role="link" onClick={() => navigate(appPath('/submissions'))}><ArrowLeftOutlined /> Submissions</span>
      <div className="ns-q">What do you need to send?</div>
      {ready.length > 1 ? (
        <Flex gap={6} justify="center" wrap style={{ marginBottom: 10 }}>
          <Text type="secondary" style={{ fontSize: 12.5 }}>From</Text>
          {ready.map((x) => <Tag.CheckableTag key={x.id} checked={x.id === g?.id} onChange={() => setGoalId(x.id)}>{x.title.length > 44 ? `${x.title.slice(0, 42)}…` : x.title}</Tag.CheckableTag>)}
        </Flex>
      ) : g ? <Text type="secondary" style={{ display: 'block', textAlign: 'center', fontSize: 12.5, marginBottom: 10 }}>From "{g.title}", worked by {g.agent.name}</Text> : null}
      <div className="ns-box">
        <Input.TextArea value={text} onChange={(e) => setText(e.target.value)} autoSize={{ minRows: 2, maxRows: 7 }} placeholder="In your own words: what it is, who reads it and what it should show. e.g. a one-page memo to Renee: the contracts on a renewal plan, what is at stake, the lessons from the renewals we lost, next steps." onPressEnter={(e) => { if (!e.shiftKey) { e.preventDefault(); submit() } }} aria-label="Describe what you need to send" />
        <div className="ns-row">
          <span role="button" className="gc-clip" title="Attach a template or a past deliverable" onClick={() => fileRef.current?.click()}><PaperClipOutlined /></span>
          <input ref={fileRef} type="file" accept=".pptx,.docx,.txt,.md,.pdf,.xlsx" style={{ display: 'none' }} data-testid="ns-upload" onChange={(e) => { const f = e.target.files?.[0]; if (f) void onFile(f); e.target.value = '' }} />
          <Text type="secondary" style={{ fontSize: 12, flex: 1 }}>Name the format (slide pack, dashboard, memo, email, spreadsheet) or I use a document.</Text>
          <span role="button" aria-label="Start" className={`gc-send${text.trim() ? ' is-on' : ''}`} onClick={submit}><ArrowUpOutlined /></span>
        </div>
      </div>
      {examples.length ? <div className="ns-ex">{examples.map((e) => <span key={e.format} className="gc-chip" onClick={() => setText(e.text)}>Example: {FORMAT_LABEL[e.format].toLowerCase()}</span>)}</div> : null}
      {thinking ? <div className="ns-thinking"><LoadingOutlined /> {thinking}</div> : hint ? <div className="ns-thinking">{hint}</div> : null}

      {recs.length ? (
        <>
          <div className="ns-h">Recommended by your agents · each rests on a template in your library</div>
          <div className="ns-cards">
            {recs.map(({ g: gg, x, t }) => (
              <div key={`${gg.id}-${x.id}`} className="ns-card" onClick={() => open(startFromGoal(gg, x, me))}>
                <Flex justify="space-between" align="center" gap={8}><AgentBadge agent={gg.agent} /><Tag icon={FORMAT_ICON[t.format]} style={{ marginInlineEnd: 0 }}>{FORMAT_LABEL[t.format]}</Tag></Flex>
                <Text style={{ display: 'block', fontSize: 14, fontWeight: 500, margin: '8px 0 2px' }}>{x.label}</Text>
                <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>To {x.audience}</Text>
                <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginTop: 4 }}>{x.why}</Text>
              </div>
            ))}
          </div>
        </>
      ) : null}

      <div className="ns-h">Or start from</div>
      <div className="ns-other">
        <div className="ns-card" onClick={() => setPicking(true)}><FileAddOutlined /> <Text style={{ fontWeight: 500 }}>A template</Text><Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>{templates.length} in your library</Text></div>
        <div className="ns-card" onClick={() => fileRef.current?.click()}><UploadOutlined /> <Text style={{ fontWeight: 500 }}>Your own file</Text><Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}>A template or a past deliverable; I read its structure</Text></div>
        <div className="ns-card" style={{ cursor: 'default' }}><Text style={{ fontWeight: 500 }}>Blank, write it yourself</Text>
          <Flex gap={4} wrap style={{ marginTop: 6 }}>{OUTPUT_FORMATS.map((f) => <span key={f.key} className="gc-chip" onClick={() => g && blank(f.key, g)}>{FORMAT_LABEL[f.key]}</span>)}</Flex>
        </div>
      </div>

      <Drawer title="Start from a template" open={picking} onClose={() => setPicking(false)} width={720} destroyOnHidden>
        <Text type="secondary" style={{ display: 'block', fontSize: 12.5, marginBottom: SP.base }}>Filled from "{g?.title}" where each section's role matches.</Text>
        <Row gutter={[SP.sm, SP.sm]}>{templates.map((t) => <Col key={t.id} span={12}><TemplateCard t={t} compact onPick={() => { setPicking(false); fromTemplate(t) }} /></Col>)}</Row>
      </Drawer>
    </div>
  )
}
