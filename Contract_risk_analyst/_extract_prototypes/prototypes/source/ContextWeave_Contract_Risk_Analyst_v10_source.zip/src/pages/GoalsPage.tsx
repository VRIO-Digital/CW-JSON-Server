import { AimOutlined, BellOutlined, ClockCircleOutlined, GlobalOutlined, PlusOutlined, ThunderboltOutlined, WarningOutlined } from '@ant-design/icons'
import { Button, Card, Col, Collapse, Flex, Row, Space, Tag, Typography } from 'antd'
import { useMemo, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { appPath } from '../api/dataset'
import PageHeader from '../components/common/PageHeader'
import GoalWorkspace from '../components/goals/GoalWorkspace'
import NewGoalChat from '../components/goals/NewGoalChat'
import GoalsHub from './GoalsHub'
import GoalsJourney from './GoalsJourney'
import { AgentBadge, StageDots, StatusTag, TriggerTag } from '../components/goals/parts'
import type { Goal, Watcher } from '../data/goalCases'
import { useGoalStore, type SavedApproach } from '../store/goalStore'
import { BRAND, BRAND_INK, SP, STATUS } from '../theme'
import '../components/goals/ChatPane.css'
import './GoalsPage.css'

const { Text } = Typography

/* ------------------------------------------------------------------ list */

function GoalCard({ g, onOpen }: { g: Goal; onOpen: () => void }) {
  return (
    <Card hoverable size="small" className="g-card" onClick={onOpen} styles={{ body: { padding: `${SP.base}px ${SP.lg}px` } }}>
      <Flex justify="space-between" align="center" gap={SP.sm}>
        <AgentBadge agent={g.agent} />
        <Space size={SP.xs}><StatusTag status={g.status} /><TriggerTag trigger={g.trigger} /></Space>
      </Flex>
      <Text style={{ display: 'block', fontSize: 15, fontWeight: 500, lineHeight: 1.3, margin: `${SP.sm}px 0 ${SP.xs}px` }}>{g.title}</Text>
      <Text type="secondary" style={{ display: 'block', fontSize: 12.5 }}><AimOutlined style={{ color: BRAND }} /> {g.target.target}</Text>
      {g.question ? <Text style={{ display: 'block', fontSize: 12.5, color: STATUS.warn, marginTop: SP.xs }}><WarningOutlined /> One question for you</Text> : null}
      {g.trigger === 'rule' && g.status === 'analysing' ? <Text style={{ display: 'block', fontSize: 12.5, color: STATUS.crit, marginTop: SP.xs }}><BellOutlined /> Rule fired · running</Text> : null}
      <Flex align="center" gap={SP.xs} style={{ marginTop: SP.md, borderTop: '1px solid #e9ecf1', paddingTop: SP.sm }}>
        <span className="g-avatar">{g.owner.split(' ').map((w) => w[0]).join('').slice(0, 2)}</span>
        <Text style={{ fontSize: 12.5, whiteSpace: 'nowrap', flex: 1, minWidth: 0 }} ellipsis>{g.owner}</Text>
        <StageDots status={g.status} />
      </Flex>
    </Card>
  )
}

function ApproachCard({ a, onUse }: { a: SavedApproach; onUse: () => void }) {
  return (
    <Card size="small" className="g-card" styles={{ body: { padding: `${SP.base}px ${SP.lg}px` } }}>
      <Flex justify="space-between" align="flex-start" gap={SP.sm}>
        <Text style={{ fontSize: 13.5, fontWeight: 500 }}>{a.name}</Text>
        <Tag style={{ marginInlineEnd: 0 }}>{a.plan.length} steps</Tag>
      </Flex>
      <ol className="g-steps">
        {a.plan.slice(0, 5).map((s) => <li key={s.id}>{s.title}</li>)}
      </ol>
      <Flex justify="space-between" align="center" style={{ marginTop: SP.sm }}>
        <Text type="secondary" style={{ fontSize: 12 }}>Saved by {a.savedBy}</Text>
        <Button size="small" type="link" style={{ padding: 0 }} onClick={onUse}>New goal from it →</Button>
      </Flex>
    </Card>
  )
}

function WatcherRow({ w, goals, onOpen, onFire, fresh }: { w: Watcher; goals: Goal[]; onOpen: (id: string) => void; onFire?: () => void; fresh?: boolean }) {
  const g = goals.find((x) => x.id === w.goalId)
  return (
    <Flex className={`g-watch${fresh ? ' is-fresh' : ''}`} align="center" gap={SP.sm}>
      <span style={{ color: BRAND_INK }}>{w.kind === 'rule' ? (w.source === 'external' ? <GlobalOutlined /> : <BellOutlined />) : <ClockCircleOutlined />}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <Text style={{ fontSize: 13, display: 'block' }}>{w.label}</Text>
        <Text type="secondary" style={{ fontSize: 12 }}>{w.condition}{w.kind === 'rule' ? (w.source === 'external' ? ' · on the internet, every morning' : ' · in our data, every snapshot') : ''} · {w.last}</Text>
      </div>
      <Tag color={w.state === 'Fired' ? 'warning' : w.state === 'Matched' ? 'processing' : undefined} style={{ marginInlineEnd: 0 }}>{w.state}</Tag>
      {onFire && g?.status === 'armed' ? <Button size="small" type="primary" ghost icon={<ThunderboltOutlined />} onClick={onFire}>{w.kind === 'rule' ? 'Simulate: rule fires' : 'Simulate: run now'}</Button> : null}
      {g ? <Button size="small" type="link" style={{ padding: 0 }} onClick={() => onOpen(g.id)}>goal →</Button> : null}
    </Flex>
  )
}

function GoalList() {
  const { goals, approaches, watchers, fire } = useGoalStore()
  const navigate = useNavigate()
  const justArmed = (useLocation().state as { justArmed?: string } | null)?.justArmed
  const armedRules = goals.filter((g) => g.trigger === 'rule' && g.status === 'armed').length
  const [bars, setBars] = useState<string[]>(armedRules || justArmed ? ['watchers'] : [])
  /* A rule that has not fired is not a goal on the board: it lives under "Watching for you". */
  const visible = useMemo(() => goals.filter((g) => !(g.trigger === 'rule' && g.status === 'armed')), [goals])

  return (
    <>
      <PageHeader
        title="Goals"
        subtitle="What you want to know or achieve. Your agents work it; you steer them in the chat."
        actions={<Button type="primary" icon={<PlusOutlined />} onClick={() => navigate(appPath('/goals/new'))}>New goal</Button>}
      />

      {justArmed ? <div className="g-armed-note">Rule saved and armed. It is under "Watching for you" below; it runs by itself when the condition is met, or simulate it there.</div> : null}
      <Row gutter={[SP.base, SP.base]} style={{ marginBottom: SP.xl }}>
        {visible.map((g) => (
          <Col key={g.id} xs={24} md={12} xl={8}>
            <GoalCard g={g} onOpen={() => navigate(appPath(`/goals/${g.id}`))} />
          </Col>
        ))}
      </Row>

      <Collapse
        ghost
        size="small"
        className="g-bars"
        activeKey={bars}
        onChange={(k) => setBars(Array.isArray(k) ? (k as string[]) : [k as string])}
        items={[
          {
            key: 'watchers',
            label: <span className="g-bar-label">Watching for you <span className="g-bar-count">{watchers.length}</span>{armedRules ? <Text type="secondary" style={{ fontSize: 12, marginLeft: 8, fontWeight: 400 }}>· {armedRules} rule{armedRules === 1 ? '' : 's'} armed</Text> : null}</span>,
            children: (
              <div className="g-watchers">
                {watchers.map((w) => (
                  <WatcherRow key={w.id} w={w} goals={goals} fresh={!!justArmed && w.goalId === justArmed} onOpen={(id) => navigate(appPath(`/goals/${id}`))} onFire={w.goalId ? () => { fire(w.goalId!, 'Agent'); window.scrollTo({ top: 0, behavior: 'smooth' }) } : undefined} />
                ))}
              </div>
            ),
          },
          {
            key: 'approaches',
            label: <span className="g-bar-label">Saved approaches <span className="g-bar-count">{approaches.length}</span></span>,
            children: (
              <div className="g-hscroll">
                {approaches.map((a) => (
                  <div key={a.id} className="g-hitem">
                    <ApproachCard a={a} onUse={() => navigate(appPath('/goals/new'), { state: { approachId: a.id } })} />
                  </div>
                ))}
              </div>
            ),
          },
        ]}
      />
    </>
  )
}

/* ------------------------------------------------------------------ route entry */

export default function GoalsPage() {
  const { goalId } = useParams()
  return <GoalsJourney routeId={goalId} />
}

/* The earlier list, goal and new-goal screens stay in the source, not routed, so they can be brought back. */
export const EARLIER = { GoalList, GoalWorkspace, NewGoalChat, GoalsHub, useGoalStore, useLocation, useMemo, PageHeader, Button, appPath }
