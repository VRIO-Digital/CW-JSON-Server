// New Role and Graph Studio walkthrough for the Veolia CPA prototype. Usage: node test/walk_newrole.mjs [file] [widths]
import { createRequire } from 'module'; const { chromium } = createRequire(import.meta.url)(process.env.PLAYWRIGHT_PATH || 'playwright')
const FILE = process.argv[2] || new URL('../dist-offline/index.html', import.meta.url).pathname
const WIDTHS = (process.argv[3] || '1280,1440,1728').split(',').map(Number)
const F = 'file://' + FILE
const SHOTS = process.env.SHOTS || new URL('./shots', import.meta.url).pathname
const BANNED = /Keolis|Valmont|€|—|use case|Use case|New Graph|Weaver\b|\bAgent [A-Z][a-z]+|Gmail/

const b = await chromium.launch()
let total = 0, fails = 0
for (const W of WIDTHS) {
  console.log(`== ${W}`)
  const p = await b.newPage({ viewport: { width: W, height: 900 } })
  const errs = []
  p.on('pageerror', (e) => errs.push(String(e)))
  p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()) })
  const ok = (c, m) => { total++; if (!c) { fails++; console.log('  FAIL', m) } }
  const shot = (n, full = false) => p.screenshot({ path: `${SHOTS}/newrole_${W}_${n}.png`, fullPage: full })
  const main = () => p.locator('.ant-layout-content, main').first()
  const clean = async (where) => { const t = await main().innerText(); const m = t.match(BANNED); ok(!m, `no banned text on ${where}${m ? `: "${m[0]}"` : ''}`) }
  const next = () => p.getByRole('button', { name: /^Next/ }).click()
  const toast = async (re) => { await p.waitForTimeout(300); return re.test(await p.locator('.ant-message').innerText().catch(() => '')) }
  const waitFor = async (fn, ms = 20000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await fn()) return true; await p.waitForTimeout(250) } return false }

  /* ---------- the first screen: add a new role */
  await p.goto(F + '#/K/new-graph'); await p.waitForTimeout(1800)
  ok(/Add a new role/.test(await main().innerText()), 'the first screen says Add a new role')
  ok(await p.locator('.nr-card').count() === 0, 'no role cards on the first screen')
  ok(await p.locator('.nr-opt').count() === 4, 'four roles to pick from')
  await shot('01_landing'); await clean('first screen')

  /* ---------- step 1: role */
  ok((await p.locator('.ng-step').allInnerTexts()).map((t) => t.replace(/\d/g, '').trim()).join('|') === 'Role|Responsibilities|Sources|Personas|Metrics|Hero questions', 'six steps: Role, Responsibilities, Sources, Personas, Metrics, Hero questions')
  await next(); ok(await toast(/Pick the role/), 'Next asks for a role first')
  await p.locator('.nr-opt', { hasText: 'Capital Program Analyst' }).click()
  ok(await p.locator('.nr-ind').count() === 5, 'five industries offered')
  ok(/Transport and transit/.test(await p.locator('.nr-inds').innerText()), 'transport and transit offered')
  ok(await p.getByTestId('utilities').count() === 0, 'no utilities listed before an industry is picked')
  await p.locator('.nr-ind', { hasText: 'Wastewater' }).click(); await p.waitForTimeout(3000)
  ok(/No wastewater utilities/.test(await p.getByTestId('utilities').innerText()), 'wastewater: none found in the connected data')
  await p.locator('.nr-ind', { hasText: /^Water/ }).click(); await p.waitForTimeout(1200)
  ok(/Finding the water utilities/.test(await p.getByTestId('utilities').innerText()) && await p.locator('.nr-util').count() === 0, 'water: reading the connected data, utilities not shown yet')
  await shot('02_finding')
  ok(await waitFor(async () => (await p.locator('.nr-util').count()) === 5, 8000), 'five utilities found after the read')
  ok(await p.locator('.nr-util.is-on').count() === 4, 'the four regulated utilities are selected, shared services is not')
  ok(/Ardenia Public Service Commission/.test(await p.getByTestId('utilities').innerText()), 'utilities show region and commission')
  ok(await p.locator('text=Works for').count() === 0, 'no Works for field')
  await next(); ok(await toast(/email address/), 'Next asks for the reports-to email')
  await p.locator('#nr-reports').fill('priya.raman@vriodigital.com')
  ok(/Capital Program Analyst · Ardenia, Belmara, Corvale, Dunmoor/.test(await p.locator('#nr-name').inputValue()), 'role name filled from role and utilities')
  await shot('03_role', true); await clean('step 1')
  await next(); await p.waitForTimeout(600)

  /* ---------- step 2: responsibilities */
  ok(await p.locator('.ng-run-inline').count() === 1 && await p.locator('.nr-area').count() === 0, 'responsibilities are drafted after a short wait')
  ok(await waitFor(async () => (await p.locator('.nr-area').count()) === 9, 6000), 'nine responsibilities drafted')
  await p.locator('.nr-area[data-area=sched] .ant-checkbox-input').uncheck()
  ok(/Out of scope/.test(await p.locator('.nr-area[data-area=sched]').innerText()) && await p.locator('.nr-area[data-area=sched] .gc-chip').count() === 3, 'taking one out asks for a reason')
  await p.locator('.nr-area[data-area=cost] .nr-area-name').click()
  await p.locator('.nr-area[data-area=cost] input[placeholder="Add a task"]').fill('Reconcile contractor pay applications'); await p.locator('.nr-area[data-area=cost] button', { hasText: 'Add' }).click()
  ok(/Reconcile contractor pay applications/.test(await p.locator('.nr-area[data-area=cost]').innerText()), 'a task added to a responsibility')
  await p.locator('input[type=file]').first().setInputFiles({ name: 'Northline_Job_Description_Capital_Program_Analyst.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-1.4') })
  await p.waitForTimeout(600)
  ok(/reading/.test(await p.getByTestId('jd').innerText()), 'job description is read after a short wait')
  ok(await waitFor(async () => (await p.locator('.nr-find').count()) === 3, 6000), 'three suggestions from the job description')
  await p.locator('.nr-find', { hasText: 'Add a task' }).getByRole('button', { name: 'Accept' }).click()
  ok(/Review contractor claims/.test(await p.locator('.nr-area[data-area=cost]').innerText()), 'accepted task lands in Cost tracking and forecasting')
  await p.locator('.nr-find', { hasText: 'out of scope' }).getByRole('button', { name: 'Accept' }).click()
  ok(/Out of scope/.test(await p.locator('.nr-area[data-area=comp]').innerText()), 'accepted scope change takes Grant and loan compliance out')
  ok(/7 of 9 responsibilities in scope/.test(await main().innerText()), '7 of 9 in scope')
  await shot('04_resp', true); await clean('step 2')
  await next(); await p.waitForTimeout(1000)

  /* ---------- step 3: sources */
  const srcText = await p.locator('.ng-form').innerText()
  ok(await p.locator('.ng-source').count() === 5, 'five connected sources')
  ok(/Northline EPBCS/.test(srcText) && /Capital Program documents/.test(srcText) && /Capital program mailbox/.test(srcText), 'EPBCS, PeopleSoft, PMO, OneDrive and Outlook')
  await next(); ok(await toast(/Select at least one source/), 'Next asks for at least one source')
  for (const c of await p.locator('.ng-check').all()) await c.click()
  await shot('05_sources', true); await clean('step 3')
  await next(); await p.waitForTimeout(800)

  /* ---------- step 4: personas */
  await p.getByRole('button', { name: /Suggest personas/ }).click(); await p.waitForTimeout(700)
  ok(await p.locator('.ng-run-inline').count() === 1, 'personas are drafted after a short wait')
  ok(await waitFor(async () => (await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).count()) >= 5, 6000), 'personas suggested for the role')
  for (let i = 0; i < 4; i++) { await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).first().click(); await p.waitForTimeout(120) }
  ok(/SVP Capital Delivery/.test(await main().innerText()), 'committee chair among the personas')
  await shot('06_personas', true); await clean('step 4')
  await next(); await p.waitForTimeout(800)

  /* ---------- step 5: metrics */
  await p.getByRole('button', { name: /Suggest metrics/ }).click()
  ok(await waitFor(async () => (await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).count()) > 5, 7000), 'metrics suggested')
  ok(/Matters to/.test(await main().innerText()), 'each metric says which personas it matters to')
  for (let i = 0; i < 5; i++) { await p.locator('.ng-suggest-row button', { hasText: /^Accept$/ }).first().click(); await p.waitForTimeout(120) }
  ok(await waitFor(async () => (await p.locator('.nr-sql').count()) === 5, 6000), 'a query is written for each kept metric')
  await p.locator('.nr-sql summary').first().click()
  ok(/SELECT[\s\S]*FROM/.test(await p.locator('.nr-sql pre').first().innerText()), 'the query reads the warehouse tables')
  await shot('07_metrics', true); await clean('step 5')
  await next(); await p.waitForTimeout(800)

  /* ---------- step 6: hero questions */
  await p.getByRole('button', { name: /Suggest/ }).first().click()
  ok(await waitFor(async () => (await p.locator('.ng-form button', { hasText: /^\+?\s*Add$/ }).count()) > 4, 7000), 'questions suggested')
  for (let i = 0; i < 4; i++) { await p.locator('.ng-form button', { hasText: /^\+?\s*Add$/ }).first().click(); await p.waitForTimeout(250) }
  ok(!(await p.getByRole('button', { name: /Save and build graph/ }).isDisabled()), 'Save and build is enabled')
  await shot('08_questions', true); await clean('step 6')
  await p.getByRole('button', { name: /Save and build graph/ }).click(); await p.waitForTimeout(2500)

  /* ---------- Graph Studio: the new role */
  ok(/graph-studio\/uc-/.test(p.url()), 'opens the role in Graph Studio')
  ok(/Capital Program Analyst · Ardenia, Belmara, Corvale, Dunmoor/.test(await main().innerText()), 'the new role is selected')
  ok((await p.locator('.ant-tabs-tab').allInnerTexts()).join('|') === 'Build|Bridge|Playground|Canvas|Versions', 'tabs: Build, Bridge, Playground, Canvas, Versions')
  await p.getByRole('button', { name: /Draft from my data model/ }).click(); await p.waitForTimeout(1200)
  ok(/Northline Water Group runs four regulated water utilities/.test(await p.locator('textarea').first().inputValue()), 'story drafted from the data model')
  await p.getByRole('button', { name: /Build graph/ }).click()
  { const okb = await waitFor(async () => /Complete · (\d+) of \1 documents/.test(await main().innerText()) && /\d+ tables/.test(await main().innerText()), 30000); const mt = await main().innerText(); ok(okb, `both lanes build (${(mt.match(/Complete · \d+ of \d+ documents/) ?? ['?'])[0]}; ${(mt.match(/\d+ tables/) ?? ['?'])[0]})`); console.log('  build:', (mt.match(/.{0,60}(of \d+ documents|\d+ tables).{0,40}/g) ?? []).slice(0, 4).join(' | ')) }
  await shot('09_built', true); await clean('Build')
  await p.locator('.ant-tabs-tab', { hasText: 'Bridge' }).click()
  ok(await waitFor(async () => /Bridge build 1/.test(await main().innerText()), 15000), 'the Bridge is formed')
  await p.getByRole('button', { name: /Accept all/ }).click(); await p.waitForTimeout(500)
  await p.locator('.ant-popover .ant-btn-primary, .ant-popconfirm .ant-btn-primary').first().click(); await p.waitForTimeout(1200)
  await p.getByRole('button', { name: /Publish v1/ }).click(); await p.waitForTimeout(1500)
  ok(await waitFor(async () => /answering/.test(await main().innerText()), 6000), 'published: the Bridge is answering')
  await shot('10_bridge'); await clean('Bridge')
  await p.locator('.ant-tabs-tab', { hasText: 'Playground' }).click(); await p.waitForTimeout(1500)
  const pg = await main().innerText()
  ok(/Forecast variance|Plant additions vs rate order|Annual plan delivery/.test(pg) && /SELECT/.test(pg), 'Playground holds the kept metrics with their queries')
  await clean('Playground')
  await p.locator('.ant-tabs-tab', { hasText: 'Canvas' }).click(); await p.waitForTimeout(2500)
  ok(/\d+ nodes/.test(await main().innerText()), 'Canvas draws the graph')
  await shot('11_canvas'); await clean('Canvas')
  await p.locator('.ant-tabs-tab', { hasText: 'Versions' }).click(); await p.waitForTimeout(1200)
  ok(/v1[\s\S]*published/.test(await main().innerText()), 'Versions: v1 published')
  await clean('Versions')

  /* ---------- back to New Role: a fresh wizard; the seeded role opens in Graph Studio */
  await p.locator('.ant-menu-item, a', { hasText: 'New Role' }).first().click(); await p.waitForTimeout(1500)
  ok(/Add a new role/.test(await main().innerText()) && await p.locator('.nr-card').count() === 0, 'New Role opens on a fresh Add a new role')
  await p.goto(F + '#/K/graph-studio/uc-capital-program-analyst-nw26a01'); await p.waitForTimeout(2500)
  const st = await main().innerText()
  ok(/Capital Program Analyst · Northline Water/.test(st) && /Build v1 · complete/.test(st) && /Graph v1 · published/.test(st), 'the seeded role: both lanes built and published')
  await clean('seeded role')
  ok(errs.length === 0, `no console errors${errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''}`)
  await p.close()
}
console.log(`${total} checks, ${fails} failures`)
await b.close()
process.exit(fails ? 1 : 0)
