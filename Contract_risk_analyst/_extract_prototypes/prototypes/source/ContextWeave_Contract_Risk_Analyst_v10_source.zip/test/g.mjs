import { chromium } from '/home/claude/cw/node_modules/playwright/index.mjs'
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
const p = await b.newPage({ viewport: { width: 1440, height: 1000 } })
await p.goto('file:///home/claude/cw/roles_work/dist-offline/index.html#/K/graph-studio'); await p.waitForTimeout(800)
await p.click('.gs-tabs button:has-text("Graph")'); await p.waitForTimeout(300)
await p.locator('[data-node="a:sched"]').click(); await p.waitForTimeout(500)
console.log(await p.locator('.gs-node.is-dim').count(), await p.locator('.gs-node.is-lit').count())
await p.screenshot({ path: 'test/shots/g.png' })
await b.close()
