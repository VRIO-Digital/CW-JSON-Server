// Records the Goals and Submissions layer from a built prototype (the 4 November 2026 flow). It drives the build through
// every demo path in one session, at a fast pace on a fixed demo clock, and writes what its stores hold: the transcripts
// and state files to <out>/03_goals, the submissions and the described outlines to <out>/04_submissions. Generated ids
// are renamed to stable ones in order of appearance, so a re-recording of the same build gives the same files.
// Usage: node record.mjs <tenant config .mjs> <built Goals and Submissions html> <out dir>   (PLAYWRIGHT_PATH may point at playwright)
import { createRequire } from 'module'
import fs from 'fs'
import path from 'path'
const { chromium } = createRequire(import.meta.url)(process.env.PLAYWRIGHT_PATH || 'playwright')
const T = (await import(path.resolve(process.argv[2]))).default
const file = path.resolve(process.argv[3]), out = process.argv[4]
const G = `${out}/03_goals`, S = `${out}/04_submissions`
fs.rmSync(`${G}/transcripts`, { recursive: true, force: true })
fs.mkdirSync(`${G}/transcripts`, { recursive: true }); fs.mkdirSync(S, { recursive: true })
const browser = await chromium.launch()
const ctx = await browser.newContext({ viewport: { width: 1728, height: 960 }, timezoneId: 'UTC' })
const page = await ctx.newPage()
const errs = []; page.on('pageerror', (e) => errs.push(e.message))
const Q = `?pace=0.05&clock=${T.clock}`
await page.goto('file://' + file + Q + '#/K/goals'); await page.waitForTimeout(1500)
const go = async (hash) => { await page.evaluate((h) => { window.location.hash = h }, hash); await page.waitForTimeout(600) }

const MAP = new Map()
const TOKEN = /(?<=[-_])m[a-z0-9]{7,11}(?![a-z0-9])/g
const REAL0 = Date.now()
/* A generated token is a base-36 time from this recording (with or without digits); a word that happens to look like one is left alone. */
const isStamp = (t) => { const ms = parseInt(t.slice(0, 8), 36); return /\d/.test(t) || (ms > REAL0 - 3600e3 && ms < Date.now() + 3600e3) }
const stable = (obj) => JSON.parse(JSON.stringify(obj, (k, v) => (k === 't0' ? undefined : v)).replace(TOKEN, (t) => { if (!isStamp(t)) return t; if (!MAP.has(t)) MAP.set(t, `${T.idPrefix}${String(MAP.size + 1).padStart(3, '0')}`); return MAP.get(t) }))
const W = (p, obj) => fs.writeFileSync(p, JSON.stringify(stable(obj), null, 2))
const J = () => page.evaluate(() => { const s = window.__cwJourney.useJourney.getState(); return s.current ? s.goals[s.current] : null })
const waitFor = async (fn, what, ms = 90000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await fn()) return true; await page.waitForTimeout(150) } throw new Error('timeout waiting for ' + what) }
const dump = async (name, note) => { const j = await J(); W(`${G}/transcripts/${name}.json`, { note, journey: j }); console.log('  transcript', name, j.stage, j.status, j.chat.length) }
const chip = (t) => page.locator('.gc-chip', { hasText: t }).first()
const tile = (sel, t) => page.locator(`${sel} .tile`, { hasText: t }).first()
const closeToasts = async () => { for (const x of await page.locator('.ant-notification-notice-close').all()) await x.click().catch(() => {}); await page.waitForTimeout(200) }
const showRail = async () => { if (!(await page.locator('.hub-rail').count())) { await page.locator('.hub-top .hub-icon[aria-label="Show the list"]').first().click(); await page.waitForTimeout(300) } }
const newGoal = async (mode) => { await go('#/K/goals'); if (await page.locator('.hub-new').count()) { await page.locator('.hub-new').click(); await page.waitForTimeout(400) } await page.locator('.ns-toggle button', { hasText: mode }).click(); await page.waitForTimeout(200) }
const send = () => page.locator('.composer.is-big .send').click()
const confirmDeliv = () => page.locator('[data-card="deliv"] [data-testid="deliv-confirm"]').click()
const idle = async (what) => { await waitFor(async () => { const j = await J(); return j && !j.prog && !j.typing }, what); await page.waitForTimeout(400) }
const subs = () => page.evaluate(() => window.__cwSubs.getState().submissions)
const stores = () => page.evaluate(() => { const st = window.__cwJourney.useJourney.getState(); return { goals: st.goals, order: st.order, saved: st.saved, start: st.start, notices: window.__cwJourney.useGoalStore.getState().notices, submissions: window.__cwSubs.getState().submissions } })
const N = T.notes

W(`${G}/seeded_state.json`, { _about: T.seededAbout, ...(await stores()) })

/* A. Answer once: two open points, the deliverables (one added in words), one click, run to the end, then two changes. */
const A = T.once
await newGoal('Answer once')
await page.getByText(A.example).click(); await send()
await waitFor(async () => (await page.locator(`.hc[data-q="${A.q1}"]`).count()) > 0, 'first question')
await page.waitForTimeout(300)
await dump(`${A.name}_01_first_question`, N.once01)
await tile(`.hc[data-q="${A.q1}"]`, A.t1).click()
if (A.q2) { await waitFor(async () => (await page.locator(`.hc[data-q="${A.q2}"]`).count()) > 0, 'second question'); await tile(`.hc[data-q="${A.q2}"]`, A.t2).click() }
await waitFor(async () => (await page.locator('[data-card="deliv"]').count()) > 0, 'deliverables card')
if (A.addFmt) {
  await page.locator('[data-card="deliv"] .dv-addlink').click()
  await page.locator('[data-card="deliv"] .dv-add .dv-mode', { hasText: A.addFmt }).click()
  await page.locator('[data-card="deliv"] .dv-add textarea').fill(A.addText)
  await page.locator('[data-card="deliv"] .dv-add .ant-btn-primary').click(); await page.waitForTimeout(300)
}
await dump(`${A.name}_02_deliverables`, N.once02)
await confirmDeliv()
await waitFor(async () => { const j = await J(); return j.findings.length >= 2 }, 'running')
await dump(`${A.name}_03_running`, N.once03)
await waitFor(async () => !!(await J()).prog, 'building')
await waitFor(async () => (await J()).prog?.shown >= 3, 'building parts')
await dump(`${A.name}_04_building`, N.once04)
await waitFor(async () => (await J()).status === 'delivered', 'delivered')
await idle('delivered')
await dump(`${A.name}_05_delivered`, N.once05)
await page.evaluate(() => { const s = window.__cwJourney.useJourney.getState(); window.dispatchEvent(new CustomEvent('cw:tab', { detail: { id: s.current, tab: 'findings' } })) }); await page.waitForTimeout(400)
await page.locator(`.gp .reco[data-rec="${A.switchTo}"] .ant-btn`, { hasText: 'Use this instead' }).click()
await waitFor(async () => (await J()).chosen === A.switchTo, 'switched option')
await waitFor(async () => { const j = await J(); const ss = await subs(); return !j.prog && ss.filter((x) => x.journeyId === j.id).every((x) => x.version === 2) && /earlier version/.test(j.chat[j.chat.length - 1].text) }, 'rebuilt v2')
await idle('v2')
await dump(`${A.name}_06_option${A.switchTo.slice(1)}_rebuilt`, N.once06)
await chip(A.steer).click(); await page.waitForTimeout(600)
await page.locator('.diff .ant-btn-primary').last().click()
await waitFor(async () => { const j = await J(); const ss = await subs(); return !j.prog && ss.filter((x) => x.journeyId === j.id).every((x) => x.version === 3) && new RegExp(A.steerDone).test(j.chat[j.chat.length - 1].text) }, 'steered v3')
await idle('v3')
await page.locator('[data-card="delivered"] .ant-btn', { hasText: 'Save this plan' }).last().click().catch(() => {}); await page.waitForTimeout(800)
await idle('saved')
await dump(`${A.name}_07_steered_rebuilt_saved`, N.once07)
const onceId = (await J()).id

/* B. The same goal with web search and the analyst's working notes: the notes answer the open points, so only the deliverables are asked. */
await newGoal('Answer once')
await page.getByText(A.example).click()
await page.locator('.composer.is-big .cmp-btn').click(); await page.locator('.cmenu .mi', { hasText: 'Web search' }).click(); await page.waitForTimeout(200)
for (const nf of (A.notesFiles ?? [A.notesFile])) { await page.locator('.composer.is-big .cmp-btn').click(); await page.locator('.cmenu .mi', { hasText: A.notesMenu }).click(); await page.locator('.cmenu .mi', { hasText: nf }).click(); await page.waitForTimeout(200) }
await send()
await waitFor(async () => (await page.locator('[data-card="deliv"]').count()) > 0, 'B deliverables')
await page.locator(`[data-card="deliv"] .dv-row[data-deliv="${A.untick}"] .ant-checkbox-input`).uncheck(); await page.waitForTimeout(200)
await confirmDeliv()
await waitFor(async () => (await J()).status === 'delivered', 'B delivered'); await idle('B')
await dump(`${A.name}_documents_web`, N.onceDocs)

/* C. The seeded watch fires: run, choose, build, act; one action held for your OK; approved. */
const Wt = T.watch
await go('#/K/goals'); await showRail()
await page.locator('[id="j-standing"] .rl-mini').first().click()
await waitFor(async () => { const j = await J(); return j?.id === Wt.seedId && j.findings.length >= 2 }, 'watch running')
await dump('watch_rule_01_fired_running', N.watch01)
await waitFor(async () => (await J()).status === 'executed', 'watch handled'); await idle('watch handled'); await closeToasts()
await dump('watch_rule_02_handled_one_waiting', N.watch02)
W(`${G}/notifications_after_watch.json`, await page.evaluate(() => window.__cwJourney.useGoalStore.getState().notices))
await page.locator('.gp .dl-acts .ant-btn', { hasText: 'Approve' }).first().click()
await waitFor(async () => (await J()).execActs.some((a) => a.state === 'approved'), 'approved'); await idle('approved')
await dump('watch_rule_03_approved', N.watch03)
const watchId = (await J()).id

/* D. A new watch from the example: two questions, the deliverables and the actions (one switched to run by itself), armed. */
await newGoal('Keep watching')
await page.getByText(Wt.example).click(); await send()
await waitFor(async () => (await page.locator('.hc[data-q="fires"]').count()) > 0, 'fires')
await tile('.hc[data-q="fires"]', Wt.fires).click()
await waitFor(async () => (await page.locator('.hc[data-q="tell"]').count()) > 0, 'tell')
await tile('.hc[data-q="tell"]', Wt.tell).click()
await waitFor(async () => (await page.locator('[data-card="deliv"] .dv-act').count()) > 0, 'watch deliverables')
await page.locator(`[data-card="deliv"] .dv-act[data-act="${Wt.autoAct}"] button`, { hasText: 'By itself' }).click(); await page.waitForTimeout(200)
await confirmDeliv()
await waitFor(async () => (await J()).stage === 'armed', 'armed'); await idle('armed')
await dump('watch_new_armed', N.watchNew)

/* E. The same positions as a one-off: nothing to clarify, the deliverables, run, delivered. */
await newGoal('Answer once')
await page.getByText(T.overrun.chip).click(); await send()
await waitFor(async () => (await page.locator('[data-card="deliv"]').count()) > 0, 'E deliverables')
await confirmDeliv()
await waitFor(async () => (await J()).status === 'delivered', 'E delivered'); await idle('E')
await dump('shortfall_once', N.overrun)

/* F. A goal in the analyst's own words with no recorded analysis. */
await newGoal('Answer once')
await page.locator('.composer.is-big textarea').fill(T.generic.text); await send()
await waitFor(async () => (await page.locator('[data-card="deliv"]').count()) > 0, 'F deliverables')
await confirmDeliv()
await waitFor(async () => (await J()).status === 'ready', 'F question'); await idle('F')
await chip('Drop it from the goal').click(); await page.waitForTimeout(600); await idle('F2')
await dump('generic_typed_goal', N.generic)

/* G. The once plan as a schedule: armed, run now, rebuilt and sent by itself. */
await newGoal('Keep watching')
await page.getByText(T.schedule.chip).click(); await send()
await waitFor(async () => (await page.locator('.hc[data-q="tell"]').count()) > 0, 'G tell')
await tile('.hc[data-q="tell"]', T.schedule.tell).click()
await waitFor(async () => (await page.locator('[data-card="deliv"]').count()) > 0, 'G deliverables')
await confirmDeliv()
await waitFor(async () => (await J()).stage === 'armed', 'G armed'); await idle('G armed')
await page.locator('.panel-actions button', { hasText: 'Simulate' }).click()
await waitFor(async () => (await J()).status === 'executed', 'G executed'); await idle('G'); await closeToasts()
await dump(T.schedule.name ?? 'schedule_monthly_run', N.schedule)

/* H. Submissions: make more from the analyses that have run. */
const M = T.more
await go(`#/K/goals/${onceId}`); await page.waitForTimeout(500)
await chip('Make more deliverables in Submissions').click()
await waitFor(async () => (await page.locator('[data-card="make"]').count()) > 0, 'make card')
await page.locator(`[data-card="make"] .dv-row[data-deliv="${M.onceExtra}"] .ant-checkbox-input`).check()
await page.locator('[data-card="make"] [data-testid="deliv-confirm"]').click()
await waitFor(async () => (await subs()).some((x) => new RegExp(M.onceTitle).test(x.title)) && (await page.locator('.hc-out').count()) > 0, 'once extra built')
await page.waitForTimeout(600)
await chip('Make another from the same analysis').click(); await page.waitForTimeout(600)
await page.locator('.hub-input textarea').fill(M.dashboard); await page.keyboard.press('Enter')
await waitFor(async () => (await subs()).some((x) => x.format === 'Dashboard') && (await page.locator('.hc-out').count()) > 0, 'dashboard built')
await page.waitForTimeout(800)
await go(`#/K/goals/${watchId}`); await page.waitForTimeout(500)
await page.locator('[data-card="delivered"] .ant-btn', { hasText: 'Make more in Submissions' }).last().click()
await waitFor(async () => (await page.locator('[data-card="make"]').count()) > 0, 'watch make card')
await page.locator(`[data-card="make"] .dv-row[data-deliv="${M.watchExtra}"] .ant-checkbox-input`).check()
await page.locator('[data-card="make"] [data-testid="deliv-confirm"]').click()
await waitFor(async () => (await subs()).some((x) => new RegExp(M.watchTitle).test(x.title)) && (await page.locator('.hc-out').count()) > 0, 'watch extra built')
await page.waitForTimeout(800)

const WITH_VISUALS = () => { const goals = window.__cwJourney.useGoalStore.getState().goals; const V = window.__cwVisuals; return window.__cwSubs.getState().submissions.map((s) => { const g = goals.find((x) => x.id === s.goalIds[0]); return { ...s, sections: s.sections.map((sec) => { const v = g ? V.visualForFormat(g, sec.role, sec.heading, s.format) : null; return { ...sec, visual: v ? { kind: v.kind, title: v.title, note: v.note, table: V.tableOf(v), data: v.data } : null } }) } }) }
W(`${S}/submissions_recorded.json`, await page.evaluate(`(${WITH_VISUALS.toString()})()`))
W(`${S}/templates_after_session.json`, await page.evaluate(() => window.__cwSubs.getState().templates))
W(`${S}/described_outlines.json`, await page.evaluate(() => { const D = window.__cwDesigner; const goals = window.__cwJourney.useGoalStore.getState().goals; const V = window.__cwVisuals
  const o = {}
  for (const [gid, xs] of Object.entries(D.EXAMPLE_BRIEFS)) { const g = goals.find((x) => x.id === gid); if (!g) continue; o[gid] = xs.map((x) => { const prop = D.designOutline(x.format, x.text, g); return { format: x.format, text: x.text, proposal: prop, visuals: prop.sections.map((s) => { const v = V.visualForFormat(g, s.role, s.heading, x.format, s.hint); return v ? { kind: v.kind, title: v.title } : null }) } }) }
  return o }))
const end = await stores()
W(`${G}/executed_analyses.json`, { _about: 'The analyses that have run at the end of the recorded session, as Submissions lists them: each with the run, the option its deliverables rest on (and who chose it), and every deliverable made from it, in the goal or later in Submissions (delivery id to submission id).',
  analyses: end.order.map((id) => end.goals[id]).filter((j) => Object.keys(j.built).length).map((j) => ({ id: j.id, title: j.title, run: j.mode === 'watch' && j.runs.length ? j.runs[j.runs.length - 1].label : j.title, mode: j.mode, case: j.case, status: j.status, executedAt: j.executedAt, agent: j.agent.name,
    chosen: j.chosen, chosenBy: j.chosenBy, option: j.recs.find((r) => r.id === j.chosen)?.title, built: j.built, actions: j.execActs })) })
W(`${G}/session_end_state.json`, { _about: 'The Goals list at the end of the recorded session, one line per goal, and the saved plans.', order: end.order, saved: end.saved,
  goals: Object.fromEntries(end.order.map((id) => { const j = end.goals[id]; return [id, { id, title: j.title, mode: j.mode, kind: j.kind, case: j.case, stage: j.stage, status: j.status, agent: j.agent.name, chosen: j.chosen ?? null, chosenBy: j.chosenBy ?? null, built: j.built, runs: j.runs }] })) })
await browser.close()
console.log(errs.length ? 'page errors: ' + errs.join(' | ') : `recorded, no page errors · ${MAP.size} ids made stable`)
if (errs.length) process.exit(1)
