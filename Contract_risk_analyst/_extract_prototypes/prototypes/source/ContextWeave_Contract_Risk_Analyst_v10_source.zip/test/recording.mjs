export default {
  clock: '2026-11-19T14:00:00Z', idPrefix: 'nc',
  seededAbout: "What the Goals store opens with: only Renee Halvorsen's armed contract risk watch and the two saved plans. Executed and Submissions start empty.",
  once: { name: 'once_renewals', example: 'Use the renewal risk review example', q1: 'four', t1: 'Count them', q2: 't3', t2: 'Keep the scorecard you agreed',
    addFmt: 'Memo', addText: 'A one-page memo for Renee Halvorsen on the quiet contracts with a client-side sign and who leads each',
    switchTo: 'r3', steer: 'Leave the evergreen contracts out', steerDone: 'with the evergreen contracts left out',
    notesMenu: 'OneDrive', notesFile: 'Renewal_review_working_notes_2026-11.xlsx', untick: 'sub-rn-brief' },
  watch: { seedId: 'g-rule-contract-risk', example: 'Use the contract risk example', answers: [['frame', 'No. Propose one']] },
  overrun: { chip: 'Harlow Creek moved from 2 to 3 overnight: why, and what do we do?' },
  generic: { text: 'What is the carbon footprint of our plants?' },
  schedule: { chip: 'Renewal review before every portfolio review', tell: 'Just me', name: 'schedule_quarterly_run' },
  more: { onceExtra: 'sub-rn-backtest', onceTitle: 'Back-test note', dashboard: 'a one-page dashboard of the renewals by region for Renee Halvorsen', watchExtra: 'sub-risk-review', watchTitle: 'Monthly portfolio risk review' },
  notes: {},
}
