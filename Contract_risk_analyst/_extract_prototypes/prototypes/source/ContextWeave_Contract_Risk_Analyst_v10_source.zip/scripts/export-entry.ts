/* Exports the Goals and Submissions seed data of the prototype as JSON for the demo data package. */
import { writeFileSync, mkdirSync } from 'node:fs'
import { AGENT_POOL, GOALS, STATUS_LABEL, TRIGGER_LABEL, WATCHERS } from '../src/data/goalCases'
import { TEMPLATES } from '../src/data/submissionTemplates'
import { EXAMPLE_BRIEFS, OUTPUT_FORMATS, designOutline } from '../src/data/outputDesigner'
import { useGoalStore } from '../src/store/goalStore'
import { useSubmissionStore } from '../src/store/submissionStore'
import type { Goal } from '../src/data/goalCases'
import { LINEAGE, visualCatalogue, visualFor } from '../src/data/visuals'

const out = process.env.OUT ?? './export'
mkdirSync(`${out}/10_goals`, { recursive: true })
mkdirSync(`${out}/11_submissions`, { recursive: true })
mkdirSync(`${out}/00_merged`, { recursive: true })
const w = (p: string, v: unknown) => writeFileSync(`${out}/${p}`, JSON.stringify(v, null, 2) + '\n')

const gs = useGoalStore.getState()
const ss = useSubmissionStore.getState()
const meta = {
  package: 'keolis_demo_data_package_updates_2026-10-15',
  tenant: 'Keolis Valmont SAS (fictional)',
  dataset: 'KEOLIS',
  asOf: '2026-09-22',
  today: '2026-10-15',
  builds_on: ['keolis_demo_data_package_2026-09-24', 'keolis_test_data_package_2026-09-25'],
  exported_from: 'ContextWeave_Keolis_Demo_offline.html source (analysis_src/v14): src/data/goalCases.ts, src/data/submissionTemplates.ts, src/store/goalStore.ts, src/store/submissionStore.ts',
  note: 'Every figure in goals.json is reproducible from datasets/keolisDrill.json and datasets/keolisUnstructured.json, which are derived from the test data package warehouse CSVs, corpus_text.json and mail_text.json. See _build/verify.py.',
}
const lifecycle = {
  statuses: Object.entries(STATUS_LABEL).map(([key, label]) => ({ key, label })),
  triggers: Object.entries(TRIGGER_LABEL).map(([key, label]) => ({ key, label })),
  transitions: {
    person: ['plan-review', 'analysing', 'findings-ready | needs-input', 'accepted'],
    schedule: ['plan-review', 'armed', 'analysing (runs by itself on the schedule)', 'findings-ready | needs-input', 'accepted'],
    rule: ['armed (set at creation; shown only under "Watching for you")', 'fired (rule fires or is simulated: notification + draft goal at the top, stopped at the approach)', 'analysing (the analyst starts it)', 'findings-ready | needs-input', 'accepted'],
  },
  stage_dots: ['Goal', 'Approach', 'Findings', 'Data', 'Decision', 'Submissions'],
  agent_action_timing_ms: {
    'rule | resolve': 2600, read_document: 2800, read_mail: 2400, read_table: 2000, 'sum | compute | compare | trace | mark': 1300, 'rank | assign | compose': 2200, check: 900, other: 1600,
    step_open: 1400, step_close: 900, jitter: '0.85 to 1.15 of the base',
  },
  notice_kinds: ['fired', 'ran', 'findings', 'needs-input'],
  rule_condition_sources: { data: 'checked in the published graph at every snapshot', external: 'checked on the internet every morning (tariffs, indices, regulation, supplier and authority news); e.g. "tariffs on steel raised by 20%"' },
  action_line_format: '"<tool> <target> → <result>" ; split on " → " for the agent log',
}

w('10_goals/agents.json', { _meta: meta, agents: AGENT_POOL })
w('10_goals/goals.json', { _meta: meta, goals: GOALS })
w('10_goals/goals_seeded_state.json', { _meta: { ...meta, note: 'The store state the prototype opens with: the rule goal armed and stripped of its findings (they land when the analyst starts it), the schedule goal with findings ready.' }, goals: gs.goals })
w('10_goals/watchers.json', { _meta: meta, watchers: WATCHERS })
w('10_goals/saved_approaches.json', { _meta: meta, approaches: gs.approaches })
w('10_goals/notices.json', { _meta: { ...meta, note: 'Empty at open: a notice is written when a rule fires, a scheduled run starts, findings land or a question is raised.' }, notices: gs.notices, example: { id: 'n-g-over-budget-p-vm-046-xxxx', at: '2026-09-22T07:05:00Z', kind: 'fired', goalId: 'g-over-budget-p-vm-046', title: 'Rule fired: Bus washing plant (P-VM-046) is 12.4% over budget: what can still be done?', text: 'Forecast at completion against the approved budget, funded projects in delivery or commissioning, checked at every snapshot. Review the approach, then start the analysis.', read: false, tab: 'approach' } })
w('10_goals/lifecycle.json', { _meta: meta, ...lifecycle })
w('11_submissions/templates.json', { _meta: { ...meta, files_in: 'prototypes/goals_submissions/templates/' }, section_roles: ['purpose', 'summary', 'findings', 'options', 'why', 'evidence', 'assumptions', 'next', 'free'], stages: ['brief', 'template', 'outline', 'draft', 'reviewed'], templates: TEMPLATES })
w('11_submissions/submissions.json', { _meta: meta, submissions: ss.submissions.filter((x) => x.origin === 'recommendation') })
const briefs = Object.entries(EXAMPLE_BRIEFS).flatMap(([goalId, list]) => list.map((b) => { const g = GOALS.find((x) => x.id === goalId)!; return { goalId, format: b.format, description: b.text, proposal: designOutline(b.format, b.text, g) } }))
w('11_submissions/output_formats.json', { _meta: { ...meta, note: 'The three ways a submission starts and the formats an author can describe. A recommendation always names a template that exists in the library (templateId). A described output has no template until the author saves its outline as one.' }, origins: ['recommendation', 'described', 'template'], formats: OUTPUT_FORMATS, example_briefs: briefs,
  actions_on_a_draft: { share: 'A link to the submission (hash route); for a dashboard the link opens the live view, not a copy.', download_by_format: { 'Slide pack': ['PowerPoint (.pptx): title slide + one slide per section, text left, the section picture right as PNG (pptxgenjs in the browser)'], Dashboard: ['PDF (browser print of the dashboard only)', 'Image (PNG rendered from the dashboard)'], Workbook: ['CSV (all sheets)'], Document: ['PDF', 'HTML page'], Memo: ['PDF', 'HTML page'], Email: ['HTML page'] } },
  live_dashboard: 'A Dashboard is always live: a described dashboard opens on its panels at once (stage draft, no brief step), every panel is computed from the goal and the drill data when the page opens, the banner shows the data as-of date and a refresh time, and the card carries a Live tag. Sources are not panels: the “Data behind the panels” (evidence) section is kept in the outline but shown only in the Data lineage drawer of the information card, with the tables behind each picture and the agent’s evidence lines.' })
/* The visuals each goal draws, computed from the drill data, with the series behind each picture. */
w('11_submissions/visuals.json', { _meta: { ...meta, note: 'Which picture a section earns (by goal, role and heading words) and the series behind it, computed live from datasets/keolisDrill.json by src/data/visuals.ts. Colours: plan #1f5fa8, actual/forecast #d97706 (validated for colour vision and contrast), status red #b42318 only for "above the 10% rule", with a label. Every chart has a table view.' },
  palette: { plan: '#1f5fa8', actual: '#d97706', status_critical: '#b42318', ink: '#0f1729', muted: '#5c6b84', grid: '#e3e6ec' },
  kinds: { bullet: 'one figure against its approved value, the 10% rule marked', hbar: 'variance per project, the 10% rule as a line, projects above it in status red with a label', 'bars-by-month': 'plan vs actual by month (forecast tail outlined), or posted ledger by month', 'line-snapshots': 'forecast at each working snapshot against the budget and the 10% line', 'hbar-pairs': 'ordered against received per order line', table: 'rows the reader scans', kpis: 'headline figures as tiles' },
  rules: [
    { goal: 'g-quarterly-committee', role: 'summary', visual: 'bullet (portfolio forecast vs approved)' }, { goal: 'g-quarterly-committee', role: 'findings', heading_words: 'month | fy2026 | cash | year | plan', visual: 'bars-by-month' }, { goal: 'g-quarterly-committee', role: 'findings', heading_words: 'project | 10% | variance | budget | category | glance | programme', visual: 'hbar' },
    { goal: 'g-quarterly-committee', role: 'assumptions', heading_words: 'provisional | forecast', visual: 'table (four projects with no forecast since June)' }, { goal: 'g-quarterly-committee', role: 'purpose', heading_words: 'decision | ask', visual: 'table (proposed change requests)' },
    { goal: 'g-over-budget-p-vm-046', role: 'summary', visual: 'bullet (P-VM-046 forecast vs approved)' }, { goal: 'g-over-budget-p-vm-046', role: 'findings', heading_words: 'order | supplier | received | design | lift | unit', visual: 'hbar-pairs' }, { goal: 'g-over-budget-p-vm-046', role: 'findings', heading_words: 'snapshot | december | forecast | how … got | over budget | breach | long', visual: 'line-snapshots' }, { goal: 'g-over-budget-p-vm-046', role: 'findings', heading_words: 'ledger | month | posted | 178 | spend', visual: 'bars-by-month (posted ledger)' },
    { goal: 'any', role: 'options', visual: 'table (options side by side, preferred first)' }, { goal: 'any', role: 'summary', visual: 'kpis (preferred recommendation figures)' },
  ],
  lineage: { note: 'Where each kind of picture reads its rows. Shown in the submission’s information card under “Data lineage” (a drawer), never on the dashboard itself; evidence-role sections are left out of dashboard panels and listed in the lineage drawer instead.', by_kind: LINEAGE },
  catalogue: visualCatalogue(GOALS) })
/* The worked journey: the slide pack described for the quarterly goal, created and taken to the draft, as the frontend should reproduce it. */
const qg = GOALS.find((x) => x.id === 'g-quarterly-committee') as Goal
const slideBrief = EXAMPLE_BRIEFS['g-quarterly-committee'].find((b) => b.format === 'Slide pack')!
const slideOutline = designOutline(slideBrief.format, slideBrief.text, qg)
const journeyId = ss.startDescribed(qg, slideBrief.text, slideOutline, 'Camille Perrin')
ss.update(journeyId, { title: 'Investment Committee Q3 2026: deck from a description' })
const tplId = ss.saveOutlineAsTemplate(journeyId, 'Slide pack: Q3 committee deck (described)', 'Camille Perrin')
ss.setStage(journeyId, 'template', 'Camille Perrin'); ss.setStage(journeyId, 'outline', 'Camille Perrin'); ss.setStage(journeyId, 'draft', 'Camille Perrin')
const journey = useSubmissionStore.getState().submissions.find((x) => x.id === journeyId)!
const savedTemplate = useSubmissionStore.getState().templates.find((t) => t.id === tplId)!
w('11_submissions/journey_described_slide_pack.json', {
  _meta: { ...meta, note: 'A worked example of the "describe a new output" journey, step by step, produced by the same code the prototype runs. Not seeded in the prototype: the demo walks it live with the "Example: slide pack" button.' },
  steps: [
    { step: 1, screen: 'Goal › 6 · Submissions, or Submissions › New submission › From a goal', action: 'Pick the goal and "Describe a new output"', goalId: qg.id, goal: qg.title, agent: qg.agent.name },
    { step: 2, screen: 'New submission › Describe a new output', action: 'Pick the format', format: slideBrief.format, formats_offered: OUTPUT_FORMATS.map((f) => f.key) },
    { step: 3, screen: 'New submission › Describe a new output', action: 'Describe what it should cover (or click "Example: slide pack")', description: slideBrief.text },
    { step: 4, screen: 'New submission › Describe a new output', action: `"Let ${qg.agent.name} propose the structure" (about 1.4 s)`, agent_reading: slideOutline.reading, audience: slideOutline.audience, proposed_outline: slideOutline.sections },
    { step: 5, screen: 'New submission › Describe a new output', action: 'Edit the slides if needed, then "Create the slide pack"', creates: { id: journeyId, origin: 'described', format: journey.format, title: journey.title, sections: journey.sections.map((x) => ({ heading: x.heading, role: x.role, from: x.from, filled: !!x.body })) } },
    { step: 6, screen: 'Submission › Brief', action: 'Title, audience and purpose are pre-filled from the goal and the description; Continue' },
    { step: 7, screen: 'Submission › Template', action: 'No library template fits: "Save as a template" puts the outline in the library', saved_template: savedTemplate },
    { step: 8, screen: 'Submission › Outline', action: 'Each slide filled from the goal where its role matches; edit, untick, add; "Build the draft"' },
    { step: 9, screen: 'Submission › Draft', action: 'Seven numbered slides as the reader sees them, each with its picture where the slide earns one; Share (link) and Download (HTML, PDF, image); Mark as reviewed', slides: journey.sections.map((x) => { const v = visualFor(qg, x.role, x.heading); return { heading: x.heading, role: x.role, visual: v ? { kind: v.kind, title: v.title, note: v.note } : null } }) },
  ],
  submission_at_draft: journey,
})
w('00_merged/db.KEOLIS.goals_submissions.json', { _meta: meta, agents: AGENT_POOL, goals: GOALS, watchers: WATCHERS, savedApproaches: gs.approaches, notices: gs.notices, lifecycle, templates: TEMPLATES, submissions: ss.submissions.filter((x) => x.origin === 'recommendation'), outputFormats: OUTPUT_FORMATS, exampleBriefs: briefs })
console.log('exported', GOALS.length, 'goals,', TEMPLATES.length, 'templates,', ss.submissions.length, 'submissions')
