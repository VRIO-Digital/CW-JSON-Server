#!/usr/bin/env bash
# Builds the offline HTML files of the Contract Risk Analyst prototype (version 10) into ./out_html/
# The Goals and Submissions file is the one to demo. The other two are the same journey with one menu item each.
set -e
cd "$(dirname "$0")"
mkdir -p out_html
VITE_CW_ONLY=journeys npx vite build -c vite.offline.config.ts --logLevel error && cp dist-offline/index.html out_html/ContextWeave_Contract_Risk_Analyst_v10_Goals_Submissions_offline.html
VITE_CW_ONLY=goals npx vite build -c vite.offline.config.ts --logLevel error && cp dist-offline/index.html out_html/ContextWeave_Contract_Risk_Analyst_v10_Goals_offline.html
VITE_CW_ONLY=submissions npx vite build -c vite.offline.config.ts --logLevel error && cp dist-offline/index.html out_html/ContextWeave_Contract_Risk_Analyst_v10_Submissions_offline.html
ls -la out_html
